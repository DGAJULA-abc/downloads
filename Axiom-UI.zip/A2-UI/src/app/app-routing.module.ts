import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './features/authentication/login/login.component';
import { DriverRosterComponent } from './features/plan/driver-roster/driver-roster.component';
// import { NotAuthorisedComponent } from './features/not-authorised/not-authorised.component';
import { AuthGuard } from './shared/_helper';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
    //canActivate: [AuthGuard]
  },
  {
    path: 'dashboard',
    loadChildren: () =>
      import('./features/dashboard/dashboard.module').then(
        (mod) => mod.DashboardModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'plan',
    loadChildren: () =>
      import('./features/plan/plan.module').then((mod) => mod.PlanModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'reconcile',
    loadChildren: () =>
      import('./features/reconcile/reconcile.module').then(
        (mod) => mod.ReconcileModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'setup',
    loadChildren: () =>
      import('./features/setup/setup.module').then((mod) => mod.SetupModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'search',
    loadChildren: () =>
      import('./features/search/search.module').then((mod) => mod.SearchModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'report',
    loadChildren: () =>
      import('./features/reports/reports.module').then(
        (mod) => mod.ReportsModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'reportview',
    loadChildren: () =>
      import('./features/reportview/report-view.module').then(
        (mod) => mod.ReportViewModule
      ),
    canActivate: [AuthGuard],
  },
  { path: 'driverroster', component: DriverRosterComponent },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard],
})
export class AppRoutingModule {}
