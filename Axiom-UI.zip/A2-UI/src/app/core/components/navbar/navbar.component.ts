import {
  Component,
  AfterViewChecked,
  OnInit,
  ChangeDetectorRef,
  Input,
  OnDestroy,
  ViewChild,
} from '@angular/core';
import { IUser } from '../../model/user.model';
import { UserService } from '../../../services/authentication/user.service';
import { NavigationStart, Router } from '@angular/router';
import { forkJoin, zip } from 'rxjs';


import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { NgFor, AsyncPipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { NavbarService } from './services/navbar.service';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { AutoComplete } from 'primeng/autocomplete';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit, AfterViewChecked, OnDestroy {
  //properties

  username: string = '';
  //isLoggedIn: boolean = true;
  siteCheck: boolean = false;
  selectedItem: string = 'Select a Site';

  siteControl = new FormControl('');
  siteOptions: string[] = [];
  userName: string = '';
  filteredOptions: Observable<string[]>;
  isNavbarShow: boolean = false;
  sub: Subscription;
  isAuthenticated: boolean = false;
  isLoggedIn: boolean= false;
  selectedSiteAdvanced: any[] | any;
  filteredSites: any[];
  sites: any[];
  selectedIdPageLoad: any = 'default value';
  browserRefresh: boolean = false;
  
  saveLayout: any = {
    heading: 'Save Layout',
    contentText: 'Are you sure you want to save this layout?'
  }
  subscription: Subscription;

  @ViewChild('autoCompleteInput') autoCompleteInput: AutoComplete;
  constructor(
    private readonly changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    public dialog: MatDialog,
    public authenticationService: AuthenticationService,
    public navbarService: NavbarService,
  ) { }

  ngAfterViewChecked(): void {

    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.selectedSiteAdvanced = null;
    //this.autoCompleteInput.inputEL.nativeElement.value = '';
 
  this.authenticationService.isLoggedIn.subscribe((data:any)=>{
    this.isLoggedIn = data
  })
      console.log("is log:",this.isLoggedIn)
    
    
    this.checkAuthNav();
    // this.getBuildVersion();
  }

  filterSite(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.sites.length; i++) {
      let sites = this.sites[i];
      if (sites.description.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(sites);
      }
    }

    this.filteredSites = filtered;
    // console.log('this.filteredSites', this.filteredSites);
  }

  checkAuthNav() {
    this.authenticationService.currentUserSubject.subscribe(data => {
      if(data) {
       this.getSiteView();
      }
      this.isAuthenticated = data;
      
    });
    this.authenticationService.checkAuth().subscribe(data => {
      this.isAuthenticated = data;
      if(data) {
       this.getSiteView();
      }
    });
  }

  getSiteView() {    
       this.authenticationService.fetchContext().subscribe(siteData => {
        // console.log("siteDatakkk >>", siteData);  
        this.sites = siteData.sites
        this.userName = siteData.userName;
        this.selectedSiteAdvanced = {id: siteData.selectedSite['id'], description: siteData.selectedSite['description']};
        // console.log("siteData.selectedSite['id'] > ", this.selectedSiteAdvanced);
        this.navbarService.referenceMetadataSubject.next(siteData.referenceMetadata);

       }); 
  }

  logout() {
    this.authenticationService.logout();
    console.log("Logout done"); 
    this.router.navigate(['/login']);
  }


  openDialog() {
    this.dialog.open(DialogComponent, {
      width: '600px',
      data: { callback: this.callBack.bind(this), defaultValue: this.saveLayout }
    });
  }

  callBack(name: string) {
    this.saveLayout = name;
  }

  onChangeSite(siteData: any) {
    //  console.log(" event data >>", siteData); 
     const  item = siteData.description ;
     
     this.navbarService.selectedSiteId=siteData.id;
     console.log("Selected Site ID-->", this.navbarService.selectedSiteId)
     this.getSiteSelectedIdNumber(siteData.id)
  }

  getSiteSelectedIdNumber(site: any) {

    this.navbarService.getSiteSelectedId(site).subscribe(()=>{
      this.isNavbarShow = true;
    })

  }


 getBuildVersion() {
  let versionText = this.navbarService.getVersionUI();
   let version =  this.navbarService.getVersion();
    forkJoin([versionText, version]).subscribe(version => {
        console.log("version >> ", version[0]);
        
    })
 }

 
  ngOnDestroy() {
      if(this.sub) {
        this.sub.unsubscribe()
      }
  }
}
