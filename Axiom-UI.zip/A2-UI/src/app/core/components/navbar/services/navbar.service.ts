import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { BehaviorSubject } from "rxjs";

// import { ViewReconcile } from '../models/view.reconcile.model';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {
  public referenceMetadataSubject = new BehaviorSubject<any>(null);
  referenceMetadata$ = this.referenceMetadataSubject.asObservable();

  constructor(
    private http: HttpClient
  ) { }
  selectedSiteId:number=0;
  getSiteView() :any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.contextView, options);
    //mock json
    //  return this.http.get<any>('assets/APIs/dashboard-view.json', options);
  }

  getVersion(): any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.version.mw, options);
  }

  getVersionUI(): any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.version.ui, options);
  }

  // getSites() {
  //   let options :any = [];
  //   return this.http.get<any>(`assets/APIs/dashboard-view.json`, options)
  //   // return this.http.get<any>(`${apiEndpoint.site}`, options)
 
  //   }

  getSiteSelectedId(site: any) {
    let options :any = [];
    return this.http.get<any>(`${apiEndpoint.selectSite}/${site}`, options)
  }  

  automaticCompletionStatus() {
    let options :any = [];
    return this.http.get<any>(`${apiEndpoint.autoCompleteStatus}`, options)
  }

}
