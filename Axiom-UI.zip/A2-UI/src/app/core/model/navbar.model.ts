export interface Version {
    
}