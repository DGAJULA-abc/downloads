/**
 * Global Translations Modal in one place
 *
 * Keys should be as snake_case to distinguish them from classes properties in components and their views
 */
export interface Translations {
  // login
  loginBtn: string;
  users: string;
  home: string;
  language: string;

}
