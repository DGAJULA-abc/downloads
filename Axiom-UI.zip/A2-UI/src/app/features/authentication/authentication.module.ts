import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from 'src/app/core/core.module';
import { SharedModule } from 'primeng/api';
@NgModule({
  declarations: [LoginComponent],
  imports: [CommonModule, ReactiveFormsModule,SharedModule, CoreModule],
  exports: [LoginComponent, CoreModule],
})
export class AuthenticationModule {}
