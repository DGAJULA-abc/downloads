import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';

// import { IUser } from '../../../core/model/user';
interface IUser {
    name: string;
    email: string;
    password: string;
}
@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    encapsulation:ViewEncapsulation.None,
})
export class LoginComponent implements OnInit {

    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    // isLogin:boolean = false;
    error = '';
    unAuthorizeText: any = {
    heading: 'Session Timeout',
    contentText: 'Your session timed out. You are redirected to login page.'
    }

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        public dialog: MatDialog
    ) {
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) {
            this.router.navigate(['/']);
            console.log("currentUserValue >> ",this.authenticationService.currentUserValue);
            
        }
    }

    ngOnInit() {

        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        this.loading = true;
        // this.authenticationService.loginMock().subscribe((data: any) => {
        //     if(data['user-status'] === 'authenticated') {
        //     //    this.isLogin = true;
        //     this.authenticationService.isAuthenticate.next(true);
        //        this.router.navigate(['/dashboard']);
        //     }
            
        // })
        this.authenticationService.login(this.f['username'].value, this.f['password'].value)
            .pipe(first())
            .subscribe(
                data => {
                    this.router.navigate(['/dashboard']);
                },
                error => {
                    this.error = error.message;
                    this.openDialog()
                    this.loading = false;
                });
                
    }

    openDialog() {
        this.dialog.open(DialogComponent, {
          width: '600px',
          data: { callback: this.callBack.bind(this), defaultValue: this.unAuthorizeText }
        });
      }
    
      callBack(name: string) {
        this.unAuthorizeText = name;
      }
   
}


