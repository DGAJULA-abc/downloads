import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AuthGuard } from 'src/app/shared/_helper';


import { ReportsComponent } from '../reports/reports.component';
import { ReconcileComponent } from '../reconcile/reconcile.component';
import { LandingPageComponent } from './landing-page/landing-page.component';

const dashboardRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      {
        path: '',
        // canActivate: [AuthGuard],
        component: LandingPageComponent,
      },
      {
        path: 'reports',
        component: ReportsComponent,
      },
      {
        path: 'reconcile',
        component: ReconcileComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(dashboardRoutes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
