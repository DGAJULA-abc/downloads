import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  constructor(
    private http: HttpClient
  ) { }
  getReconcileView() :any {
  
    let options :any = [{
        "referenceDataActiveStates": {
            "drivers": "ANY"
        }
    }];
    return this.http.post<any>(apiEndpoint.contextView, options);
    // return this.http.get<ViewReconcile>(`${apiEndpoint.reconcileView}`, options)
  }

  getDashboardViewApi() {
    let options :any = {
        "referenceDataActiveStates": {
            "drivers": "ANY"
        }
    };
    var headers = new HttpHeaders();
    return this.http
      .post<any>(`${apiEndpoint.contextView}`, { options }, { headers: headers })

      // .get<any>(`${localEndpoint.loginAuthenticate}`)
      .pipe(
        map(response => {
        //   this.currentUserSubject.next(true);
        //    this.fetchSiteSubject.next(response.sites); 
          //  this.dailogService.open();
        //   return true;
        console.log(response);
        
        })
      );
  }

  getListCompleteRunsheet() :any {
    let options :any = [];
    return this.http.get(`${localEndpoint.ListCompleteRunsheets}`, options);
  }

  getListIncompleteService() :any {
    let options :any = [];
    return this.http.get(`assets/APIs/list_incomplete.json`, options);
  }

}
