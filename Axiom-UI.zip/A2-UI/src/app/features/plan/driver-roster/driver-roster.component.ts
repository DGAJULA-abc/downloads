import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm, Validators, FormGroup } from '@angular/forms';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import {
  BulkCreateFetch,
  DriverRoster,
  DriverRosterTable,
} from '../models/plan.model';
import { PlanService } from '../services/plan.service';
import * as moment from 'moment';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Component({
  selector: 'app-driver-roster',
  templateUrl: './driver-roster.component.html',
  styleUrls: ['./driver-roster.component.scss'],
})
export class DriverRosterComponent implements OnInit {
  //display current date in header + tomorrow's date in calendar
  date_header: Date = new Date();
  date_instance: Date = new Date();
  date_tomorrow = new Date(
    this.date_instance.setDate(this.date_instance.getDate() + 1)
  );
  rosterdate: any;
  starttime: any;
  endtime: any;
  dateForm = this.fb.group({
    dateField: [''],
  });
  duplicatecalendar: boolean = true;
  minDate: Date;
  selectedsiteid: number = 0;
  ngOnInit(): void {
    this.minDate = this.date_header;
    this.selectedsiteid = this.navbarService.selectedSiteId;
    this.AllCustomerId(this.selectedsiteid);
  }

  constructor(
    public planService: PlanService,
    private fb: FormBuilder,
    public navbarService: NavbarService
  ) {}
  //AG Grid configuration
  private gridApi!: GridApi<DriverRosterTable>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: DriverRosterTable[] = [];
  columnDefs: ColDef[] = [
    {
      field: 'Driver',
      headerName: 'Driver',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { field: 'StartLocation', headerName: 'Start Location' },
    { field: 'Start', headerName: 'Start' },
    { field: 'Finish', headerName: 'Finish' },
    { field: 'Duration', headerName: 'Duration' },
    { field: 'Comments', headerName: 'Comments' },
  ];
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  ViewDataDrivers: any[];
  driver: DriverRoster;
  drivers: DriverRoster[] = [];
  onGridReady(params: GridReadyEvent<DriverRosterTable>) {
    this.gridApi = params.api;
    this.planService.getView().subscribe((result: any) => {
      this.ViewDataDrivers = result['ref'].drivers;
      // this.bulkCreateFetch();
      this.getDrivers(this.ViewDataDrivers);
    });
  }
  date_from_form: Date;
  //Get Rosters API
  GetRosters() {
    let start_date;
    start_date = moment(this.dateForm.controls['dateField'].value);
    start_date = start_date
      .set({
        hour: 0,
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    let chosendate = moment(s_india).valueOf();

    this.planService.bulkCreateFetch(chosendate).subscribe((result) => {
      this.Bulkcre = result['rosters'];
      this.bulkCreateFetch(this.Bulkcre);
    });
    this.rosterdate = moment(chosendate)
      .tz('Australia/Melbourne')
      .format('DD/MM/YYYY');
  }
  Bulkcre: BulkCreateFetch[];
  driversTable: DriverRosterTable[] = [];
  driverTable: DriverRosterTable;
  bulkCreateFetch(result: BulkCreateFetch[]) {
    this.driversTable=[];
    this.drivers.forEach((driver) => {
      this.driverTable = {
        Driver: '',
        Duration: '',
        Start: 0,
        Finish: 0,
        Comments: '',
        StartLocation: '',
      };
      result.forEach((element) => {
        if (driver.Id == element.driverId) {
          this.driverTable.Driver = driver.Driver;
          if (element.startTime) {
            this.driverTable.Start = moment(element.startTime)
              .tz('Australia/Melbourne')
              .format('HH:mm');
          } else {
            this.driverTable.Start = '';
          }
          if (element.endTime) {
            this.driverTable.Finish = moment(element.endTime)
              .tz('Australia/Melbourne')
              .format('HH:mm');
          } else {
            this.driverTable.Finish = '';
          }
          this.driverTable.StartLocation = element.startLocation;
          this.driverTable.Comments = element.comments;
          const mil = element.startTime - element.endTime;
          const hours = Math.floor(mil / 3600000);
          const minutes = Math.floor((mil % 3600000) / 60000);
          this.driverTable.Duration = hours + 'h ' + minutes + 'm';
          this.driversTable.push(this.driverTable);
        }
      });
    });
    this.rowData = this.driversTable;
  }

  //Get Driver List from View API
  getDrivers(viewdrivers: any[]) {
    viewdrivers.forEach((element) => {
      this.driver = {
        Id: 0,
        Driver: '',
        TruckId: '',
        CompanyId: '',
      };
      if (element.active == true) {
        if (element.surname != null && element.firstName != null) {
          this.driver.Driver =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName +
            ' (' +
            element.companyId +
            ')';
          this.driver.TruckId = element.truckId;
          this.driver.CompanyId = element.companyId;
          this.driver.Id = element.id;
        } else if (element.employeeName != null) {
          this.driver.Driver =
            element.employeeName + ' (' + element.companyId + ')';
          this.driver.TruckId = element.truckId;
          this.driver.CompanyId = element.companyId;
          this.driver.Id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
    // this.rowData = this.drivers;
  }
  //on Row Selection
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.duplicatecalendar = false;
    this.isDivVisible = true;
    selectedRows.forEach((row) => {
      if (row.Start) {
        this.starttime = row.Start;
      }
      else{
        this.starttime="00:00"
      }
      if (row.Finish) {
        this.endtime = row.Finish;
      }
      else{
        row.Finish="00:00"
      }
    });
  }
  customers: string[] = [];
  AllData: any[] = [];
  arr: string[] = [];
  public AllCustomerId(selectedId: number) {
    let unique: any[];
    this.planService.getAllData(selectedId).subscribe((result: any) => {
      this.AllData = result;
    });
  }
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];
  getLocationIds() {
    this.AllData.forEach((element: any) => {
      if (element.locationId != null) {
        this.location_arr.push(element.locationId);
      }
    });
    this.locationIds = this.location_arr.filter(
      (item, index) => this.location_arr.indexOf(item) === index
    );
  }
  filterLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.locationIds.length; i++) {
      let country = this.locationIds[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredLocations = filtered;
  }

  //Right side Card
  isDivVisible: boolean = false;
  submitForm() {}
  onClose() {
    this.isDivVisible = false;
  }
}
