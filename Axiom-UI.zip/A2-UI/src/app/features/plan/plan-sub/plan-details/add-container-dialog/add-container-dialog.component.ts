import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { PlanService } from '../../../services/plan.service';

@Component({
  selector: 'app-add-container-dialog',
  templateUrl: './add-container-dialog.component.html',
  styleUrls: ['./add-container-dialog.component.scss'],
})
export class AddContainerDialogComponent {
  //validation error message
  errorMessages = {
    containercode: [
      { type: 'required', message: 'Container code is required' },
    ],
  };

  types: string[] = [];
  selectedType: string;
  companys: string[] = [];
  selectedCompany: string;
  locations: string[] = [];
  selectedLocation: string;
  status: string[] = [];
  selectedStatus: string;
  AllData: any[] = [];

  addcontainerform: FormGroup;
  displayMessage: { [key: string]: string } = {};
  typemerge: { containerType: any; containerId: any; };
  statusmerge: { containerStatusId: any; containerId: any; };
  companymerge: { companyId: any; containerId: any; };
  descriptionmerge: { containerDesc: any; containerId: any; };
  weightmerge: { weightTonnes: any; containerId: any; };
  permanentmerge: { permanent: any; containerId: any; };
  onhiremerge: { onHire: any; containerId: any; };
  locationmerge: { locationId: any; containerId: any; };
  selected:boolean=false;
  condition:boolean=false;

  //Get all containertype, companys, location array from View API
  ngOnInit() {
    this.planService.getView().subscribe((result: any) => {
      this.AllData = result['ref'];
      this.getType(result['ref'].containerTypes);
      this.getCompanys(result['ref'].companys);
      this.getLocations(result['ref'].locations);
      this.getStatus(result['ref'].containerStatuses);
    });
    this.selected=false;
    this.condition=true;
    this.addcontainerform = this.formBuilder.group({
      containercode: ['', Validators.required],
      type: [],
      status: [],
      updated: [],
      company: [],
      description: [],
      weight: [],
      permanent: [],
      onhire: [],
      location: [],
      dropdate: [],
      pickup: [],
    });
  }
  constructor(
    public dialogRef: MatDialogRef<AddContainerDialogComponent>,
    private planService: PlanService,
    private formBuilder: FormBuilder
  ) {}
  onSelected(){
    if(this.addcontainerform.controls['containercode'].value!=''){
      this.selected=true;
      this.condition=false
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  // Get all dropdown items from the arrays
  getStatus(containerStatus: any[]) {
    containerStatus.forEach((element) => {
      this.status.push(element.id);
    });
  }

  getType(containertypes: any[]) {
    containertypes.forEach((element) => {
      let a: string;
      a = element.containerTypeId;
      this.types.push(a);
    });
  }
  getCompanys(allcompanys: any[]) {
    allcompanys.forEach((element) => {
      if (element.companyType == 'CONTRACTOR') {
        this.companys.push(element.companyId);
      }
    });
  }
  getLocations(alllocations: any[]) {
    alllocations.forEach((element) => {
      this.locations.push(element.locationId);
    });
  }

  addpayload_arr:any[]=[]
  onAddContainer() {
    console.log(this.addcontainerform.value);
    if (this.addcontainerform.dirty) {
      const addpayloadcommon = {
        containerId: this.addcontainerform.controls['containercode'].value,
      };
      if (this.addcontainerform.controls['type'].touched) {
        const Obj = {
          containerType: this.addcontainerform.controls['type'].value,
        };
        this.typemerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['status'].touched) {
        const Obj = {
          containerStatusId: this.addcontainerform.controls['status'].value,
        };
        this.statusmerge={...addpayloadcommon,...Obj};
      }
      //updated left
      if (this.addcontainerform.controls['company'].touched) {
        const Obj = {
          companyId: this.addcontainerform.controls['company'].value,
        };
        this.companymerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['description'].touched) {
        const Obj = {
          containerDesc: this.addcontainerform.controls['description'].value,
        };
        this.descriptionmerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['weight'].touched) {
        const Obj = {
          weightTonnes: this.addcontainerform.controls['weight'].value,
        };
        this.weightmerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['permanent'].touched) {
        const Obj = {
          permanent: this.addcontainerform.controls['permanent'].value,
        };
        this.permanentmerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['onhire'].touched) {
        const Obj = {
          onHire: this.addcontainerform.controls['onhire'].value,
        };
        this.onhiremerge={...addpayloadcommon,...Obj};
      }
      if (this.addcontainerform.controls['location'].touched) {
        const Obj = {
          locationId: this.addcontainerform.controls['location'].value,
        };
        this.locationmerge={...addpayloadcommon,...Obj};
      }
      //pickup and drop calendar left
      const finalmerge={
        ...this.typemerge,
        ...this.statusmerge,
        ...this.companymerge,
        ...this.descriptionmerge,
        ...this.weightmerge,
        ...this.permanentmerge,
        ...this.onhiremerge,
        ...this.locationmerge
      }
      this.addpayload_arr.push(finalmerge);
      //call service for add here !!
      this.planService.addContainer(this.addpayload_arr).subscribe(result=>{
        console.log('result from add container service,', result);
      })
      this.planService.searchContainer(this.addcontainerform.controls['containercode'].value).subscribe(result=>{
        console.log("search done")  
        this.dialogRef.close({data:result});
      })
    }
  }
}
