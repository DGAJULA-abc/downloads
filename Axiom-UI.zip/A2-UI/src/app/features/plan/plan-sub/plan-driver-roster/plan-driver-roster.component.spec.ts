import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanDriverRosterComponent } from './plan-driver-roster.component';

describe('PlanDriverRosterComponent', () => {
  let component: PlanDriverRosterComponent;
  let fixture: ComponentFixture<PlanDriverRosterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanDriverRosterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanDriverRosterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
