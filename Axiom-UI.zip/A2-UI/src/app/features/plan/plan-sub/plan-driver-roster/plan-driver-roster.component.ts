import { Component } from '@angular/core';

@Component({
  selector: 'app-plan-driver-roster',
  templateUrl: './plan-driver-roster.component.html',
  styleUrls: ['./plan-driver-roster.component.scss']
})
export class PlanDriverRosterComponent {
cities:any[]=[1,2,3,4,5]
}
