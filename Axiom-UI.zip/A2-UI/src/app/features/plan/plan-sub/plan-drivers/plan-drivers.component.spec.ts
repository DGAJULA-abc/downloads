import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanDriversComponent } from './plan-drivers.component';

describe('PlanDriversComponent', () => {
  let component: PlanDriversComponent;
  let fixture: ComponentFixture<PlanDriversComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanDriversComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanDriversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
