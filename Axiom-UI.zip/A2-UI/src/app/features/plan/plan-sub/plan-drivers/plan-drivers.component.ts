import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IGroupCellRendererParams,
} from 'ag-grid-community';
import { Driver } from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import { GanttCellRendererComponent } from '../plan-prime-movers/gantt-cell-renderer/gantt-cell-renderer.component';

@Component({
  selector: 'app-plan-drivers',
  templateUrl: './plan-drivers.component.html',
  styleUrls: ['./plan-drivers.component.scss'],
})
export class PlanDriversComponent implements OnInit,OnChanges {

  @Output() driverSelect:EventEmitter<any[]>=new EventEmitter<any[]>();
  @Input() dateCycleResult: any;
  //AG Grid configuration
  private gridApi!: GridApi<Driver>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: Driver[] = [];
  columnDefs: ColDef[] = [
    { field: 'name', headerName: 'Name' },
    { field: 'company', headerName: 'Company' },
    { field: 'pdtloginId', headerName: 'PDT Login ID' },
    {field:'Gantttest',headerName:'',cellRenderer:GanttCellRendererComponent}
  ];
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  constructor(public planService: PlanService,private router:Router) {}
  ngOnChanges(changes: SimpleChanges): void {
    console.log("From date->",this.dateCycleResult)
  }
  ViewDataDrivers: any[] = [];
  drivers: Driver[] = [];
  driver: Driver = {
    name: '', company: '', pdtloginId: '',
    Gantttest: undefined
  };

  ngOnInit() {
    this.planService.getView().subscribe((result: any) => {
      this.ViewDataDrivers = result['ref'].drivers;
      this.getDrivers(this.ViewDataDrivers);
    });
  }
 
 
  //Get Driver info from View API
  getDrivers(viewdrivers: any[]) {
    viewdrivers.forEach((element: any) => {
      this.driver = { name: '', company: '', pdtloginId: '',Gantttest:undefined };
      if(element.active==true){
        if (element.surname != null && element.firstName != null) {
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.pdtloginId = element.mdtCode;
        } else if (element.employeeName != null) {
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.pdtloginId = element.mdtCode;
        }
        this.drivers.push(this.driver);
      }
     
      
    });
    this.rowData = this.drivers;
  }
  //on row selection
  info:any[];
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.ViewDataDrivers.forEach(element => {
      if(element.companyId==selectedRows[0].company){
        this.info=element;
        
      }
      
    });
    this.driverSelect.emit(this.info)
   
  }
  //Go to Driver Roster page
  EditDriverRoster(){
    this.router.navigate(['/driverroster'])
  }
  
}
