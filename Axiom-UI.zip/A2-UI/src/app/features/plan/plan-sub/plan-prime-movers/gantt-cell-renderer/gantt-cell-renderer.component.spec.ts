import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GanttCellRendererComponent } from './gantt-cell-renderer.component';

describe('GanttCellRendererComponent', () => {
  let component: GanttCellRendererComponent;
  let fixture: ComponentFixture<GanttCellRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GanttCellRendererComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GanttCellRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
