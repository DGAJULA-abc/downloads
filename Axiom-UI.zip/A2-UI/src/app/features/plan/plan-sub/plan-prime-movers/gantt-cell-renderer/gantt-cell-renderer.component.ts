import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { AgChartOptions } from 'ag-charts-community';
@Component({
  selector: 'app-gantt-cell-renderer',
  templateUrl: './gantt-cell-renderer.component.html',
  styleUrls: ['./gantt-cell-renderer.component.scss'],
})
export class GanttCellRendererComponent implements ICellRendererAngularComp {
  public options: AgChartOptions;
  public params: any;
  getData(): any[] {
    return [
      {
        type: '',
        ownerOccupied: 1013,
        privateRented: 822,
        localAuthority: 168,
        housingAssociation: 295,
      },
    ];
  }
  getTotal(datum: any) {
    return (
      datum.ownerOccupied +
      datum.privateRented +
      datum.localAuthority +
      datum.housingAssociation
    );
  }
  

  agInit(params: any) {
    this.params = params;
    this.options = {
      autoSize: true,
      data: this.getData().sort( (a: any, b: any) => {
        return this.getTotal(b) - this.getTotal(a);
      }),
      theme: {
        overrides: {
          bar: {
            series: {
              strokeWidth: 0,
              highlightStyle: {
                series: {
                  strokeWidth: 1,
                  dimOpacity: 0.3,
                },
              },
            },
          },
        },
      },
     
    
      series: [
        {
          type: 'bar',
          xKey: 'type',
          yKey: 'ownerOccupied',
          yName: 'Owner occupied',
          stacked: true,
        },
        {
          type: 'bar',
          xKey: 'type',
          yKey: 'privateRented',
          yName: 'Private rented',
          stacked: true,
        },
        {
          type: 'bar',
          xKey: 'type',
          yKey: 'localAuthority',
          yName: 'Local authority',
          stacked: true,
        },
        {
          type: 'bar',
          xKey: 'type',
          yKey: 'housingAssociation',
          yName: 'Housing association',
          stacked: true,
        },
      ],
      axes: [
        {
          type: 'category',
          position: 'left',
        },
        {
          type: 'number',
          position: 'top',
          nice: false,
        },
      ],
    };
  }
  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
