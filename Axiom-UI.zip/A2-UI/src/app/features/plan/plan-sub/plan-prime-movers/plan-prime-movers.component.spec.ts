import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanPrimeMoversComponent } from './plan-prime-movers.component';

describe('PlanPrimeMoversComponent', () => {
  let component: PlanPrimeMoversComponent;
  let fixture: ComponentFixture<PlanPrimeMoversComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanPrimeMoversComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanPrimeMoversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
