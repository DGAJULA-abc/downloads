import { Component, OnInit } from '@angular/core';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IGroupCellRendererParams,
} from 'ag-grid-community';
import { PrimeMover } from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import { GanttCellRendererComponent } from './gantt-cell-renderer/gantt-cell-renderer.component';
@Component({
  selector: 'app-plan-prime-movers',
  templateUrl: './plan-prime-movers.component.html',
  styleUrls: ['./plan-prime-movers.component.scss'],
})
export class PlanPrimeMoversComponent implements OnInit {
  // AG Grid configuration
  rowData: PrimeMover[] = [];
  columnDefs: ColDef[] = [
    { field: 'Rego', headerName: 'Rego' },
    { field: 'Description', headerName: 'Description' },
    { field: 'Fleet', headerName: 'Fleet' },
    {field:'Gantttest',headerName:'',cellRenderer:GanttCellRendererComponent}
  ];
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  constructor(public planService: PlanService) {}
  ngOnInit(): void {
    this.planService.getView().subscribe((result: any) => {
      this.ViewDataTrucks = result['ref'].trucks;
      this.getTrucks(this.ViewDataTrucks);
    });
  }
  ViewDataTrucks: any[] = [];
  trucks: PrimeMover[] = [];
  primemover: PrimeMover = {
    Rego: '', Description: '', Fleet: '',
    Gantttest: undefined
  };
  //Get Trucks from View API

  getTrucks(viewtrucks: any[]) {
    viewtrucks.forEach((element: any) => {
      this.primemover = { Rego: '', Description: '', Fleet: '',Gantttest:'' };
      if (element.active == true) {
        if (element.truckId != null) {
          this.primemover.Rego = element.truckId;
          this.primemover.Description = element.truckDesc;
          this.primemover.Fleet = element.fleetNumber;
          this.trucks.push(this.primemover);
        }
      }
    });
    this.rowData = this.trucks;
  }
}
