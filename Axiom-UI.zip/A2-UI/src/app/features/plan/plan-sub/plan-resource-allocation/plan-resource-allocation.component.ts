import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ColDef, GridApi, GridReadyEvent, INumberFilterParams } from 'ag-grid-community';
import {
  ResourceAllocation,
  ResourceAllocationTable,
  TruckUnavailability,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-plan-resource-allocation',
  templateUrl: './plan-resource-allocation.component.html',
  styleUrls: ['./plan-resource-allocation.component.scss'],
})
export class PlanResourceAllocationComponent implements OnInit {
  //sending data to dialog
  @Output() resourceAllocationSelect: EventEmitter<ResourceAllocation> =
    new EventEmitter<ResourceAllocation>();
  @Output() truckUnavilabilitySelect: EventEmitter<TruckUnavailability> =
    new EventEmitter<TruckUnavailability>();

    //AG Grid configuration
  private gridApi!: GridApi<ResourceAllocationTable>;
  public rowSelection: 'single' | 'multiple' = 'single';
  rowData: ResourceAllocationTable[] = [];
  columnDefs: ColDef[] = [
    { field: 'name', headerName: 'Name' },
    { field: 'type', headerName: 'Type' },
    { field: 'capacity', headerName: 'Capacity', filter: 'agNumberColumnFilter',
    filterParams: {
      numAlwaysVisibleConditions: 2,
      defaultJoinOperator: 'OR',
    } as INumberFilterParams, },
    { field: 'fleet', headerName: 'Fleet' },
  ];
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  constructor(public planService: PlanService) {}
  ViewDataTrucks: any[] = [];
  trucks: ResourceAllocationTable[] = [];
  resource: ResourceAllocationTable = { name: '', type: '', capacity: 0, fleet: '' };

  onGridReady(params: GridReadyEvent<ResourceAllocationTable>) {
    this.gridApi = params.api;
    this.planService.getView().subscribe((result: any) => {
      this.ViewDataTrucks = result['ref'].trucks;
      this.getRATrucks(this.ViewDataTrucks);
    });
  }

  ngOnInit(): void {}
  //Get Resource Allocation Trucks
  getRATrucks(viewtrucks: any[]) {
    viewtrucks.forEach((element) => {
      this.resource = { name: '', type: '', capacity: 0, fleet: '' };
      if(element.active==true){
        if (element.truckId != null) {
          this.resource.name = element.truckId;
          this.resource.type = element.truckTypeId;
          this.resource.capacity = element.routeCapacity;
          this.resource.fleet = element.fleetNumber;
          this.trucks.push(this.resource);
        }
      }
      
    });
    this.rowData = this.trucks;
  }
  //on row selection
  info: ResourceAllocation;
  selectedTruckId: any;
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.ViewDataTrucks.forEach((element) => {
      if (element.truckId == selectedRows[0].name) {
        this.info = element;
        this.selectedTruckId = element.truckId;
      }

      this.resourceAllocationSelect.emit(this.info);
    });
    this.planService
      .getResourceAllocation(this.selectedTruckId)
      .subscribe((result: any) => {
        this.planService.truckUnavailability = result[0];
        this.truckUnavilabilitySelect.emit(
          this.planService.truckUnavailability
        );
      });
    //emit the truck unavailability data here to parent
  }
}
