import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { Reasons, ResourceAllocation } from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-plan-resource-details',
  templateUrl: './plan-resource-details.component.html',
  styleUrls: ['./plan-resource-details.component.scss']
})
export class PlanResourceDetailsComponent implements OnInit{

  //Details from Resource Allocation
  @Input() truckUnavail: any;   
  @Input() resource:ResourceAllocation;
  FleetNumber:string="";
  Capacitytypecompany:string='';
  fromdate:Date
  todate:Date
  addUnavail:boolean=false;
  constructor(public planService:PlanService){}
  ngOnInit(){
  }
  isLoading: boolean = true;
  ngOnChanges(changes: SimpleChanges) {
    this.FleetNumber=this.resource.fleetNumber;
    this.Capacitytypecompany=(this.resource.routeCapacity).toString()+","+this.resource.truckTypeId+","+this.resource.companyId;
    this.isLoading = true;
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.isLoading = false;
        this.getReason(result['ref'].reasons);
      
      }
  })
}
reasons: any[] = [];
getReason(viewreasons: Reasons[]) {
  viewreasons.forEach((element) => {
    // let temp = '';
    // temp = element.reasonId + '_' + element.reasonDescription;
    this.reasons.push(element);
  });
}
filteredReasons: any[] = [];
filterReason(event: any) {
  let filtered: any[] = [];
  let query = event.query;

  for (let i = 0; i < this.reasons.length; i++) {
    let country = this.reasons[i];
    if (
      country.reasonDescription.toLowerCase().indexOf(query.toLowerCase()) ==
      0
    ) {
      filtered.push(country);
    }
  }

  this.filteredReasons = filtered;
}
showReason: Reasons = {
  active: false,
  driver: false,
  reasonDescription: '',
  reasonId: '',
  siteId: 0,
};
reason:Reasons
onReasonSelection() {
  this.showReason = this.reason;
}
addUnavailability(){
  this.addUnavail=!this.addUnavail;
}
}
