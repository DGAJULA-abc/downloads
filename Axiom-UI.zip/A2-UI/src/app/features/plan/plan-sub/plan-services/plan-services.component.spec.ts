import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanServicesComponent } from './plan-services.component';

describe('PlanServicesComponent', () => {
  let component: PlanServicesComponent;
  let fixture: ComponentFixture<PlanServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanServicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
