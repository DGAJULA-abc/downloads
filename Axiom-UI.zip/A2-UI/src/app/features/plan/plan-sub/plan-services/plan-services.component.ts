import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IRowNode,
  IsRowSelectable,
} from 'ag-grid-community';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { DateformatComponent } from '../../services/dateformat/dateformat.component';
import { CopyService, ServiceDateCycle } from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import { BulkCopyDialogComponent } from './bulk-copy-dialog/bulk-copy-dialog.component';
import { ServiceStatusComponent } from '../../services/service-status/service-status.component';
@Component({
  selector: 'app-plan-services',
  templateUrl: './plan-services.component.html',
  styleUrls: ['./plan-services.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class PlanServicesComponent implements OnChanges {
  @Output() getselectedservice: EventEmitter<ServiceDateCycle[]> =
    new EventEmitter<ServiceDateCycle[]>();
  @Input() servicecreated: boolean;
  @Input() tobedeletedService :ServiceDateCycle;
  constructor(
    public dialog: MatDialog,
    public planService: PlanService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {}
  delete_services:any[]=[]
  serviceselected: boolean = true;
  totalrecords: number = 0;
  totalallocated: number = 0;
  totalunallocated: number = 0;
  allocatedwidth = 'width:';
  unallocatedwidth = 'width:';
  //Service Table data coming from Date Cycle Api
  isServiceDataThere: boolean = true;
  @Input() servicesdatecycle: ServiceDateCycle[];
  ngOnChanges(changes: SimpleChanges) {
    this.delete_services=[];
    if (this.servicesdatecycle.length != 0) {
      console.log('checking dates now->', this.servicesdatecycle);
      this.rowData = this.servicesdatecycle;
      this.totalrecords = this.servicesdatecycle.length;
      this.totalallocated = 0;
      this.totalunallocated = 0;
      this.allocatedwidth = 'width:';
      this.unallocatedwidth = 'width:';
      this.rowData.forEach((row) => {
        if (row.truckId == null) {
          //unallocated
          this.totalunallocated += 1;
        } else {
          //allocated
          this.totalallocated += 1;
        }
      });
      //progress bar updates
      if (this.totalunallocated != 0) {
        this.unallocatedwidth =
          this.unallocatedwidth +
          String((this.totalunallocated / this.totalrecords) * 100) +
          '%';
      } else {
        this.unallocatedwidth = this.unallocatedwidth + '0%';
      }

      if (this.totalallocated != 0) {
        this.allocatedwidth =
          this.allocatedwidth +
          String((this.totalallocated / this.totalrecords) * 100) +
          '%';
      } else {
        this.allocatedwidth = this.allocatedwidth + '0%';
      }
    }
    if (this.servicecreated == true) {
      this.gridApi.refreshCells();
    }
    if(this.tobedeletedService){
      this.delete_services.push(this.tobedeletedService)
       const res = this.gridApi.applyTransaction({ remove: this.delete_services })!;
       this.gridApi.refreshCells()
    }
  }
  //AG Grid configuration
  private gridApi!: GridApi<ServiceDateCycle>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: ServiceDateCycle[] = [];
  columnDefs: ColDef[] = [
    {
      field: 'serviceNo',
      headerName: 'Service No.',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { field: 'docket', headerName: 'Docket' },
    { field: 'customerId', headerName: 'Customer' },
    {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createddatetime',
      headerName: 'Created Date/Time',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createddate',
      headerName: 'Create Date',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createdtime',
      headerName: 'Create Time',
      cellRenderer: DateformatComponent,
    },
    { field: 'locationIdDrop', headerName: 'Drop' },
    { field: 'locationIdPickup', headerName: 'Pickup' },
    { field: 'serviceDesc', headerName: 'Service Desc' },
    { field: 'bookedTimeDrop', headerName: 'Drop Time' },
    { field: 'bookedTimePickup', headerName: 'Pickup Time' },
    { field: 'serviceTypeId', headerName: 'Service Type' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    {
      field: 'status',
      headerName: 'Status',
      cellRenderer: ServiceStatusComponent,
    },
    { field: 'tripSeq', headerName: 'Seq' },
    { field: 'loadBatchNo', headerName: 'Cust Ref' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'loadNo', headerName: 'Load No.' },
    { field: 'tripId', headerName: 'Trip No.' },
    { field: 'connote', headerName: 'ConNote' },
    { field: 'containerId', headerName: 'Container No' },
    { field: 'containerTypeId', headerName: 'Container Type' },
    { field: 'vesselId', headerName: 'Vessel No' },
    { field: 'enteredBy', headerName: 'Entered By' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'dropSuburb', headerName: 'Drop Suburb' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'qty1', headerName: 'Qty1. (TONNES)' },
    { field: 'qty2', headerName: 'Qty2. (PALLETS)' },
    { field: 'qty3', headerName: 'Qty3. (DOLLARS)' },
    { field: 'qty4', headerName: 'Qty4. (HOUR)' },
    { field: 'qty5', headerName: 'Qty5. (CONTAINER)' },
    { field: 'qty6', headerName: 'Qty6. (KILOGRAMS)' },
    { field: 'qty7', headerName: 'Qty7. (KILOMETERS)' },
    { field: 'qty8', headerName: 'Qty8. (REELS)' },
  ];
  public defaultColDef: ColDef = {
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  onGridReady(params: GridReadyEvent<ServiceDateCycle>) {
    this.gridApi = params.api;
  }
  //on row selection
  Selectedservice: ServiceDateCycle[] = [];
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.Selectedservice = [];
    this.isServiceDataThere = false;
    this.serviceselected = false;
    selectedRows.forEach((element) => {
      this.Selectedservice.push(element);
    });
    this.getselectedservice.emit(this.Selectedservice);
  }

  //Popup for Bulk Copy
  openDialog() {
    const dialogRef = this.dialog.open(BulkCopyDialogComponent);
  }
  //Duplicate the selected rows
  noOfCopies: number = 0;
  temp: CopyService = {
    newScheduledDate: '',
    noOfCopies: 0,
    newServiceDate: '',
    serviceId: 0,
  };
  DuplicateService() {
    this.Selectedservice.forEach((service) => {
      this.temp.newScheduledDate = null;
      this.temp.newServiceDate = null;
      this.temp.noOfCopies = 0;
      this.temp.serviceId = 0;
      this.temp.serviceId = service.id;
      this.temp.noOfCopies = this.noOfCopies;
      this.temp.newScheduledDate = null;
      this.temp.newServiceDate = null;
      this.planService.CopyService(this.temp).subscribe((result: any) => {
        result.forEach((rows: any) => {
          this.servicesdatecycle.push(rows);
          if (rows.truckId == null) {
            //unallocated
            this.totalunallocated += 1;
          } else {
            //allocated
            this.totalallocated += 1;
          }
        });
        this.totalrecords = this.servicesdatecycle.length;
        //progress bar updates
        this.allocatedwidth = 'width:';
        this.unallocatedwidth = 'width:';
        if (this.totalunallocated != 0) {
          this.unallocatedwidth =
            this.unallocatedwidth +
            String((this.totalunallocated / this.totalrecords) * 100) +
            '%';
        } else {
          this.unallocatedwidth = this.unallocatedwidth + '0%';
        }

        if (this.totalallocated != 0) {
          this.allocatedwidth =
            this.allocatedwidth +
            String((this.totalallocated / this.totalrecords) * 100) +
            '%';
        } else {
          this.allocatedwidth = this.allocatedwidth + '0%';
        }

        this.gridApi.setRowData(this.servicesdatecycle);
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Service duplicated',
        });
      });
    });
  }

  //Deletion of selected service row
  onDelete() {
    let toastrNO: string = '';
    this.confirmationService.confirm({
      message: 'Click OK to Continue',
      header: 'Are you sure you want to delete?',

      accept: () => {
        this.getIdsforDelete();
        this.Selectedservice.forEach((element) => {
          toastrNO += element.serviceNo + ' ';
        });
        let mess = 'Service(s): ' + toastrNO + ' deleted.';
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: mess,
        });
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }
  //Delete the row and refresh the grid
  onRemoveSelected() {
    const selectedData = this.gridApi.getSelectedRows();
    const res = this.gridApi.applyTransaction({ remove: selectedData })!;
    this.planService
      .DeleteService(this.selectedIds)
      .subscribe((result: any) => {
        this.gridApi.refreshCells();
      });
      this.totalrecords-=1;
  }
  //Getting Ids of selected row
  selectedIds: any[] = [];
  getIdsforDelete() {
    this.selectedIds=[]
    if (this.Selectedservice != null) {
      this.Selectedservice.forEach((element) => {
        this.selectedIds.push(element.id);
      });
      this.onRemoveSelected();
    }
  }
}
