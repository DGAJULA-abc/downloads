import { LiveAnnouncer } from '@angular/cdk/a11y';
import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatSort, Sort, MatSortModule } from '@angular/material/sort';
import {
  Driver,
  ResourceAllocation,
  ServiceDateCycle,
  TripDateCycle,
  TripDespatchResponse,
  TripSaveResponse,
  TripUndespatchResponse,
  TruckUnavailability,
} from '../models/plan.model';

@Component({
  selector: 'app-plan-sub',
  templateUrl: './plan-sub.component.html',
  styleUrls: ['./plan-sub.component.scss'],
})
export class PlanSubComponent implements OnChanges {
  
  previousIndex: number;

  roster: boolean = false;
  showform: boolean = false;
  resource: boolean = false;
  tripdetails:boolean=false;

  trips: boolean = true;
  primemovers: boolean = true;
  drivers: boolean = true;
  services: boolean = true;
  resourceallocation: boolean = true;
  datecycle:any;
  @Input() createnewservice :boolean;
  @Input() details: number;
  @Input() filters: string;
  @Input() servicecycle: ServiceDateCycle[];
  @Input() servicetripcycle:TripDateCycle[];
  @Input() datecycleresult:any;
  @Output() ondriverselect: EventEmitter<any[]> = new EventEmitter<any[]>();
  @Output() ontripselect:EventEmitter<TripDateCycle[]>= new EventEmitter<TripDateCycle[]>;
  @Output() onserviceselect:EventEmitter<ServiceDateCycle>= new EventEmitter<ServiceDateCycle>();
  @Output() onresourceSelect: EventEmitter<ResourceAllocation> =
    new EventEmitter<ResourceAllocation>();
    @Output() isservicecreate:EventEmitter<boolean>=new EventEmitter<boolean>();
  headers = [
    { field: 'A', index: 0 },
    { field: 'B', index: 1 },
    { field: 'C', index: 2 },
  ];

  constructor(private _liveAnnouncer: LiveAnnouncer) {}

  servicetrips:TripDateCycle[];
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    
  }
  createservice:boolean=false;
  textondetails: string = '';
  ngOnChanges(changes: SimpleChanges) {
    if (this.details == 1) {
      this.showform = true;
      this.createservice=this.createnewservice;
      this.roster = false;
      this.textondetails = '';
      this.resource = false;
      this.tripdetails=false;
    } else if (this.details == 2) {
      this.roster = true;
      this.showform = false;
      this.textondetails = '';
      this.resource = false;
      this.tripdetails=false;
    } else if (this.details == 0) {
      this.textondetails = 'Resize panel';
      this.showform = false;
      this.roster = false;
      this.resource = false;
      this.tripdetails=false;
    } else if (this.details == 3) {
      this.resource = true;
      this.showform = false;
      this.textondetails = '';
      this.roster = false;
      this.tripdetails=false;
    }
    else if (this.details == 4) {
      this.resource = false;
      this.showform = false;
      this.tripdetails=true;
      this.textondetails = '';
      this.roster = false;
    }
    else if (this.details == 5) {
      this.resource = false;
      this.showform = true;
      this.createservice=this.createnewservice;
      this.servicetrips=this.servicetripcycle;
      this.tripdetails=false;
      this.textondetails = '';
      this.roster = false;
    }
    switch (this.filters) {
      case 'trips':
        this.trips = !this.trips;
        break;
      case 'primemovers':
        this.primemovers = !this.primemovers;
        break;
      case 'drivers':
        this.drivers = !this.drivers;
        break;
      case 'services':
        this.services = !this.services;
        break;
      case 'resourceallocation':
        this.resourceallocation = !this.resourceallocation;
        break;
      default:
        break;
    }
    if(this.datecycleresult){
      this.datecycle=this.datecycleresult
    }
   
  }
  deleteService:ServiceDateCycle;
  onDeleteNotify(message:ServiceDateCycle){
this.deleteService = message;
  }	
  ngAfterViewInit() {
   
  }
  onDriverSelection(SelectedDriver: any[]) {
    if (SelectedDriver != null) {
      this.ondriverselect.emit(SelectedDriver);
      this.roster = true;
      this.showform = false;
    } else {
      this.roster = false;
    }
  }
  
  resourceAllo: ResourceAllocation;
  onResourceAllocationSelection(
    SelectedResourceAllocation: ResourceAllocation
  ) {
    //new form showld show here
    this.onresourceSelect.emit(SelectedResourceAllocation);
    this.resourceAllo = SelectedResourceAllocation;
    this.resource = true;
    this.roster = false;
    this.showform = false;
  }
  truckUnavail: TruckUnavailability;
  onTruckUnavailability(selectedtruckunavailability: TruckUnavailability) {
    this.truckUnavail = selectedtruckunavailability;
  }
SelectedTrip:TripDateCycle[]=[]
  onTripSelectionNotify(message:TripDateCycle[]){
    if (message != null) {
      this.SelectedTrip=message;
      this.ontripselect.emit(message);
      this.roster = false;
      this.showform = false;
      this.tripdetails=true;
    } else {
      this.tripdetails = false;
    }
  }
  SelectedService:ServiceDateCycle={
    address: undefined,
    bookedTimeDrop: undefined,
    bookedTimePickup: undefined,
    chargeAmt: undefined,
    chargeDesc: undefined,
    chargeZoneDrop: undefined,
    chargeZonePickup: undefined,
    complete: false,
    containerId: undefined,
    containerTypeId: undefined,
    created: 0,
    curfewWindow: undefined,
    customerId: '',
    customerSite: undefined,
    dataSourceId: '',
    dehireDeadline: undefined,
    dehirePark: undefined,
    delivered: false,
    deliveryClose: undefined,
    deliveryOpen: undefined,
    depot: undefined,
    despatchBy: undefined,
    destinationLoc: undefined,
    destinationSite: 0,
    docket: undefined,
    driverId: undefined,
    dropDesc: undefined,
    dropSuburb: undefined,
    enteredBy: '',
    etaUpdatedTime: undefined,
    exported: false,
    holdcode: undefined,
    id: 0,
    loadBatchNo: undefined,
    loadCustReference: undefined,
    loadDesc: undefined,
    loadDestination: '',
    loadId: 0,
    loadNo: '',
    loadScheduledDate: 0,
    loadSuburb: undefined,
    loadTypeId: '',
    locationIdDrop: '',
    locationIdPickup: '',
    locationIdPickupActual: undefined,
    offsiderUsed: false,
    operationType: undefined,
    originLoc: undefined,
    originSite: 0,
    podCreated: false,
    priority: undefined,
    qty1: undefined,
    qty2: undefined,
    qty3: undefined,
    qty4: undefined,
    qty5: undefined,
    qty6: undefined,
    qty7: undefined,
    qty8: undefined,
    rateId: undefined,
    reasonId: undefined,
    remarks: undefined,
    replicated: undefined,
    runsheetId: undefined,
    serviceDate: 0,
    serviceDesc: undefined,
    serviceGroup: undefined,
    serviceIdRecharge: undefined,
    serviceNo: '',
    serviceTypeId: '',
    siteId: 0,
    stopSeqDrop: undefined,
    stopSeqPickup: undefined,
    storeETA: undefined,
    todFlags: undefined,
    trailerId: undefined,
    trailerIdTag: undefined,
    tripId: undefined,
    tripIdCust: undefined,
    tripNo: undefined,
    tripSeq: undefined,
    truckId: undefined,
    unit1: '',
    unit2: '',
    unit3: '',
    unit4: undefined,
    unit5: undefined,
    unit6: undefined,
    unit7: undefined,
    unit8: undefined,
    used: false,
    usedSet: undefined,
    vesselEta: undefined,
    vesselId: undefined,
    wharf: undefined,
    window1: undefined,
    window1From: undefined,
    window1To: undefined,
    window2: undefined,
    window2From: undefined,
    window2To: undefined,
    window3: undefined,
    window3From: undefined,
    window3To: undefined
  }
  onServiceSelectionNotify(message:ServiceDateCycle[]){
    if(message!=null){
      this.SelectedService=message[0];
      this.onserviceselect.emit(message[0]);
      this.roster=false;
      this.showform=true;
      this.tripdetails=false;
    }
    else{
      this.showform=false;
    }
  }
 
  ServiceCreated:boolean=false;
  onServiceCreatedNotify(message:any){
    if(message==true){
      this.ServiceCreated=true;
      this.isservicecreate.emit(this.ServiceCreated)

    }
  }


  SelectedTripService:ServiceDateCycle[]=[]
  OnTripServiceSelecetionNotify(message:ServiceDateCycle[]){
    if(message.length!=0){
      this.SelectedTripService=message;
    }
  }
  onSaveNotify(result:TripSaveResponse){
    this.SelectedTripService=result.services;
    this.SelectedTrip=result.trips;
  }
  onDespatchNotify(result:TripDespatchResponse){
    this.SelectedTrip=result.trips;
    this.SelectedTripService=result.services
  }
  onUndespatchNotify(result:TripUndespatchResponse){
    this.SelectedTrip=result.trips;
    
  }

  /** Announce the change in sort state for assistive technology. */
  announceSortChange(sortState: Sort) {
    // This example uses English messages. If your application supports
    // multiple language, you would internationalize these strings.
    // Furthermore, you can customize the message to add additional
    // details about the values being sorted.
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }

 
  
}
