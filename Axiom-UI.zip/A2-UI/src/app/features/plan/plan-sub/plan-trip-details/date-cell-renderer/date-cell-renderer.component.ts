import { AfterViewInit, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AgEditorComponent, ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-date-cell-renderer',
  templateUrl: './date-cell-renderer.component.html',
  styleUrls: ['./date-cell-renderer.component.scss']
})
export class DateCellRendererComponent implements ICellRendererAngularComp {
  params: any;
 selectedDate:Date
 onDateSelected(event:any){
  console.log("selected date inside cell render",this.selectedDate)
 }
 //harcode the value from calendar for now
 getValue() {
    //  return Number(moment(this.selectedDate,'DD-MM-YYYY HH:mm:ss').format('x'));
    let x = moment(this.selectedDate) .set({
      second: 0,
    })
    let y =  moment(
      moment.tz(x, 'Australia/Melbourne').clone().tz('Asia/Kolkata')
    ).valueOf()
    console.log("new time", y)
    return moment(y).format('DD/MM/YY HH:mm:ss');
 }

  constructor(){ 
   
  }
 
  agInit(params: ICellRendererParams<any, any>): void {
    this.params = params;
  }

  ngOnInit(): void {
  
  }
  refresh(params: ICellRendererParams) {
    return false;
  }
  
}
