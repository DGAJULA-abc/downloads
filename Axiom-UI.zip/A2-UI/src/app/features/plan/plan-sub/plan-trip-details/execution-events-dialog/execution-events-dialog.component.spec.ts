import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecutionEventsDialogComponent } from './execution-events-dialog.component';

describe('ExecutionEventsDialogComponent', () => {
  let component: ExecutionEventsDialogComponent;
  let fixture: ComponentFixture<ExecutionEventsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExecutionEventsDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExecutionEventsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
