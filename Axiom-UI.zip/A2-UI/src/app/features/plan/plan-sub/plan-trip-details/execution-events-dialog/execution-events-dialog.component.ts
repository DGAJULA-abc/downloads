import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GridApi, ColDef, GridReadyEvent } from 'ag-grid-community';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import {
  ExecEventTable,
  ExecEventAPIResponse,
} from '../../../models/plan.model';
import { PlanService } from '../../../services/plan.service';
import { DateCellRendererComponent } from '../date-cell-renderer/date-cell-renderer.component';

@Component({
  selector: 'app-execution-events-dialog',
  templateUrl: './execution-events-dialog.component.html',
  styleUrls: ['./execution-events-dialog.component.scss'],
  providers: [MessageService],
})
export class ExecutionEventsDialogComponent implements OnInit {
  tripno: string = '';
  ngOnInit() {
    this.tripno = this.data.tripno;
  }
  constructor(
    public planService: PlanService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private messageService: MessageService,
    public dialogRef: MatDialogRef<ExecutionEventsDialogComponent>
  ) {}
  //AG Grid configuration for Execution Events dialog
  private gridApiExecEvent!: GridApi<ExecEventTable>;
  rowDataExecEvent: ExecEventTable[] = [];
  columnDefsExecEvent: ColDef[] = [
    { field: 'sno', headerName: '#' },
    { field: 'location', headerName: 'Location' },
    {
      field: 'arrive',
      headerName: 'Arrive',
      cellEditor: DateCellRendererComponent,
      editable: true,
    },
    { field: 'source_a', headerName: 'Source' },
    {
      field: 'completed',
      headerName: 'Completed',
      cellRenderer: DateCellRendererComponent,
      editable: true,
    },
    { field: 'source_c', headerName: 'Source' },
    {
      field: 'depart',
      headerName: 'Depart',
      cellRenderer: DateCellRendererComponent,
      editable: true,
    },
    { field: 'source_d', headerName: 'Source' },
    { field: 'type', headerName: 'Type' },
  ];

  public defaultColDef: ColDef = {
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };

  //On Event grid ready
  onExecEventGridReady(params: GridReadyEvent<ExecEventTable>) {
    this.gridApiExecEvent = params.api;
    this.getExecutionEvents();
  }

  //on row selection in AG Grid for Event
  onExecEventSelectionChanged(event: any) {
    const selectedRows = this.gridApiExecEvent.getSelectedRows();
  }

  onCellValueChanged(event: any) {
    console.log(event);
  }

  exectablerows: ExecEventTable[] = [];
  StoreResult: ExecEventAPIResponse;
  //get executionevent api data
  getExecutionEvents() {
    this.planService
      .getExecutionEvents(this.data.tripId)
      .subscribe((result: ExecEventAPIResponse) => {
        if (result) {
          this.StoreResult = result;
          result.executionEvents.forEach((element) => {
            this.exectablerows.push({
              sno: element.sequenceNo,
              location: element.location,
              arrive: element.arrivalEvent.time
                ? moment(element.arrivalEvent.time)
                    .tz('Australia/Melbourne')
                    .format('DD/MM/YY HH:mm:ss')
                : '',
              source_a: element.arrivalEvent.source,
              completed: element.completionEvent.time
                ? moment(element.completionEvent.time)
                    .tz('Australia/Melbourne')
                    .format('DD/MM/YY HH:mm:ss')
                : '',
              source_c: element.completionEvent.source,
              depart: element.departureEvent.time
                ? moment(element.departureEvent.time)
                    .tz('Australia/Melbourne')
                    .format('DD/MM/YY HH:mm:ss')
                : '',
              source_d: element.departureEvent.source,
              type: element.activityType,
            });
          });
          this.rowDataExecEvent = this.exectablerows;
        }
      });
  }

  //close dialog
  onCancel() {
    this.dialogRef.close();
  }

  onDateSelected(date: Date) {
    console.log('selected date in ag grid component');
  }
  // TODO: on save executionevent post
  saveexecevent_arr: ExecEventAPIResponse[] = [];
  saveexecevent: ExecEventAPIResponse;
  index:number=0;
  onSave() {
    this.index=0
    console.log(this.rowDataExecEvent);
    //updated values in table
    this.saveexecevent = this.StoreResult;
    this.rowDataExecEvent.forEach((row) => {
      if(row.arrive!=""){

        let a_compare = this.datecheck(row.arrive)
        if(a_compare != this.saveexecevent.executionEvents[this.index].arrivalEvent.time){
          this.saveexecevent.executionEvents[this.index].arrivalEvent.modified=true;
        }
        else{
          this.saveexecevent.executionEvents[this.index].arrivalEvent.modified=false;
        }
      }
      if(row.completed!=""){
        let c_compare = this.datecheck(row.completed);
        if(c_compare != this.saveexecevent.executionEvents[this.index].completionEvent.time){
          this.saveexecevent.executionEvents[this.index].completionEvent.modified=true;
        }
        else{
          this.saveexecevent.executionEvents[this.index].completionEvent.modified=false;
        }
      }
      if(row.depart!=""){

        let d_compare = this.datecheck(row.depart);
        if(d_compare != this.saveexecevent.executionEvents[this.index].departureEvent.time){
          this.saveexecevent.executionEvents[this.index].departureEvent.modified=true;
        }
        else{
          this.saveexecevent.executionEvents[this.index].departureEvent.modified=false;
        }
      }

      this.index+=1;

    });
    console.log("payload check",this.saveexecevent.executionEvents)

    this.planService.postExecutionEvents(this.data.tripId,this.saveexecevent.executionEvents).subscribe((result:ExecEventAPIResponse)=>{
   if(result){
    //all good
    this.messageService.add({
      severity: 'success',
      summary: '',
      detail: 'execution event created',
    });
   }
    })
  }

  datecheck(check:any):number{
   let a =moment(
      moment.tz(moment(check).format("DD/MM/YYYY HH:mm:ss"), 'Australia/Melbourne').clone().tz('Asia/Kolkata')
    ).valueOf();
    return a
  }
}
