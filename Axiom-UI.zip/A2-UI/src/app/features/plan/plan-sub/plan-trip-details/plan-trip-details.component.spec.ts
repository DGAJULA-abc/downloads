import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanTripDetailsComponent } from './plan-trip-details.component';

describe('PlanTripDetailsComponent', () => {
  let component: PlanTripDetailsComponent;
  let fixture: ComponentFixture<PlanTripDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanTripDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanTripDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
