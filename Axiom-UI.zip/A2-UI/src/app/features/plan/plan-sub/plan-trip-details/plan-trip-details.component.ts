import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridApi, ColDef, GridReadyEvent } from 'ag-grid-community';
import { elementAt } from 'rxjs';
import {
  Dock,
  Driver2,
  ResourceAllocation,
  Trailer,
  Location,
  ServiceDateCycle,
  TripDateCycle,
  activities,
  ActivityTypes,
  ActivityDisplay,
  ViewDriver,
  Driver,
  ChainCommand,
  GetEvent,
  EventTable,
  TripSaveResponse,
  TripDespatchResponse,
  TripUndespatchResponse,
  ExecEventTable,
  ExecEventAPIResponse,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { ExecutionEventsDialogComponent } from './execution-events-dialog/execution-events-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { EventdateCellRendererComponent } from '../../services/eventdate-cell-renderer/eventdate-cell-renderer.component';
@Component({
  selector: 'app-plan-trip-details',
  templateUrl: './plan-trip-details.component.html',
  styleUrls: ['./plan-trip-details.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class PlanTripDetailsComponent implements OnInit, OnChanges {
  @Input() selectedTrip: TripDateCycle[];
  @Input() selectedTripService: ServiceDateCycle[];
  @Output() savenotify: EventEmitter<TripSaveResponse> =
    new EventEmitter<TripSaveResponse>();
  @Output() despatchnotify: EventEmitter<TripDespatchResponse> =
    new EventEmitter<TripDespatchResponse>();
  @Output() undespatchnotify: EventEmitter<TripUndespatchResponse> =
    new EventEmitter<TripUndespatchResponse>();

  //getting data from View have View keyword
  ViewDocks: Dock[] = [];
  ViewDrivers: ViewDriver[] = [];
  ViewTrucks: ResourceAllocation[] = [];
  ViewTrailers: Trailer[] = [];
  ViewLocations: Location[] = [];
  ViewActivityTypes: ActivityTypes[] = [];

  //extra variables for form data display
  driver: Driver2;
  tripno: string = '';
  activities: activities[] = [];
  Activity_display: ActivityDisplay[] = [];
  totaltriptime: string = '';
  totaltime: number = 0;
  showReturnto: string = '';
  fulladdress: string = '';
  connote: number = 0;
  utilisation: string = '';
  status: string = '';
  endtime: string;

  //ngif to show activity label
  Activityavailable: boolean = false;

  //despatch/undespatch buttons
  despatchtoggle: boolean = false;

  //selected trip in TripDateCycle format
  TripDetails: TripDateCycle;


  constructor(
    public planService: PlanService,
    private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private messageService: MessageService,
    private confirmationService: ConfirmationService
  ) {}
  showStartTime:any;
  //geting all new data in the form based on trip selection in Plan Trips component
  ngOnChanges(changes: SimpleChanges): void {
    this.Activity_display = [];
    this.tripdetailsform = this.formBuilder.group({
      tripno: [this.tripno],
      loadready: [false],
      paperworkavailable: [false],
      starttime: [],
      despatchby: [''],
      dock: [this.selectedDock],
      comments: [''],
      connote:[],
      driver: [this.selectedDriver],
      truck: [this.selectedTruck],
      trailer1: [''],
      trailer2: [''],
      returnto: [this.selectedTrip[0].returnLocationId],
      route: [''],
    });
    if (this.selectedTrip.length != 0) {
      this.getEvents(this.selectedTrip[0].id);
      this.TripDetails = this.selectedTrip[0];
      //update form details
      this.tripno = this.selectedTrip[0].tripIdCust;
      this.tripdetailsform.controls['tripno'].setValue(
        this.selectedTrip[0].tripIdCust
      );
      this.showStartTime= moment(this.selectedTrip[0].plannedStartTime)
      .tz('Australia/Melbourne')
      .format('DD/MM/YY HH:mm:ss')
      this.tripdetailsform.controls['starttime'].setValue(
        moment(this.selectedTrip[0].plannedStartTime)
          .tz('Australia/Melbourne')
          .format('DD/MM/YY HH:mm:ss')
      );
      this.endtime =  moment(this.selectedTrip[0].plannedFinishTime)
      .tz('Australia/Melbourne')
      .format('DD/MM/YY HH:mm');
      this.rowData = this.selectedTripService;
      this.activities = this.selectedTrip[0].activities;
      this.connote = this.selectedTrip[0].batchNo;
      let stat = this.selectedTrip[0].cachedStatus;
      if (stat == 'P ') {
        this.status = 'planned';
        this.despatchtoggle = false;
        this.tripdetailsform.get('starttime')?.enable();

      } else if (stat == 'D ') {
        this.status = 'despatched';
        this.despatchtoggle = true;
        this.tripdetailsform.get('starttime')?.disable();
      }
      else if (stat == 'U ') {
        this.status = 'despatched';
        this.despatchtoggle = true;
        this.tripdetailsform.get('starttime')?.disable();
      }
      let num =
        (this.selectedTrip[0].cachedRoutingQty /
          this.selectedTrip[0].cachedTruckCapacity) *
        100;
      this.utilisation =
        num +
        ' % (' +
        String(this.selectedTrip[0].cachedRoutingQty) +
        ' of ' +
        String(this.selectedTrip[0].cachedTruckCapacity) +
        ' TONNES)';
      if (this.selectedTrip[0].comments != null) {
        this.tripdetailsform.controls['comments'].setValue(
          this.selectedTrip[0].comments
        );
      }
      if (this.activities.length != 0) {
        this.totaltriptime = '';
        this.totaltime = 0;
        this.Activityavailable = true;
        this.activities.forEach((activity) => {
          if (activity.activityTypeId == 1) {
            this.totaltime = this.totaltime + activity.activityTime;
            this.Activity_display.push({
              header: 'Travel',
              label:
                activity.pickupLocationId + ' to ' + activity.dropLocationId,
              time: this.getActivityTime(activity.activityTime),
              colorbar: true,
            });
          } else if (activity.activityTypeId == 2) {
            this.totaltime = this.totaltime + activity.activityTime;
            this.Activity_display.push({
              header: 'Pickup',
              label: 'at ' + activity.pickupLocationId,
              time: this.getActivityTime(activity.activityTime),
              colorbar: false,
            });
          } else if (activity.activityTypeId == 3) {
            this.totaltime = this.totaltime + activity.activityTime;
            this.Activity_display.push({
              header: 'Dropoff',
              label: 'at ' + activity.dropLocationId,
              time: this.getActivityTime(activity.activityTime),
              colorbar: false,
            });
          }
        });
        this.totaltriptime = this.getActivityTime(this.totaltime);
      } else if (this.activities.length == 0) {
        this.Activityavailable = false;
      }
    }
  }
  isLoading: boolean = true;
  //form data on Init
  tripdetailsform: FormGroup;
  ngOnInit(): void {
    this.isLoading = true;
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.isLoading = false;
        this.ViewDocks = result['ref'].docks;
        this.ViewDrivers = result['ref'].drivers;
        this.ViewTrucks = result['ref'].trucks;
        this.ViewTrailers = result['ref'].trailers;
        this.ViewLocations = result['ref'].locations;
        this.ViewActivityTypes = result['ref'].activityTypes;
        this.getDockvalue(this.ViewDocks);
        this.getDrivers(this.ViewDrivers);
        this.getTrucks(this.ViewTrucks);
        this.getTrailers(this.ViewTrailers);
        this.getLocations(this.ViewLocations);
      }
    });
   
    this.getEvents(this.selectedTrip[0].id);
    this.Activity_display = [];
    this.activities = this.selectedTrip[0].activities;
    this.showReturnto = this.selectedTrip[0].returnLocationId;
    this.connote = this.selectedTrip[0].batchNo;
    let stat = this.selectedTrip[0].cachedStatus;
    this.endtime =  moment(this.selectedTrip[0].plannedFinishTime)
    .tz('Australia/Melbourne')
    .format('DD/MM/YY HH:mm')
    if (stat == 'P ') {
      this.status = 'planned';
      this.despatchtoggle = false;
      this.tripdetailsform.get('starttime')?.enable();
    }
    if (stat == 'D ') {
      this.status = 'despatched';
      this.despatchtoggle = true;
      this.tripdetailsform.get('starttime')?.disable();
    }
    if (stat == 'U ') {
      this.status = 'despatched';
      this.despatchtoggle = true;
      this.tripdetailsform.get('starttime')?.disable();
    }
    let num =
      (this.selectedTrip[0].cachedRoutingQty /
        this.selectedTrip[0].cachedTruckCapacity) *
      100;
    this.utilisation =
      num +
      ' % (' +
      String(this.selectedTrip[0].cachedRoutingQty) +
      ' of ' +
      String(this.selectedTrip[0].cachedTruckCapacity) +
      ' TONNES)';
    if (this.selectedTrip.length != 0) {
      this.tripno = this.selectedTrip[0].tripIdCust;
    }
    if (this.selectedTrip[0].comments != null) {
      this.tripdetailsform.controls['comments'].setValue(
        this.selectedTrip[0].comments
      );
    }
    if (this.activities.length != 0) {
      this.totaltriptime = '';
      this.totaltime = 0;
      this.Activityavailable = true;
      this.activities.forEach((activity) => {
        if (activity.activityTypeId == 1) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Travel',
            label: activity.pickupLocationId + ' to ' + activity.dropLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: true,
          });
        } else if (activity.activityTypeId == 2) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Pickup',
            label: 'at ' + activity.pickupLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: false,
          });
        } else if (activity.activityTypeId == 3) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Dropoff',
            label: 'at ' + activity.dropLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: false,
          });
        }
      });
      this.totaltriptime = this.getActivityTime(this.totaltime);
    }
  }

  //getting total activity time
  getActivityTime(time: number): string {
    let hours = Math.floor(time / 60);
    let minutes = time % 60;
    return String(hours) + 'h ' + String(minutes) + 'm';
  }
  //get drivers in correct format in dropdown from View
  showDriver: Driver2 = {
    id: 0,
    name: '',
    company: '',
  };
  getDrivers(viewdrivers: ViewDriver[]) {
    viewdrivers.forEach((element: any) => {
      this.driver = { name: '', company: '', id: 0 };
      if (element.active == true) {
        if (
          element.surname != null &&
          element.firstName != null &&
          element.employeeName != null
        ) {
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (
          element.surname == null ||
          (element.firstName == null && element.employeeName != null)
        ) {
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (
          element.surname != null &&
          element.firstName != null &&
          element.employeeName == null
        ) {
          this.driver.name = element.surname + ' ' + element.firstName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
    viewdrivers.forEach((driver) => {
      if (driver.id != null && driver.id == this.selectedTrip[0].driverId) {
        if (
          driver.surname != null &&
          driver.firstName != null &&
          driver.employeeName != null
        ) {
          this.showDriver.name =
            driver.surname +
            ' ' +
            driver.firstName +
            ' - ' +
            driver.employeeName +
            ' (' +
            driver.companyId +
            ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        } else if (
          driver.surname == null ||
          (driver.firstName == null && driver.employeeName != null)
        ) {
          this.showDriver.name =
            driver.employeeName + ' (' + driver.companyId + ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        } else if (
          driver.surname != null &&
          driver.firstName != null &&
          driver.employeeName == null
        ) {
          this.showDriver.name =
            driver.surname +
            ' ' +
            driver.firstName +
            ' (' +
            driver.companyId +
            ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        }
      }
    });
  }

  //get docks
  showDock: Dock = {
    active: false,
    dockName: '',
    homeLocationId: undefined,
    id: 0,
    locationId: '',
    siteId: 0,
  };
  getDockvalue(viewdocks: Dock[]) {
    viewdocks.forEach((dock) => {
      if (dock.id == this.selectedTrip[0].dockId) {
        this.showDock = dock;
      }
    });
  }
  //get trucks in correct format in dropdown from View
  value: any;
  showTruck = {
    id: '',
    name: '',
  };
  getTrucks(viewtrucks: ResourceAllocation[]) {
    viewtrucks.forEach((element) => {
      if (element.active == true) {
        this.value =
          element.truckId +
          ' (' +
          element.routeCapacity +
          ', ' +
          element.truckTypeId +
          ', ' +
          element.companyId +
          ')';
        this.trucks.push(this.value);
      }
    });
    viewtrucks.forEach((truck) => {
      if (truck.truckId == this.selectedTrip[0].truckId) {
        this.showTruck.id = truck.truckId;
        this.showTruck.name =
          truck.truckId +
          ' (' +
          truck.routeCapacity +
          ', ' +
          truck.truckTypeId +
          ', ' +
          truck.companyId +
          ')';
      }
    });
  }

  //get trailers in correct format in dropdown from View
  t_val: any;
  trailers: any[] = [];
  getTrailers(viewtrailers: Trailer[]) {
    viewtrailers.forEach((trailer) => {
      if (trailer.active == true) {
        if (trailer.companyId != null) {
          if (trailer.routeCapacity != null) {
            this.t_val =
              trailer.trailerId +
              ' (' +
              trailer.routeCapacity +
              ', ' +
              trailer.trailerTypeId +
              ', ' +
              trailer.companyId +
              ')';
            this.trailers.push(this.t_val);
          } else {
            this.t_val =
              trailer.trailerId +
              ' (' +
              trailer.trailerTypeId +
              ', ' +
              trailer.companyId +
              ')';
            this.trailers.push(this.t_val);
          }
        } else {
          this.t_val =
            trailer.trailerId +
            ' (' +
            trailer.routeCapacity +
            ', ' +
            trailer.trailerTypeId +
            ')';
          this.trailers.push(this.t_val);
        }
      }
    });
  }

  //get locations in correct format in dropdown from View
  locations: any[] = [];
  getLocations(viewlocations: Location[]) {
    viewlocations.forEach((location) => {
      this.locations.push(location.locationId);
      if (location.locationId == this.selectedTrip[0].returnLocationId) {
        if (location.address2 != null) {
          this.fulladdress =
            location.address1 +
            ' ' +
            location.address2 +
            ', ' +
            location.suburb +
            ', ' +
            location.state +
            ', ' +
            location.postCode;
        }
         else {
          this.fulladdress =
            location.address1 +
            ', ' +
            location.suburb +
            ', ' +
            location.state +
            ', ' +
            location.postCode;
        }
        if(location.address1==null){
          this.fulladdress=''
        }
      }
    });
  }

  //toggle events for tabs inside form
  toggleResource: boolean = true;
  toggleService: boolean = true;
  toggleActivity: boolean = true;
  toggleEvent: boolean = true;

  Toggleresource() {
    this.toggleResource = !this.toggleResource;
  }
  Toggleservice() {
    this.toggleService = !this.toggleService;
  }
  Toggleactivity() {
    this.toggleActivity = !this.toggleActivity;
  }
  Toggleevent() {
    this.toggleEvent = !this.toggleEvent;
  }

  //autocomplete for docks
  docks: Dock[] = [];

  getDocks(viewdocks: Dock[]) {
    viewdocks.forEach((element) => {
      if (element.dockName != null) {
        this.docks.push(element);
      }
    });
    // this.docks = this.docks_arr.filter(
    //   (item, index) => this.docks_arr.indexOf(item) === index
    // );
  }

  selectedDock: any = '';
  filteredDocks: any[] = [];
  filterDock(event: any) {
    this.getDocks(this.ViewDocks);
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.docks.length; i++) {
      let country = this.docks[i];
      if (country.dockName.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredDocks = filtered;
  }
  //autocomplete for drivers
  drive_arr: Driver2[] = [];
  drivers: Driver2[] = [];
  selectedDriver: any = '';
  filteredDrivers: any[] = [];
  getDriverValue(drivers: any[]) {
    drivers.forEach((driver) => {
      let val = '';
      val = driver.name + ' (' + driver.company + ')';
      this.drive_arr.push({
        id: driver.id,
        name: val,
        company: driver.companyId,
      });
    });
  }
  filterDriver(event: any) {
    this.getDriverValue(this.drivers);
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.drive_arr.length; i++) {
      let country = this.drive_arr[i];
      if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredDrivers = filtered;
  }

  //autocomplete for trucks
  trucks: any[] = [];
  selectedTruck: any = '';
  filteredTrucks: any[] = [];

  filterTruck(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.trucks.length; i++) {
      let country = this.trucks[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredTrucks = filtered;
  }

  //autocomplete for trailer1
  selectedTrailerone: any = '';
  filteredTrailersone: any[] = [];

  filterTrailerone(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.trailers.length; i++) {
      let country = this.trailers[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredTrailersone = filtered;
  }
  //autocomplete for trailer2
  selectedTrailertwo: any = '';
  filteredTrailerstwo: any[] = [];

  filterTrailertwo(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.trailers.length; i++) {
      let country = this.trailers[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredTrailerstwo = filtered;
  }
  //autocomplete for trailer2
  selectedReturnto: any = '';
  filteredReturntos: any[] = [];

  filterReturnto(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.locations.length; i++) {
      let country = this.locations[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredReturntos = filtered;
  }

  //AG Grid configuration for Service Table
  private gridApi!: GridApi<ServiceDateCycle>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: ServiceDateCycle[] = [];
  columnDefs: ColDef[] = [
    {
      field: 'serviceGroup',
      headerName: 'Service Group',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { field: 'serviceNo', headerName: 'Service No.' },
    { field: 'docket', headerName: 'Docket' },
    { field: 'customerId', headerName: 'Customer' },
    { field: 'deliverydate', headerName: 'Delivery Date' },
    { field: 'createddatetime', headerName: 'Created Date/Time' },
    { field: 'createddate', headerName: 'Create Date' },
    { field: 'createdtime', headerName: 'Create Time' },
    { field: 'locationIdDrop', headerName: 'Drop' },
    { field: 'locationIdPickup', headerName: 'Pickup' },
    { field: 'serviceDesc', headerName: 'Service Desc' },
    { field: 'bookedTimeDrop', headerName: 'Drop Time' },
    { field: 'bookedTimePickup', headerName: 'Pickup Time' },
    { field: 'serviceTypeId', headerName: 'Service Type' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    { field: 'status', headerName: 'Status' },
    { field: 'seq', headerName: 'Seq' },
    { field: 'custref', headerName: 'Cust Ref' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'loadNo', headerName: 'Load No.' },
    { field: 'tripNo', headerName: 'Trip No.' },
    { field: 'batchNo', headerName: 'ConNote' },
    { field: 'containerId', headerName: 'Container No' },
    { field: 'containerTypeId', headerName: 'Container Type' },
    { field: 'vesselId', headerName: 'Vessel No' },
    { field: 'enteredBy', headerName: 'Entered By' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'dropSuburb', headerName: 'Drop Suburb' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'unit1', headerName: 'Qty1.' },
    { field: 'unit2', headerName: 'Qty2.' },
    { field: 'unit3', headerName: 'Qty3.' },
    { field: 'unit4', headerName: 'Qty4.' },
    { field: 'unit5', headerName: 'Qty5.' },
    { field: 'unit6', headerName: 'Qty6.' },
    { field: 'unit7', headerName: 'Qty7.' },
    { field: 'unit8', headerName: 'Qty8.' },
  ];
  public defaultColDef: ColDef = {
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };

  //On grid ready
  onGridReady(params: GridReadyEvent<ServiceDateCycle>) {
    this.gridApi = params.api;
    this.rowData = this.selectedTripService;
  }

  //on row selection in AG Grid
  selectedserviceno: number = 0;
  showGotoServicebutton: boolean = true;
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows.length != 0) {
      this.selectedserviceno = selectedRows.length;
      this.showGotoServicebutton = false;
    } else {
      this.showGotoServicebutton = true;
      this.selectedserviceno = selectedRows.length;
    }
  }
  showEventtable: boolean = false;

  tableeventrow: EventTable = {
    eventdatetime: undefined,
    eventdate: undefined,
    eventtime: 0,
    eventtype: '',
    relation: '',
    mdserverdatetime: undefined,
    mdserverdate: undefined,
    mdservertime: undefined,
    eventcreateddatetime: 0,
    eventcreateddate: undefined,
    eventcreatedtime: undefined,
    driver: '',
    trip: '',
    truck: '',
    trailer1: '',
    trailer2: '',
    dock: '',
    user: '',
    location: undefined,
    datasource: '',
    eventadjusted: false,
    todexportable: false,
    exported: false,
    comments: '',
    latitude: undefined,
    longitude: undefined,
    logonlogoffcompliance: false,
    serviceno: undefined,
    loadno: undefined,
  };
  tablevents: EventTable[] = [];
  eventfromapi: GetEvent[] = [];
  //call events of the trip
  getEvents(id: number) {
    this.planService.getTripEvent(id).subscribe((result) => {
      if (result['events'].length != 0) {
        this.showEventtable = true;
        this.eventfromapi = result['events'];
        this.tablevents = [];
        this.eventfromapi.forEach((event) => {
          this.tableeventrow = {
            eventdatetime: '',
            eventdate: '',
            eventtime: 0,
            eventtype: '',
            relation: '',
            mdserverdatetime: '',
            mdserverdate: '',
            mdservertime: '',
            eventcreateddatetime: 0,
            eventcreateddate: '',
            eventcreatedtime: '',
            driver: '',
            trip: '',
            truck: '',
            trailer1: '',
            trailer2: '',
            dock: '',
            user: '',
            location: '',
            datasource: '',
            eventadjusted: false,
            todexportable: false,
            exported: false,
            comments: '',
            latitude: '',
            longitude: '',
            logonlogoffcompliance: false,
            serviceno: '',
            loadno: '',
          };
          this.tableeventrow.eventtype = event.eventDescription;
          this.tableeventrow.relation = event.eventLevel.toLowerCase();
          this.tableeventrow.driver = String(event.driverId);
          this.tableeventrow.trip = event.tripIdCust;
          this.tableeventrow.truck = event.truckId;
          this.tableeventrow.trailer1 = event.trailerId;
          this.tableeventrow.trailer2 = event.trailerTagId;
          this.tableeventrow.user = event.userId;
          this.tableeventrow.datasource = event.datasourceId;
          this.tableeventrow.loadno = event.loadNo;
          this.tableeventrow.serviceno = event.serviceNo;
          this.tableeventrow.eventcreateddatetime= event.created;
          this.tableeventrow.eventcreateddate= event.created
          this.tableeventrow.eventcreatedtime= event.created
          this.tableeventrow.eventdatetime= event.eventTime
          this.tableeventrow.eventdate= event.eventTime
          this.tableeventrow.eventtime= event.eventTime
          this.tablevents.push(this.tableeventrow);
        });
        this.rowDataEvent = this.tablevents;
      } else {
        this.showEventtable = false;
      }
    });
  }
  //on saving the form
  onSave() {
    this.getEvents(this.selectedTrip[0].id);
    if (this.tripdetailsform.dirty) {
      let chaincommand: ChainCommand[] = [
        { commandData: [], commandString: 'PROCESS_TRIP_DATE_CHANGE' },
      ];
      //--tripno
      if (this.tripdetailsform.controls['starttime'].touched) {
        this.TripDetails.plannedStartTime =
          this.tripdetailsform.controls['starttime'].value;
      }

      if (this.tripdetailsform.controls['dock'].touched) {
        this.TripDetails.dockId =
          this.tripdetailsform.controls['dock'].value.id;
      }
      if (this.tripdetailsform.controls['comments'].touched) {
        this.TripDetails.comments =
          this.tripdetailsform.controls['comments'].value;
      }
      if (this.tripdetailsform.controls['driver'].touched) {
        this.TripDetails.driverId =
          this.tripdetailsform.controls['driver'].value.id;
      }
      if (this.tripdetailsform.controls['truck'].touched) {
        this.TripDetails.truckId = this.tripdetailsform.controls[
          'truck'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer1'].touched) {
        this.TripDetails.trailerId = this.tripdetailsform.controls[
          'trailer1'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer2'].touched) {
        this.TripDetails.trailerIdTag = this.tripdetailsform.controls[
          'trailer2'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['returnto'].touched) {
        this.TripDetails.returnLocationId =
          this.tripdetailsform.controls['returnto'].value;
      }
      if (
        this.tripdetailsform.controls['trailer1'].value == '' ||
        this.tripdetailsform.controls['trailer2'].value == ''
      ) {
      } else {
        this.TripDetails.chainCommands = chaincommand;
        this.planService
          .TripDetailUpdate(this.TripDetails)
          .subscribe((result) => {
            this.savenotify.emit(result);
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'trip saved',
            });
          });
      }
    }
  }

  //AG Grid configuration for Event Table
  private gridApiEvent!: GridApi<EventTable>;
  public rowSelectionEvent: 'single' | 'multiple' = 'multiple';
  rowDataEvent: EventTable[] = [];
  columnDefsEvent: ColDef[] = [
    {
      field: 'eventdatetime',
      headerName: 'Event date/time',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      cellRenderer: EventdateCellRendererComponent
    },
    { field: 'eventdate', headerName: 'Event-Date',cellRenderer: EventdateCellRendererComponent },
    { field: 'eventtime', headerName: 'Event-Time',cellRenderer: EventdateCellRendererComponent },
    { field: 'eventtype', headerName: 'Event Type' },
    { field: 'relation', headerName: 'Relation' },
    { field: 'mdserverdatetime', headerName: 'MD Server date/time' },
    { field: 'mdserverdate', headerName: 'MD Server-Date' },
    { field: 'mdservertime', headerName: 'MD Server-Time' },
    { field: 'eventcreateddatetime', headerName: ' Event Created date/time',cellRenderer: EventdateCellRendererComponent },
    { field: 'eventcreateddate', headerName: 'Event Created-Date',cellRenderer: EventdateCellRendererComponent },
    { field: 'eventcreatedtime', headerName: 'Event Created-Time',cellRenderer: EventdateCellRendererComponent },
    { field: 'driver', headerName: 'Driver' },
    { field: 'trip', headerName: 'Trip' },
    { field: 'truck', headerName: 'Truck' },
    { field: 'trailer1', headerName: 'Trailer 1' },
    { field: 'trailer2', headerName: 'Trailer 2' },
    { field: 'dock', headerName: 'Dock' },
    { field: 'user', headerName: 'User' },
    { field: 'location', headerName: 'Location' },
    { field: 'datasource', headerName: 'Data Source' },
    { field: 'eventadjusted', headerName: 'Event Adjusted' },
    { field: 'todexportable', headerName: 'TOD Exportable' },
    { field: 'exported', headerName: 'Exported' },
    { field: 'comments', headerName: 'Comments' },
    { field: 'latitude', headerName: 'Latitude' },
    { field: 'longitude', headerName: 'Longitude' },
    { field: 'logonlogoffcompliance', headerName: 'Logon/Logoff Compliance' },
    { field: 'serviceno', headerName: 'Service No.' },
    { field: 'loadno', headerName: 'Load No.' },
  ];

  //On Event grid ready
  onEventGridReady(params: GridReadyEvent<EventTable>) {
    this.gridApiEvent = params.api;
  }

  //on row selection in AG Grid for Event

  onEventSelectionChanged(event: any) {
    const selectedRows = this.gridApiEvent.getSelectedRows();
  }
  isFormTouched(): boolean {
    const controls = this.tripdetailsform.controls;
    return Object.keys(controls).some(
      (controlName) => controls[controlName].touched
    );
  }

  //despatch trip
  despatchTrip() {
    this.planService
      .DespatchTrip(this.selectedTrip[0].id)
      .subscribe((result) => {
        //send info back to update table
        this.despatchnotify.emit(result);
        this.getEvents(this.selectedTrip[0].id);
        let toastmessage =
          'Trip:' + this.selectedTrip[0].tripIdCust + ' despatched';
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: toastmessage,
        });
      });
  }
  //undespatch trip
  undespatchTrip() {
    this.planService
      .UndespatchTrip(this.selectedTrip[0].id)
      .subscribe((result) => {
        this.undespatchnotify.emit(result);
        this.getEvents(this.selectedTrip[0].id);
        let toastmessage =
          'Trip:' + this.selectedTrip[0].tripIdCust + ' undespatched';
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: toastmessage,
        });
      });
  }

  // //click on execution event button
  // onExecEventClick() {

  //   this.confirmationService.confirm({
  //     accept: () => {

  //       this.messageService.add({
  //         severity: 'success',
  //         summary: '',
  //         detail: 'mess',
  //       });
  //     },
  //     reject: (type: ConfirmEventType) => {
  //       switch (type) {
  //         case ConfirmEventType.REJECT:
  //           this.messageService.add({
  //             severity: 'error',
  //             summary: 'Rejected',
  //             detail: 'You have rejected',
  //           });
  //           break;
  //         case ConfirmEventType.CANCEL:
  //           this.messageService.add({
  //             severity: 'warn',
  //             summary: 'Cancelled',
  //             detail: 'You have cancelled',
  //           });
  //           break;
  //       }
  //     },
  //   });
  // }
  openExecEventsDialog() {
    const dialogRef = this.dialog.open(ExecutionEventsDialogComponent, {
      data: {
        tripId: this.selectedTrip[0].id,
        tripno: this.selectedTrip[0].tripIdCust,
      },
    });
  }

  OnTripSheetClick() {
    let tripId = this.selectedTrip[0].id;

    // open report view window
    window.open('/reportview?tripSheetPreview=' + tripId, '_blank');
  }
}
