import { Component, Inject, OnInit,OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { idLocale } from 'ngx-bootstrap/chronos';
import { Driver2, DuplicateTripOptions } from '../../../models/plan.model';
import { PlanService } from '../../../services/plan.service';

@Component({
  selector: 'app-duplicate-selected-trips-dialog',
  templateUrl: './duplicate-selected-trips-dialog.component.html',
  styleUrls: ['./duplicate-selected-trips-dialog.component.scss']
})
export class DuplicateSelectedTripsDialogComponent implements OnInit,OnChanges {
noOfCopies:number=0;
constructor( @Inject(MAT_DIALOG_DATA) public data: any,public planService:PlanService,private formBuilder: FormBuilder,  public dialogRef: MatDialogRef<DuplicateSelectedTripsDialogComponent>,){}
drivers:any[]=[]
driversall:any[]=[];
selecteddriver:any;
trucks:any[]=[];
selectedtruck:any;
loadTypes:any[]=[];
selectedloadType:any;
servicetypes:any[]=[];
selectedserviceType:any;
ngOnInit(): void {
  this.duplicateform = this.formBuilder.group({
    tripdatetime:[],
    driverId:[null],
    truckId:[null],
    servicetype:[],
    loadtype:[],
    copies:[],
   });
   this.duplicateform.patchValue({
    driverId:this.data.selectedTrips[0].driver,
    truckId:this.data.selectedTrips[0].truck
   })
   this.showtripdatetime=moment(this.data.selectedTrips[0].startdatetime)
   .tz('Australia/Melbourne')
   .format('DD/MM/YY HH:mm:ss')
  
   this.drivers.push(this.data.selectedTrips[0].driver);
   this.trucks.push(this.data.selectedTrips[0].truck)

  this.data.drivers.forEach((d:any) => {
    this.drivers.push(d.name)
  });
  this.data.trucks.forEach((element:any) => {
    this.trucks.push(element);
  });
  this.data.loadTypes.forEach((element:any) => {
    this.loadTypes.push(element)
  });
  this.data.servicetypes.forEach((element:any) => {
    this.servicetypes.push(element)
  });
 
}
showtripdatetime:any;
duplicateform:FormGroup;
ngOnChanges(changes: SimpleChanges): void {
 
}
getDriverId(drivername:string):number{
let id:number=0;
let te = drivername.split('(',1)[0].trimEnd();
this.driversall.forEach((element:any) => {
  if(element.name == te){
    id=element.id;
  }
});
return id;
}
check:any[]=[]
temp:DuplicateTripOptions={
  tripDate:0,
  truckId:'',
  serviceType:'',
  driverId:0,
  loadType:'',
  numberOfDuplicates:0
  
};
DuplicateTrip(){
  this.data.drivers.forEach((d:any) => {
    
    this.driversall.push(d)
  });
if(this.duplicateform.dirty){
  if(this.duplicateform.controls['loadtype'].touched){
    this.temp.loadType=this.duplicateform.controls['loadtype'].value;
  }
  else{
    this.temp.loadType=this.data.selectedTrips[0].firstloadtype;
  }
  if(this.duplicateform.controls['servicetype'].touched){
    this.temp.serviceType=this.duplicateform.controls['servicetype'].value
  }
  else{
    this.temp.serviceType=this.data.servicetype;
  }
  if(this.duplicateform.controls['tripdatetime'].touched){
    this.temp.tripDate=moment( moment.tz(moment( this.duplicateform.controls['tripdatetime'].value).format('YYYY-MM-DD HH:mm:ss'), 'Australia/Melbourne').clone().tz('Asia/Kolkata')).valueOf();
  }
  else{
    this.temp.tripDate=moment( moment.tz(moment( moment(this.showtripdatetime, 'DD-MM-YYYY HH:mm:ss').format(
      'YYYY-MM-DD HH:mm:ss'
    )).format('YYYY-MM-DD HH:mm:ss'), 'Australia/Melbourne').clone().tz('Asia/Kolkata')).valueOf();
    
  
  }
  if(this.duplicateform.controls['truckId'].touched){
    this.temp.truckId=this.duplicateform.controls['truckId'].value;
  }
  else{
    this.temp.truckId=this.data.selectedTrips[0].truck;
  }

  if(this.duplicateform.controls['driverId'].touched){

    this.temp.driverId=this.getDriverId(this.duplicateform.controls['driverId'].value);
  }
  else{
    this.temp.driverId= this.getDriverId(this.data.selectedTrips[0].driver);
  }
  if(this.duplicateform.controls['copies'].touched){
    this.temp.numberOfDuplicates=this.duplicateform.controls['copies'].value;

  }
}
else{
  this.check=this.data.selectedTrips[0];
  this.temp.truckId=this.data.selectedTrips[0].truck;
  this.temp.driverId= this.getDriverId(this.data.selectedTrips[0].driver);
  this.temp.numberOfDuplicates=this.duplicateform.controls['copies'].value;
}
  this.planService.DuplicateTrip(this.temp,this.data.selectedTrips[0].id).subscribe((result: any) => {
    this.dialogRef.close({data:result});
  });
}
CloseDialog(){
  this.dialogRef.close();
}
}
