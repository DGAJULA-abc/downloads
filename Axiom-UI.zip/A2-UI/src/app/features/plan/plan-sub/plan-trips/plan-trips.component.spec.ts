import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanTripsComponent } from './plan-trips.component';

describe('PlanTripsComponent', () => {
  let component: PlanTripsComponent;
  let fixture: ComponentFixture<PlanTripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanTripsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanTripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
