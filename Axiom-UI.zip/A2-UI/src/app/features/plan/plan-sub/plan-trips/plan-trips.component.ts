import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  RowClassRules,
} from 'ag-grid-community';
import {
  DeleteTripPayload,
  Dock,
  Driver,
  Driver2,
  EventTypes,
  Reasons,
  ResourceAllocation,
  ResourceAllocationTable,
  ServiceDateCycle,
  Trailer,
  TripDateCycle,
  TripTable,
} from '../../models/plan.model';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { PlanService } from '../../services/plan.service';
import { AllocatedDialogComponent } from './allocated-dialog/allocated-dialog.component';
import { DuplicateSelectedTripsDialogComponent } from './duplicate-selected-trips-dialog/duplicate-selected-trips-dialog.component';
import { ReasonDateChangeDialogComponent } from './reason-date-change-dialog/reason-date-change-dialog.component';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { DateformatTripsComponent } from '../../services/dateformat-trips/dateformat-trips.component';
import * as moment from 'moment';
@Component({
  selector: 'app-plan-trips',
  templateUrl: './plan-trips.component.html',
  styleUrls: ['./plan-trips.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class PlanTripsComponent implements OnInit, OnChanges {
  @Output() getselectedtrip: EventEmitter<TripDateCycle[]> = new EventEmitter<
    TripDateCycle[]
  >();
  @Output() getselectedtripservice: EventEmitter<ServiceDateCycle[]> =
    new EventEmitter<ServiceDateCycle[]>();
  @Input() dateCycleResult: any;

  totalrecords: number = 0;
  ngOnChanges(changes: SimpleChanges): void {
    this.totalcompleted = 0;
    this.totaldespatched = 0;
    this.totalplanned = 0;
    this.totalready = 0;
    this.totaltransit = 0;
    this.completewidth = 'width:';
    this.despatchwidth = 'width:';
    this.plannedwidth = 'width:';
    this.transitwidth = 'width:';
    this.readywidth = 'width:';
    if(this.dateCycleResult){

      if (
        this.dateCycleResult.trips.length != 0 ||
        this.dateCycleResult.services.length != 0 ||
        this.dateCycleResult.driverResources.length != 0
      ) {
        this.trips_date_cycle = this.dateCycleResult.trips;
        this.trip_service_data = this.dateCycleResult.services;
        this.trip_driver_resources = this.dateCycleResult.driverResources;
        this.TableData(this.trips_date_cycle, this.trip_driver_resources[0].id);
      }
    }

    console.log('in trips date cycle result', this.dateCycleResult);
   

    this.gridApi.refreshCells();
  }
  constructor(
    public planService: PlanService,
    public dialog: MatDialog,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public navbarService: NavbarService
  ) {}
  //disable/enable buttons on rowselection
  eventstab: boolean = true;
  moreactions: boolean = true;
  deletebtn: boolean = true;

  SiteId: number = 0;
  ngOnInit() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.isLoading = false;
        this.ViewDataDrivers = result['ref'].drivers;
        this.ViewDataTrucks = result['ref'].trucks;
        this.ViewReasons = result['ref'].reasons;
        this.ViewEventTypes = result['ref'].eventTypes;
        this.ViewTrailers = result['ref'].trailers;
        this.ViewDocks = result['ref'].docks;
        console.log('DOCKS', this.ViewDocks);
        this.getDrivers(this.ViewDataDrivers);
        this.getTrucks(this.ViewDataTrucks);
        this.getLoadTypes(result['ref'].loadTypes);
        this.getServiceTypes(result['ref'].serviceTypes);
        if (
          this.dateCycleResult.trips.length != 0 ||
          this.dateCycleResult.services.length != 0 ||
          this.dateCycleResult.driverResources.length != 0
        ) {
          this.trips_date_cycle = this.dateCycleResult.trips;
          this.trip_service_data = this.dateCycleResult.services;
          this.trip_driver_resources = this.dateCycleResult.driverResources;
          this.TableData(
            this.trips_date_cycle,
            this.trip_driver_resources[0].id
          );
        }
      }
    });
    this.SiteId = this.navbarService.selectedSiteId;
  }

  //AG Grid configuration
  private gridApi!: GridApi<TripTable>;
  public rowSelection: 'single' | 'multiple' = 'single';
  public rowStyle = { color: '#007774' };
  rowData: TripTable[] = [];
  columnDefs: ColDef[] = [
    {
      field: 'trip',
      headerName: 'Trip',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    {
      field: 'startdatetime',
      headerName: 'Start date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'startdate',
      headerName: 'Start - Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'starttime',
      headerName: 'Start - Time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'enddatetime',
      headerName: 'End date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'enddate',
      headerName: 'End - Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'endtime',
      headerName: 'End - Time',
      cellRenderer: DateformatTripsComponent,
    },
    { field: 'totaltriptime', headerName: 'Total trip time' },
    { field: 'status', headerName: 'Status' },
    { field: 'despatched', headerName: 'Despatched' },
    {
      field: 'despatchdatetime',
      headerName: 'Despatch date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'despatchdate',
      headerName: 'Despatch Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'despatchtime',
      headerName: 'Despatch Time',
      cellRenderer: DateformatTripsComponent,
    },
    { field: 'driver', headerName: 'Driver' },
    { field: 'truck', headerName: 'Truck' },
    { field: 'trailer', headerName: 'Trailer' },
    { field: 'firstpickup', headerName: 'First pickup' },
    { field: 'returnto', headerName: 'Return To' },
    { field: 'comments', headerName: 'Comments' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'custref', headerName: 'CustRef' },
    { field: 'connote', headerName: 'ConNote' },
    { field: 'multidrop', headerName: 'Multi Drop' },
    { field: 'services', headerName: 'Services' },
    { field: 'dock', headerName: 'Dock' },
    { field: 'enteredby', headerName: 'Entered By' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'utilisation', headerName: 'Utilisation' },
    { field: 'curfewbreach', headerName: 'Curfew Breach' },
    { field: 'region', headerName: 'Region' },
    { field: 'firstdrop', headerName: 'First drop' },
    { field: 'lastdrop', headerName: 'Last drop' },
    { field: 'lastpickup', headerName: 'Last pickup' },
    { field: 'firstloadtype', headerName: 'First Load Type' },
    { field: 'dropsuburb', headerName: 'Drop Suburb' },
    { field: 'loadsuburb', headerName: 'Load Suburb' },
    { field: 'despatchbydatetime', headerName: 'Despatch By date/time' },
    { field: 'despatchbydate', headerName: 'Despatch By - Date' },
    { field: 'despatchbytime', headerName: 'Despatch By - Time' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'customerid', headerName: 'Customer ID' },
    { field: 'paperworkreadydate', headerName: 'Paper Work Ready - Date' },
    { field: 'paperworkreadytime', headerName: 'Paper Work Ready - Time' },
    { field: 'containerno', headerName: 'Container No.' },
    { field: 'companyid', headerName: 'Company ID' },
    { field: 'loadno', headerName: 'Load No.' },
    { field: 'vesselno', headerName: 'Vessel No.' },
  ];
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

  //TODO: row style expression syntax - correct but not working?!
  // public rowClassRules: RowClassRules = {
  //   "despatch-rows": 'data.status == despatched',
  //   "non-despatch-rows":'data.status == planned'

  // };

  //get date from date-cyle api in main plan component.ts for now hard coded.
  // from: number = 1660140000000;
  // to: number = 1660226399999;
  trips_date_cycle: TripDateCycle[] = [];
  trip_service_data: ServiceDateCycle[] = [];
  trip_driver_resources: any = 0;

  ViewDataDrivers: Driver2[] = [];
  drivers: any[] = [];
  driver: any;
  dt: any;

  ViewDataTrucks: ResourceAllocation[] = [];
  ViewReasons: Reasons[] = [];
  ViewEventTypes: EventTypes[] = [];
  ViewTrailers: Trailer[] = [];
  ViewDocks: Dock[] = [];
  isLoading: boolean = true;
  onGridReady(params: GridReadyEvent<TripTable>) {
    this.gridApi = params.api;
    this.isLoading = true;
  }

  loadTypes: any[] = [];
  getLoadTypes(loadtypes: any[]) {
    loadtypes.forEach((element) => {
      this.loadTypes.push(element.loadTypeId);
    });
  }
  servicetypes: any[] = [];
  getServiceTypes(serviceTypes: any[]) {
    serviceTypes.forEach((element) => {
      this.servicetypes.push(element.serviceTypeId);
    });
  }

  trucks: any[] = [];
  value: any;
  //Get trucks info from View API
  getTrucks(viewtrucks: ResourceAllocation[]) {
    viewtrucks.forEach((element) => {
      if (element.active == true) {
        this.value =
          element.truckId +
          ' (' +
          element.routeCapacity +
          ', ' +
          element.truckTypeId +
          ')';
        this.trucks.push(this.value);
      }
    });
  }
  //Get Driver info from View API
  getDrivers(viewdrivers: Driver2[]) {
    viewdrivers.forEach((element: any) => {
      this.driver = { name: '', company: '', id: '' };
      if (element.active == true) {
        if (element.surname != null && element.firstName != null) {
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (element.employeeName != null) {
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
    console.log(this.drivers);
  }
  SelectedTrips: TripTable[] = [];
  selectedtrip: TripDateCycle[] = [];
  selectedservice: ServiceDateCycle[] = [];
  isdespatched: boolean = true;

  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    console.log('check', selectedRows);
    this.SelectedTrips = [];
    this.selectedtrip = [];
    if (selectedRows.length != 0) {
      this.eventstab = false;
      this.moreactions = false;
      this.deletebtn = false;

      selectedRows.forEach((element) => {
        this.SelectedTrips.push(element);
        if (element.status == 'despatched') {
          this.isdespatched = false;
        }
      });
      selectedRows.forEach((selectedrow) => {
        this.trips_date_cycle.forEach((trip) => {
          if (selectedrow.id == trip.id) {
            this.selectedtrip.push(trip);
          }
        });
        this.trip_service_data.forEach((service) => {
          if (selectedrow.trip == service.tripIdCust) {
            this.selectedservice.push(service);
          }
        });
      });
      this.getselectedtrip.emit(this.selectedtrip);
      this.getselectedtripservice.emit(this.selectedservice);
    } else {
      this.eventstab = true;
      this.moreactions = true;
      this.deletebtn = true;
      this.getselectedtrip.emit(this.selectedtrip);
    }
  }
  //fill table with data and record them for progress bar
  totalcompleted: number = 0;
  totaldespatched: number = 0;
  totalplanned: number = 0;
  totaltransit: number = 0;
  totalready: number = 0;

  completewidth = 'width:';
  despatchwidth = 'width:';
  plannedwidth = 'width:';
  transitwidth = 'width:';
  readywidth = 'width:';

  getActivityTime(time: number): string {
    let hours = Math.floor(time / 3600000);
    var minutes =(time%3600000)/60000
    // var minutes = Math.round((32.7666666 - hours) * 60);
    return String(hours) + 'h ' + String(minutes) + 'm';
  }
  drivername: string;
  getDriverforTable(dat: any): string {
    this.drivername = '';
    this.drivers.forEach((element) => {
      if (element.id == dat) {
        this.drivername = element.name + ' (' + element.company + ')';
      }
    });
    return this.drivername;
  }
  dockname: string;
  getDockName(did: number): string {
    this.dockname = '';
    this.ViewDocks.forEach((element) => {
      if (element.id == did) {
        this.dockname = element.dockName;
      }
    });
    return this.dockname;
  }
  rows: TripTable[] = [];
  date_temp: any;

  TableData(trips: TripDateCycle[], dat: any) {
    this.rows = [];
    this.totalplanned = 0;
    this.totaldespatched = 0;
    this.totalcompleted = 0;
    this.totalready = 0;
    this.totaltransit = 0;

    trips.forEach((trip) => {
      let temp: TripTable = {
        trip: '',
        id: '',
        startdatetime: '',
        startdate: '',
        starttime: '',
        enddatetime: '',
        enddate: '',
        endtime: '',
        totaltriptime: '',
        status: '',
        despatched: '',
        despatchdatetime: '',
        despatchdate: '',
        despatchtime: '',
        driver: '',
        truck: '',
        trailer: '',
        firstpickup: '',
        returnto: '',
        comments: '',
        remarks: '',
        custref: '',
        connote: '',
        multidrop: '',
        services: '',
        dock: '',
        enteredby: '',
        tonnes: '',
        utilisation: '',
        curfewbreach: '',
        region: '',
        firstdrop: '',
        lastdrop: '',
        lastpickup: '',
        firstloadtype: '',
        dropsuburb: '',
        loadsuburb: '',
        despatchbydatetime: '',
        despatchbydate: '',
        despatchbytime: '',
        deliverywindow: '',
        customerid: '',
        paperworkreadydate: '',
        paperworkreadytime: '',
        containerno: '',
        companyid: '',
        loadno: '',
        vesselno: '',
      };
      temp.trip = trip.tripIdCust;
      temp.startdate = moment(trip.tripDate)
        .tz('Australia/Melbourne')
        .format('YYYY-MM-DD HH:mm:ss');
      temp.despatched = trip.despatched;
      if (trip.cachedStatus == 'P ') {
        temp.status = 'planned';
        this.totalplanned += 1;
      }
      if (trip.cachedStatus == 'D ') {
        temp.status = 'despatched';
        this.totaldespatched += 1;
      }
      if (trip.cachedStatus == 'U ') {
        temp.status = 'despatched';
        this.totaldespatched += 1;
      }
      if(trip.cachedStatus == "L "){
        temp.status = 'transit';
        this.totaltransit += 1;
      }
      temp.startdate = trip.plannedStartTime;
      temp.starttime = trip.plannedStartTime;
      temp.startdatetime = trip.plannedStartTime;
      temp.enddatetime = trip.plannedFinishTime;
      temp.enddate = trip.plannedFinishTime;
      temp.endtime = trip.plannedFinishTime;
      if (trip.actualDespatchTime) {
        temp.despatchdatetime = trip.actualDespatchTime;
        temp.despatchdate = trip.actualDespatchTime;
        temp.despatchtime = trip.actualDespatchTime;
      } else {
        temp.despatchdatetime = 0;
        temp.despatchdate = 0;
        temp.despatchtime = 0;
      }
      temp.totaltriptime = this.getActivityTime(
        trip.plannedFinishTime - trip.plannedStartTime
      );
      temp.truck = trip.truckId;
      temp.id = trip.id;
      temp.driver = this.getDriverforTable(dat);
      temp.trailer = trip.trailerId;
      temp.connote = trip.batchNo;
      temp.dock = this.getDockName(trip.dockId);
      temp.firstpickup = trip.firstPickup;
      temp.returnto = trip.returnLocationId;
      temp.comments = trip.comments;
      temp.remarks = trip.remarks;
      temp.custref = trip.custRef;
      temp.multidrop = trip.multiDrop;
      temp.services = trip.serviceIds.length;
      temp.enteredby = trip.enteredBy;
      temp.utilisation = Math.round(Number(trip.utilization) * 100) / 100;
      temp.firstdrop = trip.firstDrop;
      temp.lastdrop = trip.lastDrop;
      temp.lastpickup = trip.lastPickup;
      temp.firstloadtype = trip.firstLoadType;
      temp.dropsuburb = trip.dropSuburb;
      temp.loadsuburb = trip.loadSuburb;
      temp.companyid = trip.companyId;
      temp.loadno = trip.loadNo;
      this.rows.push(temp);
    });
    this.rowData = this.rows;
    this.totalrecords = this.rowData.length;
    //progressbar updates
    if (this.totaldespatched != 0) {
      this.despatchwidth =
        this.despatchwidth +
        String((this.totaldespatched / this.totalrecords) * 100) +
        '%';
    } else {
      this.despatchwidth = this.despatchwidth + '0%';
    }
    if (this.totalplanned != 0) {
      this.plannedwidth =
        this.plannedwidth +
        String((this.totalplanned / this.totalrecords) * 100) +
        '%';
    } else {
      this.plannedwidth = this.plannedwidth + '0%';
    }
    if (this.totalcompleted != 0) {
      this.completewidth =
        this.completewidth +
        String((this.totalcompleted / this.totalrecords) * 100) +
        '%';
    } else {
      this.completewidth = this.completewidth + '0%';
    }
    if (this.totaltransit) {
      this.transitwidth =
        this.transitwidth +
        String((this.totaltransit / this.totalrecords) * 100) +
        '%';
    } else {
      this.transitwidth = this.transitwidth + '0%';
    }
    if (this.totalready != 0) {
      this.readywidth =
        this.readywidth +
        String((this.totalready / this.totalrecords) * 100) +
        '%';
    } else {
      this.readywidth = this.readywidth + '0%';
    }
  }
  //duplication
  servicetypeofTrip: any;
  openDuplicateDialog() {
    console.log('service type', this.selectedtrip[0]);
    this.trip_service_data.forEach((element) => {
      if (element.id == this.selectedtrip[0].serviceIds[0]) {
        this.servicetypeofTrip = element.serviceTypeId;
      }
    });
    const dialogRef = this.dialog.open(DuplicateSelectedTripsDialogComponent, {
      data: {
        drivers: this.drivers,
        trucks: this.trucks,
        loadTypes: this.loadTypes,
        servicetypes: this.servicetypes,
        selectedTrips: this.SelectedTrips,
        servicetype: this.servicetypeofTrip,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res) {
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Trip duplicated',
        });
        res.data.trips.forEach((trip: any) => {
          this.trips_date_cycle.push(trip);
        });
        this.TableData(this.trips_date_cycle, this.trip_driver_resources[0].id);
      }
    });
  }
  //change date
  openDateChangeDialog() {
    const dialogRef = this.dialog.open(ReasonDateChangeDialogComponent, {
      data: {
        reasons: this.ViewReasons,
        selectedtrips: this.SelectedTrips,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      //TODO: refresh not happening. API works.
      if (res.data == true) {
        const res = this.gridApi.applyTransaction({
          remove: this.SelectedTrips,
        })!;
        this.gridApi.refreshCells();
        this.planService
          .getTripEvent(this.SelectedTrips[0].id)
          .subscribe((res) => {
            //events called
          });
      }
    });
  }
  //event variables
  datasourceId: string;
  allocatetype: EventTypes;
  lunchbreakstarttype: EventTypes;
  lunchbreakendtype: EventTypes;
  shiftendtype: EventTypes;
  departdepoteventtype: EventTypes;
  //disabled events
  returningtobasetype: EventTypes;
  returnedtobasetype: EventTypes;
  departdepottype: EventTypes;
  returnedtobaseeventtype: EventTypes;
  returningtobaseeventtype: EventTypes;
  getdatasource() {
    this.trip_service_data.forEach((element) => {
      this.datasourceId = element.dataSourceId;
    });
  }
  openAllocatedDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Allocated') {
        this.allocatetype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.allocatetype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  openLunchBreakStartDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Lunch Break - Start') {
        this.lunchbreakstarttype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.lunchbreakstarttype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }

  openLunchBreakEndDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Lunch Break - End') {
        this.lunchbreakendtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.lunchbreakendtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  openShiftEndDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Shift End') {
        this.shiftendtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.shiftendtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  openDepartDepotDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Depart Depot') {
        this.departdepoteventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.departdepoteventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  openReturningBaseDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Returning To Base') {
        this.returningtobaseeventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.returningtobaseeventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  openReturnedBaseDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Returned To Base') {
        this.returnedtobaseeventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.returnedtobaseeventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Event created',
      });
      // received data from dialog-component
      this.rowData.forEach((row) => {
        this.planService.getTripEvent(row.id).subscribe((res) => {
          //events called
        });
      });
    });
  }
  onRemove(payload: DeleteTripPayload) {
    const selectedData = this.gridApi.getSelectedRows();
    const res = this.gridApi.applyTransaction({ remove: selectedData })!;
    this.planService.DeleteTrip(payload).subscribe((result) => {
      this.gridApi.refreshCells();
    });
  }
  deletepayload: DeleteTripPayload = {
    ids: [],
    siteId: 0,
  };
  idList: number[] = [];
  onDelete() {
    this.SelectedTrips.forEach((element) => {
      this.deletepayload.ids.push(element.id);
    });
    this.deletepayload.siteId = this.SiteId;

    let toastrNO: string = '';
    this.confirmationService.confirm({
      message: 'Click OK to Continue',
      header: 'Are you sure you want to delete?',

      accept: () => {
        this.onRemove(this.deletepayload);
        this.SelectedTrips.forEach((element) => {
          toastrNO += element.id + ' ';
        });
        let mess = 'Trip(s): ' + toastrNO + 'deleted.';
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: mess,
        });
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }
}
