import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { DateChangePayload, Reasons } from '../../../models/plan.model';
import { PlanService } from '../../../services/plan.service';

@Component({
  selector: 'app-reason-date-change-dialog',
  templateUrl: './reason-date-change-dialog.component.html',
  styleUrls: ['./reason-date-change-dialog.component.scss'],
})
export class ReasonDateChangeDialogComponent implements OnInit {
  reasons: any[] = [];
  selectedReason: any;
  selectedtripids:any[]=[];
  newdate:Date;
  refreshflag:boolean=false;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,public planService:PlanService,public dialogRef: MatDialogRef<ReasonDateChangeDialogComponent>,) {}
 

  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    this.data.reasons.forEach((element: any) => {
      let temp = '';
      temp = element.reasonId + '_' + element.reasonDescription;
      this.reasons.push(temp);
    });
    this.data.selectedtrips.forEach((element:any) => {
      this.selectedtripids.push(element.id);
    });
    
  }
  payload:DateChangePayload={
    reason:'',
    ids:[],
    fields:{tripDate:0}
    
  };
  reasonid:any;
  SaveDateChange(){
    this.reasonid=this.selectedReason.split("_",1);
    if(this.reasonid!=undefined){
      this.payload.reason=this.reasonid[0];
      
      let start_date;
      start_date = moment(this.newdate);
      start_date = start_date.format('YYYY-MM-DD HH:mm:ss');
      var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
      var s_india = s_australia_time.clone().tz('Asia/Kolkata');
      this.payload.fields.tripDate=moment(s_india).valueOf();;
      this.payload.ids=this.selectedtripids;
    }
    this.planService.Trips(this.payload).subscribe((result: any) => {
      this.refreshflag=true;
      this.dialogRef.close({data:this.refreshflag});
    });
  }
}
