import {
  Component,
  OnInit,
  ElementRef,
  Renderer2,
  ViewChild,
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { NgIf, JsonPipe, DatePipe } from '@angular/common';
import * as moment from 'moment';
import {
  Driver,
  ResourceAllocation,
  ResourceAllocationTable,
  ServiceDateCycle,
  TripDateCycle,
  ViewCustomer,
} from './models/plan.model';
import { PlanService } from './services/plan.service';
import 'moment-timezone'; // Import moment-timezone
@Component({
  selector: 'app-plan',
  templateUrl: './plan.component.html',
  styleUrls: ['./plan.component.scss'],
  providers: [DatePipe],
})
export class PlanComponent implements OnInit {
  //DetailsTab-> 0:Blank 1:New Service 2:Roster 3:Resource Allocation dialog 4:Trip Details 5:Existing Service
  DetailsTab: number = 0;
  showNewServiceForm: boolean = false;
  range = new FormGroup({
    start: new FormControl<Date | null>(null),
    end: new FormControl<Date | null>(null),
  });

  //display in details tab based on selection
  DriverSelect(message: any[]) {
    this.DetailsTab = 2;
  }
  ResourceAllocate(message: ResourceAllocation) {
    this.DetailsTab = 3;
  }
  TripSelect(message: TripDateCycle[]) {
    this.DetailsTab = 4;
  }
  ServiceSelect(mess: ServiceDateCycle) {
    this.DetailsTab = 5;
  }

  minDate = { day: 9, month: 4, year: 2022 };
  myDateValue!: Date;
  model!: any;
  date!: { year: number; month: number };
  private disabledWeekdays: number[] = [6, 7];

  selected_date = new Date();
  selected_time: any = '00:00';
  selected_duration: any = 24;
  end_date: any =
    this.datepipe.transform(this.selected_date, 'yyyy-MM-dd') + ' ' + '23:59';
  @ViewChild('toggleButton') toggleButton!: ElementRef;
  @ViewChild('dropdownmenu') dropdownmenu!: ElementRef;
  showDiv: boolean = false;
  times: any[] = [
    '00:00',
    '01:00',
    '02:00',
    '03:00',
    '04:00',
    '05:00',
    '06:00',
    '07:00',
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00',
    '19:00',
    '20:00',
    '21:00',
    '22:00',
    '23:00',
  ];
  durations: any[] = [
    { name: '4h', value: 4 },
    { name: '8h', value: 8 },
    { name: '12h', value: 12 },
    { name: '16h', value: 16 },
    { name: '20h', value: 20 },
    { name: '1d', value: 24 },
    { name: '1d4h', value: 28 },
    { name: '1d8h', value: 32 },
    { name: '1d12h', value: 36 },
    { name: '1d16h', value: 40 },
    { name: '1d20h', value: 44 },
    { name: '2d', value: 48 },
  ];

  constructor(
    public datepipe: DatePipe,
    private renderer: Renderer2,
    public planService: PlanService
  ) {
    this.renderer.listen('window', 'click', (e: Event) => {
      if (
        e.target !== this.toggleButton.nativeElement &&
        e.target !== this.dropdownmenu.nativeElement
      ) {
        this.showDiv = false;
      }
    });
  }
  customers: any[] = [];
  ViewCustomers: ViewCustomer[] = [];
  getCustomers(ViewCustomers: ViewCustomer[]) {
    ViewCustomers.forEach((element) => {
      this.customers.push(element.customerId);
    });
  }
  ngOnInit(): void {
    this.isLoading = true;
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.isLoading = false;

        this.getCustomers(result['ref'].customers);
      }
    });
  }
  toggleMenu() {
    this.showDiv = !this.showDiv;
  }

  btnclick() {
    this.selected_date = new Date();
  }
  createserviceformflag: boolean = false;
  showNewService(): void {
    this.showNewServiceForm = !this.showNewServiceForm;
    if (this.showNewServiceForm == true) {
      this.DetailsTab = 1;
      this.createserviceformflag = true;
    } else {
      this.DetailsTab = 0;
      this.createserviceformflag = false;
    }
  }

  isLoading: boolean = true;

 
  from: number = 0;
  to: number = 0;
  services_date_cycle: ServiceDateCycle[] = [];
  service_trips_date_cycle: TripDateCycle[];
  DateCycleResult: any;
  select_dateTime() {
    //palak trial on date-cycle for FROM
    let start_date;
    start_date = moment(this.selected_date);
    start_date = start_date
      .set({
        hour: Number(this.selected_time.split(':', 1)[0]),
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    this.from = moment(s_india).valueOf();

    
    //palak trial on date-cycle for TO
    let getendtime = s_australia_time
    .add(this.selected_duration, 'hours')
    .subtract(1, 'seconds');
    let endtime = getendtime.format('YYYY-MM-DD HH:mm:ss');
    this.end_date =  getendtime.format('MM/DD/YY HH:mm');
    let e_australia_time = moment.tz(endtime, 'Australia/Melbourne');
    var e_india = e_australia_time.clone().tz('Asia/Kolkata');
    this.to = moment(e_india).valueOf();
    this.end_date=endtime
    
    this.isLoading = true;
    this.planService
      .getDataCycleData(this.from, this.to)
      .subscribe((result: any) => {
        if (result) {
          this.isLoading = false;
          this.DateCycleResult = result;
          this.services_date_cycle = result.services;
          this.service_trips_date_cycle = result.trips;
          console.log('DAte cycle', this.DateCycleResult);
        }
      });
  }

  //Filter dropdown for all tabs
  filtering: string = '';
  showDrivers: boolean = true;
  showTrips: boolean = true;
  showPrimeMovers: boolean = true;
  showServices: boolean = true;
  showResourceAllocation: boolean = true;
  TabToggling(tog: string) {
    this.filtering = tog;
    if (tog == 'drivers') {
      this.showDrivers = !this.showDrivers;
    } else if (tog == 'trips') {
      this.showTrips = !this.showTrips;
    } else if (tog == 'primemovers') {
      this.showPrimeMovers = !this.showPrimeMovers;
    } else if (tog == 'services') {
      this.showServices = !this.showServices;
    } else if (tog == 'resourceallocation') {
      this.showResourceAllocation = !this.showResourceAllocation;
    }
  }
  //CSV Upload application routing
  csvUpload() {
    console.log('Clicked the button');
    window.open('https://axiom2-uat.tollgroup.com/csv/csv.html#/');
  }
  IsServiceCreated(mess: boolean) {
    if (mess == true) {
      this.isLoading = true;
      this.planService
        .getDataCycleData(this.from, this.to)
        .subscribe((result: any) => {
          if (result) {
            this.isLoading = false;
            this.services_date_cycle = result.services;
            this.service_trips_date_cycle = result.trips;
            console.log('DAte cycle', this.services_date_cycle);
          }
        });
    }
  }
}
