import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PlanRoutingModule } from './plan-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { PlanComponent } from './plan.component';
import { PlanSubComponent } from './plan-sub/plan-sub.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import {  BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { AgGridModule } from 'ag-grid-angular';
import { AgChartsAngularModule } from 'ag-charts-angular';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MessagesModule } from 'primeng/messages';
import { PlanDetailsComponent } from './plan-sub/plan-details/plan-details.component';
import { AddContainerDialogComponent } from './plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { PlanServicesComponent } from './plan-sub/plan-services/plan-services.component';
import { PlanDriversComponent } from './plan-sub/plan-drivers/plan-drivers.component';
import { PlanDriverRosterComponent } from './plan-sub/plan-driver-roster/plan-driver-roster.component';
import { PlanPrimeMoversComponent } from './plan-sub/plan-prime-movers/plan-prime-movers.component';
import { PlanTripsComponent } from './plan-sub/plan-trips/plan-trips.component';
import { PlanResourceAllocationComponent } from './plan-sub/plan-resource-allocation/plan-resource-allocation.component';
import { PlanResourceDetailsComponent } from './plan-sub/plan-resource-details/plan-resource-details.component';
import { DriverRosterComponent } from './driver-roster/driver-roster.component';
import { BulkCopyDialogComponent } from './plan-sub/plan-services/bulk-copy-dialog/bulk-copy-dialog.component';
import { DuplicateSelectedTripsDialogComponent } from './plan-sub/plan-trips/duplicate-selected-trips-dialog/duplicate-selected-trips-dialog.component';
import { ReasonDateChangeDialogComponent } from './plan-sub/plan-trips/reason-date-change-dialog/reason-date-change-dialog.component';
import { AllocatedDialogComponent } from './plan-sub/plan-trips/allocated-dialog/allocated-dialog.component';
import { PlanTripDetailsComponent } from './plan-sub/plan-trip-details/plan-trip-details.component';
import { ExecutionEventsDialogComponent } from './plan-sub/plan-trip-details/execution-events-dialog/execution-events-dialog.component';
import { DateCellRendererComponent } from './plan-sub/plan-trip-details/date-cell-renderer/date-cell-renderer.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { DateformatComponent } from './services/dateformat/dateformat.component';
import { DateformatTripsComponent } from './services/dateformat-trips/dateformat-trips.component';
import { ServiceStatusComponent } from './services/service-status/service-status.component';
import { EventdateCellRendererComponent } from './services/eventdate-cell-renderer/eventdate-cell-renderer.component';
import { GanttCellRendererComponent } from './plan-sub/plan-prime-movers/gantt-cell-renderer/gantt-cell-renderer.component';


@NgModule({
  declarations: [
    PlanComponent,
    PlanSubComponent,
    PlanDetailsComponent,
    AddContainerDialogComponent,
    PlanServicesComponent,
    PlanDriversComponent,
    PlanDriverRosterComponent,
    PlanPrimeMoversComponent,
    PlanTripsComponent,
    PlanResourceAllocationComponent,
    PlanResourceDetailsComponent,
    DriverRosterComponent,
    BulkCopyDialogComponent,
    DuplicateSelectedTripsDialogComponent,
    ReasonDateChangeDialogComponent,
    AllocatedDialogComponent,
    PlanTripDetailsComponent,
    ExecutionEventsDialogComponent,
    DateCellRendererComponent,
    DateformatComponent,
    DateformatTripsComponent,
    ServiceStatusComponent,
    EventdateCellRendererComponent,
    GanttCellRendererComponent,
   
  ],
  imports: [
    PlanRoutingModule,
    CommonModule,
    FormsModule,
    AgGridModule,
    AgChartsAngularModule,
    ConfirmDialogModule,
    DialogModule,
    MessagesModule,
    MatProgressBarModule,
    ReactiveFormsModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot()
  ],
  exports: [
    PlanComponent,
    PlanDetailsComponent,
    PlanTripDetailsComponent
  ]
})
export class PlanModule { }
