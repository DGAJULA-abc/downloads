import { Component } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-dateformat-trips',
  templateUrl: './dateformat-trips.component.html',
  styleUrls: ['./dateformat-trips.component.scss'],
})
export class DateformatTripsComponent {
  public params: any;
  x: any;

  agInit(params: any): void {
    this.params = params;
    switch (params['colDef'].field) {
      //for trips it starts here
      case 'startdatetime':
        this.showBothDateTime(params['data'].startdatetime);
        break;
      case 'startdate':
        this.showOnlyDate(params['data'].starttime);
        break;
      case 'starttime':
        this.showOnlyTime(params['data'].starttime);
        break;
      case 'enddatetime':
        this.showBothDateTime(params['data'].enddatetime);
        break;
      case 'enddate':
        this.showOnlyDate(params['data'].enddate);
        break;
      case 'endtime':
        this.showOnlyTime(params['data'].endtime);
        break;
      case 'despatchdatetime':
        if (params['data'].despatchdatetime) {
          this.showBothDateTime(params['data'].despatchdatetime);
        } else {
          this.x = '';
        }
        break;
      case 'despatchdate':
        if(params['data'].despatchdate){
          this.showOnlyDate(params['data'].despatchdate);
        }
        else{
          this.x=''
        }
        break;
      case 'despatchtime':
        if(params['data'].despatchtime){
          this.showOnlyTime(params['data'].despatchtime);
        }
        else{
          this.x=''
        }
        break;
      default:
        break;
    }
    // let milliseconds = this.incoming_data;
    // let date = moment(milliseconds);
    // this.x = date.tz('Australia/Melbourne').format('YYYY/MM/DD HH:mm:ss');
  }
  showOnlyDate(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('DD/MM/YY');
  }
  showOnlyTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('HH:mm');
  }
  showBothDateTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('DD/MM/YYYY HH:mm:ss');
  }
  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
