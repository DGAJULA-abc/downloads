import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import * as moment from 'moment';

@Component({
  selector: 'app-dateformat',
  templateUrl: './dateformat.component.html',
  styleUrls: ['./dateformat.component.scss'],
})
export class DateformatComponent implements ICellRendererAngularComp {
  public params: any;
  x: any;

  agInit(params: any): void {
    this.params = params;
    switch (params['colDef'].field) {
      //for services it starts here
      case 'createddatetime':
        this.showBothDateTime(params['data'].created);
        break;
      case 'deliverydate':
        this.showOnlyDate(params['data'].loadScheduledDate);
        break;
      case 'createddate':
        this.showOnlyDate(params['data'].created);
        break;
      case 'createdtime':
        this.showOnlyTime(params['data'].created);
        break;
      //for trips it starts here
      // case 'startdatetime':
      //   this.showBothDateTime(params['data'].plannedStartTime);
      //   break;
      // case 'startdate':
      //   this.showOnlyDate(params['data'].plannedStartTime);
      //   break;
      // case 'starttime':
      //   this.showOnlyTime(params['data'].plannedStartTime);
      //   break;
      // case 'enddatetime':
      //   this.showBothDateTime(params['data'].plannedFinishTime);
      //   break;
      // case 'enddate':
      //   this.showOnlyDate(params['data'].plannedFinishTime);
      //   break;
      // case 'endtime':
      //   this.showOnlyTime(params['data'].plannedFinishTime);
      //   break;
      // case 'despatchdatetime':
      //   this.showBothDateTime(params['data'].actualDespatchTime);
      //   break;
      //   case 'despatchdate':
      //     this.showOnlyDate(params['data'].actualDespatchTime);
      //     break;
      //     case 'despatchtime':
      //       this.showOnlyTime(params['data'].actualDespatchTime);
      //       break;
      default:
        break;
    }
    // let milliseconds = this.incoming_data;
    // let date = moment(milliseconds);
    // this.x = date.tz('Australia/Melbourne').format('YYYY/MM/DD HH:mm:ss');
  }
  showOnlyDate(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('DD/MM/YY');
  }
  showOnlyTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('HH:mm');
  }
  showBothDateTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('YYYY/MM/DD HH:mm:ss');
  }
  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
