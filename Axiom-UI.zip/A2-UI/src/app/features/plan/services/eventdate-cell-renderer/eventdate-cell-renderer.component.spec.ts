import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventdateCellRendererComponent } from './eventdate-cell-renderer.component';

describe('EventdateCellRendererComponent', () => {
  let component: EventdateCellRendererComponent;
  let fixture: ComponentFixture<EventdateCellRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventdateCellRendererComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventdateCellRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
