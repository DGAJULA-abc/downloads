import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import * as moment from 'moment';

@Component({
  selector: 'app-eventdate-cell-renderer',
  templateUrl: './eventdate-cell-renderer.component.html',
  styleUrls: ['./eventdate-cell-renderer.component.scss'],
})
export class EventdateCellRendererComponent
  implements ICellRendererAngularComp
{
  public params: any;
  x: any;
  agInit(params: any): void {
    this.params = params;
    switch (params['colDef'].field) {
      //for services it starts here
      case 'eventdatetime':
        this.showBothDateTime(params['data'].eventdatetime);
        break;
      case 'eventdate':
        this.showOnlyDate(params['data'].eventdate);
        break;
      case 'eventtime':
        this.showOnlyTime(params['data'].eventtime);
        break;
      case 'eventcreateddatetime':
        this.showBothDateTime(params['data'].eventcreateddatetime);
        break;
      case 'eventcreateddate':
        this.showOnlyDate(params['data'].eventcreateddate);
        break;
        case 'eventcreatedtime':
          this.showOnlyTime(params['data'].eventcreatedtime);
          break;

      default:
        break;
    }
  }
  showOnlyDate(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('DD/MM/YY');
  }
  showOnlyTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('HH:mm');
  }
  showBothDateTime(datetime: any) {
    let milliseconds = datetime;
    let date = moment(milliseconds);
    this.x = date.tz('Australia/Melbourne').format('DD/MM/YY HH:mm:ss');
  }
  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
