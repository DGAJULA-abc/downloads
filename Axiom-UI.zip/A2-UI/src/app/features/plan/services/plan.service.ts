import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiEndpoint } from 'src/app/config/config.model';
import {
  AllocateEventPayload,
  CopyService,
  DateChangePayload,
  DeleteTripPayload,
  DuplicateTripOptions,
  ExecEventAPIResponse,
  MultiLegSiteLocation,
  ServiceDateCycle,
  TripDateCycle,
  TruckUnavailability,
} from '../models/plan.model';

@Injectable({
  providedIn: 'root',
})
export class PlanService {
  truckUnavailability: TruckUnavailability;
  constructor(private http: HttpClient) {}
  //View API to get all info on trucks,companys,drivers,vendors,locations etc
  getView(): any {
    let options: any = {
      referenceDataActiveStates: {
        drivers: 'ANY',
      },
    };
    return this.http.post<any>(apiEndpoint.contextView, options);
  }
  //Get All Customer Data
  getAllData(selectedId: number) {
    let options: any = [];
    let url = apiEndpoint.multiLegSiteLocations + '/' + selectedId;
    return this.http.get<MultiLegSiteLocation>(url, options);
  }
  //Get All data for Resource Allocation Table
  getResourceAllocation(truckID: any) {
    let options: any = [];
    let url = apiEndpoint.getTruckUnavail + truckID;
    return this.http.get<TruckUnavailability>(url, options);
  }
  //get bulkcreatefetch data from selected date
  bulkCreateFetch(selected_date: any) {
    //From palak for 25th
    // let options:any=1698085800000;
    //From UAT for 25th
    //let options :any=1698152400000;
    let options: any = selected_date;
    let url = apiEndpoint.roster.get;
    return this.http.post<any>(url, options);
  }
  //get data from date cycle selection
  getDataCycleData(From: number, To: number) {
    let options: any = {
      from: From,
      to: To,
    };
    let url = apiEndpoint.planContextDateCycle;
    return this.http.post<any>(url, options);
  }
  CopyService(serviceInfo: CopyService) {
    let options: CopyService = {
      newScheduledDate: serviceInfo.newScheduledDate,
      newServiceDate: serviceInfo.newServiceDate,
      noOfCopies: serviceInfo.noOfCopies,
      serviceId: serviceInfo.serviceId,
    };
    let url = apiEndpoint.copyService;
    return this.http.post<any>(url, options);
  }
  DeleteService(servicenos: any[]) {
    return this.http.delete<any>(`${apiEndpoint.service}`, {
      body: servicenos,
    });
  }
  BulkCopy(fromService:number, toService:number){
    let options:any={
      fromServiceDate: fromService,
      toServiceDate: toService,
    };
    let url = apiEndpoint.bulkCopy;
    return this.http.post<any>(url, options);
  }
  DuplicateTrip(tripinfo:DuplicateTripOptions,tripid:any){
    let options={
      driverId:tripinfo.driverId,
      loadType:tripinfo.loadType,
      numberOfDuplicates:tripinfo.numberOfDuplicates,
      serviceType:tripinfo.serviceType,
      tripDate:tripinfo.tripDate,
      truckId: tripinfo.truckId,
    }
    let url = apiEndpoint.trip+"/"+tripid+"/duplicate";
    return this.http.post<any>(url,options);
  }
  Trips(tripinfo:DateChangePayload){
    let options=tripinfo;
    let url=apiEndpoint.trips;
    return this.http.post<any>(url,options);
  }
  putEvent(payload:AllocateEventPayload[]){
  let options=payload;
  let url= apiEndpoint.events;
  return this.http.put<any>(url,options);
  }
  getTripEvent(tripId:number){
    let options;
    let url=apiEndpoint.tripevent+"/"+tripId+"/events";
    return this.http.get<any>(url,options)
  }
  DeleteTrip(deletetrip: DeleteTripPayload) {
    return this.http.delete<any>(`${apiEndpoint.trips}`, {
      body: deletetrip,
    });
  }
  TripDetailUpdate(updatetrip:TripDateCycle){
    let options:TripDateCycle=updatetrip;
    let url =apiEndpoint.trip+"/"+updatetrip.id+"/trip-svc-seq-update";
    return this.http.post<any>(url,options);
  }
  DespatchTrip(tripId:number){
    let options:number[]=[tripId];
    let url = apiEndpoint.despatchtrip;
    return this.http.post<any>(url,options);
  }
  UndespatchTrip(tripdId:number){
    let options:number[]=[tripdId];
    let url = apiEndpoint.undespatchtrip;
    return this.http.post<any>(url,options);
  }
  getExecutionEvents(tripId:number){
    let options;
    let url= apiEndpoint.trip+"/"+tripId+"/execution-events";
    return this.http.get<any>(url,options)
  }
  postExecutionEvents(tripId:number,payload:any){
    let options= payload;
    let url= apiEndpoint.trip+"/"+tripId+"/execution-events";
    return this.http.post<any>(url,options)
  }
  getServiceEvent(serviceId:any){
    let options;
    let url = apiEndpoint.singleService+"/"+serviceId+"/associated-data"
    return this.http.get<any>(url,options)
  }
  searchContainer(containerid:any){
    let options= {
      containerId:containerid
    };
    let url= apiEndpoint.searchContainer
    return this.http.post<any>(url,options)
  }
  saveExistingService(services:any[]){
    let options=services;
    let url = apiEndpoint.service;
    return this.http.put<any>(url,options)
  }
  addContainer(container:any[]){
    let options=container;
    let url = apiEndpoint.containers;
    return this.http.put<any>(url,options);
  }
}
