import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutomaticCompletionStatusComponent } from './automatic-completion-status.component';

describe('AutomaticCompletionStatusComponent', () => {
  let component: AutomaticCompletionStatusComponent;
  let fixture: ComponentFixture<AutomaticCompletionStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutomaticCompletionStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AutomaticCompletionStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
