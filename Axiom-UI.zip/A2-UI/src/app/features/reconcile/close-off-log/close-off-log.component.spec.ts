import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CloseOffLogComponent } from './close-off-log.component';

describe('CloseOffLogComponent', () => {
  let component: CloseOffLogComponent;
  let fixture: ComponentFixture<CloseOffLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CloseOffLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CloseOffLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
