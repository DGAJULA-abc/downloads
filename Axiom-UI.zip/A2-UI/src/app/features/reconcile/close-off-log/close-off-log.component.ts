import { Component, ViewChild } from '@angular/core';
import { Dropdown } from 'primeng/dropdown';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-close-off-log',
  templateUrl: './close-off-log.component.html',
  styleUrls: ['./close-off-log.component.scss']
})
export class CloseOffLogComponent {
  showMissingSites:boolean = true;
  defaultIWeekEndingDate : Date;
  closeOffLogs :any[] = [];
  sites: any[] = [];
  selectedSite: any;
  disableCloseOff: boolean = true;

  public columnDefs: any[] = [
    { field: 'siteId', headerName: 'Site', width:100} ,
    { field: 'weekEnding', headerName: 'Week Ending', width:100},
    { field: 'user', headerName: 'User', width:100},
    { field: 'status', headerName: 'Status', width:100},
    { field: 'submitted', headerName: 'Submitted', width:150},
    { field: 'started', headerName: 'Started', width:100},
    { field: 'exported', headerName: 'Exported', width:100},
    { field: 'reconciled', headerName: 'Reconciled', width:100},
    { field: 'reported', headerName: 'Reported', width:100},
    { field: 'cancelled', headerName: 'Cancelled', width:100}
    
    
  ];

  constructor(private reconcileService: ReconcileService) {
    
  }

  ngOnInit() {
    let today = new Date();
    today.setDate(today.getDate());
    this.defaultIWeekEndingDate = today;
    this.getRowData();
  }

  getRowData() {
    console.log("selected site:", this.selectedSite);
    let siteId;
    if(!this.selectedSite || this.selectedSite == undefined)
    siteId = null;
    else
    siteId = this.selectedSite.siteId;
    console.log(siteId);
    let closeOffDetails = {
      selectedSite :siteId,
      showMissingSitesForLastWeek : this.showMissingSites,
      weekEndingDate: this.defaultIWeekEndingDate.getTime()
    }
    this.reconcileService.closeOffLog(closeOffDetails)
      .subscribe(
        (result: any) => {
              console.log("result:", result);
              let i =0;
              this.closeOffLogs = result.closeOffLogs;
              this.closeOffLogs.forEach( (element) => {
                // console.log(element.site);
                this.sites.push({"name":element.site, "siteId" : element.siteId});
            });
              console.log("sites:", this.sites);
        })
  }

  getOptions(){
   console.log("called cross", this.selectedSite);
   //this.selectedSite = null;
   //dropdown.placeholder = '';
   //drop//down.resetFilter();
    this.getRowData();
  }
}
