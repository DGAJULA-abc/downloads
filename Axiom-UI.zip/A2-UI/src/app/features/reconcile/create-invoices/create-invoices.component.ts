import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ColDef } from 'ag-grid-community';
import * as moment from 'moment';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';


@Component({
  selector: 'app-create-invoices',
  templateUrl: './create-invoices.component.html',
  styleUrls: ['./create-invoices.component.scss'],
})
export class CreateInvoicesComponent {
  rightTitle: string = 'Create Invoices';
  customers: any[];
  showButtons: boolean; prevDate: boolean = true;
  disableCreateInvoiceBtn: boolean = false;
  daysToPay: any = 7;
  checkboxValue: any;
  ok: boolean = false;
  sum: number = 0;
  isDivVisible: boolean = false;
  selectedRow: any = null;
  checkboxClicked: boolean = false;
  gridOptions: any;
  selectedIds: any = [];
  noDeleteBtn: boolean =  true;
  public defaultIssueDate: Date;
  public defaultFromDate: Date;
  public defaultToDate: Date;
  public columnDefs: any[] = [
    {
      field: 'effectiveDate', headerName: 'Effective date', cellRenderer: (data: any) => {
        return moment(data.value).format('DD/MM/YY')
      }
    },
    {
      field: 'serviceDate', headerName: 'Service date', cellRenderer: (data: any) => {
        return moment(data.value).format('DD/MM/YY')
      }
    }, { field: 'driverId', headerName: 'Driver' },
    { field: 'serviceNumber', headerName: 'Service No' },
    { field: 'serviceType', headerName: 'Service Type' },
    { field: 'loadNumber', headerName: 'Load Number' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    { field: 'customerId', headerName: 'Customer' },

  ];

  public Defs: any[] = [
    {
      field: ' ', headerName: ' ', cellRenderer: CellrenderComponent, cellRendererParams: {
        selectedRow: null
      }
    },
    { field: 'customerId', headerName: 'Customer Id' },
    { field: 'customerName', headerName: 'Name' },
    { field: 'groupId', headerName: 'Group' }];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };


  public menu = [{ name: "one" }, { name: "two" }];
  public rowData = [];
  

  @Output() not: EventEmitter<string> = new EventEmitter<string>();

  constructor(private reconcileService: ReconcileService, private _formBuilder: FormBuilder) {
    this.gridOptions = {
      context: { Component: this }
    }
  }

  ngOnInit() {
    this.not.emit(this.rightTitle);
    //this.getCustomers();
    let yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 4);
    let fromDate = new Date()
    fromDate.setDate(fromDate.getDate() - 7);

    this.defaultIssueDate = yesterday;
    this.defaultFromDate = fromDate;
    this.defaultToDate = yesterday;

    this.getRowData();
  }


  createInvoiceForm = new FormGroup({
    issuedate: new FormControl(),
    daterangefrom: new FormControl(),
    daterangeTo: new FormControl()
  });


  rightSideForm(event: any) {
    const clickedRowData = event.data;
    event.api.forEachNode((node: { data: { isChecked: boolean; }; }) => {
      node.data.isChecked = false;
    });

    event.api.redrawRows();

    if (this.selectedRow) {
      this.selectedRow.isChecked = false;
    }
    // Check the clicked row
    clickedRowData.isChecked = true;
    this.selectedRow = clickedRowData;
    event.api.redrawRows({ rowNodes: [event.node] });
    
    this.sum = 1;
    this.isDivVisible = true;
    this.ok = true;
    if (this.sum > 1) {
      this.isDivVisible = false;
      this.ok = false;
    }
  }

  setCellSubData(intvalue: any, selectedRows: any, checkboxEnabled: boolean) {
    console.log("check:", selectedRows, checkboxEnabled);
    if (intvalue == 0) {
      this.sum = 0
    }
    this.sum += intvalue;
    console.log("selected rows", this.selectedIds, checkboxEnabled);

    if (checkboxEnabled) {
      this.selectedIds.push(selectedRows);
    } else {
      if (this.selectedIds.includes(selectedRows)) {
        this.selectedIds = this.selectedIds.filter((id: any) => id !== selectedRows);
      }
    }
    console.log("final:", this.selectedIds)


  }

  getRowData() {

    const invoiceFormSubmit = {
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime(),
      includePreviousDates: true
    }

    this.reconcileService.createInvoice(invoiceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("invoice > ", result);

          this.rowData = result.completedUninvoicedLines;
          let customerIds = result.customerIds;
          if (!customerIds.length)
            this.disableCreateInvoiceBtn = true;
          this.reconcileService.getCustomers()
            .subscribe(
              (result: any) => {
                console.log("customers > ", result);

                this.customers = result;
                this.reconcileService.getCustomers()
                  .subscribe(
                    (result: any) => {
                      console.log("customers > ", result);

                      this.customers = result;
                      let customersList = this.customers.filter((item: any) => {
                        for (let id of customerIds) {
                          if (id === item.customerId) {
                            return item;
                          }
                        }
                      })
                      console.log("custoner:", customersList);
                      this.customers = customersList
                    })

              })




        }
      );


  }

  invoices() {
    const invoiceFormSubmit = {
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime(),
      issueDate :this.defaultIssueDate.getTime(),
      customers: this.selectedIds,
      includePreviousDates: this.prevDate,
      daysToPay: this.daysToPay
    }
    console.log(invoiceFormSubmit);
    this.reconcileService.invoiceWithCustomer(invoiceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("invoice > ", result);
          this.getRowData();
        })
  }

}
