import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePayAdvicesComponent } from './create-pay-advices.component';

describe('CreatePayAdvicesComponent', () => {
  let component: CreatePayAdvicesComponent;
  let fixture: ComponentFixture<CreatePayAdvicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatePayAdvicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreatePayAdvicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
