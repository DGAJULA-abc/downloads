import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-create-pay-advices',
  templateUrl: './create-pay-advices.component.html',
  styleUrls: ['./create-pay-advices.component.scss'],
})
export class CreatePayAdvicesComponent {
  constructor(private reconcileService: ReconcileService, private _formBuilder: FormBuilder) { }
  rightTitle: string = 'Create Pay Advices';
  disableCreatePayAdvice : boolean = false;
  public defaultIssueDate: Date;
  public defaultFromDate: Date;
  public defaultToDate: Date;


  public columnDefs: any[] = [
    { field: 'companyId', headerName: 'Company' },
    { field: 'companytype', headerName: 'Company Type' },
    { field: 'driverId', headerName: 'Driver' },
    {
      field: 'EffectiveDate', headerName: 'Effective Date', cellRenderer: (data: any) => {
        return moment(data.value).format('DD/MM/YY')
      }
    },
    { field: 'lineText', headerName: 'Description' },
    { field: 'loadNumber', headerName: 'Load No' },
    { field: 'payAmount', headerName: 'Amount' },
    { field: 'runsheetId', headerName: 'Runsheet' },
    { field: 'adjustmentTypeId', headerName: 'Adjustment' },
    { field: 'serviceNumber', headerName: 'ServiceNo' },


  ];

  public rowData = [];
  payAdviceForm = new FormGroup({
    issueDate: new FormControl(),
    toDate: new FormControl(),
    fromDate: new FormControl()
  });

  formattedYesterday: any;
  @Output() not: EventEmitter<string> = new EventEmitter<string>();

  ngOnInit() {
    this.not.emit(this.rightTitle);

    let yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 4);
    let fromDate = new Date()
    fromDate.setDate(fromDate.getDate() - 10);

    this.defaultIssueDate = yesterday;
    this.defaultFromDate = fromDate;
    this.defaultToDate = yesterday;

    this.getRowData();
  }

  getRowData() {
    const payAdviceFormSubmit = {
      issueDate: this.defaultIssueDate.getTime(),
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime()
    }
    this.reconcileService.createPayAdvices(payAdviceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("result complete runsheet data > ", result);

          this.rowData = result.targetPayAdviceLines
          if(!result.targetPayAdviceLines.length)
          this.disableCreatePayAdvice = true;
        }
      );


  }

  payAdvice() {
    const payAdviceFormSubmit = {
      issueDate: this.defaultIssueDate.getTime(),
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime()
    }
    this.reconcileService.payAdvice(payAdviceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("created pay advice > ", result);
          this.getRowData()
        })
  }
}
