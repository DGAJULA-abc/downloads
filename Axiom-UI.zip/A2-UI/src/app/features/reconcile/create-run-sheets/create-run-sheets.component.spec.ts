import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateRunSheetsComponent } from './create-run-sheets.component';

describe('CreateRunSheetsComponent', () => {
  let component: CreateRunSheetsComponent;
  let fixture: ComponentFixture<CreateRunSheetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateRunSheetsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateRunSheetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
