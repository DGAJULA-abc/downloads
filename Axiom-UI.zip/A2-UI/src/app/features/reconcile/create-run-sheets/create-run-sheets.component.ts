import { Component, ComponentFactoryResolver, SimpleChanges } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ReconcileService } from '../services/reconcile.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../../setup/service/setup.service';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import {
  ReasonCode,
  ReasonLine,
  Runsheet,
  RunsheetFormRequest,
  ViewRunsheetRunsheetId,
} from '../view-runsheet-form/ViewRunsheetId.model';
import * as moment from 'moment';
import { Driver } from '../models/view.reconcile.model';
import { RunsheetFormService } from '../services/runsheet-form.service';
import { RunsheetDetail } from '../detail/detail2.model';
import { Subscription } from 'rxjs';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Component({
  selector: 'app-create-run-sheets',
  templateUrl: './create-run-sheets.component.html',
  styleUrls: ['./create-run-sheets.component.scss'],
})
export class CreateRunSheetsComponent {
  items: SelectItem[];
  isNew: boolean = true;
  loadRunsheetComponent: boolean = false;
  // runsheetTypeId: SelectItem[];
  runsheetTypeId: any;
  starttimeTimesatamp: any
  endtimeTimesatamp: any;
  data: any[] = [];
  alldata: any[] = [];
  rowData: any[] = [];

  selectedItem: string | undefined;
  runsheetId: any = '';

  //type
  filteredRunsheetTypes: any[];
  runsheetsTypeId: any[] = [];
  selectedRunsheetTypeId: any[] | any;
  runsheetTypeValueDrop: any;
  runsheetTypeDropArr: any[] = [];
  runsheetOptionSelectedVal: any;

  //Driver
  filteredDriver: any[] = [];
  driverId: any[] = [];
  allDriver: any[] = [];
  selectedDriverId: any[] | any;
  driverIdRequest: any;
  driverIdVal: any;

  //Odometer\
  startkm: number;
  endkm: number;
  rateId: any;
  reconcileRunsheetInputHoldcode: any;
  serviceDetailComboboxReason: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  gridOptions: any;
  selectedReasonId: any[] | any;

  idRunsheetData: RunsheetFormRequest | any = {};

  lockUserName = '';
  editDeliverydateDate: any;

  showLookup: boolean = false;
  gridShow: boolean = false;

  columnDefs: any[] = [
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      cellRenderer: CellrenderComponent,
      filter: 'agNumberColumnFilter',
    },
    { field: 'runsheettypeid', headerName: 'Runsheet Type Id' },
    { field: 'deliverydate', headerName: 'Delivery Date' },
    { field: 'publicholidayapplies', headerName: 'Public Holiday Applies' },
    { field: 'driverid', headerName: 'Driver Id' },
    { field: 'driver', headerName: 'Driver' },
  ];

  editFormObj = {
    id: 14008010,
    locationContDropId: null,
    locationContPickupId: 123,
    locationDropId: '3000166-BACCHUS MARSH',
    locationPickupId: '1246 THOMASTOWN',
    locationReturnId: null,
    serviceId: 15441966,
    trailerId: null,
    containerId: null,
    loadTypeId: 'DELIVERY',
    trailerTagId: null,
    serviceTypeId: 'EXPORT',
    rateId: 'P500PERTRIP',
    truckId: null,
    siteId: 999,
    qty1: 44,
    unit1: 'TONNES',
    qty2: 45,
    unit2: 'HOURS',
    qty3: null,
    unit3: null,
    qty4: null,
    unit4: null,
    qty5: null,
    unit5: null,
    qty6: null,
    unit6: null,
    qty7: null,
    unit7: null,
    qty8: null,
    unit8: null,
    owntrailer: false,
    offsiderused: false,
    pickuparrivetime: 1700053200000,
    pickupdeparttime: 1700744400000,
    droparrivetime: 1699448400000,
    dropreadytime: null,
    dropdeparttime: 1700139600000,
    docket: null,
    payamt: 500,
    startkm: null,
    endkm: null,
    holdcode: null,
    payestimated: false,
    directfromdepot: false,
    remarks: 'rating component',
    nextstoptime: null,
    tripkm: 0,
    paydesc: '$500.00 (Trip $500.00)',
    pickupreadytime: null,
    dropdoctime: null,
    pickupdoctime: null,
    createdby: 'dhavaltr',
    tripno: 1,
    tripseq: 1,
    servicehours: null,
    hiretruck: false,
    globaldropbonus: null,
    deliverydate: 1699448400000,
    tripodostart: null,
    tripodoend: null,
    groupseq: null,
    tripstarttime: null,
    reasonLines: [
      {
        id: 552916,
        reasonId: '105',
        siteId: 999,
        reasoncomment: null,
        reasonrefEvent: null,
        reasonrefRunsheet: null,
        reasonrefService: null,
      },
    ],
    tripendtime: null,
    lineTemperature: null,
    runsheetLines: [
      {
        id: 14008010,
        locationContDropId: null,
        locationContPickupId: null,
        locationDropId: '3000166-BACCHUS MARSH',
        locationPickupId: '1246 THOMASTOWN',
        locationReturnId: '1246 THOMASTOWN',
        serviceId: 15441966,
        trailerId: '1234',
        containerId: null,
        loadTypeId: 'DELIVERY',
        trailerTagId: '39465-S',
        serviceTypeId: 'EXPORT',
        rateId: 'P500PERTRIP',
        truckId: 'A1SYNCTRUCK',
        siteId: 999,
        qty1: 44,
        unit1: 'TONNES',
        qty2: 45,
        unit2: 'HOURS',
        qty3: null,
        unit3: null,
        qty4: null,
        unit4: null,
        qty5: null,
        unit5: null,
        qty6: null,
        unit6: null,
        qty7: null,
        unit7: null,
        qty8: null,
        unit8: null,
        owntrailer: false,
        offsiderused: false,
        pickuparrivetime: 1700053200000,
        pickupdeparttime: 1700744400000,
        droparrivetime: 1699448400000,
        dropreadytime: null,
        dropdeparttime: 1700139600000,
        docket: null,
        payamt: 250,
        payestimated: false,
        directfromdepot: false,
        remarks: 'rating component',
        nextstoptime: null,
        tripkm: 1,
        paydesc: '$500.00 (Trip $500.00) + (2 stp x $0.00)',
        pickupreadytime: null,
        dropdoctime: null,
        pickupdoctime: null,
        createdby: 'dhavaltr',
        tripno: 1,
        tripseq: 1,
        servicehours: null,
        hiretruck: false,
        globaldropbonus: null,
        deliverydate: 1699448400000,
        tripodostart: 3,
        tripodoend: 4,
        groupseq: null,
        tripstarttime: 1698843600000,
        tripendtime: 1700053200000,
        lineTemperature: null,
        lineServiceTO: {
          serviceId: 15441966,
          dataSource: 'A2',
          created: 1699376153000,
          tripIdCust: null,
          serviceGroup: null,
          serviceDesc: null,
          customerId: '1052601',
          consignmentMasterCustomerId: '1052601',
          loadId: 13791515,
          serviceNo: 'M0083289',
          reasonId: '105',
          chargeAmt: 42.3,
          chargeDesc:
            'Point-Point-KM 84.6 X $1.00 (Incl. Return to 1246 THOMASTOWN) + (2 stp x $0.00)',
          rateId: 'ZZBEN',
          complete: false,
          loadNo: 'L0097771',
          batchNo: '3443',
          custRef: 'r45',
          scheduleDate: 1699448400000,
          despatchBy: null,
          deliveryOpen: 1698843600000,
          deliveryClose: null,
          returnLocationId: null,
          pickupLocation: {
            locationId: '1246 THOMASTOWN',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'COD ROBERT JARVIS CASH SALE',
            zonePayId: 'METRO',
            zoneChargeId: 'METRO',
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          dropLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: 'PZONEOUT3',
            zoneChargeId: 'CZONEOUT3',
            suburb: 'BACCHUS MARSH',
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: 'LOT 2 GISBORNE ROAD',
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          loadLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: null,
            zoneChargeId: null,
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          lastGroupSeq: null,
          clearCharge: false,
          totalChargeAmt: 84.6,
          svcReasonLines: [],
          dehireDeadline: null,
          vesselEta: 1699362000000,
          vesselId: 1801,
          priority: null,
          wharf: '1246- CRAIGIEBURN',
          depot: 'ASAHI ARCHERFIELD DC',
          customerSite: '3BUNNALTO-ALTONA',
          dehirePark: '1250 - ALTONA NORTH',
          originSite: 999,
          originLoc: '1246- CRAIGIEBURN',
          destinationSite: 999,
          destinationLoc: '1246 THOMASTOWN',
        },
        events: null,
        loadNoDuplicated: null,
      },
      {
        id: 14008013,
        locationContDropId: null,
        locationContPickupId: null,
        locationDropId: '3000166-BACCHUS MARSH',
        locationPickupId: '1246 THOMASTOWN',
        locationReturnId: '1246 THOMASTOWN',
        serviceId: 15442239,
        trailerId: '1234',
        containerId: null,
        loadTypeId: 'DELIVERY',
        trailerTagId: '39465-S',
        serviceTypeId: 'DEMURRAGE',
        rateId: 'P500PERTRIP',
        truckId: 'A1SYNCTRUCK',
        siteId: 999,
        qty1: null,
        unit1: null,
        qty2: null,
        unit2: null,
        qty3: null,
        unit3: null,
        qty4: null,
        unit4: null,
        qty5: null,
        unit5: null,
        qty6: null,
        unit6: null,
        qty7: null,
        unit7: null,
        qty8: null,
        unit8: null,
        owntrailer: false,
        offsiderused: false,
        pickuparrivetime: 1700053200000,
        pickupdeparttime: 1700744400000,
        droparrivetime: 1699448400000,
        dropreadytime: null,
        dropdeparttime: 1700139600000,
        docket: null,
        payamt: 250,
        payestimated: false,
        directfromdepot: false,
        remarks: 'rating component',
        nextstoptime: null,
        tripkm: 0,
        paydesc: '$500.00 (Trip $500.00) + (2 stp x $0.00)',
        pickupreadytime: null,
        dropdoctime: null,
        pickupdoctime: null,
        createdby: 'dhavaltr',
        tripno: 1,
        tripseq: 2,
        servicehours: null,
        hiretruck: false,
        globaldropbonus: null,
        deliverydate: 1699448400000,
        tripodostart: null,
        tripodoend: null,
        groupseq: null,
        tripstarttime: 1698843600000,
        tripendtime: 1700053200000,
        lineTemperature: null,
        lineServiceTO: {
          serviceId: 15442239,
          dataSource: 'RS',
          created: 1699891064000,
          tripIdCust: null,
          serviceGroup: null,
          serviceDesc: null,
          customerId: '1052601',
          consignmentMasterCustomerId: '1052601',
          loadId: 13791515,
          serviceNo: 'M0083542',
          reasonId: '105',
          chargeAmt: 42.3,
          chargeDesc:
            'Point-Point-KM 84.6 X $1.00 (Incl. Return to 1246 THOMASTOWN) + (2 stp x $0.00)',
          rateId: 'ZZBEN',
          complete: false,
          loadNo: 'L0097771',
          batchNo: '3443',
          custRef: 'r45',
          scheduleDate: 1699448400000,
          despatchBy: null,
          deliveryOpen: 1698843600000,
          deliveryClose: null,
          returnLocationId: null,
          pickupLocation: {
            locationId: '1246 THOMASTOWN',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'COD ROBERT JARVIS CASH SALE',
            zonePayId: 'METRO',
            zoneChargeId: 'METRO',
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          dropLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: 'PZONEOUT3',
            zoneChargeId: 'CZONEOUT3',
            suburb: 'BACCHUS MARSH',
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: 'LOT 2 GISBORNE ROAD',
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          loadLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: null,
            zoneChargeId: null,
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          lastGroupSeq: null,
          clearCharge: false,
          totalChargeAmt: 84.6,
          svcReasonLines: [],
          dehireDeadline: null,
          vesselEta: 1699362000000,
          vesselId: 1801,
          priority: null,
          wharf: '1246- CRAIGIEBURN',
          depot: 'ASAHI ARCHERFIELD DC',
          customerSite: '3BUNNALTO-ALTONA',
          dehirePark: '1250 - ALTONA NORTH',
          originSite: 999,
          originLoc: '1246- CRAIGIEBURN',
          destinationSite: 999,
          destinationLoc: '1246 THOMASTOWN',
        },
        events: null,
        loadNoDuplicated: null,
      },
    ],
    events: [],
  };

  runsheetLines = [];
  serviceFormReceivedData: any = {};
  loadFormReceivedData: any = {};
  containerFormReceivedData: any = {};
  subscription: Subscription;

  runsheetDetailLIneFormObj = {};
  loadLocationFormObj = {};
  containerFormObj = {};
  breakFormObj = {};
  ratingFormObj = {};
  runsheetLinesObj: any[]= [];
  constructor(
    private reconsileService: ReconcileService,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router,
    private runsheetFormService: RunsheetFormService,
    public navbarService: NavbarService
  ) { }

  reconcileFormCreateRunsheet = this.fb.group({
    runsheetTypeId: ['', Validators.required],
    driverId: ['', Validators.required],
    starttime: ['', Validators.required],
    endtime: ['', Validators.required],
    returndepottime: ['', Validators.required],
    startkm: ['', Validators.required],
    endkm: ['', Validators.required],
    remarks: ['', Validators.required],
    holdcode: ['', Validators.required],
    reasonId: ['', Validators.required],
    serviceDetailComboboxReason: ['', Validators.required],
    driverBreaks: [],
    payAdviceLines: [],
    invoiceLines: [],
    reasonLines: [],
    runsheetLines: this.fb.group({
      lineServiceTO: this.fb.group({
        dropLocation: this.fb.group({}),
        loadLocation: this.fb.group({}),
        pickupLocation: this.fb.group({}),
      }),
    }),
  });

  ngOnInit() {
    this.subscription = this.runsheetFormService.formData$.subscribe((data) => {
      this.serviceFormReceivedData = data.value;
    })
    this.subscription = this.runsheetFormService.loadFormData$.subscribe((data) => {
      this.loadFormReceivedData = data.value;
      //console.log("service data:", this.receivedData)
    })
    this.subscription = this.runsheetFormService.containerFormData$.subscribe((data) => {
      this.containerFormReceivedData = data.value;
      //console.log("service data:", this.receivedData)
    });
    setInterval(() => {
      this.renewLocks();
    }, 5000)
    this.getRunsheetTypes();
    this.getDriver();
    this.getReasonCode();
  }

  renewLocks() {
    this.reconsileService.renew().subscribe((response) => { })
  }

  runshheetMode(id: any) {
    this.reconsileService.showErrors(id, null).subscribe((renewLockData: any) => {
      // console.log('renewLocks >>', renewLockData);
    });

    this.reconsileService.lockRunsheet(id).subscribe((renewLockData: any) => {
      // console.log('renewLocks >>', renewLockData);
    });
  }

  reconcileFormCreateRunsheetSubmit() {
    const formRunsheet = this.reconcileFormCreateRunsheet.value;
    // driverIDCreate =
    const driverIdCrea = Number(formRunsheet.driverId?.split('-')[0]);
    const realFormData = {
      runsheetTypeId: 'PALLET',
      driverId: 10283,
      starttime: 1700571600000,
      endtime: 1700600400000,
      returndepottime: 1700600400000,
      startkm: 3443,
      endkm: 4545,
      holdcode: "User: 3434",
      remarks: formRunsheet.remarks,
    };


    if((Object.keys(this.serviceFormReceivedData).length===0) && (Object.keys(this.loadFormReceivedData).length ===0) && (Object.keys(this.containerFormReceivedData).length===0)){
      this.runsheetLinesObj =[];
    }else{
     this.runsheetLinesObj = [{
      "id": null,
      "lineServiceTO": {
        "svcReasonLines": [],
        "loadNo": null,
        "loadId": null,
        "originSite": this.navbarService.selectedSiteId,
        "destinationSite": this.navbarService.selectedSiteId,
        "customerId": this.serviceFormReceivedData.customerId,
        "pickupLocation": {
          "locationDesc": null,
          "zoneChargeId": null,
          "zonePayId": null
        },
        "dropLocation": {
          "locationDesc": null,
          "zoneChargeId": null,
          "zonePayId": null
        },
        "loadLocation": {
          "locationDesc": null
        },
        "serviceGroup": null
      },
      "truckId": "PPXRIGID",
      "trailerId": null,
      "tripno": 1,
      "loadTypeId": this.loadFormReceivedData.laodTypeId,
      "serviceTypeId": this.serviceFormReceivedData.serviceTypeId,
      "qty1": null,
      "qty2": null,
      "qty3": null,
      "qty4": null,
      "qty5": null,
      "qty6": null,
      "qty7": null,
      "qty8": null,
      "events": [],
      "unit1": null,
      "unit2": null,
      "unit3": null,
      "unit4": null,
      "unit5": null,
      "unit6": null,
      "unit7": null,
      "unit8": null,
      "tripseq": 1,
      "deliverydate": 1701262800000,
      "siteId": 999,
      "lineTemperature": null,
      "hiretruck": false,
      "owntrailer": false,
      "offsiderused": false,
      "directfromdepot": false,
      "payestimated": false
    }]
  }


    console.log("forms:", this.serviceFormReceivedData, this.loadFormReceivedData, this.containerFormReceivedData)
    const runsheetIdFormVal = {
      id: this.idRunsheetData.id,
      rateId: this.idRunsheetData.rateId,
      truckId: this.idRunsheetData.truckId,
      siteId: this.idRunsheetData.siteId,
      deliverydate: this.idRunsheetData.deliverydate,
      publicholidayapplies: this.idRunsheetData.publicholidayapplies,
      cashshortage: this.idRunsheetData.cashshortage,
      stockshortage: this.idRunsheetData.stockshortage,
      calcpaybyload: this.idRunsheetData.calcpaybyload,
      calcpaybyhour: this.idRunsheetData.calcpaybyhour,
      payamt: this.idRunsheetData.payamt,
      payhourly: this.idRunsheetData.payhourly,
      payincentive: this.idRunsheetData.payincentive,
      payallowance: this.idRunsheetData.payallowance,
      hoursnormal: this.idRunsheetData.hoursnormal,

      hoursthalf: this.idRunsheetData.hoursthalf,
      hoursdouble: this.idRunsheetData.hoursdouble,
      shiftrate: this.idRunsheetData.shiftrate,
      shifthours: this.idRunsheetData.shifthours,
      shiftamt: this.idRunsheetData.shiftamt,
      complete: this.idRunsheetData.complete,
      createdby: this.idRunsheetData.createdby,

      paydesc: this.idRunsheetData.paydesc,
      exported: this.idRunsheetData.exported,
      odokm: this.idRunsheetData.odokm,
      gpskm: this.idRunsheetData.gpskm,
      eventgenerated: this.idRunsheetData.eventgenerated,
      globaldropbonus: this.idRunsheetData.globaldropbonus,
      created: this.idRunsheetData.created,
      shiftUUID: this.idRunsheetData.shiftUUID,
      invoiceLines: this.idRunsheetData.invoiceLines,
      payAdviceLines: this.idRunsheetData.payAdviceLines,
      reasonLines: this.idRunsheetData.reasonLines,
      runsheetLines: this.runsheetLinesObj,
      shiftId: this.idRunsheetData.shiftId,
      driverBreaks: this.idRunsheetData.driverBreaks


    };
    const runsheetFormMerge = { ...runsheetIdFormVal, ...realFormData };

    this.runsheetFormService.runSheetFormSubject.next(runsheetFormMerge);
    this.submitRunsheetForm(runsheetFormMerge);
  }

  submitRunsheetForm(runsheetFormMerge: any) {

    this.runshheetMode(this.runsheetId);
    this.reconsileService
      .viewRunsheetSubmit(runsheetFormMerge)
      .subscribe((resRunsheetSubmit: any) => {
        console.log('resRunsheetSubmit >>', resRunsheetSubmit);
      });
  }

  getRunseetIdData(runsheetId: any) {
    this.reconsileService
      .getViewRunsheetId(runsheetId)
      .subscribe((resRunsheet: ViewRunsheetRunsheetId) => {
        this.isNew = resRunsheet.isNew;
        if (this.isNew) {
          this.router.navigate(['reconcile/CreateRunsheet']);
        }
        this.idRunsheetData = resRunsheet.runsheet;
        console.log('runsheetId data >>>>', resRunsheet);
        this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;
        this.driverIdVal = resRunsheet.runsheet.driverId;
        this.runsheetsTypeId.filter((filterId: any) => {
          if (filterId === this.runsheetTypeId) {
            this.selectedRunsheetTypeId = filterId;
          }
        });

        this.reconsileService.lockRunsheet(runsheetId).subscribe(
          (renewLockData: any) => {
            // console.log('LockRunsheet>>', renewLockData);
          },
          (err: any) => {
            // console.log('Runsheet Error', err);
          }
        );

        this.allDriver.map((filterDriver: any) => {
          // console.log("filterDriver >> ", filterDriver);
          if (filterDriver.id === resRunsheet.runsheet.driverId) {
            // console.log('driverId >>', filterDriver);
            this.selectedDriverId =
              this.reconsileService.getDriverDropProperVal(filterDriver);
          }
        });
        // this.selectedReasonId  = '112_Dhaval';
        this.reasonCode.filter((reasonCode: ReasonLine) => {
          if (reasonCode.id === this.editFormObj.reasonLines[0].id) {
            this.selectedReasonId =
              this.reconsileService.getReasonIdVal(reasonCode);
          }
        });
        //odometer
        this.editFormObj.startkm = resRunsheet.runsheet.startkm;
        this.editFormObj.endkm = resRunsheet.runsheet.endkm;
        this.editFormObj.rateId = resRunsheet.runsheet.rateId;
        this.editFormObj.holdcode = resRunsheet.runsheet.holdcode;
        this.editFormObj.remarks = resRunsheet.runsheet.remarks;

        // const deliveyDateVal =  moment(resRunsheet.runsheet.deliverydate).format("dddd, MMMM Do, YYYY h:mm A");
        // this.editDeliverydateDate = moment.unix(resRunsheet.runsheet.deliverydate).format("MM/DD/YYYY")
        // this.editFormObj.deliverydate = moment.unix(resRunsheet.runsheet.deliverydate).format("MM/DD/YYYY");
        const tmpDate = moment(resRunsheet.runsheet.deliverydate).format(
          'YYYY.MM.DD HH:MM:SS'
        );
        this.editDeliverydateDate = new Date(tmpDate).toLocaleDateString();

        this.editFormObj.runsheetLines.map((resRunsheetLine: any) => {
          console.log('resRunsheetLine >>', resRunsheetLine);
        });
      });
  }

  getMetaDataJson() {
    this.reconsileService.getMetaDataJson().subscribe((fieldssData: any) => {
      // console.log('FieldsData >', fieldssData);
    });
  }

  //dropdown type

  // runsheet Type
  filteredRunsheetTypesFun(event: any) {
    let runsheetTypeArr: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.runsheetsTypeId.length; i++) {
      // console.log("runsheetsTypeId >", this.runsheetsTypeId);

      let runsheetType = this.runsheetsTypeId[i];
      if (runsheetType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        runsheetTypeArr.push(runsheetType);
      }
    }

    this.filteredRunsheetTypes = runsheetTypeArr;
  }

  //onchange type
  onChangeRunsheetType(runsheetValue: any) {
    // console.log('runsheetValue >', runsheetValue);
    this.selectedRunsheetTypeId = runsheetValue;
    this.runsheetTypeValueDrop = runsheetValue;
    // console.log("filteredRunsheetTypes mm> ", this.filteredRunsheetTypes);

    this.runsheetTypeDropArr.filter((runsheetSecectedData: any) => {
      if (runsheetSecectedData.runsheetsTypeId === runsheetValue) {
        // console.log('runsheetSecectedData', runsheetSecectedData);
        this.runsheetOptionSelectedVal = runsheetSecectedData;
      }
    });
  }

  getRunsheetTypes() {
    this.reconsileService.getRunsheetTypes().subscribe((runsheetTypes: any) => {
      runsheetTypes.map((runsheetType: any) => {
        //  console.log("getRunsheetTypes >>", adjustData);
        this.runsheetTypeDropArr = runsheetTypes;
        this.runsheetsTypeId.push(runsheetType.runsheetTypeId);
      });
    });
  }

  // Driver

  getDriver() {
    this.reconsileService.getDriver().subscribe((drivers: any) => {
      // console.log('driversList >>', drivers);
      this.allDriver = drivers;
      drivers.map((driver: Driver) => {
        const driverDropVal =
          this.reconsileService.getDriverDropProperVal(driver);
        // console.log('driverDropVal', driverDropVal);

        this.driverId.push(driverDropVal);
      });
    });
  }

  filteredDriverFn(event: any) {
    let driverArr: any[] = [];
    let query = event.query;
    this.driverId.map((driver: any) => {
      const driverIdSeperate = driver.split('-')[0];
      if (driverIdSeperate.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        driverArr.push(driver);
      }
    });
    this.filteredDriver = driverArr;
  }

  onChangeDriver(selectedDriver: any) {
    const driverId = selectedDriver.split('-')[0];
    this.selectedDriverId = selectedDriver.split('-')[0];
    const starttime = this.reconcileFormCreateRunsheet.get('starttime')?.value;
    this.starttimeTimesatamp = +moment(starttime, 'YYYY-MM-DD[T]HH:mm:ss').format(
      'x'
    );


    const request = {
      driverId: driverId,
      shiftSTartDate: this.starttimeTimesatamp,
    };

    this.getShiftDetails(request)

  }

  getShiftDetails(request: any) {
    this.reconsileService
      .getShiftDetails(request)
      .subscribe((shiftData: any) => {
        console.log('shiftData >>', shiftData);
        this.showLookup = true;
      });
  }


  lookUp() {
    const endtime = this.reconcileFormCreateRunsheet.get('endtime')?.value;
    this.endtimeTimesatamp = +moment(endtime, 'YYYY-MM-DD[T]HH:mm:ss').format(
      'x'
    );

    const starttime = this.reconcileFormCreateRunsheet.get('starttime')?.value;
    this.starttimeTimesatamp = +moment(endtime, 'YYYY-MM-DD[T]HH:mm:ss').format(
      'x'
    );

    let request = {
      driverId: this.selectedDriverId,
      from: this.starttimeTimesatamp,
      shiftId: null,
      to: this.endtimeTimesatamp,
      type: this.selectedRunsheetTypeId
    }

    this.showLookup = false;
    this.gridShow = true;

    this.reconsileService
      .lookUp(request)
      .subscribe((response: any) => {
        console.log('response >>', response);
        this.runsheetId = response.runsheet.id;
        this.getRunseetIdData(this.runsheetId);
        //this.loadRunsheetComponent = true;
        // this.router.navigate(
        //   ['reconcile/ViewRunsheet'], 
        //   {
        //     queryParams: { runsheetId: runsheetId },
        //     queryParamsHandling: 'merge'
        //   })
      });
  }



  //reason code
  getReasonCode() {
    this.reconsileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: ReasonCode) => {
        if (reasonDrop.reasonDescription !== null) {
          const reasonCodeFormat =
            this.reconsileService.getReasonIdVal(reasonDrop);

          this.reasonCode.push(reasonCodeFormat);
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((reason: any) => {
      const resonId = reason.split('-')[0];

      if (resonId.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        reasonArr.push(resonId);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    // console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  reload() {
    window.location.reload();
  }
}
