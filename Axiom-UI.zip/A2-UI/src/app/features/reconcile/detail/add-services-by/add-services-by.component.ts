import { Component } from '@angular/core';

@Component({
  selector: 'app-add-services-by',
  templateUrl: './add-services-by.component.html',
  styleUrls: ['./add-services-by.component.scss']
})
export class AddServicesByComponent {

}
