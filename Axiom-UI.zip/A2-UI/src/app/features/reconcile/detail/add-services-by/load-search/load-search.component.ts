import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridOptions,
  RowNode
} from 'ag-grid-community';

import { pagination } from 'src/app/shared/model/shared.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { MatDialog } from '@angular/material/dialog';
import { Services } from 'src/app/features/search/model/search.model';
import { SearchService } from 'src/app/features/search/services/search.service';
import { DeleteInvoiceLinesComponent } from 'src/app/features/search/delete-invoice-lines/delete-invoice-lines.component';
import { ReconcileService } from '../../../services/reconcile.service';

@Component({
  selector: 'app-load-search',
  templateUrl: './load-search.component.html',
  styleUrls: ['./load-search.component.scss']
})
export class LoadSearchComponent {

  public columnDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable:false,
      pinned: 'left'
    },
     {
      field: 'loadNo',
      headerName: 'Load No',
      type: 'TEXT'
    }, {
      field: 'scheduledDate',
      headerName: 'Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'loadType',
      headerName: 'Load',
      type: 'TEXT'
    }, {
      field: '',
      headerName: 'ConNot',
      type: 'TEXT',
    },
    {
      field: 'custRef',
      headerName: 'Hello',
      type: 'TEXT',
    }, 
     {
      field: 'enteredBy',
      headerName: 'Enterred By',
      type: 'TEXT'
    },
    {
      field: 'customer',
      headerName: 'Customer',
      type: 'TEXT'
    },  
    {
      field: 'location',
      headerName: 'Location',
      type: 'TEXT'
    }
  ];
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true,
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: Services | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "serviceid"
  }
  selectedServices: any;

  totalRecords: number = 0;
  canDelete: boolean = false;
  searchForm: any;
  setupPermission: Permissions;
  gridOptions: GridOptions;

  constructor(
    private reconsileService: ReconcileService,
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog
  ) { 
    this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      }
    }
  }

  ngOnInit(): void {
    this.searchViewDetails();
    //this.getSearchLoads();
    let requestParam = {
      from: 1699534800000,
      to: 1699794000000,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'ASC',
        orderByField: 'scheduledDate',
      },
    };
    this.ServiceList(requestParam);
  }


  searchViewDetails() {
    this.searchServices.getSearchView()
      .subscribe(
        (result: any) => {
          this.setupPermission = result.permissions.sitePermissions[0].permissions;
          
          // this.rowData = result;
        }
      );
  }
  canRead() {

  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.ServiceList(event);
  }

  ServiceList(event: any) {
    this.searchForm = event;
    console.log(this.searchForm);
    this.searchServices.getSearchLoads(event).subscribe((result: any) => {
      this.rowData = result.loads;
      console.log("rowdata load search:",this.rowData);
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
    });
  }

  onSelectionChanged(event: any) {
    console.log("selected", event.api.getSelectedNodes()[0].data)
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
      let requestParam = {
        id: 13791514,
        tripNo: 4
      }
      let id = 3045835;
      this.searchServices.postLoads(requestParam, id).subscribe((result: any) => {

      })
    }
    this.selectedServices = event.api.getSelectedNodes().map((rowNode: any) => {
      return rowNode.data;
    });
    this.canDelete = this.selectedServices.filter((services: any) => services.used).length > 0 ? true : false;
  }

  onTabSelectToggle(event: any) {
    console.log(event);
  }

  runshheetMode(id: any) {
    // this.reconsileService.showErrors(id,).subscribe((renewLockData: any) => {
    //   // console.log('renewLocks >>', renewLockData);
    // });

    // this.reconsileService.renewLocks(id).subscribe((renewLockData: any) => {
    //   // console.log('renewLocks >>', renewLockData);
    // });
  }

  downloadCSVServices() {
    let selectedFields
    if (this.tableGridChnages) {
      selectedFields = this.columnDefs.map((column) => column.field);
    }
    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices.downLoadCSVService(downloadCSVRequestBody).subscribe(result => {
      if (result) {
        this.sharedDervice.downloadCSV(result, 'Search.Service.csv');
      }
    });
  }

  deleteServices() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result == true) {
        let data: any[] = [];
        let deletableServices = this.selectedServices.filter((services: any) => !services.used);
        if (deletableServices) {
          deletableServices.map((service: any) => {
            data.push(service.id);
          });
          this.searchServices.deleteServices(data).subscribe((result: any) => {
            this.ServiceList(this.searchForm);
            this.editForm = null;
          });
        }
      }
    });
  }

  addTripRunsheet() {
    
  }
  
}

