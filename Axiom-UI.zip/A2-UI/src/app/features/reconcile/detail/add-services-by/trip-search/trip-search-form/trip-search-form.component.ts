import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-trip-search-form',
  templateUrl: './trip-search-form.component.html',
  styleUrls: ['./trip-search-form.component.scss']
})
export class TripSearchFormComponent {
  @Output() searchDetails = new EventEmitter<any>();
  tripForm: FormGroup;
  currentTime: Date = new Date();
  previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
  drivers: { id: any, name: string }[] = [];
  truckId: { id: any, name: string }[] = [];
  trailer: { id: any, name: string }[] = [];
  routes: { id: any, name: string }[] = [];
  locations: { id: any, name: string }[] = [];
  searchForm: any;
  constructor(
      private shareServices: SharedService,
      private fb: FormBuilder
  ) {
      this.tripForm = this.fb.group({
          tripIdCust: new FormControl(''),
          driverId: new FormControl(''),
          truckId: new FormControl(''),
          trailerId: new FormControl(''),
          routeId: new FormControl(''),
          tripDateFrom: new FormControl(''),
          tripDateTo: new FormControl(''),
          despatchFrom: new FormControl(''),
          returnTo: new FormControl(''),
      });
  }
  ngOnInit() {
      this.searchViewDetails();
  }

  searchViewDetails() {
      this.shareServices.getContextView().subscribe(
          (result: any) => {
              this.drivers = this.shareServices.getDriverList(result.ref.drivers);
              this.truckId = this.shareServices.getTruckList(result.ref.trucks);
              this.trailer = this.shareServices.getTrailerList(result.ref.trailers);
              result.ref.routes.map((route: any)=> {
                  if (route.active)
                  this.routes.push({id: route.routeId, name: route.routeId});
              });
              result.ref.locations.map((location: any)=> {
                  if (location.active) {
                      let loactionName = [location.locationId, location.accShortCut ?  " ( " + location.accShortCut + " )" : ''].filter(function (val) {
                          return val;
                      }).join(' ');
                      this.locations.push({id: loactionName , name: loactionName});
                  }
              });
              console.log(this.truckId,
                  this.trailer,
                  this.routes,
                  this.locations);
              this.searchForm = this.getSearchFormFields();
          }
      );
  }

  getSearchFormFields() {
      console.log("testing");
      this.searchForm = {
          displayName: 'Trips',
          name: 'Search.Trips',
          endpoint: '/search/trip/',
          fields: [{
              name: 'tripIdCust',
              displayName: 'Trip No.',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              type: 'TEXT'
          }, 
          
          // {
          //     name: 'truckId',
          //     displayName: 'Truck Id',
          //     required: false,
          //     readonly: false,
          //     hidden: false,
          //     updatable: true,
          //     defaultValue: null,
          //     dropDownList: this.truckId,
          //     reference: 'trucks',
          //     type: 'REFERENCE'
          // },
          //  {
          //     name: 'trailerId',
          //     displayName: 'Trailer Id',
          //     required: false,
          //     readonly: false,
          //     hidden: false,
          //     updatable: true,
          //     defaultValue: null,
          //     dropDownList: this.trailer,
          //     reference: 'trailers',
          //     type: 'REFERENCE'
          // }, 
          
          {
              name: 'tripDateFrom',
              displayName: 'Trip Date From',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.previousDate,
              type: 'DATE'
          }, {
              name: 'tripDateTo',
              displayName: 'Trip Date To',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.currentTime,
              type: 'DATE'
          }, {
              name: 'despatchFrom',
              displayName: 'Despatch From',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              dropDownList: this.locations,
              reference: 'locations',
              type: 'REFERENCE'
          }, 
          {
              name: 'routeId',
              displayName: 'Route Id',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              dropDownList: this.routes,
              reference: 'routes',
              type: 'REFERENCE'
          }, 
          // {
          //     name: 'returnTo',
          //     displayName: 'Return To',
          //     required: false,
          //     readonly: false,
          //     hidden: false,
          //     updatable: true,
          //     defaultValue: null,
          //     dropDownList: this.locations,
          //     reference: 'locations',
          //     type: 'REFERENCE'
          // }
        ]
      };
      console.log("testing", this.searchForm);
      return this.searchForm;
  }

  updateValue(controlName: string, newValue: any) {
      this.tripForm.get(controlName)?.setValue(newValue);
      console.log(this.tripForm.value, controlName, newValue);
  }

  onSubmit() {
      let formValues = this.tripForm.value;
      if (formValues.tripDateFrom) {
          formValues.tripDateFrom = formValues.tripDateFrom.getTime();
      }
      if (formValues.tripDateTo) {
          formValues.tripDateTo = formValues.tripDateTo.getTime();
      }
      Object.keys(formValues).forEach((key) => {
          if (!formValues[key]) delete formValues[key];
      });
      this.searchDetails.emit(formValues);
      console.log(formValues);
  }
 
  addTripRunsheet() {
    
  }
}


