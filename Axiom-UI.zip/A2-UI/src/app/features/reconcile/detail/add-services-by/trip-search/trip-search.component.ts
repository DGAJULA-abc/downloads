import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridOptions,
  RowNode
} from 'ag-grid-community';

import { Driver, pagination } from 'src/app/shared/model/shared.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { MatDialog } from '@angular/material/dialog';
import { Services } from 'src/app/features/search/model/search.model';
import { ServiceDateCycle, TripDateCycle } from 'src/app/features/plan/models/plan.model';
import { SearchService } from 'src/app/features/search/services/search.service';

@Component({
  selector: 'app-trip-search',
  templateUrl: './trip-search.component.html',
  styleUrls: ['./trip-search.component.scss']
})
export class TripSearchComponent {

  public columnDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left'
    },
    {
      field: 'id',
      headerName: 'Id',
      type: 'TEXT'
    }, {
      field: 'tripid_cust',
      headerName: 'Trip No.',
      type: 'TEXT'
    }, {
      field: 'tripdate',
      headerName: 'Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'cachedstatus',
      headerName: 'Cached Status',
      type: 'TEXT'
    }, {
      field: 'driver',
      headerName: 'Driver',
      type: 'TEXT'
    }, {
      field: 'truckid',
      headerName: 'Truck',
      type: 'TEXT'
    }, {
      field: 'trailerid',
      headerName: 'Trailer',
      type: 'TEXT'
    }, {
      field: 'trailerid_tag',
      headerName: 'Trailer Tag',
      type: 'TEXT'
    }, {
      field: 'routeid',
      headerName: 'Route',
      type: 'TEXT'
    }, {
      field: 'planneddespatchtime',
      headerName: 'Planned Despatch Time',
      type: 'DATETIME',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'plannedstarttime',
      headerName: 'Planned Start Time',
      type: 'DATETIME',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'plannedfinishtime',
      headerName: 'Planned End Time',
      type: 'DATETIME',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'locationid_despatch',
      headerName: 'Location Despatch',
      type: 'TEXT'
    }, {
      field: 'locationid_return',
      headerName: 'Location Return',
      type: 'TEXT'
    }, {
      field: 'tripcomplete',
      headerName: 'Trip Complete',
      type: 'BOOLEAN',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
    }, {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'TEXT'
    }, {
      field: 'enteredby',
      headerName: 'Entered By',
      type: 'TEXT'
    }, {
      field: 'firstname',
      headerName: 'Firstname',
      type: 'TEXT'
    }, {
      field: 'lastname',
      headerName: 'Lastname',
      type: 'TEXT'
    }, {
      field: 'employeename',
      headerName: 'Employee Name',
      type: 'TEXT'
    }, {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'TEXT'
    }
  ];
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: TripDateCycle | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "id"
  }
  selectedTrip: any;
  selectedServices: ServiceDateCycle[];
  selectedTripService: any;
  totalRecords: number = 0;
  drivers: Driver;
  constructor(
    private searchServices: SearchService,
    private sharedService: SharedService
  ) { }

  ngOnInit(): void {
    let requestParam = {
      from: 1699448400000,
      to: 1699448400000,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'ASC',
        orderByField: 'scheduledDate',
      },
    };
    this.tripsList(requestParam);
    // this.searchViewDetails();
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.tripsList(event);
  }

  tripsList(event: any) {
    console.log(event);
    this.searchServices.getSearchTrips(event).subscribe((result: any) => {
      this.rowData = result.trips;
      this.pagination.pageNumber = result.pagination.currentPage !=0 ? result.pagination.currentPage: 1;
      this.totalRecords = result.pagination.totalRecords;
      console.log("rowdata trips:", this.rowData)
    });
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data
      this.selectedTripANdServicesList(this.editForm!.id);
    }
    // this.selectedTrip = event.api.getSelectedNodes();
  }

  selectedTripANdServicesList(tripid: number) {
    this.sharedService.getTripDetailsByid(tripid).subscribe(result => {
      this.selectedTrip = result.trips;
      if (this.selectedTrip.serviceIds) {
        this.selectedTrip.serviceIds.map((serviceId: number) => {
          this.sharedService.getServiceDetailsByid(serviceId).subscribe(result => {
            this.selectedServices.push(result);
          })
        })
      }
    })
  }
  onTabSelectToggle(event: any) {
    console.log(event);

  }

  downloadCSVTrips() {
    let selectedFields
    if (this.tableGridChnages) {
      selectedFields = this.columnDefs.map((column) => column.field);
    }
    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices.downLoadCSVService(downloadCSVRequestBody).subscribe((result: any) => {
      if (result) {
        this.sharedService.downloadCSV(result, 'Search.Service.csv');
      }
    });
  }

  addTripRunsheet() {
    
  }
}
