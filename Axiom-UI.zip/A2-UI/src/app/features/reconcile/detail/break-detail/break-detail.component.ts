import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ReconcileService } from '../../services/reconcile.service';
import { BreakType, Location } from '../detail.model';
import { RunsheetFormService } from '../../services/runsheet-form.service';

@Component({
  selector: 'app-break-detail',
  templateUrl: './break-detail.component.html',
  styleUrls: ['./break-detail.component.scss']
})
export class BreakDetailComponent {
  isNew: true;

   // Truck
   breakTypeId: any[] = [];
   filteredBreakType: any[] = [];
   selectedBreakType: any;

   //autocomplete for locationIds
 locationIds: any[] = [];
 selectedLocation: any;
 filteredLocations: any[];
 location_arr: any[] = [];

  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    private runsheetFormService: RunsheetFormService
  ) {}

  ngOnInit() {
    this.getTrucks();
    this.getLocationIds();
    this.getLoadDetailForm();
  }

  breakDetailForm = this.fb.group({
    breakTypeId: ['', Validators.required],
    locationId: ['', Validators.required],
    breakstarttime: ['', Validators.required],
    breakendtime: ['', Validators.required],
    commentA: ['', Validators.required],

  })
  
  getLoadDetailForm() {
    this.breakDetailForm.valueChanges.subscribe(res => {
      console.log(this.breakDetailForm.getRawValue());
      this.runsheetFormService.runsheetBreakForm = this.breakDetailForm.getRawValue();
    })
  }

   // Truck Type
 getTrucks() {
  this.reconcileService
    .getBreakType()
    .subscribe((breakType: any) => {
      console.log('breakTypeId line> ', breakType);
      breakType.map((breakType: BreakType) => {
       this.breakTypeId.push(breakType);
     });
    });
}

filteredTruckFun(event: any) {
  let breakArr: any[] = [];
  let query = event.query;
  // console.log("this.customerId >", this.customerId);
  this.breakTypeId.map((breakType: BreakType) => {
    if (
      breakType.typeId.toLowerCase().indexOf(query.toLowerCase()) ==
      0
    ) {
    // const truckName = `${truck.truckId} , (${truck.routeCapacity} , ${truck.companyId})`;
    breakArr.push(breakType.typeId);
    }
  });
  this.filteredBreakType = breakArr;
}

onChangeTruck(event: any) {}


// location
getLocationIds() {
  this.reconcileService.getLocation().subscribe((locations: any) => {
    // console.log('getReasonCode >> ', reasonCodes);
    locations.map((location: Location) => {
      if (location.locationId !== null) {
        this.location_arr.push(location.locationId);
      }
    });
    // console.log('reasonCode >>', this.reasonCode);
  });
}
filteredLoactionFun(event: any) {
  let locationIdArr: any[] = [];
  let query = event.query;
  this.location_arr.map((location: any) => {
    if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      locationIdArr.push(location);
    }
  });
  this.filteredLocations = locationIdArr;
}

onChangeLocation(event: any) {}
}


