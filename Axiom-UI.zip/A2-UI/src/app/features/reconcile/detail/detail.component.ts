import { Component } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';
import { RunsheetDetail } from './detail2.model';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent {
  selectedItemType: any;
  isDetailShow: boolean = true;

  constructor(private reconcileService: ReconcileService) {}

  ngOnInit() {
    this._setDetailScreen();
    this.getMultiLegData();
  }

  _setDetailScreen() {
    this.reconcileService.selectedItemType.subscribe((res) => {

      console.log('selectedItemType >>', res);

      this.selectedItemType = res;
    });
  }

  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe((runsheet: RunsheetDetail) => { 
      console.log("Runsheet  details _multiLangData show>> ", runsheet);
      if(runsheet) {
          this.selectedItemType = "runsheet-line";
      }
        
    })
  }

  onCloseDetail() {
    // this.isDetailShow = false;
  }
}
