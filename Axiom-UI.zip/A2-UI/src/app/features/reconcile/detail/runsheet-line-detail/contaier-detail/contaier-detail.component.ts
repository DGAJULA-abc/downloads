import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AddContainerDialogComponent } from 'src/app/features/plan/plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { ReconcileService } from '../../../services/reconcile.service';
import { MatDialog } from '@angular/material/dialog';
import { ServiceType } from '../runsheet-service-detail/runsheet-service-detail.model';
import { Location, Site, Vessel } from '../../detail.model';
import { OriginLoc, RunsheetDetail } from '../../detail2.model';
import { customers } from 'src/app/features/setup/models/setup.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';

@Component({
  selector: 'app-contaier-detail',
  templateUrl: './contaier-detail.component.html',
  styleUrls: ['./contaier-detail.component.scss'],
})
export class ContaierDetailComponent {
  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // customer name
  selectedCustomerName: any[] | any;
  customerName: any[] = [];
  filteredCustomersName: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];

  batchNo: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  addbutton = true;

  //vessel
  vesselId: any[] = [];
  filteredVessel: any[] = [];
  vessel: any[] = [];
  selectedVesselId: any[] | any;
  //  allReasonCode: any[] = [];
  //  reasonCodeUnique: any[] = [];
  //  addbutton=true;

  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];

  //autocomplete for Wharf
  selectedWharf: any;
  filteredWharf: any[];
  wharf_arr: any[] = [];
  wharf: any[] = [];

  //autocomplete for Depot
  selectedDepot: any;
  filteredDepot: any[];
  depot_arr: any[] = [];
  depot: any[] = [];

  //autocomplete for Dehire Park
  selectedDehire: any;
  filteredDehire: any[];
  dehire_arr: any[] = [];
  dehire: any[] = [];

  //autocomplete for Dehire Park
  selectedPrimaryOrigin: any;
  filteredPrimaryOrigin: any[];
  primaryOrigin_arr: any[] = [];
  primaryOrigin: any[] = [];

  selectedDestinationLocation: any[] | any;
  selectedOriginLocation: any[] | any;


  selectedDestinationSite: any[] | any;

  editContainetForm = {
    serviceId: 15441966,
    dataSource: 'A2',
    created: 1699376153000,
    tripIdCust: null,
    serviceGroup: null,
    serviceDesc: null,
    customerId: '1052601',
    consignmentMasterCustomerId: '1052601',
    loadId: 13791515,
    serviceNo: 'M0083289',
    reasonId: '105',
    chargeAmt: null,
    chargeDesc: null,
    rateId: null,
    complete: false,
    loadNo: 'L0097771',
    batchNo: '3443',
    custRef: 'r45',
    scheduleDate: 1699448400000,
    despatchBy: null,
    deliveryOpen: 1698843600000,
    deliveryClose: null,
    returnLocationId: null,
    pickupLocation: {
      locationId: null,
      siteId: 999,
      locationTypeId: null,
      locationDesc: 'COD ROBERT JARVIS CASH SALE',
      zonePayId: 'METRO',
      zoneChargeId: 'METRO',
      suburb: null,
      active: null,
      loadTimeMins: null,
      address1: null,
      address2: null,
      state: null,
      postCode: null,
      window1From: null,
      window1To: null,
      window2From: null,
      window2To: null,
      window3From: null,
      window3To: null,
      personIdContact: null,
      personIdContactName: null,
      customerId: null,
      locationCode: null,
      latitude: null,
      longitude: null,
      geofence: null,
      mapSourceId: null,
      mapReference: null,
      remarks: null,
      truckSizeLimit: null,
      defaultTripSeq: null,
      routeId: null,
      permanent: null,
      loadTimeMinsPerUnit: null,
      loadTimeUnit: null,
      waitTimeMins: null,
      waitTimeMinsPerUnit: null,
      waitTimeUnit: null,
      accShortCut: null,
      locationIdGroup: null,
      siteTravelTime: null,
      disableWPUpdated: null,
      externalLookUp: null,
      internalLookUp: null,
      segManaged: null,
      segExported: null,
      routeCapacity: null,
    },
    dropLocation: {
      locationId: null,
      siteId: 999,
      locationTypeId: null,
      locationDesc: 'ESTHER MCCLUSKEY',
      zonePayId: 'PZONEOUT3',
      zoneChargeId: 'CZONEOUT3',
      suburb: null,
      active: null,
      loadTimeMins: null,
      address1: null,
      address2: null,
      state: null,
      postCode: null,
      window1From: null,
      window1To: null,
      window2From: null,
      window2To: null,
      window3From: null,
      window3To: null,
      personIdContact: null,
      personIdContactName: null,
      customerId: null,
      locationCode: null,
      latitude: null,
      longitude: null,
      geofence: null,
      mapSourceId: null,
      mapReference: null,
      remarks: null,
      truckSizeLimit: null,
      defaultTripSeq: null,
      routeId: null,
      permanent: null,
      loadTimeMinsPerUnit: null,
      loadTimeUnit: null,
      waitTimeMins: null,
      waitTimeMinsPerUnit: null,
      waitTimeUnit: null,
      accShortCut: null,
      locationIdGroup: null,
      siteTravelTime: null,
      disableWPUpdated: null,
      externalLookUp: null,
      internalLookUp: null,
      segManaged: null,
      segExported: null,
      routeCapacity: null,
    },
    loadLocation: {
      locationId: '3000166-BACCHUS MARSH',
      siteId: 999,
      locationTypeId: null,
      locationDesc: 'ESTHER MCCLUSKEY',
      zonePayId: null,
      zoneChargeId: null,
      suburb: null,
      active: null,
      loadTimeMins: null,
      address1: null,
      address2: null,
      state: null,
      postCode: null,
      window1From: null,
      window1To: null,
      window2From: null,
      window2To: null,
      window3From: null,
      window3To: null,
      personIdContact: null,
      personIdContactName: null,
      customerId: null,
      locationCode: null,
      latitude: null,
      longitude: null,
      geofence: null,
      mapSourceId: null,
      mapReference: null,
      remarks: null,
      truckSizeLimit: null,
      defaultTripSeq: null,
      routeId: null,
      permanent: null,
      loadTimeMinsPerUnit: null,
      loadTimeUnit: null,
      waitTimeMins: null,
      waitTimeMinsPerUnit: null,
      waitTimeUnit: null,
      accShortCut: null,
      locationIdGroup: null,
      siteTravelTime: null,
      disableWPUpdated: null,
      externalLookUp: null,
      internalLookUp: null,
      segManaged: null,
      segExported: null,
      routeCapacity: null,
    },
    lastGroupSeq: null,
    clearCharge: false,
    totalChargeAmt: null,
    svcReasonLines: [],
    dehireDeadline: null,
    vesselEta: 1699362000000,
    vesselId: 1801,
    priority: null,
    wharf: '1246- CRAIGIEBURN',
    depot: 'ASAHI ARCHERFIELD DC',
    customerSite: '3BUNNALTO-ALTONA',
    dehirePark: '1250 - ALTONA NORTH',
    originSite: 999,
    originLoc: '1246- CRAIGIEBURN',
    destinationSite: 999,
    destinationLoc: '1246 THOMASTOWN',
  };

  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    public dialog: MatDialog,
    private runsheetFormService: RunsheetFormService
  ) {}

  ngOnInit() {
    this.getVesselLookup();
    this.getLocationIds();
    this.getCustomer();
    this.getLoadType();
    this.getReasonCode();
    this.getPrimaryOriginSite();
    this.getMultiLegData();
    this.getRunsheetLineContainerForm();
  }

  getRunsheetLineContainerForm() {
    this.runsheetLineContainerForm.valueChanges.subscribe(res => {
      console.log(this.runsheetLineContainerForm.getRawValue());
      this.runsheetFormService.runsheetLineContainerForm = this.runsheetLineContainerForm.getRawValue();
    })
  }

  runsheetLineContainerForm = this.fb.group({
    serviceTypeId: ['', Validators.required],
    customerId: ['', Validators.required],
    //  laodTypeId: ['', Validators.required],
    wharf: ['', Validators.required],
    depot: ['', Validators.required],

    primaryoriginsite: ['', Validators.required],

    batchNo: ['', Validators.required],
    custref: ['', Validators.required],
    serviceNo: ['', Validators.required],
    loadno: ['', Validators.required],
    docket: ['', Validators.required],
    pallets: ['', Validators.required],
    dollars: ['', Validators.required],
    tonnes: ['', Validators.required],
    hours: ['', Validators.required],
    containers: ['', Validators.required],
    kilograms: ['', Validators.required],
    kilometers: ['', Validators.required],
    reels: ['', Validators.required],
    enteredBy: ['', Validators.required],
    reasonId: ['', Validators.required],
    pickupdeparttime: ['', Validators.required],
    container: ['', Validators.required],

    locationPickupId: ['', Validators.required],
    pickuparrivetime: ['', Validators.required],
    pickupdoctime: ['', Validators.required],
    depart: ['', Validators.required],
    remarks: ['', Validators.required],
    reqDropLocation: ['', Validators.required],
    droparrivetime: ['', Validators.required],
    dropdoctime: ['', Validators.required],
    dropreadytime: ['', Validators.required],
    dropdeparttime: ['', Validators.required],
  });

  sendData() {
   this.runsheetFormService.sendContainerFormData(this.runsheetLineContainerForm);
    return null;
  }

  // Vessel
  getVesselLookup() {
    this.reconcileService.getVesselLookup().subscribe((vesselArr: any) => {
      console.log(' vessels> ', vesselArr);
      vesselArr.map((vessels: Vessel) => {
        this.vesselId.push(vessels.vessel);
      });
    });
  }

  filteredVesselFun(event: any) {
    let vesselArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.vesselId.map((vessel: any) => {
      if (vessel.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        vesselArr.push(vessel);
      }
    });
    this.filteredServiceType = vesselArr;
  }

  onChangeVessel(event: any) {}

  //location

  getLocationIds() {
    this.reconcileService.getLocation().subscribe((locations: any) => {
      console.log('locations container>> ', locations);
      locations.map((location: Location) => {
        if (location.locationId) {
          if (
            location.locationId !== null &&
            location.locationTypeId === 'originLoc'
          ) {
            this.location_arr.push(location.locationId);
          }
          if (
            location.locationId !== null &&
            location.locationTypeId === 'WHARF'
          ) {
            this.wharf_arr.push(location.locationId);
          } else if (
            location.locationId !== null &&
            location.locationTypeId === 'DEPOT'
          ) {
            this.depot_arr.push(location.locationId);
          } else if (
            location.locationId !== null &&
            location.locationTypeId === 'PARK'
          ) {
            this.dehire_arr.push(location.locationId);
          }
        }
      });
      console.log('location_arr >>', this.dehire_arr);
    });
  }
  filteredLoactionFun(event: any) {
    let wharfIdArr: any[] = [];
    let depotIdArr: any[] = [];
    let dehireArr: any[] = [];
    let locationArr: any[] = [];

    let query = event.query;
    this.wharf_arr.map((location: any) => {
      if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        wharfIdArr.push(location);
      }
    });

    this.depot_arr.map((location: any) => {
      if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        depotIdArr.push(location);
      }
    });

    this.dehire_arr.map((location: any) => {
      if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        dehireArr.push(location);
      }
    });

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        locationArr.push(location);
      }
    });
    this.filteredWharf = wharfIdArr;
    this.filteredDepot = depotIdArr;
    this.filteredDehire = dehireArr;
    this.filteredLocations = locationArr;
  }

  onChangeLocation(event: any) {}

  // Customer
  getCustomer() {
    this.reconcileService.getCustomers().subscribe((customerArr: any) => {
      console.log('Customer > ', customerArr);
      customerArr.map((customer: any) => {
        this.customerName.push(customer);
      });
    });
  }

  filteredCustomerFun(event: any) {
    let customerNameArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.customerName.map((customer: any) => {
      if (customer.customerName) {
        if (
          customer.customerName.toLowerCase().indexOf(query.toLowerCase()) == 0
        ) {
          customerNameArr.push(customer.customerName);
        }
      }
    });
    this.filteredCustomers = customerNameArr;
  }

  onChangeCustomer(event: any) {}

  getPrimaryOriginSite() {
    this.reconcileService
      .getPrimaryOriginSite()
      .subscribe((originSite: any) => {
        console.log('originSite > ', originSite);
        originSite.map((origin: OriginLoc) => {
          this.primaryOrigin.push(origin);
        });
      });
  }

  filteredOriginFun(event: any) {
    let primaryOriginArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.primaryOrigin.map((originSite: Site) => {
      if (originSite) {
        if (
          originSite.siteDesc.toLowerCase().indexOf(query.toLowerCase()) == 0
        ) {
          primaryOriginArr.push(originSite.siteDesc);
        }
      }
    });
    this.filteredPrimaryOrigin = primaryOriginArr;
  }

  onChangeOrigin(event: any) {}

  // Loadtype
  getLoadType() {
    this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
      // console.log("Customer > ", customerArr);
      loadTypeArr.map((loadType: any) => {
        this.loadTypeId.push(loadType.loadTypeId);
      });
    });
  }
  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredCustomers = loadTypeArr;
  }

  onChangeLoadType(event: any) {}

  //Reason Code

  //reason code
  getReasonCode() {
    this.reconcileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: any) => {
        if (reasonDrop.reasonDescription !== null) {
          this.reasonCode.push(
            `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`
          );
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((company: any) => {
      if (company.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        reasonArr.push(company);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  //Popup for Adding Container
  openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
  }

  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe(
      (runsheet: RunsheetDetail) => {
        console.log('Container  details >> ', runsheet);
        // console.log("customerId  Arr > ", this.loadTypeArrId);
        this.wharf_arr.filter((loadtype: Location) => {
          if (runsheet.lineServiceTO.wharf === loadtype.locationId) {
            this.selectedserviceTypeId = loadtype.locationId;
          }
        });

        this.customerId.filter((customer: customers) => {
          if (runsheet.lineServiceTO.customerId === customer.customerId) {
            this.selectedCustomerId = customer.customerId;
          }
        });

        // this.loadTypeId.map((loadtype: any) => {
        //   if (runsheet.loadTypeId === loadtype) {
        //     this.selectedLoadType = loadtype;
        //   }
        // });

        //vesselId
        this.vesselId.map((vessel: Vessel) => {
          if (vessel.id === runsheet.lineServiceTO.vesselId)
            this.selectedVesselId = vessel.vessel;
        });

        //depot
        this.depot_arr.map((depot: Location) => {
          if (depot.locationId === runsheet.lineServiceTO.depot) {
            this.selectedDepot = depot.locationId;
          }
        });

        //dehire
        this.dehire_arr.map((dehire: Location) => {
          if (dehire.locationId === runsheet.lineServiceTO.dehirePark) {
            this.selectedDepot = dehire.locationId;
          }
        });

        //primaryOrigin
        this.primaryOrigin.map((origin: OriginLoc) => {
          if(origin.siteId) {
            if(origin.siteId === runsheet.lineServiceTO.originSite) {
              this.selectedPrimaryOrigin = origin.siteDesc;
            }
            if(origin.siteId === runsheet.lineServiceTO.destinationSite) {
              this.selectedDestinationLocation = origin.siteDesc;
            }
          }
        })  
  

        //Primary Loocation
        this.primaryOrigin.map((origin: OriginLoc) => {
          if(origin.siteId) {
            if(origin.siteId === runsheet.siteId) {
              this.selectedDestinationLocation = origin.siteDesc;
            }
          }
        }) 
        
        this.location_arr.map((location: Location) => {
          if(location.locationId) {
            if(location.locationTypeId === runsheet.lineServiceTO.originLoc) {
                this.selectedOriginLocation = location.locationTypeId;
            }

            if(location.locationTypeId === runsheet.lineServiceTO.destinationLoc) {
              this.selectedDestinationLocation = location.locationTypeId;
          }
          }
        })

        this.editContainetForm.vesselEta = runsheet.lineServiceTO.vesselEta;
        this.editContainetForm.deliveryOpen =
          runsheet.lineServiceTO.deliveryOpen;
        this.editContainetForm.deliveryClose =
          runsheet.lineServiceTO.deliveryClose;
        this.editContainetForm.dehireDeadline =
          runsheet.lineServiceTO.dehireDeadline;
      }
    );
  }
}
