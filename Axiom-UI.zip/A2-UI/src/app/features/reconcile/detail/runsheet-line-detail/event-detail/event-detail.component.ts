import { Component } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { Details, Event } from '../../detail.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.scss'],
})
export class EventDetailComponent {
  created: any;

  eventRow: Event[] = [];
  eventColumnDefs: any[] = [
    {
      field: 'eventTime',
      headerName: '',
      filter: 'agNumberColumnFilter',
    },
    { field: 'eventTime', headerName: 'Event date/time', minWidth: 120 },
    { field: 'eventDescription', headerName: 'Event', minWidth: 120 },
    { field: 'eventLevel', headerName: 'Relation', minWidth: 150 },
    { field: 'mdservertime', headerName: 'MD Server date/time', minWidth: 120 },
    { field: 'created', headerName: 'Event Created date/time', minWidth: 80 },
    { field: 'driverId', headerName: 'Driver', minWidth: 80 },
    { field: 'tripIdCust', headerName: 'Trip', minWidth: 120 },
    { field: 'truckId', headerName: 'Truck', minWidth: 120 },
    { field: 'trailerId', headerName: 'Trailer 1', minWidth: 120 },
    { field: 'trailerTagId', headerName: 'Trailer 2', minWidth: 120 },
    { field: 'dockId', headerName: 'Dock', minWidth: 120 },
    { field: 'userId', headerName: 'User', minWidth: 120 },
    { field: 'locationId', headerName: 'Location', minWidth: 150, },
    { field: 'datasourceId', headerName: 'Data Source', minWidth: 120 },
    { field: 'eventAdjusted', headerName: 'Event Adjusted', minWidth: 130 },
    { field: 'todexportable', headerName: 'TOD Exportable', minWidth: 130 },
    { field: 'exported', headerName: 'Exported', minWidth: 150 },
    { field: 'comments', headerName: 'Comments', minWidth: 120 },
    { field: 'latitude', headerName: 'Latitude', minWidth: 120 },
    { field: 'longitude', headerName: 'Longitude', minWidth: 120 },
    { field: 'compliant', headerName: 'Logon/Logoff Compliance', width: 200 },
    { field: 'serviceNo', headerName: 'Service', minWidth: 120 },
    { field: 'loadNo', headerName: 'Load', minWidth: 120 },
  ];

  constructor(private reconcileService: ReconcileService, private runsheetFormService: RunsheetFormService) {}

  ngOnInit() {
    this.getEventData();
  }

  getEventData() {
    this.reconcileService._multiLangData.subscribe((fetchLoad: Details) => {
      this.eventRow = fetchLoad.events;
       this.runsheetFormService._runSheetEventDetail.next(this.eventRow);

      fetchLoad.events.map((eventData: Event) => {
        this.created = eventData.created;
      })
      
      // this.reconcileService
      //   .getEventData(fetchLoad.events.id)
      //   .subscribe((eventData: Event[]) => {
      //     this.eventRow = eventData.map((rowLoad: any) => {
      //       return rowLoad;
      //     });
      //   });
    });
  }
}
