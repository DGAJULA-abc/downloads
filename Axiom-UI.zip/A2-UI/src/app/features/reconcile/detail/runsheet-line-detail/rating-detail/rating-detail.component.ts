import { Component } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { Details } from '../../detail.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';

@Component({
  selector: 'app-rating-detail',
  templateUrl: './rating-detail.component.html',
  styleUrls: ['./rating-detail.component.scss']
})
export class RatingDetailComponent {

     ratingData: any[] = [];
     rateId: any;
     line: any;
     servicehours: any;
     tripkm: any;
     totalChargeAmt: any;
     paydesc: any;
     fuelLevyPay: any;
     chargeAmt: any;
     chargeDesc: any;
     fuelLevyCharge: any;
     remarks: any;

     rateChargeId: any;

    constructor(private reconcileService: ReconcileService, private runsheetFormService: RunsheetFormService){}

    ngOnInit(){
     this.getRateDataLoad();
    }

    getRateDataLoad() {
      this.reconcileService._multiLangData.subscribe((fetchRate: Details) => {
       this.runsheetFormService._runSheetRatingDetail.next(fetchRate);
        console.log("fetchLoad >>", fetchRate);

         this.rateId =  fetchRate?.rateId;
         this.line = fetchRate?.payamt;
         this.servicehours = fetchRate?.servicehours;
         this.tripkm = fetchRate?.tripkm;
         this.totalChargeAmt = fetchRate?.lineServiceTO?.totalChargeAmt;
         this.paydesc = fetchRate?.paydesc;
        //  this.fuelLevyPay = fetchRate?.fuelLevyInfo.fuelLevyPay;
       

        //Charge;
        this.rateChargeId = fetchRate?.lineServiceTO?.rateId;
        this.chargeAmt = fetchRate?.lineServiceTO?.chargeAmt;
        this.chargeDesc = fetchRate?.lineServiceTO?.chargeDesc;
        this.remarks = fetchRate?.remarks;

        
        // this.fuelLevyCharge = fetchRate.fuelLevyInfo.fuelLevyCharge;
        
        // this.reconcileService
        //   .getRatingDetails(fetchLoad.lineServiceTO.rateId)
        //   .subscribe((rateData: any) => {
        //     console.log("rateData >>", rateData);
            
        //     this.ratingData = rateData.map((ratesData: any) => {
        //       return ratesData;
        //     });
        //   });
      });
    }
}
