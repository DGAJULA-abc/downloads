import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-runsheet-line-detail',
  templateUrl: './runsheet-line-detail.component.html',
  styleUrls: ['./runsheet-line-detail.component.scss']
})
export class RunsheetLineDetailComponent {

  tabData: any[] = [];
  runsheetRowData: any[] = [];
  tabHeaderData: any[] = [];
   
  constructor(private fb: FormBuilder, private reconsileService: ReconcileService) {

  }

  ngOnInit() {
    this.getTabRender();
    this.getMultiLegSiteLocationsBySite();
  }

  getTabRender() {
    let uniqueData: any[] = [];
    this.reconsileService.getTabReconcileRunsheetService().subscribe((result: any) => {
      // console.log("getTabReconcileRunsheetService >> ", result);
      
      this.tabHeaderData = result;
      this.tabData = result;
      // console.log('runsheet tabs', this.tabData);
      this.tabHeaderData.sort((a: any, b: any) => a.tabOrder - b.tabOrder);

      const uniqueTabOrders = new Set();

      // Iterate through the data and add items to the uniqueData array
      for (const item of this.tabHeaderData) {
        if (!uniqueTabOrders.has(item.tabOrder)) {
          uniqueData.push(item);
          uniqueTabOrders.add(item.tabOrder);
        }
      }
      this.tabHeaderData = uniqueData;
      // console.log('Unique Data by tabOrder:', uniqueData);
    });
  }

  getMultiLegSiteLocationsBySite() {
    this.reconsileService._multiLangData.subscribe((multiData: any) => {
      console.log("Multi Data>>", multiData.siteId);
      this.reconsileService.getMultiLegSiteLocationsBySite(999).subscribe((serviceData: any) => {
        console.log("serviceData >> ", serviceData);
      })
    })
   
   }
}
