import { Component } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { LoadType, ServiceType } from './runsheet-service-detail.model';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AddContainerDialogComponent } from 'src/app/features/plan/plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { RunsheetDetail } from '../../detail2.model';
import { customers } from 'src/app/features/setup/models/setup.model';
import { Subject } from 'rxjs';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
// import { reasonsCode } from '../../runsheet-line-detail/runsheet-service-detail/runsheet-service-detail.model';

@Component({
  selector: 'app-runsheet-service-detail',
  templateUrl: './runsheet-service-detail.component.html',
  styleUrls: ['./runsheet-service-detail.component.scss'],
})
export class RunsheetServiceDetailComponent {
  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any[] | any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];
  loadTypeArrId: any[] = [];

  batchNo: any;

   //reasonCode
   reasonCodeArr: any[] = [];
   filteredReasons: any[] = [];
   reasonCode: any[] = [];
   allReasonCode: any[] = [];
   reasonCodeUnique: any[] = [];
   addbutton=true;  
   serviceDetailForm: FormGroup;


    editServiceDetail =  {
            id: 14008010,
            locationContDropId: null,
            locationContPickupId: 123,
           locationDropId: "3000166-BACCHUS MARSH",
            locationPickupId: "1246 THOMASTOWN",
            locationReturnId: null,
            serviceId: 15441966,
            trailerId: null,
            containerId: null,
            loadTypeId: "DELIVERY",
            trailerTagId: null,
            serviceTypeId: "EXPORT",
            rateId: "P500PERTRIP",
            truckId: null,
            siteId: 999,
            qty1: 44,
            unit1: "TONNES",
            qty2: 45,
            unit2: "HOURS",
            qty3: null,
            unit3: null,
            qty4: null,
            unit4: null,
            qty5: null,
            unit5: null,
            qty6: null,
            unit6: null,
            qty7: null,
            unit7: null,
            qty8: null,
            unit8: null,
            owntrailer: false,
            offsiderused: false,
            pickuparrivetime: 1700053200000,
            pickupdeparttime: 1700744400000,
            droparrivetime: 1699448400000,
            dropreadytime: null,
            dropdeparttime: 1700139600000,
            docket: null,
            payamt: 500,
            payestimated: false,
            directfromdepot: false,
            remarks: "rating component",
            nextstoptime: null,
            tripkm: 0,
            paydesc: "$500.00 (Trip $500.00)",
            pickupreadytime: null,
            dropdoctime: null,
            pickupdoctime: null,
            createdby: "dhavaltr",
            tripno: 1,
            tripseq: 1,
            servicehours: null,
            hiretruck: false,
            globaldropbonus: null,
            deliverydate: 1699448400000,
            tripodostart: null,
            tripodoend: null,
            groupseq: null,
            tripstarttime: null,
            tripendtime: null,
            lineTemperature: null,
            lineServiceTO: {
                serviceId: 15441966,
                dataSource: "A2",
                created: 1699376153000,
                tripIdCust: null,
                serviceGroup: null,
                serviceDesc: null,
                customerId: "1052601",
                consignmentMasterCustomerId: "1052601",
                loadId: 13791515,
                serviceNo: "M0083289",
                reasonId: "105",
                chargeAmt: null,
                chargeDesc: null,
                rateId: null,
                complete: false,
                loadNo: "L0097771",
                batchNo: "3443",
                custRef: "r45",
                scheduleDate: 1699448400000,
                despatchBy: null,
                deliveryOpen: 1698843600000,
                deliveryClose: null,
                returnLocationId: null,
                pickupLocation: {
                    locationId: null,
                    siteId: 999,
                    locationTypeId: null,
                    locationDesc: "COD ROBERT JARVIS CASH SALE",
                    zonePayId: "METRO",
                    zoneChargeId: "METRO",
                    suburb: null,
                    active: null,
                    loadTimeMins: null,
                    address1: null,
                    address2: null,
                    state: null,
                    postCode: null,
                    window1From: null,
                    window1To: null,
                    window2From: null,
                    window2To: null,
                    window3From: null,
                    window3To: null,
                    personIdContact: null,
                    personIdContactName: null,
                    customerId: null,
                    locationCode: null,
                    latitude: null,
                    longitude: null,
                    geofence: null,
                    mapSourceId: null,
                    mapReference: null,
                    remarks: null,
                    truckSizeLimit: null,
                    defaultTripSeq: null,
                    routeId: null,
                    permanent: null,
                    loadTimeMinsPerUnit: null,
                    loadTimeUnit: null,
                    waitTimeMins: null,
                    waitTimeMinsPerUnit: null,
                    waitTimeUnit: null,
                    accShortCut: null,
                    locationIdGroup: null,
                    siteTravelTime: null,
                    disableWPUpdated: null,
                    externalLookUp: null,
                    internalLookUp: null,
                    segManaged: null,
                    segExported: null,
                    routeCapacity: null
                },
                dropLocation: {
                    locationId: null,
                    siteId: 999,
                    locationTypeId: null,
                    locationDesc: "ESTHER MCCLUSKEY",
                    zonePayId: "PZONEOUT3",
                    zoneChargeId: "CZONEOUT3",
                    suburb: null,
                    active: null,
                    loadTimeMins: null,
                    address1: null,
                    address2: null,
                    state: null,
                    postCode: null,
                    window1From: null,
                    window1To: null,
                    window2From: null,
                    window2To: null,
                    window3From: null,
                    window3To: null,
                    personIdContact: null,
                    personIdContactName: null,
                    customerId: null,
                    locationCode: null,
                    latitude: null,
                    longitude: null,
                    geofence: null,
                    mapSourceId: null,
                    mapReference: null,
                    remarks: null,
                    truckSizeLimit: null,
                    defaultTripSeq: null,
                    routeId: null,
                    permanent: null,
                    loadTimeMinsPerUnit: null,
                    loadTimeUnit: null,
                    waitTimeMins: null,
                    waitTimeMinsPerUnit: null,
                    waitTimeUnit: null,
                    accShortCut: null,
                    locationIdGroup: null,
                    siteTravelTime: null,
                    disableWPUpdated: null,
                    externalLookUp: null,
                    internalLookUp: null,
                    segManaged: null,
                    segExported: null,
                    routeCapacity: null
                },
                loadLocation: {
                    locationId: "3000166-BACCHUS MARSH",
                    siteId: 999,
                    locationTypeId: null,
                    locationDesc: "ESTHER MCCLUSKEY",
                    zonePayId: null,
                    zoneChargeId: null,
                    suburb: null,
                    active: null,
                    loadTimeMins: null,
                    address1: null,
                    address2: null,
                    state: null,
                    postCode: null,
                    window1From: null,
                    window1To: null,
                    window2From: null,
                    window2To: null,
                    window3From: null,
                    window3To: null,
                    personIdContact: null,
                    personIdContactName: null,
                    customerId: null,
                    locationCode: null,
                    latitude: null,
                    longitude: null,
                    geofence: null,
                    mapSourceId: null,
                    mapReference: null,
                    remarks: null,
                    truckSizeLimit: null,
                    defaultTripSeq: null,
                    routeId: null,
                    permanent: null,
                    loadTimeMinsPerUnit: null,
                    loadTimeUnit: null,
                    waitTimeMins: null,
                    waitTimeMinsPerUnit: null,
                    waitTimeUnit: null,
                    accShortCut: null,
                    locationIdGroup: null,
                    siteTravelTime: null,
                    disableWPUpdated: null,
                    externalLookUp: null,
                    internalLookUp: null,
                    segManaged: null,
                    segExported: null,
                    routeCapacity: null
                },
                lastGroupSeq: null,
                clearCharge: false,
                totalChargeAmt: null,
                svcReasonLines: [],
                dehireDeadline: null,
                vesselEta: 1699362000000,
                vesselId: 1801,
                priority: null,
                wharf: "1246- CRAIGIEBURN",
                depot: "ASAHI ARCHERFIELD DC",
                customerSite: "3BUNNALTO-ALTONA",
                dehirePark: "1250 - ALTONA NORTH",
                originSite: 999,
                originLoc: "1246- CRAIGIEBURN",
                destinationSite: 999,
                destinationLoc: "1246 THOMASTOWN"
            },
            events: [],
            loadNoDuplicated: null
        }

  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    public dialog: MatDialog,
    private rootFormGroup: FormGroupDirective,
    private runsheetFormService: RunsheetFormService
  ) {}

  ngOnInit() {
    // this.detailForm = this.rootFormGroup.control;
    // console.log('root form', this.rootFormGroup.control.value);
    // console.log('current form', this.rootFormGroup.control.get("serviceLineForm") );
    // this.serviceLineForm = this.rootFormGroup.control.get("serviceLineForm") as FormGroup; 
    this.getServiceTypesLookup();
    this.getCustomer();
    this.getLoadType();
    this.getReasonCode();
    this.getMultiLegData();
    this.createServiceLineForm();
    // this.runSheetServiceSubject.subscribe(res=> {
    //   console.log('runSheetServiceSubject', res);
    // })
    // this.runsheetFormService.runSheetFormSubject.subscribe(res=> {
    //     console.log('runSheetServiceSubject', res);
    //   })

    //this.runsheetFormService.runSheetlineForm = this.serviceLineForm.getRawValue();
    this.serviceDetailForm.valueChanges.subscribe(res => {
      console.log(this.serviceDetailForm.getRawValue());
      this.runsheetFormService.serviceDetailForm = this.serviceDetailForm.getRawValue();
    })
  }

  

  createServiceLineForm () {
    this.serviceDetailForm = this.fb.group({
      serviceTypeId: ['', Validators.required],
      customerId: ['', Validators.required],
      laodTypeId: ['', Validators.required],
      batchNo: ['', Validators.required],
      custRef: ['', Validators.required],
      serviceNo: ['', Validators.required],
      loadno: ['', Validators.required],
      docket: ['', Validators.required],
      pallets: ['', Validators.required],
      dollars: ['', Validators.required],
      tonnes: ['', Validators.required],
      hours: ['', Validators.required],
      containers: ['', Validators.required],
      kilograms: ['', Validators.required],
      kilometers: ['', Validators.required],
      reels: ['', Validators.required],
      enteredBy: ['', Validators.required],
      reasonId: ['', Validators.required],
      pickupdeparttime: ['', Validators.required],
      container: ['', Validators.required],
  
  
      locationPickupId: ['', Validators.required],
      pickuparrivetime: ['', Validators.required],
      pickupdoctime: ['', Validators.required],
      depart: ['', Validators.required],
      remarks: ['', Validators.required],
      reqDropLocation: ['', Validators.required],
      droparrivetime: ['', Validators.required],
      dropdoctime: ['', Validators.required],
      dropreadytime: ['', Validators.required],
      dropdeparttime: ['', Validators.required],
  
    });  
    
  }

  sendData() {
    this.runsheetFormService.sendFormData(this.serviceDetailForm);
    return null;
  }

  saveServiceLineForm() {}

  // Service Type
  getServiceTypesLookup() {
    this.reconcileService
      .getServiceTypesLookup()
      .subscribe((serviceTypeArr: any) => {
        console.log('getServiceTypesLookup line> ', serviceTypeArr);
        serviceTypeArr.map((serviceTypeIdUniqye: ServiceType) => {
          this.serviceTypeId.push(serviceTypeIdUniqye);
        });
      });
  }

  filteredServiceFun(event: any) {
    let serviceTypeArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.serviceTypeId.map((serviceType: ServiceType) => {
      if (
        serviceType.serviceTypeId.toLowerCase().indexOf(query.toLowerCase()) ==
        0
      ) {
        serviceTypeArr.push(serviceType.serviceTypeId);
      }
    });
    this.filteredServiceType = serviceTypeArr;
  }

  onChangeServiceType(event: any) {}

  // Customer
  getCustomer() {
    this.reconcileService.getCustomers().subscribe((customerArr: any) => {
      // console.log("Customer > ", customerArr);
      customerArr.map((customer: any) => {
        this.customerId.push(customer);
      });
    });
  }

  filteredCustomerFun(event: any) {
    let customerArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.customerId.map((customer: any) => {
      if (customer.customerId.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        customerArr.push(customer.customerId);
      }
    });
    this.filteredCustomers = customerArr;
  }

  onChangeCustomer(event: any) {}

  // Loadtype
  getLoadType() {
    this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
      this.loadTypeArrId.push(loadTypeArr);
      // console.log("Customer > ", customerArr);
      loadTypeArr.map((loadType: any) => {
        this.loadTypeId.push(loadType.loadTypeId);
      });
    });
  }

  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredCustomers = loadTypeArr;
  }

  onChangeLoadType(event: any) {}

  //Reason Code

   //reason code
   getReasonCode() {
    this.reconcileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: any) => {
        if (reasonDrop.reasonDescription !== null) {
          this.reasonCode.push(
            `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`
          );
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((company: any) => {
      if (company.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        reasonArr.push(company);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

   //Popup for Adding Container
   openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
  }

  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe((runsheet: RunsheetDetail) => {
      
      console.log("Runsheet service details >> ", runsheet);
      console.log("customerId  Arr > ", this.loadTypeArrId);
      this.serviceTypeId.filter((serviceTypeId: ServiceType) => {
           if(runsheet.serviceTypeId === serviceTypeId.serviceTypeId) {
            this.selectedserviceTypeId = serviceTypeId.serviceTypeId;
           }
      })

      this.customerId.filter((customer: customers) => {
           if(runsheet.lineServiceTO.customerId === customer.customerId) {
            this.selectedCustomerId = customer.customerId;
           }
      })

      this.loadTypeId.map((loadtype: any) => {
        if(runsheet.loadTypeId === loadtype) {
          this.selectedLoadType = loadtype;
        }
      })


      this.editServiceDetail.lineServiceTO.batchNo = runsheet.lineServiceTO.batchNo;
      this.editServiceDetail.lineServiceTO.custRef = runsheet.lineServiceTO.custRef;
      this.editServiceDetail.lineServiceTO.serviceNo = runsheet.lineServiceTO.serviceNo;
      this.editServiceDetail.lineServiceTO.loadNo = runsheet.lineServiceTO.loadNo;
      this.editServiceDetail.docket = runsheet.docket;
      this.editServiceDetail.containerId = runsheet.containerId;
      this.editServiceDetail.locationContPickupId = runsheet.locationContPickupId;
      this.editServiceDetail.pickuparrivetime = runsheet.pickuparrivetime;
      this.editServiceDetail.pickupdoctime = runsheet.pickupdoctime;
      this.editServiceDetail.pickupdeparttime = runsheet.pickupdeparttime;
      this.editServiceDetail.remarks = runsheet.remarks;
      this.editServiceDetail.droparrivetime = runsheet.droparrivetime;
      this.editServiceDetail.dropdoctime = runsheet.dropdoctime;
      this.editServiceDetail.dropreadytime = runsheet.dropreadytime;
      this.editServiceDetail.dropdeparttime = runsheet.dropdeparttime;
    
    })
  }

}
