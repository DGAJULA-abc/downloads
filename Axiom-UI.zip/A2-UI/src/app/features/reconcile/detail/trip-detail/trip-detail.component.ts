import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {
  Details,
  LineServiceTo,
  LoadLocation,
  LoadTableData,
  LoadTableResponse,
  Location,
  Trailers,
} from '../detail.model';
import { ReconcileService } from '../../services/reconcile.service';
import { ServiceType } from '../runsheet-line-detail/runsheet-service-detail/runsheet-service-detail.model';
import { customers, trailers, trucks } from 'src/app/features/setup/models/setup.model';
import { RunsheetDetail } from '../detail2.model';

@Component({
  selector: 'app-trip-detail',
  templateUrl: './trip-detail.component.html',
  styleUrls: ['./trip-detail.component.scss']
})
export class TripDetailComponent {
 // service type
 serviceTypeId: any[] = [];
 filteredServiceType: any[] = [];
 selectedserviceTypeId: any;


  // Truck
  truckId: any[] = [];
  filteredTruck: any[] = [];
  selectedTruck: any;

   // trailer
   trailerId: any[] = [];
   filteredTrailer: any[] = [];
   selectedTrailer: any;

 // customer
 selectedCustomerId: any[] | any;
 customerId: any[] = [];
 filteredCustomers: any[] = [];

 // Load Type
 selectedLoadType: any[] | any;
 loadTypeId: any[] = [];
 filteredLoadType: any[] = [];
 //reasonCode
 reasonCodeArr: any[] = [];
 filteredReasons: any[] = [];
 reasonCode: any[] = [];
 allReasonCode: any[] = [];
 reasonCodeUnique: any[] = [];

 //autocomplete for locationIds
 locationIds: any[] = [];
 selectedLocation: any;
 filteredLocations: any[];
 location_arr: any[] = [];

 loadRow: any[] = [];
 loadColumnDefs: any[] = [
   {
     field: 'serviceno',
     headerName: '',
     filter: 'agNumberColumnFilter',
   },
   { field: 'serviceno', headerName: 'Service No.', minWidth: 120 },
   { field: 'enteredby', headerName: 'Entered By', minWidth: 120 },
   { field: 'loadtypeid', headerName: 'Load Type Id', minWidth: 150 },
   { field: 'servicetypeid', headerName: 'Service Type Id', minWidth: 120 },
   { field: 'servicedesc', headerName: 'Service desc', minWidth: 80 },
 ];

 editTripForm = {
  serviceId: 15441966,
  dataSource: 'A2',
  created: 1699376153000,
  tripIdCust: null,
  serviceGroup: null,
  serviceDesc: null,
  customerId: '1052601',
  consignmentMasterCustomerId: '1052601',
  loadId: 13791515,
  serviceNo: 'M0083289',
  reasonId: '105',
  chargeAmt: null,
  chargeDesc: null,
  rateId: null,
  complete: false,
  loadNo: 'L0097771',
  batchNo: '3443',
  custRef: 'r45',
  scheduleDate: 1699448400000,
  despatchBy: null,
  deliveryOpen: 1698843600000,
  deliveryClose: null,
  returnLocationId: null,
  pickupLocation: {
    locationId: null,
    siteId: 999,
    locationTypeId: null,
    locationDesc: 'COD ROBERT JARVIS CASH SALE',
    zonePayId: 'METRO',
    zoneChargeId: 'METRO',
    suburb: null,
    active: null,
    loadTimeMins: null,
    address1: null,
    address2: null,
    state: null,
    postCode: null,
    window1From: null,
    window1To: null,
    window2From: null,
    window2To: null,
    window3From: null,
    window3To: null,
    personIdContact: null,
    personIdContactName: null,
    customerId: null,
    locationCode: null,
    latitude: null,
    longitude: null,
    geofence: null,
    mapSourceId: null,
    mapReference: null,
    remarks: null,
    truckSizeLimit: null,
    defaultTripSeq: null,
    routeId: null,
    permanent: null,
    loadTimeMinsPerUnit: null,
    loadTimeUnit: null,
    waitTimeMins: null,
    waitTimeMinsPerUnit: null,
    waitTimeUnit: null,
    accShortCut: null,
    locationIdGroup: null,
    siteTravelTime: null,
    disableWPUpdated: null,
    externalLookUp: null,
    internalLookUp: null,
    segManaged: null,
    segExported: null,
    routeCapacity: null,
  },
  dropLocation: {
    locationId: null,
    siteId: 999,
    locationTypeId: null,
    locationDesc: 'ESTHER MCCLUSKEY',
    zonePayId: 'PZONEOUT3',
    zoneChargeId: 'CZONEOUT3',
    suburb: null,
    active: null,
    loadTimeMins: null,
    address1: null,
    address2: null,
    state: null,
    postCode: null,
    window1From: null,
    window1To: null,
    window2From: null,
    window2To: null,
    window3From: null,
    window3To: null,
    personIdContact: null,
    personIdContactName: null,
    customerId: null,
    locationCode: null,
    latitude: null,
    longitude: null,
    geofence: null,
    mapSourceId: null,
    mapReference: null,
    remarks: null,
    truckSizeLimit: null,
    defaultTripSeq: null,
    routeId: null,
    permanent: null,
    loadTimeMinsPerUnit: null,
    loadTimeUnit: null,
    waitTimeMins: null,
    waitTimeMinsPerUnit: null,
    waitTimeUnit: null,
    accShortCut: null,
    locationIdGroup: null,
    siteTravelTime: null,
    disableWPUpdated: null,
    externalLookUp: null,
    internalLookUp: null,
    segManaged: null,
    segExported: null,
    routeCapacity: null,
  },
  loadLocation: {
    locationId: '3000166-BACCHUS MARSH',
    siteId: 999,
    locationTypeId: null,
    locationDesc: 'ESTHER MCCLUSKEY',
    zonePayId: null,
    zoneChargeId: null,
    suburb: null,
    active: null,
    loadTimeMins: null,
    address1: null,
    address2: null,
    state: null,
    postCode: null,
    window1From: null,
    window1To: null,
    window2From: null,
    window2To: null,
    window3From: null,
    window3To: null,
    personIdContact: null,
    personIdContactName: null,
    customerId: null,
    locationCode: null,
    latitude: null,
    longitude: null,
    geofence: null,
    mapSourceId: null,
    mapReference: null,
    remarks: null,
    truckSizeLimit: null,
    defaultTripSeq: null,
    routeId: null,
    permanent: null,
    loadTimeMinsPerUnit: null,
    loadTimeUnit: null,
    waitTimeMins: null,
    waitTimeMinsPerUnit: null,
    waitTimeUnit: null,
    accShortCut: null,
    locationIdGroup: null,
    siteTravelTime: null,
    disableWPUpdated: null,
    externalLookUp: null,
    internalLookUp: null,
    segManaged: null,
    segExported: null,
    routeCapacity: null,
  },
  lastGroupSeq: null,
  clearCharge: false,
  totalChargeAmt: null,
  svcReasonLines: [],
  dehireDeadline: null,
  vesselEta: 1699362000000,
  vesselId: 1801,
  priority: null,
  wharf: '1246- CRAIGIEBURN',
  depot: 'ASAHI ARCHERFIELD DC',
  customerSite: '3BUNNALTO-ALTONA',
  dehirePark: '1250 - ALTONA NORTH',
  originSite: 999,
  originLoc: '1246- CRAIGIEBURN',
  destinationSite: 999,
  destinationLoc: '1246 THOMASTOWN',
};

 constructor(
   private fb: FormBuilder,
   private reconcileService: ReconcileService
 ) {}

 ngOnInit() {
   this.getTrucks();
   this.getTrailer();
   this.getLoadType();
   this.getLocationIds();
   this.getServicesOfLoad();
   this.getMultiLegData();
 }

 tripDetailForm = this.fb.group({
   truckId: ['', Validators.required],
   customerId: ['', Validators.required],
   returnto: ['', Validators.required],
   trailerId: ['', Validators.required],
   trailerTagId: ['', Validators.required],
   tripodostart: ['', Validators.required],
   tripodoend: ['', Validators.required],
   tripstarttime: ['', Validators.required],
   tripendtime: ['', Validators.required],
   hiretruck: ['', Validators.required],
   owntrailer: ['', Validators.required],
   offsiderused: ['', Validators.required],
 });
 saveTripDetailForm() {}

 // Truck Type
 getTrucks() {
   this.reconcileService
     .getTruck()
     .subscribe((truck: any) => {
      //  console.log('truck line> ', truck);
       truck.map((truck: trucks) => {
        this.truckId.push(truck);
      });
     });
 }

 filteredTruckFun(event: any) {
   let truckeArr: any[] = [];
   let query = event.query;
   // console.log("this.customerId >", this.customerId);
   this.truckId.map((truck: trucks) => {
     if (
       truck.truckId.toLowerCase().indexOf(query.toLowerCase()) ==
       0
     ) {
     const truckName = `${truck.truckId} , (${truck.routeCapacity} , ${truck.companyId})`;
      truckeArr.push(truckName);
     }
   });
   this.filteredTruck = truckeArr;
 }

 onChangeTruck(event: any) {}

 // Trailer
 getTrailer() {
   this.reconcileService.getTrailer().subscribe((trailer: any) => {
    //  console.log("trailer > ", trailer);
     trailer.map((trailer: Trailers) => {
       this.trailerId.push(trailer);
     });
   });
 }

 filteredTrailerFun(event: any) {
   let trailerArr: any[] = [];
   let query = event.query;
   // console.log("this.customerId >", this.customerId);
   this.trailerId.map((trailer: any) => {
     if(trailer.trailerId) {
      if (trailer.trailerId.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        const trailerName = this.reconcileService.geTrailerName(trailer);
        trailerArr.push(trailerName);
       }
     }
     
   });
   this.filteredCustomers = trailerArr;
 }

 onChangeTrailer(event: any) {}

 // Loadtype
 getLoadType() {
   this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
     // console.log("Customer > ", customerArr);
     loadTypeArr.map((loadType: any) => {
       this.loadTypeId.push(loadType.loadTypeId);
     });
   });
 }

 filteredLoadtypeFun(event: any) {
   let loadTypeArr: any[] = [];
   let query = event.query;
   // console.log("this.customerId >", this.customerId);
   this.loadTypeId.map((loadType: any) => {
     if (loadType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
       loadTypeArr.push(loadType);
     }
   });
   this.filteredLoadType = loadTypeArr;
 }

 onChangeLoadType(event: any) {}

 getLocationIds() {
   this.reconcileService.getLocation().subscribe((locations: any) => {
     // console.log('getReasonCode >> ', reasonCodes);
     locations.map((location: Location) => {
       if (location.locationId !== null) {
         this.location_arr.push(location.locationId);
       }
     });
     // console.log('reasonCode >>', this.reasonCode);
   });
 }
 filteredLoactionFun(event: any) {
   let locationIdArr: any[] = [];
   let query = event.query;
   this.location_arr.map((location: any) => {
     if (location.toLowerCase().indexOf(query.toLowerCase()) == 0) {
       locationIdArr.push(location);
     }
   });
   this.filteredLocations = locationIdArr;
 }

 onChangeLocation(event: any) {}

 getServicesOfLoad() {
   this.reconcileService._multiLangData.subscribe((fetchLoad: Details) => {
     this.reconcileService
       .getServicesOfLoad(fetchLoad.lineServiceTO.loadId)
       .subscribe((loadData: LoadTableResponse) => {
         this.loadRow = loadData.map((rowLoad: LoadTableData) => {
           return rowLoad;
         });
       });
   });
 }

 getMultiLegData() {
  this.reconcileService._multiLangData.subscribe((runsheet: RunsheetDetail) => {
    console.log("trip details >> ", runsheet);
    // console.log("customerId  Arr > ", this.loadTypeArrId);
    // this.serviceTypeId.filter((serviceTypeId: ServiceType) => {
    //      if(runsheet.serviceTypeId === serviceTypeId.serviceTypeId) {
    //       this.selectedserviceTypeId = serviceTypeId.serviceTypeId;
    //      }
    // })
    this.truckId.filter((truck: trucks) => {
      if(runsheet.truckId === truck.truckId) { 
       this.selectedTruck = truck.truckId;
      }
 })

 this.trailerId.filter((trailer: trailers) => {
  if(runsheet.trailerId === trailer.trailerId) { 
    console.log("trailer id", trailer.trailerId);
    
   this.selectedTrailer = this.reconcileService.geTrailerName(trailer);
   console.log("this.selectedTrailer ", this.selectedTrailer);
   
  }
})
    
    this.customerId.filter((customer: customers) => {
         if(runsheet.lineServiceTO.customerId === customer.customerId) {
          this.selectedCustomerId = customer.customerId;
         }
    })

    this.loadTypeId.map((loadtype: any) => {
      if(runsheet.loadTypeId === loadtype) {
        this.selectedLoadType = loadtype;
      }
    })


    // this.editTripForm.lineServiceTO.loadLocation.locationId = runsheet.lineServiceTO.loadLocation.locationId;
    // // this.editTripForm.lineServiceTO.custRef = runsheet.lineServiceTO.loadLocation;
    // this.editTripForm.lineServiceTO.serviceNo = runsheet.lineServiceTO.serviceNo;
    // this.editTripForm.lineServiceTO.loadNo = runsheet.lineServiceTO.loadNo;
    // this.editTripForm.docket = runsheet.docket;
    // this.editTripForm.containerId = runsheet.containerId;
    // this.editTripForm.locationContPickupId = runsheet.locationContPickupId;
    // this.editTripForm.pickuparrivetime = runsheet.pickuparrivetime;
    // this.editTripForm.pickupdoctime = runsheet.pickupdoctime;
    // this.editTripForm.pickupdeparttime = runsheet.pickupdeparttime;
    // this.editTripForm.remarks = runsheet.remarks;
    // this.editTripForm.droparrivetime = runsheet.droparrivetime;
    // this.editTripForm.dropdoctime = runsheet.dropdoctime;
    // this.editTripForm.dropreadytime = runsheet.dropreadytime;
    // this.editTripForm.dropdeparttime = runsheet.dropdeparttime;
  
  })
}


}
