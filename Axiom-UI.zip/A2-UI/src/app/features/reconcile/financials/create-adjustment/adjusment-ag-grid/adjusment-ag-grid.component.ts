import { Component } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { AdjustmentInvoiceLineUndocumentedTo, AdjustmentPayAdviceLineUndocumentedTo, CreateAdjustment } from '../../finaclials.model';
import { CellrenderComponent } from '../../../list-incomplete-services/cellrender/cellrender.component';

@Component({
  selector: 'app-adjusment-ag-grid',
  templateUrl: './adjusment-ag-grid.component.html',
  styleUrls: ['./adjusment-ag-grid.component.scss']
})
export class AdjusmentAgGridComponent {

  adjustmentInvoiceLineUndocumentedTOs: AdjustmentInvoiceLineUndocumentedTo[] = [];

  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'id', headerName: '', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'serviceNo', headerName: 'Service No.',minWidth: 90},
    { field: 'effectiveDate', headerName: 'Effective Date', minWidth: 120},
    { field: 'type', headerName: 'Type', minWidth: 150},
    { field: 'description', headerName: 'Description', minWidth: 120},
    { field: 'amount', headerName: 'Amount', minWidth: 80},
    { field: 'fuelLevy', headerName: 'Fuel levy %', minWidth: 80},
    { field: 'customerIdRechargeTo', headerName: 'Recharge To', minWidth: 120},
    { field: 'user', headerName: 'Customer', minWidth: 120},


  ];

  payRowData: any[] = [];
   payColumnDefs: any[] = [
    { field: 'id', headerName: '', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'runSheetId', headerName: 'Type', minWidth: 150},
    { field: 'serviceNo', headerName: 'Service No.',minWidth: 90},
    { field: 'effectiveDate', headerName: 'Effective Date', minWidth: 120},
    { field: 'type', headerName: 'Type', minWidth: 150},
    { field: 'description', headerName: 'Description', minWidth: 120},
    { field: 'amount', headerName: 'Amount', minWidth: 80},
    { field: 'fuelLevy', headerName: 'Fuel levy %', minWidth: 80},
    { field: 'driverId', headerName: 'Driver Id', minWidth: 120},
    { field: 'user', headerName: 'Customer', minWidth: 120},
  ];

  constructor(private reconcileService: ReconcileService) {}

  ngOnInit() {
    this.getundocumentedAdjustment();
  }

  getundocumentedAdjustment() {
    this.reconcileService.getundocumentedAdjustment().subscribe((undocumentData: CreateAdjustment) => {
      //  console.log("undocumentData >>", undocumentData);
      this.rowData = undocumentData.adjustmentInvoiceLineUndocumentedTOs
       .map((adjusmentData: AdjustmentInvoiceLineUndocumentedTo) => {
          // console.log("adjusmentData > ", adjusmentData);
          return adjusmentData;
      })

      this.payRowData = undocumentData.adjustmentPayAdviceLineUndocumentedTOs.map((payData: AdjustmentPayAdviceLineUndocumentedTo) => {
         console.log("payData >", payData);
           
        return payData;
      })
    })

    

    // this.rowData = this.adjustmentInvoiceLineUndocumentedTOs;
    // console.log("row data", this.rowData);
    
  }
}
