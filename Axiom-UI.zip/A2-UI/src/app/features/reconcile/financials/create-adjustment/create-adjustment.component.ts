import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { ReconcileService } from '../../services/reconcile.service';
import * as moment from 'moment';
import { ServiceFormSubmit } from '../../models/financials.model';
import { AdjustmentDropdown, AdjustmentType } from '../finaclials.model';

interface MyPayload {
  runsheetId: number;
  selectFields: string[];
}

@Component({
  selector: 'app-create-adjustment',
  templateUrl: './create-adjustment.component.html',
  styleUrls: ['./create-adjustment.component.scss'],
})



export class CreateAdjustmentComponent {
  referenceMetaData: any[] = [];
  createAdjustFormGroup: FormGroup;
  adjustmentTypeId: any[] = [];

  sites: any[];
  selectedAdjustTypeId: any[] | any;

  selectedDriverId: any[] | any;
  rechargeCustomerId: any[] | any;

  filteredAdjusTypes: any[];

  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];
  filteredDriver: any[] = [];

  invoiceCheck: boolean = false;
  checkBoxServiceNo: boolean = false;
  checkServiceSelection: boolean = true;

  AdjustRadio: any[] = [
    { name: 'Services', key: 'S' , checked: false},
    { name: 'Runsheet', key: 'R' , checked: false},
  ];

  adjustmentTypeValueDrop: any;
  adjustmentTabel: any[] = [];
  adjustTypeDropArr: any[] = [];
  adjustTypeSecectedData: any[] = [];
  adjustOptionSelectedVal: AdjustmentDropdown;

  driverId: any[] = [];
  driverIdRequest:any;
  invoiceLineObj: any;
  payAdviceLineObj: any;
  allDriver: any[] = [];

  /**Seprate driver id for runsheet case */
  runsheetDriverId: any;
  runsheetPayAdviceLineObj: any;

  constructor(
    private navbarService: NavbarService,
    private fb: FormBuilder,
    private reconcileService: ReconcileService
  ) {}

  createAdjustForm = this.fb.group({
    adjustmentTypeId: ['', Validators.required],
    effectiveDate: ['', Validators.required],
    selectedAdjust: new FormControl(),
    lineAmount: ['', Validators.required],
    customerId: ['', Validators.required],
    rechargeCustomerId: ['', Validators.required],
    fuelLevyAmount: ['', Validators.required],
    serviceNumber: ['', Validators.required],
    lineText: ['', Validators.required],

    driverId: ['', Validators.required],
    payLineAmount: ['', Validators.required],
    payFuelLevyAmount: ['', Validators.required],
    payRechargeCustomerId: ['', Validators.required],
    payLineText: ['', Validators.required],
  });

  ngOnInit() {
    this.getAdjustmentTypes();
    this.getCustomer();
    this.getDriver();
    // this.getReferenceMetadata();
  }

  isRunsheetChecked(): boolean {
    // Check if "Runsheet" is checked
    const runsheetItem = this.AdjustRadio.find(item => item.key === 'R');
    return runsheetItem ? runsheetItem.checked : false;
  }

  saveForm() {
    const formValue = {
      adjustmentTypeId: 'ADDITIONAL CHARGE',
      effectiveDate: 1697115600000,
      runsheetId: null,
      serviceNumber: 'M0081169',
      invoiceLine: {
        lineAmount: 0,
        customerId: 'BULK QLD - MANUAL',
        rechargeCustomerId: null,
        lineText: 'sdsdfsdf',
        fuelLevyAmount: -1,
      },
      payAdviceLine: null,
    };

    if(this.adjustOptionSelectedVal.adjustInvoice) {
      this.invoiceLineObj = {
        lineAmount: this.createAdjustForm.value.lineAmount,
        customerId: this.createAdjustForm.value.customerId,
        lineText: this.createAdjustForm.value.lineText,
        fuelLevyAmount: this.createAdjustForm.value.fuelLevyAmount,
      }  
     
    } else {
      this.invoiceLineObj = null
    }

    if(this.adjustOptionSelectedVal.adjustPayAdvise) {
       this.payAdviceLineObj = {
        driverId: this.driverIdRequest,
        payAmount: this.createAdjustForm.value.payLineAmount,
        lineText: this.createAdjustForm.value.payLineText,
        fuelLevyAmount: this.createAdjustForm.value.payFuelLevyAmount,
      } 
    }else {
      this.payAdviceLineObj = null;
    }
    // rechargeCustomerId: this.createAdjustForm.value.payRechargeCustomerId,

    const formSubmitValueService = {
      adjustmentTypeId: this.createAdjustForm.value.adjustmentTypeId,
      effectiveDate: +moment(
        this.createAdjustForm.value.effectiveDate,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
      runsheetId: null,
      serviceNumber: this.createAdjustForm.value.serviceNumber,
      invoiceLine: this.invoiceLineObj,
      payAdviceLine: this.payAdviceLineObj,
    };

    /**
     * payAdvice line object for Runsheet since diffrent driverid 
     * Based on runsheet API
     */
    if(this.adjustOptionSelectedVal.adjustPayAdvise) {
      this.runsheetPayAdviceLineObj = {
       driverId: this.runsheetDriverId,
       payAmount: this.createAdjustForm.value.payLineAmount,
       lineText: this.createAdjustForm.value.payLineText,
       fuelLevyAmount: this.createAdjustForm.value.payFuelLevyAmount,
     } 
   }else {
     this.runsheetPayAdviceLineObj = null;
   }
    
    const formSubmitValueRunsheet = {
      adjustmentTypeId: this.createAdjustForm.value.adjustmentTypeId,
      effectiveDate: +moment(
        this.createAdjustForm.value.effectiveDate,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
      runsheetId: this.createAdjustForm.value.serviceNumber,
      serviceNumber: null,
      invoiceLine: this.invoiceLineObj,
      payAdviceLine: this.runsheetPayAdviceLineObj,
      
    };

    this.AdjustRadio.forEach(item => {
      if (item.key === 'S' && item.checked === true) {
        this.adjustmentFormSubmit(formSubmitValueService);
      } else if(item.key === 'R' && item.checked === true) {
        this.adjustmentFormSubmit(formSubmitValueRunsheet);
      }
    });
    // console.log(this.createAdjustForm.value);
    // this.adjustmentFormSubmit(formSubmitValue);
  }

  getDriver() {
    this.reconcileService.getDriver().subscribe((drivers: any) => {
      console.log('driversList >>', drivers);
      this.allDriver = drivers;
      drivers.map((driver: any) => {
        this.driverId.push(driver.companyId);
      });
    });
  }

  //submit form
  adjustmentFormSubmit(adjustmentValue: any) {
    this.reconcileService
      .adjustmentFormSubmit(adjustmentValue)
      .subscribe((formData: any) => {
        console.log('formSubmitValue >> ', formData);
      });
  }

  // Adjust Type
  filteredAdjusTypesFun(event: any) {
    let adjustmentTypeArr: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.adjustmentTypeId.length; i++) {
      // console.log("adjustmentTypeId >", this.adjustmentTypeId);

      let adjustmentType = this.adjustmentTypeId[i];
      if (adjustmentType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        adjustmentTypeArr.push(adjustmentType);
      }
    }

    this.filteredAdjusTypes = adjustmentTypeArr;
  }

  onChangeCustomer(event: any) {}

  onChangeAdjustType(adjustMentValue: any) {
    console.log('adjustMentValue >', adjustMentValue);
    this.selectedAdjustTypeId = adjustMentValue;
    this.adjustmentTypeValueDrop = adjustMentValue;
    // console.log("filteredAdjusTypes mm> ", this.filteredAdjusTypes);

    this.adjustTypeDropArr.filter((adjustTypeSecectedData: AdjustmentDropdown) => {
      if (adjustTypeSecectedData.adjustmentTypeId === adjustMentValue) {
        console.log('adjustTypeSecectedData', adjustTypeSecectedData);
        this.adjustOptionSelectedVal = adjustTypeSecectedData;
      }
    });
  }

  getAdjustmentTypes() {
    this.reconcileService.getAdjustmentTypes().subscribe((adjustData: any) => {
      adjustData.map((adjustment: any) => {
        //  console.log("getAdjustmentTypes >>", adjustData);
        this.adjustTypeDropArr = adjustData;

        this.adjustmentTypeId.push(adjustment.adjustmentTypeId);
      });
    });
  }

  // Customer
  getCustomer() {
    this.reconcileService.getCustomers().subscribe((customerArr: any) => {
      // console.log("Customer > ", customerArr);
      customerArr.map((customer: any) => {
        this.customerId.push(customer);
      });
    });
  }

  filteredCustomerFun(event: any) {
    let customerArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.customerId.map((customer: any) => {
      if (customer.customerId.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        customerArr.push(customer.customerId);
      }
    });
    this.filteredCustomers = customerArr;
  }

  filteredDriverFn(event: any) {
    let driverArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.driverId.map((company: any) => {
      if (company.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        driverArr.push(company);
      }
    });
    this.filteredDriver = driverArr;
    // console.log("drovers >>", this.filteredDriver );
    
  }
  

  adjustCheckSlection(key: any) {
    // console.log('checkbox >> ', key);
    // if (key === 'S') {
    //   console.log('Key >', key);
    //   this.checkBoxServiceNo = true;
    // } else if (key === 'R') {
    //   this.checkBoxServiceNo = false;
    // }
    this.AdjustRadio.forEach(item => {
      if (item.key === key) {
        item.checked = true;
      } else {
        item.checked = false;
      }
    });
  }




  //service referenc
  searchServiceNo(event: any) {
    const inputVal = event.target.value;
    if (this.checkBoxServiceNo) {
      this.reconcileService
        .getServiceReference(inputVal, this.adjustmentTypeValueDrop)
        .subscribe((serviceData: any) => {
          // console.log('serviceData >>', serviceData.customerId);
          // console.log('filteredAdjusTypes >>', this.customerId);
          this.customerId.filter((customerIdList: any) => {
            if (customerIdList.customerId === serviceData.customerId) {
              // console.log('customerIdList > ', customerIdList);

              //  return customerIdList
              this.selectedCustomerId = customerIdList.customerId;
              // this.rechargeCustomerId = customerIdList.customerId;
            }
          });
          this.adjustmentTabel = serviceData;
        });
    } else {
      const payload: MyPayload = {
        runsheetId: inputVal,
        selectFields: ["runsheetid", "deliverydate", "driver", "driverid", "runsheettypeid", "cntservices"],
      };
      this.reconcileService
        .getRunsheetServiceNoData(payload)
        .subscribe((runsheetData: any) => {
          console.log('runsheetData >> ', runsheetData);
          this.runsheetDriverId = runsheetData.runsheets[0].driverid;
        });
    }
  }

  onChangeDriver(selectedDriverDrop: any) {
    //  console.log("driver selected >> ", selectedDriverDrop);
    //  console.log("all driver  >> ", this.allDriver);

     this.allDriver.filter((driverVal: any) => {
        if(driverVal.companyId === selectedDriverDrop) {
          this.driverIdRequest = driverVal.id;
          // console.log("driverIdRequest", this.driverIdRequest);
          
        }
     })
  }
}
