interface Customer {
    customerId: string
    debtorCode?: string
    customerName?: string
}

interface ServiceType {
    serviceTypeId: string,
    serviceTypeDescription?: string

}

interface GetPeriod {
    
}

interface DrivrsList {
    id: string,
    firstName: string,

} 


// create form

export interface CreateAdjustmentForm {
  id: number
  siteId: number
  serviceDate: number
  serviceNumber: string
  customerId: string
  chargeAmount: number
  fuelLevyAmount: number
  loadNumber: string
  serviceTypeId: string
  driverId: number
  dataSourceId: string
  fuelLevyPercent: number
}



// create adjusment table grid
export interface CreateAdjustment {
    adjustmentInvoiceLineUndocumentedTOs: AdjustmentInvoiceLineUndocumentedTo[]
    adjustmentPayAdviceLineUndocumentedTOs: AdjustmentPayAdviceLineUndocumentedTo[]
  }
  
  export interface AdjustmentInvoiceLineUndocumentedTo {
    id: number
    serviceNo: string
    effectiveDate: number
    type: string
    description: string
    amount: number
    fuelLevy: number
    customerIdRechargeTo: any
    customerId: string
    user: string
  }
  
  export interface AdjustmentPayAdviceLineUndocumentedTo {
    id: number
    serviceNo: string
    runSheetId: number
    effectiveDate: number
    type: string
    description: string
    amount: number
    fuelLevy: number
    driverId: number
    companyId: string
    user: string
  }
  
  export interface AdjustmentDropdown {
    adjustmentTypeId: string
    siteId: number
    adjustmentTypeDesc: string
    adjustInvoice?: boolean
    adjustPayAdvise?: boolean
    negateValue: boolean
    showReCharge: boolean
    requiredServiceId: boolean
    defaultAmt: any
    active: boolean
  }
  

  // export interface AdjustmentType {
  //   customerId: any
  //   adjustmentTypeId: string
  //   siteId: number
  //   adjustmentTypeDesc: string
  //   adjustInvoice: boolean
  //   adjustPayAdvise: boolean
  //   negateValue: boolean
  //   showReCharge: boolean
  //   requiredServiceId: boolean
  //   defaultAmt: any
  //   active: boolean
  // }


  export interface AdjustmentType {
    adjustmentTypeId: string
    effectiveDate: number
    runsheetId: any
    serviceNumber: string
    invoiceLine?: InvoiceLine
    payAdviceLine?: PayAdviceLine
  }
  
  export interface InvoiceLine {
    lineAmount: number
    customerId: string
    rechargeCustomerId: any
    lineText: string
    fuelLevyAmount: number
  }
  
  export interface PayAdviceLine {
    payAmount: number
    lineText: string
    fuelLevyAmount: number
    driverId: number
    rechargeCustomerId: any
  }
  
  