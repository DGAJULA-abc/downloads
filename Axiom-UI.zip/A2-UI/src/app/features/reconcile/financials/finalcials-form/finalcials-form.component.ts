import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { FormBuilder, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';

@Component({
  selector: 'app-finalcials-form',
  templateUrl: './finalcials-form.component.html',
  styleUrls: ['./finalcials-form.component.scss'],
})
export class FinalcialsFormComponent {
  referenceMetaData: any[] = [];
  customerId: any[] = [];
  serviceTypeId: any[] = [];
  // selectedCustomer: any[] | any;
  selectedCustomer: {};
  selectServiceType: {};
  selectedPeriod: '';
  selectServiceDesc: {};

  serviceDesc: any[] | any;
  period: any[] = ['Day', 'Week', 'Month'];
  chargeAmount: any[] | any;
  selectChargeAmount: any[] | any;

  restFormValues: {};
  financialData: any;

  lastCharged: any;

  constructor(
    private reconileService: ReconcileService,
    private fb: FormBuilder,
    private navbarService: NavbarService
  ) {}

  financialForm = this.fb.group({
    customerId: ['', Validators.required],
    serviceTypeId: ['', Validators.required],
    period: ['', Validators.required],
    serviceDesc: ['', Validators.required],
    chargeAmount: ['', Validators.required],
  });

  ngOnInit() {
    this.getFinancialCellData();
    // this.getReferenceMetadata();
    this.getCustomers();
    this.getServiceType();
  }

  financialFormFormSubmit() {
    const formData = {
      chargeAmount: 100,
      customerId: 'LUP001',
      id: 689,
      invoiceExported: false,
      invoiceId: 215869,
      lastCharged: 1598882400000,
      period: 'Week',
      serviceDesc: 'dha',
      serviceTypeId: 'DELIVERY',
    };

    const formData2 = {
      id: 678,
      customerId: 'LUP001',
      serviceTypeId: 'DELIVERY',
      serviceDesc: 'dhava',
      period: 'Week',
      chargeAmount: 100,
      lastCharged: 11232000,
      invoiceId: 215887,
      invoiceExported: false,
    };
    const RealformData = {
      chargeAmount: 100,
      customerId: 'LUP001',
      lastCharged: '',
      period: 'Week',
      serviceDesc: 'dha',
      serviceTypeId: 'DELIVERY',
    };
    const rowDataObj = {
      id: this.financialData.id,
      invoiceId: this.financialData.invoiceId,
      invoiceExported: this.financialData.invoiceExported,
      lastCharged: this.financialData.lastCharged
    };
    const financialFormMerge = { ...this.financialForm.value, ...rowDataObj };
    console.log('financialFormFormSubmit >>', financialFormMerge);
    this.postPeriodicCharges(financialFormMerge);
  }

  getFinancialCellData() {
    this.reconileService.getCellSubdata.subscribe((financialData: any) => {
      // console.log('financialData >', financialData);
      console.log('financialData data >', financialData.data);
      this.financialData = financialData.data;
      this.selectedCustomer = financialData?.data?.customerId;
      this.selectServiceType = financialData?.data?.serviceTypeId;
      this.selectedPeriod = financialData?.data?.period;

      this.selectServiceDesc = financialData?.data?.serviceDesc;
      this.selectChargeAmount = financialData?.data?.chargeAmount;
      this.lastCharged = moment(financialData?.data?.lastCharged).format('L');
    });
  }

  getCustomers() {
    this.reconileService.getCustomers().subscribe((customersArr: any) => {
      customersArr.map((customer: any) => {
        this.customerId.push(customer.customerId);
      });
    });
  }

  getServiceType() {
    this.reconileService.getServiceType().subscribe((serviceTypeArr: any) => {
      // console.log("serviceTypeArr >>", serviceTypeArr);
      serviceTypeArr.map((serviceType: any) => {
        this.serviceTypeId.push(serviceType.serviceTypeId);
      });
    });
  }

  postPeriodicCharges(chargeFormData: any) {
    this.reconileService
      .postPeriodicCharges(chargeFormData)
      .subscribe((chargeFormData: any) => {
        console.log('chargeFormData >>', chargeFormData);
      });
  }

  getReferenceMetadata() {
    this.navbarService.referenceMetadataSubject.subscribe(
      (referenceData: any) => {
        // console.log('referenceMetadataSubject > ', referenceData);
        // referenceData.map((customers: any) => {
        // console.log("Customers >>", customers.customers);
        // })
      }
    );
  }
}
