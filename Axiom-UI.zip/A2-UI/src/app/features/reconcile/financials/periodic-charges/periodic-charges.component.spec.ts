import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodicChargesComponent } from './periodic-charges.component';

describe('PeriodicChargesComponent', () => {
  let component: PeriodicChargesComponent;
  let fixture: ComponentFixture<PeriodicChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PeriodicChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PeriodicChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
