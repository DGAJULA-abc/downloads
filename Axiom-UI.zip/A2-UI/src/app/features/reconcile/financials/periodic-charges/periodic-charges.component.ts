import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { CellrenderComponent } from '../../list-incomplete-services/cellrender/cellrender.component';

@Component({
  selector: 'app-periodic-charges',
  templateUrl: './periodic-charges.component.html',
  styleUrls: ['./periodic-charges.component.scss']
})
export class PeriodicChargesComponent {
  showPanelLeft: boolean = false;
  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'id', headerName: 'Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'customerId', headerName: 'Service Type Id'},
    { field: 'serviceTypeId', headerName: 'Delivery Date'},
    { field: 'period', headerName: 'Period'},
    { field: 'serviceDesc', headerName: 'Description'},
    { field: 'chargeAmount', headerName: 'Amount'},
    { field: 'lastCharged', headerName: 'Last applied'},
    { field: 'invoiceId', headerName: 'Invoice No'},
    { field: 'invoiceExported', headerName: 'Invoice Exported'},
  ];

  showRunsheetDetail: boolean = true;
  constructor(private reconcileService: ReconcileService) {}
 

  ngOnInit(): void {
    this.getRowData();
    this.showPanel();
    this.reconcileService.reloadGrid.subscribe(res => {
      console.log("reload Data> ", res);
      this.getRowData();
     });
  }

  getRowData() {
    this.reconcileService.getPeriodicCharges()
   .subscribe(
     (result: any) => {
       console.log("result getPeriodicCharges > ", result);
       
       this.rowData = result;
     }
   );
  }

  showPanel() {
    this.reconcileService.panelBehSubject.subscribe(res => {
      console.log("show Left Panel> ", res);
      
      this.showPanelLeft = res;
     });
  }

}


