import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { CellrenderComponent } from '../../list-incomplete-services/cellrender/cellrender.component';

@Component({
  selector: 'app-periodic-payments',
  templateUrl: './periodic-payments.component.html',
  styleUrls: ['./periodic-payments.component.scss']
})
export class PeriodicPaymentsComponent {
  showPanelLeft: boolean = false;
  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'id', headerName: 'Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'driverId', headerName: 'Service Type Id'},
    { field: 'companyId', headerName: 'Company Id'},
    { field: 'serviceTypeId', headerName: 'Service Type ID'},
    { field: 'period', headerName: 'Period'},
    { field: 'serviceDesc', headerName: 'Description'},
    { field: 'chargeAmount', headerName: 'Amount'},
    { field: 'lastCharged', headerName: 'Last applied'},
    { field: 'glCode', headerName: 'GL Code'},
    { field: 'payAdviceId', headerName: 'Pay Advice Id'},
    { field: 'payAdviceExported', headerName: 'Pay Advice Exported'},
  ];

  showRunsheetDetail: boolean = true;
  constructor(private reconcileService: ReconcileService) {}
 

  ngOnInit(): void {
    this.getRowData();
    this.showPanel();
    this.reconcileService.reloadGrid.subscribe(res => {
      console.log("reload Data> ", res);
      this.getRowData();
     });
  }

  getRowData() {
    this.reconcileService.getPeriodicPayments()
   .subscribe(
     (result: any) => {
       console.log("result getPeriodicPayments > ", result);
       
       this.rowData = result;
     }
   );
  }

  showPanel() {
    this.reconcileService.panelBehSubject.subscribe(res => {
      console.log("show Left Panel> ", res);
      
      this.showPanelLeft = res;
     });
  }

}


