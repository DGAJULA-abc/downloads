import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { ReconcileService } from '../../../services/reconcile.service';

@Component({
  selector: 'app-perodic-payment-form',
  templateUrl: './perodic-payment-form.component.html',
  styleUrls: ['./perodic-payment-form.component.scss'],
})
export class PerodicPaymentFormComponent {
  referenceMetaData: any[] = [];
  customers: any[] = [];
  // selectedCustomer: any[] | any;
  selectedCustomer: { id: 'LUP001'; customerName: 'LUP001' };

  serviceDesc: any[] | any;
  period: any[] = ['Day', 'Week', 'Month'];
  chargeAmount: any[] | any;
  lastCharged: any;

  driverId: any[] = [];
  selectedDriverId = {};
  serviceTypeId: any[] = [];
  glCode: any = 'glcode';

  companyId: any[] = [];
  selectedCompanyId: {};

  selectedServiceTypeId: any;
  restRowTableValue: any;
  selectedPeriod: any;
  

  constructor(
    private reconileService: ReconcileService,
    private fb: FormBuilder,
    private navbarService: NavbarService
  ) {}

  financialPaymentForm = this.fb.group({
    driverId: ['', Validators.required],
    serviceTypeId: ['', Validators.required],
    companyId: ['', Validators.required],
    period: ['', Validators.required],
    serviceDesc: ['', Validators.required],
    chargeAmount: ['', Validators.required],
    glCode: ['', Validators.required],
    lastCharged: [''],
  });

  ngOnInit() {
    this.getFinancialCellData();
    // this.getReferenceMetadata();
    this.getDriver();
    this.getCompany();
    // this.getCustomers();
    this.getServiceType();
  }

  financialFormFormSubmit() {
    const rowFormData = {
      id: this.restRowTableValue.id,
      lastCharged: this.restRowTableValue.lastCharged,
      payAdviceId: this.restRowTableValue.payAdviceId,
      payAdviceExported: this.restRowTableValue.payAdviceExported,
    }
 
    const payFormMerge = {...this.financialPaymentForm.value, ...rowFormData};
    console.log("payFormMerge ?> ", payFormMerge);
    
    this.postPeriodicPayment(payFormMerge);
  }

  getFinancialCellData() {
    this.reconileService.getCellSubdata.subscribe((financialData: any) => {
      // console.log('financialData >', financialData);
      this.restRowTableValue = financialData.data;
      console.log('financialData data >', financialData.data);
      this.selectedServiceTypeId = financialData?.data?.serviceTypeId;
      // this.selectedDriverId = financialData?.data?.serviceTypeId;
       this.selectedCompanyId = financialData?.data?.companyId;
      this.serviceDesc = financialData?.data?.serviceDesc;
      this.chargeAmount = financialData?.data?.chargeAmount;
      this.selectedPeriod = financialData?.data?.period;
      this.lastCharged = moment(financialData?.data?.lastCharged).format('L');
    });
  }

  getDriver() {
    this.reconileService.getDriver().subscribe((drivers: any) => {
      console.log('driversList >>', drivers);
      drivers.map((driver: any) => {
        // const driverFullName = `${driver.surname} ${driver.employeeName} ${driver.companyId}`
        
        // let driverObj = { id: driver.driverId, name: driver.firstName };
        this.driverId.push(driver.companyId);
      });
    });
  }

  getCompany() {
    this.reconileService.getCompany().subscribe((companies: any) => {
      console.log('Company >>', companies);
      companies.map((company: any) => {
        // let companyObj = { id: company.companyId, name: company.payAdviceId };
        this.companyId.push(company.companyId);
      });
    });
  }

  getServiceType() {
    this.reconileService.getServiceType().subscribe((serviceTypeArr: any) => {
      // console.log("serviceTypeArr >>", serviceTypeArr);
      serviceTypeArr.map((serviceType: any) => {
        this.serviceTypeId
        .push(serviceType.serviceTypeId);
      });
    });
  }

  postPeriodicPayment(chargeFormData: any) {
    this.reconileService
      .perdiocPaymentFormApi(chargeFormData)
      .subscribe((chargeFormData: any) => {
        console.log('chargeFormData >>', chargeFormData);
      });
  }

  getReferenceMetadata() {
    this.navbarService.referenceMetadataSubject.subscribe(
      (referenceData: any) => {
        // console.log('referenceMetadataSubject > ', referenceData);
        // referenceData.map((customers: any) => {
        // console.log("Customers >>", customers.customers);
        // })
      }
    );
  }
}
