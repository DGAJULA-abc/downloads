import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { invalid } from 'moment';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-invoice-details',
  templateUrl: './invoice-details.component.html',
  styleUrls: ['./invoice-details.component.scss']
})
export class InvoiceDetailsComponent {
  isPrintInvoicePage: Boolean = false;
  isPayAdvicePage: Boolean = false;
  public columnDefs: any[];
  public columnDefsForInvoice: any[] = [
    { field: 'id', headerName: 'Id' },
    { field: 'serviceNumber', headerName: 'Service'},
    { field: 'effectiveDate', headerName: 'Effective Date',cellRenderer: (data:any) => {
      return moment(data.value).format('DD/MM/YY')
  }},
    { field: 'lineText', headerName: 'Description' },
    { field: 'lineAmount', headerName: 'Amount'},
    { field: 'invoicePeriod', headerName: 'Period'}];

    public columnDefsForPayAdvices: any[] = [
      { field: 'id', headerName: 'Id', width:50 },
      { field: 'serviceNumber', headerName: 'Driver', width:100},
      { field: 'effectivedate', headerName: 'Effective Date',width:100, cellRenderer: (data:any) => {
        return moment(data.value).format('DD/MM/YY')
    }},
      { field: 'linetext', headerName: 'Description' , width:250},
      { field: 'payamt', headerName: 'Amount', width:50}];

    public rowData :any[];
    public invoiceDetails:any = {};
    applyGST :boolean = true;
   
    constructor(private route : ActivatedRoute, private router : Router,private reconsileService :ReconcileService) {

    }

    ngOnInit(){
      const id = this.route.snapshot.paramMap.get('id');
      console.log(this.router.url)
      if(this.router.url.includes('PrintPayAdvices')) {
        this.isPayAdvicePage = true;
        this.columnDefs = this.columnDefsForPayAdvices;
       this.getPayAdviceDetails(id);
      }else{
        this.isPrintInvoicePage = true;
        this.columnDefs = this.columnDefsForInvoice;
        this.getInvoiceDetails(id);
      }
      
    } 

    getInvoiceDetails(id: any) {
      console.log("id :", id);
      this.reconsileService
      .getInvoiceDeatails(id)
      .subscribe((res: any) => {
         console.log(' data >>>>', res);
         this.invoiceDetails = res.invoice;
         this.rowData = res.lines;
         this.applyGST = this.invoiceDetails.applyGST;
        //this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;

      });

    }

    
    getPayAdviceDetails(id: any) {
      console.log("id pay advice:", id);
      this.reconsileService
      .getPayAdviceDetails(id)
      .subscribe((res: any) => {
         console.log(' data pay advice>>>>', res);
         this.invoiceDetails = res.payAdvice;
         this.rowData = res.lines;
         this.applyGST = this.invoiceDetails.applyGST;
        //this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;

      });

    }

}
