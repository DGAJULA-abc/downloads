
import { Component } from '@angular/core';
import { Router } from '@angular/router';
//import { AgRendererComponent } from 'ag-grid-angular';

@Component({
  template:
    '',
})
export class LinkRendererComponent {
  params: any;

  constructor( private router: Router) {}

//   agInit(params: any): void {
//     console.log(params);
//     this.params = params;
//   }

//   refresh(params: any): boolean {
//     return false;
//   }

//   // This was needed to make the link work correctly
//   navigate() {
//     console.log("called");
//     this.ngZone.run(() => {
// //      this.router.navigate([link, this.params.value]);
//     });
//   }
}
