import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCompleteRunsheetsComponent } from './list-complete-runsheets.component';

describe('ListCompleteRunsheetsComponent', () => {
  let component: ListCompleteRunsheetsComponent;
  let fixture: ComponentFixture<ListCompleteRunsheetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCompleteRunsheetsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListCompleteRunsheetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
