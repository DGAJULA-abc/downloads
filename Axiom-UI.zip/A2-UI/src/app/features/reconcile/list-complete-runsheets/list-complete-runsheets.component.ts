import { Component, EventEmitter, Output, ViewChild } from '@angular/core';

import { CellrenderComponent } from '../list-incomplete-services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';
import { FormBuilder, NgForm, Validators, FormGroup } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-list-complete-runsheets',
  templateUrl: './list-complete-runsheets.component.html',
  styleUrls: ['./list-complete-runsheets.component.scss'],
})
export class ListCompleteRunsheetsComponent {

  // @ViewChild(NgForm) form: NgForm;
  val = "Initial value";
  submitted: {};
  rightTitle: string = 'List Complete Runsheet';
  date: Date | undefined;
  

  @Output() not: EventEmitter<string> = new EventEmitter<string>();
  showPanelLeft: boolean = false;
  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'runsheetid', headerName: 'Runsheet Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'runsheettypeid', headerName: 'Runsheet Type Id'},
    { field: 'deliverydate', headerName: 'Delivery Date'},
    { field: 'publicholidayapplies', headerName: 'Public Holiday Applies'},
    { field: 'driverid', headerName: 'Driver Id'},
    { field: 'driver', headerName: 'Driver'},

  ];

  showRunsheetDetail: boolean = true;
  constructor(private reconcileService: ReconcileService, private fb: FormBuilder) {}
 
  listForm = this.fb.group({
    deliveryFrom: ['', Validators.required],
    deliveryTo: ['', Validators.required]
  })

  ngOnInit(): void {
    // this.getRowData();
    this.showPanel();
  }

  ListCompleteRunsheetSubmit() {
  //  const deliveryDate = this.listForm.value.deliveryFrom;
  //   new Date(deliveryDate)
   const  listFormSubmit = {
    deliveryFrom:  moment(this.listForm.value.deliveryFrom, "YYYY-MM-DD HH:mm:ss").format("x"),
    deliveryTo: moment(this.listForm.value.deliveryTo, "YYYY-MM-DD HH:mm:ss").format("x")
     }

     this.reconcileService.getListCompleteRunsheet(listFormSubmit)
   .subscribe(
     (result: any) => {
       console.log("result complete runsheet data > ", result);
       
       this.rowData = result.runsheets
     }
   );

    
  }


  showPanel() {
    this.reconcileService.panelBehSubject.subscribe(res => {
      console.log("show Left Panel> ", res);
      
      this.showPanelLeft = res;
     });
}

}