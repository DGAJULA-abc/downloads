import { Component } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';
import { CellrenderComponent } from '../list-incomplete-services/cellrender/cellrender.component';

@Component({
  selector: 'app-list-incomplete-runsheets',
  templateUrl: './list-incomplete-runsheets.component.html',
  styleUrls: ['./list-incomplete-runsheets.component.scss']
})
export class ListIncompleteRunsheetsComponent {

  showPanelLeft: boolean = false;
  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'runsheetid', headerName: 'Runsheet Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'runsheettypeid', headerName: 'Runsheet Type Id'},
    { field: 'deliverydate', headerName: 'Delivery Date'},
    { field: 'publicholidayapplies', headerName: 'Public Holiday Applies'},
    { field: 'driverid', headerName: 'Driver Id'},
    { field: 'driver', headerName: 'Driver'},

  ];

  showRunsheetDetail: boolean = true;
  constructor(private reconcileService: ReconcileService) {}
 

  ngOnInit(): void {
    this.getRowData();
    this.showPanel();
    this.reconcileService.reloadGrid.subscribe(res => {
      console.log("reload Data> ", res);
      this.getRowData();
     });
  }

  getRowData() {
    this.reconcileService.getListIncompleteRunsheet()
   .subscribe(
     (result: any) => {
       console.log("result getListIncompleteRunsheet > ", result);
       
       this.rowData = result.runsheets
     }
   );
  }

  showPanel() {
    this.reconcileService.panelBehSubject.subscribe(res => {
      console.log("show Left Panel> ", res);
      
      this.showPanelLeft = res;
     });
  }

}
