import { Component, Input } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { ReconcileService } from '../../services/reconcile.service';

@Component({
  selector: 'app-cellrender',
  templateUrl: './cellrender.component.html',
  styleUrls: ['./cellrender.component.scss']
})
export class CellrenderComponent implements ICellRendererAngularComp{
  rowCheckData: any = "";
  params: any;
  
  constructor(private reconsileService: ReconcileService) {
      
  }

  agInit(params: ICellRendererParams<any, any, any>): void {
    this.params = params;
    //  params.value = this.rowCheckData;
      // throw new Error('Method not Implemented');
  }

  refresh(params: ICellRendererParams<any, any, any>): boolean {
    return false;
    // throw new Error('Method not Implemented');
  }

  ngOninit(): void {
     
  }

  getRowIdData(event: any) {
    //this.reconsileService.panelBehSubject.next(true);
    this.reconsileService.setCellSubData(this.params, event.target.checked)
    // console.log("Check Ag box", event.target.checked);
    
  }

}
