import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListIncompleteServicesComponent } from './list-incomplete-services.component';

describe('ListIncompleteServicesComponent', () => {
  let component: ListIncompleteServicesComponent;
  let fixture: ComponentFixture<ListIncompleteServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListIncompleteServicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListIncompleteServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
