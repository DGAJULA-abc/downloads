import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  CheckboxSelectionCallbackParams,
  ColDef,
  HeaderCheckboxSelectionCallbackParams,
  IGroupCellRendererParams,
} from 'ag-grid-community';
import { SearchService } from '../../search/services/search.service';
import { ReconcileService } from '../services/reconcile.service';
import { ListIncompleteReconcile } from '../models/view.reconcile.model';
// import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { CellrenderComponent } from './cellrender/cellrender.component';
import { ServiceDateCycle, TripDateCycle } from '../../plan/models/plan.model';
import { SharedService } from 'src/app/shared/services/shared.service';

// import { SearchService } from '../services/search.service';

@Component({
  selector: 'app-list-incomplete-services',
  templateUrl: './list-incomplete-services.component.html',
  styleUrls: ['./list-incomplete-services.component.scss'],
})
export class ListIncompleteServicesComponent {
  rightTitle: string = 'Create Invoices';
  @Output() not: EventEmitter<string> = new EventEmitter<string>();
  // selectedTrip: any;
  // selectedServices: ServiceDateCycle[];
  selectedTripService: any;

  editForm: TripDateCycle | null;

  public columnDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'docket',
      headerName: 'Docket',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'serviceid',
      headerName: 'Service ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'serviceno',
      headerName: 'Service No.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicetypeid',
      headerName: 'Service type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicedate',
      headerName: 'Service Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },
    {
      field: 'customerid',
      headerName: 'Customer ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customergroupid',
      headerName: 'Customer Group',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'truckid',
      headerName: 'Truck',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'trailerid',
      headerName: 'Trailer',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'containerid',
      headerName: 'Container',
      type: 'container',
    },
    {
      field: 'containertypeid',
      headerName: 'Container type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid_pickup',
      headerName: 'Location Pickup',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid_drop',
      headerName: 'Location Drop',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'enteredby',
      headerName: 'Entered by',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadid',
      headerName: 'Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtydesc',
      headerName: 'Qty Desc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locations',
      headerName: 'Locations',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
    },
    {
      field: 'originsite',
      headerName: 'Origin Site',
      type: 'site',
    },
    {
      field: 'destinationsite',
      headerName: 'Destination Site',
      type: 'site',
    },
    {
      field: 'originloc',
      headerName: 'Origin Loc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'destinationloc',
      headerName: 'Destination Loc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'invoiceid',
      headerName: 'Invoice',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'employeefield',
      headerName: 'Employee field',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'firstfield',
      headerName: 'Firstfield',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'lastfield',
      headerName: 'Lastfield',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customerid_load',
      headerName: 'Customer ID Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadno',
      headerName: 'Load No.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadtypeid',
      headerName: 'Load type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'scheduleddate',
      headerName: 'Scheduled Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },
    {
      field: 'holdcode_load',
      headerName: 'Holdcode Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'complete_load',
      headerName: 'Complete Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'batchno',
      headerName: 'ConNote',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid',
      headerName: 'Location',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'custreference',
      headerName: 'Cust Ref.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customergroupid_load',
      headerName: 'Customer Group Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty1',
      headerName: 'Qty 1',
      type: 'DECIMAL',
    },
    {
      field: 'unit1',
      headerName: 'Unit 1',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty2',
      headerName: 'Qty 2',
      type: 'DECIMAL',
    },
    {
      field: 'unit2',
      headerName: 'Unit 2',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty3',
      headerName: 'Qty 3',
      type: 'DECIMAL',
    },
    {
      field: 'unit3',
      headerName: 'Unit 3',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty4',
      headerName: 'Qty 4',
      type: 'DECIMAL',
    },
    {
      field: 'unit4',
      headerName: 'Unit 4',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty5',
      headerName: 'Qty 5',
      type: 'DECIMAL',
    },
    {
      field: 'unit5',
      headerName: 'Unit 5',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty6',
      headerName: 'Qty 6',
      type: 'DECIMAL',
    },
    {
      field: 'unit6',
      headerName: 'Unit 6',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty7',
      headerName: 'Qty 7',
      type: 'DECIMAL',
    },
    {
      field: 'unit7',
      headerName: 'Unit 7',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty8',
      headerName: 'Qty 8',
      type: 'DECIMAL',
    },
    {
      field: 'unit8',
      headerName: 'Unit 8',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtya',
      headerName: 'Qty A',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyb',
      headerName: 'Qty B',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyc',
      headerName: 'Qty C',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyd',
      headerName: 'Qty D',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtye',
      headerName: 'Qty E',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyf',
      headerName: 'Qty F',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyg',
      headerName: 'Qty G',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyh',
      headerName: 'Qty H',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'sloadtype',
      headerName: 'S Load type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'trailerid_tag',
      headerName: 'Trailer Tag',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'chargeamt',
      headerName: 'Charge Amount',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'rateid',
      headerName: 'Rate',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'driverrate',
      headerName: 'Driver Rate',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'driverpay',
      headerName: 'Driver Pay',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripid_cust',
      headerName: 'Trip Cust',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'datasourceid',
      headerName: 'Datasource',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripid',
      headerName: 'Trip',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripdate',
      headerName: 'Trip Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },
    {
      field: 'driver',
      headerName: 'Driver',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'used',
      headerName: 'Used',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicedesc',
      headerName: 'Service Desc',
      type: 'TEXT',
      minWidth: 120,
    },
  ];

  public autoGroupColumnDef: ColDef = {
    headerName: 'Group',
    minWidth: 170,
    field: 'runsheetid',
    valueGetter: (params) => {
      if (params.node!.group) {
        return params.node!.key;
      } else {
        return params.data[params.colDef.field!];
      }
    },
    headerCheckboxSelection: true,
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true,
    } as IGroupCellRendererParams,
  };

  public rowSelection: 'single' | 'multiple' = 'multiple';
  public rowGroupPanelShow: 'always' | 'onlyWhenGrouping' | 'never' = 'always';
  public pivotPanelShow: 'always' | 'onlyWhenPivoting' | 'never' = 'always';

  public defaultColDef: ColDef = {
    flex: 1,
    // minWidth: 180,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

  showRunsheetDetail: boolean = true;

  public rowData: ListIncompleteReconcile[] | null;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;

  constructor(
    private reconcileService: ReconcileService,
    private sharedService: SharedService,
    private searchServices: SearchService
  ) {}

  ngOnInit(): void {
    this.not.emit(this.rightTitle);
    this.onGridReady();
  }

  onGridReady() {
    this.reconcileService
      .getListIncompleteService()
      .subscribe((result: any) => {
        console.log('result incompplete > ', result);

        this.rowData = result.services;
      });

    //  this.searchFormDetails = event;
    // this.searchServices.getRunsheetList(event).subscribe((result: any) => {
    //   this.rowData = result.runsheets;
    //   // this.pagination.pageNumber = 1;
    //   // this.totalRecords = result.pagination.totalRecords;

    // });
  }

  onCellClicked(e: any): void {
    console.log('cellClicked', e);
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
      debugger;
      this.selectedTripANdServicesList(this.editForm!.id);
    }
    //this.selectedTrip = event.api.getSelectedNodes();
  }
  selectedServices: ServiceDateCycle;
  selectedTrip: TripDateCycle[];
  selectedTripANdServicesList(tripid: number) {
    this.sharedService.geServiceDetailsByid(tripid).subscribe((result: any) => {
      this.selectedServices = result;
      if (this.selectedServices.tripId) {
          this.sharedService
            .getTripDetails(this.selectedServices.tripId)
            .subscribe((result) => {
              this.selectedTrip= result.trips;
            });
      }
    });
  }
}
