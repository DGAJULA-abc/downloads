import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CellrenderComponent } from '../cellrender/cellrender.component';

@Component({
  selector: 'app-view-runsheet',
  templateUrl: './view-runsheet.component.html',
  styleUrls: ['./view-runsheet.component.scss']
})
export class ViewRunsheetComponent {
  viewListDataGrid: any;
  runSheetId: string = '';

  rowData: any[] = [];
   columnDefs: any[] = [
    { field: 'runsheetid', headerName: 'Runsheet Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'tripseq', headerName: 'Seq'},
    { field: 'loadTypeId', headerName: 'Load Type Id'},
    { field: 'serviceId', headerName: 'Service Id'},
    { field: 'serviceTypeId', headerName: 'Service Type Id'},
    { field: 'truckId', headerName: 'Truck Id'},

  ];

  constructor(private reconileService: ReconcileService, private router: Router, private activatedRoute: ActivatedRoute) {

  }

  ngOnInit() {
    this.getViewCellData();
  }

  getViewCellData() {
    this.reconileService.getCellSubdata.subscribe((viewListData: any) => {
     this.runsheetIdData(viewListData.data.runsheetid);
     this.runSheetId = viewListData.data.runsheetid;
    }
    )
  }
  
  runsheetIdData(runSheetId: any) {
      this.reconileService.getViewRunsheetId(runSheetId).subscribe((idData) => {
        console.log("idData >> ", idData);
        this.viewListDataGrid = idData.runsheet;
        if(idData.runsheet?.runsheetLines) {
              console.log("runsheetLines >>", idData.runsheet.runsheetLines);
              this.rowData =  idData.runsheet.runsheetLines;
        }    
      })
  }



  viewRunsheetPage() {
    this.router.navigate(
      ['reconcile/ViewRunsheet'], 
      {
        queryParams: { runsheetId: this.runSheetId },
        queryParamsHandling: 'merge'
      })
      // .then(data => this.reloadCurrentRoute())
  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('reconcile/ViewRunsheet', {skipLocationChange: true}).then(() => {
        this.router.navigate([currentUrl]);
    });
  }
}
