import { NONE_TYPE } from '@angular/compiler';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { InvoicePreview, InvoicePreviewRequest } from '../../reportview/model/report-view.model';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-print-custom-page',
  templateUrl: './print-custom-page.component.html',
  styleUrls: ['./print-custom-page.component.scss']
})
export class PrintCustomPageComponent {

  rightTitle: string = 'Print Custom Page';
  gridOptions: any;
  displayStyle = "none";
  @Input() statusList: any;
  @Input() columnDefs: any;
  @Input() rowData: any;
  @Input() printMenu: any;
  @Input() pageName: any;
  @Output() not: EventEmitter<string> = new EventEmitter<string>();
  applyGST: boolean = false;
  checkboxValue: boolean = false;
  ok: boolean = false;
  sum: number = 0;
  isDivVisible: boolean = false;
  selectedRow: any = null;
  checkboxClicked: boolean = false;
  invoiceDetails: any = {};
  lines: any = []
  dataSource: any = [];
  selectedIds: any = [];
  showZero: boolean= false;
  displayedColumns: string[] = ['demo-position', 'demo-name', 'demo-weight', 'demo-symbol', 'demo-amount'];
  public invoiceMenu = [{ 'name': 'Standard Invoice' }, { 'name': 'Detailed Wide Format (Service Drop)' }, { 'name': 'Load Level Summary' }, { 'name': 'Date Level Summary' }, { 'name': 'Cover Page' }, { 'name': 'Service Type/Location Summary' }, { 'name': 'Detailed Wide Format' }, { 'name': 'Wide Format With Load#(5 Units)' }, { 'name': 'Service Type/Location Summary/Rate' }, { 'name': 'Detailed Wide Format/Rate' }, { 'name': 'Trip-Based' }, { 'name': 'Special' },
  { 'name': 'Detailed Wide Format(Loc Number)' }, { 'name': 'Cover Page With Breakdown' }, { 'name': 'Customer Report' }]

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

  constructor(private reconsileService: ReconcileService) {
    //this.setColumns();
    this.gridOptions = {
      context: { Component: this }
    }

  }

  rightSideForm(event: any) {
    const clickedRowData = event.data;
    event.api.forEachNode((node: { data: { isChecked: boolean; }; }) => {
      node.data.isChecked = false;
    });
    event.api.redrawRows();
    if (this.selectedRow) {
      this.selectedRow.isChecked = false;
    }
    clickedRowData.isChecked = true;
    this.selectedRow = clickedRowData;
    event.api.redrawRows({ rowNodes: [event.node] });
    this.sum = 1;
    this.isDivVisible = true;
    this.ok = true;
    if (this.sum > 1) {
      this.isDivVisible = false;
      this.ok = false;
    }

    this.reconsileService
      .getInvoiceDeatails(event.data.id)
      .subscribe((res: any) => {
        console.log(' data >>>>', res);
        this.invoiceDetails = res.invoice;
        this.lines = res.lines;
        this.dataSource = this.lines;
      }
      )
  }

  setCellSubData(intvalue: any, selectedRows: any, checkboxEnabled: boolean) {

    if (intvalue == 0) {
      this.sum = 0
    }
    this.sum += intvalue;
    console.log("selected rows", this.selectedIds, this.sum);
    if (this.sum === 1) {
      console.log("right")
      this.isDivVisible = this.ok = true;
      this.ok = true;
      this.invoiceDetailsfunction(selectedRows)
    } else {
      this.ok = false;
      this.isDivVisible = false;
    }

    if (checkboxEnabled) {
      this.selectedIds.push(selectedRows);
    } else {
      if (this.selectedIds.includes(selectedRows)) {
        this.selectedIds = this.selectedIds.filter((id: any) => id !== selectedRows);
      }
    }


  }




  updateStatus(status: any) {
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .updatePayAdviceStatus(this.selectedIds, status)
        .subscribe((res: any) => {
          this.getRowData();
        });

    } else if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .updateInvoiceStatus(this.selectedIds, status)
        .subscribe((res: any) => {
          this.getRowData();
        });
    }
  }


  deleteRows() {
    if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .deleteInvoices(this.selectedIds)
        .subscribe((res: any) => {
          this.getRowData();
          this.closePopup();
          window.location.reload();
        });
    }
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .deletePayAdvices(this.selectedIds)
        .subscribe((res: any) => {
          this.getRowData();
          this.closePopup();
          window.location.reload();
        });

    }

  }
  invoiceDetailsfunction(id: any) {
    console.log("details:", id);
    if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .getInvoiceDeatails(id)
        .subscribe((res: any) => {
          console.log(' data >>>>', res);
          this.invoiceDetails = res.invoice;
          this.lines = res.lines;
          this.dataSource = this.lines;
          this.applyGST = res.invoice.applyGST;
        });
    }

    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .getPayAdviceDetails(id)
        .subscribe((res: any) => {
          console.log(' data pay advice>>>>', res);
          this.invoiceDetails = res.payAdvice;
          this.dataSource = res.lines;
          console.log(this.dataSource)
        });
    }

  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  getRowData() {
    this.checkboxValue = !this.checkboxValue;
    if (this.pageName === 'PrintPayAdvicesComponent') {

      this.reconsileService.getPrintPayAdvices(this.checkboxValue)
        .subscribe(
          (result: any) => {
            console.log("result getPrintPayAdvices > ", result);

            this.rowData = result.payadvices;
          }
        );

    } else if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService.getPrintInvoices(this.checkboxValue)
        .subscribe(
          (result: any) => {
            console.log("result getPrintInvoices > ", result);

            this.rowData = result.invoices;
            console.log("rowdata:", this.rowData);
          }
        );
    }
  }



  onPrintWithCustomerFormatClick(printMenu: any) {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    console.log(this.invoiceDetails);
    let invoicesParam: InvoicePreview[] = [{
      id: this.invoiceDetails.id,
      siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
      documenttype: printMenu == 'CustomerFormat' ? 'Invoice' : 'Credit Note',
      exported: this.invoiceDetails.exported,
      invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      cnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
      defaultinvformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : null,
      defaultcnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : null
    }];

    // create request params
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: printMenu == 'CustomerFormat' ? true : false,
      cnFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
      invFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      showZero: this.showZero,
      invoices: invoicesParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

    // open report view window
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  }

  onPrintInvoiceFormatClick() {
    console.log(this.invoiceDetails)
    // TODO: this is just mock parameters. replace with data from selected rows in grid that are documenttype='Invoice' only
    let invoicesParam: InvoicePreview[] = [{
      id: this.invoiceDetails.id,
      siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
      documenttype: 'Invoice',
      exported: this.invoiceDetails.exported,
      invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      cnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
      defaultinvformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : null,
      defaultcnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : null
    }];


    // create request params
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: false,
      cnFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
      invFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      showZero: this.showZero,      invoices: invoicesParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

    // open report view window
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  }
}
