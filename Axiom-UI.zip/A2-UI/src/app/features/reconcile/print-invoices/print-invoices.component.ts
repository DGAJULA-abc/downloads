import { Component, EventEmitter, Input, Output } from '@angular/core';
import * as moment from 'moment';
import { LinkRendererComponent } from '../link-renderer/link-renderer.component';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-print-invoices',
  templateUrl: './print-invoices.component.html',
  styleUrls: ['./print-invoices.component.scss']
})
export class PrintInvoicesComponent {
  constructor(private reconcileService: ReconcileService) {
    this.getRowData();
  }
  public columnDefs: any[] = [
    { field: ' ', headerName: ' ', cellRenderer: CellrenderComponent, cellRendererParams: {
      selectedRow: null}
    },
    { field: 'id', headerName: 'Pay Advice No',         cellRenderer: (id:any) => 
    `<a style="color:#00aaa6!important" href="reconcile/PrintInvoices/invoiceDetails/${id.value}" >${id.value}</a>` ,
    } ,
    { field: 'fromdate', headerName: 'From',  cellRenderer: (data:any) => {
      return moment(data.value).format('MM/DD/YYYY HH:mm')
  }},
    { field: 'todate', headerName: 'To', cellRenderer: (data:any) => {
      return moment(data.value).format('DD/MM/YY')
  }},
    { field: 'customerid', headerName: 'Company Code'},
    { field: 'customerid', headerName: 'Company Type'},
    { field: 'invoicestatusid', headerName: 'Status'},
    { field: 'fuellevy', headerName: 'Description'},
    { field: 'issueDate', headerName: 'Issue Date',  cellRenderer: (data:any) => {
      return moment(data.value).format('DD/MM/YY')
  }},
    { field: 'baseexgst', headerName: 'Base Ex GST'},
    { field: 'totalexgst', headerName: 'Total Ex GST'},
    { field: 'created', headerName: 'Created On',cellRenderer: (data:any) => {
      return moment(data.value).format('MM/DD/YYYY HH:mm')
  }}
    
    
  ];
 public statusList = [{name:"Ready"},{name:"Hold"},{name:"Printed"}];
  public printMenu = [{name:"Include zero value lines", value:"withzerolines"},{name:"Print with customer format", value: "withcustomerformat"},{name:"Print creadit notes with format", value:"creditnotesformat"},{name:"Print invoices with format", value:"printInvoiceFormat"}]
  
  
  public rowData :any[];
  
  getRowData() {
    this.reconcileService.getPrintInvoices(false)
   .subscribe(
     (result: any) => {
       console.log("result getPrintInvoices > ", result);
       
       this.rowData = result.invoices;
       console.log("rowdata:",this.rowData);
     }
   );
  }

  getdata() {
    console.log("call")
  }

}
