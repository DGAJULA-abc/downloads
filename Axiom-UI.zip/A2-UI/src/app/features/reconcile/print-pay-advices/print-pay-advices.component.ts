import { Component, Input } from '@angular/core';
import * as moment from 'moment';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-print-pay-advices',
  templateUrl: './print-pay-advices.component.html',
  styleUrls: ['./print-pay-advices.component.scss']
})
export class PrintPayAdvicesComponent {
  constructor(private reconcileService: ReconcileService) {
    this.getRowData();
  }
public statusList = [{name:"Ready"},{name:"Hold"},{name:"Printed"}];;
public columnDefs: any[] = [
  { field: ' ', headerName: ' ', cellRenderer: CellrenderComponent, cellRendererParams: {
    selectedRow: null}
  },
  { field: 'id', headerName: 'Pay Advice No',         cellRenderer: (id:any) => 
  `<a style="color:#00aaa6!important" href="reconcile/PrintPayAdvices/invoiceDetails/${id.value}" >${id.value}</a>` ,
  } ,
  { field: 'fromDate', headerName: 'From',  cellRenderer: (data:any) => {
    return moment(data.value).format('DD/MM/YY')
}},
  { field: 'toDate', headerName: 'To',  cellRenderer: (data:any) => {
    return moment(data.value).format('DD/MM/YY')
}},
  { field: 'companyId', headerName: 'Company Code'},
  { field: 'companyId', headerName: 'Company Type'},
  { field: 'statusId', headerName: 'Status'},
  { field: 'payAdviceText', headerName: 'Description'},
  { field: 'issueDate', headerName: 'Issue Date',cellRenderer: (data:any) => {
    return moment(data.value).format('MM/DD/YYYY HH:mm')
}},
  { field: 'baseExGst', headerName: 'Base Ex GST'},
  { field: 'totalExGst', headerName: 'Total Ex GST'},
  { field: 'created', headerName: 'Created On',cellRenderer: (data:any) => {
    return moment(data.value).format('MM/DD/YYYY HH:mm')
}}
  
  
];
public printMenu = [{name:"Include zero value lines", value:"withzerolines"},{name:"Print with customer format", value: "withcustomerformat"},{name:"Print creadit notes with format", value:"creditnotesformat"},{name:"Print invoices with format"}]
  
  
  public rowData = [];

  getRowData() {
    this.reconcileService.getPrintPayAdvices(false)
   .subscribe(
     (result: any) => {
       console.log("result getPrintPayAdvices > ", result);
       
       this.rowData = result.payadvices;
     }
   );
  }
}
