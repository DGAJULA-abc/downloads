import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RootRunsheetFormComponent } from './root-runsheet-form.component';

describe('RootRunsheetFormComponent', () => {
  let component: RootRunsheetFormComponent;
  let fixture: ComponentFixture<RootRunsheetFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RootRunsheetFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RootRunsheetFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
