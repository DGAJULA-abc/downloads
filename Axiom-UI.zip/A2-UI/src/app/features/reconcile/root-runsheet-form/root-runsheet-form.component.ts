import { Component } from '@angular/core';

@Component({
  selector: 'app-root-runsheet-form',
  templateUrl: './root-runsheet-form.component.html',
  styleUrls: ['./root-runsheet-form.component.scss']
})
export class RootRunsheetFormComponent {

}
