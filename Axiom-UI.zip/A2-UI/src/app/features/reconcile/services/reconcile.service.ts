import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  Driver,
  ListIncompleteReconcile,
  ViewReconcile,
} from '../models/view.reconcile.model';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';

import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { RunsheetFormRequest } from '../view-runsheet-form/ViewRunsheetId.model';
import { MultiLegSiteLocation } from '../../plan/models/plan.model';
import { OriginLoc } from '../detail/detail2.model';
import { trailers } from '../../setup/models/setup.model';

@Injectable({
  providedIn: 'root',
})
export class ReconcileService {
  private _cellSubdata: Subject<any> = new Subject();
  public panelBehSubject = new BehaviorSubject<any>(false);
  public reloadGrid = new BehaviorSubject<any>(false);
  public selectedItemType = new BehaviorSubject<any>("");
  public setRowData: any = [];

  public _multiLangData: Subject<any> = new Subject();
  constructor(private http: HttpClient) {}
  getReconcileView(): any {
    // let options :any = [];
    let options: any = { referenceDataActiveStates: { drivers: 'ANY' } };

    return this.http.get<ViewReconcile>(
      'assets/APIs/reconcile-view.json',
      options
    );
  }

   runsheetIdJson = 
   {
    "id": 3045830,
    "runsheetTypeId": "PALLET",
    "rateId": null,
    "truckId": "893",
    "siteId": 999,
    "driverId": 10283,
    "deliverydate": 1699448400000,
    "publicholidayapplies": false,
    "starttime": 1699448400000,
    "endtime": 1699477200000,
    "returndepottime": 1699477200000,
    "startkm": null,
    "endkm": null,
    "cashshortage": null,
    "stockshortage": null,
    "calcpaybyload": true,
    "calcpaybyhour": false,
    "payamt": null,
    "payhourly": null,
    "payincentive": null,
    "payallowance": null,
    "hoursnormal": null,
    "hoursthalf": null,
    "hoursdouble": null,
    "shiftrate": null,
    "shifthours": null,
    "shiftamt": null,
    "holdcode": null,
    "complete": false,
    "remarks": null,
    "createdby": "dhavaltr",
    "paydesc": null,
    "exported": false,
    "odokm": null,
    "gpskm": null,
    "enddate": 1699448400000,
    "eventgenerated": false,
    "globaldropbonus": null,
    "created": 1699598799000,
    "runsheetLines": [
        {
            "id": 14008010,
            "locationContDropId": null,
            "locationContPickupId": null,
            "locationDropId": "3000166-BACCHUS MARSH",
            "locationPickupId": "1246 THOMASTOWN",
            "locationReturnId": null,
            "serviceId": 15441966,
            "trailerId": null,
            "containerId": null,
            "loadTypeId": "DELIVERY",
            "trailerTagId": null,
            "serviceTypeId": "EXPORT",
            "rateId": "P500PERTRIP",
            "truckId": null,
            "siteId": 999,
            "qty1": 44,
            "unit1": "TONNES",
            "qty2": 45,
            "unit2": "HOURS",
            "qty3": null,
            "unit3": null,
            "qty4": null,
            "unit4": null,
            "qty5": null,
            "unit5": null,
            "qty6": null,
            "unit6": null,
            "qty7": null,
            "unit7": null,
            "qty8": null,
            "unit8": null,
            "owntrailer": false,
            "offsiderused": false,
            "pickuparrivetime": 1700053200000,
            "pickupdeparttime": 1700744400000,
            "droparrivetime": 1699448400000,
            "dropreadytime": null,
            "dropdeparttime": 1700139600000,
            "docket": null,
            "payamt": 500,
            "payestimated": false,
            "directfromdepot": false,
            "remarks": "rating component",
            "nextstoptime": null,
            "tripkm": 0,
            "paydesc": "$500.00 (Trip $500.00)",
            "pickupreadytime": null,
            "dropdoctime": null,
            "pickupdoctime": null,
            "createdby": "dhavaltr",
            "tripno": 1,
            "tripseq": 1,
            "servicehours": null,
            "hiretruck": false,
            "globaldropbonus": null,
            "deliverydate": 1699448400000,
            "tripodostart": null,
            "tripodoend": null,
            "groupseq": null,
            "tripstarttime": null,
            "tripendtime": null,
            "lineTemperature": null,
            "lineServiceTO": {
                "serviceId": 15441966,
                "dataSource": "A2",
                "created": 1699376153000,
                "tripIdCust": null,
                "serviceGroup": null,
                "serviceDesc": null,
                "customerId": "1052601",
                "consignmentMasterCustomerId": "1052601",
                "loadId": 13791515,
                "serviceNo": "M0083289",
                "reasonId": "105",
                "chargeAmt": null,
                "chargeDesc": null,
                "rateId": null,
                "complete": false,
                "loadNo": "L0097771",
                "batchNo": "3443",
                "custRef": "r45",
                "scheduleDate": 1699448400000,
                "despatchBy": null,
                "deliveryOpen": 1698843600000,
                "deliveryClose": null,
                "returnLocationId": null,
                "pickupLocation": {
                    "locationId": null,
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "COD ROBERT JARVIS CASH SALE",
                    "zonePayId": "METRO",
                    "zoneChargeId": "METRO",
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "dropLocation": {
                    "locationId": null,
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "ESTHER MCCLUSKEY",
                    "zonePayId": "PZONEOUT3",
                    "zoneChargeId": "CZONEOUT3",
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "loadLocation": {
                    "locationId": "3000166-BACCHUS MARSH",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "ESTHER MCCLUSKEY",
                    "zonePayId": null,
                    "zoneChargeId": null,
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "lastGroupSeq": null,
                "clearCharge": false,
                "totalChargeAmt": null,
                "svcReasonLines": [],
                "dehireDeadline": null,
                "vesselEta": 1699362000000,
                "vesselId": 1801,
                "priority": null,
                "wharf": "1246- CRAIGIEBURN",
                "depot": "ASAHI ARCHERFIELD DC",
                "customerSite": "3BUNNALTO-ALTONA",
                "dehirePark": "1250 - ALTONA NORTH",
                "originSite": 999,
                "originLoc": "1246- CRAIGIEBURN",
                "destinationSite": 999,
                "destinationLoc": "1246 THOMASTOWN"
            },
            "events": [],
            "loadNoDuplicated": null
        },
        {
            "id": 14008011,
            "locationContDropId": null,
            "locationContPickupId": null,
            "locationDropId": "1246- CRAIGIEBURN",
            "locationPickupId": "1246 THOMASTOWN",
            "locationReturnId": "1246- CRAIGIEBURN",
            "serviceId": 15442142,
            "trailerId": "N69158",
            "containerId": null,
            "loadTypeId": null,
            "trailerTagId": null,
            "serviceTypeId": "EXPORT",
            "rateId": "P500PERTRIP",
            "truckId": "893",
            "siteId": 999,
            "qty1": 3,
            "unit1": "TONNES",
            "qty2": null,
            "unit2": "HOURS",
            "qty3": null,
            "unit3": null,
            "qty4": null,
            "unit4": null,
            "qty5": null,
            "unit5": null,
            "qty6": null,
            "unit6": null,
            "qty7": null,
            "unit7": null,
            "qty8": null,
            "unit8": null,
            "owntrailer": false,
            "offsiderused": false,
            "pickuparrivetime": 1699363800000,
            "pickupdeparttime": 1699367400000,
            "droparrivetime": 1699369200000,
            "dropreadytime": null,
            "dropdeparttime": 1699372800000,
            "docket": null,
            "payamt": 250,
            "payestimated": false,
            "directfromdepot": false,
            "remarks": null,
            "nextstoptime": null,
            "tripkm": 0,
            "paydesc": "$500.00 (Trip $500.00) + (2 stp x $0.00)",
            "pickupreadytime": null,
            "dropdoctime": null,
            "pickupdoctime": null,
            "createdby": "dhavaltr",
            "tripno": 2,
            "tripseq": 1,
            "servicehours": null,
            "hiretruck": false,
            "globaldropbonus": null,
            "deliverydate": 1699448400000,
            "tripodostart": null,
            "tripodoend": null,
            "groupseq": null,
            "tripstarttime": 1699367400000,
            "tripendtime": 1699372800000,
            "lineTemperature": null,
            "lineServiceTO": {
                "serviceId": 15442142,
                "dataSource": "A2",
                "created": 1699442209000,
                "tripIdCust": "T33484",
                "serviceGroup": null,
                "serviceDesc": null,
                "customerId": "MEL001",
                "consignmentMasterCustomerId": "MEL001",
                "loadId": 13791691,
                "serviceNo": "M0083462",
                "reasonId": null,
                "chargeAmt": 9.355,
                "chargeDesc": "Point-Point-KM 18.7 X $1.00 (Incl. Return to 1246- CRAIGIEBURN) + (2 stp x $0.00)",
                "rateId": "ZZBEN",
                "complete": false,
                "loadNo": "L0097944",
                "batchNo": null,
                "custRef": null,
                "scheduleDate": 1699448400000,
                "despatchBy": null,
                "deliveryOpen": null,
                "deliveryClose": null,
                "returnLocationId": "1246- CRAIGIEBURN",
                "pickupLocation": {
                    "locationId": "1246 THOMASTOWN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "COD ROBERT JARVIS CASH SALE",
                    "zonePayId": "METRO",
                    "zoneChargeId": "METRO",
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "dropLocation": {
                    "locationId": "1246- CRAIGIEBURN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "Clint Sneddon Staff Sale 4 Rushwood Dve Craigiebur",
                    "zonePayId": "METRO",
                    "zoneChargeId": "METRO",
                    "suburb": "Melbourne",
                    "active": null,
                    "loadTimeMins": null,
                    "address1": "Level 3 390 St Kilda",
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "loadLocation": {
                    "locationId": "1246- CRAIGIEBURN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "Clint Sneddon Staff Sale 4 Rushwood Dve Craigiebur",
                    "zonePayId": null,
                    "zoneChargeId": null,
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "lastGroupSeq": null,
                "clearCharge": false,
                "totalChargeAmt": 18.71,
                "svcReasonLines": [],
                "dehireDeadline": null,
                "vesselEta": null,
                "vesselId": null,
                "priority": null,
                "wharf": null,
                "depot": null,
                "customerSite": null,
                "dehirePark": null,
                "originSite": 999,
                "originLoc": null,
                "destinationSite": 999,
                "destinationLoc": null
            },
            "events": [
                {
                    "id": 49606888,
                    "key": 15442142,
                    "eventTypeId": 11,
                    "dockId": null,
                    "locationId": "1246 THOMASTOWN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699363800000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699363800000,
                    "eventDescription": "Pickup Arrive",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606889,
                    "key": 15442142,
                    "eventTypeId": 15,
                    "dockId": null,
                    "locationId": "1246 THOMASTOWN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699365600000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699365600000,
                    "eventDescription": "Pickup Completed",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606890,
                    "key": 15442142,
                    "eventTypeId": 12,
                    "dockId": null,
                    "locationId": "1246 THOMASTOWN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699367400000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699367400000,
                    "eventDescription": "Pickup Depart",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606891,
                    "key": 15442142,
                    "eventTypeId": 13,
                    "dockId": null,
                    "locationId": "1246- CRAIGIEBURN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699369200000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699369200000,
                    "eventDescription": "Drop Arrive",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606892,
                    "key": 15442142,
                    "eventTypeId": 16,
                    "dockId": null,
                    "locationId": "1246- CRAIGIEBURN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699371000000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699371000000,
                    "eventDescription": "Drop Completed",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606893,
                    "key": 15442142,
                    "eventTypeId": 14,
                    "dockId": null,
                    "locationId": "1246- CRAIGIEBURN",
                    "serviceId": 15442142,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699372800000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442250000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "SERVICE",
                    "eventTime": 1699372800000,
                    "eventDescription": "Drop Depart",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                },
                {
                    "id": 49606887,
                    "key": 15442142,
                    "eventTypeId": 8,
                    "dockId": null,
                    "locationId": null,
                    "serviceId": null,
                    "trailerId": "N69158",
                    "tripId": 5377334,
                    "truckId": "893",
                    "siteId": 999,
                    "driverId": 10256,
                    "trailerTagId": null,
                    "loggedDateTime": 1699442232000,
                    "value1": null,
                    "value2": null,
                    "textValue": null,
                    "userId": "brandtan",
                    "time1": null,
                    "time2": null,
                    "textValue2": null,
                    "exception": false,
                    "exceptiondesc": null,
                    "exported": false,
                    "eventAdjusted": false,
                    "datasourceId": "A2",
                    "latitude": null,
                    "longitude": null,
                    "fleetId": null,
                    "unitId": null,
                    "vehicleId": null,
                    "mdrego": null,
                    "mdtcode": null,
                    "mdservertime": null,
                    "created": 1699442232000,
                    "certainty": null,
                    "compliant": false,
                    "comments": null,
                    "eventLevel": "TRIP",
                    "eventTime": 1699442232000,
                    "eventDescription": "Despatched",
                    "todexportable": true,
                    "tripIdCust": "T33484",
                    "loadNo": "L0097944",
                    "employeeName": "Bevan N",
                    "companyId": "TOLL",
                    "firstName": "Bevan",
                    "lastName": "Narayanan",
                    "tripNo": null,
                    "serviceNo": "M0083462"
                }
            ],
            "loadNoDuplicated": null
        },
        {
            "id": 14008012,
            "locationContDropId": null,
            "locationContPickupId": null,
            "locationDropId": "1246- CRAIGIEBURN",
            "locationPickupId": "1246 THOMASTOWN",
            "locationReturnId": "1246- CRAIGIEBURN",
            "serviceId": 15442225,
            "trailerId": "N69158",
            "containerId": null,
            "loadTypeId": null,
            "trailerTagId": null,
            "serviceTypeId": "DEMURRAGE",
            "rateId": "P500PERTRIP",
            "truckId": "893",
            "siteId": 999,
            "qty1": null,
            "unit1": null,
            "qty2": null,
            "unit2": null,
            "qty3": null,
            "unit3": null,
            "qty4": null,
            "unit4": null,
            "qty5": null,
            "unit5": null,
            "qty6": null,
            "unit6": null,
            "qty7": null,
            "unit7": null,
            "qty8": null,
            "unit8": null,
            "owntrailer": false,
            "offsiderused": false,
            "pickuparrivetime": 1699363800000,
            "pickupdeparttime": 1699367400000,
            "droparrivetime": 1699369200000,
            "dropreadytime": null,
            "dropdeparttime": 1699372800000,
            "docket": null,
            "payamt": 250,
            "payestimated": false,
            "directfromdepot": false,
            "remarks": null,
            "nextstoptime": null,
            "tripkm": 0,
            "paydesc": "$500.00 (Trip $500.00) + (2 stp x $0.00)",
            "pickupreadytime": null,
            "dropdoctime": null,
            "pickupdoctime": null,
            "createdby": "dhavaltr",
            "tripno": 2,
            "tripseq": 2,
            "servicehours": null,
            "hiretruck": false,
            "globaldropbonus": null,
            "deliverydate": 1699448400000,
            "tripodostart": null,
            "tripodoend": null,
            "groupseq": null,
            "tripstarttime": 1699367400000,
            "tripendtime": 1699372800000,
            "lineTemperature": null,
            "lineServiceTO": {
                "serviceId": 15442225,
                "dataSource": "RS",
                "created": 1699598863000,
                "tripIdCust": null,
                "serviceGroup": null,
                "serviceDesc": null,
                "customerId": "MEL001",
                "consignmentMasterCustomerId": "MEL001",
                "loadId": 13791691,
                "serviceNo": "M0083538",
                "reasonId": null,
                "chargeAmt": 9.355,
                "chargeDesc": "Point-Point-KM 18.7 X $1.00 (Incl. Return to 1246- CRAIGIEBURN) + (2 stp x $0.00)",
                "rateId": "ZZBEN",
                "complete": false,
                "loadNo": "L0097944",
                "batchNo": null,
                "custRef": null,
                "scheduleDate": 1699448400000,
                "despatchBy": null,
                "deliveryOpen": null,
                "deliveryClose": null,
                "returnLocationId": null,
                "pickupLocation": {
                    "locationId": "1246 THOMASTOWN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "COD ROBERT JARVIS CASH SALE",
                    "zonePayId": "METRO",
                    "zoneChargeId": "METRO",
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "dropLocation": {
                    "locationId": "1246- CRAIGIEBURN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "Clint Sneddon Staff Sale 4 Rushwood Dve Craigiebur",
                    "zonePayId": "METRO",
                    "zoneChargeId": "METRO",
                    "suburb": "Melbourne",
                    "active": null,
                    "loadTimeMins": null,
                    "address1": "Level 3 390 St Kilda",
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "loadLocation": {
                    "locationId": "1246- CRAIGIEBURN",
                    "siteId": 999,
                    "locationTypeId": null,
                    "locationDesc": "Clint Sneddon Staff Sale 4 Rushwood Dve Craigiebur",
                    "zonePayId": null,
                    "zoneChargeId": null,
                    "suburb": null,
                    "active": null,
                    "loadTimeMins": null,
                    "address1": null,
                    "address2": null,
                    "state": null,
                    "postCode": null,
                    "window1From": null,
                    "window1To": null,
                    "window2From": null,
                    "window2To": null,
                    "window3From": null,
                    "window3To": null,
                    "personIdContact": null,
                    "personIdContactName": null,
                    "customerId": null,
                    "locationCode": null,
                    "latitude": null,
                    "longitude": null,
                    "geofence": null,
                    "mapSourceId": null,
                    "mapReference": null,
                    "remarks": null,
                    "truckSizeLimit": null,
                    "defaultTripSeq": null,
                    "routeId": null,
                    "permanent": null,
                    "loadTimeMinsPerUnit": null,
                    "loadTimeUnit": null,
                    "waitTimeMins": null,
                    "waitTimeMinsPerUnit": null,
                    "waitTimeUnit": null,
                    "accShortCut": null,
                    "locationIdGroup": null,
                    "siteTravelTime": null,
                    "disableWPUpdated": null,
                    "externalLookUp": null,
                    "internalLookUp": null,
                    "segManaged": null,
                    "segExported": null,
                    "routeCapacity": null
                },
                "lastGroupSeq": null,
                "clearCharge": false,
                "totalChargeAmt": 18.71,
                "svcReasonLines": [],
                "dehireDeadline": null,
                "vesselEta": null,
                "vesselId": null,
                "priority": null,
                "wharf": null,
                "depot": null,
                "customerSite": null,
                "dehirePark": null,
                "originSite": 999,
                "originLoc": null,
                "destinationSite": 999,
                "destinationLoc": null
            },
            "events": null,
            "loadNoDuplicated": null
        }
    ],
    "invoiceLines": [],
    "payAdviceLines": [],
    "reasonLines": [],
    "driverBreaks": [],
    "shiftId": null,
    "shiftUUID": null
}

  getListIncompleteService(): any {
    let searchQuery = {
      svcDateFrom: 1698172200000,
      svcDateTo: 1699429961759,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'serviceid',
      },
    };
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.searchService}`, searchQuery);
  }

  lookUp(requestParam : any) : any{
    return this.http.post<any>(`${apiEndpoint.runsheetLookup}`, requestParam);
  }

  getListIncompleteRunsheet(): any {
    let searchQuery = {
      completed: false,

      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'runsheetid',
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(`${apiEndpoint.searchRunsheet}`, searchQuery);
  }

  getListCompleteRunsheet(listFormSubmit: any): any {
    let searchQuery = {
      completed: false,
      deliveryFrom: listFormSubmit.deliveryFrom,
      deliveryTo: listFormSubmit.deliveryTo,

      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'runsheetid',
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(`${apiEndpoint.searchRunsheet}`, searchQuery);
  }

  public get getCellSubdata(): Observable<any> {
    return this._cellSubdata.asObservable();
  }

  setCellSubData(cellData: any, isChecked?: boolean) {
    const runsheetId = cellData.data.runsheetid;
    if (isChecked) {
      this.setRowData.push(runsheetId);
      // console.log('cellData >> ', this.setRowData);
    } else {
      const index = this.setRowData.indexOf(runsheetId);
      if (index > -1) {
        // only splice array when item is found
        this.setRowData.splice(index, 1); // 2nd parameter means remove one item only
      }
      // console.log('cellData >> ', this.setRowData);
    }

    this._cellSubdata.next(cellData);
  }

  setReconcilePage() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.reconcileView}`, options);
  }

  autoCompletionStatus() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.autoCompleteStatus}`, options);
  }

  deleteRunsheetId() {
    return this.http.delete<any>(`${apiEndpoint.runsheets}`, {
      body: this.setRowData,
    });
  }

  getViewRunsheetId(runsheetId: any) {
    return this.http.get<any>(`${apiEndpoint.runsheet}/${runsheetId}`);
  }

  getPeriodicCharges() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodics.charge}`);
  }

  postPeriodicCharges(chargeForm: any) {
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.periodic.charge}`, chargeForm);
  }

  getCustomers() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.customerLookup}`, options);
  }

  getServiceType() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.serviceTypesLookup}`, options);
  }

  getAllRunsheetStatus(completiondate: any) {
    let options = completiondate;
    return this.http.post<any>(`${apiEndpoint.autoComplete}`, options);

    // return this.http.get<any>('assets/APIs/auto-complete.json');
  }

  getReleaseRunsheetOnHold() {
    let options: any = {};
    return this.http.post<any>(`${apiEndpoint.releaseRunsheetOnHold}`, options);
  }

  getPrintInvoices(printed: boolean): any {
    let searchQuery;
    if (printed === true) {
      searchQuery = {
        exported: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    } else {
      searchQuery = {
        printed: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    }
    return this.http.post<any>(`${apiEndpoint.searchInvoice}`, searchQuery);
  }

  getPrintPayAdvices(printed: boolean): any {
    let searchQuery;
    if (printed === true) {
      searchQuery = {
        exported: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    } else {
      searchQuery = {
        printed: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    }

    return this.http.post<any>(`${apiEndpoint.searchPayAdvice}`, searchQuery);
  }

  createPayAdvices(payAdviceForm: any): any {
    let searchQuery = {
      issueDate: payAdviceForm.issueDate,
      effectiveDateFrom: payAdviceForm.effectiveDateFrom,
      effectiveDateTo: payAdviceForm.effectiveDateT,

      pagination: {
        orderType: 'ASC',
        pageNumber: 1,
        recordsPerPage: 100,
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(
      `${apiEndpoint.payAdviceSimulationCreation}`,
      searchQuery
    );
  }

  createInvoice(invoiceFormSubmit: any): any {
    let searchQuery = {
      invoiceCreationParameters: {
        effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
        effectiveDateTo: invoiceFormSubmit.effectiveDateT,
        includePreviousDates: invoiceFormSubmit.includePreviousDates,
      },
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
    };

    return this.http.post<any>(
      `${apiEndpoint.invoiceSimulateCreation}`,
      searchQuery
    );
  }

  invoiceWithCustomer(invoiceFormSubmit: any): any {
    let searchQuery = {
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
      issueDate: invoiceFormSubmit.issueDate,
      includePreviousDates: invoiceFormSubmit.includePreviousDates,
      customers: invoiceFormSubmit.customers,
      daysToPay: invoiceFormSubmit.daysToPay,
    };

    return this.http.put<any>(`${apiEndpoint.invoice}`, searchQuery);
  }

  closeOffLog(LogsDetails: any) {
    let searchQuery = {
      selectedSite: LogsDetails.selectedSite,
      showMissingSitesForLastWeek: LogsDetails.showMissingSitesForLastWeek,
      weekEndingDate: LogsDetails.weekEndingDate,
    };

    return this.http.post<any>(`${apiEndpoint.closeOff.logs}`, searchQuery);
  }

  closeOffSummary(weekEndingDate: any) {
    let searchQuery = weekEndingDate;
    return this.http.post<any>(`${apiEndpoint.closeOff.summary}`, searchQuery);
  }
  //viewreconcilre tab data;
  getTabsDada(): any {
    let options: any = [];
    return this.http.get<any>('assets/APIs/reconcileTab.json', options);
  }

  //viewreconcilre tab data;
  getTabReconcileRunsheetService(): any {
    let options: any = [];
    return this.http.get<any>(
      'assets/APIs/runsheet_Lines_Tab_Data.json',
      options
    );
  }

  getMetaDataJson() {
    let options: any = [];
    return this.http.get<any>('assets/APIs/metadata.json', options);
  }

  getInvoiceDeatails(invoiceId: any) {
    return this.http.get<any>(`${apiEndpoint.invoice}/${invoiceId}`);
  }

  getPayAdviceDetails(invoiceId: any) {
    return this.http.get<any>(`${apiEndpoint.payAdviceCreation}/${invoiceId}`);
  }

  getPeriodic() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodic}`, options);
  }

  getPeriodicPayments() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodics.payment}`, options);
  }

  getDriver() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.drivers}`, options);
  }

  getCompany() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.companies}`, options);
  }

  // getGLCode() {
  //   let options :any = [];
  //   return this.http.get<any>(`${apiEndpoint.glCode}`, options);
  // }

  perdiocPaymentFormApi(paymentValue: any) {
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.periodic.payment}`, paymentValue);
  }

  payAdvice(invoiceFormSubmit: any) {
    let searchQuery = {
      issueDate: invoiceFormSubmit.issueDate,
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
    };

    return this.http.put<any>(`${apiEndpoint.payAdviceCreation}`, searchQuery);
  }

  invoice(invoiceFormSubmit: any) {
    let searchQuery = {
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
      includePreviousDates: true,
    };

    return this.http.put<any>(`${apiEndpoint.invoice}`, searchQuery);
  }

  getAdjustmentTypes() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.adjustmentTypes}`);
  }

  getRunsheetTypes() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.runsheetTypes}`);
  }

  getEffectiveDate() {
    let options: any = [];
    // return this.http.get<any>(`${apiEndpoint.adjus}`);
  }

  getundocumentedAdjustment() {
    return this.http.get<any>(`${apiEndpoint.adjustmentUndocumented}`);
  }

  getRunsheetServiceNoData(runsheetNo: any) {
    return this.http.post<any>(
      `${apiEndpoint.searchRunsheet}`,
      runsheetNo
    );
  }
  getServiceReference(serviceNumber: any, adjustType: any) {
    let options: any = [];
    // const url = http://axiapauu04/api/v1/d/adjustment/service-reference/M0081941/type/CREDIT%20CHARGE
    return this.http.get<any>(
      `${apiEndpoint.adjustmentServiceRef}/${serviceNumber}/type/${adjustType}`
    );
  }

  adjustmentFormSubmit(formValue: any) {
    return this.http.put<any>(`${apiEndpoint.adjustment}`, formValue);
  }

  updateInvoiceStatus(invoiceIds: any, invoiceStatus: any) {
    let searchQuery = {
      ids: invoiceIds,
      status: invoiceStatus,
    };

    return this.http.post<any>(
      `${apiEndpoint.updateInvoiceStatus}`,
      searchQuery
    );
  }

  updatePayAdviceStatus(payAdviceIds: any, payAdviceStatus: any) {
    let searchQuery = {
      status: payAdviceStatus,
      ids: payAdviceIds,
    };

    return this.http.post<any>(
      `${apiEndpoint.updatePayAdviceStatus}`,
      searchQuery
    );
  }

  deleteInvoices(selectedIds: any) {
    let searchQuery = selectedIds;

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: searchQuery,
    };

    return this.http.delete<any>(`${apiEndpoint.deleteInvoice}`, options);
  }

  deletePayAdvices(selectedIds: any) {
    let searchQuery = selectedIds;

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: searchQuery,
    };
    return this.http.post<any>(`${apiEndpoint.deletePayAdvice}`, searchQuery);
  }

  //viewRunsheet id

  getReasonCode() {
    return this.http.get<any>(`${apiEndpoint.reasonsCode}`);
  }

  //viewRunsheet id

  viewRunsheetSubmit(runsheetForm:any) {
    return this.http.post<any>(`${apiEndpoint.runsheet}`, runsheetForm);
  }

  lockRunsheet(id: any) {
    let data = {};
    return this.http.post<any>(`${apiEndpoint.runsheet}/${id}/lock`, data);
  }

  showErrors(id: any, shiftId: any) {
    let shiftId_ = 123;
    const httpOptions ={
      Headers : new HttpHeaders({
        'Content-Type' :'application/json'
      })
    } 
 //return this.http.post(`${apiEndpoint.despatchDecision.endpoint}`, requestParam, {headers: headers});
    return this.http.post<any>(
      `${apiEndpoint.runsheet}/${id}/show-errors`,
      shiftId_, {headers: httpOptions.Headers}
    );
  }

  unlockRunsheet(id: any) {
    let data = {};
    return this.http.post<any>(`${apiEndpoint.runsheet}/${id}/unlock`, data);
  }

  renewLocks(id: any) {
    let data: any ={};
    return this.http.post<any>(`${apiEndpoint.renewLocks}/${id}/lock`, data);
  }

  renew() {
    let data ={}
   // return this.http.post(`${apiEndpoint.renewLocks}`);
    return this.http.post<any>(`${apiEndpoint.renewLocks}`,data);
  }

  getMultiLegSiteLocationsBySite(sideId: any) {
    return this.http.get<any>(
      `${apiEndpoint.locationMultiLegSiteLocations}/${sideId}`
    );
  }

  getLocation() {
    return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getServiceTypesLookup() {
    return this.http.get<any>(`${apiEndpoint.serviceTypesLookup}`);
  }

  getLoadType() {
    return this.http.get<any>(`${apiEndpoint.loadTypes}`);
  }

  getServicesOfLoad(loadId: any) {
    return this.http.get<any>(
      `${apiEndpoint.runsheetGetServicesOfLoad}/${loadId}`
    );
  }

  getEventData(loadId: any) {
    return this.http.get<any>(`${apiEndpoint.events}}`);
  }

  getRatingDetails(rateId: any) {
    return this.http.get<any>(`${apiEndpoint.runsheetRate}}/${rateId}`);
  }

  getContainerLookup(rateId: any) {
    return this.http.get<any>(`${apiEndpoint.containerLookup}}`);
  }

  getVesselLookup() {
    return this.http.get<any>(`${apiEndpoint.vessels}`);
  }
  getWharfLookup() {
    // return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getDepot() {
    return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getCustomerSite() {
    return this.http.get<any>(`${apiEndpoint.customerLookup}`);
  }

  getPrimaryOriginSite() {
    return this.http.get<OriginLoc>(`${apiEndpoint.maxxToAxiomTranslation.originSites}`);
  }

  getTruck() {
    return this.http.get<any>(`${apiEndpoint.truckLookup}`);
  }

  getTrailer() {
    return this.http.get<any>(`${apiEndpoint.trailerLookup}`);
  }

  getBreakType() {
    return this.http.get<any>(`${apiEndpoint.breakTypes}`);
  }

  getShiftDetails(request: any) {
    return this.http.post<any>(`${apiEndpoint.shiftDetails}`, request);
  }

  postLookupRunsheet(request: any) {
    return this.http.post<any>(`${apiEndpoint.runsheetLookup}`, request);
  }

//shared function

   getDriverDropProperVal(driver: Driver) {
    const driverName = `${driver.id} - ${driver.firstName} - ${driver.employeeName} (${driver.companyId})`;
    return driverName;
   }

   getReasonIdVal(reasonDrop: any) {
    const reasonId = `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`;
    return reasonId;
   }

   geTrailerName(trailer: trailers) {
    const trailerName = `${trailer.trailerId} , (${trailer.trailerTypeId} , ${trailer.companyId})`;

    return trailerName;
   }
  
}
