import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RunsheetFormService {
  public runSheetFormParentObject: Subject<any> = new Subject();
  public runSheetFormSubject: Subject<any> = new Subject();
  private _serviceDetailForm: any;
  private _runLoadDetailForm: any;
  private _runSheetContainerDetailForm: any;
  private _runSheetBreakForm: any;

  public _runSheetEventDetail: Subject<any> = new Subject();
  public _runSheetRatingDetail: Subject<any> = new Subject();

  runsheetFormObject = {
    id: 14008010,
    locationContDropId: null,
    locationContPickupId: 123,
    locationDropId: '3000166-BACCHUS MARSH',
    locationPickupId: '1246 THOMASTOWN',
    locationReturnId: null,
    serviceId: 15441966,
    trailerId: null,
    containerId: null,
    loadTypeId: 'DELIVERY',
    trailerTagId: null,
    serviceTypeId: 'EXPORT',
    rateId: 'P500PERTRIP',
    truckId: null,
    siteId: 999,
    qty1: 44,
    unit1: 'TONNES',
    qty2: 45,
    unit2: 'HOURS',
    qty3: null,
    unit3: null,
    qty4: null,
    unit4: null,
    qty5: null,
    unit5: null,
    qty6: null,
    unit6: null,
    qty7: null,
    unit7: null,
    qty8: null,
    unit8: null,
    owntrailer: false,
    offsiderused: false,
    pickuparrivetime: 1700053200000,
    pickupdeparttime: 1700744400000,
    droparrivetime: 1699448400000,
    dropreadytime: null,
    dropdeparttime: 1700139600000,
    docket: null,
    payamt: 500,
    payestimated: false,
    directfromdepot: false,
    remarks: 'rating component',
    nextstoptime: null,
    tripkm: 0,
    paydesc: '$500.00 (Trip $500.00)',
    pickupreadytime: null,
    dropdoctime: null,
    pickupdoctime: null,
    createdby: 'dhavaltr',
    tripno: 1,
    tripseq: 1,
    servicehours: null,
    hiretruck: false,
    globaldropbonus: null,
    deliverydate: 1699448400000,
    tripodostart: null,
    tripodoend: null,
    groupseq: null,
    tripstarttime: null,
    tripendtime: null,
    lineTemperature: null,
    lineServiceTO: {
      serviceId: 15441966,
      dataSource: 'A2',
      created: 1699376153000,
      tripIdCust: null,
      serviceGroup: null,
      serviceDesc: null,
      customerId: '1052601',
      consignmentMasterCustomerId: '1052601',
      loadId: 13791515,
      serviceNo: 'M0083289',
      reasonId: '105',
      chargeAmt: null,
      chargeDesc: null,
      rateId: null,
      complete: false,
      loadNo: 'L0097771',
      batchNo: '3443',
      custRef: 'r45',
      scheduleDate: 1699448400000,
      despatchBy: null,
      deliveryOpen: 1698843600000,
      deliveryClose: null,
      returnLocationId: null,
      pickupLocation: {
        locationId: null,
        siteId: 999,
        locationTypeId: null,
        locationDesc: 'COD ROBERT JARVIS CASH SALE',
        zonePayId: 'METRO',
        zoneChargeId: 'METRO',
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      dropLocation: {
        locationId: null,
        siteId: 999,
        locationTypeId: null,
        locationDesc: 'ESTHER MCCLUSKEY',
        zonePayId: 'PZONEOUT3',
        zoneChargeId: 'CZONEOUT3',
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      loadLocation: {
        locationId: '3000166-BACCHUS MARSH',
        siteId: 999,
        locationTypeId: null,
        locationDesc: 'ESTHER MCCLUSKEY',
        zonePayId: null,
        zoneChargeId: null,
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      lastGroupSeq: null,
      clearCharge: false,
      totalChargeAmt: null,
      svcReasonLines: [],
      dehireDeadline: null,
      vesselEta: 1699362000000,
      vesselId: 1801,
      priority: null,
      wharf: '1246- CRAIGIEBURN',
      depot: 'ASAHI ARCHERFIELD DC',
      customerSite: '3BUNNALTO-ALTONA',
      dehirePark: '1250 - ALTONA NORTH',
      originSite: 999,
      originLoc: '1246- CRAIGIEBURN',
      destinationSite: 999,
      destinationLoc: '1246 THOMASTOWN',
    },
    events: [],
    loadNoDuplicated: null,
  };

  constructor() {}

  private formDataSubject = new Subject<any>();
  formData$ = this.formDataSubject.asObservable();

  private loadFormDataSubject = new Subject<any>();
  loadFormData$ = this.loadFormDataSubject.asObservable();

  private containerFormDataSubject = new Subject<any>();
  containerFormData$ = this.containerFormDataSubject.asObservable();

  sendFormData(data: any) {
    this.formDataSubject.next(data);
  }

  sendLoadFormData(data: any) {
    this.loadFormDataSubject.next(data);
  }

  sendContainerFormData(data: any) {
    this.containerFormDataSubject.next(data);
  }
  // runsheetFormSubmitObj () {
  //   this.runSheetFormParentObject.subscribe((res: any) => {
  //     console.log("Submit runsheet res", res);

  //   })
  // }

  //runsheet Lines Service Detail form
  get serviceDetailForm() {
    return this._serviceDetailForm;
  }
  set serviceDetailForm(value) {
    this._serviceDetailForm = value;
  }

  // runsheet Lines Service Load Form
  get serviceLoadForm() {
    return this._runLoadDetailForm;
  }
  set serviceLoadForm(value) {
    this._runLoadDetailForm = value;
  }

  // runsheet Lines Container Load Form
  get runsheetLineContainerForm() {
    return this._runSheetContainerDetailForm;
  }
  set runsheetLineContainerForm(value) {
    this._runSheetContainerDetailForm = value;
  }

  // runsheet Lines Container Load Form
  get runsheetBreakForm() {
    return this._runSheetBreakForm;
  }
  set runsheetBreakForm(value) {
    this._runSheetBreakForm = value;
  }

  /**
   * Check of lookup button can be displayed
   *
   * @returns {boolean}
   */
  isReadyToShiftDetails() {
    // return  $scope.Runsheet.data.runsheet.driverId && $scope.Runsheet.deliveryDateStamp;
  }
}
