import { Component } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-submit-close-off',
  templateUrl: './submit-close-off.component.html',
  styleUrls: ['./submit-close-off.component.scss']
})
export class SubmitCloseOffComponent {
  defaultIWeekEndingDate: Date = new Date();
  closeOffSummary :any[] = [];

  public columnDefs: any[] = [
    { field: 'recordType', headerName: 'Records', width:100} ,
    { field: 'recordCount', headerName: 'Type', width:100},
    { field: 'totalAmount', headerName: 'Total Amount', width:100}
    
    
  ];
  constructor(private reconsileService: ReconcileService) {
  }

  ngOnInit() {
    var now = new Date();
    var daysBack = -7 + (7 - now.getDay());

    console.log(
      new Date(now.getTime() + ((daysBack || -7) * 1000 * 60 * 60 * 24))
    );
    this.defaultIWeekEndingDate = new Date(now.getTime() + ((daysBack || -7) * 1000 * 60 * 60 * 24));
    this.getRowData();
  }

  getRowData() {
    this.reconsileService.closeOffSummary(this.defaultIWeekEndingDate.getTime())
      .subscribe(
        (result: any) => {
          console.log(result);
          this.closeOffSummary = result.closeOffSummary;
        });


  }
}

