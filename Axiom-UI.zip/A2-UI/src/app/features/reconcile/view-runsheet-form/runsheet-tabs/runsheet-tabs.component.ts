import { Component, Input } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { ActivatedRoute } from '@angular/router';
import { CellrenderComponent } from '../../list-incomplete-services/cellrender/cellrender.component';
import { FormGroup, FormGroupDirective } from "@angular/forms";
import { ColDef } from 'ag-grid-community';
import { Subscription } from 'rxjs';
import { RunsheetFormService } from '../../services/runsheet-form.service';

@Component({
  selector: 'app-runsheet-tabs',
  templateUrl: './runsheet-tabs.component.html',
  styleUrls: ['./runsheet-tabs.component.scss']
})
export class RunsheetTabsComponent {
  tabData: any[] = [];
  runsheetRowData: any[] = [];
  tabHeaderData: any[] = [];
  runsheetLinesRow: any[] = [];
  driverBreaks: any[] = [];
  gridOptions: any;
  subscription: Subscription;
  form: FormGroup;
  serviceFormReceivedData: any = {};


runsheetId: any = '';

  columnDefs: any[] = [
    { field: 'id', headerName: 'Runsheet Id', cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter',  minWidth: 150, },
    { field: 'tripseq', headerName: 'Seq',  minWidth: 150,},
    { field: 'loadNo', headerName: 'Load no.',  minWidth: 150,},
    { field: 'tripIdCust', headerName: 'Trip',  minWidth: 150,},
    { field: 'serviceGroup', headerName: 'Service Group No.',  minWidth: 150,},
    { field: 'serviceTypeId', headerName: 'Service Type Id',  minWidth: 150,},
    { field: 'returnLocationId', headerName: 'From',  minWidth: 150,},
    { field: 'dropLocation.locationId', headerName: 'To',  minWidth: 150,},
    { field: 'complete', headerName: 'Complete',  minWidth: 150,},
    { field: 'totalChargeAmt', headerName: 'Charge Amount',  minWidth: 150,},
    { field: 'serviceNo', headerName: 'Service No.',  minWidth: 150,},
    { field: 'docket', headerName: 'Docket',  minWidth: 150,},
    { field: 'truckSizeLimit', headerName: 'Truck Size Limit',  minWidth: 150,},
    { field: 'trailerId', headerName: 'Trailer Id',  minWidth: 150,},
    { field: 'trailerTagId', headerName: 'Trailer Tag Id',  minWidth: 150,},
    { field: 'fleetId', headerName: 'Charge Amount',  minWidth: 150,},
    { field: 'customerId', headerName: 'Customer Id',  minWidth: 150,},
    { field: 'totalChargeAmt', headerName: 'Charge Amount',  minWidth: 150,},
    { field: 'serviceNo', headerName: 'Service No.',  minWidth: 150,},
    { field: 'docket', headerName: 'Docket',  minWidth: 150,},
    { field: 'truckSizeLimit', headerName: 'Truck Size Limit',  minWidth: 150,},
    { field: 'trailerId', headerName: 'Trailer Id',  minWidth: 150,},
    { field: 'trailerTagId', headerName: 'Trailer Tag Id',  minWidth: 150,},
    { field: 'fleetId', headerName: 'Charge Amount',  minWidth: 150,},
    { field: 'customerId', headerName: 'Customer Id',  minWidth: 150,},

  ];

  /**
   * Fro Breaks we need an different columnDefs
   */
  columnDefsBreaks: any[] = [
    { field: 'id', headerName: '#',filter: 'agNumberColumnFilter',  minWidth: 150, },
    { field: 'locationId', headerName: 'Location',  minWidth: 150,},
    { field: 'breakTypeId', headerName: 'Type',  minWidth: 150,},
    { field: 'breakstarttime', headerName: 'Start date/time',  minWidth: 150,},
    { field: 'breakendtime', headerName: 'End date/time',  minWidth: 150,},
    { field: 'serviceTypeId', headerName: 'Break duration',  minWidth: 150,},
    { field: 'commentA', headerName: 'Comments',  minWidth: 150,},
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 150,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };

  constructor(private reconsileService: ReconcileService, 
    private runsheetFormService: RunsheetFormService,
    private activatedRoute: ActivatedRoute, private rootFormGroup: FormGroupDirective) {}

  
ngOnInit() {
  this.form = this.rootFormGroup.control;
  console.log("rootFormGroup value >>", this.form);
  
  this.gridOptions = {
    context: { Component: this }
  }
  this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
 this.getTabRender();
 this.getRowDataReconsileSheet(this.runsheetId);

 // update ROw data though form

//  this.subscription = this.runsheetFormService.formData$.subscribe((data) => {
//   this.serviceFormReceivedData = data.value;
//   const tempObj = {
//     "id" : 111,
//     "tripseq": 5
//   }
//   console.log("service data, serviceFormReceivedData:", this.serviceFormReceivedData)
//   this.runsheetLinesRow.push(tempObj);
//  });
}


  getTabRender() {
    let uniqueData: any[] = [];
    this.reconsileService.getTabsDada().subscribe((result: any) => {
      this.tabHeaderData = result;
      this.tabData = result;
      // console.log('runsheet tabs', this.tabData);
      this.tabHeaderData.sort((a: any, b: any) => a.tabOrder - b.tabOrder);

      const uniqueTabOrders = new Set();

      // Iterate through the data and add items to the uniqueData array
      for (const item of this.tabHeaderData) {
        if (!uniqueTabOrders.has(item.tabOrder)) {
          uniqueData.push(item);
          uniqueTabOrders.add(item.tabOrder);
        }
      }
      this.tabHeaderData = uniqueData;
      // console.log('Unique Data by tabOrder:', uniqueData);
    });
  }

  getRowDataReconsileSheet(runsheetId: any) {
    this.reconsileService.reloadGrid.subscribe(res => {
      console.log("reload Data> ", res);
      this.getRowReconcileData(runsheetId);
     });
  }

  getRowReconcileData(runsheetId: any) {
    this.reconsileService.getViewRunsheetId(runsheetId)
   .subscribe(
     (result: any) => {
       this.runsheetRowData.push(result.runsheet);
       this.runsheetRowData.map((runsheetRow: any) => {
          this.runsheetLinesRow = runsheetRow.runsheetLines;
          this.driverBreaks = runsheetRow.driverBreaks;

          console.log("driverBreaks >>",this.runsheetLinesRow);
       })
       
     }
   );
 }




 addServiceBy() {
  console.log("Hi addServiceBy");
  this.reconsileService.selectedItemType.next("add-by-service");
}

addEntity() {
  console.log("click runsheet-line");
  this.reconsileService.selectedItemType.next("runsheet-line");
}

break() {
  this.reconsileService.selectedItemType.next("break");
}

deletebreak() {
  console.log("Delete Break");
  
}
/**on click on break row we need to pass that data to break form 
 * For Edit Sistuation
 */
breakForm(event:any){
  this.reconsileService.selectedItemType.next("break");
  console.log("helooooooooooooooooooooooooooooooooooooooooooooooooooooooo");

}

}
