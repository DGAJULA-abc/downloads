import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRunsheetFormComponent } from './view-runsheet-form.component';

describe('ViewRunsheetFormComponent', () => {
  let component: ViewRunsheetFormComponent;
  let fixture: ComponentFixture<ViewRunsheetFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewRunsheetFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewRunsheetFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
