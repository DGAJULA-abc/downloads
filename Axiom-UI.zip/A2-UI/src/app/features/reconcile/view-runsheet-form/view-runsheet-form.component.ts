import { Component, SimpleChanges } from '@angular/core';
import { MessageService, SelectItem } from 'primeng/api';
import { ReconcileService } from '../services/reconcile.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../../setup/service/setup.service';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import {
  ErrorList,
  ExceptionInfo,
  GenericError,
  ReasonCode,
  ReasonLine,
  Runsheet,
  RunsheetFormRequest,
  ViewRunsheetRunsheetId,
} from './ViewRunsheetId.model';
import * as moment from 'moment';
import { Driver } from '../models/view.reconcile.model';
import { RunsheetFormService } from '../services/runsheet-form.service';
import { RunsheetDetail } from '../detail/detail2.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-view-runsheet-form',
  templateUrl: './view-runsheet-form.component.html',
  styleUrls: ['./view-runsheet-form.component.scss'],
})
export class ViewRunsheetFormComponent {
  items: SelectItem[];
  isNew: boolean = false;
  // runsheetTypeId: SelectItem[];
  runsheetTypeId: any;

  data: any[] = [];
  alldata: any[] = [];
  rowData: any[] = [];

  selectedItem: string | undefined;
  runsheetId: any = '';
  shiftId: any;
  //type
  filteredRunsheetTypes: any[];
  runsheetsTypeId: any[] = [];
  selectedRunsheetTypeId: any[] | any;
  runsheetTypeValueDrop: any;
  runsheetTypeDropArr: any[] = [];
  runsheetOptionSelectedVal: any;

  //Driver
  filteredDriver: any[] = [];
  driverId: any[] = [];
  allDriver: any[] = [];
  selectedDriverId: any[] | any;
  driverIdRequest: any;
  driverIdVal: any;

  //Odometer
  startkm: number;
  endkm: number;
  rateId: any;
  reconcileRunsheetInputHoldcode: any;
  serviceDetailComboboxReason: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  gridOptions: any;
  selectedReasonId: any[] | any;

  idRunsheetData: RunsheetFormRequest | any = {};

  lockUserName = '';
  editDeliverydateDate: any;

  columnDefs: any[] = [
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      cellRenderer: CellrenderComponent,
      filter: 'agNumberColumnFilter',
    },
    { field: 'runsheettypeid', headerName: 'Runsheet Type Id' },
    { field: 'deliverydate', headerName: 'Delivery Date' },
    { field: 'publicholidayapplies', headerName: 'Public Holiday Applies' },
    { field: 'driverid', headerName: 'Driver Id' },
    { field: 'driver', headerName: 'Driver' },
  ];
  errFirst: any;
  runsheetLineId: any;

  editFormObj = {
    id: 14008010,
    locationContDropId: null,
    locationContPickupId: 123,
    locationDropId: '3000166-BACCHUS MARSH',
    locationPickupId: '1246 THOMASTOWN',
    locationReturnId: null,
    serviceId: 15441966,
    trailerId: null,
    containerId: null,
    loadTypeId: 'DELIVERY',
    trailerTagId: null,
    serviceTypeId: 'EXPORT',
    rateId: 'P500PERTRIP',
    truckId: null,
    siteId: 999,
    qty1: 44,
    unit1: 'TONNES',
    qty2: 45,
    unit2: 'HOURS',
    qty3: null,
    unit3: null,
    qty4: null,
    unit4: null,
    qty5: null,
    unit5: null,
    qty6: null,
    unit6: null,
    qty7: null,
    unit7: null,
    qty8: null,
    unit8: null,
    owntrailer: false,
    offsiderused: false,
    pickuparrivetime: 1700053200000,
    pickupdeparttime: 1700744400000,
    droparrivetime: 1699448400000,
    dropreadytime: null,
    dropdeparttime: 1700139600000,
    docket: null,
    payamt: 500,
    startkm: null,
    endkm: null,
    holdcode: null,
    payestimated: false,
    directfromdepot: false,
    remarks: 'rating component',
    nextstoptime: null,
    tripkm: 0,
    paydesc: '$500.00 (Trip $500.00)',
    pickupreadytime: null,
    dropdoctime: null,
    pickupdoctime: null,
    createdby: 'dhavaltr',
    tripno: 1,
    tripseq: 1,
    servicehours: null,
    hiretruck: false,
    globaldropbonus: null,
    deliverydate: 1699448400000,
    tripodostart: null,
    tripodoend: null,
    groupseq: null,
    tripstarttime: null,
    reasonLines: [
      {
        id: 552916,
        reasonId: '105',
        siteId: 999,
        reasoncomment: null,
        reasonrefEvent: null,
        reasonrefRunsheet: null,
        reasonrefService: null,
      },
    ],
    tripendtime: null,
    lineTemperature: null,
    runsheetLines: [
      {
        id: 14008010,
        locationContDropId: null,
        locationContPickupId: null,
        locationDropId: '3000166-BACCHUS MARSH',
        locationPickupId: '1246 THOMASTOWN',
        locationReturnId: '1246 THOMASTOWN',
        serviceId: 15441966,
        trailerId: '1234',
        containerId: null,
        loadTypeId: 'DELIVERY',
        trailerTagId: '39465-S',
        serviceTypeId: 'EXPORT',
        rateId: 'P500PERTRIP',
        truckId: 'A1SYNCTRUCK',
        siteId: 999,
        qty1: 44,
        unit1: 'TONNES',
        qty2: 45,
        unit2: 'HOURS',
        qty3: null,
        unit3: null,
        qty4: null,
        unit4: null,
        qty5: null,
        unit5: null,
        qty6: null,
        unit6: null,
        qty7: null,
        unit7: null,
        qty8: null,
        unit8: null,
        owntrailer: false,
        offsiderused: false,
        pickuparrivetime: 1700053200000,
        pickupdeparttime: 1700744400000,
        droparrivetime: 1699448400000,
        dropreadytime: null,
        dropdeparttime: 1700139600000,
        docket: null,
        payamt: 250,
        payestimated: false,
        directfromdepot: false,
        remarks: 'rating component',
        nextstoptime: null,
        tripkm: 1,
        paydesc: '$500.00 (Trip $500.00) + (2 stp x $0.00)',
        pickupreadytime: null,
        dropdoctime: null,
        pickupdoctime: null,
        createdby: 'dhavaltr',
        tripno: 1,
        tripseq: 1,
        servicehours: null,
        hiretruck: false,
        globaldropbonus: null,
        deliverydate: 1699448400000,
        tripodostart: 3,
        tripodoend: 4,
        groupseq: null,
        tripstarttime: 1698843600000,
        tripendtime: 1700053200000,
        lineTemperature: null,
        lineServiceTO: {
          serviceId: 15441966,
          dataSource: 'A2',
          created: 1699376153000,
          tripIdCust: null,
          serviceGroup: null,
          serviceDesc: null,
          customerId: '1052601',
          consignmentMasterCustomerId: '1052601',
          loadId: 13791515,
          serviceNo: 'M0083289',
          reasonId: '105',
          chargeAmt: 42.3,
          chargeDesc:
            'Point-Point-KM 84.6 X $1.00 (Incl. Return to 1246 THOMASTOWN) + (2 stp x $0.00)',
          rateId: 'ZZBEN',
          complete: false,
          loadNo: 'L0097771',
          batchNo: '3443',
          custRef: 'r45',
          scheduleDate: 1699448400000,
          despatchBy: null,
          deliveryOpen: 1698843600000,
          deliveryClose: null,
          returnLocationId: null,
          pickupLocation: {
            locationId: '1246 THOMASTOWN',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'COD ROBERT JARVIS CASH SALE',
            zonePayId: 'METRO',
            zoneChargeId: 'METRO',
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          dropLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: 'PZONEOUT3',
            zoneChargeId: 'CZONEOUT3',
            suburb: 'BACCHUS MARSH',
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: 'LOT 2 GISBORNE ROAD',
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          loadLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: null,
            zoneChargeId: null,
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          lastGroupSeq: null,
          clearCharge: false,
          totalChargeAmt: 84.6,
          svcReasonLines: [],
          dehireDeadline: null,
          vesselEta: 1699362000000,
          vesselId: 1801,
          priority: null,
          wharf: '1246- CRAIGIEBURN',
          depot: 'ASAHI ARCHERFIELD DC',
          customerSite: '3BUNNALTO-ALTONA',
          dehirePark: '1250 - ALTONA NORTH',
          originSite: 999,
          originLoc: '1246- CRAIGIEBURN',
          destinationSite: 999,
          destinationLoc: '1246 THOMASTOWN',
        },
        events: null,
        loadNoDuplicated: null,
      },
      {
        id: 14008013,
        locationContDropId: null,
        locationContPickupId: null,
        locationDropId: '3000166-BACCHUS MARSH',
        locationPickupId: '1246 THOMASTOWN',
        locationReturnId: '1246 THOMASTOWN',
        serviceId: 15442239,
        trailerId: '1234',
        containerId: null,
        loadTypeId: 'DELIVERY',
        trailerTagId: '39465-S',
        serviceTypeId: 'DEMURRAGE',
        rateId: 'P500PERTRIP',
        truckId: 'A1SYNCTRUCK',
        siteId: 999,
        qty1: null,
        unit1: null,
        qty2: null,
        unit2: null,
        qty3: null,
        unit3: null,
        qty4: null,
        unit4: null,
        qty5: null,
        unit5: null,
        qty6: null,
        unit6: null,
        qty7: null,
        unit7: null,
        qty8: null,
        unit8: null,
        owntrailer: false,
        offsiderused: false,
        pickuparrivetime: 1700053200000,
        pickupdeparttime: 1700744400000,
        droparrivetime: 1699448400000,
        dropreadytime: null,
        dropdeparttime: 1700139600000,
        docket: null,
        payamt: 250,
        payestimated: false,
        directfromdepot: false,
        remarks: 'rating component',
        nextstoptime: null,
        tripkm: 0,
        paydesc: '$500.00 (Trip $500.00) + (2 stp x $0.00)',
        pickupreadytime: null,
        dropdoctime: null,
        pickupdoctime: null,
        createdby: 'dhavaltr',
        tripno: 1,
        tripseq: 2,
        servicehours: null,
        hiretruck: false,
        globaldropbonus: null,
        deliverydate: 1699448400000,
        tripodostart: null,
        tripodoend: null,
        groupseq: null,
        tripstarttime: 1698843600000,
        tripendtime: 1700053200000,
        lineTemperature: null,
        lineServiceTO: {
          serviceId: 15442239,
          dataSource: 'RS',
          created: 1699891064000,
          tripIdCust: null,
          serviceGroup: null,
          serviceDesc: null,
          customerId: '1052601',
          consignmentMasterCustomerId: '1052601',
          loadId: 13791515,
          serviceNo: 'M0083542',
          reasonId: '105',
          chargeAmt: 42.3,
          chargeDesc:
            'Point-Point-KM 84.6 X $1.00 (Incl. Return to 1246 THOMASTOWN) + (2 stp x $0.00)',
          rateId: 'ZZBEN',
          complete: false,
          loadNo: 'L0097771',
          batchNo: '3443',
          custRef: 'r45',
          scheduleDate: 1699448400000,
          despatchBy: null,
          deliveryOpen: 1698843600000,
          deliveryClose: null,
          returnLocationId: null,
          pickupLocation: {
            locationId: '1246 THOMASTOWN',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'COD ROBERT JARVIS CASH SALE',
            zonePayId: 'METRO',
            zoneChargeId: 'METRO',
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          dropLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: 'PZONEOUT3',
            zoneChargeId: 'CZONEOUT3',
            suburb: 'BACCHUS MARSH',
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: 'LOT 2 GISBORNE ROAD',
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          loadLocation: {
            locationId: '3000166-BACCHUS MARSH',
            siteId: 999,
            locationTypeId: null,
            locationDesc: 'ESTHER MCCLUSKEY',
            zonePayId: null,
            zoneChargeId: null,
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null,
          },
          lastGroupSeq: null,
          clearCharge: false,
          totalChargeAmt: 84.6,
          svcReasonLines: [],
          dehireDeadline: null,
          vesselEta: 1699362000000,
          vesselId: 1801,
          priority: null,
          wharf: '1246- CRAIGIEBURN',
          depot: 'ASAHI ARCHERFIELD DC',
          customerSite: '3BUNNALTO-ALTONA',
          dehirePark: '1250 - ALTONA NORTH',
          originSite: 999,
          originLoc: '1246- CRAIGIEBURN',
          destinationSite: 999,
          destinationLoc: '1246 THOMASTOWN',
        },
        events: null,
        loadNoDuplicated: null,
      },
    ],
    events: [],
  };

  runsheetDetailLIneFormObj = {};
  loadLocationFormObj = {};
  containerFormObj = {};
  breakFormObj = {};
  ratingFormObj = {};

  runsheetLines = [];
  runsheetLinesObj: any[]= [];
  serviceFormReceivedData: any = {};
  loadFormReceivedData: any = {};
  containerFormReceivedData: any = {};
  subscription: Subscription;
  // runsheetLines: FormArray;
  errorDetail: any;
  errorInner: any;
  exceptionTime: any;
  errorHeader2: any;

  constructor(
    private reconsileService: ReconcileService,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router,
    private runsheetFormService: RunsheetFormService,
    private messageService: MessageService
  ) {
    // this.subscription = this.runsheetFormService.formData$.subscribe((data) =>{
    //   this.receivedData = data;
    //   console.log("service data:", this.receivedData)
    // })
  }

  reconcileFormCreateRunsheet = this.fb.group({
    runsheetTypeId: ['', Validators.required],
    driverId: ['', Validators.required],
    starttime: ['', Validators.required],
    endtime: ['', Validators.required],
    returndepottime: ['', Validators.required],
    startkm: ['', Validators.required],
    endkm: ['', Validators.required],
    remarks: ['', Validators.required],
    holdcode: ['', Validators.required],
    reasonId: ['', Validators.required],
    serviceDetailComboboxReason: ['', Validators.required],
    driverBreaks: [],
    payAdviceLines: [],
    invoiceLines: [],
    reasonLines: [],
    runsheetLines: this.fb.group({
      lineServiceTO: this.fb.group({
        dropLocation: this.fb.group({}),
        loadLocation: this.fb.group({}),
        pickupLocation: this.fb.group({}),
      }),
    }),
  });

  //  enddate: this.formRunsheet.enddate
  // runsheetLines: ThisParameterType.formRunsheet.runsheetLines
  // invoiceLines: this.formRunsheet.invoiceLines
  // payAdviceLines:  this.formRunsheet.payAdviceLines
  // reasonLines:  this.formRunsheet.payAdviceLines
  // driverBreaks: this.formRunsheet.driverBreaks
  // shiftId:  this.formRunsheet.shiftId
  // reasonLines:  this.formRunsheet.payAdviceLines

  ngOnInit() {
    this.subscription = this.runsheetFormService.formData$.subscribe((data) => {
      this.serviceFormReceivedData = data.value;
      //console.log("service data:", this.receivedData)
    });
    this.subscription = this.runsheetFormService.loadFormData$.subscribe(
      (data) => {
        this.loadFormReceivedData = data.value;
        //console.log("service data:", this.receivedData)
      }
    );
    this.subscription = this.runsheetFormService.containerFormData$.subscribe(
      (data) => {
        this.containerFormReceivedData = data.value;
        //console.log("service data:", this.receivedData)
      }
    );
    setInterval(() => {
      this.renewLocks();
    }, 5000);
    this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    // console.log('runsheetId >> ', this.runsheetId);
    this.getRunseetIdData(this.runsheetId);
    this.getRunsheetTypes();
    this.getDriver();
    this.getReasonCode();
    this.runshheetMode(+this.runsheetId);
    this.getMultiLegData();
    // this.runsheetFormObjMapping();
  }

  renewLocks() {
    this.reconsileService.renew().subscribe((response) => {});
  }

  runshheetMode(id: any) {
    this.reconsileService
      .showErrors(id, this.shiftId)
      .subscribe((renewLockData: any) => {
        // console.log('renewLocks >>', renewLockData);
      });

    this.reconsileService.lockRunsheet(id).subscribe((renewLockData: any) => {
      // console.log('renewLocks >>', renewLockData);
    });
  }

  reconcileFormCreateRunsheetSubmit() {
    const formRunsheet = this.reconcileFormCreateRunsheet.value;
    // driverIDCreate =
    const driverIdCrea = Number(formRunsheet.driverId?.split('-')[0]);
    // if(this.runsheetLineId) {
    //   return this.runsheetLineId;
    // } else {
    //   return null
    // }
    this.runsheetLineId ? this.runsheetLineId : null;
    const realFormData = {
      // runsheetTypeId: this.reconcileFormCreateRunsheet.value.runsheetTypeId,
      // driverId: driverIdCrea,
      // starttime: moment(formRunsheet.starttime, 'YYYY-MM-DD[T]HH:mm:ss').format(
      //   'x'
      // ),
      // endtime: moment(formRunsheet.endtime, 'YYYY-MM-DD[T]HH:mm:ss').format(
      //   'x'
      // ),
      // returndepottime: moment(
      //   formRunsheet.returndepottime,
      //   'YYYY-MM-DD[T]HH:mm:ss'
      // ).format('x'),.
      runsheetTypeId: 'PALLET',
      driverId: 10283,
      starttime: 1700571600000,
      endtime: 1700600400000,
      returndepottime: 1700600400000,
      startkm: 3443,
      endkm: 4545,
      holdcode: 'User: 3434',
      remarks: formRunsheet.remarks,
    };

    if((Object.keys(this.serviceFormReceivedData).length===0) && (Object.keys(this.loadFormReceivedData).length ===0) && (Object.keys(this.containerFormReceivedData).length===0)){
      this.runsheetLinesObj =[];
    } else {

    

    this.runsheetLinesObj = [
      {
        id: this.runsheetLineId,
        lineServiceTO: {
          svcReasonLines: [],
          loadNo: this.loadFormReceivedData.loadno,
          loadId: null,
          originSite: 999,
          destinationSite: 999,
          customerId: this.serviceFormReceivedData.customerId,
          pickupLocation: {
            locationDesc: 'Asahi Archerfield DC',
            zoneChargeId: 'METRO',
            zonePayId: 'METRO',
          },
          dropLocation: {
            locationDesc: 'Asahi Archerfield DC',
            zoneChargeId: 'METRO',
            zonePayId: 'METRO',
          },
          loadLocation: {
            locationDesc: 'Asahi Archerfield DC',
            locationId: 'ASAHI ARCHERFIELD DC',
          },
          batchNo: this.serviceFormReceivedData.batchNo,
          custRef: this.serviceFormReceivedData.custRef,
          scheduleDate: this.loadFormReceivedData.scheduleDate,
          deliveryOpen: this.loadFormReceivedData.deliveryOpen,
          deliveryClose: this.loadFormReceivedData.deliveryClose,
          vesselId: 1801,
          wharf: this.containerFormReceivedData.wharf,
          depot: this.containerFormReceivedData.depot,
          customerSite: 'IGA',
          dehirePark: '1250 - ALTONA NORTH',
        },
        truckId: 'TOLLFAST-OURIER',
        trailerId: null,
        tripno: 1,
        loadTypeId: this.loadFormReceivedData.laodTypeId,
        serviceTypeId: this.serviceFormReceivedData.serviceTypeId,
        qty1: 1,
        qty2: 1,
        qty3: null,
        qty4: null,
        qty5: null,
        qty6: null,
        qty7: null,
        qty8: null,
        events: [],
        unit1: 'TONNES',
        unit2: 'PALLETS',
        unit3: 'DOLLARS',
        unit4: 'HOURS',
        unit5: 'CONTAINERS',
        unit6: 'KILOGRAMS',
        unit7: 'KILOMETRES',
        unit8: 'REELS',
        tripseq: 1,
        deliverydate: 1701176400000,
        siteId: 999,
        lineTemperature: null,
        docket: this.containerFormReceivedData.docket,
        locationPickupId: 'ASAHI ARCHERFIELD DC',
        locationDropId: 'ASAHI ARCHERFIELD DC',
        containerId: 'qw',
        hiretruck: false,
        owntrailer: false,
        offsiderused: false,
        directfromdepot: false,
        payestimated: false,
      },
    ];
  }

    console.log("forms:", this.serviceFormReceivedData, this.loadFormReceivedData, this.containerFormReceivedData)
    const runsheetIdFormVal = {
      id: this.idRunsheetData.id,
      rateId: this.idRunsheetData.rateId,
      truckId: this.idRunsheetData.truckId,
      siteId: this.idRunsheetData.siteId,
      deliverydate: this.idRunsheetData.deliverydate,
      publicholidayapplies: this.idRunsheetData.publicholidayapplies,
      cashshortage: this.idRunsheetData.cashshortage,
      stockshortage: this.idRunsheetData.stockshortage,
      calcpaybyload: this.idRunsheetData.calcpaybyload,
      calcpaybyhour: this.idRunsheetData.calcpaybyhour,
      payamt: this.idRunsheetData.payamt,
      payhourly: this.idRunsheetData.payhourly,
      payincentive: this.idRunsheetData.payincentive,
       payallowance: this.idRunsheetData.payallowance,
      hoursnormal: this.idRunsheetData.hoursnormal,

      hoursthalf: this.idRunsheetData.hoursthalf,
      hoursdouble: this.idRunsheetData.hoursdouble,
      shiftrate: this.idRunsheetData.shiftrate,
      shifthours: this.idRunsheetData.shifthours,
      shiftamt: this.idRunsheetData.shiftamt,
      complete: this.idRunsheetData.complete,
      createdby: this.idRunsheetData.createdby,

      paydesc: this.idRunsheetData.paydesc,
      exported: this.idRunsheetData.exported,
      odokm: this.idRunsheetData.odokm,
      gpskm: this.idRunsheetData.gpskm,
      eventgenerated: this.idRunsheetData.eventgenerated,
      globaldropbonus: this.idRunsheetData.globaldropbonus,
      created: this.idRunsheetData.created,
      shiftUUID: this.idRunsheetData.shiftUUID,
      invoiceLines: this.idRunsheetData.invoiceLines,
      payAdviceLines: this.idRunsheetData.payAdviceLines,
      reasonLines: this.idRunsheetData.reasonLines,
      runsheetLines: this.getUpdatedRunSheetLineData(this.idRunsheetData.runsheetLines, this.runsheetLinesObj),
      shiftId: this.idRunsheetData.shiftId,
      driverBreaks: this.idRunsheetData.driverBreaks,
    };
    //console.log("invoiceLines:", this.idRunsheetData.invoiceLines)
    const runsheetFormMerge = { ...runsheetIdFormVal, ...realFormData };

    this.runsheetFormService.runSheetFormSubject.next(runsheetFormMerge);

    //console.log('form values >>', this.serviceFormReceivedData, this.loadFormReceivedData, this.containerFormReceivedData);

    //console.log("obj:", runsheetLinesObj)
    this.submitRunsheetForm(runsheetFormMerge);
  }
  /**
   * Check this function since getting some error
   *
   * */
  getUpdatedRunSheetLineData(runsheetApiData: any, formData: any) {
    let runsheetApiDataArray = [];
    let runsheetFormDataArray = [];
    if(runsheetApiData && runsheetApiData.length > 0) {
      runsheetApiDataArray = runsheetApiData;
    }

    if(formData && formData.length > 0  ) {
      if(formData.id === null) {
        runsheetFormDataArray = formData;
      } else {
        runsheetApiDataArray = runsheetApiDataArray.map((obj: any) => formData.find((o: any) => o.id === obj.id) || obj);
      }
      console.log(runsheetApiDataArray);
    }
    return [...runsheetApiDataArray, ...runsheetFormDataArray];
  }

  runsheetLinesFormObj: any;
  submitRunsheetForm(runsheetFormMerge: any) {
    // this.runsheetLines = this.runsheetFormService.runSheetlineForm
    // this.runsheetLinesFormObj = this.runsheetFormService?.runSheetlineForm;
    // this.loadLocationFormObj = this.runsheetFormService?.serviceLoadForm;
    // this.containerFormObj = this.runsheetFormService?.runsheetLineContainerForm;
    // this.breakFormObj = this.runsheetFormService?.runsheetBreakForm;
    // debugger;
    //  runsheetFormMerge.lineServiceTO = this.runsheetLinesFormObj;
    // runsheetFormMerge.lineServiceTO.loadLocation = this.loadLocationFormObj;
    // runsheetFormMerge.lineServiceTO.containers = this.containerFormObj;

    /**since driver breaktype is an array of object  */
    //   var breakObject = this.breakFormObj;
    //   var breakArray = [breakObject];
    // runsheetFormMerge.driverBreaks = breakArray;
    // // this.runsheetLines = this.runsheetFormService.runSheetlineForm
    // this.runsheetDetailLIneFormObj = this.runsheetFormService?.serviceDetailForm;
    // this.loadLocationFormObj = this.runsheetFormService?.serviceLoadForm;
    // this.containerFormObj = this.runsheetFormService?.runsheetLineContainerForm;
    // this.breakFormObj = this.runsheetFormService?.runsheetBreakForm
    //  runsheetFormMerge.lineServiceTO = this.runsheetLinesFormObj;
    // runsheetFormMerge.lineServiceTO.loadLocation = this.loadLocationFormObj;
    // runsheetFormMerge.lineServiceTO.containers = this.containerFormObj;

    /**since driver breaktype is an array of object  */
    //   var breakObject = this.breakFormObj;
    //   var breakArray = [breakObject];
    // runsheetFormMerge.driverBreaks = breakArray;
   

    console.log(
      'runsheetFormMerge >>',
      runsheetFormMerge,
      this.idRunsheetData.invoiceLines
    );
    // this.runsheetFormService.runSheetFormParentObject.next(runsheetFormMerge)
    //  let requestParam = {"id":3045858,"runsheetTypeId":"PALLET","rateId":null,"truckId":"831","siteId":999,"driverId":10283,"deliverydate":1700571600000,"publicholidayapplies":false,"starttime":1700571600000,"endtime":1700600400000,"returndepottime":1700600400000,"startkm":3443,"endkm":4545,"cashshortage":null,"stockshortage":null,"calcpaybyload":false,"calcpaybyhour":false,"payamt":null,"payhourly":null,"payincentive":null,"payallowance":null,"hoursnormal":null,"hoursthalf":null,"hoursdouble":null,"shiftrate":null,"shifthours":null,"shiftamt":null,"holdcode":"User: 3434","complete":false,"remarks":"Test","createdby":"dhavaltr","paydesc":null,"exported":false,"odokm":null,"gpskm":null,"enddate":1700571600000,"eventgenerated":false,"globaldropbonus":null,"created":1700660588000,"runsheetLines":[{"id":14008028,"locationContDropId":null,"locationContPickupId":null,"locationDropId":"COSTCO","locationPickupId":"WaggaRSL","locationReturnId":"WaggaRSL","serviceId":15442279,"trailerId":"39465-S","containerId":"12341234","loadTypeId":"EMPTY","trailerTagId":"L62779","serviceTypeId":"LOCAL","rateId":null,"truckId":"831","siteId":999,"qty1":12,"unit1":"TONNES","qty2":12,"unit2":"PALLETS","qty3":12,"unit3":"DOLLARS","qty4":1,"unit4":"HOURS","qty5":12,"unit5":"CONTAINERS","qty6":1,"unit6":"KILOGRAMS","qty7":1,"unit7":"KILOMETRES","qty8":1,"unit8":"REELS","owntrailer":false,"offsiderused":false,"pickuparrivetime":null,"pickupdeparttime":null,"droparrivetime":null,"dropreadytime":null,"dropdeparttime":1700744400000,"docket":"123","payamt":null,"payestimated":false,"directfromdepot":false,"remarks":"2345","nextstoptime":null,"tripkm":0,"paydesc":null,"pickupreadytime":null,"dropdoctime":null,"pickupdoctime":null,"createdby":"dhavaltr","tripno":1,"tripseq":1,"servicehours":null,"hiretruck":false,"globaldropbonus":null,"deliverydate":1700571600000,"tripodostart":null,"tripodoend":null,"groupseq":null,"tripstarttime":null,"tripendtime":1700744400000,"lineTemperature":null,"lineServiceTO":{"serviceId":15442279,"dataSource":"A2","created":1700459928000,"tripIdCust":"T33498","serviceGroup":null,"serviceDesc":"23","customerId":"MEL001","consignmentMasterCustomerId":"MEL001","loadId":13791826,"serviceNo":"M0083566","reasonId":"103","chargeAmt":null,"chargeDesc":null,"rateId":null,"complete":false,"loadNo":"L0098046","batchNo":"234","custRef":"1234","scheduleDate":1700571600000,"despatchBy":null,"deliveryOpen":1696251600000,"deliveryClose":1695650400000,"returnLocationId":"WaggaRSL","pickupLocation":{"locationId":"WaggaRSL","siteId":999,"locationTypeId":null,"locationDesc":"Wagga RSL Club","zonePayId":"METRO","zoneChargeId":"METRO","suburb":"Wagga Wagga","active":null,"loadTimeMins":null,"address1":"Kincaid St & Dobbs St","address2":null,"state":null,"postCode":null,"window1From":null,"window1To":null,"window2From":null,"window2To":null,"window3From":null,"window3To":null,"personIdContact":null,"personIdContactName":null,"customerId":null,"locationCode":null,"latitude":null,"longitude":null,"geofence":null,"mapSourceId":null,"mapReference":null,"remarks":null,"truckSizeLimit":null,"defaultTripSeq":null,"routeId":null,"permanent":null,"loadTimeMinsPerUnit":null,"loadTimeUnit":null,"waitTimeMins":null,"waitTimeMinsPerUnit":null,"waitTimeUnit":null,"accShortCut":null,"locationIdGroup":null,"siteTravelTime":null,"disableWPUpdated":null,"externalLookUp":null,"internalLookUp":null,"segManaged":null,"segExported":null,"routeCapacity":null},"dropLocation":{"locationId":"COSTCO","siteId":999,"locationTypeId":null,"locationDesc":"Costco - North Lakes","zonePayId":"METRO","zoneChargeId":"METRO","suburb":"North Lakes","active":null,"loadTimeMins":null,"address1":"17-39 Cook St","address2":null,"state":null,"postCode":null,"window1From":null,"window1To":null,"window2From":null,"window2To":null,"window3From":null,"window3To":null,"personIdContact":null,"personIdContactName":null,"customerId":null,"locationCode":null,"latitude":null,"longitude":null,"geofence":null,"mapSourceId":null,"mapReference":null,"remarks":null,"truckSizeLimit":null,"defaultTripSeq":null,"routeId":null,"permanent":null,"loadTimeMinsPerUnit":null,"loadTimeUnit":null,"waitTimeMins":null,"waitTimeMinsPerUnit":null,"waitTimeUnit":null,"accShortCut":null,"locationIdGroup":null,"siteTravelTime":null,"disableWPUpdated":null,"externalLookUp":null,"internalLookUp":null,"segManaged":null,"segExported":null,"routeCapacity":null},"loadLocation":{"locationId":"COSTCO","siteId":999,"locationTypeId":null,"locationDesc":"Costco - North Lakes","zonePayId":null,"zoneChargeId":null,"suburb":null,"active":null,"loadTimeMins":null,"address1":null,"address2":null,"state":null,"postCode":null,"window1From":null,"window1To":null,"window2From":null,"window2To":null,"window3From":null,"window3To":null,"personIdContact":null,"personIdContactName":null,"customerId":null,"locationCode":null,"latitude":null,"longitude":null,"geofence":null,"mapSourceId":null,"mapReference":null,"remarks":null,"truckSizeLimit":null,"defaultTripSeq":null,"routeId":null,"permanent":null,"loadTimeMinsPerUnit":null,"loadTimeUnit":null,"waitTimeMins":null,"waitTimeMinsPerUnit":null,"waitTimeUnit":null,"accShortCut":null,"locationIdGroup":null,"siteTravelTime":null,"disableWPUpdated":null,"externalLookUp":null,"internalLookUp":null,"segManaged":null,"segExported":null,"routeCapacity":null},"lastGroupSeq":null,"clearCharge":false,"totalChargeAmt":null,"svcReasonLines":[],"dehireDeadline":1695650400000,"vesselEta":1696251600000,"vesselId":1801,"priority":null,"wharf":"1246- CRAIGIEBURN","depot":"BSL MELBOURNE TERMINAL","customerSite":"IMPACT STELL - DANDENONG","dehirePark":"1250 - ALTONA NORTH","originSite":999,"originLoc":"1246- CRAIGIEBURN","destinationSite":999,"destinationLoc":"1246- CRAIGIEBURN"},"events":[{"id":49606904,"key":15442279,"eventTypeId":39,"dockId":null,"locationId":null,"serviceId":null,"trailerId":"39465-S","tripId":5377379,"truckId":"831","siteId":999,"driverId":10280,"trailerTagId":"L62779","loggedDateTime":1699228850000,"value1":null,"value2":null,"textValue":null,"userId":"palaktri","time1":null,"time2":null,"textValue2":null,"exception":false,"exceptiondesc":null,"exported":false,"eventAdjusted":false,"datasourceId":"A2","latitude":null,"longitude":null,"fleetId":null,"unitId":null,"vehicleId":null,"mdrego":null,"mdtcode":null,"mdservertime":null,"created":1700462458000,"certainty":null,"compliant":null,"comments":null,"eventLevel":"TRIP","eventTime":1699228850000,"eventDescription":"Allocated","todexportable":false,"tripIdCust":"T33498","loadNo":"L0098046","employeeName":"TESTER","companyId":"3ASSOC08","firstName":null,"lastName":null,"tripNo":null,"serviceNo":"M0083566"}],"loadNoDuplicated":null}],"invoiceLines":[],"payAdviceLines":[],"reasonLines":[{"id":552943,"reasonId":"105","siteId":999,"reasoncomment":null,"reasonrefEvent":null,"reasonrefRunsheet":null,"reasonrefService":null}],"driverBreaks":[],"shiftId":null,"shiftUUID":null}

    this.runshheetMode(this.runsheetId);
    this.reconsileService
      .viewRunsheetSubmit(runsheetFormMerge)
      .subscribe((resRunsheetSubmit: any) => {
        console.log('resRunsheetSubmit >>', resRunsheetSubmit);
      });
  }

  getRunseetIdData(runsheetId: any) {
    this.reconsileService
      .getViewRunsheetId(runsheetId)
      .subscribe((resRunsheet: ViewRunsheetRunsheetId) => {
        this.isNew = resRunsheet.isNew;
        if (this.isNew) {
          this.router.navigate(['reconcile/CreateRunsheet']);
        }
        this.idRunsheetData = resRunsheet.runsheet;

        console.log('runsheetId data >>>>', resRunsheet);
      console.log('runsheetId data >>>>', resRunsheet.runsheet.runsheetLines);

        this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;
        this.driverIdVal = resRunsheet.runsheet.driverId;
        this.runsheetsTypeId.filter((filterId: any) => {
          if (filterId === this.runsheetTypeId) {
            this.selectedRunsheetTypeId = filterId;
          }
        });

        this.reconsileService.lockRunsheet(runsheetId).subscribe(
          (lockRunsheet: any) => {
            console.log('LockRunsheet>>', lockRunsheet);
          },
          (err: any) => {
            const  lockErr: ErrorList = err.error.errorList;
            const lockErrDetail: ExceptionInfo =
              err.error.errorList.ExceptionInfos[0];
            this.errFirst = '';
            this.errorHeader2 = lockErr.ErrorMessage;
            this.errorInner = lockErrDetail.UserErrorDescription;
            this.exceptionTime = lockErr.ExceptionTime;
            const lockUsername =lockErrDetail.UserErrorDescription.indexOf('BY ') + 3;
            this.lockUserName = lockErrDetail.UserErrorDescription.substring(lockUsername);
            if (lockErrDetail.ErrorType === 'INTERNAL') {
              this.errFirst = '500 Internal Server Error';
            }

            console.log('Runsheet Error', lockErr);

            this.messageService.add({
              key: 'customToast',
              severity: 'error',
              life: 30000,
            });
          }
        );

        this.allDriver.map((filterDriver: any) => {
          // console.log("filterDriver >> ", filterDriver);
          if (filterDriver.id === resRunsheet.runsheet.driverId) {
            // console.log('driverId >>', filterDriver);
            this.selectedDriverId =
              this.reconsileService.getDriverDropProperVal(filterDriver);
          }
        });
        // this.selectedReasonId  = '112_Dhaval';
        this.reasonCode.filter((reasonCode: ReasonLine) => {
          if (reasonCode.id === this.editFormObj.reasonLines[0].id) {
            this.selectedReasonId =
              this.reconsileService.getReasonIdVal(reasonCode);
          }
        });
        //odometer
        this.editFormObj.startkm = resRunsheet.runsheet.startkm;
        this.editFormObj.endkm = resRunsheet.runsheet.endkm;
        this.editFormObj.rateId = resRunsheet.runsheet.rateId;
        this.editFormObj.holdcode = resRunsheet.runsheet.holdcode;
        this.editFormObj.remarks = resRunsheet.runsheet.remarks;

        // const deliveyDateVal =  moment(resRunsheet.runsheet.deliverydate).format("dddd, MMMM Do, YYYY h:mm A");
        // this.editDeliverydateDate = moment.unix(resRunsheet.runsheet.deliverydate).format("MM/DD/YYYY")
        // this.editFormObj.deliverydate = moment.unix(resRunsheet.runsheet.deliverydate).format("MM/DD/YYYY");
        const tmpDate = moment(resRunsheet.runsheet.deliverydate).format(
          'YYYY.MM.DD HH:MM:SS'
        );
        this.editDeliverydateDate = new Date(tmpDate).toLocaleDateString();

        this.editFormObj.runsheetLines.map((resRunsheetLine: any) => {
          console.log('resRunsheetLine >>', resRunsheetLine);
        });
      });
  }

  getMetaDataJson() {
    this.reconsileService.getMetaDataJson().subscribe((fieldssData: any) => {
      // console.log('FieldsData >', fieldssData);
    });
  }

  //dropdown type

  // runsheet Type
  filteredRunsheetTypesFun(event: any) {
    let runsheetTypeArr: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.runsheetsTypeId.length; i++) {
      // console.log("runsheetsTypeId >", this.runsheetsTypeId);

      let runsheetType = this.runsheetsTypeId[i];
      if (runsheetType.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        runsheetTypeArr.push(runsheetType);
      }
    }

    this.filteredRunsheetTypes = runsheetTypeArr;
  }

  //onchange type
  onChangeRunsheetType(runsheetValue: any) {
    // console.log('runsheetValue >', runsheetValue);
    this.selectedRunsheetTypeId = runsheetValue;
    this.runsheetTypeValueDrop = runsheetValue;
    // console.log("filteredRunsheetTypes mm> ", this.filteredRunsheetTypes);

    this.runsheetTypeDropArr.filter((runsheetSecectedData: any) => {
      if (runsheetSecectedData.runsheetsTypeId === runsheetValue) {
        // console.log('runsheetSecectedData', runsheetSecectedData);
        this.runsheetOptionSelectedVal = runsheetSecectedData;
      }
    });
  }

  getRunsheetTypes() {
    this.reconsileService.getRunsheetTypes().subscribe((runsheetTypes: any) => {
      runsheetTypes.map((runsheetType: any) => {
        //  console.log("getRunsheetTypes >>", adjustData);
        this.runsheetTypeDropArr = runsheetTypes;
        this.runsheetsTypeId.push(runsheetType.runsheetTypeId);
      });
    });
  }

  // Driver

  getDriver() {
    this.reconsileService.getDriver().subscribe((drivers: any) => {
      // console.log('driversList >>', drivers);
      this.allDriver = drivers;
      drivers.map((driver: Driver) => {
        const driverDropVal =
          this.reconsileService.getDriverDropProperVal(driver);
        // console.log('driverDropVal', driverDropVal);

        this.driverId.push(driverDropVal);
      });
    });
  }

  filteredDriverFn(event: any) {
    let driverArr: any[] = [];
    let query = event.query;
    this.driverId.map((driver: any) => {
      const driverIdSeperate = driver.split('-')[0];
      if (driverIdSeperate.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        driverArr.push(driver);
      }
    });
    this.filteredDriver = driverArr;
  }

  onChangeDriver(selectedDriver: any) {
    const driverId = selectedDriver.split('-')[0];

    const starttime = this.reconcileFormCreateRunsheet.get('starttime')?.value;
    const starttimeTimesatamp = +moment(
      starttime,
      'YYYY-MM-DD[T]HH:mm:ss'
    ).format('x');

    const request = {
      driverId: driverId,
      shiftSTartDate: starttimeTimesatamp,
    };

    this.getShiftDetails(request);
  }

  getShiftDetails(request: any) {
    this.reconsileService
      .getShiftDetails(request)
      .subscribe((shiftData: any) => {
        console.log('shiftData >>', shiftData);
      });
  }

  //reason code
  getReasonCode() {
    this.reconsileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: ReasonCode) => {
        if (reasonDrop.reasonDescription !== null) {
          const reasonCodeFormat =
            this.reconsileService.getReasonIdVal(reasonDrop);

          this.reasonCode.push(reasonCodeFormat);
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((reason: any) => {
      const resonId = reason.split('-')[0];

      if (resonId.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        reasonArr.push(resonId);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    // console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  reload() {
    window.location.reload();
  }

  getMultiLegData() {
    this.reconsileService._multiLangData.subscribe((runsheet: RunsheetDetail) => { 
      console.log("RunsheetLine Id  show>> ", runsheet.id);
      if(runsheet) {
        this.runsheetLineId = runsheet.id
          // this.selectedItemType = "runsheet-line";
      }
        
    })
  }
}
