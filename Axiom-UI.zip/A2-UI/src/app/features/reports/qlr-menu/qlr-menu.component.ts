import { Component, EventEmitter, OnInit, AfterViewInit, Output, ViewChild } from '@angular/core';
import { EditFoldersComponent } from '../edit-folders/edit-folders.component';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi, GridReadyEvent, IRowNode } from 'ag-grid-community';
import { HttpClient } from '@angular/common/http';
import { IDandName, QlrReports, ViewReport } from '../model/report.model';
import { Site } from "src/app/shared/model/context-vew.model";
import { ReportService } from '../services/report.service';
import { DeleteFolderComponent } from '../delete-folder/delete-folder.component';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'app-qlr-menu',
  templateUrl: './qlr-menu.component.html',
  styleUrls: ['./qlr-menu.component.scss'],
})

export class QlrMenuComponent implements OnInit {
  @ViewChild('closebutton') closebutton: { nativeElement: { click: () => void; }; };
  @ViewChild('mySelect') mySelect: MatSelect;

  //properties
  pageTitle: string = 'QLR Menu';
  canSaveNewReport: boolean = false;
  canProcessReport: boolean = false;
  isEdit: boolean = false;
  isNew: boolean = false;
  isRowSelected: boolean = false;
  gridAPI!: GridApi<QlrReports>;
  viewDetails: ViewReport;
  selectedServerId: null | IDandName;
  selectedFolderId: number;
  selectedSiteId: Site | undefined;
  selectedPermissionGroupId: number;
  selectedRowNode: null | IRowNode<QlrReports>;
  templateQlrReport: QlrReports; // scratch object to be used for updating.
  rowData: QlrReports[];
  filteredServer: any[];
  filteredFolder: any[];
  filteredSite: any[];
  filteredPermissiongroup: any[];
  formSelectedFolder: null | IDandName;
  formSelectedQuery: null | any;
  formSelectedLayout: null | any;
  gridUserVisibleColumns: any[];
  gridSelectedVisibleColumns: any[];
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  
  constructor(public dialog: MatDialog, private http: HttpClient, private reportService: ReportService) {}
  

  openEditFoldersDialog() {
    const dialogRef = this.dialog.open(EditFoldersComponent, { data: this.viewDetails.qlrFolders });  
    
    dialogRef.afterClosed().subscribe(result => {
      // received new list of QLRFolders
      this.viewDetails.qlrFolders = result;
    });
  }

  colDefs: ColDef[] = [
    { headerName: 'Name', field: 'name', resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Query', field: 'query', resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Layout', field: 'layout', resizable: true, filter: true, floatingFilter: true }    ,
    { field: 'serverId', hide: true, filter: true },
    { field: 'folderId', hide: true, filter: true },
    //{ field: 'description', resizable: true, filter: true, floatingFilter: true },
    //{ field: 'siteIds', hide: false, valueFormatter: this.siteIdsValueFormatter,  filter: 'agTextColumnFilter' },
    { field: 'siteIds', hide: true, filter: true },
    { field: 'groupIds', hide: true, filter: true },
    { field: 'allSites', hide: true, filter: true },
    { field: 'allGroups', hide: true, filter: true },   
  ];

  public defaultColDef: ColDef = {
    cellStyle: {'border-right': '1px solid #d4d4d4'},
    //flex: 1,
     width: 200,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,

  };
  public  onNoClick() {
    this.closebutton.nativeElement.click();
  } 
  
  ngOnInit() {    
    this.notify.emit(this.pageTitle);
    
    this.viewDetails = this.reportService.viewReport;
    this.rowData = this.reportService.viewReport.qlrReports;      

    // initialize grid hamburger tool for column selection.
    this.gridUserVisibleColumns = [];
    this.gridSelectedVisibleColumns = [];
    this.colDefs.forEach(element => {
      if (!element.hide) {
        this.gridUserVisibleColumns.push(element.headerName);
        this.gridSelectedVisibleColumns.push(element.headerName);
      }
    });
  }

  applyQlrServerFilter(serverId: number) {
    var serverIdFilterComponent = this.gridAPI.getFilterInstance('serverId')!;
    serverIdFilterComponent.setModel({
      type: 'equals',
      filter: serverId
    });
    this.gridAPI.onFilterChanged();
  }

  applyQlrFolderFilter(folderId: number) {
    var folderIdFilterComponent = this.gridAPI.getFilterInstance('folderId')!;
    folderIdFilterComponent.setModel({
      type: 'equals',
      filter: folderId
    });
    this.gridAPI.onFilterChanged();
  }

  applySitesFilter(siteId: number) {
    var siteIdsFilterComponent = this.gridAPI.getFilterInstance('siteIds')!;
    siteIdsFilterComponent.setModel({      
      type: 'contains',
      filter: siteId
    });
    this.gridAPI.onFilterChanged();
  }

  applyPermissionGroupsFilter(permissionGroupId: number) {
    var siteIdsFilterComponent = this.gridAPI.getFilterInstance('groupIds')!;
    siteIdsFilterComponent.setModel({      
      type: 'contains',
      filter: permissionGroupId
    });
    this.gridAPI.onFilterChanged();
  }

  onQlrFolderChange(event: any) {
    this.applyQlrFolderFilter(event.id);
  }

  onQlrServerChange(event: any) {
    this.applyQlrServerFilter(event.id);
  }

 onSitesChange(event: any) {       
    this.applySitesFilter(event.id);
  }

  onPermissionGroupChange(event: any) {    
    this.applyPermissionGroupsFilter(event.permissionGroupId);
  }

  onGridReady(params: GridReadyEvent<QlrReports>) {
    this.gridAPI = params.api;  
    this.selectedSiteId = this.viewDetails.refSites.find((site: Site) => site.id == this.viewDetails.selectedSite);
    
    if (this.selectedSiteId?.id) {
      this.applySitesFilter(this.selectedSiteId?.id);  
    }
  }

  onGridColumnSelectionChange(event: any) {
    // event will contain only the selected columns. 
    this.colDefs.forEach(element => {
      // columns that have Header names are the ones that need to be displayed so that's what we check for.      
      if (element.headerName && event.value.includes(element.headerName)) {
        element.hide = false;
      } else {
        element.hide = true;
      }
    });
    this.gridAPI.setColumnDefs(this.colDefs);
  }

  ok:boolean  =false;
  sum : number = 0;
  
  closeDialog(){
    
    this.unselectSelectedRow();
    this.isNew = false;
    this.ok = false;    
    this.sum = 0;
  }

  // looks for matching qlrFolder in context and returns it.
  getQlrFolderFromId(id: null | number) {
    if (id) {
      for (let i = 0; i < this.viewDetails.qlrFolders.length; i++) {    
        let item = this.viewDetails.qlrFolders[i];
        if (item.id === id) {
          return item;
        }
      }
    }
    return null;
  }

  // looks for matching qlrQuery in context and returns it.
  getQlrQueryFromName(name: null | string) {
    if (name) {
      for (let i = 0; i < this.viewDetails.qlrQueries.length; i++) {    
        let item = this.viewDetails.qlrQueries[i];
        if (item.name === name) {
          return item;
        }
      }
    }
    return null;
  }

  // looks for matching qlrLayout in context and returns it.
  getQlrLayoutFromName(name: null | string) {
    if (name) {
      for (let i = 0; i < this.viewDetails.qlrLayouts.length; i++) {    
        let item = this.viewDetails.qlrLayouts[i];
        if (item.name === name) {
          return item;
        }
      }
    }
    return null;
  }

  onRowSelected(event: any) {   
    if (event.node.isSelected()) {
      this.isNew = false;
      this.isRowSelected = true;
      this.selectedRowNode = event.node; // this is a pass by reference to the original object.
      if (this.selectedRowNode?.data) {
        // create a copy of the object so we don't affect the original object while user edits the fields. 
        // we only overwrite the original object when Save is clicked.
        this.templateQlrReport = JSON.parse(JSON.stringify(this.selectedRowNode.data));

        // initialize form autocomplete models.        
        this.formSelectedFolder = this.getQlrFolderFromId(this.templateQlrReport.folderId);     
        this.formSelectedQuery = this.getQlrQueryFromName(this.templateQlrReport.query);    
        this.formSelectedLayout =  this.getQlrLayoutFromName(this.templateQlrReport.layout);    
      }      
    } 
  }
  onNameInputChanged(event: any) {    
    let text = event.target.value;
    this.templateQlrReport.name = text;
    this.validateNewReportForm();
  } 

  onDescriptionInputChanged(event: any) {
    let text = event.target.value;
    this.templateQlrReport.description = text;
  }

  onQueryInputChanged(event: any) {    
    this.templateQlrReport.query = event.name;
    this.validateNewReportForm();
  }

  onLayoutInputChanged(event: any) {
    this.templateQlrReport.layout = event.name;
  }

  onAllSitesChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.allSites = checked;
  }

  onAllGroupsChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.allGroups = checked;
  }

  onEnabledChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.enabled = checked;
  }

  onEditFolderChange(event: any) {    
    this.templateQlrReport.folderId = event.id;
  }

  onEditReportsClick() {
    this.isEdit = true;    
  }

  onStopEditReportsClick() {
    this.isEdit = false;    
    this.isNew = false;
  }

  onUpdateQlrReportClick() {    
    // call API to save templateQlrReport 
    this.reportService.saveQlrReport(this.templateQlrReport).subscribe(
      (result: any) => {
        // update selectedRowNode with templateQlrReport        
        this.selectedRowNode?.setData(this.templateQlrReport);

        // update reference data ??
        let obj = this.viewDetails.qlrReports.find((o, i) => {
          if (o.id === this.templateQlrReport.id) {
            this.viewDetails.qlrReports[i] = this.templateQlrReport;
            return true; // stop searching
          }
          return false;          
        });        
      }
    );
  }

  onNewSaveClick() {
    // call API to save templateQlrReport 
    this.reportService.createQlrReport(this.templateQlrReport).subscribe(
      (result: any) => {
        // update grid with new QLR Report 
        // add to grid since it's a new record.
        this.gridAPI.applyTransaction({ add: result.qlrReports });
        // close edit section.
        this.isNew = false;

        // update reference data
        this.viewDetails.qlrReports.push(result);
      }
    );
  }

  onProcessClick() {
    // get selected report Id.
    let reportId = this.selectedRowNode?.data?.id;

    // open report view window
    window.open('/reportview?qlrReportPreview=' + reportId, '_blank');    
  }


  validateNewReportForm() {    
    // only allow saving if report name and query are filled.
    if (this.templateQlrReport.name && this.templateQlrReport.query) {
      this.canSaveNewReport = true;
    } else {
      this.canSaveNewReport = false;
    }
    this.validateProcessButton();
  }

  validateProcessButton() {
    // only allow process of report if it has an ID.
    if (this.templateQlrReport.id) {
      this.canProcessReport = true;
    } else {
      this.canProcessReport = false;
    }
  }

  doesExternalFilterPass(node: IRowNode<QlrReports>): boolean {
    var folderIdFilterComponent = this.gridAPI.getFilterInstance('folderId')!;
    var siteIdFilterComponent = this.gridAPI.getFilterInstance('siteId')!;
    // return true;
    // if (node.data) {
    //   switch (ageType) {
    //     case 'below25':
    //       return node.data.age < 25;
    //     case 'between25and50':
    //       return node.data.age >= 25 && node.data.age <= 50;
    //     case 'above50':
    //       return node.data.age > 50;
    //     case 'dateAfter2008':
    //       return asDate(node.data.date) > new Date(2008, 1, 1);
    //     default:
    //       return true;
    //   }
    // }
    return true;
  }

  openDeleteDialog() {
    const dialogRef = this.dialog.open(DeleteFolderComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result == true && this.selectedRowNode?.data?.id != null) {
        // call delete folder API
        this.reportService.deleteQlrReport(this.selectedRowNode.data.id).subscribe(
          (result: any) => {
            if (this.selectedRowNode?.data?.id) {              
              // remove folder from grid
              this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.data] });
              //this.removeSelected();
              this.selectedRowNode = null;
              this.closeDialog();
            }        
          }
        );        
      }
    });
  }

  unselectSelectedRow() {
    //unselect the selected row.
    if (this.selectedRowNode) {
      this.selectedRowNode.setSelected(false);
    }
    this.selectedRowNode = null;
    this.isRowSelected = false;
  }

  onNewButtonClick() {
    this.unselectSelectedRow();

    // clear templateQlrReport
    this.templateQlrReport = {} as QlrReports;
    if (this.selectedServerId?.id) {
      this.templateQlrReport.serverId = this.selectedServerId.id;
    }

    // clear other variables.         
    this.formSelectedFolder = null;  
    this.formSelectedQuery = null;   
    this.formSelectedLayout =  null; 

    this.isNew = true;

    this.validateNewReportForm();
  } 
  
  filterServer(event: any) {
    let filtered: any[] = [];
    let query = event.query
    for (let i = 0; i < this.viewDetails.qlrServers.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrServers[i]);
      let country = this.viewDetails.qlrServers[i];
      if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredServer = filtered;
  }

  filterFolder(event: any) {
    let filtered: any[] = [];
    let query = event.query
    for (let i = 0; i < this.viewDetails.qlrFolders.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.qlrFolders[i];
      if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredFolder = filtered;
  }

filteredQuery : any[]; 
filterQuery(event: any) {
  let filtered: any[] = [];
  let query = event.query
  for (let i = 0; i < this.viewDetails.qlrQueries.length; i++) {
    // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
    let country = this.viewDetails.qlrQueries[i];
    if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      filtered.push(country);
    }
  }
  this.filteredQuery = filtered;
}
filteredLayout: any[];
filterLayout(event: any) {
  let filtered: any[] = [];
  let query = event.query
  for (let i = 0; i < this.viewDetails.qlrLayouts.length; i++) {
    // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
    let country = this.viewDetails.qlrLayouts[i];
    if (country && country.name && country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      filtered.push(country);
    }
  }
  this.filteredLayout = filtered;
}

  filterSite(event: any) {
    let filtered: any[] = [];
    let query = event.query
    for (let i = 0; i < this.viewDetails.refSites.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.refSites[i];
      if (country.description.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredSite = filtered;
  }

  filterPermissiongroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.viewDetails.permissionGroups.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.permissionGroups[i];
      if (country.permissionGroupDesc.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredPermissiongroup = filtered;
  }
}
