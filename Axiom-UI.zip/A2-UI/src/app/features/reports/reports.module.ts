import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsComponent } from './reports.component';
import { MessageComponent } from './message/message.component';
import { QlrMenuComponent } from './qlr-menu/qlr-menu.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ReportsRoutingModule } from './reports-routing.module';
import { EditFoldersComponent } from './edit-folders/edit-folders.component';
import { DeleteFolderComponent } from './delete-folder/delete-folder.component';
import { MultiSelectModule } from 'primeng/multiselect';

@NgModule({
  declarations: [
    ReportsComponent,
    MessageComponent,
    QlrMenuComponent,
    LandingPageComponent,
    EditFoldersComponent,
    DeleteFolderComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ReportsRoutingModule,
    MultiSelectModule
  ],
  exports: [
    ReportsComponent
  ]
})
export class ReportsModule { }
