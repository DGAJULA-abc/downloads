export interface InvoicePreviewRequest {
  invoices: InvoicePreview[];
  showZero: null | boolean;
  defaultCustFormat: boolean;
  invFormat: null | number;
  cnFormat: null | number;
}

export interface InvoicePreview {
  id: number;
  siteid: number;
  documenttype: string;
  exported: boolean;
  invformat: string;
  cnformat: string;
  defaultinvformat: string;
  defaultcnformat: string;
}

export interface PayAdvicePreview {
  id: number,
  siteId: number,
  paFormat: null | string,
  defaultPaFormat: number  
}

export interface PayAdvicePreviewRequest {
  payAdvice: PayAdvicePreview[],
  payrollCodeRequired: boolean,
  defaultCustFormat: boolean,
  paFormat: null | number
}