import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ReportViewService } from './services/report-view.service';
import { models } from 'powerbi-client';

@Component({
  selector: 'app-report-view',
  templateUrl: './report-view.component.html',
  styleUrls: ['./report-view.component.scss']
})
export class ReportViewComponent { 

  // properties
  requestParams:any = {};   

  constructor(private route: ActivatedRoute, private reportViewService: ReportViewService){
    this.route.queryParamMap.subscribe((p: any ) => {
      this.requestParams = p['params'];
    })    
  }
   

  ngOnInit(): void {

    // get EmbedConfig for requested report
    if (this.requestParams.invoicePreview) {
      // prepare to call invoice report
      let invoicePreview = JSON.parse(window.atob(this.requestParams.invoicePreview));      
      
      // get embed config.
      this.reportViewService.printInvoices(invoicePreview).subscribe(
        (result: any) => {
          // display report 
          this.renderReport(result);
        }
      );
    } else if (this.requestParams.payAdvicePreview) {
      // prepare to call pay advice report
      let payAdvicePreview = JSON.parse(window.atob(this.requestParams.payAdvicePreview));
      
      // get embed config.
      this.reportViewService.printPayAdvices(payAdvicePreview).subscribe(
        (result: any) => {
          // display report 
          this.renderReport(result);
        }
      );
    } else if (this.requestParams.tripSheetPreview) {
      // prepare to call trip sheet report
      let tripIds = [];
      tripIds.push(this.requestParams.tripSheetPreview);
            
      // get embed config.
      this.reportViewService.generateTripSheet(tripIds).subscribe(
        (result: any) => {
          // display report 
          this.renderReport(result);
        }
      );
    } else if (this.requestParams.qlrReportPreview) {
      // get embed config.
      this.reportViewService.callQlrReport(this.requestParams.qlrReportPreview).subscribe(
        (result: any) => {
          // display report 
          this.renderReport(result);
        }
      );      
    }
    // else if (this.requestParams.unibisReportPreview) {
    // 
    //}

    
  }

  renderReport(embedConfig: any) {
    
    let reportConfigTemp: any = {
      id: embedConfig.embedReports[0].reportId,
      type: 'report',    
      tokenType: models.TokenType.Embed,
      accessToken: embedConfig.embedToken.token,
      embedUrl: embedConfig.embedReports[0].embedUrl,      
      parameterValues: embedConfig.parameterValues
    };
    
    let reportContainer = document.getElementById("report-container");
    if (reportContainer) {
      window.powerbi.embed(reportContainer, reportConfigTemp);
    }
  }                       

    
  
}
