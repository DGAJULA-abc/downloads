import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteInvoiceLinesComponent } from './delete-invoice-lines.component';

describe('DeleteInvoiceLinesComponent', () => {
  let component: DeleteInvoiceLinesComponent;
  let fixture: ComponentFixture<DeleteInvoiceLinesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteInvoiceLinesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeleteInvoiceLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
