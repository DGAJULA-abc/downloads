import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Optional } from 'ag-grid-community';

@Component({
  selector: 'app-delete-invoice-lines',
  templateUrl: './delete-invoice-lines.component.html',
  styleUrls: ['./delete-invoice-lines.component.scss']
})
export class DeleteInvoiceLinesComponent {
  constructor(
    public dialogRef: MatDialogRef<DeleteInvoiceLinesComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
}
