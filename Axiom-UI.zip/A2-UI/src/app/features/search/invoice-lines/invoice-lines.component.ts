import { Component } from '@angular/core';
import { SearchService } from '../services/search.service';

import { ColDef, GridApi } from 'ag-grid-community';

import { SearchInvoiceService } from '../services/search-invoice.service';
import { InvoiceLines, InvoiceLinesGetData } from '../model/searchInvoice.model';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import * as moment from 'moment';
import { DeleteFolderComponent } from '../../reports/delete-folder/delete-folder.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';
@Component({
  selector: 'app-invoice-lines',
  templateUrl: './invoice-lines.component.html',
  styleUrls: ['./invoice-lines.component.scss']
})
export class InvoiceLinesComponent {
  InvoiceLinesGetData: any;
  constructor( public dialog: MatDialog,private service: SearchInvoiceService){}
  public rowData: InvoiceLines[] = [];
  companies: any[] = [];
  serviceTypes: any[] = [];
  loadTypes: any[] = [];
  adjustmentTypes: any[] = [];
  customers: any[] = [];
  customerGroups: any[] = [];
  companyTypes: any[] = [];
  invoiceLines:InvoiceLinesGetData;
  InvoiceLines:InvoiceLinesGetData[];
  filteredLoadTypes: any[];
  filteredCompanyID: any[];
  filteredServiceType: any[];
  filteredAdjustmentType: any[];
  filteredCustomerID: any[];
  filteredCustomerGroup: any[];
  filteredCompanyType: any[];
  filteDriverData :any[] = [];
  drivers: any[] = [];
  gridApi: GridApi<InvoiceLinesGetData>
  ngOnInit() {
    this.service.getDropDownData().subscribe((data: any) => {
      this.companies = data.ref.companys.map((obj: { companyId: any; }) => obj.companyId);
      this.drivers = data.ref.drivers
      this.filteDriverData = this.drivers.map(item => {
        let nameParts = [];
        if (item.surname && item.firstName) {
          nameParts.push(item.surname, item.firstName);
          if (item.employeeName) {
            nameParts.push(`- ${item.employeeName}`);
          }
        } else {
          if (item.surname) {
            nameParts.push(item.surname);
          }
          if (item.firstName) {
            nameParts.push(item.firstName);
          }
          if (item.employeeName) {
            nameParts.push(item.employeeName);
          }
        }
        if (item.companyId) {
          nameParts.push(`(${item.companyId})`);
        }      
        const filteredName = nameParts
          .filter(value => value !== null && value !== undefined && value !== '')
          .join(' ');
      
        return {
          id: item.id,
          name: filteredName
        };
      });           
      console.log(this.drivers);
      console.log(this.filteDriverData)
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.companies = data.ref.companys.map((obj: { companyId: any; }) => obj.companyId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.serviceTypes = data.ref.serviceTypes.map((obj: { serviceTypeId: any; }) => obj.serviceTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.loadTypes = data.ref.loadTypes.map((obj: { loadTypeId: any; }) => obj.loadTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.adjustmentTypes = data.ref.adjustmentTypes.map((obj: { adjustmentTypeId: any; }) => obj.adjustmentTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customers = data.ref.customers.map((obj: { customerId: any; }) => obj.customerId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customerGroups = data.ref.customerGroups.map((obj: { groupId: any; }) => obj.groupId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.companyTypes = data.ref.companyTypes.map((obj: { companyTypeId: any; }) => obj.companyTypeId);
    });
  }
  formData: any = {
    description: null,
    company: null,
    driver: null,
    loadNo: null,
    serviceNo: null,
    serviceType: null,
    loadType: null,
    unAllocatedOnly: null,
    adjustmentLineType:null,
    adjustmentType:null,
    effectiveFrom:null,
    effectiveTo:null,
    customer: null,
    customerGroup: null,
    companyType: null,
    amoutFrom: null,
    amoutTo: null
  }; 
// table
colDefs: ColDef[] = [
  {
   cellRenderer: CellrenderComponent,filter: 'agNumberColumnFilter',resizable: true,headerName: '✔'
  },
  { field:'id',headerName: 'Id',resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter'},
  { field: 'serviceid', headerName: 'Service ID', resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'serviceno', headerName: 'Service No',resizable: true, floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'effectivedate', headerName: 'Effective Date',cellRenderer: (data: { value: moment.MomentInput; }) => {
    return moment(data.value).format('MM/DD/YYYY')
},resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'parentid',  headerName: 'Print id',resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'adjustmenttypeid',headerName: ' Adjustment Type Id',  resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'linetext',headerName: 'Line Text', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'lineamt', headerName: 'Line amt',  resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter'},
  { field: 'customerid',headerName: 'Customer Id', resizable: true,floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'enteredby',headerName: 'Entered By', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'payrollcode',headerName: 'Payroll', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'driver',headerName: 'Driver', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'linetype',headerName: 'Line Type', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' }
];

isunAllocatedOnly: boolean = true
public defaultColDef: ColDef = {
  cellStyle: {'border-right': '1px solid #d4d4d4'},
  headerClass: function(params) {
    // logic to return the correct class
    return 'header-one';
  },
  flex: 1,
   minWidth: 100,
  filter: 'agTextColumnFilter',
  floatingFilter: true,
  sortable: true,
  resizable: true,
  // editable: true,

};

  submitFormInvoiceLines(){
    this.formData.unAllocatedOnly = this.isChecked?'true' :null
    if(this.selectedlineTypes == 'Any'){
      this.formData.adjustmentLineType  = 'ALL';
    }else if(this.selectedlineTypes == 'Invoice Adjustment') {
      this.formData.adjustmentLineType  = 'ADJUST';
    }else if(this.selectedlineTypes == 'Periodic Charges') {
      this.formData.adjustmentLineType  = 'PERIODIC';
    }else if(this.selectedlineTypes == 'Service Charges') {
      this.formData.adjustmentLineType  = 'LINE';
    }
    console.log('hello');
    this.service.postInvoiceLineData(this.formData).
    subscribe((response : any) => {
      console.log('left form');
      console.log(response);
      this.rowData = response.adjustments;
        console.log('hiii',this.rowData);
    }
  );
    
  }
  isDivVisible:boolean = false;
  isChecked: boolean = true;
  isComponentVisible = true;
  
  GetInvoiceLinedata(id: any){

    this.isDivVisible =true;
    this.service.getInvoiceLineById(id).subscribe(
      response => {
        console.log('Resource:', response);
        this.invoiceLines = response;
        console.log(this.invoiceLines);
      }
    );
  }

  close() {
    this.isComponentVisible = false;
  }  

  filterLoadType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.loadTypes.length; i++) {
      let country = this.loadTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredLoadTypes = filtered;
  }  

  filterCompanyID(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.companies.length; i++) {
      let country = this.companies[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredCompanyID = filtered;
  }  
  selectedDriver:any;
  filteredDrivers: any[];
  filteredDriver(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.filteDriverData.length; i++) {
      let driver = this.filteDriverData[i];
      if (driver.name.toLowerCase().indexOf(query.toLowerCase()) === 0) {
        filtered.push(driver);
      }
    } 
    this.filteredDrivers = filtered;
  }
    // Function to handle the selection
handleCompanyTypeSelect(event:any) {
  // Find the selected option by value
  const selectedOption = this.filteDriverData.find(option => option.name === event.name);
  // If an option is found, update the formData with its id
  if (selectedOption) {
    this.formData.driver = selectedOption.id;
  }
}
  filterServiceType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.serviceTypes.length; i++) {
      let country = this.serviceTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredServiceType = filtered;
  }   

  filterAdjustmentType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.adjustmentTypes.length; i++) {
      let country = this.adjustmentTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredAdjustmentType = filtered;
  }  

  filterCustomerID(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredCustomerID = filtered;
  }  

  filterCustomerGroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.customerGroups.length; i++) {
      let country = this.customerGroups[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredCustomerGroup = filtered;
  }   

  lineType: any[] = ['Any', 'Invoice Adjustment', 'Periodic Charges', 'Service Charges'];
  selectedlineTypes:any;
  filteredlineTypes: any[];
  filteredlineType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.lineType.length; i++) {
      let country = this.lineType[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    } 
    this.filteredlineTypes = filtered;
  }

  filterCompanyType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.companyTypes.length; i++) {
      let country = this.companyTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredCompanyType = filtered;
  }  

  downloadCsv(){
    this.service.InvoiceLineCsvDownload(this.formData).subscribe(
      (res: any) => {
       // Assuming 'response' is the array buffer received from your HTTP request
        var arrayBuffer = res;
        var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'report.csv'; // Set the desired file name
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
      }
    );
  }

  isAbleToDeleteInvoiceLines() {
    return this.canWrite() &&
      this.rowData &&
      (this.rowData.length > 0) &&
      this.rowData.every(item => this.service.canDelete(item));
  }
  selectedRowNode: null | InvoiceLines;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
      this.service.deleteInvoiceLines(this.invoiceLines.id).subscribe(
        (result: any) =>{
          this.service.postInvoiceLineData(this.formData).
                           subscribe((response : any) => {
                           console.log('left form');
                          console.log(response);
                          this.rowData = response.adjustments;
                          console.log('hiii',this.rowData);
                          }
                          );
        }
      );
    }
  })
}  

 canWrite(){
 return true;
 }

 ok:boolean  =false;
 sum : number = 0;
 selectedRow: any = null;
 closeDialog(){
   this.ok = false;
   this.isDivVisible =false;
   this.sum = 0

// Uncheck the previously selected row
   if (this.selectedRow) {
     this.selectedRow.isChecked = false;
   }
}
 
}
