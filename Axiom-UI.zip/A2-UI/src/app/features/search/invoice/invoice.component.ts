import { Component, Input } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Router } from '@angular/router';
import { ColDef, GridApi, GridReadyEvent, IGroupCellRendererParams } from 'ag-grid-community';

import { SearchInvoiceService } from '../services/search-invoice.service';
import { Invoice, Line } from '../model/searchInvoice.model';
import { InvoicePreviewRequest, InvoicePreview } from '../../reportview/model/report-view.model';
import { DateFormateComponent } from '../services/date-formate/date-formate.component';
import { CellRendarComponent } from '../services/cell-rendar/cell-rendar.component';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { DatePipe } from '@angular/common';
import { MomentInput } from 'moment';
import * as moment from 'moment';


@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent {
  public rowData: Invoice[] = [];
  lines: Line[] = [];
  invoice:Invoice;
  private gridApi!: GridApi;
  @Input() printMenu: any;
  @Input() pageName: any;
  customers: any[] = [];
  invoiceDetails: any = {};
  invoiceReportFormats: any[];
  customerGroups: any[] = [];
  filteredCustomerID: any[];
  filteredCustomerGroup: any[];
  documentType: any[] = [
    "Credit Note",
    "Invoice"
  ];
  status: any[] = ['HOLD', 'PRINTED', 'READY'];
  filteredDocumentType: any[];
  filteredStatus: any[];
  showZero: boolean= false;
  public invoiceMenu = [{ 'name': 'Standard Invoice' }, { 'name': 'Detailed Wide Format (Service Drop)' }, { 'name': 'Load Level Summary' }, { 'name': 'Date Level Summary' }, { 'name': 'Cover Page' }, { 'name': 'Service Type/Location Summary' }, { 'name': 'Detailed Wide Format' }, { 'name': 'Wide Format With Load#(5 Units)' }, { 'name': 'Service Type/Location Summary/Rate' }, { 'name': 'Detailed Wide Format/Rate' }, { 'name': 'Trip-Based' }, { 'name': 'Special' },
  { 'name': 'Detailed Wide Format(Loc Number)' }, { 'name': 'Cover Page With Breakdown' }, { 'name': 'Customer Report' }]

  ngOnInit(): void {
    // this.service.getDropDownData().subscribe((data: any) => {
    //   console.log('onInit',data.ref.customers);
    //   this.customers = data.ref.customers.map((obj: { customerId: any; }) => obj.customerId);
    //   console.log(this.customers)
    // });
    // this.service.getDropDownData().subscribe((data: any) => {
    //   console.log('onInit',data.ref.customerGroups);
    //   this.customerGroups = data.ref.customerGroups.map((obj: { groupId: any; }) => obj.groupId);
    //   console.log(this.customerGroups)
    // });
  }
  constructor(private service: SearchInvoiceService, private datePipe: DatePipe){}
  formData: any = {
    likeInvoiceId: null,
    status: null,
    customerID: null,
    customerGroup: null,
    issuedDate: null,
    invoiceDate:null,
    dueDate:null,
    documentType:null
  }; 
  ok:boolean  =false;
  sum : number = 0;
  selectedRow: any = null;
  closeDialog(){
    this.ok = false;
    this.isDivVisible =false;
    this.sum = 0

// Uncheck the previously selected row
    if (this.selectedRow) {
      this.selectedRow.isChecked = false;
    }
}

InvoiceDate: Date;
IssuedDate: Date;
DueDate: Date;

  submitForm() {
    // if(this.InvoiceDate != null){
    //   this.formData.invoiceDate = this.InvoiceDate.getTime();
    //   console.log("Heoo---------")
    // }
    // if(this.IssuedDate != null){
    //   this.formData.issuedDate = this.IssuedDate.getTime()
    // }
    // if(this.DueDate != null){
    //   this.formData.dueDate = this.DueDate.getTime()
    // }

    //this.formData.issuedDate =  moment(this.formData.issuedDate, "YYYY-MM-DD HH:mm:ss").format("x")
    this.service.postInvoiceData(this.formData).

    subscribe(
      (response : any) => {
        // Handle the response here if needed
        console.log('Response:', response);
        this.rowData = response.invoices;
        console.log('hiii',this.rowData);

      }

    );

  }
  displayedColumns: string[] = ['demo-position', 'demo-name','demo-weight','demo-symbol','demo-amount','demo-period'];
  dataSource: any;
  public popupParent: HTMLElement | null = document.body;
  checkboxClicked: boolean = false;
  colDefs: ColDef[] = [
    // { field: '&#10003;', resizable: true, filter: true, floatingFilter: true },
    {
      cellRenderer: CellrenderComponent,headerName: '✔', cellRendererParams: {
        selectedRow: null, // Initially, no row is selected
      },
    },
    { field:'id',headerName: 'Invoice No',resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter'},
    { field: 'customerid', headerName: 'Customer ID', resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
    { field: 'customergroupid', headerName: 'Customer Group',resizable: true, floatingFilter: true ,filter: 'agNumberColumnFilter'},
    { field: 'duedate', headerName: 'Due Date',cellRenderer: (data: { value: MomentInput; }) => {
      return moment(data.value).format('DD/MM/YYYY')
  }, resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'fromdate', headerName: 'From Date',  cellRenderer: (data: { value: MomentInput; }) => {
      return moment(data.value).format('DD/MM/YYYY')
  },resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
    { field: 'todate',  headerName: 'To Date',cellRenderer: (data: { value: MomentInput; }) => {
      return moment(data.value).format('DD/MM/YYYY')
  },resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'issuedate',headerName: 'Issue Date', cellRenderer: (data: { value: MomentInput; }) => {
      return moment(data.value).format('DD/MM/YYYY')
  }, resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
    { field: 'invoicestatusid',headerName: 'Invoice status', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'documenttype', headerName: 'Type',  resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter'},
    { field: 'exported',headerName: 'Exported', resizable: true,floatingFilter: true ,filter: 'agNumberColumnFilter'},
    { field: 'exgst',headerName: 'Base Charge Ex GST', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'fuellevy',headerName: 'Fuel Levy', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'discountamt',headerName: 'Discount', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'totalexgst', headerName: 'Total Ex GST',resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },
    { field: 'created',cellRenderer: (data: { value: MomentInput; }) => {
      return moment(data.value).format('DD/MM/YYYY')
  }, headerName: 'Created On',resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },

  ];

  public defaultColDef: ColDef = {
    cellStyle: {'border-right': '1px solid #d4d4d4'},
    flex: 1,
     minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,

  };
    /**

   * For toggle button

   */

    isDivVisible:boolean = false;
    
    rightSideForm(id :any){
    this.isDivVisible =true;
      console.log(id);
      this.service.getInvoiceList(id).subscribe(
        (response) =>{
           console.log('Left side :',response);
          this.invoice = response.invoice;
          // console.log('right',this.invoice);
           this.lines = response.lines;
          console.log('right',this.lines);
          this.dataSource = this.lines;
        }
      )
    }
    
  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('filter-text-box') as HTMLInputElement).value
    );
  }
  // isChecked: boolean = true;
  isChecked = false;
  showRunsheetDetail: boolean = false;
  public autoGroupColumnDef: ColDef = {
    headerName: 'Group',
    minWidth: 250,
    field: 'runsheetid',
    valueGetter: (params) => {
      if (params.node!.group) {
        return params.node!.key;
      } else {
        return params.data[params.colDef.field!];
      }
    },
    headerCheckboxSelection: true,
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true,
    } as IGroupCellRendererParams,
  };
  
  public rowSelection: 'single' | 'multiple' = 'multiple';
  public rowGroupPanelShow: 'always' | 'onlyWhenGrouping' | 'never' = 'always';
  public pivotPanelShow: 'always' | 'onlyWhenPivoting' | 'never' = 'always';
  
  showInvoiceDetail: boolean = false;
  
  downloadCsv(){
    this.service.InvoiceCsvDownload(this.formData).subscribe(
      (res: any) => {
       // Assuming 'response' is the array buffer received from your HTTP request
        var arrayBuffer = res;
        var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'report.csv'; // Set the desired file name
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
      }
    );

}
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
  }
 
  selectedCustomers:any;
  // onPrintWithCustomerFormatClick() {
    
  //   // TODO: this is just mock parameters. replace with data from selected rows in grid.
  //   let invoicesParam: InvoicePreview[] = [
  //     {
  //     id: 215587,
  //     siteid: 296,
  //     documenttype: 'Invoice',
  //     exported: true,
  //     invformat: '16',
  //     cnformat: '1',
  //     defaultinvformat: '3',
  //     defaultcnformat: '1'
  //   }
  // ];

  //   // create request params
  //   let invoicePreviewParam: InvoicePreviewRequest = {
  //     defaultCustFormat: true,
  //     cnFormat: null,
  //     invFormat: null,
  //     showZero: null,
  //     invoices: invoicesParam
  //   };

  //   // encode params
  //   let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

  //   // open report view window
  //   window.open('/reportview?invoicePreview=' + requestParam, '_blank');
    
  // }

  // onPrintInvoiceFormatClick() {
    
    // TODO: this is just mock parameters. replace with data from selected rows in grid that are documenttype='Invoice' only
  //   let invoicesParam: InvoicePreview[] = [{
  //     id: 215587,
  //     siteid: 296,
  //     documenttype: 'Invoice',
  //     exported: true,
  //     invformat: '16',
  //     cnformat: '1',
  //     defaultinvformat: '3',
  //     defaultcnformat: '1'
  //   }];

  //   // create request params
  //   let invoicePreviewParam: InvoicePreviewRequest = {
  //     defaultCustFormat: false,
  //     cnFormat: null,
  //     invFormat: 16, // TODO: change this to what was chosen in the invoice format list.
  //     showZero: null,
  //     invoices: invoicesParam
  //   };

  //   // encode params
  //   let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

  //   // open report view window
  //   window.open('/reportview?invoicePreview=' + requestParam, '_blank');
    
  //}


  filterCustomerID(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredCustomerID = filtered;
  }    

  filterCustomerGroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.customerGroups.length; i++) {
      let country = this.customerGroups[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }

    this.filteredCustomerGroup = filtered;
  }   

  
filterDocumentType(event: any) {
  let filtered: any[] = [];
  let query = event.query;

  for (let i = 0; i < this.documentType.length; i++) {
    let country = this.documentType[i];
    if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      filtered.push(country);
    }
  }

  this.filteredDocumentType = filtered;
}   

selectedStatus:any;
filterStatus(event: any) {
  let filtered: any[] = [];
  let query = event.query;

  for (let i = 0; i < this.status.length; i++) {
    let country = this.status[i];
    if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      filtered.push(country);
    }
  }

  this.filteredStatus = filtered;
}

filteredCustomers: any[];
filteredCustomer(event: any) {
  let filtered: any[] = [];
  let query = event.query;

  for (let i = 0; i < this.customers.length; i++) {
    let country = this.customers[i];
    if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
      filtered.push(country);
    }
  }

  this.filteredCustomers = filtered;
}
onPrintWithCustomerFormatClick(printMenu: any) {
  // TODO: this is just mock parameters. replace with data from selected rows in grid.
  console.log(this.invoiceDetails);
  let invoicesParam: InvoicePreview[] = [{
    id: this.invoiceDetails.id,
    siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
    documenttype: printMenu == 'CustomerFormat' ? 'Invoice' : 'Credit Note',
    exported: this.invoiceDetails.exported,
    invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
    cnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
    defaultinvformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : null,
    defaultcnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : null
  }];

  // create request params
  let invoicePreviewParam: InvoicePreviewRequest = {
    defaultCustFormat: printMenu == 'CustomerFormat' ? true : false,
    cnFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
    invFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
    showZero: this.showZero,
    invoices: invoicesParam
  };


}
onPrintInvoiceFormatClick() {
  console.log(this.invoiceDetails)
  // TODO: this is just mock parameters. replace with data from selected rows in grid that are documenttype='Invoice' only
  let invoicesParam: InvoicePreview[] = [{
    id: this.invoiceDetails.id,
    siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
    documenttype: 'Invoice',
    exported: this.invoiceDetails.exported,
    invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
    cnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
    defaultinvformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : null,
    defaultcnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : null
  }];


  // create request params
  let invoicePreviewParam: InvoicePreviewRequest = {
    defaultCustFormat: false,
    cnFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
    invFormat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
    showZero: this.showZero,      invoices: invoicesParam
  };

  // encode params
  let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

  // open report view window
  window.open('/reportview?invoicePreview=' + requestParam, '_blank');

}
}
