import { ActionGroupList, CloseOffSites, pagination } from "src/app/shared/model/shared.model";

export interface ViewSearch {
    actionGroupList: ActionGroupList,
    closeOffSites: CloseOffSites[],
    payAdviceLineTypes: {
        name: string, 
        value: string
    }
    
}

export interface ServiceList {
  operation: string
  pagination: pagination
  services: Services[]
}

export interface Services {
  docket: String
  serviceid: number
  serviceno: string
  servicetypeid: string
  servicedate: number
  customerid: string
  customergroupid: string
  truckid: string
  trailerid: string
  containerid: string
  containertypeid: string
  locationid_pickup: string
  locationid_drop: string
  enteredby: string
  loadid: number
  qtydesc: string
  locations: string
  holdcode: string
  complete: boolean
  originsite: number
  destinationsite: number
  originloc: string
  destinationloc: string
  invoiceid: number
  companyid: number
  employeename: string
  firstname: string
  lastname: string
  runsheetid: number
  customerid_load: string
  loadno: string
  loadtypeid: string
  scheduleddate: number
  holdcode_load: string
  complete_load: boolean
  batchno: string
  locationid: string
  custreference: string
  customergroupid_load: string
  qty1: number
  unit1: string
  qty2: number
  unit2: string
  qty3: number
  unit3: string
  qty4: number
  unit4: string
  qty5: number
  unit5: string
  qty6: number
  unit6: string
  qty7: number
  unit7: string
  qty8: number
  unit8: string
  qtya: string
  qtyb: string
  qtyc: string
  qtyd: string
  qtye: string
  qtyf: string
  qtyg: string
  qtyh: string
  sloadtype: string
  trailerid_tag: string
  chargeamt: number
  rateid: string
  driverrate: string
  driverpay: number
  tripid_cust: string
  datasourceid: string
  pickuparrivetemp: string
  pickupdoctemp: string
  pickupreadytemp: string
  pickupdeparttemp: string
  droparrivetemp: string
  dropdoctemp: string
  dropreadytemp: string
  dropdeparttemp: string
  tripid: number
  siteid: number
  tripdate: number
  driverid: number
  driver: string
  used: boolean
  servicedesc: string
}

export interface RunsheetList {
  operation: string
  pagination: pagination
  runsheets: Runsheet[]
}

export interface Runsheet {
  runsheetid: number,
  siteid: number,
  deliverydate: Date,
  publicholidayapplies: boolean,
  driverid: number,
  driver: string,
  truckid: string,
  startdatetime: Date,
  enddatetime: Date,
  returndepottime: Date,
  startkm: number,
  endkm: number,
  cashshortage: number,
  stockshortage: number,
  calcpaybyload: boolean,
  calcpaybyhour: boolean,
  rateid: string,
  payamt: number,
  payhourly: number,
  payincentive: number,
  payallowance: number,
  hoursnormal: number,
  hoursthalf: number,
  hoursdouble: number,
  shiftrate: number,
  shifthours: number,
  shiftamt: number,
  holdcode: string,
  complete: boolean,
  remarks: string,
  runsheettypeid: string,
  createdby: string,
  paydesc: string,
  exported: boolean,
  odokm: number,
  gpskm: number,
  eventgenerated: boolean,
  globaldropbonus: number,
  created: Date,
  employeeid: number,
  companyid: string,
  employeeposition: string,
  employeename: string,
  active_driver: boolean,
  truckid_driver: string,
  trailerid: string,
  paybasisid: string,
  payrollcode: string,
  homelocationid: string,
  report_to: number,
  employeestatus: string,
  status_from: Date,
  status_to: Date,
  employeetype: string,
  mdtcode: string,
  mdtpin: string,
  mdtexception: number,
  groupdriver: boolean,
  trackableobjectid: number,
  usesleopard: boolean,
  title: string,
  firstname: string,
  middlename: string,
  lastname: string,
  position: string,
  salutation: string,
  address_person: string,
  address2_person: string,
  suburb_person: string,
  city_person: string,
  state_person: string,
  postcode_person: string,
  homephone: string,
  officephone: string,
  fax: string,
  email: string,
  mobile: string,
  version: number,
  lastmoduser: string,
  lastmodapp: string,
  companytypeid: string,
  personid: number,
  customerid: string,
  active_company: boolean,
  paformat: number,
  contagreesightby: string,
  contagreesightdate: Date,
  abn: string,
  vendorname: string,
  unibis_vendorname: string,
  rctiagreement: true,
  markedforactivate: false,
  markedfordelete: false,
  address1_company: string,
  address2_company: string,
  suburb_company: string,
  city_company: string,
  state_company: string,
  postcode_company: string,
  lastmodified: Date,
  cntbreaks: number,
  cntservices: number,
  sumcharge: number,
  totalhours: number,
  totalkms: number,
  hasbreaks: boolean
}

export interface RunsheetById {
  invoices: any
  isNew: boolean
  payAdvices: any
  runsheet: RunsheetDetails
}

export interface RunsheetDetails {
  id: number;
  runsheetTypeId: string;
  rateId: string;
  truckId: string;
  siteId: number;
  driverId: number;
  deliverydate: Date; // TODO COMBINE WITH TIME
  publicholidayapplies: boolean;
  starttime: Date;
  endtime: Date;
  returndepottime: Date;
  startkm: number;
  endkm: number;
  cashshortage: number;
  stockshortage: number;
  calcpaybyload: boolean;
  calcpaybyhour: boolean;
  payamt: number;
  payhourly: number;
  payincentive: number;
  payallowance: number;
  hoursnormal: number;
  hoursthalf: number;
  hoursdouble: number;
  shiftrate: number;
  shifthours: number;
  shiftamt: number;
  holdcode: string;
  complete: boolean;
  remarks: string;
  createdby: string;
  paydesc: string;
  exported: boolean;
  odokm: number;
  gpskm: number;
  enddate: Date;
  eventgenerated: boolean;
  globaldropbonus: number;
  created: Date;
  runsheetLines: RunsheetLines[];
  invoiceLines: Line[];
  payAdviceLines: any[];
  reasonLines: any[];
  driverBreaks: DriverBreak[];
  shiftId: number;
  shiftUUID: string;
}

export interface RunsheetLines {
  id: number;
  locationContDropId: string;
  locationContPickupId: string;
  locationDropId: string;
  locationPickupId: string;
  locationReturnId: string;
  serviceId: number;
  trailerId: string;
  containerId: string;
  loadTypeId: string;
  trailerTagId: string;
  serviceTypeId: string;
  rateId: string;
  truckId: string;
  siteId: number;
  qty1: number;
  unit1: string;
  qty2: number;
  unit2: string;
  qty3: number;
  unit3: string;
  qty4: number;
  unit4: string;
  qty5: number;
  unit5: string;
  qty6: number;
  unit6: string;
  qty7: number;
  unit7: string;
  qty8: number;
  unit8: string;
  owntrailer: boolean;
  offsiderused: boolean;
  pickuparrivetime: Date;
  pickupdeparttime: Date;
  droparrivetime: Date;
  dropreadytime: Date;
  dropdeparttime: Date;
  docket: string;
  payamt: number;
  payestimated: boolean;
  directfromdepot: boolean;
  remarks: string;
  nextstoptime: Date;
  tripkm: number;
  paydesc: string;
  pickupreadytime: Date;
  dropdoctime: Date;
  pickupdoctime: Date;
  createdby: string;
  tripno: number;
  tripseq: number;
  servicehours: number;
  hiretruck: boolean;
  globaldropbonus: number;
  deliverydate: Date;
  tripodostart: number;
  tripodoend: number;
  groupseq: number;
  tripstarttime: Date;
  tripendtime: Date;
  lineTemperature: any;
  lineServiceTO: any;
  events: any[];
  loadNoDuplicated: boolean;
}

export interface DriverBreak {
  drivershiftId: number;
  locationId: string;
  tripId: number;
  locationPlannedId: string;
  siteId: number;
  breakTypeId: string;
  driverId: number;
  breakstarttime: Date;
  breakendtime: Date;
  commentA: string;
  planned: boolean;
  plannedstarttime: Date;
  plannedendtime: Date;
  deducted: boolean;
}

export interface Line {
  invoiceId: number;
  siteid: number ;
  customerid: string;
  customergroupid: string;
  duedate: number| 'MM/dd/yy';
  fromdate: number| 'MM/dd/yy';
  todate: number| 'MM/dd/yy';
  issuedate: number| 'MM/dd/yy';
  invoicestatusid:string;
  documenttype: string;
  exported: boolean;
  invformat: string;
  cnformat: string;
  exgst: number;
  fuellevy: number;
  discountamt: string;
  totalexgst: number;
  defaultinvformat: string;
  defaultcnformat: string;
  showzero: boolean;
  created:number| 'MM/dd/yy';
  serviceNumber: string;
  effectiveDate: number;
  lineAmount: number;
  invoicePeriod:number;
}
export interface Invoice {
  id: number;
  siteid: number ;
  statusid:string;
  customerid: string;
  customergroupid: string;
  duedate: number| 'MM/dd/yy';
  fromdate: number| 'MM/dd/yy';
  todate: number| 'MM/dd/yy';
  issuedate: number| 'MM/dd/yy';
  invoicestatusid:string;
  documenttype: string;
  daystopay:number;
  exported: boolean;
  invformat: string;
  cnformat: string;
  exgst: number;
  applyGST:boolean;
  fuellevy: number;
  discountamt: string;
  totalexgst: number;
  defaultinvformat: string;
  defaultcnformat: string;
  showzero: boolean;
  created:number| 'MM/dd/yy';
}  
export interface InvoicesAPI {
    invoice: Invoice;
    lines: Line[];
    }  

export interface InvoiceLines {
      id: number;
      serviceid: number ;
      serviceno:string;
      effectivedate:  number;
      parentid: string;
      adjustmenttypeid: string;
      linetext: string;
      lineamt: number;
      customerid: string;
      enteredby:string;
      payrollcode: string;
      driver:string;
      linetype: string;
  }      

 export interface InvoiceDemoData {
  invoiceDate: any;
  pagination: {
    pageNumber: number;
    recordsPerPage: number;
    orderType: string;
    orderByField: string;
  };
  id?: any; 
  status?: any; 
  customerID?: any; 
  customerGroup?: any;
  issuedDate?: any; 
  InvoiceDate?: any;
  dueDate?: any;
  documentType?: any;
  selectFields?: any;
}


// pay-advice.model.ts
export interface PayAdvice {
    id: number;
    siteId: number;
    fromDate: number;
    toDate: number| 'MM/dd/yy';
    companyId: string;
    statusId: string;
    payAdviceText: string;
    issueDate: number;
    exported: boolean;
    paFormat: string;
    defaultPaFormat: string;
    created: number;
    baseExGst:number;
    totalExGst:number;
  }

  // line.model.ts
export interface Line {
    id: number;
    serviceId: number;
    adjustmentTypeId: number;
    payAdviceId: number;
    siteId: number;
    driverId: number;
  }

  export interface ApiResponse {
    payAdvice: PayAdvice;
    lines: Line[];
  }

  export interface DemoData {
    payAdviceDate: any;
    pagination: {
      pageNumber: number;
      recordsPerPage: number;
      orderType: string;
      orderByField: string;
    };
    likePayAdviceId?: any;
    status?: any;
    company?: any; 
    issuedDate?: any; 
  }

  export interface InvoiceLinesGetData {
    id: number;
  siteId: number;
  customerId: string;
  invoiceId: string;
   serviceId: number ;
  lineAmount: number;
  lineText: string;
  invoicePeriod: string;
   qty1: number;
    unit1: string;
    qty2: number;
    unit2: string;
    qty3: number;
  unit3: string;
  qty4: string;
  unit4: string;
  qty5: string;
  unit5: string;
  qty6: string;
  unit6: string;
  qty7: string;
  unit7: string;
  qty8: string;
  unit8: string;
  qtyExtra: string;
dataSourceId: string;
effectiveDate:  number;
  adjustmentTypeId: string; 
    parentid: string;
  enteredBy:string;
    fuelLevyAmount: number;
    adjustmentReference: string;
  serviceNumber:string;
  partitionDate:number;
  discountAmount: string;
} 