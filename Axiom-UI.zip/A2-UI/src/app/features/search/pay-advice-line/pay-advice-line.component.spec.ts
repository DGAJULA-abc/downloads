import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayAdviceLineComponent } from './pay-advice-line.component';

describe('PayAdviceLineComponent', () => {
  let component: PayAdviceLineComponent;
  let fixture: ComponentFixture<PayAdviceLineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayAdviceLineComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayAdviceLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
