import { Component } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { CellRendarComponent } from '../services/cell-rendar/cell-rendar.component';
import { SearchInvoiceService } from '../services/search-invoice.service';
import { PayAdviceLineService } from '../services/search-payAdviceLine.service';
import { PayAdviceLine, PayAdviceLinesGetData } from '../model/searchpayAdviceLine.model';
import { MatDialog } from '@angular/material/dialog';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';

@Component({
  selector: 'app-pay-advice-line',
  templateUrl: './pay-advice-line.component.html',
  styleUrls: ['./pay-advice-line.component.scss']
})
export class PayAdviceLineComponent {
  constructor(private service: SearchInvoiceService,
        private adviceLine: PayAdviceLineService, 
        public dialog: MatDialog
    ){}
  companies: any[] = [];
  serviceTypes: any[] = [];
  loadTypes: any[] = [];
  adjustmentTypes: any[] = [];
  customers: any[] = [];
  customerGroups: any[] = [];
  companyTypes: any[] = [];

    /**For Driver data */
    drivers: any[] = [];

    filteDriverData :any[] = [];

    /**
   * for ag grid drop down for Company ID
   */
    //autocomplete for dropdowns
    selectedCompanies:any;
    filteredCompanies: any[];
    filteredCompanie(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.companies.length; i++) {
        let country = this.companies[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredCompanies = filtered;
    }
        /**
   * for ag grid drop down for Driver ID
   */
    //autocomplete for dropdowns
    selectedDriver:any;
    filteredDrivers: any[];
    filteredDriver(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.filteDriverData.length; i++) {
        let driver = this.filteDriverData[i];
        if (driver.name.toLowerCase().indexOf(query.toLowerCase()) === 0) {
          filtered.push(driver);
        }
      } 
      this.filteredDrivers = filtered;
    }
      // Function to handle the selection
  handleCompanyTypeSelect(event:any) {
    // Find the selected option by value
    const selectedOption = this.filteDriverData.find(option => option.name === event.name);
    // If an option is found, update the formData with its id
    if (selectedOption) {
      this.formData.driver = selectedOption.id;
    }
  }

      /**
   * for ag grid drop down for Service Type
   */
    //autocomplete for dropdowns
    selectedserviceTypes:any;
    filteredserviceTypes: any[];
    filteredserviceType(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.serviceTypes.length; i++) {
        let country = this.serviceTypes[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredserviceTypes = filtered;
    }

  /**
   * for ag grid drop down for Load Type
   */
    //autocomplete for dropdowns
    selectedloadTypes:any;
    filteredloadTypes: any[];
    filteredloadType(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.loadTypes.length; i++) {
        let country = this.loadTypes[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredloadTypes = filtered;
    }

  /**
   * for ag grid drop down for Line Type
   */
    //autocomplete for dropdowns
    lineType: any[] = ['Any', 'Driver Payment', 'Pay Adjustment', 'Periodic Payment'];
    selectedlineTypes:any;
    filteredlineTypes: any[];
    filteredlineType(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.lineType.length; i++) {
        let country = this.lineType[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      } 
      this.filteredlineTypes = filtered;
    }
    /**
   * for ag grid drop down for Adjustment Type
   */
    //autocomplete for dropdowns
    selectedAdjustmentTypes:any;
    filteredAdjustmentTypes: any[];
    filteredAdjustmentType(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.loadTypes.length; i++) {
        let country = this.loadTypes[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredAdjustmentTypes = filtered;
    }
      /**
   * for ag grid drop down for Customer ID
   */
    //autocomplete for dropdowns
    selectedCustomers:any;
    filteredCustomers: any[];
    filteredCustomer(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.customers.length; i++) {
        let country = this.customers[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredCustomers = filtered;
    }
  /**
   * for ag grid drop down for Company Group
   */
    //autocomplete for dropdowns
    selectedCustomerGroups:any;
    filteredCustomerGroups: any[];
    filteredCustomerGroup(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.customerGroups.length; i++) {
        let country = this.customerGroups[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredCustomerGroups = filtered;
    }
    /**
     * For filter Company Type
     */
    selectedCompanyTypes:any;
    filteredCompanyTypes: any[];
    filteredCompanyType(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.companyTypes.length; i++) {
        let country = this.companyTypes[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredCompanyTypes = filtered;
    }


  /**On page Reload or initally we get all Drop down values of form
   * 
   */
  ngOnInit() {
    this.service.getDropDownData().subscribe((data: any) => {
      this.companies = data.ref.companys.map((obj: { companyId: any; }) => obj.companyId);
      this.drivers = data.ref.drivers
      this.filteDriverData = this.drivers.map(item => {
        let nameParts = [];
        if (item.surname && item.firstName) {
          nameParts.push(item.surname, item.firstName);
          if (item.employeeName) {
            nameParts.push(`- ${item.employeeName}`);
          }
        } else {
          if (item.surname) {
            nameParts.push(item.surname);
          }
          if (item.firstName) {
            nameParts.push(item.firstName);
          }
          if (item.employeeName) {
            nameParts.push(item.employeeName);
          }
        }
        if (item.companyId) {
          nameParts.push(`(${item.companyId})`);
        }      
        const filteredName = nameParts
          .filter(value => value !== null && value !== undefined && value !== '')
          .join(' ');
      
        return {
          id: item.id,
          name: filteredName
        };
      });           
      console.log(this.drivers);
      console.log(this.filteDriverData)
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.serviceTypes = data.ref.serviceTypes.map((obj: { serviceTypeId: any; }) => obj.serviceTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.loadTypes = data.ref.loadTypes.map((obj: { loadTypeId: any; }) => obj.loadTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.adjustmentTypes = data.ref.adjustmentTypes.map((obj: { adjustmentTypeId: any; }) => obj.adjustmentTypeId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customers = data.ref.customers.map((obj: { customerId: any; }) => obj.customerId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customerGroups = data.ref.customerGroups.map((obj: { groupId: any; }) => obj.groupId);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.companyTypes = data.ref.companyTypes.map((obj: { companyTypeId: any; }) => obj.companyTypeId);
    });


  }
  /**This is the form Data 
   * So we can pass it to backend to get Response
   * (based on conditions)
   */
  formData: any = {
    description: null,
    companyId: null,
    driver: null,
    loadNo: null,
    serviceNo: null,
    serviceType: null,
    loadType: null,
    unAllocatedOnly: true,
    adjustmentLineType:null,
    adjustmentType:null,
    effectiveFrom:null,
    effectiveTo:null,
    customerId: null,
    customerGroup: null,
    companyType: null,
    amoutFrom: null,
    amoutTo: null
  }; 
// table
colDefs: ColDef[] = [
  {
   cellRenderer: CellRendarComponent,headerName: '✔'
  },
  { field:'id',headerName: 'Id',resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter'},
  { field: 'serviceid', headerName: 'Service ID', resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'serviceno', headerName: 'Service No',resizable: true, floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'effectivedate', headerName: 'Effective Date',resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'parentid',  headerName: 'Print id',resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'adjustmenttypeid',headerName: ' Adjustment Type Id',  resizable: true,  floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'linetext',headerName: 'Line Text', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'lineamt', headerName: 'Line amt',  resizable: true,  floatingFilter: true,filter: 'agNumberColumnFilter'},
  { field: 'customerid',headerName: 'Customer Id', resizable: true,floatingFilter: true ,filter: 'agNumberColumnFilter'},
  { field: 'enteredby',headerName: 'Entered By', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'payrollcode',headerName: 'Payroll', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'driver',headerName: 'Driver', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' },
  { field: 'linetype',headerName: 'Line Type', resizable: true, floatingFilter: true,filter: 'agNumberColumnFilter' }
];

public defaultColDef: ColDef = {
  flex: 1,
  minWidth: 100,
  filter: 'agTextColumnFilter',
  floatingFilter: true,
  sortable: true,
  resizable: true,
  // editable: true,
};

/**
 * On Submitt the form we pass the form value 
 * and based on the payload we get the Response(in rowData)
 *  to diaplay in table
 */
  isChecked: boolean = false; // Initial state of the checkbox to send true and null
  rowData:  any[]=[];
  submitFormInvoiceLines(){
    this.formData.unAllocatedOnly = this.isChecked?'true' :null
    this.formData.companyId = this.selectedCompanies;
    this.formData.serviceType = this.selectedserviceTypes
    this.formData.loadType = this.selectedloadTypes 
    if(this.selectedlineTypes == 'Any'){
      this.formData.adjustmentLineType  = 'ALL';
    }else if(this.selectedlineTypes == 'Driver Payment') {
      this.formData.adjustmentLineType  = 'LINE';
    }else if(this.selectedlineTypes == 'Pay Adjustment') {
      this.formData.adjustmentLineType  = 'ADJUST';
    }else if(this.selectedlineTypes == 'Periodic Paymentt') {
      this.formData.adjustmentLineType  = 'PERIODIC';
    }
    this.formData.customerId  = this.selectedCustomers
    this.formData.customerGroup = this.selectedCustomerGroups
    this.formData.companyType = this.selectedCompanyTypes
    this.adviceLine.postpayAdviceLineTableData(this.formData).
      subscribe(
        (response : any) => {
        this.rowData = response.adjustments;
      }
    );
  }

  isDivVisible:boolean = false;
/**
 * OnClick on row We pass the 
 * @param : id 
 * of that row and Fetch Right Side Data
 * in payAdviceLine to display on right Form
 */
  matchedDriver :any;
  payAdviceLine :any;
  payadvice :PayAdviceLine;
  GetInvoiceLinedata(id: any){
    this.isDivVisible =true;
    this.adviceLine.getpayAdviceLineById(id).subscribe(
      response => {
        this.payAdviceLine = response;
        this.payadvice = response;
        console.log(this.payAdviceLine);  
        this.matchedDriver = this.findDriverById(this.payAdviceLine.driverId);
        console.log(this.matchedDriver);
      }
    );
  }
  // Function to find the driver object based on driver_id
 findDriverById(driverId: any) {
  console.log(driverId)
  return this.drivers.find(driver => driver.id === driverId);
}
   /**
   * Here getting inpot as Array Buffer
   * then handeling it and printing csv file as requried
   */
    downloadCsv(){
      this.adviceLine.postCsvDownload(this.formData).subscribe(
        (res: any) => {
         // Assuming 'response' is the array buffer received from your HTTP request
          var arrayBuffer = res;
          var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
          var url = window.URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'Search.PayAdviceLines.csv'; // Set the desired file name
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
        }
      );
  }

  closeDialog() {
    this.isDivVisible = false;
  }  

  isAbleToDeleteInvoiceLines() {
    return this.canWrite() &&
      this.rowData &&
      (this.rowData.length > 0) &&
      this.rowData.every(item => this.service.canDelete(item));
  }
  canWrite(){
    return true;
    }
    gridApi: GridApi<PayAdviceLinesGetData>
    selectedRowNode: null | PayAdviceLine;
    deleteInvoiceLines(){
      const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
      dialogRef.afterClosed().subscribe(result =>{
        console.log("clicked the download button");
        if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
          this.service.deleteInvoiceLines(this.payadvice.id).subscribe(
            (result: any) =>{
              if (this.selectedRowNode?.id) {       
                console.log("clicked the download button coming");
                //               // remove folder from grid
                              this.gridApi.applyTransaction({ remove:[this.selectedRowNode?.id as unknown as PayAdviceLinesGetData] });
                              this.selectedRowNode = null;
              } 
            }
          );
        }
      })
    }  


}
