import { Component } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Line, PayAdvice, ViewSearch } from '../model/search.model';
import { ColDef } from 'ag-grid-community';
import { DatePipe } from '@angular/common';
import { DateFormateComponent } from '../services/date-formate/date-formate.component';
import { CellRendarComponent } from '../services/cell-rendar/cell-rendar.component';
import { PayAdvicePreview, PayAdvicePreviewRequest } from '../../reportview/model/report-view.model';

// import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import {  ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { GridApi } from 'ag-grid-community';


@Component({
  selector: 'app-pay-advice',
  templateUrl: './pay-advice.component.html',
  styleUrls: ['./pay-advice.component.scss']
})
export class PayAdviceComponent {

  constructor(private service: SearchService,private datePipe: DatePipe){
  }

    /**for drop down data */
    companies: any[] = [];

  /**
   * for ag grid drop down for Company ID
   */
    //autocomplete for dropdowns
    selectedCompanies:any;
    filteredCompanies: any[];
    filteredCompanie(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.companies.length; i++) {
        let country = this.companies[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredCompanies = filtered;
    }

    /**
     * For Ag-Grid Dropdown for Status
     */
    status: any[] = ['HOLD', 'PRINTED', 'READY'];
    selectedStatus:any;
    filteredStatus: any[];
    filterStatus(event: any) {
      let filtered: any[] = [];
      let query = event.query;
  
      for (let i = 0; i < this.status.length; i++) {
        let country = this.status[i];
        if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
        }
      }
  
      this.filteredStatus = filtered;
    }


  payAdviceTable: PayAdvice[] =[]; 
  payAdvice!: PayAdvice;
  lines: Line[] = [];


  /**For Driver data */
  drivers: any[] = [];

  ngOnInit() {
    this.service.getDropDownData().subscribe((data: any) => {
      // console.log('onInit',data.ref.drivers);
      this.companies = data.ref.companys.map((obj: { companyId: any; }) => obj.companyId);
      console.log(this.companies)

      this.drivers = data.ref.drivers
      console.log(this.drivers);
    });
  }

  formData: any = {
    payAdviceNo: null,
    status: null,
    companyId: null,
    payAdviceDate: null,
    issuedDate: null
  }; // Initialize the form data fields as null

  /**
   * Here on submitt form we can send data to backend as post 
   * And receive data we can display in frontend
   */
    PayAdviceDate:Date;
    IssuedDate:Date;

    submitForm() {
      console.log(this.PayAdviceDate)
      this.formData.companyId = this.selectedCompanies
      this.formData.status = this.selectedStatus
      if(this.PayAdviceDate != null){
      this.formData.payAdviceDate = this.PayAdviceDate.getTime()
      }else if(this.PayAdviceDate == null){
        this.formData.payAdviceDate = null
        console.log(this.formData.payAdviceDate)
      }
      if(this.IssuedDate != null){
        this.formData.issuedDate = this.IssuedDate.getTime()
      }else if(this.IssuedDate ==null){
        this.formData.issueDate = null
      }
      console.log(this.formData)
      this.service.postData(this.formData).
      subscribe(
        (response : any) => {
          // Handle the response here if needed
          console.log('Response:', response);
          this.payAdviceTable = response.payadvices;
          console.log(this.payAdviceTable);
        }
      );
    }

    /**
     * For right side Form table
     */
    displayedColumns: string[] = ['demo-position', 'demo-name','demo-weight','demo-symbol','demo-amount'];
    dataSource: any;

    isDivVisible:boolean =false;
    selectedRow: any = null;
    checkboxClicked: boolean = false;

  /**
   * ag -grid table 
   * 
   */
  colDefs: ColDef[] = [
    { cellRenderer: CellRendarComponent,width:50,headerName: '✔', cellRendererParams: {
      selectedRow: null, // Initially, no row is selected
    }, },
    { headerName: 'Pay Advice', field:'id', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true },
    { headerName: 'From', field:'fromDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    { headerName: 'To', field:'toDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Company Code', field:'companyId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Company Type', field:'companyId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Status', field:'statusId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Description', field:'', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Issue Date', field:'issueDate',cellRenderer:DateFormateComponent, width: 190, filter: true, floatingFilter: true },
    { headerName: 'Pa Formate', field:'paFormat', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Default Pa Formate', field:'defaultPaFormat', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Base Ex GST', field:'baseExGst', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Total Ex GST', field:'totalExGst', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Created On', field:'created',cellRenderer:DateFormateComponent, width: 190, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

    /**
   * Here getting inpot as Array Buffer
   * then handeling it and printing csv file as requried
   */
    downloadCsv(){
      this.service.postCsvDownload(this.formData).subscribe(
        (res: any) => {
         // Assuming 'response' is the array buffer received from your HTTP request
          var arrayBuffer = res;
          var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
          var url = window.URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'report.csv'; // Set the desired file name
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
        }
      );
  }

  filteredDrivers:any;
  /**
   * To fetch data on click onclick on check box or row
   */
  dataForRightSideForm(event: any){
    this.service.getPayAdviceById(event.data.id).subscribe(
      (response) =>{
        console.log('Left side :',response);
        this.payAdvice = response.payAdvice;
        this.lines = response.lines;
    // Map the lines array to include the associated driver object
        const linesWithDrivers = this.lines.map(line => {
          const driverId = line.driverId;
          const driver = this.drivers.find(d => d.id === driverId);
          return { ...line, driver }; // Spread operator to include the driver object
        });
          this.dataSource = linesWithDrivers;

        console.log(linesWithDrivers);
      }
    )

  }

  ok:boolean  =false;
  sum : number = 0;
    /**
   * For toggle button 
   */
    rightSideForm(event :any ){
      console.log(event)
        //write logic to make all click check box unclick an reset every thing
        const clickedRowData = event.data;
            // Reset all checkboxes to their default state
            event.api.forEachNode((node: { data: { isChecked: boolean; }; }) => {
              // Reset the isChecked property of each row to false
              node.data.isChecked = false;
            });         
            // Redraw all rows to reflect the changes
            event.api.redrawRows();

        // Uncheck the previously selected row
        if (this.selectedRow) {
          this.selectedRow.isChecked = false;
        }
        // Check the clicked row
        clickedRowData.isChecked = true;
        this.selectedRow = clickedRowData;
        event.api.redrawRows({ rowNodes: [event.node] });

      this.sum = 1;
      console.log("Can u check sum here",this.sum)
      if(this.sum <= 1){
        this.isDivVisible =true;
        this.ok =true;
        this.dataForRightSideForm(event);
      }
       if(this.sum > 1){
        this.isDivVisible =false;
        this.ok = false;
      } 

    }
  /**
   * For Checkbox function
   * 
   */

  setCellSubData(intvalue :any, event:any) {
    console.log(intvalue);
    if(intvalue == 0){
      this.sum = 0
    }
    this.sum += intvalue;
    console.log("Checking sum in checkbox", this.sum)
    // if(this.sum == 1 && intvalue ==1){
    //    this.StoreEvevnt =event;
    // }
     if(this.sum == 1 ){
      this.isDivVisible = true;
      this.ok = true;
      // this.StoreEvevnt =event;
      console.log("okkkkkkkkkkkkkkkkkkkkkkkkkkkk")
    }else{
      this.ok = false;
      this.isDivVisible =false;
      console.log("not ok")
    } 
    this.dataForRightSideForm(event);
 
  }   
  
  /**
   * To close right side 
   */
closeDialog(){
      this.ok = false;
      this.isDivVisible =false;
      this.sum = 0

// Uncheck the previously selected row
      if (this.selectedRow) {
        this.selectedRow.isChecked = false;
      }
  }

  onPrintWithCompanyFormatClick() {
    
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    let payAdviceParam: PayAdvicePreview[] = [{
      id: 215587,
      siteId: 296,
      paFormat: null,
      defaultPaFormat: 7
    }];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: true,      
      paFormat: null,
      payrollCodeRequired: false,      
      payAdvice: payAdviceParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');
    
  }

  onPrintPayAdviceFormatClick() {
    
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    let payAdviceParam: PayAdvicePreview[] = [{
      id: 215587,
      siteId: 296,
      paFormat: null,
      defaultPaFormat: 7
    }];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: false,
      paFormat: 4, // TODO: change this to what was chosen in the pay advice format list.
      payrollCodeRequired: false,      
      payAdvice: payAdviceParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');
    
  }

}
