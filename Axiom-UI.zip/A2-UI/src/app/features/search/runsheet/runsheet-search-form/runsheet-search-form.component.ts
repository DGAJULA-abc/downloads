import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
@Component({
    selector: 'app-runsheet-search-form',
    templateUrl: './runsheet-search-form.component.html',
    styleUrls: ['./runsheet-search-form.component.scss']
})
export class RunsheetSearchFormComponent {
    @Output() searchDetails = new EventEmitter<any>();
    runsheetForm: FormGroup;
    currentTime: Date = new Date();
    previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
    searchForm: any = {};
    drivers: { id: any, name: string }[] = [];
    companyId: { id: any, name: string }[] = [];
    runsheetTypes: { id: any, name: string }[] = [];
    routes: { id: any, name: string }[] = [];
    companyTypes: { id: any, name: string }[] = [];

    constructor(
        private shareServices: SharedService
    ) {
    }
    ngOnInit() {
        this.getSearchFormWithDropDown();
        this.runsheetForm = new FormGroup({
            runsheetId: new FormControl(''),
            companyId: new FormControl(''),
            runsheetTypeId: new FormControl(''),
            companyTypeId: new FormControl(''),
            deliveryFrom: new FormControl(''),
            deliveryTo: new FormControl(''),
            employeeSiteId: new FormControl(''),
            activeOnly: new FormControl(''),
        });
    }

    getSearchFormWithDropDown() {
        this.shareServices.getContextView().subscribe((result: any) => {
            this.drivers = this.shareServices.getDriverList(result.ref.drivers);
            result.ref.companys.map((company: any) => {
                if (company.active)
                this.companyId.push({ id: company.companyId, name: company.companyId });
            });
            result.ref.companyTypes.map((company: any) => {
                if (company.active)
                this.companyTypes.push({ id: company.companyTypeId, name: company.companyTypeId });
            });

            result.ref.runsheetTypes.map((runsheetType: any) => {
                if (runsheetType.active)
                this.runsheetTypes.push({ id: runsheetType.runsheetTypeId, name: runsheetType.runsheetTypeId });
            });

            this.updateSearchFormFields();
        });
    }
    updateSearchFormFields() {
        this.searchForm = {
            displayName: 'Runsheets',
            fields: [{
                name: 'runsheetId',
                displayName: 'Runsheet Id',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'companyId',
                displayName: 'Company ID',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'companys',
                dropDownList: this.companyId,
                type: 'REFERENCE'
            }, {
                name: 'runsheetTypeId',
                displayName: 'Runsheet Type',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                dropDownList: this.runsheetTypes,
                reference: 'runsheetTypes',
                type: 'REFERENCE'
            }, {
                name: 'companyTypeId',
                displayName: 'Company Type',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                dropDownList: this.companyTypes,
                reference: 'companyTypes',
                type: 'REFERENCE'
            }, {
                name: 'deliveryFrom',
                displayName: 'Delivery From',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: this.previousDate,
                type: 'DATE'
            }, {
                name: 'deliveryTo',
                displayName: 'Delivery To',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: this.currentTime,
                type: 'DATE'
            }, {
                name: 'employeeSiteId',
                displayName: 'Driver',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                dropDownList: this.drivers,
                reference: 'drivers',
                type: 'REFERENCE'
            }, {
                name: 'activeOnly',
                displayName: 'Active drivers only?',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'BOOLEAN'
            }]
        };
    }
    updateValue(controlName: string, newValue: any) {
        this.runsheetForm.get(controlName)?.setValue(newValue);
        console.log(this.runsheetForm.value, controlName, newValue);
    }

    onSubmit() {
        let formValues = this.runsheetForm.value;
        if (formValues.deliveryFrom) {
            console.log(formValues.deliveryFrom);
            formValues.deliveryFrom = formValues.deliveryFrom.getTime();
        }
        if (formValues.deliveryTo) {
            formValues.deliveryTo = formValues.deliveryTo.getTime();
        }
        Object.keys(formValues).forEach((key) => {
            if (!formValues[key]) delete formValues[key];
        });
        this.searchDetails.emit(formValues);
        console.log(formValues);
    }

}
