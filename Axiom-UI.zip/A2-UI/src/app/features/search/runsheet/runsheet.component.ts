import { Component, ViewChild } from '@angular/core';
import { ColDef, RowNode } from 'ag-grid-community';
import { SearchService } from '../services/search.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FormGroup } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import { pagination } from 'src/app/shared/model/shared.model';
import { Runsheet, RunsheetDetails } from '../model/search.model';
import { MatDialog } from '@angular/material/dialog';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';

@Component({
  selector: 'app-runsheet',
  templateUrl: './runsheet.component.html',
  styleUrls: ['./runsheet.component.scss']
})
export class RunsheetComponent {
  columnDefs : ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable:false,
      pinned: 'left'
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      type: 'text'
  }, {
      field: 'runsheettypeid',
      headerName: 'Runsheet Type',
      type: 'text'
  }, {
      field: 'driver',
      headerName: 'Driver',
      type: 'text'
  }, {
      field: 'startdatetime',
      headerName: 'Start Date Time',
      type: 'DATETIME'
  }, {
      field: 'enddatetime',
      headerName: 'End Date Time',
      type: 'DATETIME'
  }, {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'text'
  }, {
      field: 'companytypeid',
      headerName: 'Company Type',
      type: 'text'
  }, {
      field: 'returndepottime',
      headerName: 'Return Depot Time',
      type: 'DATETIME'
  }, {
      field: 'totalhours',
      headerName: 'Total Hours',
      type: 'text'
  }, {
      field: 'startkm',
      headerName: 'Start KM',
      type: 'text'
  }, {
      field: 'endkm',
      headerName: 'End KM',
      type: 'text'
  }, {
      field: 'totalkms',
      headerName: 'Total Kms',
      type: 'text'
  }, {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
  }, {
      field: 'sumcharge',
      headerName: 'Sum Charge',
      type: 'text'
  }, {
      field: 'payamt',
      headerName: 'Pay amt',
      type: 'text'
  }, {
      field: 'cntservices',
      headerName: 'Count Services',
      type: 'text'
  }, {
      field: 'createdby',
      headerName: 'Created By',
      type: 'text'
  }, {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'text'
  }, {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
          disabled: true,
      },
  }, {
      field: 'hasbreaks',
      headerName: 'Has Breaks',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
          disabled: true,
      },
  }, {
      field: 'employeename',
      headerName: 'Employee Name',
      type: 'text'
  }, {
      field: 'firstname',
      headerName: 'Firstname',
      type: 'text'
  }, {
      field: 'lastname',
      headerName: 'Lastname',
      type: 'text'
  }, {
      field: 'vendorname',
      headerName: 'Vendor name',
      type: 'text'
  }, {
      field: 'gpskm',
      headerName: 'GPS KM',
      type: 'text'
  }, {
      field: 'odokm',
      headerName: 'Odo KM',
      type: 'text'
  }, {
      field: 'rateid',
      headerName: 'Rate ID',
      type: 'text'
  }
  ];

  columnDefsRunsheetLines: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable:false,
      pinned: 'left'
    },
    {
      type: 'default',
      field: 'seqDisplay',
      headerName: 'Seq',
      width: 80
    }, {
      type: 'default',
      field: 'lineServiceTO.loadNo',
      headerName: 'Load No'

    }, {
      type: 'default',
      field: 'lineServiceTO.tripIdCust',
      headerName: 'Trip'

    }, {
      type: 'default',
      field: 'lineServiceTO.serviceGroup',
      headerName: 'Service Group'

    }, {
      type: 'default',
      field: 'serviceTypeId',
      headerName: 'Service Type'

    }, {
      type: 'default',
      field: 'loadTypeId',
      headerName: 'Load Type'

    }, {
      type: 'default',
      field: 'locationPickupId',
      headerName: 'From',
      width: 200

    }, {
      type: 'default',
      field: 'locationDropId',
      headerName: 'To',
      width: 200

    }, {
      type: 'yesOrNo',
      field: 'lineServiceTO.complete',
      headerName: 'Complete'

    }, {
      type: 'default',
      field: 'locationReturnId',
      headerName: 'Return To',
      width: 200

    }, {
      type: 'default',
      field: 'lineServiceTO.chargeAmt',
      headerName: 'Charge Amount',
      // cellFilter: 'currency'

    }, {
      type: 'currency',
      field: 'payamt',
      headerName: 'Pay Amount'

    }, {
      type: 'default',
      field: 'lineServiceTO.serviceNo',
      headerName: 'Service No.'

    }, {
      type: 'default',
      field: 'docket',
      headerName: 'Docket'

    }, {
      type: 'container',
      field: 'containerId',
      headerName: 'Container'

    }, {
      type: 'default',
      field: 'truckId',
      headerName: 'Truck'

    }, {
      type: 'default',
      field: 'trailerId',
      headerName: 'Trailer'

    }, {
      type: 'default',
      field: 'trailerTagId',
      headerName: 'Trailer Tag'

    }, {
      type: 'default',
      field: 'truck.fleetNumber',
      headerName: 'Fleet No.'

    }, {
      type: 'default',
      field: 'lineServiceTO.customerId',
      headerName: 'Customer Id'

    }, {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.locationDesc',
      headerName: 'Pickup Location Desc',
      width: 300

    }, {
      type: 'default',
      field: 'lineServiceTO.dropLocation.locationDesc',
      headerName: 'Drop Location Desc',
      width: 300

    }, {
      type: 'default',
      field: 'truck.truckTypeId',
      headerName: 'Truck Type',
      width: 150

    }, {
      type: 'default',
      field: 'lineServiceTO.batchNo',
      headerName: "ConNote"

    }, {
      type: 'default',
      field: 'lineServiceTO.custRef',
      headerName: "CustRef"

    }, {
      type: 'default',
      field: 'lineServiceTO.loadLocation.locationId',
      headerName: 'Load Location',
      width: 200

    }, {
      type: 'default',
      field: 'lineServiceTO.loadLocation.locationDesc',
      headerName: 'Load Location Desc',
      width: 300

    }, {
      type: 'default',
      field: 'lineServiceTO.dropLocation.zoneChargeId',
      headerName: 'Charge Zone Drop',
      width: 150

    }, {
      type: 'default',
      field: 'lineServiceTO.dropLocation.zonePayId',
      headerName: 'Pay Zone Drop',
      width: 150

    }, {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zoneChargeId',
      headerName: 'Charge Zone Pickup',
      width: 150

    }, {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      width: 150

    }, {
      type: 'vessel', field: 'lineServiceTO.vesselId', headerName: 'Vessel No.'
    },
  {
      field: 'createdby', headerName: 'Created by'
    },
    {
      field: 'fuelLevyInfo.fuelLevyCharge', headerName: 'Fuel Levy Charge'
    },
    {
      field: 'fuelLevyInfo.fuelLevyPay', headerName: 'Fuel Levy Pay'
    },
    {
      field: 'fuelLevyInfo.fuelLevyPay', headerName: 'Fuel Levy Pay'
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Qty. 1',
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      width: 150

    },
  ];

  columnDefBreaks = [
    {type: 'autoId'},
    {type: 'default', field: 'locationId', displayName: 'Location'},
    {type: 'default', field: 'breakTypeId', displayName: 'Type'},
    {type: 'dateAndTime', field: 'breakstarttime', displayName: 'Start date/time'},
    {type: 'dateAndTime', field: 'breakendtime', displayName: 'End date/time'},
    {
      type: 'default',
      field: 'getDuration()',
      displayName: 'Break duration',
      cellFilter: 'duration:\'ms\':\'m[m]\''
    },
    {type: 'default', field: 'commentA', displayName: 'Comments', width: 300}
];
summary: { label: string; value: number }[];
  public rowData: Runsheet[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true
  };
  runsheetDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: Runsheet| null;
  runsheetDetails: RunsheetDetails;
  rowNodeRunsheetLines: RowNode[];
  rowNodeDriverBreak: RowNode[];
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "runsheetid"
  }
  selectedSRunsheets: any;
  canDelete: boolean = false;
  totalRecords: number = 0;
  searchFormDetails: any;
  constructor(
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.runsheetList(event);
  }

  runsheetList(event: any) {
    this.searchFormDetails = event;
    this.searchServices.getRunsheetList(event).subscribe((result: any) => {
      this.rowData = result.runsheets;
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
    });
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
      console.log(this.editForm)
      if (this.editForm)
      this.searchServices.getRunsheetDetailsByID(this.editForm?.runsheetid).subscribe((results: any) => {
        this.runsheetDetails = results.runsheet;
        this.rowNodeRunsheetLines = results.runsheet.runsheetLines;
        this.summary = this.getSummary(this.rowNodeRunsheetLines);
        this.rowNodeDriverBreak = results.runsheet.driverBreaks;
      });
    }

    this.selectedSRunsheets = event.api.getSelectedNodes().map((rowNode: any) => {
      return rowNode.data;
    });
    this.canDelete = this.selectedSRunsheets.filter((services: any) => services.complete).length > 0 ? true : false;
  }
  onTabSelectToggle(event: any) {
    console.log(event);
  }

  downloadCSVServices() {
    let selectedFields
    if (this.tableGridChnages) {
      selectedFields = this.columnDefs.map((column) => column.field);
    }
    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices.downLoadCSVService(downloadCSVRequestBody).subscribe(result => {
      if (result) {
        this.sharedDervice.downloadCSV(result, 'Search.Service.csv');
      }
    });
  }

  getSummary(runsheetlines: any[]): { label: string; value: number }[] {
    const result: { label: string; value: number }[] = [{ label: 'services', value: runsheetlines.length }];
    const resultObj: { [key: string]: number } = {};

    runsheetlines.map(line => {
      for (let index = 1; index <= 8; index++) {
        const unitKey = `unit${index}`;
        const qtyKey = `qty${index}`;

        const isUnitRegistered = resultObj[line[unitKey]];
        const qtyValue = parseFloat(line[qtyKey] || 0);
        const addedValue = (resultObj[line[unitKey]] || 0) + qtyValue;
        resultObj[unitKey] = isUnitRegistered ? addedValue : qtyValue;
      }
    });

    const roundDecimal = (input: number): number => {
      return input % 1 === 0 ? input : parseFloat(input.toFixed(3));
    };

    for (const prop in resultObj) {
      if (resultObj[prop]) {
        result.push({ label: runsheetlines[0][prop], value: roundDecimal(resultObj[prop]) });
      }
    }
    return result;
  }

  deletRunsheet() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if(result == true) {
        let canDeleteRecords: any[] = [];
        this.selectedSRunsheets.filter((runsheet: any) => {
          if (runsheet.complete == false) {
            canDeleteRecords.push(runsheet.runsheetid)
          }
        });
        this.searchServices.deleteRunsheet(canDeleteRecords).subscribe((result: any)=> {
          if (result)
          this.runsheetList(this.searchFormDetails);
        });
        
      }
    });
  }
}
