import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchComponent } from './search.component';
import { ServicesListComponent } from './services-list/services-list.component';
import { PayAdviceComponent } from './pay-advice/pay-advice.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { InvoiceLinesComponent } from './invoice-lines/invoice-lines.component';
import { PayAdviceLineComponent } from './pay-advice-line/pay-advice-line.component';
import { RunsheetComponent } from './runsheet/runsheet.component';
import { TripsListComponent } from './trips-list/trips-list.component';


const routes: Routes = [
  {
    path: '',
    component: SearchComponent,
    children: [
      {
        path: 'Search.Services',
        component: ServicesListComponent
      },
      {
        path: 'Search.Trips',
        component: TripsListComponent
      },
      {
        path: 'Search.Runsheets',
        component: RunsheetComponent
      },
      {
        path: 'Search.Invoices',
        component: InvoiceComponent
      },
      {
        path: 'Search.InvoiceLines',
        component: InvoiceLinesComponent
      },
      {
        path: 'Search.PayAdvices',
        component: PayAdviceComponent 
      },
      {
        path: 'Search.PayAdviceLines',
        component: PayAdviceLineComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SearchRoutingModule { }
