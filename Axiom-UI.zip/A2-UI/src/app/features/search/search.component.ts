import { Component } from '@angular/core';
import { SearchService } from './services/search.service';
import { ViewSearch } from './model/search.model';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent  {
  isClicked = false;
  viewDetails: ViewSearch;

  constructor( 
    private searchServices: SearchService
  ) { }

  ngOnInit(): void {
    this.getSerchviewDetails();
  }

  getSerchviewDetails() {
    this.searchServices.getSearchView()
    .subscribe(
      (result: any) => {
        this.viewDetails = result;
        console.log(this.viewDetails);
      }
    );
  }
}
