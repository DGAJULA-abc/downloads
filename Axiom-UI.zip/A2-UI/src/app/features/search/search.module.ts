import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SearchRoutingModule } from './search-routing.module';
import { SearchComponent } from './search.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ServicesListComponent } from './services-list/services-list.component';
import { PayAdviceComponent } from './pay-advice/pay-advice.component';
import { ServiceSearchFormComponent } from './services-list/service-search-form/service-search-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InvoiceComponent } from './invoice/invoice.component';
import { ViewInvoiceListComponent } from './view-invoice-list/view-invoice-list.component';
import { CellRendarComponent } from './services/cell-rendar/cell-rendar.component';
import { InvoiceLinesComponent } from './invoice-lines/invoice-lines.component';
import { DateFormateComponent } from './services/date-formate/date-formate.component';
import { PayAdviceLineComponent } from './pay-advice-line/pay-advice-line.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ServiceEditFormComponent } from './services-list/service-edit-form/service-edit-form.component';
import { TripsListComponent } from './trips-list/trips-list.component';
import { TripsFormComponent } from './trips-list/trips-form/trips-form.component';
import { TripsEditFormComponent } from './trips-list/trips-edit-form/trips-edit-form.component';
import { RunsheetComponent } from './runsheet/runsheet.component';
import { RunsheetSearchFormComponent } from './runsheet/runsheet-search-form/runsheet-search-form.component';
import { PlanModule } from '../plan/plan.module';
import { DeleteInvoiceLinesComponent } from './delete-invoice-lines/delete-invoice-lines.component';
import { MatAutoCompleteComponent } from './mat-auto-complete/mat-auto-complete.component';
import { TooltipModule } from 'primeng/tooltip';
@NgModule({
  declarations: [
    SearchComponent,
    ServicesListComponent,
    PayAdviceComponent,
    ServiceSearchFormComponent,
    InvoiceComponent,
    ViewInvoiceListComponent,
    CellRendarComponent,
    InvoiceLinesComponent,
    DateFormateComponent,
    PayAdviceLineComponent,
    ServiceEditFormComponent,
    TripsListComponent,
    TripsFormComponent,
    TripsEditFormComponent,
    RunsheetComponent,
    RunsheetSearchFormComponent,
    DeleteInvoiceLinesComponent,
    MatAutoCompleteComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SearchRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    DragDropModule,
    PlanModule,
    TooltipModule
  ],
  providers:[DatePipe,
    PayAdviceComponent
  ],
  exports: [
    SearchComponent,
    MatAutoCompleteComponent
  ]
})
export class SearchModule { }
