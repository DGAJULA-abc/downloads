import { Component } from '@angular/core';

@Component({
  selector: 'app-service-edit-form',
  templateUrl: './service-edit-form.component.html',
  styleUrls: ['./service-edit-form.component.scss']
})
export class ServiceEditFormComponent {

}
