import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceSearchFormComponent } from './service-search-form.component';

describe('ServiceSearchFormComponent', () => {
  let component: ServiceSearchFormComponent;
  let fixture: ComponentFixture<ServiceSearchFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceSearchFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceSearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
