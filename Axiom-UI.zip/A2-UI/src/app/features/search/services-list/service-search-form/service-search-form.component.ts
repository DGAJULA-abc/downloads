import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SearchService } from '../../services/search.service';
import { SharedService } from '../../../../shared/services/shared.service';

@Component({
    selector: 'app-service-search-form',
    templateUrl: './service-search-form.component.html',
    styleUrls: ['./service-search-form.component.scss']
})
export class ServiceSearchFormComponent implements OnInit {
    @Output() searchDetails = new EventEmitter<any>();
    serviceForm: FormGroup;
    currentTime: Date = new Date();
    previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
    drivers: { id: any, name: string }[] = [];
    companyId: { id: any, name: string }[] = [];
    routes: { id: any, name: string }[] = [];
    companyTypes: { id: any, name: string }[] = [];
    truckId: { id: any, name: string }[] = [];
    trailer: { id: any, name: string }[] = [];
    locations: { id: any, name: string }[] = [];
    siteUsers: { id: any, name: string }[] = [];
    serviceType: { id: any, name: string }[] = [];
    loadType: { id: any, name: string }[] = [];
    customer: { id: any, name: string }[] = [];

    searchForm: any = {};

    constructor(
        private sharedServices: SharedService
    ) {
    }
    ngOnInit() {
        this.getSearchFormWithDropDown();
        this.serviceForm = new FormGroup({
            svcNo: new FormControl(''),
            loadNo: new FormControl(''),
            svcDateFrom: new FormControl(''),
            svcDateTo: new FormControl(''),
            svcType: new FormControl(''),
            loadType: new FormControl(''),
            svcCustomer: new FormControl(''),
            loadCustRef: new FormControl(''),
            svcContainer: new FormControl(''),
            svcPickupLocation: new FormControl(''),
            loadBatchNo: new FormControl(''),
            svcDropLocation: new FormControl(''),
            svcEnteredBy: new FormControl(''),
            runsheetId: new FormControl(''),
            tripTruck: new FormControl(''),
            tripDriver: new FormControl(''),
            tripTrailer: new FormControl(''),
            tripCompany: new FormControl(''),
            invoiceId: new FormControl(''),
            svcPeriodic: new FormControl('')
        });
    }

    getSearchFormWithDropDown() {
        this.sharedServices.getContextView().subscribe((result: any) => {
            this.drivers = this.sharedServices.getDriverList(result.ref.drivers);
            this.truckId = this.sharedServices.getTruckList(result.ref.trucks);
            this.trailer = this.sharedServices.getTrailerList(result.ref.trailers);
            result.ref.locations.map((location: any)=> {
                if (location.active) {
                    let loactionName = [location.locationId, location.accShortCut ?  " ( " + location.accShortCut + " )" : ''].filter(function (val) {
                        return val;
                    }).join(' ');
                    this.locations.push({id: loactionName , name: loactionName});
                }
            });
            result.ref.companys.map((company: any) => {
                if (company.active)
                    this.companyId.push({ id: company.companyId, name: company.companyId });
            });
            result.ref.companyTypes.map((company: any) => {
                if (company.active)
                    this.companyTypes.push({ id: company.companyTypeId, name: company.companyTypeId });
            });

            result.ref.serviceTypes.map((serviceType: any) => {
                if (serviceType.active)
                    this.serviceType.push({ id: serviceType.serviceTypeId, name: serviceType.serviceTypeId });
            });

            result.ref.loadTypes.map((loaType: any) => {
                if (loaType.active)
                    this.loadType.push({ id: loaType.loadTypeId, name: loaType.loadTypeId });
            });

            result.ref.userDatas.map((userData: any) => {
                let useraName = userData.userName + " ("+ userData.userId +" )";
                this.siteUsers.push({ id: userData.userId, name: useraName});
            });
            console.log(this.siteUsers);

            result.ref.customers.map((customer: any) => {
                if (customer.active){
                    this.customer.push({ id: customer.customerId, name: customer.customerId});
                }
            });

            this.updateSearchFormFields();
        });
    }
    updateSearchFormFields() {
        this.searchForm = {
            displayName: 'Services',
            name: 'Search.Services',
            endpoint: '/search/service/',
            fields: [{
                name: 'svcNo',
                displayName: 'Service No.',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'loadNo',
                displayName: 'Load No.',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'svcDateFrom',
                displayName: 'Service Date From',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: this.previousDate,
                type: 'DATE'
            }, {
                name: 'svcDateTo',
                displayName: 'Service Date To',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: this.currentTime,
                type: 'DATE'
            }, {
                name: 'svcType',
                displayName: 'Service Type',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'serviceTypes',
                dropDownList: this.serviceType,
                type: 'REFERENCE'
            }, {
                name: 'loadType',
                displayName: 'Load Type',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'loadTypes',
                dropDownList: this.loadType,
                type: 'REFERENCE'
            }, {
                name: 'svcCustomer',
                displayName: 'Customer',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'customers',
                dropDownList: this.customer,
                type: 'REFERENCE'
            }, {
                name: 'loadCustRef',
                displayName: 'Cust Ref.',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'loadBatchNo',
                displayName: 'Batch No.',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'svcContainer',
                displayName: 'Container',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'containers',
                type: 'REFERENCE'
            }, {
                name: 'svcPickupLocation',
                displayName: 'Pickup Location',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'locations',
                dropDownList: this.locations,
                type: 'REFERENCE'
            }, {
                name: 'svcDropLocation',
                displayName: 'Drop Location',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'locations',
                dropDownList: this.locations,
                type: 'REFERENCE'
            }, {
                name: 'svcEnteredBy',
                displayName: 'Entered By',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'siteUsers',
                dropDownList: this.siteUsers,
                type: 'REFERENCE'
            }, {
                name: 'runsheetId',
                displayName: 'Runsheet No',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'tripTruck',
                displayName: 'Truck',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'trucks',
                dropDownList: this.truckId,
                type: 'REFERENCE'
            }, {
                name: 'tripDriver',
                displayName: 'Driver',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'drivers',
                dropDownList: this.drivers,
                type: 'REFERENCE'
            }, {
                name: 'tripTrailer',
                displayName: 'Trailer',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'trailers',
                dropDownList: this.trailer,
                type: 'REFERENCE'
            }, {
                name: 'tripCompany',
                displayName: 'Company',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                reference: 'companys',
                dropDownList: this.companyId,
                type: 'REFERENCE'
            }, {
                name: 'invoiceId',
                displayName: 'Invoice No',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, {
                name: 'svcPeriodic',
                displayName: 'Periodic Services only',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'BOOLEAN'
            }
            ],
        };
    }

    updateValue(controlName: string, newValue: any) {
        this.serviceForm.get(controlName)?.setValue(newValue);
        console.log(this.serviceForm.value, controlName, newValue);
    }
    onSubmit() {
        let formValues = this.serviceForm.value;
        if (formValues.svcDateFrom) {
            console.log(formValues.svcDateFrom);
            formValues.svcDateFrom = formValues.svcDateFrom.getTime();
        }
        if (formValues.svcDateTo) {
            formValues.svcDateTo = formValues.svcDateTo.getTime();
        }
        Object.keys(formValues).forEach((key) => {
            if (!formValues[key]) delete formValues[key];
        });
        this.searchDetails.emit(formValues);
        console.log(formValues);
    }

}
