import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  RowNode
} from 'ag-grid-community';

import { SearchService } from '../services/search.service';
import { pagination } from 'src/app/shared/model/shared.model';
import { Services } from '../model/search.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'app-services-list',
  templateUrl: './services-list.component.html',
  styleUrls: ['./services-list.component.scss']
})
export class ServicesListComponent {
  gridApi!: GridApi<any>;
  columnFields: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable:false,
      pinned: 'left'
    },
    {
      field: 'docket',
      headerName: 'Docket',
      type: 'TEXT'
    }, {
      field: 'serviceid',
      headerName: 'Service ID',
      type: 'TEXT'
    }, {
      field: 'serviceno',
      headerName: 'Service No.',
      type: 'TEXT'
    }, {
      field: 'servicetypeid',
      headerName: 'Service type',
      type: 'TEXT'
    }, {
      field: 'servicedate',
      headerName: 'Service Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'customerid',
      headerName: 'Customer ID',
      type: 'TEXT'
    }, {
      field: 'customergroupid',
      headerName: 'Customer Group',
      type: 'TEXT'
    },
    {
      field: 'truckid',
      headerName: 'Truck',
      type: 'TEXT'
    }, {
      field: 'trailerid',
      headerName: 'Trailer',
      type: 'TEXT'
    }, {
      field: 'containerid',
      headerName: 'Container',
      type: 'container'
    }, {
      field: 'containertypeid', headerName: 'Container type', type: 'TEXT'
    }, {
      field: 'locationid_pickup',
      headerName: 'Location Pickup',
      type: 'TEXT'
    }, {
      field: 'locationid_drop',
      headerName: 'Location Drop',
      type: 'TEXT'
    }, {
      field: 'enteredby',
      headerName: 'Entered by',
      type: 'TEXT'
    }, {
      field: 'loadid',
      headerName: 'Load',
      type: 'TEXT'
    }, {
      field: 'qtydesc',
      headerName: 'Qty Desc',
      type: 'TEXT'
    }, {
      field: 'locations',
      headerName: 'Locations',
      type: 'TEXT'
    }, {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'TEXT'
    }, {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
        cellRendererParams: {
            disabled: true,
        },
    }, {
      field: 'originsite',
      headerName: 'Origin Site',
      type: 'site'
    }, {
      field: 'destinationsite',
      headerName: 'Destination Site',
      type: 'site'
    }, {
      field: 'originloc',
      headerName: 'Origin Loc',
      type: 'TEXT'
    }, {
      field: 'destinationloc',
      headerName: 'Destination Loc',
      type: 'TEXT'
    }, {
      field: 'invoiceid',
      headerName: 'Invoice',
      type: 'TEXT'
    }, {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'TEXT'
    }, {
      field: 'employeefield',
      headerName: 'Employee field',
      type: 'TEXT'
    }, {
      field: 'firstfield',
      headerName: 'Firstfield',
      type: 'TEXT'
    }, {
      field: 'lastfield',
      headerName: 'Lastfield',
      type: 'TEXT'
    }, {
      field: 'runsheetid',
      headerName: 'Runsheet ID',
      type: 'TEXT'
    }, {
      field: 'customerid_load',
      headerName: 'Customer ID Load',
      type: 'TEXT'
    }, {
      field: 'loadno',
      headerName: 'Load No.',
      type: 'TEXT'
    }, {
      field: 'loadtypeid',
      headerName: 'Load type',
      type: 'TEXT'
    }, {
      field: 'scheduleddate',
      headerName: 'Scheduled Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'holdcode_load',
      headerName: 'Holdcode Load',
      type: 'TEXT'
    }, {
      field: 'complete_load',
      headerName: 'Complete Load',
      type: 'TEXT'
    }, {
      field: 'batchno',
      headerName: 'ConNote',
      type: 'TEXT'
    }, {
      field: 'locationid',
      headerName: 'Location',
      type: 'TEXT'
    }, {
      field: 'custreference',
      headerName: 'Cust Ref.',
      type: 'TEXT'
    }, {
      field: 'customergroupid_load',
      headerName: 'Customer Group Load',
      type: 'TEXT'
    }, {
      field: 'qty1',
      headerName: 'Qty 1',
      type: 'DECIMAL'
    }, {
      field: 'unit1',
      headerName: 'Unit 1',
      type: 'TEXT'
    }, {
      field: 'qty2',
      headerName: 'Qty 2',
      type: 'DECIMAL'
    }, {
      field: 'unit2',
      headerName: 'Unit 2',
      type: 'TEXT'
    }, {
      field: 'qty3',
      headerName: 'Qty 3',
      type: 'DECIMAL'
    }, {
      field: 'unit3',
      headerName: 'Unit 3',
      type: 'TEXT'
    }, {
      field: 'qty4',
      headerName: 'Qty 4',
      type: 'DECIMAL'
    }, {
      field: 'unit4',
      headerName: 'Unit 4',
      type: 'TEXT'
    }, {
      field: 'qty5',
      headerName: 'Qty 5',
      type: 'DECIMAL'
    }, {
      field: 'unit5',
      headerName: 'Unit 5',
      type: 'TEXT'
    }, {
      field: 'qty6',
      headerName: 'Qty 6',
      type: 'DECIMAL'
    }, {
      field: 'unit6',
      headerName: 'Unit 6',
      type: 'TEXT'
    }, {
      field: 'qty7',
      headerName: 'Qty 7',
      type: 'DECIMAL'
    }, {
      field: 'unit7',
      headerName: 'Unit 7',
      type: 'TEXT'
    }, {
      field: 'qty8',
      headerName: 'Qty 8',
      type: 'DECIMAL'
    }, {
      field: 'unit8',
      headerName: 'Unit 8',
      type: 'TEXT'
    }, {
      field: 'qtya',
      headerName: 'Qty A',
      type: 'TEXT'
    }, {
      field: 'qtyb',
      headerName: 'Qty B',
      type: 'TEXT'
    }, {
      field: 'qtyc',
      headerName: 'Qty C',
      type: 'TEXT'
    }, {
      field: 'qtyd',
      headerName: 'Qty D',
      type: 'TEXT'
    }, {
      field: 'qtye',
      headerName: 'Qty E',
      type: 'TEXT'
    }, {
      field: 'qtyf',
      headerName: 'Qty F',
      type: 'TEXT'
    }, {
      field: 'qtyg',
      headerName: 'Qty G',
      type: 'TEXT'
    }, {
      field: 'qtyh',
      headerName: 'Qty H',
      type: 'TEXT'
    }, {
      field: 'sloadtype',
      headerName: 'S Load type',
      type: 'TEXT'
    }, {
      field: 'trailerid_tag',
      headerName: 'Trailer Tag',
      type: 'TEXT'
    }, {
      field: 'chargeamt',
      headerName: 'Charge Amount',
      type: 'TEXT'
    }, {
      field: 'rateid',
      headerName: 'Rate',
      type: 'TEXT'
    }, {
      field: 'driverrate',
      headerName: 'Driver Rate',
      type: 'TEXT'
    }, {
      field: 'driverpay',
      headerName: 'Driver Pay',
      type: 'TEXT'
    }, {
      field: 'tripid_cust',
      headerName: 'Trip Cust',
      type: 'TEXT'
    }, {
      field: 'datasourceid',
      headerName: 'Datasource',
      type: 'TEXT'
    }, {
      field: 'tripid',
      headerName: 'Trip',
      type: 'TEXT'
    }, {
      field: 'tripdate',
      headerName: 'Trip Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? (new Date(data.value)).toLocaleDateString() : '';
      }
    }, {
      field: 'driver',
      headerName: 'Driver',
      type: 'TEXT'
    }, {
      field: 'used',
      headerName: 'Used',
      type: 'TEXT'
    }, {
      field: 'servicedesc',
      headerName: 'Service Desc',
      type: 'TEXT'
    }
  ];
  columnDefs: ColDef[] = this.columnFields;
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true,
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  @ViewChild('mySelect') mySelect: MatSelect;
  editForm: Services | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "serviceid"
  }
  selectedServices: any;

  totalRecords: number = 0;
  canDelete: boolean = false;
  searchForm: any;
  setupPermission: Permissions;
  gridOptions: GridOptions;
  selectedOptions: any[];

  constructor(
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog
  ) { 
    this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      }
    }
  }

  ngOnInit(): void {
    this.selectedOptions = this.columnDefs.map(coulmn=> coulmn.field);
    this.searchViewDetails();
  }

  searchViewDetails() {
    this.searchServices.getSearchView()
      .subscribe(
        (result: any) => {
          this.setupPermission = result.permissions.sitePermissions[0].permissions;
          
          // this.rowData = result;
        }
      );
  }
  canRead() {

  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.ServiceList(event);
  }

  ServiceList(event: any) {
    this.searchForm = event;
    console.log(this.searchForm);
    this.searchServices.getSearchList(event).subscribe((result: any) => {
      this.rowData = result.services;
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
    });
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data
    }
    this.selectedServices = event.api.getSelectedNodes().map((rowNode: any) => {
      return rowNode.data;
    });
    this.canDelete = this.selectedServices.filter((services: any) => services.used).length > 0 ? true : false;
  }

  onTabSelectToggle(event: any) {
    console.log(event);
  }

  downloadCSVServices() {
    let selectedFields
    if (this.tableGridChnages) {
      selectedFields = this.columnDefs.map((column) => column.field);
    }
    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices.downLoadCSVService(downloadCSVRequestBody).subscribe(result => {
      if (result) {
        this.sharedDervice.downloadCSV(result, 'Search.Service.csv');
      }
    });
  }

  deleteServices() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result == true) {
        let data: any[] = [];
        let deletableServices = this.selectedServices.filter((services: any) => !services.used);
        if (deletableServices) {
          deletableServices.map((service: any) => {
            data.push(service.id);
          });
          this.searchServices.deleteServices(data).subscribe((result: any) => {
            this.ServiceList(this.searchForm);
            this.editForm = null;
          });
        }
      }
    });
  }

  onSelectionChange(event: any) {
    console.log(event.value);
    this.columnDefs =  this.columnFields.filter(column => event.value.includes(column.field) );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
}
