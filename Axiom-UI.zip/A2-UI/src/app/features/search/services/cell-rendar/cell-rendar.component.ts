import { Component, Input } from '@angular/core';
import { SearchService } from '../search.service';
import { ICellRendererParams } from 'ag-grid-community';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { PayAdviceComponent } from '../../pay-advice/pay-advice.component';

@Component({
  selector: 'app-cell-rendar',
  templateUrl: './cell-rendar.component.html',
  styleUrls: ['./cell-rendar.component.scss']
})
export class CellRendarComponent implements ICellRendererAngularComp{
  rowCheckData: any = "";
  params: any;
  constructor(
    private invoiceService: SearchService,
    private ok: PayAdviceComponent
  ) {

  }
  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: ICellRendererParams<any, any, any>): boolean {
    return false;
    // throw new Error('Method not Implemented');
  }
  ngOninit(): void {
  }

  isChecked: boolean = false;
  totalCount:number = 0;
  getRowIdData(event :any,event1 :MouseEvent){
      console.log(this.params.data.id)
        // Prevent the click event from bubbling up to the row click
        event1.stopPropagation();

        // Set the checkboxClicked flag to true in the grid component
        // this.params.context.componentParent.checkboxClicked = true;

    console.log("pay-advice line click value",this.params.data.isChecked)
    // if(this.params.data.isChecked === true){
    //   this.params.data.isChecked = false
    // }
    console.log(event.target.checked);
    /*** For Single Check function suppose
     *  if any row is checked and we have to unchek then use this method */
    if(this.params.data.isChecked === true && event.target.checked === false){
        this.params.data.isChecked = false
        this.totalCount = 0;
        this.ok.setCellSubData(this.totalCount,this.params);
        console.log("hiiiii here")
    /**this is used for multiline selection : suppose more than one checkbox selected thean close side bar */
    }else{
    this.totalCount = event.target.checked ? 1 : -1;
    this.invoiceService.panelBehSubject.next(true);
    this.ok.setCellSubData(this.totalCount,this.params);
    console.log("hii in else")
  }

  }

}
/**
 * Here I want to check click(checkbox) or not on click on raw 
 */