import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-date-formate',
  templateUrl: './date-formate.component.html',
  styleUrls: ['./date-formate.component.scss']
})
export class DateFormateComponent implements ICellRendererAngularComp  {
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }

}
