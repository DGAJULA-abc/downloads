import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiResponse, ViewSearch, DemoData, InvoicesAPI, InvoiceLinesGetData, ServiceList, InvoiceDemoData, RunsheetList, RunsheetDetails, RunsheetById } from '../model/search.model';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { TripDateCycle } from '../../plan/models/plan.model';


@Injectable({
  providedIn: 'root'
})
export class SearchService {

  public panelBehSubject = new BehaviorSubject<any>(false);

  private _cellSubdata: Subject<any> = new Subject();
  getCellSubdata: any;
  setRowData: any = [];

  constructor(private http: HttpClient) { }

  getSearchView() {
    let options: any = [];
    return this.http.get<ViewSearch>('assets/APIs/search-view.json', options);
  }

  getSearchList(options: any) {
    let headers = options
    return this.http.post<ServiceList>(apiEndpoint.searchService, options);
  }

  getSearchLoads(options: any) {
    let headers = options
    return this.http.post(apiEndpoint.searchLoads, options);
  }

  getRunsheetList(options: any) {
    let headers = options
    return this.http.post<ServiceList>(apiEndpoint.searchRunsheet, options);
  }

  getTripsList(options: any) {
    // return this.http.get<RunsheetList>('assets/APIs/trips.json', options);
    return this.http.post<TripDateCycle>(apiEndpoint.searchPageTrip, options);
  }

  getSearchTrips(options: any) {
    // return this.http.get<RunsheetList>('assets/APIs/trips.json', options);
    return this.http.post<TripDateCycle>(apiEndpoint.searchTrips, options);
  }

  getRunsheetDetailsByID(runsheerId: number) {
    // return this.http.get<RunsheetById>('assets/APIs/runsheet-details-id.json');
    return this.http.get<RunsheetDetails>(apiEndpoint.runsheetUpdate+'/'+runsheerId);
  }

  downLoadCSVService(body: any) {
    return this.http.post(apiEndpoint.setupCsvDownload.services, body, { responseType: 'arraybuffer' });
  }
  
  deleteServices(data: any) {
    return this.http.delete(apiEndpoint.service, data)
  }

  deleteRunsheet(data: any) {
    return this.http.delete(apiEndpoint.runsheets, data)
  }

  private createDemoData(form_data: any): any {
    const demoData: DemoData = {
      payAdviceDate: form_data.payAdviceDate,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
    };

    if (form_data.payAdviceNo !== null) {
      demoData.likePayAdviceId = form_data.payAdviceNo;
    }
    if (form_data.status !== null) {
      demoData.status = form_data.status;
    }
    if (form_data.issuedDate !== null) {
      demoData.issuedDate = form_data.issuedDate;
    }
    if (form_data.companyId !== null) {
      demoData.company = form_data.companyId;
    }

    return demoData;
  }
  /**
   * Here I have to fetch data from Form and send to backend 
   *        Conditions :- Not all filled requried in form so we can send null if not filled. 
   *                      
   */
  //getting table data
  postData(form_data: any): any {
    const demoData = this.createDemoData(form_data);
    return this.http.post<any>(`${apiEndpoint.searchPayAdvice}`, demoData);
  }

  /**
   * Post method for CSV Files
   */
  postCsvDownload(form_data: any) {
    const demoData = this.createDemoData(form_data);
    demoData.selectFields = [];
    console.log('hii csvvvv', demoData)
    // return this.http.post<any>(`${apiEndpoint.payAdvicesCsv}`, demoData  ,{responseType: 'arraybuffer'});  
    return this.http.post(apiEndpoint.payAdvicesCsv, demoData, { responseType: 'arraybuffer' });
  }

  getPayAdviceById(payAdviceId: any) {
    return this.http.get<ApiResponse>(`${apiEndpoint.payAdviceCreation}/${payAdviceId}`)
  }

  getDropDownData() {
    return this.http.get<any>(`${apiEndpoint.contextView}`)
  }



  getInvoiceList(invoiceId: any) {
    return this.http.get<InvoicesAPI>(`${apiEndpoint.invoice}/${invoiceId}`)
  }



  setCellSubData(cellData: any) {
    console.log('cellData >> ', cellData);
    this._cellSubdata.next(cellData);
  }

  postInvoiceData(form_data: any): any {
    let invoiceData: InvoiceDemoData = {
      invoiceDate: null,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      }
    };

    if (form_data.id !== null) {
      invoiceData.id = form_data.id;
    }

    if (form_data.status !== null) {
      invoiceData.status = form_data.status;
    }

    if (form_data.customerID !== null) {
      invoiceData.customerID = form_data.customerID;
    }

    if (form_data.customerGroup !== null) {
      invoiceData.customerGroup = form_data.customerGroup;
    }

    if (form_data.issuedDate !== null) {
      invoiceData.issuedDate = form_data.issuedDate;
    }

    if (form_data.invoiceDate !== null) {
      invoiceData.invoiceDate = form_data.invoiceDate;
    }

    if (form_data.dueDate !== null) {
      invoiceData.dueDate = form_data.dueDate;
    }

    if (form_data.documentType !== null) {
      invoiceData.documentType = form_data.documentType;
    }
    return this.http.post<any>(`${apiEndpoint.searchInvoice}`, invoiceData);
  }

  postLoads(requestParam:any,id:any) {
    return this.http.post<any>(`${apiEndpoint.runsheetLock}/${id}/add-line-by/load`, requestParam);
  }

  

}
