import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TripsEditFormComponent } from './trips-edit-form.component';

describe('TripsEditFormComponent', () => {
  let component: TripsEditFormComponent;
  let fixture: ComponentFixture<TripsEditFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TripsEditFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TripsEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
