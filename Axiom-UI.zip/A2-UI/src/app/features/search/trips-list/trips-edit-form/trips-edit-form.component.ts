import { Component } from '@angular/core';

@Component({
  selector: 'app-trips-edit-form',
  templateUrl: './trips-edit-form.component.html',
  styleUrls: ['./trips-edit-form.component.scss']
})
export class TripsEditFormComponent {

}
