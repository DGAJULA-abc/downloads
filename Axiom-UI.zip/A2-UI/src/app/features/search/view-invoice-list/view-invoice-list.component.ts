import { Component } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-invoice-list',
  templateUrl: './view-invoice-list.component.html',
  styleUrls: ['./view-invoice-list.component.scss']
})
export class ViewInvoiceListComponent {
  viewListDataGrid: any;
  constructor(private invoiceService: SearchService, private router: Router) {

  }
  getViewCellData() {
    this.invoiceService.getCellSubdata.subscribe((viewListData: any) => {
      this.viewListDataGrid = viewListData.data;
      
      console.log("viewListData >", this.viewListDataGrid);
      console.log("viewListData typeOf >", typeof(this.viewListDataGrid));
    }
    )
  }
}
