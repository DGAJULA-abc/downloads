import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityCategoriesComponent } from './activity-categories.component';

describe('ActivityCategoriesComponent', () => {
  let component: ActivityCategoriesComponent;
  let fixture: ComponentFixture<ActivityCategoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActivityCategoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActivityCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
