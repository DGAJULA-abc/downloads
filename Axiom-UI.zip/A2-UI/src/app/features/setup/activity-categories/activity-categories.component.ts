import { Component } from '@angular/core';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { SetupService } from '../service/setup.service';


@Component({
  selector: 'app-activity-categories',
  templateUrl: './activity-categories.component.html',
  styleUrls: ['./activity-categories.component.scss']
})
export class ActivityCategoriesComponent {
  isDivVisible:boolean =false;
  data:any;
  rowData: any[] = [];
   columnDefs: any[] = [
    { cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'category', headerName: 'Category'},
    { field: 'productive', headerName: 'Productive'},
  ];
  id: any;
  category: any;
  constructor(private setupservices:SetupService){
  }

  ngOnInit(): void {
    this.getRowData();
  }

  getRowData() {
    this.setupservices.getactivitycategories().subscribe((result:any)=>{
      this.rowData = result;
      console.log("actcat", result);  
      });
  }

  rightSideForm(id :any){
    this.isDivVisible =true;
    this.id = id;
    this.category = this.findCategoryById(id);
    console.log("jyoti", this.id);
    
  }
  findCategoryById(id: any): string | undefined {
    const foundItem = this.rowData.find(item => item.id === id);
    return foundItem ? foundItem.category : undefined;
  }

  downloadASCsv(){
    const filename = 'Setup.Activity Categories.csv';
    this.setupservices.postCsvDownload().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}
}
