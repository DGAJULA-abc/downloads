import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustmentTypesComponent } from './adjustment-types.component';

describe('AdjustmentTypesComponent', () => {
  let component: AdjustmentTypesComponent;
  let fixture: ComponentFixture<AdjustmentTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjustmentTypesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdjustmentTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
