import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ColDef, GridApi, GridOptions } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { SetupService } from '../service/setup.service';
import { MessageService } from 'primeng/api';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { MatDialog } from '@angular/material/dialog';
import { adjustmentTypes } from '../models/setup.model';


@Component({
  selector: 'app-adjustment-types',
  templateUrl: './adjustment-types.component.html',
  styleUrls: ['./adjustment-types.component.scss'],
  providers: [MessageService],
})
export class AdjustmentTypesComponent implements OnInit {
  zoneForm: FormGroup;
  // rowdata:any;
  isDivVisible:boolean =false;
  // showPanelLeft: boolean = false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;
  isDataAvailable: boolean = false;
  
  updaterowData: any[] = [];
  colDefs: ColDef[] = [
  //  columnDefs: any[] = [
    { cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
    { field: 'adjustmentTypeId', headerName: 'Type', resizable: true, filter: true,floatingFilter: true },
    { field: 'adjustmentTypeDesc', headerName: 'Description', resizable: true, filter: true, floatingFilter: true},
    { field: 'adjustInvoice', headerName: 'Invoice?', resizable: true, filter: true, floatingFilter: true },
    { field: 'adjustPayAdvise', headerName: 'Pay Adv.?', resizable: true, width: 190, filter: true, floatingFilter: true },
    { field: 'negateValue', headerName: 'Negate?', resizable: true, width: 190, filter: true, floatingFilter: true },
    { field: 'showReCharge', headerName: 'Recharge?', resizable: true, width: 190, filter: true, floatingFilter: true },
    { field: 'requiredServiceId', headerName: 'Service?', resizable: true, width: 190, filter: true, floatingFilter: true },
    { field: 'defaultAmt', headerName: 'Default', resizable: true, width: 190, filter: true, floatingFilter: true },
    { field: 'active', headerName: 'Active?', resizable: true, width: 190, filter: true, floatingFilter: true },

  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  
  // data: any;
  // showRunsheetDetail: boolean = true;
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 

  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      adjustmentTypeId:['', Validators.required],
      adjustmentTypeDesc:'',
      adjustInvoice:false,
      adjustPayAdvise:false,
      negateValue:false,
      showReCharge:false,
      requiredServiceId:false,
      defaultAmt:false,
      active:false,
  })
    this.getRowData();
    // this.showPanel();
    // this.reconcileService.reloadGrid.subscribe(res => {
    //   console.log("reload Data> ", res);
    //   this.getRowData();
    //  });
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'adjustmentTypeId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }


  getRowData() {
    this.setupservices.getadjustmentTypes().subscribe((result:any)=>{
    this.rowData = result;
    console.log("adjData", result);  
    });
  }

  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible =true;
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    
    console.log("hi", data);
    this.typeIdSet.add(data.adjustmentTypeId);
   this.idList = Array.from(this.typeIdSet);
    this.sideid = data.siteId;
    this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
    // if (this.idList) {
    //   this.isDataAvailable = true;
    // }
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
      this.setupservices.editadjustmentTypes(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        if(res){
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'Adjustment Types saved',
          });
        }
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.newadjustmentTypes(this.zoneForm.value).subscribe((result:any)=>{
      console.log("xyz",result);
      if(result){
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Adjustment Types saved',
        });
      }
      this.getRowData();
     });
    }
  }


  gridOptions:GridOptions = {

  }

  // postRowData() {
  //    const updateData: any[] = [];
  //   this.gridOptions.api?.forEachNode(node => {
  //       updateData.push(node.data);
  //   });
    
  //   this.setupservices.postadjustmentTypes(updateData).subscribe((result:any)=>{
  //   this.rowData = result;
  //   console.log("adjData", result);  
  //   });
  // }

  // showPanel() {
  
  // }

  downloadASCsv(){
    const filename = 'Setup.Adjustment Types.csv';
    this.setupservices.postadjTypeCsvDownload().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}

// deleteadjustmentType(){

// }
gridAPI!: GridApi<adjustmentTypes>;
selectedRowNode: null | adjustmentTypes;
deleteInvoiceLines(){
  //  console.log("jyotiaaa");
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("jyotivanya", result, this.sideid, this.idList);
    
    // if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deleteadjustmentType(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Adjustment-Types Deleted',
          });
           window.location.reload();
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as adjustmentTypes] });
                            this.selectedRowNode = null;
                          }
                          // this.messageService.add({
                          //   severity: 'success',
                          //   summary: '',
                          //   detail: 'Adjustment Types deleted',
                          // });
        }
      );
    }
  })
}  


}

