import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BreakTypesComponent } from './break-types.component';

describe('BreakTypesComponent', () => {
  let component: BreakTypesComponent;
  let fixture: ComponentFixture<BreakTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BreakTypesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BreakTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
