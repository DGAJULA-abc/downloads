import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { breakTypes } from '../models/setup.model';
import { SetupService } from '../service/setup.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-break-types',
  templateUrl: './break-types.component.html',
  styleUrls: ['./break-types.component.scss'],
  providers: [MessageService],
})
export class BreakTypesComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  // colDefs: ColDef[] = [
  //  columnDefs: any[] = [
  //   { cellRenderer: CellrenderComponent, filter: 'agNumberColumnFilter' },
  //   { field: 'adjustmentTypeId', headerName: 'Type', resizable: true, filter: true,floatingFilter: true },
  //   { field: 'adjustmentTypeDesc', headerName: 'Description', resizable: true, filter: true, floatingFilter: true},
  //   { field: 'adjustInvoice', headerName: 'Invoice?', resizable: true, filter: true, floatingFilter: true },
  //   { field: 'adjustPayAdvise', headerName: 'Pay Adv.?', resizable: true, width: 190, filter: true, floatingFilter: true },
  //   { field: 'negateValue', headerName: 'Negate?', resizable: true, width: 190, filter: true, floatingFilter: true },
  //   { field: 'showReCharge', headerName: 'Recharge?', resizable: true, width: 190, filter: true, floatingFilter: true },
  //   { field: 'requiredServiceId', headerName: 'Service?', resizable: true, width: 190, filter: true, floatingFilter: true },
  //   { field: 'defaultAmt', headerName: 'Default', resizable: true, width: 190, filter: true, floatingFilter: true },
  //   { field: 'active', headerName: 'Active?', resizable: true, width: 190, filter: true, floatingFilter: true },

  // ];

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Type', field:'typeId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Description', field:'description', resizable: true, filter: true, floatingFilter: true },
    // { headerName: 'To', field:'toDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Paid?', field:'breakPaid', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Minutes', field:'minutes', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Min Length', field:'minLength', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Max Length', field:'maxLength', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 190, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  data: any;
  id: any;
  sideid: any;
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder,private messageService: MessageService){

  }
 

  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      typeId:['', Validators.required],
      description:'',
      breakPaid:'',
      minutes:'',
      minLength:'',
      maxLength:'',
      active:false,
  })
    this.getRowData();
    
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'typeId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getbreaktype().subscribe((result:any)=>{
    this.rowData = result;
    console.log("breaktype", result);  
    });
  }
  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible =true;
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    console.log("jyoti", data);
    // this.id = data.id;
    // console.log("getId", this.id);

    this.typeIdSet.add(data.typeId);
   // this.idList.push(this.id);
   this.idList = Array.from(this.typeIdSet);
    this.sideid = data.siteId;
    console.log("getdata", this.idList);
    this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }
  

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
      this.setupservices.editbreaktype(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        if(res){
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'Break Types saved',
          });
        }
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.putbreaktype(this.zoneForm.value).subscribe((result:any)=>{
      console.log("xyz",result);
      if(result){
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Break Types saved',
        });
      }
      this.getRowData();
     });
    }
  }


  downloadASCsv(){
    const filename = 'Setup.Break Types.csv';
    this.setupservices.postbreakTypesCsv().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}

gridAPI!: GridApi<breakTypes>;
selectedRowNode: null | breakTypes;
deleteInvoiceLines(){
  // console.log("jyotiaaa");
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("jyotiaaa", result, this.sideid, this.idList);
    // if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.breakdeleteInvoiceLines(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
           window.location.reload();
          // this.setupservices.postInvoiceLineData(this.formData).
                          //  subscribe((response : any) => {
                          //  console.log('left form');
                          // console.log(response);
                          // this.rowData = response.adjustments;
                          // console.log('hiii',this.rowData);
                          // }
                          // );
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as breakTypes] });
                            this.selectedRowNode = null;
                          }
                          this.messageService.add({
                            severity: 'success',
                            summary: '',
                            detail: 'Break Type deleted',
                          });
        }
      );
    }
  })
}  



}
