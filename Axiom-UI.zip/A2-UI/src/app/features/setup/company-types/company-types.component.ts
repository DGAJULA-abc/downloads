import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { companyTypes } from '../models/setup.model';
import { SetupService } from '../service/setup.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-company-types',
  templateUrl: './company-types.component.html',
  styleUrls: ['./company-types.component.scss'],
  providers: [MessageService],
})
export class CompanyTypesComponent implements OnInit {
  zoneForm: FormGroup;
  isDivVisible: boolean = false;
  rowData: any[];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent, width: 50 },
    {
      headerName: 'Type',
      field: 'companyTypeId',
      resizable: true,
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Description',
      field: 'description',
      resizable: true,
      filter: true,
      floatingFilter: true,
    },
    // { headerName: 'To', field:'toDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    {
      headerName: 'PA Format',
      field: 'paFormat',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Active?',
      field: 'active',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  selectedSiteId: number;

  constructor(
    private setupservices: SetupService,
    public dialog: MatDialog,
    public navbarservices: NavbarService,
    private formBuilder: FormBuilder,
    private messageService: MessageService
  ) {}

  PAFormateget: any[];
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      companyTypeId: ['', Validators.required],
      description: '',
      paFormat: '',
      active: false,
    });
    this.getRowData();
    this.setupservices.getView().subscribe((res: any) => {
      console.log('getview', res);
      this.getpaFormat(res['ref'].payAdviceReportFormats);
      this.PAFormateget = res['ref'].payAdviceReportFormats;
    });
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'companyTypeId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcompanyTypes().subscribe((result: any) => {
      this.rowData = result;
      this.rowData.forEach((row) => {
        if (row.paFormat) {
          const matchingSite = this.PAFormateget.find(
            (site) => site.id === row.paFormat
          );
          if (matchingSite) {
            row.paFormat = matchingSite.name;
            // const paFormate = row.paFormat;
          }
        }
      });

      console.log('data_companyTypes', result);
    });
  }

  Format: any[] = [];
  selectedpaFormat: any;
  filteredpaFormat: any[];

  getpaFormat(Format: any[]) {
    if (Format) {
      Format.forEach((element) => {
        this.Format.push(element.name);
      });
    }
  }
  filterpaFormat(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.Format.length; i++) {
      let country = this.Format[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredpaFormat = filtered;
  }

  isedit: boolean = false;
  isnew: boolean = false;
  // selectedSiteId:any;
  typeIdSet = new Set<number>();
  rightSideForm(data: any) {
    this.isDivVisible = true;
    this.isedit = true;
    this.isnew = false;
    this.data = data;
    console.log('jyoti', data);
    this.typeIdSet.add(data.companyTypeId);
    this.idList = Array.from(this.typeIdSet);
    this.selectedSiteId = this.navbarservices.selectedSiteId;
    this.sideid = data.siteId;
    this.zoneForm.patchValue(data);
    console.log('get_patchValue', data);
  }

  detaSend() {
    this.isDivVisible = true;
    this.isedit = false;
    this.isnew = true;
  }
  closeDialog() {
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit = false;
    this.isnew = false;
  }
  zonedata: any;
  submitdata() {
    console.log(this.zoneForm.value);
    this.zonedata = this.zoneForm.value;
    // this.PAFormateget = res['ref'].payAdviceReportFormats;
    const matchingPAFormat = this.PAFormateget.find(
      (site) => site.name === this.zonedata.paFormat
    );
    if (matchingPAFormat) {
      this.zonedata.paFormat = matchingPAFormat.id;
    }

    if (this.isedit) {
      this.setupservices
        .postcompanyTypes(this.zonedata)
        .subscribe((res: any) => {
          console.log(res);
          if (res) {
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'Company Types saved',
            });
          }
        });
      this.getRowData();
    }
    if (this.isnew) {
      console.log('send', this.zoneForm.value);
      this.setupservices
        .putcompanyTypes(this.zonedata)
        .subscribe((result: any) => {
          console.log('xyz', result);
          if (result) {
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'Company Types saved',
            });
            this.getRowData();
          }
        });
    }
  }

  downloadASCsv() {
    const filename = 'Setup.Company Types.csv';
    this.setupservices.postcompanyTypesCsv().subscribe((res) => {
      this.data = res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
    });
  }

  gridAPI!: GridApi<companyTypes>;
  selectedRowNode: null | companyTypes;
  deleteInvoiceLines() {
    const dialogRef = this.dialog.open(DeletepopupComponent);
    dialogRef.afterClosed().subscribe((result) => {
      console.log('clicked the download button');
      console.log('get_data', result, this.sideid, this.idList);

      if (result == true && this.sideid != null && this.idList != null) {
        this.setupservices
          .deleteCompanyTypes(this.sideid, this.idList)
          .subscribe((result: any) => {
            window.location.reload();
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'Company Type deleted',
            });

            // if(this.selectedRowNode?.siteId){
            //   this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as companyTypes] });

            //   this.selectedRowNode = null;
            // }
          });
      }
    });
  }
}
