import { Component } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { SetupService } from '../service/setup.service';
// import { FormGroup, FormControl } from '@angular/forms';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-companys',
  templateUrl: './companys.component.html',
  styleUrls: ['./companys.component.scss']
})
export class CompanysComponent {
  isDivVisible:boolean =false;
  rowData: any[] = [];
  // isDropdownDisabled: boolean = true;
  isDisabled: boolean = true;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,filter: 'agNumberColumnFilter', width:50},
    { headerName: 'Company', field:'companyId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Vendor Name', field:'companyName', resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Type', field:'companyType', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Contact person', field:'personName', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Default Customer', field:'customerId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 190, filter: true, floatingFilter: true },
    { headerName: 'PA', field:'paFormat', width: 190, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  data: any;
  // selected: any;
  selected: string = '';
  constructor(private setupservices:SetupService){

  }
 
  ngOnInit(): void {
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getcompanys().subscribe((result:any)=>{
    this.rowData = result;
    console.log("ratecharges", result);  
    });
  }

  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    // this.selected = data.companyType;
     console.log("getdata", this.selected);
  }

  downloadASCsv(){
    const filename = 'Setup.Companies.csv';
    this.setupservices.postcompaniesCsv().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}
}


