import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContainerStatusesComponent } from './container-statuses.component';

describe('ContainerStatusesComponent', () => {
  let component: ContainerStatusesComponent;
  let fixture: ComponentFixture<ContainerStatusesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContainerStatusesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContainerStatusesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
