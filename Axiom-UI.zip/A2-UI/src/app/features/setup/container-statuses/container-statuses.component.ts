import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DateFormateComponent } from '../../search/services/date-formate/date-formate.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { containerStatuses } from '../models/setup.model';
import { SetupService } from '../service/setup.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { from } from 'rxjs';
import { MessageService } from 'primeng/api';


@Component({
  selector: 'app-container-statuses',
  templateUrl: './container-statuses.component.html',
  styleUrls: ['./container-statuses.component.scss'],
  providers: [MessageService],
})
export class ContainerStatusesComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;
  selectedSiteId: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellRendarComponent,width:50},
    { headerName: 'Code', field:'id', width:20, resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 50,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, public navbarservices:NavbarService, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      id:['', Validators.required],
  })
    this.getRowData();
    
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'id' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcontainerStatuses().subscribe((result:any)=>{
    this.rowData = result;
    console.log("ratecharges", result);  
    });
  }

  isedit:boolean=false;
  isnew:boolean=false;
  // selectedSiteId:any;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.isedit=true;
    this.isnew=false;
    this.data = data;
    console.log("jyoti", data);
    this.typeIdSet.add(data.id);
   this.idList = Array.from(this.typeIdSet);
    this.selectedSiteId =this.navbarservices.selectedSiteId;
    this.sideid = this.selectedSiteId;
    this.zoneForm.patchValue(data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
      this.setupservices.editcontainerStatuses(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Containers statuses Saved',
        });
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.newcontainerStatuses(this.zoneForm.value).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Containers statuses Saved',
      });
      this.getRowData();
     });
    }
  }

  
  downloadASCsv(){
    const filename = 'Setup.Container Status Codes.csv';
    this.setupservices.postcontainerStatusesCsv().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<containerStatuses>;
selectedRowNode: null | containerStatuses;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("get_data", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deleteContainerStatuses(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Containers statuses Deleted',
          });
           window.location.reload();

           if(this.selectedRowNode?.selectedSiteId){
            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.selectedSiteId as unknown as containerStatuses] });
           
            this.selectedRowNode = null;
          }
          
        }
      );
    }
  })
}  






}
