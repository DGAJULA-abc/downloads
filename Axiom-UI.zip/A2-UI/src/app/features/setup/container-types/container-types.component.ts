import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { containerTypes } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-container-types',
  templateUrl: './container-types.component.html',
  styleUrls: ['./container-types.component.scss'],
  providers: [MessageService],
})
export class ContainerTypesComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Type', field:'containerTypeId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Capacity', field:'capacity', resizable: true, filter: true, floatingFilter: true },
    // { headerName: 'To', field:'toDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Description', field:'description', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 190, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      containerTypeId:['', Validators.required],
      capacity:'',
      description:'',
      active:false,
  })
    this.getRowData();
    
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'containerTypeId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcontainerTypes().subscribe((result:any)=>{
    this.rowData = result;
    console.log("ratecharges", result);  
    });
  }

  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;    
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    console.log("jyoti", data);
    this.typeIdSet.add(data.containerTypeId);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    // this.selectedSiteId =this.navbarservices.selectedSiteId;
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }
  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
    this.setupservices.editcontainerTypes(this.zoneForm.value).subscribe((res:any)=>{
      console.log(res);
      this.messageService.add({
        severity: 'success',
        detail: 'Containers Types Saved',
      });
        });
        this.getRowData();
  }
  if(this.isnew){
    console.log("send", this.zoneForm.value);
   this.setupservices.newcontainerTypes(this.zoneForm.value).subscribe((result:any)=>{
    console.log("xyz",result);
    this.messageService.add({
      severity: 'success',
      detail: 'Containers Types Saved',
    });
    this.getRowData();
   });
  }
}


  downloadASCsv(){
    const filename = 'Setup.Container Types.csv';
    this.setupservices.postcontainerTypesCsv().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<containerTypes>;
selectedRowNode: null | containerTypes;
deleteInvoiceLines(){
  // console.log("jyotiaaa");
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("jyotiaaa", result, this.sideid, this.idList);
    // if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletecontainerTypes(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Containers Types Deleted',
          });
           window.location.reload();
          // this.setupservices.postInvoiceLineData(this.formData).
                          //  subscribe((response : any) => {
                          //  console.log('left form');
                          // console.log(response);
                          // this.rowData = response.adjustments;
                          // console.log('hiii',this.rowData);
                          // }
                          // );
                          // if(this.selectedRowNode?.siteId){
                          //   this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as breakTypes] });
                           
                          //   this.selectedRowNode = null;
                          // }
        }
      );
    }
  })
}  





}



