import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { containers } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-containers',
  templateUrl: './containers.component.html',
  styleUrls: ['./containers.component.scss'],
  providers: [MessageService],
})
export class ContainersComponent implements OnInit{
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Container Code', field:'containerId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Type', field:'containerType', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    // { headerName: 'Description', field:'containerType', resizable: true, filter: true, floatingFilter: true },
    // { headerName: 'To', field:'toDate',cellRenderer:DateFormateComponent, resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Status', field:'containerStatusId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Updated', field:'statusUdpdated', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Company', field:'companyId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Description', field:'containerDesc', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Weight (tonnes)', field:'weightTonnes', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Permanent?', field:'permanent', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Currently On Hire?', field:'onHire', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Location', field:'locationId', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Drop Date', field:'dropDate', width: 190, filter: true, floatingFilter: true },
    { headerName: 'Picked Up', field:'dropDate', width: 190, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  containersget : any[];
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      containerId:['', Validators.required],
      containerType:'',
      containerStatusId:'',
      statusUdpdated:'',
      companyId:'',
      containerDesc:'',
      weightTonnes:'',
      permanent:'',
      onHire:'',
      locationId:'',
      dropDate:'',
      pickupDate:'',
  })
    this.getRowData();
    this.setupservices.getView().subscribe((res:any)=>{
      console.log('getview',res);
      this.getcontainers(res['ref'].containerTypes);
      this.containersget = res['ref'].containerTypes;
      this.getcontainerStatus(res['ref'].containerStatuses);
      this.getcompanys(res['ref'].companys);
      this.getlocation(res['ref'].locations);
      });
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'containerId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcontainers().subscribe((result:any)=>{
    this.rowData = result;

    this.rowData.forEach((row) => {
      if (row.containerType) {
        const matchingSite = this.containersget.find(
          (site) => site.id === row.containerType
        );
        if (matchingSite) {
          row.containerType = matchingSite.containerTypeId;
          // const paFormate = row.paFormat;
        }
      }
    });
    
    console.log("data_companyTypes", result);  
    });
  }

  containersType: any[] = [];
  selectedcontainersType: any;
  filteredcontainersType: any[];

  status: any[] = [];
  selectedstatus: any;
  filteredstatus: any[];

  companys: any[] = [];
  selectedcompanys: any;
  filteredcompanys: any[];

  location: any[] = [];
  selectedlocation: any;
  filteredlocation: any[];

  getcontainers(containersType: any[]) {
    if (containersType) {
      containersType.forEach((element) => {
        this.containersType.push(element.containerTypeId);
      });
    }
  }

  filtercontainersType(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.containersType.length; i++) {
      let country = this.containersType[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcontainersType = filtered;
  }

  getcontainerStatus(status: any[]) {
    if (status) {
      status.forEach((element) => {
        this.status.push(element.id);
      });
    }
  }
  filterstatus(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.status.length; i++) {
      let country = this.status[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredstatus = filtered;
  }

  getcompanys(companys: any[]) {
    if (companys) {
      companys.forEach((element) => {
        this.companys.push(element.companyId);
      });
    }
  }

  filtercompanys(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.companys.length; i++) {
      let country = this.companys[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcompanys = filtered;
  }

  getlocation(location: any[]) {
    if (location) {
      location.forEach((element) => {
        this.location.push(element.locationId);
      });
    }
  }

  filterlocation(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.location.length; i++) {
      let country = this.location[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredlocation = filtered;
  }




  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    console.log("jyoti", data);
    this.typeIdSet.add(data.containerId);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }
  
  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  zonedata:any;
  submitdata(){
    console.log("getdata",this.zoneForm.value);

    this.zonedata= this.zoneForm.value;
    const matchingcontainers = this.containersget.find(
      (site) => site.containerTypeId === this.zonedata.containerType
    );
    if (matchingcontainers) {
      this.zonedata.containerType = matchingcontainers.containerTypeId;
    }


    if(this.isedit){
      this.setupservices.editcontainers(this.zonedata).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Containers Saved',
        });
      
      });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.newcontainers(this.zonedata).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Containers Saved',
      });
      this.getRowData();
     });
    }
  }


  downloadASCsv(){
    const filename = 'Setup.Containers.csv';
    this.setupservices.postCsvContainers().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<containers>;
selectedRowNode: null | containers;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletecontainers(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Containers Deleted',
          });
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as containers] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  



}
