import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurfewWindowsComponent } from './curfew-windows.component';

describe('CurfewWindowsComponent', () => {
  let component: CurfewWindowsComponent;
  let fixture: ComponentFixture<CurfewWindowsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurfewWindowsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CurfewWindowsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
