import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { curfewwindows } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-curfew-windows',
  templateUrl: './curfew-windows.component.html',
  styleUrls: ['./curfew-windows.component.scss'],
  providers: [MessageService],
})
export class CurfewWindowsComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  customrowData = [
    { windowDay: 0 },
    { windowDay: 1 },
    { windowDay: 2 },
    { windowDay: 3 },
    { windowDay: 4 },
    { windowDay: 5 },
    { windowDay: 6 }, 
    { windowDay: 7 }, 
    // Add more day values as needed
  ];

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Day', field:'windowDay', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true, 
    valueFormatter: this.customValueFormatter},
    { headerName: 'Start', field:'startTime', width: 100, filter: true, floatingFilter: true },
    { headerName: 'End Day', field:'endDay', width: 100, filter: true, floatingFilter: true, valueFormatter: this.customValueFormatter },
    { headerName: 'End', field:'endTime', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Location', field:'locationId', width: 100, filter: true, floatingFilter: true },
  ];

  

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      windowDay:'',
      startTime: '',
      endDay:'',
      endTime:'',
      locationId:''
  })
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getcurfewWindows().subscribe((result:any)=>{
    this.rowData = result;
    console.log("data_companyTypes", result);  
    });
  }

  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.isedit=true;
    this.isnew=false;
    this.data = data;
    console.log("displaydata", data);
    this.typeIdSet.add(data.id);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
    this.setupservices.editcurfewWindows(this.zoneForm.value).subscribe((res:any)=>{
      console.log(res);
      this.messageService.add({
        severity: 'success',
        detail: 'Curfew Saved',
      });
        });
        this.getRowData();
  }
  if(this.isnew){
    console.log("send", this.zoneForm.value);
   this.setupservices.newcurfewWindows(this.zoneForm.value).subscribe((result:any)=>{
    console.log("xyz",result);
    this.messageService.add({
      severity: 'success',
      detail: 'Curfew Saved',
    });
    this.getRowData();
   });
  }
}

  customValueFormatter(params: { value: any; }) {let windowDay = params.value; // Numeric day value
    // let windowDay;

    switch (windowDay) {
      case 0:
        windowDay = 'Same Day';
        break;
        case 1:
        windowDay = 'Sunday';
        break;
      case 2:
        windowDay = 'Monday';
        break;
      case 3:
        windowDay = 'Tuesday';
        break;
      case 4:
        windowDay = 'Wednesday';
        break;
      case 5:
        windowDay = 'Thursday';
        break;
      case 6:
        windowDay = 'Friday';
        break;
      case 7:
        windowDay = 'Saturday';
        break;
      default:
        windowDay = 'Unknown'; // Handle unknown values
    }

    return windowDay;
  }

  downloadASCsv(){
    const filename = 'Setup.Curfew Window.csv';
    this.setupservices.postCsvCurfewWindows().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}



gridAPI!: GridApi<curfewwindows>;
selectedRowNode: null | curfewwindows;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletecurfewwindows(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Curfew Deleted',
          });
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as curfewwindows] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  



}
