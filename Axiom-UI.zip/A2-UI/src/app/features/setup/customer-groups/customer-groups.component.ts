import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { customerGroups } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-customer-groups',
  templateUrl: './customer-groups.component.html',
  styleUrls: ['./customer-groups.component.scss'],
  providers: [MessageService],
})
export class CustomerGroupsComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Code', field:'groupId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Name', field:'groupName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Invoice', field:'invFormat', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Credit Note', field:'cnFormat', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 100, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
  invFormatget : any[];
  cnFormatget : any[];
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      groupId:['', Validators.required],
      groupName:'',
      invFormat:'',
      cnFormat:'',
      active:false,
  })
    this.getRowData();
    this.setupservices.getView().subscribe((res:any)=>{
      console.log('getview',res);
      this.getinvoiceReport(res['ref'].invoiceReportFormats);
      this.invFormatget = res['ref'].invoiceReportFormats;

      this.getcnFormat(res['ref'].creditNoteReportFormats);
      this.cnFormatget = res['ref'].creditNoteReportFormats;
      // this.gethomelocation(res['ref'].homeLocations);
  
  
      });
    
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'groupId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcustomerGroups().subscribe((result:any)=>{
    this.rowData = result;
    this.rowData.forEach((row) => {
      if (row.invFormat) {
        const matchingSite = this.invFormatget.find(
          (site) => site.id === row.invFormat
        );
        if (matchingSite) {
          row.invFormat = matchingSite.name;
        }
      }
    });

    this.rowData.forEach((row) => {
      if (row.cnFormat) {
        const matchingSite = this.cnFormatget.find(
          (site) => site.id === row.cnFormat
        );
        if (matchingSite) {
          row.cnFormat = matchingSite.name;
        }
      }
    });

    console.log("get_data", result);  
    });
  }

  invoiceReport: any[] = [];
  selectedInvoiceReport: any;
  filteredInvoiceReport: any[];

  cnFormate: any[] = [];
  selectedcnFormate: any;
  filteredcnFormate: any[];
  getinvoiceReport(invoiceReport: any[]) {
    if (invoiceReport) {
      invoiceReport.forEach((element) => {
        this.invoiceReport.push(element.name);
      });
    }
  }
  filterinvoiceReport(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.invoiceReport.length; i++) {
      let country = this.invoiceReport[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredInvoiceReport = filtered;
  }



  getcnFormat(cnFormate: any[]) {
    if (cnFormate) {
      cnFormate.forEach((element) => {
        this.cnFormate.push(element.name);
      });
    }
  }
  filtercnFormate(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.cnFormate.length; i++) {
      let country = this.cnFormate[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcnFormate = filtered;
  }


  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.isedit=true;
    this.isnew=false;
    this.data = data;
    console.log("displaydata", data);
    this.typeIdSet.add(data.groupId);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  invoicedata:any;
  cnFdata:any;
  submitdata(){
    console.log(this.zoneForm.value);
    this.invoicedata= this.zoneForm.value;
    // this.PAFormateget = res['ref'].payAdviceReportFormats;
    const matchinginvoiceFormat = this.invFormatget.find(
      (site) => site.name === this.invoicedata.invFormat
    );
    if (matchinginvoiceFormat) {
      this.invoicedata.invFormat = matchinginvoiceFormat.id;
    }


    this.invoicedata= this.zoneForm.value;
    // this.PAFormateget = res['ref'].payAdviceReportFormats;
    const matchingcnFormat = this.cnFormatget.find(
      (site) => site.name === this.invoicedata.cnFormat
    );
    if (matchingcnFormat) {
      this.invoicedata.cnFormat = matchingcnFormat.id;
    }


    if(this.isedit){
      this.setupservices.postcustomerGroups(this.invoicedata).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Customer-groups Saved',
        });
  
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.putcustomerGroups(this.invoicedata).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Customer-groups Saved',
      });
      this.getRowData();
     });
    }
  }

  downloadASCsv(){
    const filename = 'Setup.Customer Groups.csv';
    this.setupservices.postCustomerGroups().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<customerGroups>;
selectedRowNode: null | customerGroups;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletecustomerGroups(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Customer-groups Deleted',
          });
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as customerGroups] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  





}
