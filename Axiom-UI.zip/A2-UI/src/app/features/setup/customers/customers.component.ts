import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { customers } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
  providers: [MessageService],
})
export class CustomersComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Customer Code', field:'customerId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Internal?', field:'internalCustomer', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Name', field:'customerName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Group', field:'groupId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Group Name', field:'groupName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Debtor Code', field:'debtorCode', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Contact Details', field:'personContactName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Billing Details', field:'personBillingName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'GL Branch Code (must be 5 chars)', field:'glCodeBranch', width: 100, filter: true, floatingFilter: true },
    { headerName: 'ABN', field:'abn', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Apply GST?', field:'applyGST', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#1 Name', field:'customBillingName1', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#1 Value', field:'customBillingValue1', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#2 Name', field:'customBillingName2', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#2 Value', field:'customBillingValue2', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#3 Name', field:'customBillingName3', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Custom#3 Value', field:'customBillingValue3', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Also include in billing reference:', field:'invoiceRemarksModeName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Active Customer?', field:'active', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Default Invoice Format', field:'invFormatName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Default Credit Note Format', field:'cnFormatName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Schedule Entry Form', field:'scheduleEntryForm', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Schedule Import Function', field:'scheduledImportFunction', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Customer Pick/Drop?', field:'allowContPickupDrop', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unique Load No?', field:'uniqueLoadNo', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Numeric Load No?', field:'numericLoadNo', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Minimum Length of Load No', field:'loadNoMinLen', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Maximum Lenght of Load No', field:'loadNoMaxLen', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 1', field:'invUnit1', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 2', field:'invUnit2', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 3', field:'invUnit3', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 4', field:'invUnit4', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 5', field:'invUnit5', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 6', field:'invUnit6', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 7', field:'invUnit7', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Unit 8', field:'invUnit8', width: 100, filter: true, floatingFilter: true },
    
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      customerId:['', Validators.required],
      
      customerName: '',
      personIdContact: '',
      personContactName: '',
      personIdBilling: '',
      personBillingName: '',
      groupId: '',
      groupName: '',
      invFormat: '',
      invFormatName: '',
      applyGST: false,
      internalCustomer: false,
      allowContPickupDrop: false,
      fuelLevyChargeRate: '',
      fuelLevyPayRate: '',
      scheduleEntryForm: '',
      scheduledImportFunction: '',
      uniqueLoadNo: false,
      numericLoadNo: false,
      loadNoMinLen: '',
      loadNoMaxLen: '',
      glCodeBranch: ['', Validators.required],
      abn: '',
      debtorCode: '',
      active: false,
      cnFormat: '',
      cnFormatName: '',
      invUnit1:'',
      invUnit2:'',
      invUnit3: '',
      invUnit4:'',
      invUnit5: '',
      invUnit6:'',
      invUnit7: '',
      invUnit8:'',
      customBillingName1: '',
      customBillingName2: '',
      customBillingName3: '',
      customBillingValue1: '',
      customBillingValue2:'',
      customBillingValue3:'',
      invoiceRemarksMode:'',
      invoiceRemarksModeName: '',
      
  })
    this.getRowData();
    this.setupservices.getView().subscribe((res:any)=>{
      console.log('getview',res);
      this.getgroup(res['ref'].customerGroups);
      this.getinvoice(res['ref'].invoiceRemarksModes);
      this.getinvoiceFr(res['ref'].invoiceReportFormats);
      this.getcreditNoteFr(res['ref'].creditNoteReportFormats);
      // this.getEntryFrom(res['ref'].creditNoteReportFormats);
  
  
      });
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'customerId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
     if (controlName === 'glCodeBranch' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    // if (controlName === 'destinationCode' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    // if (controlName === 'originSite' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    // if (controlName === 'serviceType' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    // if (controlName === 'axLoadType' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    // if (controlName === 'customerId' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.getcustomer().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  group: any[] = [];
  selectedgroup: any;
  filteredgroup: any[];

  invoice: any[] = [];
  selectedinvoice: any;
  filteredinvoice: any[];

  invoiceFr: any[] = [];
  selectedinvoiceFr: any;
  filteredinvoiceFr: any[];

  creditnoteFr: any[] = [];
  selectedcreditnoteFr: any;
  filteredcreditnoteFr: any[];

  getcreditNoteFr(creditnoteFr: any[]) {
    if (creditnoteFr) {
      creditnoteFr.forEach((element) => {
        this.creditnoteFr.push(element.name);
      });
    }
  }
  filtercreditnoteFr(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.creditnoteFr.length; i++) {
      let country = this.creditnoteFr[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcreditnoteFr = filtered;
  }

  getinvoiceFr(invoiceFr: any[]) {
    if (invoiceFr) {
      invoiceFr.forEach((element) => {
        this.invoiceFr.push(element.name);
      });
    }
  }
  filterinvoiceFr(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.invoiceFr.length; i++) {
      let country = this.invoiceFr[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredinvoiceFr = filtered;
  }


  getinvoice(invoice: any[]) {
    if (invoice) {
      invoice.forEach((element) => {
        this.invoice.push(element.name);
      });
    }
  }
  filterinvoice(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.invoice.length; i++) {
      let country = this.invoice[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredinvoice = filtered;
  }


  getgroup(group: any[]) {
    if (group) {
      group.forEach((element) => {
        this.group.push(element.groupId);
      });
    }
  }
  filtergroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.group.length; i++) {
      let country = this.group[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredgroup = filtered;
  }


  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    console.log("displaydata", data);
    this.typeIdSet.add(data.workGroupId);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
      this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }

  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
      this.setupservices.editcustomers(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Customer Saved',
        });
  
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.putcustomers (this.zoneForm.value).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Customer Saved',
      });

      this.getRowData();
     });
    }
  }
  downloadASCsv(){
    const filename = 'Setup.Customers.csv';
    this.setupservices.postCustomers().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}

gridAPI!: GridApi<customers>;
selectedRowNode: null | customers;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletecustomers(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Customer Deleted',
          });
    
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as customers] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  




}
