import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletionCompletionLoggingComponent } from './deletion-completion-logging.component';

describe('DeletionCompletionLoggingComponent', () => {
  let component: DeletionCompletionLoggingComponent;
  let fixture: ComponentFixture<DeletionCompletionLoggingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletionCompletionLoggingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeletionCompletionLoggingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
