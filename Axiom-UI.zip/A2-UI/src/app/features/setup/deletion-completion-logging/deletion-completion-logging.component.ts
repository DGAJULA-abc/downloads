import { Component } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-deletion-completion-logging',
  templateUrl: './deletion-completion-logging.component.html',
  styleUrls: ['./deletion-completion-logging.component.scss']
})
export class DeletionCompletionLoggingComponent {
  isDivVisible:boolean =false;
  rowData: any[] = [];

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Time', field:'eventTime', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Event', field:'eventDesc', width: 100, filter: true, floatingFilter: true},
    { headerName: 'User', field:'userId', width: 100, filter: true, floatingFilter: true},
    { headerName: 'Text', field:'eventText', width: 100, filter: true, floatingFilter: true},
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  constructor(private setupservices:SetupService){

  }
 
  ngOnInit(): void {
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getDeletionCompletionLogging().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  rightSideForm(id:any) {
    this.isDivVisible = true;
    console.log("jyoti", id);
  }

}
