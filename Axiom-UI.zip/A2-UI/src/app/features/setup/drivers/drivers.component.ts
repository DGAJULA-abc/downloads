import { Component } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DateFormateComponent } from '../../search/services/date-formate/date-formate.component';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-drivers',
  templateUrl: './drivers.component.html',
  styleUrls: ['./drivers.component.scss']
})
export class DriversComponent {
  isDivVisible:boolean =false;
  isDisabled:boolean=true;
  rowData: any[] = [];

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'First Name', field:'firstName', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Last Name', field:'surname', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Nickname', field:'employeeName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'PDT Login Code', field:'mdtCode', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Group?', field:'groupDriver', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Company Code', field:'companyId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Company Name', field:'vendorName', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Truck', field:'truckId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Trailer', field:'trailerId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Pay Basis', field:'payBasisId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Home Location', field:'homeLocationId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Mobile', field:'mobile', width: 100, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  data: any;
  constructor(private setupservices:SetupService){

  }
 
  ngOnInit(): void {
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getsetupDrivers().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  closeDialog(){
    this.isDivVisible = false;
  }
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    console.log("jyoti", data);
  }

  downloadASCsv(){
    const filename = 'Setup.Drivers.csv';
    this.setupservices.postCsvDrivers().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


// deleteInvoiceLines(){
//   const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
//   dialogRef.afterClosed().subscribe(result =>{
//     console.log("clicked the download button");
//     if (this.canWrite() && this.isAbleToDeleteInvoiceLines()){
//       this.service.deleteInvoiceLines(this.invoiceLines.id).subscribe(
//         (result: any) =>{
//           this.service.postInvoiceLineData(this.formData).
//                            subscribe((response : any) => {
//                            console.log('left form');
//                           console.log(response);
//                           this.rowData = response.adjustments;
//                           console.log('hiii',this.rowData);
//                           }
//                           );
//         }
//       );
//     }
//   })
// }  



}
