import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuplicateChargePayLinesComponent } from './duplicate-charge-pay-lines.component';

describe('DuplicateChargePayLinesComponent', () => {
  let component: DuplicateChargePayLinesComponent;
  let fixture: ComponentFixture<DuplicateChargePayLinesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DuplicateChargePayLinesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuplicateChargePayLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
