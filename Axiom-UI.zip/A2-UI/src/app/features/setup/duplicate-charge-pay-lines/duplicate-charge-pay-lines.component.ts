import { Component } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-duplicate-charge-pay-lines',
  templateUrl: './duplicate-charge-pay-lines.component.html',
  styleUrls: ['./duplicate-charge-pay-lines.component.scss']
})
export class DuplicateChargePayLinesComponent {
  isDivVisible:boolean =false;
  rowData: any[] = [];

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'ID', field:'', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Type', field:'', width: 100, filter: true, floatingFilter: true},
    { headerName: 'Service', field:'', width: 100, filter: true, floatingFilter: true},
    { headerName: 'Driver', field:'', width: 100, filter: true, floatingFilter: true},
    { headerName: 'Effect.Date', field:'', width: 100, filter: true, floatingFilter: true},
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  constructor(private setupservices:SetupService){

  }
 
  ngOnInit(): void {
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getDuplicateChargeLines().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  rightSideForm(id:any) {
    this.isDivVisible = true;
    console.log("jyoti", id);
  }

}
