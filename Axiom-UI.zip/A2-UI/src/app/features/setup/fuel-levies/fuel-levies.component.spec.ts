import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FuelLeviesComponent } from './fuel-levies.component';

describe('FuelLeviesComponent', () => {
  let component: FuelLeviesComponent;
  let fixture: ComponentFixture<FuelLeviesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FuelLeviesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FuelLeviesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
