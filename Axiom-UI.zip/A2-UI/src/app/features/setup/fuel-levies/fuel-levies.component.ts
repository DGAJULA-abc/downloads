import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DateFormateComponent } from '../../search/services/date-formate/date-formate.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { fuelLevies } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-fuel-levies',
  templateUrl: './fuel-levies.component.html',
  styleUrls: ['./fuel-levies.component.scss'],
  providers: [MessageService],
})
export class FuelLeviesComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Order', field:'id', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Levy %(Charge)', field:'fuelLevyCharge', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Levy %(Pay)', field:'fuelLevyPay', width: 100, filter: true, floatingFilter: true },
    { headerName: 'From', field:'fromDate', width: 100, cellRenderer:DateFormateComponent, filter: true, floatingFilter: true },
    { headerName: 'To', field:'toDate', width: 100, cellRenderer:DateFormateComponent, filter: true, floatingFilter: true },
    { headerName: 'Day of Week', field:'dayOfWeek', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Customer', field:'customerId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Service Type', field:'serviceTypeId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Pickup Zone (Charge)', field:'zoneChargeIdPickup', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Drop Zone (Charge)', field:'zoneChargeIdDrop', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Company Type', field:'companyTypeId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Company', field:'companyId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Pickup Zone (Pay)', field:'zonePayIdPickup', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Drop Zone (Pay)', field:'zonePayIdDrop', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Truck Type', field:'truckTypeId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Pickup Location', field:'locationIdPickup', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Drop Location', field:'locationIdDrop', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Load Type', field:'loadTypeId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Pickup Route', field:'routeIdPickup', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Drop Route', field:'routeIdDrop', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Customer Group', field:'customerGroupId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Origin Site', field:'originSite', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Origin Location', field:'originLoc', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Destingation Site', field:'destinationSite', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Destination Location', field:'destinationLoc', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Wharf', field:'locationIdWharf', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Depot', field:'locationIdDepot', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Customer Site', field:'locationIdCustomer', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Dehire Park', field:'locationIdPark', width: 100, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  multiLegSitesget : any[];
  ngOnInit(): void {
    this.setupservices.getView().subscribe((res:any)=>{
      console.log('getview',res);
       this.getcustomers(res['ref'].customers);
       this.getserviceTypes(res['ref'].serviceTypes);
       this.getzoneCharges(res['ref'].zoneCharges);
       this.getcompanyTypes(res['ref'].companyTypes);
       this.getcompanys(res['ref'].companys);
       this.getzonePays(res['ref'].zonePays);
       this.gettruckTypes(res['ref'].truckTypes);
       this.getlocations(res['ref'].locations);
       this.getloadTypes(res['ref'].loadTypes);
       this.getroutes(res['ref'].routes);
       this.getcustomerGroups(res['ref'].customerGroups);
       this.getmultiLegSites(res['ref'].multiLegSites);
      this.multiLegSitesget = res['ref'].multiLegSites;
      this.getWhrafdata(res['ref'].locations);
      this.getDeportdata(res['ref'].locations);
      this.getCustomerdata(res['ref'].locations);
      this.getParkdata(res['ref'].locations);
    });  

    this.zoneForm = this.formBuilder.group({
      siteId:'',
      id:'',
      originalId:['', Validators.required],
      deletedOriginalId:'',
      fuelLevyCharge:'',
      fuelLevyPay:'',
      fromDate:'',
      toDate:'',
      dayOfWeek:'',
      customerId:'',
      serviceTypeId:'',
      zoneChargeIdPickup:'',
      zoneChargeIdDrop:'',
      companyTypeId:'',
      companyId:'',
      zonePayIdPickup:'',
      zonePayIdDrop:'',
      truckTypeId:'',
      locationIdPickup:'',
      locationIdDrop:'',
      loadTypeId:'',
      routeIdPickup:'',
      routeIdDrop:'',
      customerGroupId:'',
      originSite:'',
      originLoc:'',
      destinationSite:'',
      destinationLoc:'',
      locationIdWharf:'',
      locationIdDepot:'',
      locationIdCustomer:'',
      locationIdPark:'',
      
  })
    this.getRowData();
  }

  location:any[];
//locationdata:any[]=[];
whraf:any[]=[];
getWhrafdata(location:any){
  this.location=location;

  if (this.location) {
    this.location.forEach((ele: any) => {
      if(ele.locationTypeId==='WHARF'){
        this.whraf.push(ele.locationId);
      }
          });
          console.log("location", this.location)
      console.log("whraf",this.whraf);
  }
}

// location:any[];
depot:any[]=[];
getDeportdata(location:any){
  this.location=location;

  if (this.location) {
    this.location.forEach((ele: any) => {
      if(ele.locationTypeId==='DEPOT'){
        this.depot.push(ele.locationId);
      }
          });
          console.log("location", this.location)
      console.log("depot",this.depot);
  }
}

customer:any[]=[];
getCustomerdata(location:any){
  this.location=location;

  if (this.location) {
    this.location.forEach((ele: any) => {
      if(ele.locationTypeId==='CUSTOMER'){
        this.customer.push(ele.locationId);
      }
          });
          console.log("location", this.location)
      console.log("customer",this.customer);
  }
}

park:any[]=[];
getParkdata(location:any){
  this.location=location;

  if (this.location) {
    this.location.forEach((ele: any) => {
      if(ele.locationTypeId==='PARK'){
        this.park.push(ele.locationId);
      }
          });
          console.log("location", this.location)
      console.log("park",this.park);
  }
}


getTooltipContent(controlName: string): string {
  const control = this.zoneForm.get(controlName);
  if (controlName === 'originalId' && control?.value === '') {
    return 'This Value cannot be Empty';
  }
  
  return '';
}

isControlEmpty(controlName: string): boolean {
  const control = this.zoneForm.get(controlName);
  return control ? control.value === '' : false;
}


  getRowData() {
    this.setupservices.getfuelLevies().subscribe((result:any)=>{
    this.rowData = result;
    this.rowData.forEach((row) => {
      if (row.originSite) {
        const matchingSite = this.multiLegSitesget.find(
          (site) => site.id === row.originSite
        );
        if (matchingSite) {
          row.originSite = matchingSite.description;
          // const paFormate = row.paFormat;
        }
      }
    });
    console.log("get_data", result);  
    });
  }

  multiLegSites: any[] = [];
  selectedmultiLegSites: any;
  filteredmultiLegSites: any[];

  getmultiLegSites(multiLegSites: any[]) {
    if (multiLegSites) {
      multiLegSites.forEach((element) => {
        this.multiLegSites.push(element.description);
      });
    }
  }
  filtermultiLegSites(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.multiLegSites.length; i++) {
      let country = this.multiLegSites[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredmultiLegSites = filtered;
  }

  customers: any[] = [];
  selectedcustomers: any;
  filteredcustomers: any[];

  serviceTypes: any[] = [];
  selectedserviceTypes: any;
  filteredserviceTypes: any[];

  zoneCharges: any[] = [];
  selectedzoneCharges: any;
  filteredzoneCharges: any[];

  companyTypes: any[] = [];
  selectedcompanyTypes: any;
  filteredcompanyTypes: any[];

  companys: any[] = [];
  selectedcompanys: any;
  filteredcompanys: any[];

  zonePays: any[] = [];
  selectedzonePays: any;
  filteredzonePays: any[];

  truckTypes: any[] = [];
  selectedtruckTypes: any;
  filteredtruckTypes: any[];

  locations: any[] = [];
  selectedlocations: any;
  filteredlocations: any[];

  loadTypes: any[] = [];
  selectedloadTypes: any;
  filteredloadTypes: any[];

  routes: any[] = [];
  selectedroutes: any;
  filteredroutes: any[];

  customerGroups: any[] = [];
  selectedcustomerGroups: any;
  filteredcustomerGroups: any[];

  getroutes(routes: any[]) {
    if (routes) {
      routes.forEach((element) => {
        this.routes.push(element.routeId);
      });
    }
  }
  filterroutes(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.routes.length; i++) {
      let country = this.routes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredroutes = filtered;
  }

  getcustomerGroups(customerGroups: any[]) {
    if (customerGroups) {
      customerGroups.forEach((element) => {
        this.customerGroups.push(element.groupId);
      });
    }
  }
  filtercustomerGroups(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.customerGroups.length; i++) {
      let country = this.customerGroups[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcustomerGroups = filtered;
  }

  gettruckTypes(truckTypes: any[]) {
    if (truckTypes) {
      truckTypes.forEach((element) => {
        this.truckTypes.push(element.truckTypeId);
      });
    }
  }
  filtertruckTypes(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.truckTypes.length; i++) {
      let country = this.truckTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredtruckTypes = filtered;
  }

  getlocations(locations: any[]) {
    if (locations) {
      locations.forEach((element) => {
        this.locations.push(element.locationId);
      });
    }
  }
  filterlocations(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.locations.length; i++) {
      let country = this.locations[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredlocations = filtered;
  }

  getloadTypes(loadTypes: any[]) {
    if (loadTypes) {
      loadTypes.forEach((element) => {
        this.loadTypes.push(element.loadTypeId);
      });
    }
  }
  filterloadTypes(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.loadTypes.length; i++) {
      let country = this.loadTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredloadTypes = filtered;
  }

  getcompanyTypes(companyTypes: any[]) {
    if (companyTypes) {
      companyTypes.forEach((element) => {
        this.companyTypes.push(element.companyTypeId);
      });
    }
  }
  filtercompanyTypes(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.companyTypes.length; i++) {
      let country = this.companyTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcompanyTypes = filtered;
  }

  getcompanys(companys: any[]) {
    if (companys) {
      companys.forEach((element) => {
        this.companys.push(element.companyId);
      });
    }
  }
  filtercompanys(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.companys.length; i++) {
      let country = this.companys[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcompanys = filtered;
  }

  getzonePays(zonePays: any[]) {
    if (zonePays) {
      zonePays.forEach((element) => {
        this.zonePays.push(element.id);
      });
    }
  }
  filterzonePays(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.zonePays.length; i++) {
      let country = this.zonePays[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredzonePays = filtered;
  }

  getcustomers(customers: any[]) {
    if (customers) {
      customers.forEach((element) => {
        this.customers.push(element.customerId);
      });
    }
  }
  filtercustomers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredcustomers = filtered;
  }

  getserviceTypes(serviceTypes: any[]) {
    if (serviceTypes) {
      serviceTypes.forEach((element) => {
        this.serviceTypes.push(element.serviceTypeId);
      });
    }
  }
  filterserviceTypes(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.serviceTypes.length; i++) {
      let country = this.serviceTypes[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredserviceTypes = filtered;
  }

  getzoneCharges(zoneCharges: any[]) {
    if (zoneCharges) {
      zoneCharges.forEach((element) => {
        this.zoneCharges.push(element.id);
      });
    }
  }
  filterzoneCharges(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.zoneCharges.length; i++) {
      let country = this.zoneCharges[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredzoneCharges = filtered;
  }

  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    this.isedit=true;
    this.isnew=false;
    console.log("displaydata", data);
    this.typeIdSet.add(data.id);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }
  zonedata:any;
  submitdata(){
    console.log(this.zoneForm.value);
    this.zonedata= this.zoneForm.value;
    // this.PAFormateget = res['ref'].payAdviceReportFormats;
    const matchingmultiLegSites = this.multiLegSitesget.find(
      (site) => site.description === this.zonedata.originSite
    );
    if (matchingmultiLegSites) {
      this.zonedata.originSite = matchingmultiLegSites.id;
    }

    if(this.isedit){
      this.setupservices.editfuelLevies(this.zonedata).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Fuel levies Saved',
        });
          });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.newfuelLevies(this.zonedata).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Fuel levies Saved',
      });
      this.getRowData();
     });
    }
  }


  downloadASCsv(){
    const filename = 'Setup.Fuel Levy Decision Table.csv';
    this.setupservices.postCsvfuelLevies().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<fuelLevies>;
selectedRowNode: null | fuelLevies;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletefuelLevies(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Fuel levies Deleted',
          });
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as fuelLevies] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  


}
