import { Component,OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { DeletepopupComponent } from '../deletepopup/deletepopup.component';
import { homeloc } from '../models/setup.model';
import { SetupService } from '../service/setup.service';

@Component({
  selector: 'app-home-locations',
  templateUrl: './home-locations.component.html',
  styleUrls: ['./home-locations.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None,
})
export class HomeLocationsComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  idList: number[] = [];
  data: any;
  sideid: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Identifier', field:'homeLocationId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Description', field:'homeLocationDesc', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Active?', field:'active', width: 100, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, public dialog: MatDialog, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:999,
      homeLocationId:['', Validators.required],
      homeLocationDesc:'',
      active:false,
  })
    this.getRowData();
    this.setupservices.getView().subscribe((res:any)=>{
      console.log('getview',res);
      this.getlocation(res['ref'].locations);
      // this.gethomelocation(res['ref'].homeLocations);
    });
    
  }

  getTooltipContent(controlName: string): string {
    const control = this.zoneForm.get(controlName);
    if (controlName === 'homeLocationId' && control?.value === '') {
      return 'This Value cannot be Empty';
    }
    // if (controlName === 'locationTo' && control?.value === '') {
    //   return 'This Value cannot be Empty';
    // }
    
    return '';
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.zoneForm.get(controlName);
    return control ? control.value === '' : false;
  }

  getRowData() {
    this.setupservices.gethomeLocation().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  location: any[] = [];
  selectedLocation: any;
  filteredLocation: any[];

  getlocation(location: any[]) {
    if (location) {
      location.forEach((element) => {
        this.location.push(element.locationId);
      });
    }
  }
  filterLocation(event: any) {
    let filtered: any[] = [];
    let query = event.query;
 
    for (let i = 0; i < this.location.length; i++) {
      let country = this.location[i];
      if (country.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredLocation = filtered;
  }


  isedit:boolean=false;
  isnew:boolean=false;
  typeIdSet = new Set<number>();
  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.isedit=true;
    this.isnew=false;
    this.data = data;
    console.log("displaydata", data);
    this.typeIdSet.add(data.homeLocationId);
   this.idList = Array.from(this.typeIdSet);
   this.sideid = data.siteId;
   this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  detaSend(){
    this.isDivVisible = true;
    this.isedit=false;
    this.isnew=true;
  }
  closeDialog(){
    this.isDivVisible = false;
    this.zoneForm.reset();
    this.isedit=false;
    this.isnew=false;
  }
  submitdata(){
    console.log(this.zoneForm.value);
    if(this.isedit){
      this.setupservices.posthomelocations(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        // debugger
        this.messageService.add({
          severity: 'success',
          detail: 'Home Location saved',
        });
        // res.forEach((updatedRow: any) => {
        //   debugger
        //   this.gridAPI.applyTransaction({ update: [updatedRow] });  
        // });
         });
          this.getRowData();
    }
    if(this.isnew){
      console.log("send", this.zoneForm.value);
     this.setupservices.puthomelocations(this.zoneForm.value).subscribe((result:any)=>{
      console.log("xyz",result);
      this.messageService.add({
        severity: 'success',
        detail: 'Home Location saved',
      });
      // if (result) {
      //   this.gridAPI.applyTransaction({ add: result });
      //   this.messageService.add({
      //     severity: 'success',
      //     detail: 'Location saved',
      //   });
      // }
      this.getRowData();
     });
    }
  }

  downloadASCsv(){
    const filename = 'Setup.Home Location.csv';
    this.setupservices.postCsvHomeLocations().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}


gridAPI!: GridApi<homeloc>;
selectedRowNode: null | homeloc;
deleteInvoiceLines(){
  const dialogRef = this.dialog.open(DeletepopupComponent);
  dialogRef.afterClosed().subscribe(result =>{
    console.log("clicked the download button");
    console.log("deleteApi", result, this.sideid, this.idList);
    
      if(result== true && this.sideid!=null && this.idList!=null){
      this.setupservices.deletehomeloc(this.sideid, this.idList).subscribe(
   
        (result: any) =>{
          this.messageService.add({
            severity: 'success',
            detail: 'Location details deleted',
          });
           window.location.reload();
          
                          if(this.selectedRowNode?.siteId){
                            this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.siteId as unknown as homeloc] });
                           
                            this.selectedRowNode = null;
                          }
        }
      );
    }
  })
}  

}
