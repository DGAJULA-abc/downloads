import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyGensComponent } from './key-gens.component';

describe('KeyGensComponent', () => {
  let component: KeyGensComponent;
  let fixture: ComponentFixture<KeyGensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeyGensComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KeyGensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
