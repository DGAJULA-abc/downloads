import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ColDef } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { CellRendarComponent } from '../../search/services/cell-rendar/cell-rendar.component';
import { SetupService } from '../service/setup.service';


@Component({
  selector: 'app-key-gens',
  templateUrl: './key-gens.component.html',
  styleUrls: ['./key-gens.component.scss'],
  providers: [MessageService],
})
export class KeyGensComponent implements OnInit {
  zoneForm: FormGroup;

  isDivVisible:boolean =false;
  rowData: any[] = [];
  data: any;

  colDefs: ColDef[] = [
    { cellRenderer: CellrenderComponent,width:50},
    { headerName: 'Key Name', field:'keyFieldId', resizable: true, cellDataType: 'text' ,filter: true,floatingFilter: true},
    { headerName: 'Last Id', field:'nextId', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Prefix', field:'keyPrefix', width: 100, filter: true, floatingFilter: true },
    { headerName: 'Digits', field:'keyDigits', width: 100, filter: true, floatingFilter: true },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  
  constructor(private setupservices:SetupService, private formBuilder: FormBuilder, private messageService: MessageService){

  }
 
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      siteId:'',
      keyFieldId:'',
      nextId:'',
      keyPrefix:'',
      keyDigits:'',
      
  })
    this.getRowData();
    
  }

  getRowData() {
    this.setupservices.getkeygens().subscribe((result:any)=>{
    this.rowData = result;
    console.log("get_data", result);  
    });
  }

  rightSideForm(data:any) {
    this.isDivVisible = true;
    this.data = data;
    console.log("jyoti", data);
    this.zoneForm.patchValue(data);
    console.log("get_patchValue",data);
  }

  submitdata(){
    console.log(this.zoneForm.value);
    
      this.setupservices.postkeygens(this.zoneForm.value).subscribe((res:any)=>{
        console.log(res);
        this.messageService.add({
          severity: 'success',
          detail: 'Key gens Saved',
        });
  
          });
          this.getRowData();
    }

  downloadASCsv(){
    const filename = 'Setup.Key Generation Setup.csv';
    this.setupservices.postCsvkeyGens().subscribe((res)=>{
      this.data=res;
      console.log(res);
      this.setupservices.downloadCsv(this.data, filename);
  });
}

}
