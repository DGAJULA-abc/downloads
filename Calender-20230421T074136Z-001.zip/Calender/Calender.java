package Calender;
import java.util.*;
import java.text.*;
public class Calender {
public static void main(String args[]) {
	Date date = new Date();
	SimpleDateFormat month = new SimpleDateFormat("M");
	SimpleDateFormat current_year = new SimpleDateFormat("YYYY");
	String week[] = new String[7];
	week[0]="Sun";
	week[1]="Mon";
	week[2]="Tue";
	week[3]="Wed";
	week[4]="The";
	week[5]="Fri";
	week[6]="Sat";
	int count_year, count_day=0, mnth=0;
	try {
		mnth=Integer.parseInt(args[0]); 
		}
	catch(Exception e) {
		mnth=Integer.parseInt(month.format(date)); 
		
	}
	int year=0000,start_week_day;
	try {
		year=Integer.parseInt(args[1]);
	}
	catch(Exception e) {
		year=Integer.parseInt(current_year.format(date));
	}
	System.out.println("\n\n\t\t.........calendar of "+ mnth+","+year+"............\n\n\n\t");
	for(int i=0;i<7;i++) {
		System.out.print(week[i]+"\t");
	}
	System.out.println("\n\t");
	int week_no=1,month_day[], count_leap_year=0;
	month_day=new int[12];
	month_day[0]=31;month_day[1]=28;month_day[2]=31;
	month_day[3]=30;month_day[4]=31;month_day[5]=30;
	month_day[6]=31;month_day[7]=31;month_day[8]=30;
	month_day[9]=31;month_day[10]=30;month_day[11]=31;
	if(year%4==0) {
		month_day[1]=29;
	}
	else {
		month_day[1]=28;
	}
	if(year<2011) {
		count_year = 2011-year-1;
		for(int j=12;j>=mnth;j--) {
			count_day+=month_day[j-1];
		}
		for(int j=2010;j>year;j--) {
			if(j%4==0) count_leap_year++;
		}
		count_day+=(count_year*365) + count_leap_year;
		start_week_day =7 - (count_day%7);
		
	}
	else {
		count_year= year-2011;
		for(int j=1;j<mnth;j++) count_day+= month_day[j-1];
		for(int j=2011;j<year;j++) {
			if(j%4==0) count_year++;
		}
		count_day+= (count_year*365) + count_leap_year;
		start_week_day = (count_day%7); 
		if(start_week_day ==0) start_week_day=7; 
	}
	for(int k=1;k<start_week_day;k++) System.out.print("\t");
	week_no = start_week_day ;
	for(int i=1;i<=month_day[mnth-1];i++) {
		if((week_no%7)==0) {
			week_no = 0;
			System.out.println("\t"+i);
		}
		else {
			System.out.print("\t"+i);
			week_no++;
		}
	}
}
}
