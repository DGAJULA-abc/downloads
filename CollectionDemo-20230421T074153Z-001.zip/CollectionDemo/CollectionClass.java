package CollectionDemo;

import java.util.*;

public class CollectionClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Integer> a1= new ArrayList<>();
a1.add(99);
a1.add(100);
a1.add(67);
a1.add(42);
System.out.println(a1);

Collections.sort(a1);
System.out.println(a1);

Collections.reverse(a1);
System.out.println(a1);

Collections.swap(a1,1,3);
System.out.println(a1);


System.out.println(Collections.min(a1));

System.out.println(Collections.max(a1));
	}

}
