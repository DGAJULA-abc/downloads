package CollectionDemo;

import java.util.HashSet;
import java.util.Iterator;

public class HashSet2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet h1=new HashSet();
h1.add(9);
h1.add(3);
h1.add(8);
h1.add(2);
h1.add(10);
h1.add(3);
h1.add(8);
Iterator h2=h1.iterator();
while(h2.hasNext()) {
	System.out.println(h2.next());
}
	}

}
