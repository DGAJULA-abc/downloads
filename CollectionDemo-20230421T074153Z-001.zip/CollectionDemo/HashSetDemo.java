package CollectionDemo;

import java.util.*;

class Hash{
	int id;
	String name;
	int age;
	public Hash(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	
}
public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet<Hash> has=new HashSet<>();
Hash h1=new Hash(1,"santhosh",21);
Hash h2=new Hash(2,"pavan",21);
Hash h3=new Hash(3,"shandy",21);
Hash h4=new Hash(4,"dinesh",28);
Hash h5=new Hash(4,"dinesh",28);
has.add(h1);
has.add(h2);
has.add(h3);
has.add(h4);
has.add(h5);

//Iterator has1=has.iterator();
//while(has1.hasNext()) {
	//System.out.println(has1.id+" "+has1.name+" "+has1.age);
	//System.out.println(has1.next());
//}
for(Hash has1:has) {
	System.out.println(has1.id+" "+has1.name+" "+has1.age);
}
  
	}

}
