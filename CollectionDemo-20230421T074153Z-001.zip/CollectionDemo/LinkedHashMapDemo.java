package CollectionDemo;

import java.util.*;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashMap l1 = new LinkedHashMap();
		l1.put("name", "Dinesh");
		l1.put("FatherName", "Prasad");
		l1.put("motherName", "uma");
		l1.put("BrotherName", "Dileep");
		Set s = l1.keySet();
		Iterator l2 = s.iterator();
		while (l2.hasNext()) {
			Object obj = l2.next();
			String str = (String) obj;
			System.out.println(str + " " + l1.get(str));
		}
	}

}
