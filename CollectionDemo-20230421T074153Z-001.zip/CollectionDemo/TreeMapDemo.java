package CollectionDemo;

import java.util.*;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         TreeMap<Integer,String> map= new TreeMap();
         map.put(5, "dinesh");
         map.put(4, "dileep");
         map.put(3, "yoga");
         map.put(2, "keeru");
         map.put(1,"pandu");
        // System.out.println(map);
  //Iterator ma = map.Iterator();
  //for(int i=0;i<map.size();i++) {
	  //System.out.println(map.get(i));
 // }
       for(Integer k:map.keySet())  {
    	   System.out.println( " key "+ k + " value "+ map.get(k));
       }
	}
	

}
