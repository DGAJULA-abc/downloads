package CollectionDemo;

import java.util.Iterator;
import java.util.TreeSet;

public class TresSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        TreeSet a11= new TreeSet<>();
        a11.add(45);
        a11.add(67);
        a11.add(6);
        a11.add(8);
        a11.add(29);
        a11.add(6);
        
     Iterator a2 =a11.descendingIterator();
     while(a2.hasNext()) {
    	 System.out.println(a2.next());
     }
        
	}

}
