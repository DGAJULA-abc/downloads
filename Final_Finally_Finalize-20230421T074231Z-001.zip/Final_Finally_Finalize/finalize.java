package Final_Finally_Finalize;

public class finalize {
	public static void main(String[] args) {
		finalize obj = new finalize();
		finalize obj1 = new finalize();
// printing the hashcode
		System.out.println("Hashcode is: " + obj.hashCode());
		System.out.println("Hashcode is: " + obj1.hashCode());
		obj = null;
// calling the garbage collector using gc()
		System.gc();
//System.out.println("End of the garbage collection");
	}

	// defining the finalize method
	public void finalize() {
		System.out.println("Called the finalize() method");
	}
}