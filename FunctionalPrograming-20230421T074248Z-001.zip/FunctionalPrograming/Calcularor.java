package FunctionalPrograming;
interface Abc{
	void show();
}
public class Calcularor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Abc o1=()->System.out.println("in am the best");
        	o1.show();
        
	}

}
