package MainjavaStreamAPI;

public enum Gender {
	 MALE,FEMALE;
}
