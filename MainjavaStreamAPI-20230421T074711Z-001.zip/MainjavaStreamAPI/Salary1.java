package MainjavaStreamAPI;

public class Salary1 {
private int id;
private int salary;
private String designation;
public Salary1(int id, int salary, String designation) {
	super();
	this.id = id;
	this.salary = salary;
	this.designation = designation;
	
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}

}
