package Practice1Programs;

import java.util.Scanner;

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc= new Scanner(System.in);
      int b=sc.nextInt();
      int h=sc.nextInt();
      if(b>0&&h>0) {
    	 int area=b*h;
    	 System.out.println(area);
      }else {
      System.out.println("negative");
	}
	}
}
