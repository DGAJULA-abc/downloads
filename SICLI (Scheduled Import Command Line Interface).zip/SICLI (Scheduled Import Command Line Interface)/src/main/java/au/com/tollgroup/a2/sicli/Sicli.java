package au.com.tollgroup.a2.sicli;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan(basePackages = {"au.com.tollgroup"})
public class Sicli {

	public static void main(String[] args) {
		SpringApplication.run(Sicli.class, args);
		}

}
