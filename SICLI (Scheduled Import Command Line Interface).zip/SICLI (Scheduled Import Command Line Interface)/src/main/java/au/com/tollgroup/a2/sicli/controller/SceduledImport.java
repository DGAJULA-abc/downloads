package au.com.tollgroup.a2.sicli.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.silci.service.StandardAxiomImport;

@Controller
public class SceduledImport {
	@Autowired
	StandardAxiomImport standardAxiomImport;
	@Value("#{'${Site_id}'.split(',')}")
	
	private int[] tSite;
	@Value("#{'${importDate}'}")
	private String importDate;
	@Value("#{'${onlyMultileg}'}")
	private String onlyMultileg;
	@GetMapping("/runsicliimport/")
//public void runSicliImport	(@PathVariable String siteids,@PathVariable(required = false) String importDate,@PathVariable(required = false) String onlyMultileg,@PathVariable(required = false) String autoDespatch) throws SQLException, NotImplementedException, IOException {
	//@Scheduled(cron = "*/30 * * * * *")
	public void runSicliImport	() throws SQLException, NotImplementedException, IOException {
	List<Long> siteidsLis = Arrays.stream(tSite).mapToLong(n -> (long) n).boxed().collect(Collectors.toList());
		System.out.println("hii sicli----------------------");
           Boolean bmultileg=false;
           Date dimportDate=null;
           Boolean bautoDespatch=false;
           for(long siteid:siteidsLis) {
        	   if(onlyMultileg!=null) {
           if(onlyMultileg.equalsIgnoreCase("IM0"))
           bmultileg=false;
           else if(onlyMultileg.equalsIgnoreCase("IM1"))
               bmultileg=true;   
           else if(onlyMultileg.equalsIgnoreCase("/D"))
        	   bautoDespatch=true; 
        	   }
        	   System.out.println("hii sicli----------------------"+bmultileg+"===="+bautoDespatch+"===="+dimportDate);
		    standardAxiomImport.standardImport(siteid,dimportDate, bmultileg, bautoDespatch);
			}		
	}

}
