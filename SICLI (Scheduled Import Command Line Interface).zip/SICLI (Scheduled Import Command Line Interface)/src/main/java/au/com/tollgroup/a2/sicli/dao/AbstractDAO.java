package au.com.tollgroup.a2.sicli.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;

import au.com.tollgroup.a2.sicli.util.TimeUtil;
import au.com.tollgroup.a2.sicli.util.constants.ApplicationConstants;
import au.com.tollgroup.a2.sicli.exception.NotImplementedException;





/**
 * Parent class of all the DAOs defining common functionality for all the DAOs
 *
 * @author mahilalh
 */
public abstract class AbstractDAO {

	public static final String NATIVE_SITE_TIMEZONE = "{ ? = call F_SITE_TIMEZONE(?) }";
	
	String contextId = AbstractDAO.class.getSimpleName();
	private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());
	
//	
//	@Autowired  
//	private DataSource dataSource;
//    
//    protected Connection getConnection() throws SQLException {
//        
//        return dataSource.getConnection();
//    }
//    
    @Bean 
    public DataSource getDataSource() { 
        DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create(); 
        dataSourceBuilder.driverClassName("oracle.jdbc.OracleDriver"); 
        dataSourceBuilder.url("jdbc:oracle:thin:@AXIDBSUD01:1521:AXIOMDEV"); 
        dataSourceBuilder.username("axiom"); 
        dataSourceBuilder.password("axidev"); 
        return dataSourceBuilder.build();
        }

    //@Autowired  
    public DataSource dataSource = getDataSource();
    protected Connection getConnection() throws SQLException {
        return dataSource.getConnection();

 

    }

	/**
	 * Given a sequence name, it retrieves the equivalent to nextval.
	 *
	 * @param sequenceName
	 * @return
	 * @throws NotImplementedException 
	 */
	protected Long getNextSequenceNumber(String sequenceName, Connection conn) throws SQLException, NotImplementedException {
		PreparedStatement st = null;
		ResultSet rs = null;
		try {
			st = prepareStatement(conn, "select " + sequenceName
					+ ".nextval from dual");
			rs = st.executeQuery();
			rs.next();
			Long result = getLong(1, rs);
			return result;
		} finally {
			closeResultSet(rs);
			closeStatement(st);
		}
	}

	protected PreparedStatement prepareStatement(Connection conn, String query, Object... params) throws SQLException, NotImplementedException {
		PreparedStatement pstmt = conn.prepareStatement(query);
		populateStatement(pstmt, false, params);

		return pstmt;
	}

	protected CallableStatement callableStatement(Connection conn, String query, Object... params) throws SQLException, NotImplementedException {
		CallableStatement pstmt = conn.prepareCall(query);
		populateStatement(pstmt, false, params);

		return pstmt;
	}

	protected CallableStatement functionStatement(Connection conn, String query, Object... params) throws SQLException, NotImplementedException {
		CallableStatement pstmt = conn.prepareCall(query);
		populateStatement(pstmt, true, params);

		return pstmt;
	}

//	public void addParameters(PreparedStatement pstmt, List<Object> params) throws SQLException {
//		for (int i = 0; i < params.size(); i++) {
//			addParameter(pstmt, (i + 1), params.get(i));
//		}
//	}

	public void addParameter(PreparedStatement pstmt, int column, Object param) throws SQLException, NotImplementedException {
		if (param == null) {
			pstmt.setNull(column, Types.NULL);
		} else if (param instanceof Long) {
			pstmt.setLong(column, (Long) param);
		} else if (param instanceof Boolean) {
			pstmt.setInt(column, ((Boolean) param) == true ? ApplicationConstants.DB_TRUE_FLAG : ApplicationConstants.DB_FALSE_FLAG);
		} else if (param instanceof Integer) {
			pstmt.setInt(column, (Integer) param);
		} else if (param instanceof Float) {
			pstmt.setFloat(column, (Float) param);
		} else if (param instanceof Double) {
			pstmt.setDouble(column, (Double) param);
		} else if (param instanceof String) {
			pstmt.setString(column, (String) param);
		} else if (param instanceof BigDecimal) {
			pstmt.setBigDecimal(column, (BigDecimal) param);
		} else if (param instanceof Short) {
			pstmt.setShort(column, (Short) param);
		} else if (param instanceof java.sql.Date) {
			pstmt.setDate(column, (java.sql.Date) param);
		} else if (param instanceof java.util.Date) {
			pstmt.setTimestamp(column, new Timestamp(((java.util.Date) param).getTime()));
		} else if (param instanceof Timestamp) {
			pstmt.setTimestamp(column, (Timestamp) param);		
		} else if (param instanceof Clob) {
			pstmt.setClob(column, (Clob) param);
		} else {
			throw new NotImplementedException("The supplied datatype has not been implemented - " + param.getClass() + " with value " + param);
		}
	}

	private void populateStatement(PreparedStatement pstmt, boolean isFunction, Object... params) throws SQLException, NotImplementedException {
		if (params != null) {
			int increment = 1;
			if (isFunction) {
				//increment = 2;
				increment++;
			}
			for (int i = 0; i < params.length; i++) {
				if (params[i] == null) {
					pstmt.setNull(i + increment, Types.NULL);
				} else if (params[i] instanceof Long) {
					pstmt.setLong(i + increment, (Long) params[i]);
				} else if (params[i] instanceof Boolean) {
					pstmt.setInt(i + increment, ((Boolean) params[i]) == true ? ApplicationConstants.DB_TRUE_FLAG : ApplicationConstants.DB_FALSE_FLAG);
				} else if (params[i] instanceof Integer) {
					pstmt.setInt(i + increment, (Integer) params[i]);
				} else if (params[i] instanceof Float) {
					pstmt.setFloat(i + increment, (Float) params[i]);
				} else if (params[i] instanceof Double) {
					pstmt.setDouble(i + increment, (Double) params[i]);
				} else if (params[i] instanceof String) {
					pstmt.setString(i + increment, (String) params[i]);
				} else if (params[i] instanceof BigDecimal) {
					pstmt.setBigDecimal(i + increment, (BigDecimal) params[i]);
				} else if (params[i] instanceof Short) {
					pstmt.setShort(i + increment, (Short) params[i]);
				} else if (params[i] instanceof java.sql.Date) {
					pstmt.setDate(i + increment, (java.sql.Date) params[i]);
				} else if (params[i] instanceof java.util.Date) {
					pstmt.setTimestamp(i + increment, new Timestamp(((java.util.Date) params[i]).getTime()));
				} else if (params[i] instanceof Timestamp) {
					pstmt.setTimestamp(i + increment, (Timestamp) params[i]);
				
				} else if (params[i] instanceof Clob) {
					pstmt.setClob(i + increment, (Clob) params[i]);
				} else {
					throw new NotImplementedException("The supplied datatype has not been implemented - " + params[i].getClass() + " with value " + params[i]);
				}
			}
		}
	}

	public String getSiteTimeZone(Long siteId) throws SQLException, NotImplementedException {
		Connection conn = getConnection();
		String ret = "UTC";
		CallableStatement pstmt = null;
		try {
			pstmt = callableStatement(conn, NATIVE_SITE_TIMEZONE);
			pstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.VARCHAR);
			//pstmt.registerOutParameter(1, OracleTypes.VARCHAR);
			pstmt.setLong(2, siteId);
			pstmt.execute();
			ret = pstmt.getString(1);
		} finally {
			closeConn(conn, pstmt);
		}
		return ret;

	}

	protected String getSPBooleanFlag(boolean flag) {
		return flag ? ApplicationConstants.SP_TRUE_FLAG : ApplicationConstants.SP_FALSE_FLAG;
	}

	protected void closeConn(Connection conn) {
		try {
			conn.close();
		} catch (Exception e) {

		}
	}

	protected void closeRsStatement(ResultSet rs, Statement stmt) {
		closeResultSet(rs); 
		closeStatement(stmt);
	}

	protected void closeStatement(Statement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {
			// do nothing
		}
	}

	protected void closeResultSet(ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (Exception e) {
			// do nothing
		}
	}

	protected void closeConn(Connection conn, Statement stmt) {
		closeStatement(stmt);
		closeConn(conn);
	}

	protected void freeClob(Clob c) {
		try {
			c.free();
		} catch (Exception e) {
		}
	}

	protected void closeConn(Connection conn, Statement stmt, ResultSet rs) {
		closeResultSet(rs);
		closeStatement(stmt);
		closeConn(conn);
	}

	/**
	 * Given a ResultSet row, return null if the value is null; otherwise,
	 * return the integer value.
	 *
	 * @param row
	 *            the row index
	 * @param rs
	 *            the result set
	 * @return the Integer value
	 * @throws SQLException
	 */
	protected Integer getInt(int row, ResultSet rs) throws SQLException {
		int num = rs.getInt(row);
		if (rs.wasNull()) {
			return null;
		}
		return num;
	}

	protected Integer getIntNullIfZero(int row, ResultSet rs) throws SQLException {
		int num = rs.getInt(row);
		if (rs.wasNull() || num == 0) {
			return null;
		}
		return num;
	}

	protected Integer getInt(String columnlabel, ResultSet rs)
			throws SQLException {
		int num = rs.getInt(columnlabel);
		if (rs.wasNull()) {
			return null;
		}
		return num;
	}

	protected void setInt(int index, Integer value, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.INTEGER);
		} else {
			pstmt.setInt(index, value.intValue());
		}
	}

	protected void setLong(int index, Long value, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.BIGINT);
		} else {
			pstmt.setLong(index, value.longValue());
		}
	}

	protected void setArray(int index, Object value, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.ARRAY);
		} else {
			pstmt.setObject(index, value);
		}
	}

	protected void setString(int index, String value, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.VARCHAR);
		} else {
			pstmt.setString(index, value);
		}
	}

	protected void setClob(int index, Clob value, CallableStatement pstmt)
			throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.CLOB);
		} else {
			pstmt.setClob(index, value);
		}
	}

	protected void setDouble(int index, Double value, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.DOUBLE);
		} else {
			pstmt.setDouble(index, value.doubleValue());
		}
	}

	protected void setConvertedTimestamp(int index, java.util.Date value, long siteId, CallableStatement pstmt) throws SQLException {
		if (value == null) {
			pstmt.setNull(index, java.sql.Types.TIMESTAMP);
		} else {
			pstmt.setTimestamp(index, new Timestamp(TimeUtil.convertToAxiomDate(value, siteId).getTime()));
		}
	}

	/**
	 * Given a ResultSet row, return null if the value is null; otherwise,
	 * return the short value.
	 *
	 * @param row
	 *            the row index
	 * @param rs
	 *            the result set
	 * @return the short value
	 * @throws SQLException
	 */
	 protected Short getShort(int row, ResultSet rs) throws SQLException {
		 short num = rs.getShort(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 protected Short getShort(String columnlabel, ResultSet rs)
			 throws SQLException {
		 short num = rs.getShort(columnlabel);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 /**
	  * Given a ResultSet row, return true if the int in the column matches to
	  * <code>trueValue</code>
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @param trueVal
	  *            the accepted true value
	  * @return boolean value
	  * @throws SQLException
	  */
	 protected Boolean getIntAsBool(int row, ResultSet rs, int trueVal) throws SQLException {
		 int num = rs.getInt(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num == trueVal;
	 }

	 protected int getBoolAsInt(boolean value) {
		 return (value ? ApplicationConstants.DB_TRUE_FLAG : ApplicationConstants.DB_FALSE_FLAG);
	 }

	 /**
	  * Given a ResultSet row, return true if the value is not null and not 0.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return boolean value
	  * @throws SQLException
	  */
	 protected Boolean getIntAsAxiomBool(int row, ResultSet rs) throws SQLException {
		 // rs.getInt() returns 0 when value is null
		 int num = rs.getInt(row);
		 if (rs.wasNull()) {
			 return null;
		 }

		 if (num != 0) {
			 return true;
		 }
		 return false;
	 }

	 /**
	  * Given a ResultSet row, return true if the value is not null and not 0.
	  *
	  * @param row the row index
	  * @param rs the ResultSet
	  * @return boolean value
	  * @throws SQLException
	  */
	 protected Boolean getIntAsAxiomBool(String columnLabel, ResultSet rs)
			 throws SQLException {
		 // rs.getInt() returns 0 when value is null
		 int num = rs.getInt(columnLabel);
		 if (rs.wasNull()) {
			 return null;
		 }

		 if (num != 0) {
			 return true;
		 }
		 return false;
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the long value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the long value
	  * @throws SQLException
	  */
	 protected Long getLong(int row, ResultSet rs) throws SQLException {
		 long num = rs.getLong(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 protected Long getLong(String columnlabel, ResultSet rs)
			 throws SQLException {
		 long num = rs.getLong(columnlabel);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the BigDecimal value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the BigDecimal value
	  * @throws SQLException
	  */
	 protected BigDecimal getBigDecimal(int row, ResultSet rs) throws SQLException {
		 BigDecimal num = rs.getBigDecimal(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 protected BigDecimal getBigDecimal(String columnlabel, ResultSet rs)
			 throws SQLException {
		 BigDecimal num = rs.getBigDecimal(columnlabel);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the string value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the string value
	  * @throws SQLException
	  */
	 protected String getString(int row, ResultSet rs) throws SQLException {
		 // already returns null when value is null
		 return rs.getString(row);
	 }

	 protected String getString(String columnlabel, ResultSet rs)
			 throws SQLException {
		 // already returns null when value is null
		 return rs.getString(columnlabel);
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the double value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the double value
	  * @throws SQLException
	  */
	 protected Double getDouble(int row, ResultSet rs) throws SQLException {
		 double num = rs.getDouble(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 protected Double getDouble(String columnlabel, ResultSet rs)
			 throws SQLException {
		 double num = rs.getDouble(columnlabel);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return num;
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the SQL date value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the SQL date value
	  * @throws SQLException
	  */
	 protected Timestamp getTimestamp(int row, ResultSet rs) throws SQLException {
		 return rs.getTimestamp(row);
	 }

	

	 protected Timestamp getTimestamp(String columnlabel, ResultSet rs)
			 throws SQLException {
		 return rs.getTimestamp(columnlabel);
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the string value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the string value
	  * @throws SQLException
	  */
	 protected String getClob(int row, ResultSet rs) throws SQLException {
		 Clob clob = rs.getClob(row);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return clobToString(clob);
	 }

	 protected String getClob(String columnlabel, ResultSet rs)
			 throws SQLException {
		 // already returns null when value is null
		 Clob clob = rs.getClob(columnlabel);
		 if (rs.wasNull()) {
			 return null;
		 }
		 return clobToString(clob);

	 }

	 private String clobToString(Clob data) {

		 StringBuilder sb = new StringBuilder();
		 try {
			 long clobLength = data.length();
			 if (clobLength <= 0) {
				 if (log.isDebugEnabled()) {
					 log.debug("Converting empty clob to String");
				 }
				 return "";
			 }

			 Reader reader = data.getCharacterStream();
			 BufferedReader br = new BufferedReader(reader);

			 int charCount;
			 char[] charBuff;

			 int MAX_ARRAY_SIZE = Integer.MAX_VALUE / 2;

			 if (clobLength < MAX_ARRAY_SIZE) {
				 // All of our clobs appear to be very small at present. 
				 charBuff = new char[(int) clobLength];

				 while ((charCount = br.read(charBuff, 0, charBuff.length)) != -1) {
					 sb.append(charBuff);
				 }
			 }
			 else {
				 charBuff = new char[MAX_ARRAY_SIZE];

				 long remainingChars = clobLength;
				 int nextArraySize = 0;
				 while ((charCount = br.read(charBuff, 0, charBuff.length)) != -1) {
					 sb.append(charBuff);

					 remainingChars = remainingChars - charBuff.length;
					 if (remainingChars <= 0) {
						 charBuff = new char[1];
						 continue; // While loop will exit on next iteration
					 }

					 // Chars remain, create array of adequate size for next read
					 if (remainingChars < MAX_ARRAY_SIZE) { 
						 nextArraySize = (int) remainingChars;
					 }
					 else {
						 nextArraySize = MAX_ARRAY_SIZE;
					 }
					 charBuff = new char[nextArraySize];
				 }
			 }
			 charBuff = null;
			 br.close();
		 } 
		 catch (SQLException | IOException e) {
			 log.error("AbstractDAO.clobToString failed reading Clob char stream.");
			 e.printStackTrace();
		 } 
		 return sb.toString();
	 }

	 /**
	  * Given a ResultSet row, return null if the value is null; otherwise,
	  * return the SQL date value.
	  *
	  * @param row
	  *            the row index
	  * @param rs
	  *            the ResultSet
	  * @return the SQL date value
	  * @throws SQLException
	  */
	 protected java.util.Date getConvertedTimestamp(long siteId, int row, ResultSet rs) throws SQLException {
		 Timestamp timestamp = rs.getTimestamp(row);
		 if (timestamp == null) {
			 return null;
		 }
		 return TimeUtil.convertFromAxiomDate(timestamp, siteId);
	 }

	 /**
	  * Get boolean from the bigdecimal value
	  *
	  * @param value
	  * @return
	  */
	 protected Boolean getBoolean(BigDecimal value) {
		 if (value == null) {
			 return null;
		 }
		 return value.intValue() != 0;
	 }

	 protected Boolean getBoolean(Integer value) {
		 if (value == null) {
			 return null;
		 }
		 return value.intValue() != 0;
	 }

	 /**
	  * Get boolean from the bigdecimal value
	  *
	  * @param value
	  * @return
	  */
	 protected Long getLong(BigDecimal value) {
		 if (value == null) {
			 return null;
		 }
		 return value.longValue();
	 }

	 /**
	  * @param value
	  * @return
	  */
	 protected Integer getInteger(BigDecimal value) {
		 if (value == null) {
			 return null;
		 }
		 return value.intValue();
	 }

	 protected String getSQLCriteria(java.util.Date from) {
		 if (from == null) {
			 return null;
		 }
		 String format = "yyyy-MM-dd HH:mm:ss.SSS000000";
		 SimpleDateFormat dt = new SimpleDateFormat(format);
		 return "to_timestamp('" + dt.format(from) + "', 'YYYY-MM-DD HH24:MI:SS.FF')";
	 }

	 

	 /**
	  * Prepares the in clause using the list of primary key. This processes the
	  * key assuming it is object in general and converts to String IN clause
	  *
	  * @param ids
	  *            the list of ids
	  * @return the in clause string
	  */
	 protected <T extends Object> String listToInClause(List<T> ids) {
		 if (ids == null) {
			 return "()";
		 }

		 String inClause = "(";
		 for (Object id : ids) {
			 inClause = inClause + "'" + id.toString().replace("'", "''") + "',";
		 }
		 if (inClause.length() > 1 && inClause.charAt(inClause.length() - 1) == ',') {
			 inClause = inClause.substring(0, inClause.length() - 1) + ")";
		 }
		 return inClause;
	 }

	 /**
	  * Prepares the in clause using the list of numeric primary key. This processes the
	  * key assuming it is a subclass of Number and converts to String IN clause
	  *
	  * @param ids
	  *            the list of ids
	  * @return the in clause string
	  */
	 protected <T extends Number> String listNumericInClause(List<T> ids) {
		 if (ids == null) {
			 return "";
		 }

		 String inClause = "";
		 for (Number id : ids) {
			 inClause = inClause + id + ",";
		 }
		 if (inClause.length() > 1 && inClause.charAt(inClause.length() - 1) == ',') {
			 inClause = inClause.substring(0, inClause.length() - 1);
		 }
		 return inClause;
	 }

	 /**
	  * Prepares the in clause using the list of strings.
	  *
	  * @param ids
	  *            the list of string values
	  * @return the in clause string
	  */
	 protected String listStringToInClause(List<String> ids) {
		 if (ids == null || ids.isEmpty()) {
			 return "()";
		 }

		 StringBuilder sb = new StringBuilder();
		 sb.append("(");
		 for (int i = 0; i < ids.size(); i++) {
			 String id = ids.get(i).replace("'", "''");
			 sb.append("'").append(id).append("'");
			 if (i < ids.size() - 1) {
				 sb.append(",");
			 }
		 }
		 sb.append(")");
		 return sb.toString();
	 }

	 /**
	  * Provides a clone of the source, by making use of Dozer
	  *
	  * @param source
	  * @return
	  */
	 
	 /**
	  * Convenience method that returns a string with ?, ?, ?... typically used
	  * in insert statements.
	  *
	  * @param num
	  * @return
	  */
	 public String generateQuetionMarkCriteria(int num) {
		 StringBuilder sb = new StringBuilder();
		 for (int i = 0; i < num; i++) {
			 sb.append("?");
			 if (i < num - 1) {
				 sb.append(",");
			 }
		 }
		 return sb.toString();
	 }
}