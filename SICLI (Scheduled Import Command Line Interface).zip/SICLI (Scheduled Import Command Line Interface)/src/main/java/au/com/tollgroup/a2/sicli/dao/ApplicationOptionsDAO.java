package au.com.tollgroup.a2.sicli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import au.com.tollgroup.a2.sicli.model.ApplicationOptionTO;
import au.com.tollgroup.a2.sicli.util.constants.ApplicationConstants;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Application options DAO classs
 */


public class ApplicationOptionsDAO extends AbstractDAO {
	@Autowired  
	private DataSource dataSource;
	static Logger log = Logger.getLogger(ApplicationOptionsDAO.class);
	String contextId = ApplicationOptionsDAO.class.getSimpleName();
	private static final String[] TABLES = new String[] { "A2_APPLICATION_OPTIONS" };

	//private ICRUDInterface<ApplicationOptionTO> appOptCrudImpl;

	/** Query strings */
	public static final String NATIVE_QUERY_GET_SITE_OPTIONS = "select APPLICATIONOPTIONID, SITEID, USERID, OPTIONNAME, OPTIONVALUE from A2_APPLICATION_OPTIONS where SITEID IS NOT NULL and USERID IS NULL ";

	public static final String NATIVE_QUERY_GET_RATE_ARCHIVE_CUT_OFF = "SELECT OPTIONVALUE FROM A2_APPLICATION_OPTIONS WHERE USERID IS NULL AND SITEID IS NULL AND OPTIONNAME='"
			+ ApplicationConstants.APP_OPTION_RATE_ARCHIVE_CUT_OFF + "'";

	public static ConcurrentHashMap<Long, Map<String, String>> STATIC_SITE_OPTIONS_CACHE;

	/**
	 * Initializes the internal static cache.
	 */
	public void iniSiteOptionCache(Boolean forceRecache) {
		if (STATIC_SITE_OPTIONS_CACHE == null
				|| (forceRecache != null && forceRecache)) {
			try {

				STATIC_SITE_OPTIONS_CACHE = new ConcurrentHashMap<Long, Map<String, String>>();

				log.info("\t ......Site options : "
						+ ApplicationOptionsDAO.class.getSimpleName());
				List<ApplicationOptionTO> list = getSiteOptions();
				if (list == null || list.isEmpty()) {
					log.error("Application will not work properly without site level application options!");
					return;
				}

				for (ApplicationOptionTO to : list) {
					if (to.getSiteId() != null) {

						if (STATIC_SITE_OPTIONS_CACHE.get(to.getSiteId()) == null) {
							STATIC_SITE_OPTIONS_CACHE.put(to.getSiteId(),
									new Hashtable<String, String>());
						}
						if (to.getOptionValue() != null) {
							STATIC_SITE_OPTIONS_CACHE.get(to.getSiteId()).put(
									to.getOptionName(), to.getOptionValue());
						}
					}
				}
				log.info("\t .......................DONE DAO [ "
						+ STATIC_SITE_OPTIONS_CACHE.size() + " sites "
						+ list.size() + " options cached]: "
						+ ApplicationOptionsDAO.class.getSimpleName());
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * Get the site timezone from static site option cache.
	 * 
	 * @param siteId
	 * @return
	 */
	public static String getTimeZone(Long siteId) {
		if (siteId == null) {
			return null;
		}

		if (STATIC_SITE_OPTIONS_CACHE == null) {
			log.warn("Application options static cache has not been initialized!");
			STATIC_SITE_OPTIONS_CACHE = new ConcurrentHashMap<Long, Map<String, String>>();
		}

		if (STATIC_SITE_OPTIONS_CACHE.get(siteId) == null) {
			log.warn("Site [" + siteId
					+ "] does not have site level application options!!!");
			STATIC_SITE_OPTIONS_CACHE.put(siteId,
					new Hashtable<String, String>());
		}

		String timezone = STATIC_SITE_OPTIONS_CACHE.get(siteId).get(
				ApplicationConstants.APP_OPTION_TIMEZONE_NAME);
		if (timezone != null) {
			return timezone;
		} else {
			log.warn("Site ["
					+ siteId
					+ "] does not have timezone configured! Default UTC timezone will be used.");
			STATIC_SITE_OPTIONS_CACHE.get(siteId).put(
					ApplicationConstants.APP_OPTION_TIMEZONE_NAME,
					ApplicationConstants.DEFAULT_TIMEZONE_UTC);
			return ApplicationConstants.DEFAULT_TIMEZONE_UTC;
		}
	}

	/**
	 * Gets the given site option for the site from the site options cache
	 *
	 * @param siteId
	 * @param optionName
	 * @return
	 */
	public String getSiteOption(Long siteId, String optionName) {

		if (siteId == null || optionName == null
				|| STATIC_SITE_OPTIONS_CACHE == null
				|| STATIC_SITE_OPTIONS_CACHE.get(siteId) == null) {
			return null;
		}

		return STATIC_SITE_OPTIONS_CACHE.get(siteId).get(optionName);
	}

	/**
	 * Fetches application options from the database given the site id and null
	 * for the user id
	 *
	 * @param siteId
	 *            the site id
	 * @param userId
	 *            the user id
	 * @return the list of application option TO
	 */
	private List<ApplicationOptionTO> getSiteOptions() throws SQLException {

		Connection conn = dataSource.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<ApplicationOptionTO> options = new ArrayList<>();

		try {
			pstmt = conn.prepareStatement(NATIVE_QUERY_GET_SITE_OPTIONS);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				ApplicationOptionTO to = new ApplicationOptionTO();
				int i = 1;

				to.setApplicationOptionId(getLong(i++, rs));
				Long sid = getLong(i++, rs);
				if (sid != 0) {
					to.setSiteId(sid);
				} else {
					to.setSiteId(null);
				}
				to.setUserId(rs.getString(i++));
				to.setOptionName(rs.getString(i++));
				to.setOptionValue(rs.getString(i++));
				options.add(to);
			}
		} finally {
			closeConn(conn, pstmt, rs);
		}

		return options;
	}

	
	public int recache(Long siteId) {
		// do nothing. data is already loaded during start up. just need to keep
		// it up to date
		return 0;
	}

	public List<Object> recacheDelete(String tableName, Long siteId,
			Set<String> ids) {
		List<Object> objects = new ArrayList<Object>();

		if (tableName.equals("A2_APPLICATION_OPTIONS")) {
			if (!STATIC_SITE_OPTIONS_CACHE.containsKey(siteId)) {
				return objects;
			}

			try {
				for (String id : ids) {
					STATIC_SITE_OPTIONS_CACHE.get(siteId).remove(id);
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return objects;
	}

}
