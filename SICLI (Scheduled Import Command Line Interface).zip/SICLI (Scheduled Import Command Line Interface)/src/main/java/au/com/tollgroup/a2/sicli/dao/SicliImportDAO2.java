package au.com.tollgroup.a2.sicli.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.AxiomServiceReturnTO;
import au.com.tollgroup.a2.sicli.model.AxiomServiceTO;
import au.com.tollgroup.a2.sicli.model.ResourceResultTO;
import au.com.tollgroup.a2.sicli.model.CompanyTO;
import au.com.tollgroup.a2.sicli.model.ContainerTO;
import au.com.tollgroup.a2.sicli.model.CustomerTO;
import au.com.tollgroup.a2.sicli.model.DespatchDecisionTO;
import au.com.tollgroup.a2.sicli.model.DriverResourceTO;
import au.com.tollgroup.a2.sicli.model.ImpLoadTO;
import au.com.tollgroup.a2.sicli.model.ImpServiceTO;
import au.com.tollgroup.a2.sicli.model.LoadServiceTO;
import au.com.tollgroup.a2.sicli.model.LoadTO;
import au.com.tollgroup.a2.sicli.model.LocationTO;
import au.com.tollgroup.a2.sicli.model.ReturnCreationTO;
import au.com.tollgroup.a2.sicli.model.ServiceTO;
import au.com.tollgroup.a2.sicli.model.ServiceTypeTO;
import au.com.tollgroup.a2.sicli.model.TrailerResourceTO;
import au.com.tollgroup.a2.sicli.model.TripTO;
import au.com.tollgroup.a2.sicli.model.TruckResourceTO;
import au.com.tollgroup.a2.sicli.model.TruckTrailerCapacityTO;
import au.com.tollgroup.a2.sicli.model.UnitTO;
import au.com.tollgroup.a2.sicli.model.WindowTO;
import au.com.tollgroup.a2.sicli.util.ImpJobLogTO;
import au.com.tollgroup.a2.sicli.util.ServiceUtil;
import au.com.tollgroup.a2.sicli.util.TimeUtil;
import au.com.tollgroup.a2.silci.service.StandardAxiomImport;

@Repository
public class SicliImportDAO2 extends AbstractDAO {

//	@Autowired
//	private DataSource dataSource;

	private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());

	private static final String REJECT_IMP_SERVICE = "update axiomimp.imp_service set importerror=?, imported=? where importid=? ";

	private static final String QUERY_MULTILEG_ENABLED_SITE = "Select count(Set1.siteid) from (SELECT SiteId_Owner SiteId From AXIOMIMP.Multileg_sites "
			+ "UNION SELECT SiteID_Selectable Siteid From AXIOMIMP.MultiLeg_Sites) Set1 where Set1.SiteId=?";

	private static final String QUERY_IMP_SERVICE = "select IMPORTID,SITEID,IMPORTDATETIME,IMPORTSOURCE,IMPORTCOMMENTS,UPPER(SERVICETYPE),SERVICEDATE,"
			+ "SERVICEDESC,UPPER(CUSTOMERID),UPPER(LOADTYPE),DRIVERID,UPPER(TRUCKID),UPPER(TRAILERID),UPPER(TRAILERID_TAG),UPPER(CONTAINERID),"
			+ "UPPER(LOCATIONID_PICKUP),UPPER(LOCATIONID_DROP),QTY1,UPPER(UNIT1),QTY2,UPPER(UNIT2),QTY3,UPPER(UNIT3),QTY4,UPPER(UNIT4),QTY5,UPPER(UNIT5),"
			+ "QTY6,UPPER(UNIT6),QTY7,UPPER(UNIT7),QTY8,UPPER(UNIT8),DOCKET,SUBSTR(REMARKS_SERVICE,1,3999),DELIVERED,WINDOW1FROM,WINDOW1TO,WINDOW2FROM,"
			+ "WINDOW2TO,BATCHNO,CUSTREFERENCE,SCHEDULEDDATE,UPPER(LOADNO),UPPER(LOCATIONID_LOAD),CUSTCLAIMAMT,SETTLEDATE,REMARKS_LOAD,"
			+ "UPPER(LOCATIONTYPE_DROP),LOCATIONDESC_DROP,PERSONID_DROP,CUSTOMERID_DROP,LOCATIONCODE_DROP,WINDOW1FROM_DROP,WINDOW1TO_DROP,"
			+ "WINDOW2FROM_DROP,WINDOW2TO_DROP,UPPER(PAYZONEID_DROP),UPPER(CHARGEZONEID_DROP),LATITUDE_DROP,LONGITUDE_DROP,GEOFENCE_DROP,"
			+ "UPPER(MAPSOURCEID_DROP),MAPREFERENCE_DROP,ADDRESS1_DROP,ADDRESS2_DROP,SUBURB_DROP,STATE_DROP,POSTCODE_DROP,REMARKS_DROP,"
			+ "TRUCKSIZELIMIT_DROP,DEFAULTTRIPSEQ_DROP,UPPER(ROUTEID_DROP),PERMANENT_DROP,UPPER(CONTAINERTYPE_CONT),CONTAINERDESC_CONT,"
			+ "COMPANYID_CONT,WEIGHTTONNES_CONT,PERMANENT_CONT,IMPORTENTEREDBY,VALIDATELOAD,VALIDATECUSTOMER,VALIDATEDROP,VALIDATECONTAINER,"
			+ "PROMPTFORSERVICEDATE,VALIDATEPICKUP,VALIDATETRUCK,VALIDATETRAILER,VALIDATETRAILERTAG,VALIDATEDRIVER,VALIDATEPAYZONE,VALIDATECHARGEZONE,"
			+ "VALIDATEPERSONDROP,VALIDATEMAPSOURCE,VALIDATELOCATIONTYPE,VALIDATEROUTE,VALIDATECONTAINERTYPE,VALIDATECOMPANYCONT,VALIDATELOADTYPE,"
			+ "IMPORTED,IMPORTERROR,IMPORTSERVICEID,VALIDATETRIP,TRIPID,TRIPSEQ,VALIDATESERVICE,DESPATCHBY,DELIVERYOPEN,DELIVERYCLOSE,SERVICEGROUP,"
			+ "UPPER(TRIPNO),VALIDATEDESPATCH,VALIDATERETURN,LOCATIONID_DESPATCH,LOCATIONID_RETURN,PLANNEDSTARTTIME,PLANNEDENDTIME,LATITUDE_PICKUP,"
			+ "LONGITUDE_PICKUP,LOCATIONCODE,LOCATIONDESC,UPPER(LOCATIONTYPE),ADDRESS1,ADDRESS2,MAPREFERENCE,UPPER(MAPSOURCEID),CUSTOMERID_PICKUP,"
			+ "PERSONID,POSTCODE,SUBURB,STATE,TRUCKSIZELIMIT_PICKUP,UPPER(PAYZONEID),UPPER(CHARGEZONEID),WINDOW1FROM_PICKUP,WINDOW1TO_PICKUP,"
			+ "WINDOW2FROM_PICKUP,WINDOW2TO_PICKUP,GEOFENCE_PICKUP,PERMANENT_PICKUP,UPPER(ROUTEID_PICKUP),DEFAULTTRIPSEQ_PICKUP,REMARKS_PICKUP,"
			+ "UPPER(SERVICENO),ORIGINSITE,ORIGINLOC,DESTINATIONSITE,DESTINATIONLOC,CREATETRIP,LASTMODIFIED,UPPER(LOCATIONID_FINISH),DOCKNAME,"
			+ "IMPORTBATCH FROM AXIOMIMP.IMP_SERVICE WHERE SITEID=? AND IMPORTED=-1";

	private static final String QUERY_IMP_SERVICE_MULTILEG_ONLY = QUERY_IMP_SERVICE
			+ " AND ORIGINSITE IS NOT NULL AND ORIGINLOC IS NOT NULL " + "ORDER BY TRIPNO, TRIPSEQ, IMPORTID ";
	private static final String QUERY_IMP_SERVICE_FOR_IMPORT = QUERY_IMP_SERVICE
			+ " ORDER BY TRIPNO, TRIPSEQ, IMPORTID ";

	private static final String CUSTOMER_SERVICE_LIST = "SELECT CUSTOMER.* FROM CUSTOMER WHERE CUSTOMER.CUSTOMERID=? AND CUSTOMER.SITEID=? ";

	public static final String NQ_INSERT_MINIMAL = "INSERT INTO CUSTOMER(CUSTOMERID,SITEID,ACTIVE,APPLYGST,INTERNALCUSTOMER,"
			+ "ALLOWCONTPICKUPDROP,UNIQUELOADNO,NUMERICLOADNO,INVOICEREMARKSMODE) values (?,?,?,0,0,0,0,0,0) ";

	private static final String ID_KEY_GEN_SQL = "{ ? = call F_GENERATE_ID(?, ?) }";

	private static final String NATIVE_NOTIFICATION_CREATE = "INSERT INTO UTYHOME.NOTIFICATION (ID,ACTIONID,SITEID,SUBJECT,BODYTEXT,STAMP,SENT) "
			+ "VALUES (?,?,?,?,?,SYSTIMESTAMP,?) ";
	private static final String QUERY_NOTIFICATION_ACTION = "SELECT AG.ID GROUPID,AN.ID ACTIONID FROM utyhome.ACTION_GROUP AG "
			+ "LEFT JOIN utyhome.ACTION AN ON AG.ID=AN.GROUPID AND AN.ACTIONNAME=? WHERE AG.GROUPNAME=? ";
	private static final String QUERY_NEXT_ACTION_ID = "SELECT UTYHOME.ACTION_SEQ.NEXTVAL FROM DUAL ";
	private static final String QUERY_NEXT_ACTION_GROUP_ID = "select UTYHOME.ACTION_GROUP_SEQ.NEXTVAL FROM DUAL ";
	private static final String NATIVE_ACTION_CREATE = "INSERT INTO UTYHOME.ACTION (ID,GROUPID,ACTIONNAME) VALUES (?,?,?) ";
	private static final String NATIVE_ACTION_GROUP_CREATE = "INSERT INTO UTYHOME.ACTION_GROUP(ID,GROUPNAME) VALUES (?,?) ";

	private static final String QUERY_QTY_SERVICES_BY_ID = "SELECT ID,QTY1,QTY2,QTY3,QTY4,QTY5,QTY6,QTY7,QTY8,"
			+ "UNIT1,UNIT2,UNIT3,UNIT4,UNIT5,UNIT6,UNIT7,UNIT8,DELIVERED FROM SERVICE WHERE SITEID=? AND ID=? ";

	private static final String NATIVE_UPDATE_SERVICE_QTY_DETAILS = "UPDATE SERVICE SET tripid=?, tripseq=?, servicedesc=?,"
			+ "window1from=?,window1to=?,window2from=?,window2to=?,"
			+ "Qty1=?,Unit1=?,Qty2=?,Unit2=?,Qty3=?,Unit3=?,Qty4=?,Unit4=?,Qty5=?,Unit5=?,Qty6=?,Unit6=?,Qty7=?,Unit7=?,Qty8=?,Unit8=? "
			+ " where id=?";

	private static final String QUERY_RETURN_DECISION = "Select CREATIONID from RETURN_DECISION where "
			+ "((ServiceType is Null) or (ServiceType=?)) AND " + "((LoadType is Null) or (LoadType=?)) AND "
			+ "((LocationID_Drop is Null) or (LocationID_Drop=?)) AND "
			+ "((LocationType_Drop is Null) or (LocationType_Drop=?)) AND "
			+ "((CustomerID is Null) or (CustomerID=?)) AND "
			+ "((ContainerPrefix is Null) or (? LIKE '%'||ContainerPrefix)) AND "
			+ "((ContainerType is Null) or (ContainerType=?)) AND "
			+ "((ContainerCompany is Null) or (ContainerCompany=?)) AND " + "(LastLeg=?) ";

	private static final String QUERY_RETURN_CREATION = "SELECT ID,SITEID,LOCATIONID_DROP,SERVICETYPE,LOADTYPE,"
			+ "UNIT1,QTY1,UNIT2,QTY2,UNIT3,QTY3,UNIT4,QTY4,UNIT5,QTY5,UNIT6,QTY6,UNIT7,QTY7,UNIT8,QTY8 "
			+ "from RETURN_CREATION WHERE ID=?";

	private static final String QUERY_UPDATE_LOCATION = "UPDATE LOCATION SET LOCATIONID=? WHERE LOCATIONID=null";

	private static final String QUERY_SERVICE_LOAD = "Select L.*, nvl(CM.Customerid,'NOCUSTOMER') AS CUSTOMERID from CustLoad L left join Consignment_master CM on CM.Id=L.MasterID and CM.SiteID_ORigin=L.SiteID "
			+ " where L.SiteID=?and L.id=? ";

	private static final String QUERY_SERVICE_LOAD_REBUILD = "Select Set1.* , s.id as serviceid, S.Complete ServiceComplete,T.Despatch,S.* from SERVICE S LEFT JOIN TRIP T ON T.ID=S.TRIPID AND T.SITEID=S.SITEID, "
			+ "(" + QUERY_SERVICE_LOAD + ") Set1 where S.SiteID=Set1.SiteId and S.LoadId=Set1.ID";

	private static final String TRAIN_VALID_DRIVER_QUERY = "SELECT ES.ID FROM EMPLOYEE_SITE ES INNER JOIN PERSON P ON ES.EmployeeId=P.ID"
			+ "WHERE ES.SITEID=? AND P.FirstName=?";

	private static final String QUERY_SERVICE_LOAD_REBUILD_PICKUP = "Select Set1.* ,s.id as serviceid, S.* from SERVICE S LEFT JOIN TRIP T ON T.ID=S.TRIPID AND T.SITEID=S.SITEID, "
			+ "(" + QUERY_SERVICE_LOAD + ") Set1 where S.SiteID=Set1.SiteId and S.LoadId=Set1.ID and "
			+ " (NVL(?,'NULLVALUE')=NVL(S.LOCATIONID_PICKUP,'NULLVALUE') or " + " NVL(?,'NULLVALUE')='NULLVALUE')";

	private static final String QUERY_SERVICE_RETURN_DETAILS = "select S.ID,D.HOMELOCATIONID,S.LOADID,S.LOCATIONID_DROP,S.LOCATIONID_PICKUP,"
			+ "S.UNIT1,S.QTY1,S.UNIT2,S.QTY2,S.UNIT3,S.QTY3,S.UNIT4,S.QTY4,S.UNIT5,S.QTY5,S.UNIT6,S.QTY6,S.UNIT7,S.QTY7,S.UNIT8,S.QTY8,"
			+ "S.SERVICENO,S.TRIPID,S.SITEID,S.SERVICEDATE,S.SERVICEDESC,S.CUSTOMERID,S.DRIVERID,S.TRUCKID,S.TRAILERID,S.CONTAINERID,"
			+ "S.OFFSIDERUSED,S.DOCKET,S.TRAILERID_TAG,S.LOADTYPEID,S.SERVICETYPEID,S.ENTEREDBY "
			+ "FROM SERVICE S LEFT JOIN (SELECT ES.ID AS DRIVERID, ES.HOMELOCATIONID FROM DRIVER "
			+ "LEFT JOIN EMPLOYEE_SITE ES ON ES.ID=DRIVER.ID ) D ON D.DRIVERID=S.DRIVERID "
			+ "WHERE S.ID=? AND S.SITEID=? ";
	private static final String FIND_DRIVER = "SELECT EMPLOYEE_SITE.* FROM DRIVER JOIN EMPLOYEE_SITE ON DRIVER.ID=EMPLOYEE_SITE.EMPLOYEEID ";

	private static final String QUERY_SERVICE_TRIP_UPDATE = "UPDATE TRIP SET PlannedStartTime=?, PlannedFinishTime=? WHERE ID=?";

	private static final String LOCATION_QUERY = "SELECT * FROM LOCATION WHERE LocationId=? AND SiteId=?";

	// private static final String QUERY_SERVICE_TRIP_UPDATE="UPDATE TRIP SET
	// PlannedStartTime=?, PlannedFinishTime=? WHERE ID=?" ;

	private static final String NQ_INSERT_LOCATION = "INSERT INTO LOCATION(siteId,locationId,locationTypeId,locationDesc,LocationCode,window1From,window1To,window2From,window2To,zonePayId,zoneChargeId,Latitude,Longitude,Geofence,MapSourceId,MapReference,Address1,Address2,Suburb,State,PostCode,Remarks,TruckSizeLimit,DefaultTripSeq,RouteId,Permanent) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String MULTILEG_QUERYFOR_VERIFYLOAD = "SELECT * FROM axiomimp.IMP_MULTILEG WHERE ImportId=?";

	private static final String QUERY_OBTAIN_SERVICES_BY_ID = "SELECT * FROM SERVICE WHERE ID=? ";

	private static final String QUERY_EXISTING_LOAD_RECORD = "SELECT T.DESPATCH,RS.RUNSHEETID,S.ID SERVICEID, S.TRIPID, CL.ID AS LOADID, "
			+ "CM.ID CONSIGNMENTID, CL.LOADNO, CL.LOADTYPEID, CL.IMPORTEDBY, CL.HOLDCODE, CL.COMPLETE, CL.SCHEDULEDDATE, CM.CUSTOMERID, "
			+ "CM.BATCHNO, CM.CUSTREFERENCE, CM.LOCATIONID, CM.CUSTCLAIMAMT, CM.SETTLEDATE, CM.REMARKS, CM.DATASOURCEID, CM.ENTEREDBY, "
			+ "CM.DESPATCHBY, CM.DELIVERYOPEN, CM.DELIVERYCLOSE, T.DRIVERID T_DRIVERID, T.TRUCKID T_TRUCKID, T.TRAILERID T_TRAILERID, "
			+ "T.TRAILERID_TAG T_TRAILERID_TAG, S.DRIVERID S_DRIVERID, S.TRUCKID S_TRUCKID, S.TRAILERID S_TRAILERID, S.TRAILERID_TAG S_TRAILERID_TAG, "
			+ "S.SERVICEDESC, S.LOCATIONID_DROP	FROM CUSTLOAD CL JOIN CONSIGNMENT_MASTER CM ON CL.MASTERID=CM.ID INNER JOIN SERVICE S ON CL.ID=S.LOADID "
			+ "LEFT JOIN TRIP T ON S.TRIPID=T.ID AND T.SITEID=S.SITEID LEFT JOIN RUNSHEET_LINE RS ON S.ID=RS.SERVICEID "
			+ "WHERE CL.LOADNO=? AND (S.DOCKET=? OR ?=1) AND CL.SITEID=? %%_FILTER%% "
			+ "ORDER BY CASE WHEN S.DOCKET=? THEN 1 WHEN ?=1 AND T.TRIPID_CUST=? THEN 2 WHEN ?=1 THEN 3 ELSE 4 END,S.ID ";
	// query to insert trip
	public static final String QUERY_INSERT_TRIP = "INSERT INTO TRIP (id,siteid,tripdate,routeid,driverid,truckid,trailerid,trailerid_tag,tripcomplete,plannedstarttime, planneddespatchtime,plannedreturntime,plannedfinishtime,settledate,locationid_despatch,locationid_return,enteredby,datasourceid,tripno,dockid,despatch,actualstarttime,actualreturntime,actualfinishtime,created,comments)values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	// Custload
	private static final String UPD_SCHED_DATE = "%%_SCHEDDATE%%";
	private static final String NATIVE_UPDATE_CUSTLOAD = "UPDATE CUSTLOAD SET " + UPD_SCHED_DATE
			+ "LOADNO=?,LOADTYPEID=?," + "IMPORTEDBY=? WHERE ID=? ";

	private static final String QUERY_DESPATCH_DECISION = "Select nvl(UsesTimeTable,0) as UsesTimeTable from DESPATCH_DECISION where "
			+ "((ServiceType is Null) or (ServiceType=?)) AND " + "((LoadType is Null) or (LoadType=?)) AND "
			+ "((DriverType is Null) or (DriverType=?)) AND " + "((DriverID is Null) or (DriverID=?)) AND "
			+ "((LocationID_Pickup is Null) or (LocationID_PickUp=?)) AND "
			+ "((LocationType_Pickup is Null) or (LocationType_PickUp=?)) AND "
			+ "((LocationID_Drop is Null) or (LocationID_Drop=?)) AND "
			+ "((LocationType_Drop is Null) or (LocationType_Drop=?)) AND "
			+ "((EnteredBy is Null) or (EnteredBy=?)) AND " + "SiteId=? ";

	private static final String QUERY_RAILDAYS = "select departdate from raildays where railcode=? or railcode=? ";

	// Consignment Master
	private static final String NATIVE_UPDATE_CONSIGNMENT = "UPDATE CONSIGNMENT_MASTER SET " + UPD_SCHED_DATE
			+ "LOADNO=?, CUSTOMERID=?,BATCHNO=?,LOCATIONID=?,ENTEREDBY=? " + "WHERE ID=? ";

	private static final String UPDATE_IMP_SERVICE_STATUS = "UPDATE axiomimp.IMP_SERVICE SET Imported=-1, ImportServiceId=? WHERE ImportId=?";

	// Service
	private static final String UPD_SVC_DATE = "%%_SERVICEDATE%%";
	private static final String UPD_DRIVER = "%%_DRIVER%%";
	private static final String UPD_TRUCK = "%%_TRUCK%%";
	private static final String UPD_TRAILER = "%%_TRAILER%%";
	private static final String UPD_TRAILERTAG = "%%_TRAILERTAG%%";
	private static final String UPD_SVC_DESC = "%%_SVCDESC%%";
	private static final String NATIVE_UPDATE_SERVICE = "UPDATE SERVICE SET " + UPD_SVC_DATE + UPD_DRIVER + UPD_TRUCK
			+ UPD_TRAILER + UPD_TRAILERTAG + UPD_SVC_DESC
			+ "Qty1=?,Unit1=?,Qty2=?,Unit2=?,Qty3=?,Unit3=?,Qty4=?,Unit4=?,Qty5=?,Unit5=?,Qty6=?,Unit6=?,Qty7=?,Unit7=?,Qty8=?,Unit8=?,"
			+ "LocationId_Pickup=?,LocationId_Drop=?,Window1From=?,Window1To=?,Window2From=?,Window2To=?,LoadTypeId=?,ServiceTypeId=?,"
			+ "CustomerId=?,Remarks=?,Docket=?,EnteredBy=? WHERE ID=? ";

	private static final String QUERY_TRIP_BY_TRIPNO = "SELECT ID,DESPATCH,DRIVERID,TRUCKID,TRAILERID,TRAILERID_TAG FROM TRIP "
			+ "WHERE TRIPID_CUST=? AND SITEID=? ORDER BY TRIPDATE DESC";

	private static final String QUERY_TRIP_COUNT_BY_ID = "select count(1) from trip where id=? ";

	private static final String QUERY_NEXT_TRIP_SEQ = "select nvl(max(tripseq),1) as NextTripSeq from Service where siteid=? and tripid=? ";

	private static final String QUERY_GET_UNIT = "Select * from Unit where siteid=? and UnitId=?";

	private static final String QUERY_GET_DRIVERTYPE_COUNT = "Select count(id) as cId from employee_site es where upper(companyid) in ('TOLL', 'TOLL PERM') and id=?";

	private static final String QUERY_OBTAIN_SERVICES_BY_TRIP = "SELECT ID,QTY1,QTY2,QTY3,QTY4,QTY5,QTY6,QTY7,QTY8,"
			+ "UNIT1,UNIT2,UNIT3,UNIT4,UNIT5,UNIT6,UNIT7,UNIT8 FROM SERVICE WHERE TRIPID=? ";

	public static final String QUERT_OBTAIN_TRUCK_TRAILER_CAPACITY = "SELECT TRUCK.RouteCapacity As TruckCapacity, TRAILER1.RouteCapacity  As Trailer1Capacity, "
			+ "TRAILER2.RouteCapacity As Trailer2Capacity "
			+ "FROM TRIP LEFT JOIN TRUCK ON TRIP.TRUCKID=TRUCK.TRUCKID LEFT JOIN TRAILER AS TRAILER1 "
			+ "ON TRIP.TRAILERID=TRAILER1.TRAILERID LEFT JOIN TRAILER AS TRAILER2 ON "
			+ "TRIP.TRAILERID_TAG=TRAILER2.TRAILERID WHERE TRIP.TRIPID=?";

	public static final String QUERT_UPDATE_AGGREGATE_CAPACITY = "  UPDATE TRIP SET CachedRoutingQty=?, "
			+ "CachedTruckCapacity=?, CachedTrailerCapacity=? WHERE TRIPID=?";
	public static String QUERY_WINDOW = "SELECT WINDOW1FROM, WINDOW1TO, WINDOW2FROM, WINDOW2TO, WINDOW3FROM, WINDOW3TO "
			+ "FROM WINDOW " + "WHERE LOCATIONID=? " + "AND (LOADTYPEID=? OR LOADTYPEID IS NULL) %tStFilter%"
			+ "AND (LOCATIONID_PICKUP=? OR LOCATIONID_PICKUP IS NULL) "
			+ "AND (CUSTOMERID=? OR CUSTOMERID IS NULL) " + "AND (WINDOWDAY IS NULL OR WINDOWDAY=?) "
			+ "AND (EFFECTIVEDATE_FROM IS NULL OR ? >= EFFECTIVEDATE_FROM) "
			+ "AND (EFFECTIVEDATE_TO IS NULL OR ? <= EFFECTIVEDATE_TO) " + "ORDER BY SERVICETYPEID DESC";


//	public void rejectImpService(long id, String error, int imported)
//			throws SQLException, NotImplementedException {

//	private static final String QUERY_GET_UNIT = "Select * from Unit where siteid=? and UnitId=?";
//
//	private static final String QUERY_GET_DRIVERTYPE_COUNT = "Select count(id) as cId from employee_site es where upper(companyid) in ('TOLL', 'TOLL PERM') and id=?";

	public void rejectImpService(long id, String error, int imported) throws SQLException, NotImplementedException {

		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, REJECT_IMP_SERVICE);
			stmt.setString(1, error);
			stmt.setInt(2, imported);
			stmt.setLong(3, id);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public boolean isSiteMultilegEnabled(long siteId) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = prepareStatement(conn, QUERY_MULTILEG_ENABLED_SITE, siteId);
			rs = pstmt.executeQuery();
			int count = 0;
			if (rs.next()) {
				count = rs.getInt(1);
			}
			return count > 0 ? true : false;
		} finally {
			closeConn(conn, pstmt, rs);
		}
	}

	public List<ImpServiceTO> getImportServicesBySite(long siteId, boolean multiLegOnly)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String siteTimeZone = ApplicationOptionsDAO.getTimeZone(siteId);

		List<ImpServiceTO> svcs = new ArrayList<ImpServiceTO>();
		try {
			conn = getConnection();
			String sql = "";
			if (multiLegOnly) {
				sql = QUERY_IMP_SERVICE_MULTILEG_ONLY;
			} else {
				sql = QUERY_IMP_SERVICE_FOR_IMPORT;
			}
			stmt = prepareStatement(conn, sql, siteId);
			rs = stmt.executeQuery();

			while (rs.next()) {
				ImpServiceTO svc = mapImpServiceResultSetToTO(rs);
				svcs.add(svc);
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return svcs;
	}

	public List<CustomerTO> custListService(String customerId, long siteid)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<CustomerTO> custlist = new ArrayList<CustomerTO>();
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, CUSTOMER_SERVICE_LIST);
			stmt.setString(1, customerId);
			stmt.setLong(2, siteid);
			rs = stmt.executeQuery();

			while (rs.next()) {
				CustomerTO cust = mapCustomerToCustomerTO(rs);
				custlist.add(cust);
			}
			return custlist;
		} finally {
			closeConn(conn, stmt);
		}
	}

	public CustomerTO addCustomerWithMinimalData(CustomerTO customer) throws SQLException, NotImplementedException {
		if (customer == null || customer.getCUSTOMERID() == null || customer.getACTIVE() == null) {
			return null;
		}
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		try {

			stmt = prepareStatement(conn, NQ_INSERT_MINIMAL, customer.getCUSTOMERID(), customer.getSITEID(),
					customer.getACTIVE());
			int rows = stmt.executeUpdate();
			if (rows != 1) {
				customer = null;
			}
			return customer;
		} finally {
			closeConn(conn, stmt);
		}
	}

	private ImpServiceTO mapImpServiceResultSetToTO(ResultSet rs) throws SQLException {
		if (rs == null) {
			return null;
		}

		int i = 0;
		ImpServiceTO svc = new ImpServiceTO();
		svc.setImportId(getLong(++i, rs));
		Long siteId = getLong(++i, rs);
		svc.setSiteId(siteId);
		svc.setImportDateTime(getConvertedTimestamp(siteId, ++i, rs));
		svc.setImportSource(getString(++i, rs));
		svc.setImportComments(getString(++i, rs));
		svc.setServiceType(getString(++i, rs));

		// NOTE: The service date should not be converted yet
		svc.setServiceDate(getConvertedTimestamp(siteId, ++i, rs));
		// svc.setServiceDate(getTimestamp(++i, rs));

		svc.setServiceDesc(getString(++i, rs));
		svc.setCustomerId(getString(++i, rs));
		svc.setLoadType(getString(++i, rs));
		svc.setDriverId(getLong(++i, rs));
		svc.setTruckId(getString(++i, rs));
		svc.setTrailerId(getString(++i, rs));
		svc.setTrailerIdTag(getString(++i, rs));
		svc.setContainerId(getString(++i, rs));
		svc.setLocationIdPickup(getString(++i, rs));
		svc.setLocationIdDrop(getString(++i, rs));
		svc.setQty1(getDouble(++i, rs));
		svc.setUnit1(getString(++i, rs));
		svc.setQty2(getDouble(++i, rs));
		svc.setUnit2(getString(++i, rs));
		svc.setQty3(getDouble(++i, rs));
		svc.setUnit3(getString(++i, rs));
		svc.setQty4(getDouble(++i, rs));
		svc.setUnit4(getString(++i, rs));
		svc.setQty5(getDouble(++i, rs));
		svc.setUnit5(getString(++i, rs));
		svc.setQty6(getDouble(++i, rs));
		svc.setUnit6(getString(++i, rs));
		svc.setQty7(getDouble(++i, rs));
		svc.setUnit7(getString(++i, rs));
		svc.setQty8(getDouble(++i, rs));
		svc.setUnit8(getString(++i, rs));
		svc.setDocket(getString(++i, rs));
		svc.setRemarksService(getString(++i, rs));
		svc.setDelivered(getIntAsAxiomBool(++i, rs));
		svc.setWindow1From(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow1To(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2From(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2To(getConvertedTimestamp(siteId, ++i, rs));
		svc.setBatchNo(getString(++i, rs));
		svc.setCustReference(getString(++i, rs));
		svc.setScheduledDate(getConvertedTimestamp(siteId, ++i, rs));
		svc.setLoadNo(getString(++i, rs));
		svc.setLocationIdLoad(getString(++i, rs));
		svc.setCustClaimAmt(getDouble(++i, rs));
		svc.setSettleDate(getConvertedTimestamp(siteId, ++i, rs));
		svc.setRemarksLoad(getString(++i, rs));
		svc.setLocationTypeDrop(getString(++i, rs));
		svc.setLocationDescDrop(getString(++i, rs));
		svc.setPersonIdDrop(getLong(++i, rs));
		svc.setCustomerIdDrop(getString(++i, rs));
		svc.setLocationCodeDrop(getString(++i, rs));
		svc.setWindow1FromDrop(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow1ToDrop(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2FromDrop(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2ToDrop(getConvertedTimestamp(siteId, ++i, rs));
		svc.setPayZoneIdDrop(getString(++i, rs));
		svc.setChargeZoneIdDrop(getString(++i, rs));
		svc.setLatitudeDrop(getDouble(++i, rs));
		svc.setLongitudeDrop(getDouble(++i, rs));
		svc.setGeofenceDrop(getInt(++i, rs));
		svc.setMapSourceIdDrop(getString(++i, rs));
		svc.setMapReferenceDrop(getString(++i, rs));
		svc.setAddress1Drop(getString(++i, rs));
		svc.setAddress2Drop(getString(++i, rs));
		svc.setSuburbDrop(getString(++i, rs));
		svc.setStateDrop(getString(++i, rs));
		svc.setPostCodeDrop(getString(++i, rs));
		svc.setRemarksDrop(getString(++i, rs));
		svc.setTruckSizeLimitDrop(getDouble(++i, rs));
		svc.setDefaultTripSeqDrop(getInt(++i, rs));
		svc.setRouteIdDrop(getString(++i, rs));
		svc.setPermanentDrop(getIntAsAxiomBool(++i, rs));
		svc.setContainerTypeCont(getString(++i, rs));
		svc.setContainerDescCont(getString(++i, rs));
		svc.setCompanyIdCont(getString(++i, rs));
		svc.setWeightTonnesCont(getDouble(++i, rs));
		svc.setPermanentCont(getIntAsAxiomBool(++i, rs));
		svc.setImportEnteredBy(getString(++i, rs));
		svc.setValidateLoad(getString(++i, rs));
		svc.setValidateCustomer(getString(++i, rs));
		svc.setValidateDrop(getString(++i, rs));
		svc.setValidateContainer(getString(++i, rs));
		svc.setPromptForServiceDate(getIntAsAxiomBool(++i, rs));
		svc.setValidatePickup(getString(++i, rs));
		svc.setValidateTruck(getString(++i, rs));
		svc.setValidateTrailer(getString(++i, rs));
		svc.setValidateTrailerTag(getString(++i, rs));
		svc.setValidateDriver(getString(++i, rs));
		svc.setValidatePayZone(getString(++i, rs));
		svc.setValidateChargeZone(getString(++i, rs));
		svc.setValidatePersonDrop(getString(++i, rs));
		svc.setValidateMapSource(getString(++i, rs));
		svc.setValidateLocationType(getString(++i, rs));
		svc.setValidateRoute(getString(++i, rs));
		svc.setValidateContainerType(getString(++i, rs));
		svc.setValidateCompanyCont(getString(++i, rs));
		svc.setValidateLoadType(getString(++i, rs));
		svc.setImported(getInt(++i, rs));
		svc.setImportError(getString(++i, rs));
		svc.setImportServiceId(getLong(++i, rs));
		svc.setValidateTrip(getString(++i, rs));
		svc.setTripId(getLong(++i, rs));
		svc.setTripSeq(getInt(++i, rs));
		svc.setValidateService(getString(++i, rs));
		svc.setDespatchBy(getConvertedTimestamp(siteId, ++i, rs));
		svc.setDeliveryOpen(getConvertedTimestamp(siteId, ++i, rs));
		svc.setDeliveryClose(getConvertedTimestamp(siteId, ++i, rs));
		svc.setServiceGroup(getString(++i, rs));
		svc.setTripNo(getString(++i, rs));
		svc.setValidateDespatch(getString(++i, rs));
		svc.setValidateReturn(getString(++i, rs));
		svc.setLocationIdDespatch(getString(++i, rs));
		svc.setLocationIdReturn(getString(++i, rs));
		svc.setPlannedStartTime(getConvertedTimestamp(siteId, ++i, rs));
		svc.setPlannedEndTime(getConvertedTimestamp(siteId, ++i, rs));
		svc.setLatitudePickup(getDouble(++i, rs));
		svc.setLongitudePickup(getDouble(++i, rs));
		svc.setLocationCode(getString(++i, rs));
		svc.setLocationDesc(getString(++i, rs));
		svc.setLocationType(getString(++i, rs));
		svc.setAddress1(getString(++i, rs));
		svc.setAddress2(getString(++i, rs));
		svc.setMapReference(getString(++i, rs));
		svc.setMapSourceId(getString(++i, rs));
		svc.setCustomerIdPickup(getString(++i, rs));
		svc.setPersonId(getLong(++i, rs));
		svc.setPostCode(getString(++i, rs));
		svc.setSuburb(getString(++i, rs));
		svc.setState(getString(++i, rs));
		svc.setTruckSizeLimitPickup(getDouble(++i, rs));
		svc.setPayZoneId(getString(++i, rs));
		svc.setChargeZoneId(getString(++i, rs));
		svc.setWindow1FromPickup(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow1ToPickup(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2FromPickup(getConvertedTimestamp(siteId, ++i, rs));
		svc.setWindow2ToPickup(getConvertedTimestamp(siteId, ++i, rs));
		svc.setGeofencePickup(getInt(++i, rs));
		svc.setPermanentPickup(getIntAsAxiomBool(++i, rs));
		svc.setRouteIdPickup(getString(++i, rs));
		svc.setDefaultTripSeqPickup(getInt(++i, rs));
		svc.setRemarksPickup(getString(++i, rs));
		svc.setServiceNo(getString(++i, rs));
		svc.setOriginSite(getLong(++i, rs));
		svc.setOriginLoc(getString(++i, rs));
		svc.setDestinationSite(getLong(++i, rs));
		svc.setDestinationLoc(getString(++i, rs));
		svc.setCreateTrip(getIntAsAxiomBool(++i, rs));
		svc.setLastModified(getConvertedTimestamp(siteId, ++i, rs));
		svc.setLocationIdFinish(getString(++i, rs));
		svc.setDockName(getLong(++i, rs));
		svc.setImportBatch(getLong(++i, rs));
		return svc;
	}

	private CustomerTO mapCustomerToCustomerTO(ResultSet rs) throws SQLException {
		if (rs == null) {
			return null;
		}

		CustomerTO cust = new CustomerTO();
		// mapping rs to to

		return cust;
	}

	public String nextKey(Long siteId, String tableName) throws SQLException, NotImplementedException {
		if ("CUSTLOAD".equals(tableName.toUpperCase()) || "CONSIGNMENT_MASTER".equals(tableName.toUpperCase())) {
			// Bloody axiom exceptions!
			tableName = "LOAD";
		}
		Connection conn = null;
		CallableStatement pstmt = null;
		String key = null;
		try {
			conn = getConnection();

			pstmt = callableStatement(conn, ID_KEY_GEN_SQL);
			pstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.VARCHAR);
			pstmt.setLong(2, siteId);
			pstmt.setString(3, tableName);

			pstmt.execute();

			key = pstmt.getString(1);

		} finally {
			closeConn(conn, pstmt);
		}

		return key;
	}

	@Autowired
	WindowTO windowTO;

	public List<WindowTO> setDeliveryWindow(String locationId, String loadType, String serviceType, Date serviceDate,
			String pickUp, String customer) throws SQLException, NotImplementedException {

		if (locationId.isEmpty())
			return null;
		if (loadType.isEmpty())
			return null;
		if (serviceType.isEmpty())
			return null;
		if (serviceDate == null)
			return null;

		List<WindowTO> userDeliverytypeList = new ArrayList<>();

		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.setTime(serviceDate);
		int dow = cal.get(java.util.Calendar.DAY_OF_WEEK);

		String tStFilter = "";
		if (!serviceType.isEmpty()) {
			tStFilter = "AND (SERVICETYPEID IS NULL OR SERVICETYPEID=' " + serviceType + " ') ";
		}

		QUERY_WINDOW = QUERY_WINDOW.replace("%tStFilter%", tStFilter);
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {

			conn = getConnection();
			statement = prepareStatement(conn, QUERY_WINDOW);

			statement.setString(1, locationId);
			statement.setString(2, loadType);
			statement.setString(3, pickUp);
			statement.setString(5, customer);
			statement.setInt(6, dow);
			statement.setDate(7, new java.sql.Date(serviceDate.getTime()));
			statement.setDate(8, new java.sql.Date(serviceDate.getTime()));

			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				windowTO.setWindow1From(new Date(resultSet.getTimestamp("WINDOW1FROM").getTime()));
				windowTO.setWindow1To(new Date(resultSet.getTimestamp("WINDOW1TO").getTime()));
				windowTO.setWindow2From(new Date(resultSet.getTimestamp("WINDOW2FROM").getTime()));
				windowTO.setWindow2To(new Date(resultSet.getTimestamp("WINDOW2TO").getTime()));
				windowTO.setWindow3From(new Date(resultSet.getTimestamp("WINDOW3FROM").getTime()));
				windowTO.setWindow3To(new Date(resultSet.getTimestamp("WINDOW3TO").getTime()));
				userDeliverytypeList.add(windowTO);
			} else {

				// Not found - look for default window in location table
				statement.clearParameters();
				statement.setString(1, locationId);
				resultSet = statement.executeQuery();
				if (resultSet.next()) {
					windowTO.setWindow1From(new Date(resultSet.getTimestamp("WINDOW1FROM").getTime()));
					windowTO.setWindow1To(new Date(resultSet.getTimestamp("WINDOW1TO").getTime()));
					windowTO.setWindow2From(new Date(resultSet.getTimestamp("WINDOW2FROM").getTime()));
					windowTO.setWindow2To(new Date(resultSet.getTimestamp("WINDOW2TO").getTime()));
					windowTO.setWindow3From(new Date(resultSet.getTimestamp("WINDOW3FROM").getTime()));
					windowTO.setWindow3To(new Date(resultSet.getTimestamp("WINDOW3TO").getTime()));
					userDeliverytypeList.add(windowTO);
				}

			}
			return userDeliverytypeList;
		} finally {
			closeConn(conn, statement, rs);
		}

	}

	/**
	 * Generate the id
	 * 
	 * @param Type of id generator
	 * @return the id
	 * @throws SQLException
	 * @throws NotImplementedException
	 */

	public long generateID(String IDGenerator) throws SQLException, NotImplementedException {

		long id = -1;
		String sql = "Select " + IDGenerator + ".nextval as NewValue from dual";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			pstmt = prepareStatement(conn, sql);
			rs = pstmt.executeQuery();
			if (!rs.next()) {
				return id;
			} else {
				id = rs.getLong("NewValue");
			}

		} finally {
			closeConn(conn, pstmt, rs);
		}
		return id;
	}

	public ServiceTO insertImportServices(ServiceTO service, long siteId, String sequenceName)
			throws SQLException, NotImplementedException, IOException {

		String INSERT_TABLE_NAME = "SERVICE";
		List<String> columnval = new LinkedList<String>();

		columnval.add("ServiceGroup");
		columnval.add("LoadId");
		columnval.add("ServiceDate");
		columnval.add("ServiceTypeID");
		columnval.add("ServiceDesc");
		columnval.add("CustomerId");
		columnval.add("LoadTypeID");
		columnval.add("DriverId");
		columnval.add("Truckid");
		columnval.add("TrailerId");
		columnval.add("TrailerId_Tag");
		columnval.add("ContainerId");
		columnval.add("LocationId_Pickup");
		columnval.add("LocationId_Drop");
		columnval.add("Docket");
		columnval.add("TripId");
		columnval.add("TripSeq");
		columnval.add("Remarks");
		columnval.add("Delivered");
		columnval.add("Window1From");
		columnval.add("Window1To");
		columnval.add("Window2From");
		columnval.add("Window2To");
		columnval.add("EnteredBy");
		columnval.add("Siteid");
		columnval.add("ID");
		columnval.add("ServiceNo");

		String insertsql = ServiceUtil.createinsertQuery(INSERT_TABLE_NAME, columnval);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// String serviceno=nextKey(siteId,INSERT_TABLE_NAME);
		try {
			conn = getConnection();
			pstmt = prepareStatement(conn, insertsql);
			long id = getNextSequenceNumber(sequenceName, conn);

			pstmt.setString(1, service.getServiceGroup());
			pstmt.setLong(2, service.getLoadId());
			pstmt.setTimestamp(3, ServiceUtil.convertDateToTimeStamp(service.getServiceDate()));
			pstmt.setString(4, service.getServiceTypeId());
			pstmt.setString(5, service.getServiceDesc());
			pstmt.setString(6, service.getCustomerId());
			pstmt.setString(7, service.getLoadTypeId());
			pstmt.setLong(8, service.getDriverId());
			pstmt.setString(9, service.getTruckId());
			pstmt.setString(10, service.getTrailerId());
			pstmt.setString(11, service.getTrailerIdTag());
			pstmt.setString(12, service.getContainerId());
			pstmt.setString(13, service.getLocationIdPickup());
			pstmt.setString(14, service.getLocationIdDrop());
			//
			pstmt.setString(15, service.getDocket());
			pstmt.setLong(16, service.getTripId());
			pstmt.setLong(17, service.getTripSeq());
			pstmt.setString(18, service.getRemarks());
			pstmt.setBoolean(19, service.getDelivered());
			pstmt.setTimestamp(20, ServiceUtil.convertDateToTimeStamp(service.getWindow1From()));
			pstmt.setTimestamp(21, ServiceUtil.convertDateToTimeStamp(service.getWindow1To()));
			pstmt.setTimestamp(22, ServiceUtil.convertDateToTimeStamp(service.getWindow2From()));
			pstmt.setTimestamp(23, ServiceUtil.convertDateToTimeStamp(service.getWindow2To()));
			pstmt.setString(24, service.getEnteredBy());
			pstmt.setLong(25, service.getSiteId());
			pstmt.setLong(26, id);
			pstmt.setString(27, service.getServiceNo());
			int rows = pstmt.executeUpdate();
			if (rows > 0) {
				service.setId(id);
			}
			return service;

		} finally {
			closeConn(conn, pstmt, rs);
		}
	}

	public void makeNotification(Integer actionId, long siteId, String subject, String message, Boolean sent)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			long id = getNextSequenceNumber("utyhome.NOTIFICATION_SEQ", conn);

			stmt = prepareStatement(conn, NATIVE_NOTIFICATION_CREATE, id, actionId, siteId, subject, message, sent);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}

	}

	public void createNotification(String action, String group, long siteId, String subject, String message,
			Boolean sent) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_NOTIFICATION_ACTION, action, group);
			rs = stmt.executeQuery();
			Long groupId = null;
			Long actionId = null;
			while (rs.next()) {
				groupId = getLong(1, rs);
				actionId = getLong(2, rs);
			}
			closeResultSet(rs);
			closeStatement(stmt);

			if (groupId == null) {
				// get next group id
				stmt = prepareStatement(conn, QUERY_NEXT_ACTION_GROUP_ID);
				rs = stmt.executeQuery();
				while (rs.next()) {
					groupId = getLong(1, rs);
				}
				closeResultSet(rs);
				closeStatement(stmt);
				// create new group
				stmt = prepareStatement(conn, NATIVE_ACTION_GROUP_CREATE, groupId, group);
				stmt.executeUpdate();
				closeStatement(stmt);
			}
			if (actionId == null) {
				// get next action id
				stmt = prepareStatement(conn, QUERY_NEXT_ACTION_ID);
				rs = stmt.executeQuery();
				while (rs.next()) {
					actionId = getLong(1, rs);
				}
				closeResultSet(rs);
				closeStatement(stmt);
				// create new action
				stmt = prepareStatement(conn, NATIVE_ACTION_CREATE, actionId, groupId, action);
				stmt.executeUpdate();
				closeStatement(stmt);
			}
			stmt = prepareStatement(conn, NATIVE_NOTIFICATION_CREATE, actionId, siteId, subject, message, sent);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public AxiomServiceTO getServiceById(long siteId, long serviceId) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_OBTAIN_SERVICES_BY_ID, siteId, serviceId);
			rs = stmt.executeQuery();
			AxiomServiceTO svc = null;
			while (rs.next()) {
				int i = 0;
				svc = new AxiomServiceTO();
				svc.setId(getLong(++i, rs));
				svc.setQty1(getDouble(++i, rs));
				svc.setQty2(getDouble(++i, rs));
				svc.setQty3(getDouble(++i, rs));
				svc.setQty4(getDouble(++i, rs));
				svc.setQty5(getDouble(++i, rs));
				svc.setQty6(getDouble(++i, rs));
				svc.setQty7(getDouble(++i, rs));
				svc.setQty8(getDouble(++i, rs));
				svc.setUnit1(getString(++i, rs));
				svc.setUnit2(getString(++i, rs));
				svc.setUnit3(getString(++i, rs));
				svc.setUnit4(getString(++i, rs));
				svc.setUnit5(getString(++i, rs));
				svc.setUnit6(getString(++i, rs));
				svc.setUnit7(getString(++i, rs));
				svc.setUnit8(getString(++i, rs));
				svc.setDelivered(getIntAsAxiomBool(++i, rs));
			}
			return svc;
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public void updateServiceQtyDetails(ImpServiceTO impSvc, long siteId, long serviceId, Long tripId, Integer tripSeq)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, NATIVE_UPDATE_SERVICE_QTY_DETAILS);

			int i = 0;
			stmt.setLong(++i, tripId);
			stmt.setInt(++i, tripSeq);
			stmt.setString(++i, impSvc.getRemarksService());

			// these windows times need to be converted back to local time
			Date win1From = TimeUtil.convertToAxiomDate(impSvc.getWindow1From(), siteId);
			Date win2From = TimeUtil.convertToAxiomDate(impSvc.getWindow2From(), siteId);
			Date win1To = TimeUtil.convertToAxiomDate(impSvc.getWindow1To(), siteId);
			Date win2To = TimeUtil.convertToAxiomDate(impSvc.getWindow2To(), siteId);
			if (win1From == null) {
				stmt.setNull(++i, Types.NULL);
			} else {
				stmt.setTimestamp(++i, new Timestamp(win1From.getTime()));
			}
			if (win1To == null) {
				stmt.setNull(++i, Types.NULL);
			} else {
				stmt.setTimestamp(++i, new Timestamp(win1To.getTime()));
			}
			if (win2From == null) {
				stmt.setNull(++i, Types.NULL);
			} else {
				stmt.setTimestamp(++i, new Timestamp(win2From.getTime()));
			}
			if (win2To == null) {
				stmt.setNull(++i, Types.NULL);
			} else {
				stmt.setTimestamp(++i, new Timestamp(win2To.getTime()));
			}

			addParameter(stmt, ++i, impSvc.getQty1());
			addParameter(stmt, ++i, impSvc.getQty2());
			addParameter(stmt, ++i, impSvc.getQty3());
			addParameter(stmt, ++i, impSvc.getQty4());
			addParameter(stmt, ++i, impSvc.getQty5());
			addParameter(stmt, ++i, impSvc.getQty6());
			addParameter(stmt, ++i, impSvc.getQty7());
			addParameter(stmt, ++i, impSvc.getQty8());
			addParameter(stmt, ++i, serviceId);
			int row = stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public Long getCreationID(ImpServiceTO svc, boolean isLastLeg) throws SQLException, NotImplementedException {
		List<Long> ids = new LinkedList<>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Long creationId = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_RETURN_DECISION, svc.getServiceType(), svc.getLoadType(),
					svc.getLocationIdDrop(), svc.getLocationTypeDrop(), svc.getCustomerId(), svc.getContainerId(),
					svc.getContainerTypeCont(), svc.getCompanyIdCont(), isLastLeg);
			rs = stmt.executeQuery();
			while (rs.next()) {
				creationId = getLong(1, rs);
				// ids.add(creationId);

			}
			return creationId;
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public ReturnCreationTO getReturnCreationById(long id) throws SQLException, NotImplementedException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ReturnCreationTO to = null;

		try {
			stmt = prepareStatement(conn, QUERY_RETURN_CREATION, id);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 0;
				to = new ReturnCreationTO();
				to.setId(getLong(++i, rs));
				to.setSiteId(getLong(++i, rs));
				to.setLocationIdDrop(getString(++i, rs));
				to.setServiceType(getString(++i, rs));
				to.setLoadType(getString(++i, rs));
				to.setUnit1(getString(++i, rs));
				to.setQty1(getString(++i, rs));
				to.setUnit2(getString(++i, rs));
				to.setQty2(getString(++i, rs));
				to.setUnit3(getString(++i, rs));
				to.setQty3(getString(++i, rs));
				to.setUnit4(getString(++i, rs));
				to.setQty4(getString(++i, rs));
				to.setUnit5(getString(++i, rs));
				to.setQty5(getString(++i, rs));
				to.setUnit6(getString(++i, rs));
				to.setQty6(getString(++i, rs));
				to.setUnit7(getString(++i, rs));
				to.setQty7(getString(++i, rs));
				to.setUnit8(getString(++i, rs));
				to.setQty8(getString(++i, rs));
				break;
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return to;
	}

//////////////////////////////////////////////VALID - COLOUM - VALUE////////////////////////////////////////////////////////////////////////////////////////////////
	public List<Object> validColumnValue(String inKeyName, String inTableName, String tSid, String inKeyValue,long siteID)
			throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet tRs = null;

		try {
			conn = dataSource.getConnection();
			String query = "SELECT " + inKeyName + " FROM " + inTableName + " WHERE " + inKeyName + "= ? " + tSid;
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, inKeyValue); // Set the parameter value
			pstmt.setLong(2, siteID);
			
			tRs = pstmt.executeQuery();

			List<Object> objectTO = new ArrayList<>();

			if (inTableName.equals("LOAD_TYPE")) {

				while (tRs.next()) {
					LoadTO loadTO = new LoadTO();
					loadTO.setLoadTypeId(tRs.getString("LoadTypeID"));
					objectTO.add(loadTO);
				}
				return objectTO;
			} else if (inTableName.equals("LOCATION")) {
				while (tRs.next()) {
					LocationTO locationTO = new LocationTO();
					locationTO.setLocationId(tRs.getString("LocationID"));
					objectTO.add(locationTO);
				}
				return objectTO;
			} else if (inTableName.equals("TRUCK")) {
				while (tRs.next()) {
					TruckResourceTO truckTo = new TruckResourceTO();
					truckTo.setTruckId(tRs.getString("TruckID"));
					objectTO.add(truckTo);
				}
				return objectTO;
			} else if (inTableName.equals("TRAILER")) {
				while (tRs.next()) {
					TrailerResourceTO trailerTo = new TrailerResourceTO();
					trailerTo.setTrailerId(tRs.getString("TrailerID"));
					trailerTo.setTrailerIdTag(tRs.getString("TrailerIdTag"));
					objectTO.add(trailerTo);
				}
				return objectTO;
			}
		} finally {
			if (tRs != null) {
				tRs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

		return null;
	}

	public AxiomServiceReturnTO getServiceReturnDetailsById(long serviceId, long siteId)
			throws SQLException, NotImplementedException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		AxiomServiceReturnTO to = null;

		try {
			stmt = prepareStatement(conn, QUERY_SERVICE_RETURN_DETAILS, serviceId, siteId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 0;
				to = new AxiomServiceReturnTO();
				to.setId(getLong(++i, rs));
				to.setHomeLocationId(getString(++i, rs));
				to.setLoadId(getLong(++i, rs));
				to.setLocationIdDrop(getString(++i, rs));
				to.setLocationIdPickup(getString(++i, rs));
				to.setUnit1(getString(++i, rs));
				to.setQty1(getDouble(++i, rs));
				to.setUnit2(getString(++i, rs));
				to.setQty2(getDouble(++i, rs));
				to.setUnit3(getString(++i, rs));
				to.setQty3(getDouble(++i, rs));
				to.setUnit4(getString(++i, rs));
				to.setQty4(getDouble(++i, rs));
				to.setUnit5(getString(++i, rs));
				to.setQty5(getDouble(++i, rs));
				to.setUnit6(getString(++i, rs));
				to.setQty6(getDouble(++i, rs));
				to.setUnit7(getString(++i, rs));
				to.setQty7(getDouble(++i, rs));
				to.setUnit8(getString(++i, rs));
				to.setQty8(getDouble(++i, rs));
				to.setServiceNo(getString(++i, rs));
				to.setTripId(getLong(++i, rs));
				to.setSiteId(getLong(++i, rs));

				// convert service date to UTC
				// to.setServiceDate(getTimestamp(++i, rs));
				to.setServiceDate(getConvertedTimestamp(siteId, ++i, rs));

				to.setServiceDesc(getString(++i, rs));
				to.setCustomerId(getString(++i, rs));
				to.setDriverId(getLong(++i, rs));
				to.setTruckId(getString(++i, rs));
				to.setTrailerId(getString(++i, rs));
				to.setContainerId(getString(++i, rs));
				to.setOffsiderUsed(getIntAsAxiomBool(++i, rs));
				to.setDocket(getString(++i, rs));
				to.setTrailerIdTag(getString(++i, rs));
				to.setLoadTypeId(getString(++i, rs));
				to.setServiceTypeId(getString(++i, rs));
				to.setEnteredBy(getString(++i, rs));
				break;
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return to;
	}

	public List<ContainerTO> verifyContainer(ImpServiceTO rsImp, long SiteID) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM CONTAINER WHERE ContainerId=? AND SiteId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, rsImp.getContainerId());
			pstmt.setLong(2, SiteID);
			rs = pstmt.executeQuery();

			List<ContainerTO> containerTos = new ArrayList<>();

			while (rs.next()) {
				ContainerTO containerto = new ContainerTO();
				containerto.setCONTAINERID(rs.getString("CONTAINERID"));
				containerto.setSITEID(rs.getLong("SITEID"));
				containerto.setCONTAINERDESC(rs.getString("CONTAINERDESC"));
				containerto.setCOMPANYID(rs.getString("COMPANYID"));
				containerto.setONHIRE(rs.getLong("ONHIRE"));
				containerto.setLOCATIONID(rs.getString("LOCATIONID"));
				containerto.setDROPDATE(rs.getTimestamp("DROPDATE"));
				containerto.setPICKUPDATE(rs.getTimestamp("PICKUPDATE"));
				containerto.setWEIGHTTONNES(rs.getLong("WEIGHTTONNES"));
				containerto.setPERMANENT(rs.getLong("PERMANENT"));
				containerto.setCONTAINERSTATUSID(rs.getString("CONTAINERSTATUSID"));
				containerto.setSTATUSUPDATED(rs.getTimestamp("STATUSUPDATED"));

				containerTos.add(containerto);
			}
			return containerTos;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

	}

	public List<CompanyTO> ValidCompany(String inValue, long SiteID) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			String sql = "SELECT COMPANY.* FROM COMPANY " + "WHERE COMPANY.COMPANYID=? AND COMPANY.SITEID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, inValue);
			pstmt.setLong(2, SiteID);
			rs = pstmt.executeQuery();

			List<CompanyTO> companyTos = new ArrayList<>();

			while (rs.next()) {
				CompanyTO companyto = new CompanyTO();
				companyto.setCOMPANYID(rs.getString("COMPANYID"));
				companyto.setSITEID(rs.getLong("SITEID"));
				companyto.setCOMPANYTYPEID(rs.getString("COMPANYTYPEID"));
				companyto.setPERSONID(rs.getLong("PERSONID"));
				companyto.setCUSTOMERID(rs.getString("CUSTOMERID"));
				companyto.setACTIVE(rs.getLong("ACTIVE"));
				companyto.setPAFORMAT(rs.getLong("PAFORMAT"));
				companyto.setCONTAGREESIGHTBY(rs.getString("CONTAGREESIGHTBY"));
				companyto.setCONTAGREESIGHTDATE(rs.getTimestamp("CONTAGREESIGHTDATE"));

				companyTos.add(companyto);
			}
			return companyTos;

		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}

	public List<ServiceTypeTO> VerifyServiceType(String servicetype, long SiteID) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			String query = "SELECT * FROM SERVICE_TYPE WHERE ServiceTypeID = ? AND SiteId = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, servicetype);
			pstmt.setLong(2, SiteID);
			rs = pstmt.executeQuery();
			List<ServiceTypeTO> ServiceTypeTos = new ArrayList<>();

			while (rs.next()) {
				ServiceTypeTO serviceType = new ServiceTypeTO();
				serviceType.setUNIT1(rs.getString("UNIT1"));
				serviceType.setUNIT2(rs.getString("UNIT2"));
				serviceType.setUNIT3(rs.getString("UNIT3"));
				serviceType.setUNIT4(rs.getString("UNIT4"));
				serviceType.setUNIT5(rs.getString("UNIT5"));
				serviceType.setUNIT6(rs.getString("UNIT6"));
				serviceType.setUNIT7(rs.getString("UNIT7"));
				serviceType.setUNIT8(rs.getString("UNIT8"));

				ServiceTypeTos.add(serviceType);
			}
			return ServiceTypeTos;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}

	/**
	 * Maps result set to ImpLoadTO.
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private ImpLoadTO mapLoadRSToTO(ResultSet rs, long siteId) throws SQLException {
		if (rs == null) {
			return null;
		}

		int i = 0;
		ImpLoadTO load = new ImpLoadTO();

		// despatch column can return null so handle it here.
		Boolean tmpBool = getIntAsAxiomBool(++i, rs);
		load.setDespatch(tmpBool == null ? false : tmpBool);

		load.setRunsheetId(getLong(++i, rs));
		load.setServiceId(getLong(++i, rs));
		load.setTripId(getLong(++i, rs));
		load.setLoadId(getLong(++i, rs));
		load.setConsignmentId(getLong(++i, rs));
		load.setLoadNo(getString(++i, rs));
		load.setLoadTypeId(getString(++i, rs));
		load.setImportedBy(getString(++i, rs));
		load.setHoldCode(getString(++i, rs));

		tmpBool = getIntAsAxiomBool(++i, rs);
		load.setComplete(tmpBool == null ? false : tmpBool);

		load.setScheduledDate(getConvertedTimestamp(siteId, ++i, rs));
		load.setCustomerId(getString(++i, rs));
		load.setBatchNo(getString(++i, rs));
		load.setCustReference(getString(++i, rs));
		load.setLocationId(getString(++i, rs));
		load.setCustClaimAmt(getDouble(++i, rs));
		load.setSettleDate(getConvertedTimestamp(siteId, ++i, rs));
		load.setRemarks(getString(++i, rs));
		load.setDataSourceId(getString(++i, rs));
		load.setEnteredBy(getString(++i, rs));
		load.setDespatchBy(getConvertedTimestamp(siteId, ++i, rs));
		load.setDeliveryOpen(getConvertedTimestamp(siteId, ++i, rs));
		load.setDeliveryClose(getConvertedTimestamp(siteId, ++i, rs));
		load.settDriverId(getLong(++i, rs));
		load.settTruckId(getString(++i, rs));
		load.settTrailerId(getString(++i, rs));
		load.settTrailerIdTag(getString(++i, rs));
		load.setsDriverId(getLong(++i, rs));
		load.setsTruckId(getString(++i, rs));
		load.setsTrailerId(getString(++i, rs));
		load.setsTrailerIdTag(getString(++i, rs));
		load.setServiceDesc(getString(++i, rs));
		load.setLocationIdDrop(getString(++i, rs));

		return load;
	}

	public List<TripTO> VerifyTripRecycle(String tripNo, Timestamp ServiceDate) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			String query = "SELECT * FROM TRIP WHERE TRIPID_CUST=? AND TRIPDATE=? AND DESPATCH=0";
			pstmt = conn.prepareStatement(query);

			// Set the parameters
			pstmt.setString(1, tripNo);
			pstmt.setTimestamp(2, ServiceDate);

			rs = pstmt.executeQuery();
			List<TripTO> TripTos = new ArrayList<>();
			while (rs.next()) {
				TripTO tripto = new TripTO();
				tripto.setID(rs.getLong("ID"));

				TripTos.add(tripto);
			}
			return TripTos;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

	}

	public boolean traindriverService(String driverID, long siteid) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<DriverResourceTO> driverlist = new ArrayList<DriverResourceTO>();
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, TRAIN_VALID_DRIVER_QUERY);
			stmt.setLong(1, siteid);
			stmt.setString(2, driverID);
			rs = stmt.executeQuery();
			while (rs.next()) {
				return true;
			}
			return false;
		} finally {
			closeConn(conn, stmt);
		}
	}

	public void updateServiceTripDetails(ImpServiceTO impserv, long tripid)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_SERVICE_TRIP_UPDATE);
			stmt.setTimestamp(1, ServiceUtil.convertDateToTimeStamp(impserv.getPlannedStartTime()));
			stmt.setTimestamp(2, ServiceUtil.convertDateToTimeStamp(impserv.getPlannedEndTime()));
			stmt.setLong(3, tripid);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public ImpServiceTO getServiceById(long serviceId) throws SQLException, NotImplementedException {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rsSrve = null;
		ImpServiceTO exeServiceTO = null;
		conn = getConnection();

		try {
			stmt = prepareStatement(conn, QUERY_OBTAIN_SERVICES_BY_ID, serviceId);
			rsSrve = stmt.executeQuery();
			if (rsSrve.next()) {
				exeServiceTO = mapImpServiceResultSetToTO(rsSrve);
			}
			return exeServiceTO;
		} finally {

		}

	}

	public boolean findDriverService(String driverID, long siteid) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, FIND_DRIVER);
			stmt.setLong(1, siteid);
			stmt.setString(2, driverID);
			rs = stmt.executeQuery();

			while (rs.next()) {
				return true;
			}
			return false;
		} finally {
			closeConn(conn, stmt);
		}

	}

	public boolean locationInfo(String locationId, long siteid) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, LOCATION_QUERY);
			stmt.setString(1, locationId);
			stmt.setLong(2, siteid);
			rs = stmt.executeQuery();
			while (rs.next()) {
				return true;
			}
			return false;
		} finally {
			closeConn(conn, stmt);
		}
	}

	// insert into driver
	public LocationTO addLocationdata(LocationTO location) throws SQLException, NotImplementedException {
		if (location == null || location.getLocationId() == null) {
			return null;
		}
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = prepareStatement(conn, NQ_INSERT_LOCATION, location.getLocationId());
			int rows = stmt.executeUpdate();
			if (rows != 1) {
				location = null;
			}
			return location;
		} finally {
			closeConn(conn, stmt);
		}
	}

	public boolean locationUpdate(String locationId) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = getConnection();

			pstmt = prepareStatement(conn, QUERY_UPDATE_LOCATION, locationId);

			pstmt.executeUpdate();

		} finally {
			closeConn(conn, pstmt, rs);
		}
		return true;
	}

	public boolean verifyLoadService(String importId) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, MULTILEG_QUERYFOR_VERIFYLOAD);
			stmt.setString(1, importId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				return true;
			}
			return false;
		} finally {
			closeConn(conn, stmt);
		}
	}

	public List<ImpLoadTO> getExistingLoadRecord(String customerId, String loadNo, long siteId, Date scheduledDate)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		List<ImpLoadTO> loads = new ArrayList<ImpLoadTO>();
		String filter = "";
		if (scheduledDate != null) {
			filter = " CL.SCHEDULEDDATE=? ";
		}
		try {
			conn = getConnection();
			String sql = QUERY_EXISTING_LOAD_RECORD;
			if (filter != null && !filter.isEmpty()) {
				sql = sql.replace("%%_FILTER%%", filter);
			}
			if (scheduledDate == null) {
				stmt = prepareStatement(conn, sql, customerId, loadNo, siteId);
			} else {
				stmt = prepareStatement(conn, sql, customerId, loadNo, siteId, scheduledDate);
			}
			rs = stmt.executeQuery();

			while (rs.next()) {
				ImpLoadTO load = mapLoadRSToTO(rs, siteId);	
				loads.add(load);
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return loads;
	}

//	/**
//	 * Gets existing load record.
//	 * 
//	 * @param docket
//	 * @param tripSeq
//	 * @param shipment
//	 * @param siteId
//	 * @param scheduledDate
//	 * @return
//	 * @throws SQLException
//	 * @throws NotImplementedException
//	 */
//	public List<ImpLoadTO> getExistingLoadRecord(String docket, Integer tripSeq, String shipment, long siteId,
//			Date scheduledDate) throws SQLException, NotImplementedException {
//		Connection conn = null;
//		PreparedStatement stmt = null;
//		ResultSet rs = null;
//
//		List<ImpLoadTO> loads = new ArrayList<ImpLoadTO>();
//		String filter = "";
//		if (scheduledDate != null) {
//			filter = " CL.SCHEDULEDDATE=? ";
//		}
//		try {
//			conn = getConnection();
//			String sql = QUERY_EXISTING_LOAD_RECORD;
//			sql = sql.replace("%%_FILTER%%", filter);
//			if (scheduledDate == null) {
//				stmt = prepareStatement(conn, sql, shipment, docket, tripSeq, siteId, docket, tripSeq, shipment,
//						tripSeq);
//			} else {
//				stmt = prepareStatement(conn, sql, shipment, docket, tripSeq, siteId, scheduledDate, docket, tripSeq,
//						shipment, tripSeq);
//			}
//			rs = stmt.executeQuery();
//
//			while (rs.next()) {
//				ImpLoadTO load = mapLoadRSToTO(rs, siteId);
//				loads.add(load);
//			}
//		} finally {
//			closeConn(conn, stmt, rs);
//		}
//		return loads;
//	}

	public void updateService(ImpServiceTO svc, long siteId, Long driverId, String truckId, String trailerId,
			String trailerIdTag, String serviceDesc, boolean updServiceDate, boolean updDriver, boolean updTruck,
			boolean updTrailer, boolean updTrailerTag, boolean updServiceDesc)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			String sql = NATIVE_UPDATE_SERVICE;
			sql = sql.replace(UPD_SVC_DATE, (updServiceDate ? "ServiceDate=?," : ""));
			sql = sql.replace(UPD_DRIVER, (updDriver ? "DRIVERID=?," : ""));
			sql = sql.replace(UPD_TRUCK, (updTruck ? "TRUCKID=?," : ""));
			sql = sql.replace(UPD_TRAILER, (updTrailer ? "TRAILERID=?," : ""));
			sql = sql.replace(UPD_TRAILERTAG, (updTrailerTag ? "TRAILERID_TAG=?," : ""));
			sql = sql.replace(UPD_SVC_DESC, (updServiceDesc ? "SERVICEDESC=?," : ""));

			stmt = prepareStatement(conn, sql);
			int index = 0;
			if (updServiceDate) {
				log.info("%%% Updating service date : " + svc.getServiceDate());
				Date sDate = TimeUtil.convertToAxiomDate(svc.getServiceDate(), siteId);
				addParameter(stmt, ++index, new Timestamp(sDate.getTime()));
			}
			if (updDriver) {
				addParameter(stmt, ++index, driverId);
			}
			if (updTruck) {
				addParameter(stmt, ++index, truckId);
			}
			if (updTrailer) {
				addParameter(stmt, ++index, trailerId);
			}
			if (updTrailerTag) {
				addParameter(stmt, ++index, trailerIdTag);
			}
			if (updServiceDesc) {
				addParameter(stmt, ++index, serviceDesc);
			}
			addParameter(stmt, ++index, svc.getQty1());
			addParameter(stmt, ++index, svc.getUnit1());
			addParameter(stmt, ++index, svc.getQty2());
			addParameter(stmt, ++index, svc.getUnit2());
			addParameter(stmt, ++index, svc.getQty3());
			addParameter(stmt, ++index, svc.getUnit3());
			addParameter(stmt, ++index, svc.getQty4());
			addParameter(stmt, ++index, svc.getUnit4());
			addParameter(stmt, ++index, svc.getQty5());
			addParameter(stmt, ++index, svc.getUnit5());
			addParameter(stmt, ++index, svc.getQty6());
			addParameter(stmt, ++index, svc.getUnit6());
			addParameter(stmt, ++index, svc.getQty7());
			addParameter(stmt, ++index, svc.getUnit7());
			addParameter(stmt, ++index, svc.getQty8());
			addParameter(stmt, ++index, svc.getUnit8());
			addParameter(stmt, ++index, svc.getLocationIdPickup());
			addParameter(stmt, ++index, svc.getLocationIdDrop());

			// these windows times need to be converted back to local time
			Date win1From = TimeUtil.convertToAxiomDate(svc.getWindow1From(), siteId);
			Date win2From = TimeUtil.convertToAxiomDate(svc.getWindow2From(), siteId);
			Date win1To = TimeUtil.convertToAxiomDate(svc.getWindow1To(), siteId);
			Date win2To = TimeUtil.convertToAxiomDate(svc.getWindow2To(), siteId);

			addParameter(stmt, ++index, win1From == null ? null : new Timestamp(win1From.getTime()));
			addParameter(stmt, ++index, win1To == null ? null : new Timestamp(win1To.getTime()));
			addParameter(stmt, ++index, win2From == null ? null : new Timestamp(win2From.getTime()));
			addParameter(stmt, ++index, win2To == null ? null : new Timestamp(win2To.getTime()));

			addParameter(stmt, ++index, svc.getLoadType());
			addParameter(stmt, ++index, svc.getServiceType());
			addParameter(stmt, ++index, svc.getCustomerId());
			addParameter(stmt, ++index, svc.getRemarksService());
			addParameter(stmt, ++index, svc.getDocket());
			addParameter(stmt, ++index, svc.getImportEnteredBy());
			addParameter(stmt, ++index, svc.getImportServiceId());
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public void updateCustload(String loadNo, String loadTypeId, String importedBy, Date schedDate, long id,
			long siteId, boolean updSchedDate) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			String sql = NATIVE_UPDATE_CUSTLOAD;
			sql = sql.replace(UPD_SCHED_DATE, (updSchedDate ? "scheduleddate=?," : ""));
			stmt = prepareStatement(conn, sql);
			int index = 0;
			if (updSchedDate) {
				// sched date needs to be converted to local time
				Date sDate = TimeUtil.convertToAxiomDate(schedDate, siteId);
				if (sDate == null) {
					stmt.setNull(++index, Types.NULL);
				} else {
					stmt.setTimestamp(++index, new Timestamp(sDate.getTime()));
				}
			}
			stmt.setString(++index, loadNo);
			stmt.setString(++index, loadTypeId);
			stmt.setString(++index, importedBy);
			stmt.setLong(++index, id);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public void updateConsignment(String loadNo, String customerId, String batchNo, String locationDrop,
			String enteredBy, Date schedDate, long id, long siteId, boolean updSchedDate)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = getConnection();
			String sql = NATIVE_UPDATE_CONSIGNMENT;
			sql = sql.replace(UPD_SCHED_DATE, (updSchedDate ? "scheduleddate=?," : ""));
			stmt = prepareStatement(conn, sql);
			int index = 0;
			if (updSchedDate) {
				// sched date needs to be converted to local time
				Date sDate = TimeUtil.convertToAxiomDate(schedDate, siteId);
				if (sDate == null) {
					stmt.setNull(++index, Types.NULL);
				} else {
					stmt.setTimestamp(++index, new Timestamp(sDate.getTime()));
				}
			}
			stmt.setString(++index, loadNo);
			stmt.setString(++index, customerId);
			stmt.setString(++index, batchNo);
			stmt.setString(++index, locationDrop);
			stmt.setString(++index, enteredBy);
			stmt.setLong(++index, id);
			stmt.executeUpdate();
		} finally {
			closeConn(conn, stmt);
		}
	}

	public int getRecordCount(String query, Object... objects) throws SQLException, NotImplementedException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;

		int cnt = 0;
		try {
			stmt = prepareStatement(conn, query, objects);
			rs = stmt.executeQuery();
			while (rs.next()) {
				cnt = getInt(1, rs);
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return cnt;
	}

	public int getTripCountById(long tripId) throws SQLException, NotImplementedException {
		return getRecordCount(QUERY_TRIP_COUNT_BY_ID, tripId);
	}

	public TripTO getTripByTripNo(String tripNo, long siteId) throws SQLException, NotImplementedException {
		if (tripNo == null || tripNo.isEmpty()) {
			return null;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		TripTO trip = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_TRIP_BY_TRIPNO, tripNo, siteId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 0;
				trip = new TripTO();
				trip.setID(getLong(++i, rs));
				trip.setDESPATCH(getIntAsAxiomBool(++i, rs));
				trip.setDRIVERID(getLong(++i, rs));
				trip.setTRUCKID(getLong(++i, rs));
				trip.setTRAILERID(getString(++i, rs));
				trip.setTRAILERID_TAG(getString(++i, rs));
				break;
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return trip;
	}

	public ResourceResultTO bssAllocation(ImpJobLogTO jobLog, ImpServiceTO svc, long siteId,
			List<TruckResourceTO> trucks, List<DriverResourceTO> drivers, List<TrailerResourceTO> trailers) {
		StandardAxiomImport standardaxiomimport=new StandardAxiomImport();
		Long outDriver = null;
		String outTruck = null;
		String outTrailer = null;
		String outTrailerTag = null;
		String outServiceDesc = null;
		ResourceResultTO result = new ResourceResultTO();
		if (svc == null) {
			return result;
		}
		if (svc.getTruckId() != null) {
			TruckResourceTO truck = new TruckResourceTO();
			truck.setTruckId(svc.getTruckId());
			truck.setSiteid(siteId);
			if (trucks.contains(truck)) {
				truck = trucks.get(trucks.indexOf(truck));
			} else {
				try {
					standardaxiomimport.makeNotification(
							"Truck Id missing", "Truck " + svc.getTruckId() + " doesn't exist for load "
									+ svc.getLoadNo() + ", batch " + svc.getBatchNo() + ".",
							siteId, "Missing Truck", "B2B Import");
				} catch (NotImplementedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				outServiceDesc = svc.getTruckId();
				result.setOutServiceDesc(outServiceDesc);
				return result;
			}

			outTruck = svc.getTruckId();
			result.setOutTruck(outTruck);

			// get default trailers for truck
			if (outTrailer == null) {
				outTrailer = truck.getTruckId();
				result.setOutTrailer(outTrailer);
			}
			outTrailerTag = truck.getTrailerIdTag();
			result.setOutTrailerTag(outTrailerTag);

			if (outTrailerTag == null && outTrailer != null) {
				// get default tag for lead
				TrailerResourceTO trailer = new TrailerResourceTO();
				trailer.setTrailerId(outTrailer);
				trailer.setSiteid(siteId);

			}
		}
		return result;
	}

	public TripTO createtrip(ImpJobLogTO jobLog, TripTO triprsimp, long SiteID) throws SQLException {
		ImpServiceTO rsImp = new ImpServiceTO();
		String sql = QUERY_INSERT_TRIP;
		try (Connection conn = dataSource.getConnection(); PreparedStatement statement = conn.prepareStatement(sql)) {
			// Set parameter values
			statement.setLong(1, rsImp.getTripId());
			statement.setLong(2, SiteID);
			statement.setTimestamp(3, triprsimp.getTRIPDATE());
			statement.setString(4, triprsimp.getROUTEID());
			statement.setLong(5, rsImp.getDriverId());
			statement.setString(6, rsImp.getTruckId());
			statement.setString(7, rsImp.getTrailerId());
			statement.setString(8, rsImp.getTrailerIdTag());
			statement.setBoolean(9, triprsimp.getTRIPCOMPLETE());
			statement.setTimestamp(10, triprsimp.getPLANNEDSTARTTIME());
			statement.setTimestamp(11, triprsimp.getPLANNEDDESPATCHTIME());
			statement.setTimestamp(12, triprsimp.getPLANNEDRETURNTIME());
			statement.setTimestamp(13, triprsimp.getPLANNEDFINISHTIME());
			statement.setTimestamp(14, triprsimp.getSETTLEDATE());
			statement.setString(15, triprsimp.getLOCATIONID_DESPATCH());
			statement.setString(16, rsImp.getLocationIdReturn());
			statement.setString(17, triprsimp.getENTEREDBY());
			statement.setString(18, triprsimp.getDATASOURCEID());
			statement.setLong(19, rsImp.getTripId());
			statement.setLong(20, triprsimp.getDOCKID());
			statement.setBoolean(21, triprsimp.DESPATCH);
			statement.setTimestamp(22, triprsimp.getACTUALSTARTTIME());
			statement.setTimestamp(23, triprsimp.getACTUALRETURNTIME());
			statement.setTimestamp(24, triprsimp.getACTUALFINISHTIME());
			statement.setTimestamp(25, triprsimp.getCREATED());
			statement.setString(26, triprsimp.getCOMMENTS());
			// Execute the insert statement
			int rowsAffected = statement.executeUpdate();

			if (rowsAffected > 0) {
				// Insertion successful
			} else {
				jobLog.addError("Couldn't create new load in system; SQL error");
			}

		}

		return triprsimp;
	}

	public Long insertNewServices(ImpServiceTO service, Date tServiceDate, long tLoadId, long tTripId, int tTripSeq,
			long siteId, String sequenceName) throws SQLException, NotImplementedException, IOException {

		String INSERT_TABLE_NAME = "SERVICE";
		List<String> columnval = new LinkedList<String>();

		columnval.add("ServiceGroup");
		columnval.add("LoadId");
		columnval.add("ServiceDate");
		columnval.add("ServiceTypeID");
		columnval.add("ServiceDesc");
		columnval.add("CustomerId");
		columnval.add("LoadTypeID");
		columnval.add("DriverId");
		columnval.add("Truckid");
		columnval.add("TrailerId");
		columnval.add("TrailerId_Tag");
		columnval.add("ContainerId");
		columnval.add("LocationId_Pickup");
		columnval.add("LocationId_Drop");
		columnval.add("Docket");
		columnval.add("TripId");
		columnval.add("TripSeq");
		columnval.add("Remarks");
		columnval.add("Delivered");
		columnval.add("Window1From");
		columnval.add("Window1To");
		columnval.add("Window2From");
		columnval.add("Window2To");
		columnval.add("Window3From");
		columnval.add("Window3To");
		columnval.add("EnteredBy");
		columnval.add("Siteid");
		columnval.add("ID");
		columnval.add("ServiceNo");
		columnval.add("QTY1");
		columnval.add("UNIT1");
		columnval.add("QTY2");
		columnval.add("UNIT2");
		columnval.add("QTY3");
		columnval.add("UNIT3");
		columnval.add("QTY4");
		columnval.add("UNIT4");
		columnval.add("QTY5");
		columnval.add("UNIT5");
		columnval.add("QTY6");
		columnval.add("UNIT6");
		columnval.add("QTY7");
		columnval.add("UNIT7");
		columnval.add("QTY8");
		columnval.add("UNIT8");

		String insertsql = ServiceUtil.createinsertQuery(INSERT_TABLE_NAME, columnval);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long id = null;
		String serviceno = nextKey(siteId, INSERT_TABLE_NAME);
		try {
			conn = getConnection();
			pstmt = prepareStatement(conn, insertsql);
			id = getNextSequenceNumber(sequenceName, conn);

			pstmt.setString(1, service.getServiceGroup());
			pstmt.setLong(2, tLoadId);
			pstmt.setTimestamp(3, ServiceUtil.convertDateToTimeStamp(tServiceDate));
			pstmt.setString(4, service.getServiceType());
			pstmt.setString(5, service.getServiceDesc());
			pstmt.setString(6, service.getCustomerId());
			pstmt.setString(7, service.getLoadType());
			pstmt.setLong(8, service.getDriverId());
			pstmt.setString(9, service.getTruckId());
			pstmt.setString(10, service.getTrailerId());
			pstmt.setString(11, service.getTrailerIdTag());
			pstmt.setString(12, service.getContainerId());
			pstmt.setString(13, service.getLocationIdPickup());
			pstmt.setString(14, service.getLocationIdDrop());
			pstmt.setString(15, service.getDocket());
			pstmt.setLong(16, tTripId);
			pstmt.setInt(17, tTripSeq);
			pstmt.setString(18, service.getRemarksService());
			pstmt.setBoolean(19, service.isDelivered());
			pstmt.setTimestamp(20, ServiceUtil.convertDateToTimeStamp(service.getWindow1From()));
			pstmt.setTimestamp(21, ServiceUtil.convertDateToTimeStamp(service.getWindow1To()));
			pstmt.setTimestamp(22, ServiceUtil.convertDateToTimeStamp(service.getWindow2From()));
			pstmt.setTimestamp(23, ServiceUtil.convertDateToTimeStamp(service.getWindow2To()));
			pstmt.setTimestamp(24, ServiceUtil.convertDateToTimeStamp(service.getWindow2From()));
			pstmt.setTimestamp(25, ServiceUtil.convertDateToTimeStamp(service.getWindow2To()));
			pstmt.setString(26, service.getImportEnteredBy());
			pstmt.setLong(27, service.getSiteId());
			pstmt.setLong(28, id);
			pstmt.setString(29, serviceno);

			//
			pstmt.setDouble(30, service.getQty1());
			pstmt.setString(31, service.getUnit1());
			pstmt.setDouble(32, service.getQty2());
			pstmt.setString(33, service.getUnit2());
			pstmt.setDouble(34, service.getQty3());
			pstmt.setString(35, service.getUnit3());
			pstmt.setDouble(36, service.getQty4());
			pstmt.setString(37, service.getUnit4());
			pstmt.setDouble(38, service.getQty5());
			pstmt.setString(39, service.getUnit5());
			pstmt.setDouble(40, service.getQty6());
			pstmt.setString(41, service.getUnit6());
			pstmt.setDouble(42, service.getQty7());
			pstmt.setString(43, service.getUnit7());
			pstmt.setDouble(44, service.getQty8());
			pstmt.setString(45, service.getUnit8());

			int rows = pstmt.executeUpdate();

			return id;

		} finally {
			closeConn(conn, pstmt, rs);
		}
	}

	public LoadServiceTO getRoutingDetailService(long siteid, long loadid, String locationIdPickup,
			String locationIdDrop) throws SQLException, NotImplementedException {
		Connection conn = null;

		PreparedStatement stmt = null;
		ResultSet rsrout = null;
		LoadServiceTO to = new LoadServiceTO();
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_SERVICE_LOAD_REBUILD);
			stmt.setLong(1, siteid);
			stmt.setLong(2, loadid);
			rsrout = stmt.executeQuery();
			if (!(rsrout.next())) {
				return to;
			} else {
				to.setServiceId(rsrout.getLong("ID"));
				to.setServiceComplete(rsrout.getBoolean("COMPLETE"));
				to.setTruckId(rsrout.getLong("TRUCKID"));
				to.setTripId(rsrout.getLong("TRIPID"));
				to.setServiceNo(rsrout.getString("SERVICENO"));
			}
			return to;

		} finally {
			closeConn(conn, stmt, rsrout);
		}

	}

	public LoadServiceTO getRoutingPickupDetailService(long siteid, long loadid, String locationIdPickup,
			String locationIdDrop) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rsrout = null;
		LoadServiceTO to = new LoadServiceTO();
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_SERVICE_LOAD_REBUILD_PICKUP);
			stmt.setLong(1, siteid);
			stmt.setLong(2, loadid);
			stmt.setString(3, locationIdPickup);
			rsrout = stmt.executeQuery();
			if (!(rsrout.next()))
				to.setServiceId(rsrout.getLong("ID"));
			// to.setServiceComplete(rsrout.getBoolean("COMPLETE"));
			to.setTruckId(rsrout.getLong("TRUCKID"));
			to.setTripId(rsrout.getLong("TRIPID"));
			to.setServiceNo(rsrout.getString("SERVICENO"));
		} finally {
			closeConn(conn, stmt, rsrout);
		}
		return to;
	}

	public ImpJobLogTO updateServiceTruckDetais(ImpJobLogTO jobLog, ImpServiceTO service, LoadServiceTO lsServ,
			long serviceId, long tripId, int tripSeq) {

		return jobLog;

	}

	public List<DespatchDecisionTO> getDespatchDecision(ImpServiceTO impSvc, ServiceTO svc, int driverType, long siteId)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<DespatchDecisionTO> decisions = new ArrayList<DespatchDecisionTO>();
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_DESPATCH_DECISION, impSvc.getServiceType(), impSvc.getLoadType(),
					driverType, svc.getDriverId(), impSvc.getLocationIdPickup(), impSvc.getLocationType(),
					impSvc.getLocationIdDrop(), impSvc.getLocationTypeDrop(), impSvc.getImportEnteredBy(), siteId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 0;
				DespatchDecisionTO decision = new DespatchDecisionTO();
				decision.setUsesTimeTable(getIntAsAxiomBool(++i, rs));
				decisions.add(decision);
			}
			return decisions;
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public Date getRailDayDate(String railCode1, String railCode2) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Date railDayDate = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_RAILDAYS, railCode1, railCode2);
			rs = stmt.executeQuery();
			while (rs.next()) {
				railDayDate = getTimestamp(1, rs);
			}
			return railDayDate;
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public int updateImportServiceStatus(long serviceId, long importId, long importedLoadID)
			throws SQLException, NotImplementedException {

		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			stmt = prepareStatement(conn, UPDATE_IMP_SERVICE_STATUS);
			stmt.setLong(1, serviceId);
			stmt.setLong(2, importId);
			// stmt.setLong(3, importedLoadID);
			int updatedrow = stmt.executeUpdate();
			return updatedrow;
		} finally {
			closeConn(conn, stmt);
		}

	}

	public Integer getNextTripSeq(long tripId, long siteId) throws SQLException, NotImplementedException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Integer nextSeq = null;
		try {
			stmt = prepareStatement(conn, QUERY_NEXT_TRIP_SEQ, siteId, tripId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				nextSeq = getInt(1, rs);
			}
			if (nextSeq == null) {
				nextSeq = 2;
			} else {
				nextSeq++;
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return nextSeq;
	}

	public List<UnitTO> getUnitListBYSiteId(long siteId, String unitid) throws SQLException, NotImplementedException {

		List<UnitTO> unitlist = new ArrayList<>();
		UnitTO ut = new UnitTO();
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = prepareStatement(conn, QUERY_GET_UNIT, siteId, unitid);
			rs = stmt.executeQuery();
			while (rs.next()) {
				ut.setUnitId(rs.getString("UNITID"));
				ut.setSiteId(rs.getLong("SITEID"));
				ut.setAllowNegative(rs.getBoolean("ALLOWNEGATIVE"));
				ut.setDecimalPlaces(rs.getShort("DECIMALPLACES"));
				unitlist.add(ut);

			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return unitlist;

	}

	public int getDriverTyeByID(long driverid) throws SQLException, NotImplementedException {

		int result = 0;
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = prepareStatement(conn, QUERY_GET_DRIVERTYPE_COUNT, driverid);
			rs = stmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt("cId") > 0)
					result = -1;
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return result;

	}

	public List<ServiceTO> getServicesByTrip(long tripId) throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<ServiceTO> services = new ArrayList<ServiceTO>();

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_OBTAIN_SERVICES_BY_TRIP, tripId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 0;
				ServiceTO svc = new ServiceTO();
				svc.setId(getLong(++i, rs));
				svc.setQty1(getDouble(++i, rs));
				svc.setQty2(getDouble(++i, rs));
				svc.setQty3(getDouble(++i, rs));
				svc.setQty4(getDouble(++i, rs));
				svc.setQty5(getDouble(++i, rs));
				svc.setQty6(getDouble(++i, rs));
				svc.setQty7(getDouble(++i, rs));
				svc.setQty8(getDouble(++i, rs));
				svc.setUnit1(getString(++i, rs));
				svc.setUnit2(getString(++i, rs));
				svc.setUnit3(getString(++i, rs));
				svc.setUnit4(getString(++i, rs));
				svc.setUnit5(getString(++i, rs));
				svc.setUnit6(getString(++i, rs));
				svc.setUnit7(getString(++i, rs));
				svc.setUnit8(getString(++i, rs));
				services.add(svc);
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return services;
	}

	public TruckTrailerCapacityTO getTruckTralerCapacityByTripID(long tripid)
			throws SQLException, NotImplementedException {

		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		TruckTrailerCapacityTO capacity = new TruckTrailerCapacityTO();

		try {
			stmt = prepareStatement(conn, QUERT_OBTAIN_TRUCK_TRAILER_CAPACITY, tripid);
			rs = stmt.executeQuery();
			while (rs.next()) {
				capacity.setTruckcapacity(rs.getDouble("TruckCapacity"));
				capacity.setTrailer1capacity(rs.getDouble("Trailer1Capacity"));
				capacity.setTrailer2capacity(rs.getDouble("Trailer2Capacity"));
			}
		} finally {
			closeConn(conn, stmt, rs);
		}
		return capacity;

	}

	public void updateAggregateWithTripID(Double rouqty, Double truckcap, Double trailercap, long tripid)
			throws SQLException, NotImplementedException {

		Connection conn = getConnection();
		PreparedStatement stmt = null;

		try {
			stmt = prepareStatement(conn, QUERT_UPDATE_AGGREGATE_CAPACITY);
			stmt.setDouble(1, rouqty);
			stmt.setDouble(2, truckcap);
			stmt.setDouble(3, trailercap);
			stmt.setDouble(4, tripid);
			stmt.executeUpdate();

		} finally {
			closeConn(conn, stmt);
		}

	}

//	}

	public TripTO getmDespatchTrip(Long inTripId) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			String query = "SELECT * FROM TRIP WHERE ID=?";
			stmt = conn.prepareStatement(query);
			stmt.setLong(1, inTripId);
			rs = stmt.executeQuery();
			TripTO tripTo = new TripTO();
			if (rs.next()) {
				tripTo.setDRIVERID(rs.getLong("DriverID"));
				tripTo.setTRAILERID(rs.getString("TrailerID"));
				tripTo.setTRAILERID_TAG(rs.getString("TrailerId_Tag"));
				tripTo.setTRUCKID(rs.getLong("TruckID"));

			}
			return tripTo;
		} finally {
			closeConn(conn, stmt, rs);
		}
	}

	public List<String> getmDespatchTrip1(Long inTripId) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;

//		String locationId_Pickup = null;
		List<String> locationId_Pickup = new ArrayList<>();
		try {
			String query = "SELECT LOCATIONID_PICKUP FROM SERVICE WHERE TRIPID=? ORDER BY TRIPSEQ";
			stmt = conn.prepareStatement(query);
			stmt.setLong(1, inTripId);
			rs = stmt.executeQuery();

			if (rs.next()) {
				String locationId;
				locationId = rs.getString("LOCATIONID_PICKUP");
				locationId_Pickup.add(locationId);
			}
			return locationId_Pickup;
		} finally {
			closeConn(conn, stmt, rs);
		}

	}
}
