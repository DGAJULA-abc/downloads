package au.com.tollgroup.a2.sicli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.ServiceTO;
import au.com.tollgroup.a2.sicli.model.TripTO;
import au.com.tollgroup.a2.sicli.util.ServiceUtil;
import au.com.tollgroup.a2.sicli.model.EventTO;
import au.com.tollgroup.a2.sicli.model.InternalEventQueueTO;

@Repository
public class SilciDispatchDAO extends AbstractDAO {
	
	public static final String QUERY_OBTAIN_DISPATCH_DATA_BY_TRIP="SELECT '0' AS RETURNSSERVICE,"
			+ "  SERVICE.CONTAINERID, SERVICE.TRIPSEQ AS ZSEQ, SERVICE.TRAILERID AS ZTRAILR, SERVICE.ID AS TOLLSERVICEID, "
			+ "  SERVICE.SERVICEGROUP, SERVICE.UNIT1 AS QUANTITYTYPE_1, SERVICE.QTY1 AS QUANTITY_1, \r\n"
			+ "  SERVICE.UNIT2 AS QUANTITYTYPE_2, SERVICE.QTY2 AS QUANTITY_2, SERVICE.UNIT3 AS QUANTITYTYPE_3, "
			+ "  SERVICE.QTY3 AS QUANTITY_3, SERVICE.UNIT4 AS QUANTITYTYPE_4, SERVICE.QTY4 AS QUANTITY_4, "
			+ "  SERVICE.UNIT5 AS QUANTITYTYPE_5, SERVICE.QTY5 AS QUANTITY_5, SERVICE.UNIT6 AS QUANTITYTYPE_6,"
			+ "  SERVICE.QTY6 AS QUANTITY_6,SERVICE.UNIT7 AS QUANTITYTYPE_7, SERVICE.QTY7 AS QUANTITY_7,"
			+ "  SERVICE.UNIT8 AS QUANTITYTYPE_8, SERVICE.QTY8 AS QUANTITY_8, SERVICE.TRIPSEQ AS RESTSEQ, "
			+ "  SERVICE.LOADTYPEID, SERVICE.SERVICETYPEID, SERVICE.SERVICEDATE AS RUNDATE, SERVICE.DRIVERID,"
			+ "  SERVICE.TRUCKID,CUSTLOAD.LOADNO, CUSTLOAD.LOADNO, TRUCK.FLEETNO AS FLEETID,\r\n"
			+ "  SERVICE_TYPE.REQCONTAINER, SERVICE_TYPE.MDALLOWREJECT, SERVICE_TYPE.MDALLOWCANCEL,"
			+ "  SERVICE_TYPE.MDALLOWLOADNOEDIT,\r\n"
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.LATITUDE, PLOC.LATITUDE) AS PICKUPLATITUDE, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.LONGITUDE, PLOC.LONGITUDE) AS PICKUPLONGITUDE, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.GEOFENCE, PLOC.GEOFENCE) AS PICKUPRADIUS, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW1FROM, PLOC.WINDOW1FROM) AS PICKUPTIMEWINDOWSTART_1, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW1TO, PLOC.WINDOW1TO) AS PICKUPTIMEWINDOWSTOP_1, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW2FROM, PLOC.WINDOW2FROM) AS PICKUPTIMEWINDOWSTART_2, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW2TO, PLOC.WINDOW2TO) AS PICKUPTIMEWINDOWSTOP_2, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW3FROM, PLOC.WINDOW3FROM) AS PICKUPTIMEWINDOWSTART_3,"
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.WINDOW3TO, PLOC.WINDOW3TO) AS PICKUPTIMEWINDOWSTOP_3, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.LOCATIONID, PLOC.LOCATIONID) AS PICKUPCOMPANYNAME, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.LOCATIONDESC, PLOC.LOCATIONDESC) AS PICKUPLOCDESC, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.ADDRESS1, PLOC.ADDRESS1) AS PICKUPLOCADDRESS1, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.ADDRESS2, PLOC.ADDRESS2) AS PICKUPLOCADDRESS2, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.SUBURB, PLOC.SUBURB) AS PICKUPLOCSUBURB, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.POSTCODE, PLOC.POSTCODE) AS PICKUPLOCPOSTCODE, "
			+ "  NVL2(SERVICE.LOCATIONID_PICKUPACTUAL, PLOCA.REMARKS, PLOC.REMARKS) AS PICKUPLOCREMARKS,"
			+ "  PPERSON.FIRSTNAME||' '||PPERSON.LASTNAME AS PICKUPCONTACTNAME, PPERSON.MOBILE AS PICKUPMOBILE, PPERSON.OFFICEPHONE AS PICKUPPHONE,"
			+ "  DLOC.LATITUDE AS DELIVERYLATITUDE, DLOC.LONGITUDE AS DELIVERYLONGITUDE, DLOC.GEOFENCE AS DELIVERYRADIUS, "
			+ "  DLOC.WINDOW1FROM AS DELIVERYTIMEWINDOWSTART_1, DLOC.WINDOW1TO AS DELIVERYTIMEWINDOWSTOP_1, "
			+ "  DLOC.WINDOW2FROM AS DELIVERYTIMEWINDOWSTART_2, DLOC.WINDOW2TO AS DELIVERYTIMEWINDOWSTOP_2, "
			+ "  DLOC.WINDOW3FROM AS DELIVERYTIMEWINDOWSTART_3, DLOC.WINDOW3TO AS DELIVERYTIMEWINDOWSTOP_3, "
			+ "  DLOC.LOCATIONID AS DELIVERYCOMPANYNAME, DLOC.LOCATIONDESC AS DELIVERYLOCDESC,"
			+ "  DLOC.ADDRESS1 AS DELIVERYLOCADDRESS1, DLOC.ADDRESS2 AS DELIVERYLOCADDRESS2, DLOC.SUBURB AS DELIVERYLOCSUBURB, "
			+ "  DLOC.POSTCODE AS DELIVERYLOCPOSTCODE, DLOC.REMARKS AS DELIVERYLOCREMARKS,"
			+ "  DPERSON.FIRSTNAME||' '||DPERSON.LASTNAME AS DELIVERYCONTACTNAME, DPERSON.MOBILE AS DELIVERYMOBILE, DPERSON.OFFICEPHONE AS DELIVERYPHONE,"
			+ "  ES.MDTCODE"			
			+ "FROM SERVICE"
			+ "    JOIN CUSTLOAD ON SERVICE.LOADID=CUSTLOAD.ID"
			+ "    JOIN EMPLOYEE_SITE ES ON SERVICE.DRIVERID=ES.ID AND ES.SITEID=SERVICE.SITEID"
			+ "    JOIN DRIVER ON ES.EMPLOYEEID=DRIVER.ID"
			+ "    LEFT JOIN LOCATION PLOC ON SERVICE.LOCATIONID_PICKUP=PLOC.LOCATIONID AND PLOC.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN LOCATION PLOCA ON SERVICE.LOCATIONID_PICKUPACTUAL=PLOCA.LOCATIONID AND PLOCA.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN LOCATION DLOC ON SERVICE.LOCATIONID_DROP=DLOC.LOCATIONID AND DLOC.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN TRIP ON SERVICE.TRIPID=TRIP.ID\r\n"
			+ "    LEFT JOIN TRUCK ON SERVICE.TRUCKID=TRUCK.TRUCKID AND TRUCK.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN TRAILER ON SERVICE.TRAILERID=TRAILER.TRAILERID AND TRAILER.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN TRAILER TAGT ON SERVICE.TRAILERID_TAG=TAGT.TRAILERID AND TAGT.SITEID=SERVICE.SITEID"
			+ "    LEFT JOIN PERSON PPERSON ON PLOC.PERSONID_CONTACT=PPERSON.ID"
			+ "    LEFT JOIN PERSON DPERSON ON DLOC.PERSONID_CONTACT=DPERSON.ID"
			+ "    LEFT JOIN SERVICE_TYPE ON SERVICE.SERVICETYPEID=SERVICE_TYPE.SERVICETYPEID AND SERVICE_TYPE.SITEID=SERVICE.SITEID"
			+ "WHERE  SERVICE.TRIPID= ? "
			+ "ORDER BY SERVICE.TRIPSEQ";
	
	public static final String QUERY_INSERT_EVENT_QUE_SEQ="INSERT INTO INTERNAL_EVENT_QUEUE (ID,TYPEID,LOGGEDDATETIME,SITEID,TASKID,DETAIL)values (?,?,?,?,?,?)";
	 
	public static final String QUERY_OBTAIN_DISPATCH_BY_TRIP="select t.driverid, t.truckid, s.locationid_pickup, s.locationid_drop from service s, trip t "
			+ " where t.id=s.tripid and t.siteid=s.siteid ";
	
	
	public static final String QUERY_OBTAIN_ID_FROM_EMP_SITE="Select ID from EMPLOYEE_SITE where driverid=?";
	
	public static final String QUERY_OBTAIN_ID_FROM_TRUCK="Select TRUCKID from TRUCK where truckid=?";
	
	public static final String QUERY_OBTAIN_ID_FROM_LOCATION="Select LOCATIONID from LOCATION where locationid_pickup=?"	;
	
	private static final String QUERY_CURRENT_TRIP_DETAILS="SELECT CACHEDSTATUS,CACHEDPHASE,DRIVERID FROM TRIP WHERE ID=?";
	
	private static final String QUERY_SERVICE_CANCELLED_EVENTS = "SELECT COUNT(*) AS C FROM EVENT WHERE TRIPID=? AND EVENTTYPEID IN (23,38)";
    private static final String QUERY_LATEST_EVENT_OF_TRIP = "Select * from event where id=(SELECT max(id) FROM EVENT WHERE TRIPID=? AND "
			+ "EVENTTYPEID IN (8, 18, 19, 39, 47, 11, 15, 12, 13, 16, 14, 38)) ";
	private static final String QUERY_GET_RETURN_SERVICE_CNT = "SELECT COUNT(*) FROM SERVICE WHERE SERVICETYPEID=? AND TRIPID=?";
	private static final String QUERY_GET_UNDELIVERED_SERVICE_CNT = "SELECT COUNT(*) FROM SERVICE WHERE TRIPID=? AND DELIVERED=0";
	private static final String QUERY_GET_FIRST_SERVICE_ID_BY_TRIP = "SELECT ID FROM SERVICE WHERE TRIPID=? AND TRIPSEQ=1";
    private final static String SQL_RETURN_TYPE = "select opt_value from AXIOM.USER_OPTIONS where siteid = ? and opt_name = ?";
	
	public String getServicesDetailsByTrip(String tripId)
			throws SQLException, NotImplementedException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		InternalEventQueueTO ieq = new InternalEventQueueTO();
		String details="";

		try {
			conn = getConnection();
			stmt = prepareStatement(conn, QUERY_OBTAIN_DISPATCH_DATA_BY_TRIP,
					tripId);
			rs = stmt.executeQuery();
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			     int count=0;
			     while(rs.next()){
					count++;					
					for (int i = count; i <= columnCount; i++ ) {
						details =details+ rsmd.getColumnName(i).concat(" ")
								.concat((rs.getString(i)).toString()).concat(" "); 
						break;
					}					
				}			  
		
	      } finally {
		    closeConn(conn, stmt, rs);
	     } 
	       return details;
      }	  
			
	public void addServicesEventQueSeq(String details,String tripId,long siteid)
			throws SQLException, NotImplementedException {
		
		Connection conn = null;
 		PreparedStatement stmt = null;

 		try {
 			conn = getConnection();
 			long id=getNextSequenceNumber("INTERNAL_EVENT_QUEUE_SEQ",conn);
       	 
 			stmt = prepareStatement(conn,QUERY_INSERT_EVENT_QUE_SEQ);
 			stmt.setLong(1, id);
 			stmt.setLong(2, 1);
 			stmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
 			stmt.setLong(4, siteid);
 			stmt.setString(5, tripId);
 			stmt.setString(6, details);
 			stmt.executeUpdate();
 		} finally {
 			closeConn(conn, stmt);
 		}		
	}
	
	public int validTripDispatch(String tripId,long siteid)
			throws SQLException, NotImplementedException {
	
	Connection conn = getConnection();
	PreparedStatement stmt = null;
	ResultSet rs = null;
	int result=0;

	try {
		stmt = prepareStatement(conn, QUERY_OBTAIN_DISPATCH_BY_TRIP);
		stmt.setString(1, tripId);
		stmt.setDouble(2, siteid);		
		rs = stmt.executeQuery();
		if(!rs.next()) {
			return result;
		}
		else {
			result=1;
			do {
				Long driverid=rs.getLong("driverid");
				if(driverid == null || ExistValueforId("EMPLOYEE_SITE","ID",driverid,siteid)==0) {
						result=0;
				}
				
				Long truckid=rs.getLong("truckid");
				if(truckid == null || ExistValueforId("TRUCK","TRUCKID",truckid,siteid)==0)
					result=0;
				
				String locationid_Pickup=rs.getString("Locationid_Pickup");
				if(locationid_Pickup==null) {
					result=0;
				}else {
					if(ExistValueforLocation("LOCATION","LOCATIONID",locationid_Pickup,siteid)==0)
						result=0;
				}
				
				String locationid_Drop=rs.getString("Locationid_Drop");
				if(locationid_Drop==null) {
					result=0;
				}else {
					if(ExistValueforLocation("LOCATION","LOCATIONID",locationid_Drop,siteid)==0)
						result=0;
				}		
				
			}while(rs.next());
		}
		
		return result;		

	} finally {
		closeConn(conn, stmt);
	}
}
	
private int ExistValueforId(String inTableName,String inKeyName, Long keyvalue,Long siteid) throws SQLException, NotImplementedException {
		
		String QUERY_OBTAIN_BY_ID=  "SELECT "+inKeyName+" FROM "+inTableName+" WHERE "+inKeyName+" =? AND SITEID=?";
		
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result=-1;
		
		stmt = prepareStatement(conn, QUERY_OBTAIN_BY_ID);
		stmt.setLong(1,keyvalue);
		stmt.setLong(2, siteid);		
		rs = stmt.executeQuery();
		if(!rs.next()) {
			return result;
		}
		return result;
	}
	
private int ExistValueforLocation(String inTableName,String inKeyName, String keyvalue,Long siteid) throws SQLException, NotImplementedException {
		
		String QUERY_OBTAIN_BY_ID=  "SELECT "+inKeyName+" FROM "+inTableName+" WHERE "+inKeyName+" =? AND SITEID=?";
		
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result=-1;
		
		stmt = prepareStatement(conn, QUERY_OBTAIN_BY_ID);
		stmt.setString(1,keyvalue);
		stmt.setLong(2, siteid);		
		rs = stmt.executeQuery();
		if(!rs.next()) {
			return result;
		}
		return result;
	}

public TripTO getCurrentTripDetails(long tripId) throws SQLException, NotImplementedException {
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;

	try {
		conn = getConnection();
		stmt = prepareStatement(conn, QUERY_CURRENT_TRIP_DETAILS ,tripId);
		rs = stmt.executeQuery();
		TripTO tripcahe = null;
		while (rs.next()) {
			int i = 0;
			tripcahe = new TripTO();
			tripcahe.setCACHEDSTATUS(rs.getString("CACHEDSTATUS"));
			tripcahe.setCACHEDPHASE(rs.getLong("CACHEDPHASE"));
			tripcahe.setDRIVERID(rs.getLong("DRIVERID"));
		}
		return tripcahe;
	} finally {
		closeConn(conn, stmt, rs);
	}
}

public int getServiceCancelledEventCountByTrip(Long tripId)
		throws SQLException, NotImplementedException {
	return getRecordCount(QUERY_SERVICE_CANCELLED_EVENTS, tripId);
}
public EventTO getLatestEventTrip(long tripId, long siteId)
		throws SQLException, NotImplementedException {
	Connection conn = getConnection();
	PreparedStatement stmt = null;
	ResultSet rs = null;

//	String siteTimeZone = ApplicationOptionsDAO.getTimeZone(siteId);
	EventTO event = null;
	try {
		stmt = prepareStatement(conn, QUERY_LATEST_EVENT_OF_TRIP, tripId);
		rs = stmt.executeQuery();
		while(rs.next()) {
			int i =0;
			event = new EventTO();
			event.setId(getLong(++i, rs));
			event.setSiteId(getLong(++i, rs));
			event.setLoggedDateTime(getConvertedTimestamp(siteId, ++i, rs));
			event.setEventTypeId(getInt(++i, rs));
			event.setTripId(getLong(++i, rs));
			event.setDriverId(getLong(++i, rs));
			event.setTruckId(getString(++i, rs));
			event.setTrailerId(getString(++i, rs));
			event.setTrailerTagId(getString(++i, rs));
			event.setDockId(getLong(++i, rs));
			event.setValue1(getDouble(++i, rs));
			event.setValue2(getDouble(++i, rs));
			event.setTextValue(getString(++i, rs));
			event.setUserId(getString(++i, rs));
			event.setTime1(getConvertedTimestamp(siteId, ++i, rs));
			event.setTime2(getConvertedTimestamp(siteId, ++i, rs));
			event.setTextValue2(getString(++i, rs));
			event.setServiceId(getLong(++i, rs));
			event.setLocationId(getString(++i, rs));
			event.setException(getIntAsAxiomBool(++i, rs));
			event.setExceptiondesc(getString(++i, rs));
			event.setExported(getIntAsAxiomBool(++i, rs));
			event.setEventAdjusted(getIntAsAxiomBool(++i, rs));
			event.setDatasourceId(getString(++i, rs));
			event.setLatitude(getDouble(++i, rs));
			event.setLongitude(getDouble(++i, rs));
			event.setFleetId(getLong(++i, rs));
			event.setUnitId(getLong(++i, rs));
			event.setVehicleId(getLong(++i, rs));
			event.setMdrego(getString(++i,rs));
			event.setMdtcode(getInt(++i, rs));
			event.setMdservertime(getConvertedTimestamp(siteId, ++i, rs));
			event.setCreated(getConvertedTimestamp(siteId, ++i, rs));
			event.setCertainty(getInt(++i, rs));
			event.setCompliant(getIntAsAxiomBool(++i, rs));
			event.setComments(getString(++i, rs));
		}
	} finally {
		closeConn(conn, stmt, rs);
	}
	return event;
}
public int getReturnServiceCountByTrip(long tripId, String serviceTypeId)
		throws SQLException, NotImplementedException {
	return getRecordCount(QUERY_GET_RETURN_SERVICE_CNT, serviceTypeId, tripId);
}
public long getUndeliveredServiceCountTrip(long tripId)
		throws SQLException, NotImplementedException {
	return getRecordCount(QUERY_GET_UNDELIVERED_SERVICE_CNT, tripId);
}
public Long getFirstServiceIdByTrip(Long tripId) throws SQLException, NotImplementedException {
	Connection conn = getConnection();
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	Long serviceId = null;
	try {
		pstmt = prepareStatement(conn, QUERY_GET_FIRST_SERVICE_ID_BY_TRIP,
				tripId);
		rs = pstmt.executeQuery();
		if (rs.next()) {
			serviceId = getLong(1, rs);
		}
	} finally {
		closeConn(conn, pstmt, rs);
	}
	return serviceId;
}

public int getRecordCount(String query, Object... objects) throws SQLException, NotImplementedException {
	Connection conn = getConnection();
	PreparedStatement stmt = null;
	ResultSet rs = null;

	int cnt = 0;
	try {
		stmt = prepareStatement(conn, query, objects);
		rs = stmt.executeQuery();
		while (rs.next()) {
			cnt = getInt(1, rs);
		}
	} finally {
		closeConn(conn, stmt, rs);
	}
	return cnt;
}

public String returnServiceType(Long siteId,String optname) throws SQLException, NotImplementedException {

    String retType = null;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try {
        conn = getConnection();
        pstmt = prepareStatement(conn, SQL_RETURN_TYPE, siteId, optname);
        rs = pstmt.executeQuery();
        if (rs.next()) {
            retType = getString(1, rs);
        }

    } finally {
        closeConn(conn, pstmt, rs);

    }
    return retType;

}

}
