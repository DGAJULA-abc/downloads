package au.com.tollgroup.a2.sicli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.EventTO;


@Repository
public class TripDAO extends AbstractDAO {
//	@Autowired
//	private DataSource dataSource;
	
	private static final String QUERY_SERVICE_CANCELLED_EVENTS = "SELECT COUNT(*) AS C FROM EVENT WHERE TRIPID=? AND EVENTTYPEID IN (23,38)";
    private static final String QUERY_LATEST_EVENT_OF_TRIP = "Select * from event where id=(SELECT max(id) FROM EVENT WHERE TRIPID=? AND "
			+ "EVENTTYPEID IN (8, 18, 19, 39, 47, 11, 15, 12, 13, 16, 14, 38)) ";
	private static final String QUERY_GET_RETURN_SERVICE_CNT = "SELECT COUNT(*) FROM SERVICE WHERE SERVICETYPEID=? AND TRIPID=?";
	private static final String QUERY_GET_UNDELIVERED_SERVICE_CNT = "SELECT COUNT(*) FROM SERVICE WHERE TRIPID=? AND DELIVERED=0";
	private static final String QUERY_GET_FIRST_SERVICE_ID_BY_TRIP = "SELECT ID FROM SERVICE WHERE TRIPID=? AND TRIPSEQ=1";
	
	
	//methods for query
	
		public int getServiceCancelledEventCountByTrip(long tripId)
				throws SQLException, NotImplementedException {
			return getRecordCount(QUERY_SERVICE_CANCELLED_EVENTS, tripId);
		}
			
			
		public EventTO getLatestEventTrip(long tripId, long siteId)
				throws SQLException, NotImplementedException {
			Connection conn = getConnection();
			PreparedStatement stmt = null;
			ResultSet rs = null;

//			String siteTimeZone = ApplicationOptionsDAO.getTimeZone(siteId);
			EventTO event = null;
			try {
				stmt = prepareStatement(conn, QUERY_LATEST_EVENT_OF_TRIP, tripId);
				rs = stmt.executeQuery();
				while(rs.next()) {
					int i =0;
					event = new EventTO();
					event.setId(getLong(++i, rs));
					event.setSiteId(getLong(++i, rs));
					event.setLoggedDateTime(getConvertedTimestamp(siteId, ++i, rs));
					event.setEventTypeId(getInt(++i, rs));
					event.setTripId(getLong(++i, rs));
					event.setDriverId(getLong(++i, rs));
					event.setTruckId(getString(++i, rs));
					event.setTrailerId(getString(++i, rs));
					event.setTrailerTagId(getString(++i, rs));
					event.setDockId(getLong(++i, rs));
					event.setValue1(getDouble(++i, rs));
					event.setValue2(getDouble(++i, rs));
					event.setTextValue(getString(++i, rs));
					event.setUserId(getString(++i, rs));
					event.setTime1(getConvertedTimestamp(siteId, ++i, rs));
					event.setTime2(getConvertedTimestamp(siteId, ++i, rs));
					event.setTextValue2(getString(++i, rs));
					event.setServiceId(getLong(++i, rs));
					event.setLocationId(getString(++i, rs));
					event.setException(getIntAsAxiomBool(++i, rs));
					event.setExceptiondesc(getString(++i, rs));
					event.setExported(getIntAsAxiomBool(++i, rs));
					event.setEventAdjusted(getIntAsAxiomBool(++i, rs));
					event.setDatasourceId(getString(++i, rs));
					event.setLatitude(getDouble(++i, rs));
					event.setLongitude(getDouble(++i, rs));
					event.setFleetId(getLong(++i, rs));
					event.setUnitId(getLong(++i, rs));
					event.setVehicleId(getLong(++i, rs));
					event.setMdrego(getString(++i,rs));
					event.setMdtcode(getInt(++i, rs));
					event.setMdservertime(getConvertedTimestamp(siteId, ++i, rs));
					event.setCreated(getConvertedTimestamp(siteId, ++i, rs));
					event.setCertainty(getInt(++i, rs));
					event.setCompliant(getIntAsAxiomBool(++i, rs));
					event.setComments(getString(++i, rs));
				}
			} finally {
				closeConn(conn, stmt, rs);
			}
			return event;
		}
		public int getReturnServiceCountByTrip(long tripId, String serviceTypeId)
				throws SQLException, NotImplementedException {
			return getRecordCount(QUERY_GET_RETURN_SERVICE_CNT, serviceTypeId, tripId);
		}
		public long getUndeliveredServiceCountTrip(long tripId)
				throws SQLException, NotImplementedException {
			return getRecordCount(QUERY_GET_UNDELIVERED_SERVICE_CNT, tripId);
		}
		public Long getFirstServiceIdByTrip(long tripId) throws SQLException, NotImplementedException {
			Connection conn = getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			Long serviceId = null;
			try {
				pstmt = prepareStatement(conn, QUERY_GET_FIRST_SERVICE_ID_BY_TRIP,
						tripId);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					serviceId = getLong(1, rs);
				}
			} finally {
				closeConn(conn, pstmt, rs);
			}
			return serviceId;
		}
		
		private int getRecordCount(String query, Object... objects)
				throws SQLException, NotImplementedException {
			Connection conn = getConnection();
			PreparedStatement stmt = null;
			ResultSet rs = null;

			int cnt = 0;
			try {
				stmt = prepareStatement(conn, query, objects);
				rs = stmt.executeQuery();
				while (rs.next()) {
					cnt = getInt(1, rs);
				}
			} finally {
				closeConn(conn, stmt, rs);
			}
			return cnt;
		}

}
