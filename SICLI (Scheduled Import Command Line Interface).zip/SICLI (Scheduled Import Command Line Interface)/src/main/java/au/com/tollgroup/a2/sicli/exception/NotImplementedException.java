package au.com.tollgroup.a2.sicli.exception;

    public class NotImplementedException extends Exception{

		private static final long serialVersionUID = 3950789056521834765L;
		
		private String message;
		
		public NotImplementedException(String message) {
			this.message = message;
		}

		/**
		 * @return the message
		 */
		public String getMessage() {
			return message;
		}

		/**
		 * @param message the message to set
		 */
		public void setMessage(String message) {
			this.message = message;
		}
}
