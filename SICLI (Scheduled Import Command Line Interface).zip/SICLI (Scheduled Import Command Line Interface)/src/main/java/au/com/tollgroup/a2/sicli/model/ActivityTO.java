package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;



public class ActivityTO implements Serializable {

    private static final long serialVersionUID = 7461217406416699988L;

    private Long id;
    private long tripId;
    private long siteId;
    private String pickupLocationId;
    private String dropLocationId;
    private int activityIndex;
    private Long activityTime;
    private Long activityTypeId;
    private String comments;

    /**
     * @return the id
     */

    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
 
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the tripId
     */
    public long getTripId() {
        return tripId;
    }

    /**
     * @param tripId
     *            the tripId to set
     */
    public void setTripId(long tripId) {
        this.tripId = tripId;
    }

    /**
     * @return the siteId
     */
    public long getSiteId() {
        return siteId;
    }

    /**
     * @param siteId
     *            the siteId to set
     */
    public void setSiteId(long siteId) {
        this.siteId = siteId;
    }

    /**
     * @return the pickupLocationId
     */
    public String getPickupLocationId() {
        return pickupLocationId;
    }

    /**
     * @param pickupLocationId
     *            the pickupLocationId to set
     */
    public void setPickupLocationId(String pickupLocationId) {
        this.pickupLocationId = pickupLocationId;
    }

    /**
     * @return the dropLocationId
     */
    public String getDropLocationId() {
        return dropLocationId;
    }

    /**
     * @param dropLocationId
     *            the dropLocationId to set
     */
    public void setDropLocationId(String dropLocationId) {
        this.dropLocationId = dropLocationId;
    }

    /**
     * @return the activityIndex
     */
    public int getActivityIndex() {
        return activityIndex;
    }

    /**
     * @param activityIndex
     *            the activityIndex to set
     */
    public void setActivityIndex(int activityIndex) {
        this.activityIndex = activityIndex;
    }

    /**
     * @return the activityTime
     */
    public Long getActivityTime() {
        return activityTime;
    }

    /**
     * @param activityTime
     *            the activityTime to set
     */
    public void setActivityTime(Long activityTime) {
        this.activityTime = activityTime;
    }

    /**
     * @return the activityTypeId
     */
    public Long getActivityTypeId() {
        return activityTypeId;
    }

    /**
     * @param activityTypeId
     *            the activityTypeId to set
     */
    public void setActivityTypeId(Long activityTypeId) {
        this.activityTypeId = activityTypeId;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((activityTypeId == null) ? 0 : activityTypeId.hashCode());
        result = prime * result
                + ((dropLocationId == null) ? 0 : dropLocationId.hashCode());
        result = prime
                * result
                + ((pickupLocationId == null) ? 0 : pickupLocationId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ActivityTO other = (ActivityTO) obj;
        if (activityTypeId == null) {
            if (other.activityTypeId != null) {
                return false;
            }
        } else if (!activityTypeId.equals(other.activityTypeId)) {
            return false;
        }
        if (dropLocationId == null) {
            if (other.dropLocationId != null) {
                return false;
            }
        } else if (!dropLocationId.equals(other.dropLocationId)) {
            return false;
        }
        if (pickupLocationId == null) {
            if (other.pickupLocationId != null) {
                return false;
            }
        } else if (!pickupLocationId.equals(other.pickupLocationId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ActivityTO [activityId=" + id + ", tripId=" + tripId
                + ", siteId=" + siteId + ", pickupLocationId="
                + pickupLocationId + ", dropLocationId=" + dropLocationId
                + ", activityIndex=" + activityIndex + ", activityTime="
                + activityTime + ", activityTypeId=" + activityTypeId
                + ", comments=" + comments + "]";
    }




}
