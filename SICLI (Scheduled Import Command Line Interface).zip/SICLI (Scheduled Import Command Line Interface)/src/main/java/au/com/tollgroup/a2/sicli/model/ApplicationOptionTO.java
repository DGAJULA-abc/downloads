package au.com.tollgroup.a2.sicli.model;

//import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class ApplicationOptionTO {

	private Long applicationOptionId;
	private Long siteId;
	private String userId;
	private String optionName;
	private String optionValue;

	public ApplicationOptionTO() {
	}

	public ApplicationOptionTO(
			Long applicationOptionId,
			Long siteId,
			String userId,
			String optionName,
			String optionValue) {
		super();
		this.applicationOptionId = applicationOptionId;
		this.siteId = siteId;
		this.userId = userId;
		this.optionName = optionName;
		this.optionValue = optionValue;
	}

	public String getOptionName() {
		return optionName;
	}

	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	public String getOptionValue() {
		return optionValue;
	}

	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}

	public Long getApplicationOptionId() {
		return applicationOptionId;
	}

	public void setApplicationOptionId(Long applicationOptionId) {
		this.applicationOptionId = applicationOptionId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((applicationOptionId == null) ? 0 : applicationOptionId
						.hashCode());
		result = prime * result + ((siteId == null) ? 0 : siteId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ApplicationOptionTO other = (ApplicationOptionTO) obj;
		if (applicationOptionId == null) {
			if (other.applicationOptionId != null) {
				return false;
			}
		} else if (!applicationOptionId.equals(other.applicationOptionId)) {
			return false;
		}
		if (siteId == null) {
			if (other.siteId != null) {
				return false;
			}
		} else if (!siteId.equals(other.siteId)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "ApplicationOptionTO [applicationOptionId="
				+ applicationOptionId + ", siteId=" + siteId + ", userId="
						+ userId + ", optionName=" + optionName + ", optionValue="
								+ optionValue + "]";
	}

}
