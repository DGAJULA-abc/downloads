package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.xml.bind.annotation.XmlRootElement;



/**
 * Axiom - trimmed down Service fields for Return Creation.
 */
@XmlRootElement
public class AxiomServiceReturnTO implements Serializable {

	private static final long serialVersionUID = 7973673448262694L;

	private long id;
	private String homeLocationId;
	private Long loadId;
	private String locationIdDrop;
	private String locationIdPickup;
	private String unit1;
	private Double qty1;
	private String unit2;
	private Double qty2;
	private String unit3;
	private Double qty3;
	private String unit4;
	private Double qty4;
	private String unit5;
	private Double qty5;
	private String unit6;
	private Double qty6;
	private String unit7;
	private Double qty7;
	private String unit8;
	private Double qty8;
	private String serviceNo;
	private Long tripId;
	private long siteId;
	private Date serviceDate;
	private String serviceDesc;
	private String customerId;
	private Long driverId;
	private String truckId;
	private String trailerId;
	private String containerId;
	private Boolean offsiderUsed;
	private String docket;
	private String trailerIdTag;
	private String loadTypeId;
	private String serviceTypeId;
	private String enteredBy;

	public String getHomeLocationId() {
		return homeLocationId;
	}

	public void setHomeLocationId(String homeLocationId) {
		this.homeLocationId = homeLocationId;
	}

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	public String getLocationIdDrop() {
		return locationIdDrop;
	}

	public void setLocationIdDrop(String locationIdDrop) {
		this.locationIdDrop = locationIdDrop;
	}
	public String getLocationIdPickup() {
		return locationIdPickup;
	}
	public void setLocationIdPickup(String locationIdPickup) {
		this.locationIdPickup = locationIdPickup;
	}

	public String getUnit1() {
		return unit1;
	}

	public void setUnit1(String unit1) {
		this.unit1 = unit1;
	}
	public Double getQty1() {
		return qty1;
	}
	public void setQty1(Double qty1) {
		this.qty1 = qty1;
	}

	public String getUnit2() {
		return unit2;
	}

	public void setUnit2(String unit2) {
		this.unit2 = unit2;
	}
	public Double getQty2() {
		return qty2;
	}
	public void setQty2(Double qty2) {
		this.qty2 = qty2;
	}

	public String getUnit3() {
		return unit3;
	}

	public void setUnit3(String unit3) {
		this.unit3 = unit3;
	}
	public Double getQty3() {
		return qty3;
	}
	public void setQty3(Double qty3) {
		this.qty3 = qty3;
	}

	public String getUnit4() {
		return unit4;
	}

	public void setUnit4(String unit4) {
		this.unit4 = unit4;
	}
	public Double getQty4() {
		return qty4;
	}
	public void setQty4(Double qty4) {
		this.qty4 = qty4;
	}

	public String getUnit5() {
		return unit5;
	}

	public void setUnit5(String unit5) {
		this.unit5 = unit5;
	}
	public Double getQty5() {
		return qty5;
	}
	public void setQty5(Double qty5) {
		this.qty5 = qty5;
	}

	public String getUnit6() {
		return unit6;
	}

	public void setUnit6(String unit6) {
		this.unit6 = unit6;
	}
	public Double getQty6() {
		return qty6;
	}
	public void setQty6(Double qty6) {
		this.qty6 = qty6;
	}

	public String getUnit7() {
		return unit7;
	}

	public void setUnit7(String unit7) {
		this.unit7 = unit7;
	}
	public Double getQty7() {
		return qty7;
	}
	public void setQty7(Double qty7) {
		this.qty7 = qty7;
	}

	public String getUnit8() {
		return unit8;
	}

	public void setUnit8(String unit8) {
		this.unit8 = unit8;
	}
	public Double getQty8() {
		return qty8;
	}
	public void setQty8(Double qty8) {
		this.qty8 = qty8;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public long getSiteId() {
		return siteId;
	}

	public void setSiteId(long siteId) {
		this.siteId = siteId;
	}

	public Date getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getDriverId() {
		return driverId;
	}

	public void setDriverId(Long driverId) {
		this.driverId = driverId;
	}

	public String getTruckId() {
		return truckId;
	}

	public void setTruckId(String truckId) {
		this.truckId = truckId;
	}

	public String getTrailerId() {
		return trailerId;
	}

	public void setTrailerId(String trailerId) {
		this.trailerId = trailerId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public Boolean getOffsiderUsed() {
		return offsiderUsed;
	}

	public void setOffsiderUsed(Boolean offsiderUsed) {
		this.offsiderUsed = offsiderUsed;
	}
	public String getDocket() {
		return docket;
	}
	public void setDocket(String docket) {
		this.docket = docket;
	}
	public String getTrailerIdTag() {
		return trailerIdTag;
	}
	public void setTrailerIdTag(String trailerIdTag) {
		this.trailerIdTag = trailerIdTag;
	}

	public String getLoadTypeId() {
		return loadTypeId;
	}

	public void setLoadTypeId(String loadTypeId) {
		this.loadTypeId = loadTypeId;
	}

	public String getServiceTypeId() {
		return serviceTypeId;
	}

	public void setServiceTypeId(String serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}

	public String getEnteredBy() {
		return enteredBy;
	}

	public void setEnteredBy(String enteredBy) {
		this.enteredBy = enteredBy;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
