package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.xml.bind.annotation.XmlRootElement;



/**
 * Axiom - trimmed down Service fields.
 */
@XmlRootElement
public class AxiomServiceTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;
	
	private long id;
	private Date serviceDate;

	private Long driverId;

	private String truckId;
	private String trailerId;

	private String locationIdPickup;
	private String locationIdDrop;

	private Double qty1;
	private String unit1;
	private Double qty2;
	private String unit2;
	private Double qty3;
	private String unit3;
	private Double qty4;
	private String unit4;
	private Double qty5;
	private String unit5;
	private Double qty6;
	private String unit6;
	private Double qty7;
	private String unit7;
	private Double qty8;
	private String unit8;

	private String docket;
	private String trailerIdTag;

	private Long tripId;
	private Integer tripSeq;

	private boolean delivered;

	public Date getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}

	public Long getDriverId() {
		return driverId;
	}

	public void setDriverId(Long driverId) {
		this.driverId = driverId;
	}

	public String getTruckId() {
		return truckId;
	}

	public void setTruckId(String truckId) {
		this.truckId = truckId;
	}

	public String getTrailerId() {
		return trailerId;
	}

	public void setTrailerId(String trailerId) {
		this.trailerId = trailerId;
	}

	public String getLocationIdPickup() {
		return locationIdPickup;
	}

	public void setLocationIdPickup(String locationIdPickup) {
		this.locationIdPickup = locationIdPickup;
	}

	public String getLocationIdDrop() {
		return locationIdDrop;
	}

	public void setLocationIdDrop(String locationIdDrop) {
		this.locationIdDrop = locationIdDrop;
	}

	public Double getQty1() {
		return qty1;
	}

	public void setQty1(Double qty1) {
		this.qty1 = qty1;
	}

	public String getUnit1() {
		return unit1;
	}

	public void setUnit1(String unit1) {
		this.unit1 = unit1;
	}

	public Double getQty2() {
		return qty2;
	}

	public void setQty2(Double qty2) {
		this.qty2 = qty2;
	}

	public String getUnit2() {
		return unit2;
	}

	public void setUnit2(String unit2) {
		this.unit2 = unit2;
	}

	public Double getQty3() {
		return qty3;
	}

	public void setQty3(Double qty3) {
		this.qty3 = qty3;
	}

	public String getUnit3() {
		return unit3;
	}

	public void setUnit3(String unit3) {
		this.unit3 = unit3;
	}

	public Double getQty4() {
		return qty4;
	}

	public void setQty4(Double qty4) {
		this.qty4 = qty4;
	}

	public String getUnit4() {
		return unit4;
	}

	public void setUnit4(String unit4) {
		this.unit4 = unit4;
	}

	public Double getQty5() {
		return qty5;
	}

	public void setQty5(Double qty5) {
		this.qty5 = qty5;
	}

	public String getUnit5() {
		return unit5;
	}

	public void setUnit5(String unit5) {
		this.unit5 = unit5;
	}

	public Double getQty6() {
		return qty6;
	}

	public void setQty6(Double qty6) {
		this.qty6 = qty6;
	}

	public String getUnit6() {
		return unit6;
	}

	public void setUnit6(String unit6) {
		this.unit6 = unit6;
	}

	public Double getQty7() {
		return qty7;
	}

	public void setQty7(Double qty7) {
		this.qty7 = qty7;
	}

	public String getUnit7() {
		return unit7;
	}

	public void setUnit7(String unit7) {
		this.unit7 = unit7;
	}

	public Double getQty8() {
		return qty8;
	}

	public void setQty8(Double qty8) {
		this.qty8 = qty8;
	}

	public String getUnit8() {
		return unit8;
	}

	public void setUnit8(String unit8) {
		this.unit8 = unit8;
	}

	public String getDocket() {
		return docket;
	}

	public void setDocket(String docket) {
		this.docket = docket;
	}

	public String getTrailerIdTag() {
		return trailerIdTag;
	}

	public void setTrailerIdTag(String trailerIdTag) {
		this.trailerIdTag = trailerIdTag;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public Integer getTripSeq() {
		return tripSeq;
	}

	public void setTripSeq(Integer tripSeq) {
		this.tripSeq = tripSeq;
	}

	public boolean isDelivered() {
		return delivered;
	}

	public void setDelivered(boolean delivered) {
		this.delivered = delivered;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
