package au.com.tollgroup.a2.sicli.model;

import java.sql.Timestamp;

public class CompanyTO {
	public String COMPANYID;          
	public long SITEID;               
	public String COMPANYTYPEID;
	public long PERSONID;
	public String CUSTOMERID;
	public long ACTIVE;   
	public long PAFORMAT;  
	public String CONTAGREESIGHTBY;
	public Timestamp CONTAGREESIGHTDATE;
	public String getCOMPANYID() {
		return COMPANYID;
	}
	public void setCOMPANYID(String cOMPANYID) {
		COMPANYID = cOMPANYID;
	}
	public long getSITEID() {
		return SITEID;
	}
	public void setSITEID(long sITEID) {
		SITEID = sITEID;
	}
	public String getCOMPANYTYPEID() {
		return COMPANYTYPEID;
	}
	public void setCOMPANYTYPEID(String cOMPANYTYPEID) {
		COMPANYTYPEID = cOMPANYTYPEID;
	}
	public long getPERSONID() {
		return PERSONID;
	}
	public void setPERSONID(long pERSONID) {
		PERSONID = pERSONID;
	}
	public String getCUSTOMERID() {
		return CUSTOMERID;
	}
	public void setCUSTOMERID(String cUSTOMERID) {
		CUSTOMERID = cUSTOMERID;
	}
	public long getACTIVE() {
		return ACTIVE;
	}
	public void setACTIVE(long aCTIVE) {
		ACTIVE = aCTIVE;
	}
	public long getPAFORMAT() {
		return PAFORMAT;
	}
	public void setPAFORMAT(long pAFORMAT) {
		PAFORMAT = pAFORMAT;
	}
	public String getCONTAGREESIGHTBY() {
		return CONTAGREESIGHTBY;
	}
	public void setCONTAGREESIGHTBY(String cONTAGREESIGHTBY) {
		CONTAGREESIGHTBY = cONTAGREESIGHTBY;
	}
	public Timestamp getCONTAGREESIGHTDATE() {
		return CONTAGREESIGHTDATE;
	}
	public void setCONTAGREESIGHTDATE(Timestamp cONTAGREESIGHTDATE) {
		CONTAGREESIGHTDATE = cONTAGREESIGHTDATE;
	}
	@Override
	public String toString() {
		return "CompanyTO [COMPANYID=" + COMPANYID + ", SITEID=" + SITEID + ", COMPANYTYPEID=" + COMPANYTYPEID
				+ ", PERSONID=" + PERSONID + ", CUSTOMERID=" + CUSTOMERID + ", ACTIVE=" + ACTIVE + ", PAFORMAT="
				+ PAFORMAT + ", CONTAGREESIGHTBY=" + CONTAGREESIGHTBY + ", CONTAGREESIGHTDATE=" + CONTAGREESIGHTDATE
				+ "]";
	}     
	
	

}
