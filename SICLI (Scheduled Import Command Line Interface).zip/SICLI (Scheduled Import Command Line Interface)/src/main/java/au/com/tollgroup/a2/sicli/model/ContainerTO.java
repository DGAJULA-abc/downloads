package au.com.tollgroup.a2.sicli.model;

import java.sql.Timestamp;

import oracle.sql.TIMESTAMP;

public class ContainerTO {
	public String CONTAINERID;
	public long SITEID;
	public String CONTAINERDESC;
	public String COMPANYID;
	public long ONHIRE;
	public String LOCATIONID;
	public Timestamp DROPDATE;
	public Timestamp PICKUPDATE;
	public long WEIGHTTONNES;
	public long PERMANENT;
	public String CONTAINERSTATUSID;
	public Timestamp STATUSUPDATED;

	public String getCONTAINERID() {
		return CONTAINERID;
	}

	public void setCONTAINERID(String cONTAINERID) {
		CONTAINERID = cONTAINERID;
	}

	public long getSITEID() {
		return SITEID;
	}

	public void setSITEID(long sITEID) {
		SITEID = sITEID;
	}

	public String getCONTAINERDESC() {
		return CONTAINERDESC;
	}

	public void setCONTAINERDESC(String cONTAINERDESC) {
		CONTAINERDESC = cONTAINERDESC;
	}

	public String getCOMPANYID() {
		return COMPANYID;
	}

	public void setCOMPANYID(String cOMPANYID) {
		COMPANYID = cOMPANYID;
	}

	public long getONHIRE() {
		return ONHIRE;
	}

	public void setONHIRE(long oNHIRE) {
		ONHIRE = oNHIRE;
	}

	public String getLOCATIONID() {
		return LOCATIONID;
	}

	public void setLOCATIONID(String lOCATIONID) {
		LOCATIONID = lOCATIONID;
	}

	public Timestamp getDROPDATE() {
		return DROPDATE;
	}

	public void setDROPDATE(Timestamp dROPDATE) {
		DROPDATE = dROPDATE;
	}

	public Timestamp getPICKUPDATE() {
		return PICKUPDATE;
	}

	public void setPICKUPDATE(Timestamp pICKUPDATE) {
		PICKUPDATE = pICKUPDATE;
	}

	public long getWEIGHTTONNES() {
		return WEIGHTTONNES;
	}

	public void setWEIGHTTONNES(long wEIGHTTONNES) {
		WEIGHTTONNES = wEIGHTTONNES;
	}

	public long getPERMANENT() {
		return PERMANENT;
	}

	public void setPERMANENT(long pERMANENT) {
		PERMANENT = pERMANENT;
	}

	public String getCONTAINERSTATUSID() {
		return CONTAINERSTATUSID;
	}

	public void setCONTAINERSTATUSID(String cONTAINERSTATUSID) {
		CONTAINERSTATUSID = cONTAINERSTATUSID;
	}

	public Timestamp getSTATUSUPDATED() {
		return STATUSUPDATED;
	}

	public void setSTATUSUPDATED(Timestamp sTATUSUPDATED) {
		STATUSUPDATED = sTATUSUPDATED;
	}

	@Override
	public String toString() {
		return "ContainerTO [CONTAINERID=" + CONTAINERID + ", SITEID=" + SITEID + ", CONTAINERDESC=" + CONTAINERDESC
				+ ", COMPANYID=" + COMPANYID + ", ONHIRE=" + ONHIRE + ", LOCATIONID=" + LOCATIONID + ", DROPDATE="
				+ DROPDATE + ", PICKUPDATE=" + PICKUPDATE + ", WEIGHTTONNES=" + WEIGHTTONNES + ", PERMANENT="
				+ PERMANENT + ", CONTAINERSTATUSID=" + CONTAINERSTATUSID + ", STATUSUPDATED=" + STATUSUPDATED + "]";
	}

}
