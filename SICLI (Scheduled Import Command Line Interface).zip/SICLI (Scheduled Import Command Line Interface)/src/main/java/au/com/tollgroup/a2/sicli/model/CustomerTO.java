package au.com.tollgroup.a2.sicli.model;

public class CustomerTO {
	
	private String CUSTOMERID ;             
	private Long SITEID    ;                  
	private Long PERSONID_CONTACT ;                  
	private Long PERSONID_BILLING   ;                 
	private String CUSTOMERGROUPID   ;                
	private Long INVFORMAT      ;                     
	private Long APPLYGST     ;              
	private Long INTERNALCUSTOMER    ;        
	private Long ALLOWCONTPICKUPDROP  ;      
	private Long FUELLEVYCHARGERATE  ;             
	private Long FUELLEVYPAYRATE     ;             
	private String SCHEDULEENTRYFORM   ;              
	private String SCHEDULEIMPORTFUNCTION   ;         
	private Long UNIQUELOADNO      ;       
	private Long NUMERICLOADNO  ;         
	private Long LOADNOMINLEN   ;                    
	private Long LOADNOMAXLEN  ;                    
	private String GLCODE_BRANCH  ;                   
	private Long ACTIVE    ;                 
	private Long CNFORMAT  ;                        
	private String INVUNIT1 ;                       
	private String INVUNIT2   ;                       
	private String INVUNIT3   ;                       
	private String INVUNIT4  ;                        
	private String INVUNIT5   ;                       
	private String INVUNIT6   ;                       
	private String INVUNIT7   ;                       
	private String INVUNIT8   ;                       
	private String CUSTOMBILLINGNAME1   ;            
	private String CUSTOMBILLINGNAME2   ;            
	private String CUSTOMBILLINGNAME3   ;            
	private String CUSTOMBILLINGVALUE1   ;           
	private String CUSTOMBILLINGVALUE2 ;             
	private String CUSTOMBILLINGVALUE3    ;          
	private Long INVOICEREMARKSMODE    ;
	public String getCUSTOMERID() {
		return CUSTOMERID;
	}
	public void setCUSTOMERID(String cUSTOMERID) {
		CUSTOMERID = cUSTOMERID;
	}
	public Long getSITEID() {
		return SITEID;
	}
	public void setSITEID(Long sITEID) {
		SITEID = sITEID;
	}
	public Long getPERSONID_CONTACT() {
		return PERSONID_CONTACT;
	}
	public void setPERSONID_CONTACT(Long pERSONID_CONTACT) {
		PERSONID_CONTACT = pERSONID_CONTACT;
	}
	public Long getPERSONID_BILLING() {
		return PERSONID_BILLING;
	}
	public void setPERSONID_BILLING(Long pERSONID_BILLING) {
		PERSONID_BILLING = pERSONID_BILLING;
	}
	public String getCUSTOMERGROUPID() {
		return CUSTOMERGROUPID;
	}
	public void setCUSTOMERGROUPID(String cUSTOMERGROUPID) {
		CUSTOMERGROUPID = cUSTOMERGROUPID;
	}
	public Long getINVFORMAT() {
		return INVFORMAT;
	}
	public void setINVFORMAT(Long iNVFORMAT) {
		INVFORMAT = iNVFORMAT;
	}
	public Long getAPPLYGST() {
		return APPLYGST;
	}
	public void setAPPLYGST(Long aPPLYGST) {
		APPLYGST = aPPLYGST;
	}
	public Long getINTERNALCUSTOMER() {
		return INTERNALCUSTOMER;
	}
	public void setINTERNALCUSTOMER(Long iNTERNALCUSTOMER) {
		INTERNALCUSTOMER = iNTERNALCUSTOMER;
	}
	public Long getALLOWCONTPICKUPDROP() {
		return ALLOWCONTPICKUPDROP;
	}
	public void setALLOWCONTPICKUPDROP(Long aLLOWCONTPICKUPDROP) {
		ALLOWCONTPICKUPDROP = aLLOWCONTPICKUPDROP;
	}
	public Long getFUELLEVYCHARGERATE() {
		return FUELLEVYCHARGERATE;
	}
	public void setFUELLEVYCHARGERATE(Long fUELLEVYCHARGERATE) {
		FUELLEVYCHARGERATE = fUELLEVYCHARGERATE;
	}
	public Long getFUELLEVYPAYRATE() {
		return FUELLEVYPAYRATE;
	}
	public void setFUELLEVYPAYRATE(Long fUELLEVYPAYRATE) {
		FUELLEVYPAYRATE = fUELLEVYPAYRATE;
	}
	public String getSCHEDULEENTRYFORM() {
		return SCHEDULEENTRYFORM;
	}
	public void setSCHEDULEENTRYFORM(String sCHEDULEENTRYFORM) {
		SCHEDULEENTRYFORM = sCHEDULEENTRYFORM;
	}
	public String getSCHEDULEIMPORTFUNCTION() {
		return SCHEDULEIMPORTFUNCTION;
	}
	public void setSCHEDULEIMPORTFUNCTION(String sCHEDULEIMPORTFUNCTION) {
		SCHEDULEIMPORTFUNCTION = sCHEDULEIMPORTFUNCTION;
	}
	public Long getUNIQUELOADNO() {
		return UNIQUELOADNO;
	}
	public void setUNIQUELOADNO(Long uNIQUELOADNO) {
		UNIQUELOADNO = uNIQUELOADNO;
	}
	public Long getNUMERICLOADNO() {
		return NUMERICLOADNO;
	}
	public void setNUMERICLOADNO(Long nUMERICLOADNO) {
		NUMERICLOADNO = nUMERICLOADNO;
	}
	public Long getLOADNOMINLEN() {
		return LOADNOMINLEN;
	}
	public void setLOADNOMINLEN(Long lOADNOMINLEN) {
		LOADNOMINLEN = lOADNOMINLEN;
	}
	public Long getLOADNOMAXLEN() {
		return LOADNOMAXLEN;
	}
	public void setLOADNOMAXLEN(Long lOADNOMAXLEN) {
		LOADNOMAXLEN = lOADNOMAXLEN;
	}
	public String getGLCODE_BRANCH() {
		return GLCODE_BRANCH;
	}
	public void setGLCODE_BRANCH(String gLCODE_BRANCH) {
		GLCODE_BRANCH = gLCODE_BRANCH;
	}
	public Long getACTIVE() {
		return ACTIVE;
	}
	public void setACTIVE(Long aCTIVE) {
		ACTIVE = aCTIVE;
	}
	public Long getCNFORMAT() {
		return CNFORMAT;
	}
	public void setCNFORMAT(Long cNFORMAT) {
		CNFORMAT = cNFORMAT;
	}
	public String getINVUNIT1() {
		return INVUNIT1;
	}
	public void setINVUNIT1(String iNVUNIT1) {
		INVUNIT1 = iNVUNIT1;
	}
	public String getINVUNIT2() {
		return INVUNIT2;
	}
	public void setINVUNIT2(String iNVUNIT2) {
		INVUNIT2 = iNVUNIT2;
	}
	public String getINVUNIT3() {
		return INVUNIT3;
	}
	public void setINVUNIT3(String iNVUNIT3) {
		INVUNIT3 = iNVUNIT3;
	}
	public String getINVUNIT4() {
		return INVUNIT4;
	}
	public void setINVUNIT4(String iNVUNIT4) {
		INVUNIT4 = iNVUNIT4;
	}
	public String getINVUNIT5() {
		return INVUNIT5;
	}
	public void setINVUNIT5(String iNVUNIT5) {
		INVUNIT5 = iNVUNIT5;
	}
	public String getINVUNIT6() {
		return INVUNIT6;
	}
	public void setINVUNIT6(String iNVUNIT6) {
		INVUNIT6 = iNVUNIT6;
	}
	public String getINVUNIT7() {
		return INVUNIT7;
	}
	public void setINVUNIT7(String iNVUNIT7) {
		INVUNIT7 = iNVUNIT7;
	}
	public String getINVUNIT8() {
		return INVUNIT8;
	}
	public void setINVUNIT8(String iNVUNIT8) {
		INVUNIT8 = iNVUNIT8;
	}
	public String getCUSTOMBILLINGNAME1() {
		return CUSTOMBILLINGNAME1;
	}
	public void setCUSTOMBILLINGNAME1(String cUSTOMBILLINGNAME1) {
		CUSTOMBILLINGNAME1 = cUSTOMBILLINGNAME1;
	}
	public String getCUSTOMBILLINGNAME2() {
		return CUSTOMBILLINGNAME2;
	}
	public void setCUSTOMBILLINGNAME2(String cUSTOMBILLINGNAME2) {
		CUSTOMBILLINGNAME2 = cUSTOMBILLINGNAME2;
	}
	public String getCUSTOMBILLINGNAME3() {
		return CUSTOMBILLINGNAME3;
	}
	public void setCUSTOMBILLINGNAME3(String cUSTOMBILLINGNAME3) {
		CUSTOMBILLINGNAME3 = cUSTOMBILLINGNAME3;
	}
	public String getCUSTOMBILLINGVALUE1() {
		return CUSTOMBILLINGVALUE1;
	}
	public void setCUSTOMBILLINGVALUE1(String cUSTOMBILLINGVALUE1) {
		CUSTOMBILLINGVALUE1 = cUSTOMBILLINGVALUE1;
	}
	public String getCUSTOMBILLINGVALUE2() {
		return CUSTOMBILLINGVALUE2;
	}
	public void setCUSTOMBILLINGVALUE2(String cUSTOMBILLINGVALUE2) {
		CUSTOMBILLINGVALUE2 = cUSTOMBILLINGVALUE2;
	}
	public String getCUSTOMBILLINGVALUE3() {
		return CUSTOMBILLINGVALUE3;
	}
	public void setCUSTOMBILLINGVALUE3(String cUSTOMBILLINGVALUE3) {
		CUSTOMBILLINGVALUE3 = cUSTOMBILLINGVALUE3;
	}
	public Long getINVOICEREMARKSMODE() {
		return INVOICEREMARKSMODE;
	}
	public void setINVOICEREMARKSMODE(Long iNVOICEREMARKSMODE) {
		INVOICEREMARKSMODE = iNVOICEREMARKSMODE;
	}

}
