package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;



public class DespatchDecisionTO implements Serializable {

    private static final long serialVersionUID = -298645463037165662L;
    
    private Long id;
    private Long siteId;
    private String serviceType;
    private String loadType;
    private Integer driverType;
    private Long driverId;
    private String locationIdPickup;
    private String locationTypePickup;
    private String locationIdDrop;
    private String locationTypeDrop;
    private boolean usesTimeTable;
    private String enteredBy;
    private String driver;

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getLoadType() {
        return loadType;
    }

    public void setLoadType(String loadType) {
        this.loadType = loadType;
    }

    public Integer getDriverType() {
        return driverType;
    }

    public void setDriverType(Integer driverType) {
        this.driverType = driverType;
    }

    public Long getDriverId() {
        return driverId;
    }

    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    public String getLocationIdPickup() {
        return locationIdPickup;
    }

    public void setLocationIdPickup(String locationIdPickup) {
        this.locationIdPickup = locationIdPickup;
    }

    public String getLocationTypePickup() {
        return locationTypePickup;
    }

    public void setLocationTypePickup(String locationTypePickup) {
        this.locationTypePickup = locationTypePickup;
    }

    public String getLocationIdDrop() {
        return locationIdDrop;
    }

    public void setLocationIdDrop(String locationIdDrop) {
        this.locationIdDrop = locationIdDrop;
    }

    public String getLocationTypeDrop() {
        return locationTypeDrop;
    }

    public void setLocationTypeDrop(String locationTypeDrop) {
        this.locationTypeDrop = locationTypeDrop;
    }

    public boolean getUsesTimeTable() {
        return usesTimeTable;
    }

    public void setUsesTimeTable(boolean usesTimeTable) {
        this.usesTimeTable = usesTimeTable;
    }

    public String getEnteredBy() {
        return enteredBy;
    }

    public void setEnteredBy(String enteredBy) {
        this.enteredBy = enteredBy;
    }

    @Override
    public String toString() {
        return "DespatchDecisionTO [siteId=" + siteId + ", serviceType="
                + serviceType + ", loadType=" + loadType + ", driverType="
                + driverType + ", driverId=" + driverId + ", locationIdPickup="
                + locationIdPickup + ", locationTypePickup="
                + locationTypePickup + ", locationIdDrop=" + locationIdDrop
                + ", locationTypeDrop=" + locationTypeDrop + ", usesTimeTable="
                + usesTimeTable + ", enteredBy=" + enteredBy + ", id=" + id
                + "]";
    }

    /**
     * @return the driver
     */
    public String getDriver() {
        return driver;
    }

    /**
     * @param driver the driver to set
     */
    public void setDriver(String driver) {
        this.driver = driver;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
