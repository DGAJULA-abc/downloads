package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.List;

public class DriverResourceTO implements Serializable {
	
	/**
	 * Universal serial id 
	 */
	private static final long serialVersionUID = 8755412579169060529L;
	
	private Long id;
	private Long MASTER_SITEID;
	private int VersionId;
	private boolean isActive;
	private String TrailerId;
	private List<TripResourceTO> trips;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the trips
	 */
	public List<TripResourceTO> getTrips() {
		return trips;
	}
	
	/**
	 * @param trips
	 *            the trips to set
	 */
	public void setTrips(List<TripResourceTO> trips) {
		this.trips = trips;
	}

	@Override
	public String toString() {
		return "DriverResourceTO [id=" + id + ", trips=" + trips + "]";
	}


	public int getVersionId() {
		return VersionId;
	}

	public void setVersionId(int versionId) {
		VersionId = versionId;
	}

	public Long getMASTER_SITEID() {
		return MASTER_SITEID;
	}

	public void setMASTER_SITEID(Long mASTER_SITEID) {
		MASTER_SITEID = mASTER_SITEID;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getTrailerId() {
		return TrailerId;
	}

	public void setTrailerId(String trailerId) {
		TrailerId = trailerId;
	}

	
}
