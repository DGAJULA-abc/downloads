package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;




public class DriverTO implements Serializable {

    /**
     * Universal serial id
     */
    private static final long serialVersionUID = 8532240012960257674L;

    
    private Long id;    
    private Long siteId;    
    private Long personId;    
    private String firstName;    
    private String surname;    
    private String employeeName;    
    private String mdtCode;    
    private Boolean groupDriver;    
    private String companyId;    
    private String vendorName;	
    private String truckId;   
    private String trailerId;   
    private String payBasisId;    
    private String homeLocationId;    
    private Boolean active;    
    private String mobile;    
    private Date invalidationDate;    
    private Boolean entityDriver;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the siteId
     */
    public Long getSiteId() {
        return siteId;
    }

    /**
     * @param siteId the siteId to set
     */
    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    /**
     * @return the personId
     */
    public Long getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    /**
     * @return the employeeName
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * @param employeeName the employeeName to set
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    /**
     * @return the truckId
     */
    public String getTruckId() {
        return truckId;
    }

    /**
     * @param truckId the truckId to set
     */
    public void setTruckId(String truckId) {
        this.truckId = truckId;
    }

    /**
     * @return the trailerId
     */
    public String getTrailerId() {
        return trailerId;
    }

    /**
     * @param trailerId the trailerId to set
     */
    public void setTrailerId(String trailerId) {
        this.trailerId = trailerId;
    }

    /**
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * @return the companyId
     */
    public String getCompanyId() {
        return companyId;
    }

    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    /**
     * @return the invalidationDate
     */
    public Date getInvalidationDate() {
        return invalidationDate;
    }

    /**
     * @param invalidationDate
     *            the invalidationDate to set
     */
    public void setInvalidationDate(Date invalidationDate) {
        this.invalidationDate = invalidationDate;
    }

    /**
     * @return the entityDriver
     */
    public Boolean getEntityDriver() {
        return entityDriver;
    }

    /**
     * @param entityDriver
     *            the entityDriver to set
     */
    public void setEntityDriver(Boolean entityDriver) {
        this.entityDriver = entityDriver;
    }

    /**
     * @return the mdtCode
     */
    public String getMdtCode() {
        return mdtCode;
    }

    /**
     * @param mdtCode
     *            the mdtCode to set
     */
    public void setMdtCode(String mdtCode) {
        this.mdtCode = mdtCode;
    }

    /**
     * @return the groupDriver
     */
    public Boolean getGroupDriver() {
        return groupDriver;
    }

    /**
     * @param groupDriver
     *            the groupDriver to set
     */
    public void setGroupDriver(Boolean groupDriver) {
        this.groupDriver = groupDriver;
    }

    /**
     * @return the payBasisId
     */
    public String getPayBasisId() {
        return payBasisId;
    }

    /**
     * @param payBasisId
     *            the payBasisId to set
     */
    public void setPayBasisId(String payBasisId) {
        this.payBasisId = payBasisId;
    }

    /**
     * @return the homeLocationId
     */
    public String getHomeLocationId() {
        return homeLocationId;
    }

    /**
     * @param homeLocationId
     *            the homeLocationId to set
     */
    public void setHomeLocationId(String homeLocationId) {
        this.homeLocationId = homeLocationId;
    }

    /**
     * @return the mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile
     *            the mobile to set
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }    
	
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        DriverTO other = (DriverTO) obj;
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "DriverTO [id=" + id + ", personId=" + personId
                + ", employeeName=" + employeeName + ", truckId=" + truckId
                + ", trailerId=" + trailerId + ", firstName=" + firstName
                + ", surname=" + surname + ", companyId=" + companyId
                + ", siteId=" + siteId + ", active=" + active
                + ", invalidationDate=" + invalidationDate + ", entityDriver="
                + entityDriver + ", mdtCode=" + mdtCode + ", groupDriver="
                + groupDriver + ", payBasisId=" + payBasisId
                + ", homeLocationId=" + homeLocationId + ", mobile=" + mobile
                + ", vendorName=" + vendorName
                + "]";
    }

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
}
