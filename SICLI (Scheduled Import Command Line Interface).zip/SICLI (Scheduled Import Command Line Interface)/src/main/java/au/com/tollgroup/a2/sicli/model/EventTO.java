package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;

import java.util.Date;

public class EventTO implements Serializable {

 private static final long serialVersionUID = 161397193316283789L;

 private Long key;
 private Long id;
 private int eventTypeId;
 private Long dockId;
 private String locationId;
 private Long serviceId;
 private String trailerId;
 private Long tripId;
 private String truckId;
 private long siteId;
 private Long driverId;
 private String trailerTagId;
 private Date loggedDateTime;
 private Double value1;
 private Double value2;
 private String textValue;
 private String userId;
 private Date time1;
 private Date time2;
 private String textValue2;
 private boolean exception;
 private String exceptiondesc;
 private boolean exported;
 private boolean eventAdjusted;
 private String datasourceId;
 private Double latitude;
 private Double longitude;
 private Long fleetId;
 private Long unitId;
 private Long vehicleId;
 private String mdrego;
 private Integer mdtcode;
 private Date mdservertime;
 private Date created;
 private Integer certainty;
 private Boolean compliant;
 private String comments;

 // Display only fields
 private String eventLevel;
 private Date eventTime;
 private String eventDescription;
 private boolean todexportable;
 private String tripIdCust;
 private String loadNo;
 private String employeeName;
 private String companyId;
 private String firstName;
 private String lastName;

 // Trip and service numbers
 private Long tripNo;
 private String serviceNo;

 public EventTO() {
 }

 public EventTO(
                long id,
                int eventTypeId,
                String locationId,
                String trailerId,
                String truckId,
                long siteId,
                String trailerTagId,
                boolean exception,
                boolean exported,
                boolean eventadjusted) {
     this.eventTypeId = eventTypeId;
     this.locationId = locationId;
     this.trailerId = trailerId;
     this.truckId = truckId;
     this.siteId = siteId;
     this.trailerTagId = trailerTagId;
     this.exception = exception;
     this.exported = exported;
     this.eventAdjusted = eventadjusted;
 }

 /**
  * @return the eventTypeId
  */
 public int getEventTypeId() {
     return eventTypeId;
 }

 /**
  * @param eventTypeId
  *            the eventTypeId to set
  */
 public void setEventTypeId(int eventTypeId) {
     this.eventTypeId = eventTypeId;
 }

 /**
  * @return the dockId
  */
 public Long getDockId() {
     return dockId;
 }

 /**
  * @param dockId
  *            the dockId to set
  */
 public void setDockId(Long dockId) {
     this.dockId = dockId;
 }

 /**
  * @return the locationId
  */
 public String getLocationId() {
     return locationId;
 }

 /**
  * @param locationId
  *            the locationId to set
  */
 public void setLocationId(String locationId) {
     this.locationId = locationId;
 }

 /**
  * @return the serviceId
  */
 public Long getServiceId() {
     return serviceId;
 }

 /**
  * @param serviceId
  *            the serviceId to set
  */
 public void setServiceId(Long serviceId) {
     this.serviceId = serviceId;
 }

 /**
  * @return the trailerId
  */
 public String getTrailerId() {
     return trailerId;
 }

 /**
  * @param trailerId
  *            the trailerId to set
  */
 public void setTrailerId(String trailerId) {
     this.trailerId = trailerId;
 }

 /**
  * @return the tripId
  */
 public Long getTripId() {
     return tripId;
 }

 /**
  * @param tripId
  *            the tripId to set
  */
 public void setTripId(Long tripId) {
     this.tripId = tripId;
 }

 /**
  * @return the truckId
  */
 public String getTruckId() {
     return truckId;
 }

 /**
  * @param truckId
  *            the truckId to set
  */
 public void setTruckId(String truckId) {
     this.truckId = truckId;
 }

 /**
  * @return the siteId
  */
 public long getSiteId() {
     return siteId;
 }

 /**
  * @param siteId
  *            the siteId to set
  */
 public void setSiteId(long siteId) {
     this.siteId = siteId;
 }

 /**
  * @return the driverId
  */
 public Long getDriverId() {
     return driverId;
 }

 /**
  * @param driverId
  *            the driverId to set
  */
 public void setDriverId(Long driverId) {
     this.driverId = driverId;
 }

 /**
  * @return the trailerTagId
  */
 public String getTrailerTagId() {
     return trailerTagId;
 }

 /**
  * @param trailerTagId
  *            the trailerTagId to set
  */
 public void setTrailerTagId(String trailerTagId) {
     this.trailerTagId = trailerTagId;
 }

 /**
  * @return the loggedDateTime
  */
 public Date getLoggedDateTime() {
     return loggedDateTime;
 }

 /**
  * @param loggedDateTime
  *            the loggedDateTime to set
  */
 public void setLoggedDateTime(Date loggedDateTime) {
     this.loggedDateTime = loggedDateTime;
 }

 /**
  * @return the value1
  */
 public Double getValue1() {
     return value1;
 }

 /**
  * @param value1
  *            the value1 to set
  */
 public void setValue1(Double value1) {
     this.value1 = value1;
 }

 /**
  * @return the value2
  */
 public Double getValue2() {
     return value2;
 }

 /**
  * @param value2
  *            the value2 to set
  */
 public void setValue2(Double value2) {
     this.value2 = value2;
 }

 /**
  * @return the textValue
  */
 public String getTextValue() {
     return textValue;
 }

 /**
  * @param textValue
  *            the textValue to set
  */
 public void setTextValue(String textValue) {
     this.textValue = textValue;
 }

 /**
  * @return the userId
  */
 public String getUserId() {
     return userId;
 }

 /**
  * @param userId
  *            the userId to set
  */
 public void setUserId(String userId) {
     this.userId = userId;
 }

 /**
  * @return the time1
  */
 public Date getTime1() {
     return time1;
 }

 /**
  * @param time1
  *            the time1 to set
  */
 public void setTime1(Date time1) {
     this.time1 = time1;
 }

 /**
  * @return the time2
  */
 public Date getTime2() {
     return time2;
 }

 /**
  * @param time2
  *            the time2 to set
  */
 public void setTime2(Date time2) {
     this.time2 = time2;
 }

 /**
  * @return the textValue2
  */
 public String getTextValue2() {
     return textValue2;
 }

 /**
  * @param textValue2
  *            the textValue2 to set
  */
 public void setTextValue2(String textValue2) {
     this.textValue2 = textValue2;
 }

 /**
  * @return the exception
  */
 public boolean isException() {
     return exception;
 }

 /**
  * @param exception
  *            the exception to set
  */
 public void setException(boolean exception) {
     this.exception = exception;
 }

 /**
  * @return the exceptiondesc
  */
 public String getExceptiondesc() {
     return exceptiondesc;
 }

 /**
  * @param exceptiondesc
  *            the exceptiondesc to set
  */
 public void setExceptiondesc(String exceptiondesc) {
     this.exceptiondesc = exceptiondesc;
 }

 /**
  * @return the exported
  */
 public boolean isExported() {
     return exported;
 }

 /**
  * @param exported
  *            the exported to set
  */
 public void setExported(boolean exported) {
     this.exported = exported;
 }

 /**
  * @return the eventAdjusted
  */
 public boolean isEventAdjusted() {
     return eventAdjusted;
 }

 /**
  * @param eventAdjusted
  *            the eventAdjusted to set
  */
 public void setEventAdjusted(boolean eventAdjusted) {
     this.eventAdjusted = eventAdjusted;
 }

 /**
  * @return the datasourceId
  */
 public String getDatasourceId() {
     return datasourceId;
 }

 /**
  * @param datasourceId
  *            the datasourceId to set
  */
 public void setDatasourceId(String datasourceId) {
     this.datasourceId = datasourceId;
 }

 /**
  * @return the latitude
  */
 public Double getLatitude() {
     return latitude;
 }

 /**
  * @param latitude
  *            the latitude to set
  */
 public void setLatitude(Double latitude) {
     this.latitude = latitude;
 }

 /**
  * @return the longitude
  */
 public Double getLongitude() {
     return longitude;
 }

 /**
  * @param longitude
  *            the longitude to set
  */
 public void setLongitude(Double longitude) {
     this.longitude = longitude;
 }

 /**
  * @return the fleetId
  */
 public Long getFleetId() {
     return fleetId;
 }

 /**
  * @param fleetId
  *            the fleetId to set
  */
 public void setFleetId(Long fleetId) {
     this.fleetId = fleetId;
 }

 /**
  * @return the unitId
  */
 public Long getUnitId() {
     return unitId;
 }

 /**
  * @param unitId
  *            the unitId to set
  */
 public void setUnitId(Long unitId) {
     this.unitId = unitId;
 }

 /**
  * @return the vehicleId
  */
 public Long getVehicleId() {
     return vehicleId;
 }

 /**
  * @param vehicleId
  *            the vehicleId to set
  */
 public void setVehicleId(Long vehicleId) {
     this.vehicleId = vehicleId;
 }

 /**
  * @return the mdrego
  */
 public String getMdrego() {
     return mdrego;
 }

 /**
  * @param mdrego
  *            the mdrego to set
  */
 public void setMdrego(String mdrego) {
     this.mdrego = mdrego;
 }

 /**
  * @return the mdtcode
  */
 public Integer getMdtcode() {
     return mdtcode;
 }

 /**
  * @param mdtcode
  *            the mdtcode to set
  */
 public void setMdtcode(Integer mdtcode) {
     this.mdtcode = mdtcode;
 }

 /**
  * @return the mdservertime
  */
 public Date getMdservertime() {
     return mdservertime;
 }

 /**
  * @param mdservertime
  *            the mdservertime to set
  */
 public void setMdservertime(Date mdservertime) {
     this.mdservertime = mdservertime;
 }

 /**
  * @return the created
  */
 public Date getCreated() {
     return created;
 }

 /**
  * @param created
  *            the created to set
  */
 public void setCreated(Date created) {
     this.created = created;
 }

 /**
  * @return the certainty
  */
 public Integer getCertainty() {
     return certainty;
 }

 /**
  * @param certainty
  *            the certainty to set
  */
 public void setCertainty(Integer certainty) {
     this.certainty = certainty;
 }

 /**
  * @return the compliant
  */
 public Boolean getCompliant() {
     return compliant;
 }

 /**
  * @param compliant
  *            the compliant to set
  */
 public void setCompliant(Boolean compliant) {
     this.compliant = compliant;
 }

 /**
  * @return the comments
  */
 public String getComments() {
     return comments;
 }

 /**
  * @param comments
  *            the comments to set
  */
 public void setComments(String comments) {
     this.comments = comments;
 }

 /**
  * @return the eventLevel
  */
 public String getEventLevel() {
     return eventLevel;
 }

 /**
  * @param eventLevel
  *            the eventLevel to set
  */
 public void setEventLevel(String eventLevel) {
     this.eventLevel = eventLevel;
 }

 /**
  * @return the eventTime
  */
 public Date getEventTime() {
     return eventTime;
 }

 /**
  * @param eventTime
  *            the eventTime to set
  */
 public void setEventTime(Date eventTime) {
     this.eventTime = eventTime;
 }

 /**
  * @return the eventDescription
  */
 public String getEventDescription() {
     return eventDescription;
 }

 /**
  * @param eventDescription
  *            the eventDescription to set
  */
 public void setEventDescription(String eventDescription) {
     this.eventDescription = eventDescription;
 }

 /**
  * @return the todexportable
  */
 public boolean isTodexportable() {
     return todexportable;
 }

 /**
  * @param todexportable
  *            the todexportable to set
  */
 public void setTodexportable(boolean todexportable) {
     this.todexportable = todexportable;
 }

 /**
  * @return the tripIdCust
  */
 public String getTripIdCust() {
     return tripIdCust;
 }

 /**
  * @param tripIdCust
  *            the tripIdCust to set
  */
 public void setTripIdCust(String tripIdCust) {
     this.tripIdCust = tripIdCust;
 }

 /**
  * @return the loadNo
  */
 public String getLoadNo() {
     return loadNo;
 }

 /**
  * @param loadNo
  *            the loadNo to set
  */
 public void setLoadNo(String loadNo) {
     this.loadNo = loadNo;
 }

 /**
  * @return the employeeName
  */
 public String getEmployeeName() {
     return employeeName;
 }

 /**
  * @param employeeName
  *            the employeeName to set
  */
 public void setEmployeeName(String employeeName) {
     this.employeeName = employeeName;
 }

 /**
  * @return the companyId
  */
 public String getCompanyId() {
     return companyId;
 }

 /**
  * @param companyId
  *            the companyId to set
  */
 public void setCompanyId(String companyId) {
     this.companyId = companyId;
 }

 /**
  * @return the firstName
  */
 public String getFirstName() {
     return firstName;
 }

 /**
  * @param firstName
  *            the firstName to set
  */
 public void setFirstName(String firstName) {
     this.firstName = firstName;
 }

 /**
  * @return the lastName
  */
 public String getLastName() {
     return lastName;
 }

 /**
  * @param lastName
  *            the lastName to set
  */
 public void setLastName(String lastName) {
     this.lastName = lastName;
 }

 /**
  * @return the tripNo
  */
 public Long getTripNo() {
     return tripNo;
 }

 /**
  * @param tripNo the tripNo to set
  */
 public void setTripNo(Long tripNo) {
     this.tripNo = tripNo;
 }

 /**
  * @return the serviceNo
  */
 public String getServiceNo() {
     return serviceNo;
 }

 /**
  * @param serviceNo the serviceNo to set
  */
 public void setServiceNo(String serviceNo) {
     this.serviceNo = serviceNo;
 }

 /**
  * @return the key
  */
 public Long getKey() {
     return key;
 }

 /**
  * @param key the key to set
  */
 public void setKey(Long key) {
     this.key = key;
 }

 /*
  * (non-Javadoc)
  *
  * @see java.lang.Object#toString()
  */
 @Override
 public String toString() {
     return "EventTO [eventTypeId=" + eventTypeId
             + ", dockId=" + dockId + ", locationId=" + locationId
             + ", serviceId=" + serviceId + ", trailerId=" + trailerId
             + ", tripId=" + tripId + ", truckId=" + truckId + ", siteId="
             + siteId + ", driverId=" + driverId + ", trailerTagId="
             + trailerTagId + ", loggedDateTime=" + loggedDateTime
             + ", value1=" + value1 + ", value2=" + value2 + ", textValue="
             + textValue + ", userId=" + userId + ", time1=" + time1
             + ", time2=" + time2 + ", textValue2=" + textValue2
             + ", exception=" + exception + ", exceptiondesc="
             + exceptiondesc + ", exported=" + exported + ", eventAdjusted="
             + eventAdjusted + ", datasourceId=" + datasourceId
             + ", latitude=" + latitude + ", longitude=" + longitude
             + ", fleetId=" + fleetId + ", unitId=" + unitId
             + ", vehicleId=" + vehicleId + ", mdrego=" + mdrego
             + ", mdtcode=" + mdtcode + ", mdservertime=" + mdservertime
             + ", created=" + created + ", certainty=" + certainty
             + ", compliant=" + compliant + ", comments=" + comments
             + ", eventLevel=" + eventLevel + ", eventTime=" + eventTime
             + ", eventDescription=" + eventDescription + ", todexportable="
             + todexportable + ", tripIdCust=" + tripIdCust + ", loadNo="
             + loadNo + ", employeeName=" + employeeName + ", companyId="
             + companyId + ", firstName=" + firstName + ", lastName="
             + lastName + ", serviceNo=" + serviceNo + ", tripNo=" + tripNo
             + "]";
 }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}

