package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;


public class ImpLoadTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;

	private boolean despatch;
	private Long runsheetId;
	private Long serviceId;
	private Long tripId;
	private Long loadId;
	private Long consignmentId;
	private String loadNo;
	private String loadTypeId;
	private String importedBy;
	private String holdCode;
	private boolean complete;
	private Date scheduledDate;
	private String customerId;
	private String batchNo;
	private String custReference;
	private String locationId;
	private Double custClaimAmt;
	private Date settleDate;
	private String remarks;
	private String dataSourceId;
	private String enteredBy;
	private Date despatchBy;
	private Date deliveryOpen;
	private Date deliveryClose;
	private Long tDriverId;
	private String tTruckId;
	private String tTrailerId;
	private String tTrailerIdTag;
	private Long sDriverId;
	private String sTruckId;
	private String sTrailerId;
	private String sTrailerIdTag;
	private String serviceDesc;
	private String locationIdDrop;

	public boolean isDespatch() {
		return despatch;
	}

	public void setDespatch(boolean despatch) {
		this.despatch = despatch;
	}

	public Long getRunsheetId() {
		return runsheetId;
	}

	public void setRunsheetId(Long runsheetId) {
		this.runsheetId = runsheetId;
	}

	public Long getServiceId() {
		return serviceId;
	}

	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	public Long getConsignmentId() {
		return consignmentId;
	}

	public void setConsignmentId(Long consignmentId) {
		this.consignmentId = consignmentId;
	}

	public String getLoadNo() {
		return loadNo;
	}

	public void setLoadNo(String loadNo) {
		this.loadNo = loadNo;
	}

	public String getLoadTypeId() {
		return loadTypeId;
	}

	public void setLoadTypeId(String loadTypeId) {
		this.loadTypeId = loadTypeId;
	}

	public String getImportedBy() {
		return importedBy;
	}

	public void setImportedBy(String importedBy) {
		this.importedBy = importedBy;
	}

	public String getHoldCode() {
		return holdCode;
	}

	public void setHoldCode(String holdCode) {
		this.holdCode = holdCode;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getCustReference() {
		return custReference;
	}

	public void setCustReference(String custReference) {
		this.custReference = custReference;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public Double getCustClaimAmt() {
		return custClaimAmt;
	}

	public void setCustClaimAmt(Double custClaimAmt) {
		this.custClaimAmt = custClaimAmt;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDataSourceId() {
		return dataSourceId;
	}

	public void setDataSourceId(String dataSourceId) {
		this.dataSourceId = dataSourceId;
	}

	public String getEnteredBy() {
		return enteredBy;
	}

	public void setEnteredBy(String enteredBy) {
		this.enteredBy = enteredBy;
	}

	public Date getDespatchBy() {
		return despatchBy;
	}

	public void setDespatchBy(Date despatchBy) {
		this.despatchBy = despatchBy;
	}

	public Date getDeliveryOpen() {
		return deliveryOpen;
	}

	public void setDeliveryOpen(Date deliveryOpen) {
		this.deliveryOpen = deliveryOpen;
	}

	public Date getDeliveryClose() {
		return deliveryClose;
	}

	public void setDeliveryClose(Date deliveryClose) {
		this.deliveryClose = deliveryClose;
	}

	public Long gettDriverId() {
		return tDriverId;
	}

	public void settDriverId(Long tDriverId) {
		this.tDriverId = tDriverId;
	}

	public String gettTruckId() {
		return tTruckId;
	}

	public void settTruckId(String tTruckId) {
		this.tTruckId = tTruckId;
	}

	public String gettTrailerId() {
		return tTrailerId;
	}

	public void settTrailerId(String tTrailerId) {
		this.tTrailerId = tTrailerId;
	}

	public String gettTrailerIdTag() {
		return tTrailerIdTag;
	}

	public void settTrailerIdTag(String tTrailerIdTag) {
		this.tTrailerIdTag = tTrailerIdTag;
	}

	public Long getsDriverId() {
		return sDriverId;
	}

	public void setsDriverId(Long sDriverId) {
		this.sDriverId = sDriverId;
	}

	public String getsTruckId() {
		return sTruckId;
	}

	public void setsTruckId(String sTruckId) {
		this.sTruckId = sTruckId;
	}

	public String getsTrailerId() {
		return sTrailerId;
	}

	public void setsTrailerId(String sTrailerId) {
		this.sTrailerId = sTrailerId;
	}

	public String getsTrailerIdTag() {
		return sTrailerIdTag;
	}

	public void setsTrailerIdTag(String sTrailerIdTag) {
		this.sTrailerIdTag = sTrailerIdTag;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	public String getLocationIdDrop() {
		return locationIdDrop;
	}

	public void setLocationIdDrop(String locationIdDrop) {
		this.locationIdDrop = locationIdDrop;
	}

	@Override
	public String toString() {
		return "ImpLoadTO [despatch=" + despatch + ", runsheetId=" + runsheetId
				+ ", serviceId=" + serviceId + ", tripId=" + tripId
				+ ", loadId=" + loadId + ", consignmentId=" + consignmentId
				+ ", loadNo=" + loadNo + ", loadTypeId=" + loadTypeId
				+ ", importedBy=" + importedBy + ", holdCode=" + holdCode
				+ ", complete=" + complete + ", scheduledDate=" + scheduledDate
				+ ", customerId=" + customerId + ", batchNo=" + batchNo
				+ ", custReference=" + custReference + ", locationId="
				+ locationId + ", custClaimAmt=" + custClaimAmt
				+ ", settleDate=" + settleDate + ", remarks=" + remarks
				+ ", dataSourceId=" + dataSourceId + ", enteredBy=" + enteredBy
				+ ", despatchBy=" + despatchBy + ", deliveryOpen="
				+ deliveryOpen + ", deliveryClose=" + deliveryClose
				+ ", tDriverId=" + tDriverId + ", tTruckId=" + tTruckId
				+ ", tTrailerId=" + tTrailerId + ", tTrailerIdTag="
				+ tTrailerIdTag + ", sDriverId=" + sDriverId + ", sTruckId="
				+ sTruckId + ", sTrailerId=" + sTrailerId + ", sTrailerIdTag="
				+ sTrailerIdTag + ", serviceDesc=" + serviceDesc
				+ ", locationIdDrop=" + locationIdDrop + "]";
	}

}
