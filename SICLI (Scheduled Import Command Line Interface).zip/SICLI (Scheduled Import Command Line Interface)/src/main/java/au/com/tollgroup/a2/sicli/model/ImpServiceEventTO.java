package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ImpServiceEventTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;
	private Integer eventType;
	private String eventText;

	public ImpServiceEventTO(Integer eventType, String eventText) {
		super();
		this.eventType = eventType;
		this.eventText = eventText;
	}

	public Integer getEventType() {
		return eventType;
	}

	public void setEventType(Integer eventType) {
		this.eventType = eventType;
	}

	public String getEventText() {
		return eventText;
	}

	public void setEventText(String eventText) {
		this.eventText = eventText;
	}

}
