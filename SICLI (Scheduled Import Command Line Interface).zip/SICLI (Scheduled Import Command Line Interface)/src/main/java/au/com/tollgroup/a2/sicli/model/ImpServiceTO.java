package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ImpServiceTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;
	private long importId;
	private Long siteId;
	private Date importDateTime;
	private String importSource;
	private String importComments;
	private String serviceType;
	private Date serviceDate;
	private String serviceDesc;
	private String customerId;
	private String loadType;
	private Long driverId;
	private String truckId;
	private String trailerId;
	private String trailerIdTag;
	private String containerId;
	private String locationIdPickup;
	private String locationIdDrop;
	private Double qty1;
	private String unit1;
	private Double qty2;
	private String unit2;
	private Double qty3;
	private String unit3;
	private Double qty4;
	private String unit4;
	private Double qty5;
	private String unit5;
	private Double qty6;
	private String unit6;
	private Double qty7;
	private String unit7;
	private Double qty8;
	private String unit8;
	private String docket;
	private String remarksService;
	private boolean delivered;
	private Date window1From;
	private Date window1To;
	private Date window2From;
	private Date window2To;
	private String batchNo;
	private String custReference;
	private Date scheduledDate;
	private String loadNo;
	private String locationIdLoad;
	private Double custClaimAmt;
	private Date settleDate;
	private String remarksLoad;
	private String locationTypeDrop;
	private String locationDescDrop;
	private Long personIdDrop;
	private String customerIdDrop;
	private String locationCodeDrop;
	private Date window1FromDrop;
	private Date window1ToDrop;
	private Date window2FromDrop;
	private Date window2ToDrop;
	private String payZoneIdDrop;
	private String chargeZoneIdDrop;
	private Double latitudeDrop;
	private Double longitudeDrop;
	private Integer geofenceDrop;
	private String mapSourceIdDrop;
	private String mapReferenceDrop;
	private String address1Drop;
	private String address2Drop;
	private String suburbDrop;
	private String stateDrop;
	private String postCodeDrop;
	private String remarksDrop;
	private Double truckSizeLimitDrop;
	private Integer defaultTripSeqDrop;
	private String routeIdDrop;
	private boolean permanentDrop;
	private String containerTypeCont;
	private String containerDescCont;
	private String companyIdCont;
	private Double weightTonnesCont;
	private boolean permanentCont;
	private String importEnteredBy;
	private String validateLoad;
	private String validateCustomer;
	private String validateDrop;
	private String validateContainer;
	private boolean promptForServiceDate;
	private String validatePickup;
	private String validateTruck;
	private String validateTrailer;
	private String validateTrailerTag;
	private String validateDriver;
	private String validatePayZone;
	private String validateChargeZone;
	private String validatePersonDrop;
	private String validateMapSource;
	private String validateLocationType;
	private String validateRoute;
	private String validateContainerType;
	private String validateCompanyCont;
	private String validateLoadType;
	private Integer imported;
	private String importError;
	private Long importServiceId;
	private String validateTrip;
	private Long tripId;
	private Integer tripSeq;
	private String validateService;
	private Date despatchBy;
	private Date deliveryOpen;
	private Date deliveryClose;
	private String serviceGroup;
	private String tripNo;
	private String validateDespatch;
	private String validateReturn;
	private String locationIdDespatch;
	private String locationIdReturn;
	private Date plannedStartTime;
	private Date plannedEndTime;
	private Double latitudePickup;
	private Double longitudePickup;
	private String locationCode;
	private String locationDesc;
	private String locationType;
	private String address1;
	private String address2;
	private String mapReference;
	private String mapSourceId;
	private String customerIdPickup;
	private Long personId;
	private String postCode;
	private String suburb;
	private String state;
	private Double truckSizeLimitPickup;
	private String payZoneId;
	private String chargeZoneId;
	private Date window1FromPickup;
	private Date window1ToPickup;
	private Date window2FromPickup;
	private Date window2ToPickup;
	private Integer geofencePickup;
	private Boolean permanentPickup;
	private String routeIdPickup;
	private Integer defaultTripSeqPickup;
	private String remarksPickup;
	private String serviceNo;
	private Long originSite;
	private String originLoc;
	private Long destinationSite;
	private String destinationLoc;
	private boolean createTrip;
	private Date lastModified;
	private String locationIdFinish;
	private Long dockName;
	private Long importBatch;
	private Long id;

	public long getImportId() {
		return importId;
	}

	public void setImportId(long importId) {
		this.importId = importId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Date getImportDateTime() {
		return importDateTime;
	}

	public void setImportDateTime(Date importDateTime) {
		this.importDateTime = importDateTime;
	}

	public String getImportSource() {
		return importSource;
	}

	public void setImportSource(String importSource) {
		this.importSource = importSource;
	}

	public String getImportComments() {
		return importComments;
	}

	public void setImportComments(String importComments) {
		this.importComments = importComments;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public Date getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getLoadType() {
		return loadType;
	}

	public void setLoadType(String loadType) {
		this.loadType = loadType;
	}

	public Long getDriverId() {
		return driverId;
	}

	public void setDriverId(Long driverId) {
		this.driverId = driverId;
	}

	public String getTruckId() {
		return truckId;
	}

	public void setTruckId(String truckId) {
		this.truckId = truckId;
	}

	public String getTrailerId() {
		return trailerId;
	}

	public void setTrailerId(String trailerId) {
		this.trailerId = trailerId;
	}

	public String getTrailerIdTag() {
		return trailerIdTag;
	}

	public void setTrailerIdTag(String trailerIdTag) {
		this.trailerIdTag = trailerIdTag;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getLocationIdPickup() {
		return locationIdPickup;
	}

	public void setLocationIdPickup(String locationIdPickup) {
		this.locationIdPickup = locationIdPickup;
	}

	public String getLocationIdDrop() {
		return locationIdDrop;
	}

	public void setLocationIdDrop(String locationIdDrop) {
		this.locationIdDrop = locationIdDrop;
	}

	public Double getQty1() {
		return qty1;
	}

	public void setQty1(Double qty1) {
		this.qty1 = qty1;
	}

	public String getUnit1() {
		return unit1;
	}

	public void setUnit1(String unit1) {
		this.unit1 = unit1;
	}

	public Double getQty2() {
		return qty2;
	}

	public void setQty2(Double qty2) {
		this.qty2 = qty2;
	}

	public String getUnit2() {
		return unit2;
	}

	public void setUnit2(String unit2) {
		this.unit2 = unit2;
	}

	public Double getQty3() {
		return qty3;
	}

	public void setQty3(Double qty3) {
		this.qty3 = qty3;
	}

	public String getUnit3() {
		return unit3;
	}

	public void setUnit3(String unit3) {
		this.unit3 = unit3;
	}

	public Double getQty4() {
		return qty4;
	}

	public void setQty4(Double qty4) {
		this.qty4 = qty4;
	}

	public String getUnit4() {
		return unit4;
	}

	public void setUnit4(String unit4) {
		this.unit4 = unit4;
	}

	public Double getQty5() {
		return qty5;
	}

	public void setQty5(Double qty5) {
		this.qty5 = qty5;
	}

	public String getUnit5() {
		return unit5;
	}

	public void setUnit5(String unit5) {
		this.unit5 = unit5;
	}

	public Double getQty6() {
		return qty6;
	}

	public void setQty6(Double qty6) {
		this.qty6 = qty6;
	}

	public String getUnit6() {
		return unit6;
	}

	public void setUnit6(String unit6) {
		this.unit6 = unit6;
	}

	public Double getQty7() {
		return qty7;
	}

	public void setQty7(Double qty7) {
		this.qty7 = qty7;
	}

	public String getUnit7() {
		return unit7;
	}

	public void setUnit7(String unit7) {
		this.unit7 = unit7;
	}

	public Double getQty8() {
		return qty8;
	}

	public void setQty8(Double qty8) {
		this.qty8 = qty8;
	}

	public String getUnit8() {
		return unit8;
	}

	public void setUnit8(String unit8) {
		this.unit8 = unit8;
	}

	public String getDocket() {
		return docket;
	}

	public void setDocket(String docket) {
		this.docket = docket;
	}

	public String getRemarksService() {
		return remarksService;
	}

	public void setRemarksService(String remarksService) {
		this.remarksService = remarksService;
	}

	public boolean isDelivered() {
		return delivered;
	}

	public void setDelivered(boolean delivered) {
		this.delivered = delivered;
	}

	public Date getWindow1From() {
		return window1From;
	}

	public void setWindow1From(Date window1From) {
		this.window1From = window1From;
	}

	public Date getWindow1To() {
		return window1To;
	}

	public void setWindow1To(Date window1To) {
		this.window1To = window1To;
	}

	public Date getWindow2From() {
		return window2From;
	}

	public void setWindow2From(Date window2From) {
		this.window2From = window2From;
	}

	public Date getWindow2To() {
		return window2To;
	}

	public void setWindow2To(Date window2To) {
		this.window2To = window2To;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getCustReference() {
		return custReference;
	}

	public void setCustReference(String custReference) {
		this.custReference = custReference;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getLoadNo() {
		return loadNo;
	}

	public void setLoadNo(String loadNo) {
		this.loadNo = loadNo;
	}

	public String getLocationIdLoad() {
		return locationIdLoad;
	}

	public void setLocationIdLoad(String locationIdLoad) {
		this.locationIdLoad = locationIdLoad;
	}

	public Double getCustClaimAmt() {
		return custClaimAmt;
	}

	public void setCustClaimAmt(Double custClaimAmt) {
		this.custClaimAmt = custClaimAmt;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public String getRemarksLoad() {
		return remarksLoad;
	}

	public void setRemarksLoad(String remarksLoad) {
		this.remarksLoad = remarksLoad;
	}

	public String getLocationTypeDrop() {
		return locationTypeDrop;
	}

	public void setLocationTypeDrop(String locationTypeDrop) {
		this.locationTypeDrop = locationTypeDrop;
	}

	public String getLocationDescDrop() {
		return locationDescDrop;
	}

	public void setLocationDescDrop(String locationDescDrop) {
		this.locationDescDrop = locationDescDrop;
	}

	public Long getPersonIdDrop() {
		return personIdDrop;
	}

	public void setPersonIdDrop(Long personIdDrop) {
		this.personIdDrop = personIdDrop;
	}

	public String getCustomerIdDrop() {
		return customerIdDrop;
	}

	public void setCustomerIdDrop(String customerIdDrop) {
		this.customerIdDrop = customerIdDrop;
	}

	public String getLocationCodeDrop() {
		return locationCodeDrop;
	}

	public void setLocationCodeDrop(String locationCodeDrop) {
		this.locationCodeDrop = locationCodeDrop;
	}

	public Date getWindow1FromDrop() {
		return window1FromDrop;
	}

	public void setWindow1FromDrop(Date window1FromDrop) {
		this.window1FromDrop = window1FromDrop;
	}

	public Date getWindow1ToDrop() {
		return window1ToDrop;
	}

	public void setWindow1ToDrop(Date window1ToDrop) {
		this.window1ToDrop = window1ToDrop;
	}

	public Date getWindow2FromDrop() {
		return window2FromDrop;
	}

	public void setWindow2FromDrop(Date window2FromDrop) {
		this.window2FromDrop = window2FromDrop;
	}

	public Date getWindow2ToDrop() {
		return window2ToDrop;
	}

	public void setWindow2ToDrop(Date window2ToDrop) {
		this.window2ToDrop = window2ToDrop;
	}

	public String getPayZoneIdDrop() {
		return payZoneIdDrop;
	}

	public void setPayZoneIdDrop(String payZoneIdDrop) {
		this.payZoneIdDrop = payZoneIdDrop;
	}

	public String getChargeZoneIdDrop() {
		return chargeZoneIdDrop;
	}

	public void setChargeZoneIdDrop(String chargeZoneIdDrop) {
		this.chargeZoneIdDrop = chargeZoneIdDrop;
	}

	public Double getLatitudeDrop() {
		return latitudeDrop;
	}

	public void setLatitudeDrop(Double latitudeDrop) {
		this.latitudeDrop = latitudeDrop;
	}

	public Double getLongitudeDrop() {
		return longitudeDrop;
	}

	public void setLongitudeDrop(Double longitudeDrop) {
		this.longitudeDrop = longitudeDrop;
	}

	public Integer getGeofenceDrop() {
		return geofenceDrop;
	}

	public void setGeofenceDrop(Integer geofenceDrop) {
		this.geofenceDrop = geofenceDrop;
	}

	public String getMapSourceIdDrop() {
		return mapSourceIdDrop;
	}

	public void setMapSourceIdDrop(String mapSourceIdDrop) {
		this.mapSourceIdDrop = mapSourceIdDrop;
	}

	public String getMapReferenceDrop() {
		return mapReferenceDrop;
	}

	public void setMapReferenceDrop(String mapReferenceDrop) {
		this.mapReferenceDrop = mapReferenceDrop;
	}

	public String getAddress1Drop() {
		return address1Drop;
	}

	public void setAddress1Drop(String address1Drop) {
		this.address1Drop = address1Drop;
	}

	public String getAddress2Drop() {
		return address2Drop;
	}

	public void setAddress2Drop(String address2Drop) {
		this.address2Drop = address2Drop;
	}

	public String getSuburbDrop() {
		return suburbDrop;
	}

	public void setSuburbDrop(String suburbDrop) {
		this.suburbDrop = suburbDrop;
	}

	public String getStateDrop() {
		return stateDrop;
	}

	public void setStateDrop(String stateDrop) {
		this.stateDrop = stateDrop;
	}

	public String getPostCodeDrop() {
		return postCodeDrop;
	}

	public void setPostCodeDrop(String postCodeDrop) {
		this.postCodeDrop = postCodeDrop;
	}

	public String getRemarksDrop() {
		return remarksDrop;
	}

	public void setRemarksDrop(String remarksDrop) {
		this.remarksDrop = remarksDrop;
	}

	public Double getTruckSizeLimitDrop() {
		return truckSizeLimitDrop;
	}

	public void setTruckSizeLimitDrop(Double truckSizeLimitDrop) {
		this.truckSizeLimitDrop = truckSizeLimitDrop;
	}

	public Integer getDefaultTripSeqDrop() {
		return defaultTripSeqDrop;
	}

	public void setDefaultTripSeqDrop(Integer defaultTripSeqDrop) {
		this.defaultTripSeqDrop = defaultTripSeqDrop;
	}

	public String getRouteIdDrop() {
		return routeIdDrop;
	}

	public void setRouteIdDrop(String routeIdDrop) {
		this.routeIdDrop = routeIdDrop;
	}

	public boolean isPermanentDrop() {
		return permanentDrop;
	}

	public void setPermanentDrop(boolean permanentDrop) {
		this.permanentDrop = permanentDrop;
	}

	public String getContainerTypeCont() {
		return containerTypeCont;
	}

	public void setContainerTypeCont(String containerTypeCont) {
		this.containerTypeCont = containerTypeCont;
	}

	public String getContainerDescCont() {
		return containerDescCont;
	}

	public void setContainerDescCont(String containerDescCont) {
		this.containerDescCont = containerDescCont;
	}

	public String getCompanyIdCont() {
		return companyIdCont;
	}

	public void setCompanyIdCont(String companyIdCont) {
		this.companyIdCont = companyIdCont;
	}

	public Double getWeightTonnesCont() {
		return weightTonnesCont;
	}

	public void setWeightTonnesCont(Double weightTonnesCont) {
		this.weightTonnesCont = weightTonnesCont;
	}

	public boolean isPermanentCont() {
		return permanentCont;
	}

	public void setPermanentCont(boolean permanentCont) {
		this.permanentCont = permanentCont;
	}

	public String getImportEnteredBy() {
		return importEnteredBy;
	}

	public void setImportEnteredBy(String importEnteredBy) {
		this.importEnteredBy = importEnteredBy;
	}

	public String getValidateLoad() {
		return validateLoad;
	}

	public void setValidateLoad(String validateLoad) {
		this.validateLoad = validateLoad;
	}

	public String getValidateCustomer() {
		return validateCustomer;
	}

	public void setValidateCustomer(String validateCustomer) {
		this.validateCustomer = validateCustomer;
	}

	public String getValidateDrop() {
		return validateDrop;
	}

	public void setValidateDrop(String validateDrop) {
		this.validateDrop = validateDrop;
	}

	public String getValidateContainer() {
		return validateContainer;
	}

	public void setValidateContainer(String validateContainer) {
		this.validateContainer = validateContainer;
	}

	public boolean isPromptForServiceDate() {
		return promptForServiceDate;
	}

	public void setPromptForServiceDate(boolean promptForServiceDate) {
		this.promptForServiceDate = promptForServiceDate;
	}

	public String getValidatePickup() {
		return validatePickup;
	}

	public void setValidatePickup(String validatePickup) {
		this.validatePickup = validatePickup;
	}

	public String getValidateTruck() {
		return validateTruck;
	}

	public void setValidateTruck(String validateTruck) {
		this.validateTruck = validateTruck;
	}

	public String getValidateTrailer() {
		return validateTrailer;
	}

	public void setValidateTrailer(String validateTrailer) {
		this.validateTrailer = validateTrailer;
	}

	public String getValidateTrailerTag() {
		return validateTrailerTag;
	}

	public void setValidateTrailerTag(String validateTrailerTag) {
		this.validateTrailerTag = validateTrailerTag;
	}

	public String getValidateDriver() {
		return validateDriver;
	}

	public void setValidateDriver(String validateDriver) {
		this.validateDriver = validateDriver;
	}

	public String getValidatePayZone() {
		return validatePayZone;
	}

	public void setValidatePayZone(String validatePayZone) {
		this.validatePayZone = validatePayZone;
	}

	public String getValidateChargeZone() {
		return validateChargeZone;
	}

	public void setValidateChargeZone(String validateChargeZone) {
		this.validateChargeZone = validateChargeZone;
	}

	public String getValidatePersonDrop() {
		return validatePersonDrop;
	}

	public void setValidatePersonDrop(String validatePersonDrop) {
		this.validatePersonDrop = validatePersonDrop;
	}

	public String getValidateMapSource() {
		return validateMapSource;
	}

	public void setValidateMapSource(String validateMapSource) {
		this.validateMapSource = validateMapSource;
	}

	public String getValidateLocationType() {
		return validateLocationType;
	}

	public void setValidateLocationType(String validateLocationType) {
		this.validateLocationType = validateLocationType;
	}

	public String getValidateRoute() {
		return validateRoute;
	}

	public void setValidateRoute(String validateRoute) {
		this.validateRoute = validateRoute;
	}

	public String getValidateContainerType() {
		return validateContainerType;
	}

	public void setValidateContainerType(String validateContainerType) {
		this.validateContainerType = validateContainerType;
	}

	public String getValidateCompanyCont() {
		return validateCompanyCont;
	}

	public void setValidateCompanyCont(String validateCompanyCont) {
		this.validateCompanyCont = validateCompanyCont;
	}

	public String getValidateLoadType() {
		return validateLoadType;
	}

	public void setValidateLoadType(String validateLoadType) {
		this.validateLoadType = validateLoadType;
	}

	public Integer getImported() {
		return imported;
	}

	public void setImported(Integer imported) {
		this.imported = imported;
	}

	public String getImportError() {
		return importError;
	}

	public void setImportError(String importError) {
		this.importError = importError;
	}

	public Long getImportServiceId() {
		return importServiceId;
	}

	public void setImportServiceId(Long importServiceId) {
		this.importServiceId = importServiceId;
	}

	public String getValidateTrip() {
		return validateTrip;
	}

	public void setValidateTrip(String validateTrip) {
		this.validateTrip = validateTrip;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public Integer getTripSeq() {
		return tripSeq;
	}

	public void setTripSeq(Integer tripSeq) {
		this.tripSeq = tripSeq;
	}

	public String getValidateService() {
		return validateService;
	}

	public void setValidateService(String validateService) {
		this.validateService = validateService;
	}

	public Date getDespatchBy() {
		return despatchBy;
	}

	public void setDespatchBy(Date despatchBy) {
		this.despatchBy = despatchBy;
	}

	public Date getDeliveryOpen() {
		return deliveryOpen;
	}

	public void setDeliveryOpen(Date deliveryOpen) {
		this.deliveryOpen = deliveryOpen;
	}

	public Date getDeliveryClose() {
		return deliveryClose;
	}

	public void setDeliveryClose(Date deliveryClose) {
		this.deliveryClose = deliveryClose;
	}

	public String getServiceGroup() {
		return serviceGroup;
	}

	public void setServiceGroup(String serviceGroup) {
		this.serviceGroup = serviceGroup;
	}

	public String getTripNo() {
		return tripNo;
	}

	public void setTripNo(String tripNo) {
		this.tripNo = tripNo;
	}

	public String getValidateDespatch() {
		return validateDespatch;
	}

	public void setValidateDespatch(String validateDespatch) {
		this.validateDespatch = validateDespatch;
	}

	public String getValidateReturn() {
		return validateReturn;
	}

	public void setValidateReturn(String validateReturn) {
		this.validateReturn = validateReturn;
	}

	public String getLocationIdDespatch() {
		return locationIdDespatch;
	}

	public void setLocationIdDespatch(String locationIdDespatch) {
		this.locationIdDespatch = locationIdDespatch;
	}

	public String getLocationIdReturn() {
		return locationIdReturn;
	}

	public void setLocationIdReturn(String locationIdReturn) {
		this.locationIdReturn = locationIdReturn;
	}

	public Date getPlannedStartTime() {
		return plannedStartTime;
	}

	public void setPlannedStartTime(Date plannedStartTime) {
		this.plannedStartTime = plannedStartTime;
	}

	public Date getPlannedEndTime() {
		return plannedEndTime;
	}

	public void setPlannedEndTime(Date plannedEndTime) {
		this.plannedEndTime = plannedEndTime;
	}

	public Double getLatitudePickup() {
		return latitudePickup;
	}

	public void setLatitudePickup(Double latitudePickup) {
		this.latitudePickup = latitudePickup;
	}

	public Double getLongitudePickup() {
		return longitudePickup;
	}

	public void setLongitudePickup(Double longitudePickup) {
		this.longitudePickup = longitudePickup;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLocationDesc() {
		return locationDesc;
	}

	public void setLocationDesc(String locationDesc) {
		this.locationDesc = locationDesc;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getMapReference() {
		return mapReference;
	}

	public void setMapReference(String mapReference) {
		this.mapReference = mapReference;
	}

	public String getMapSourceId() {
		return mapSourceId;
	}

	public void setMapSourceId(String mapSourceId) {
		this.mapSourceId = mapSourceId;
	}

	public String getCustomerIdPickup() {
		return customerIdPickup;
	}

	public void setCustomerIdPickup(String customerIdPickup) {
		this.customerIdPickup = customerIdPickup;
	}

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Double getTruckSizeLimitPickup() {
		return truckSizeLimitPickup;
	}

	public void setTruckSizeLimitPickup(Double truckSizeLimitPickup) {
		this.truckSizeLimitPickup = truckSizeLimitPickup;
	}

	public String getPayZoneId() {
		return payZoneId;
	}

	public void setPayZoneId(String payZoneId) {
		this.payZoneId = payZoneId;
	}

	public String getChargeZoneId() {
		return chargeZoneId;
	}

	public void setChargeZoneId(String chargeZoneId) {
		this.chargeZoneId = chargeZoneId;
	}

	public Date getWindow1FromPickup() {
		return window1FromPickup;
	}

	public void setWindow1FromPickup(Date window1FromPickup) {
		this.window1FromPickup = window1FromPickup;
	}

	public Date getWindow1ToPickup() {
		return window1ToPickup;
	}

	public void setWindow1ToPickup(Date window1ToPickup) {
		this.window1ToPickup = window1ToPickup;
	}

	public Date getWindow2FromPickup() {
		return window2FromPickup;
	}

	public void setWindow2FromPickup(Date window2FromPickup) {
		this.window2FromPickup = window2FromPickup;
	}

	public Date getWindow2ToPickup() {
		return window2ToPickup;
	}

	public void setWindow2ToPickup(Date window2ToPickup) {
		this.window2ToPickup = window2ToPickup;
	}

	public Integer getGeofencePickup() {
		return geofencePickup;
	}

	public void setGeofencePickup(Integer geofencePickup) {
		this.geofencePickup = geofencePickup;
	}

	public Boolean getPermanentPickup() {
		return permanentPickup;
	}

	public void setPermanentPickup(Boolean permanentPickup) {
		this.permanentPickup = permanentPickup;
	}

	public String getRouteIdPickup() {
		return routeIdPickup;
	}

	public void setRouteIdPickup(String routeIdPickup) {
		this.routeIdPickup = routeIdPickup;
	}

	public Integer getDefaultTripSeqPickup() {
		return defaultTripSeqPickup;
	}

	public void setDefaultTripSeqPickup(Integer defaultTripSeqPickup) {
		this.defaultTripSeqPickup = defaultTripSeqPickup;
	}

	public String getRemarksPickup() {
		return remarksPickup;
	}

	public void setRemarksPickup(String remarksPickup) {
		this.remarksPickup = remarksPickup;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public Long getOriginSite() {
		return originSite;
	}

	public void setOriginSite(Long originSite) {
		this.originSite = originSite;
	}

	public String getOriginLoc() {
		return originLoc;
	}

	public void setOriginLoc(String originLoc) {
		this.originLoc = originLoc;
	}

	public Long getDestinationSite() {
		return destinationSite;
	}

	public void setDestinationSite(Long destinationSite) {
		this.destinationSite = destinationSite;
	}

	public String getDestinationLoc() {
		return destinationLoc;
	}

	public void setDestinationLoc(String destinationLoc) {
		this.destinationLoc = destinationLoc;
	}

	public boolean isCreateTrip() {
		return createTrip;
	}

	public void setCreateTrip(boolean createTrip) {
		this.createTrip = createTrip;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public String getLocationIdFinish() {
		return locationIdFinish;
	}

	public void setLocationIdFinish(String locationIdFinish) {
		this.locationIdFinish = locationIdFinish;
	}

	public Long getDockName() {
		return dockName;
	}

	public void setDockName(Long dockName) {
		this.dockName = dockName;
	}

	public Long getImportBatch() {
		return importBatch;
	}

	public void setImportBatch(Long importBatch) {
		this.importBatch = importBatch;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (importId ^ (importId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ImpServiceTO other = (ImpServiceTO) obj;
		if (importId != other.importId) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "ImpServiceTO [importId=" + importId + ", siteId=" + siteId
				+ ", importDateTime=" + importDateTime + ", importSource="
				+ importSource + ", importComments=" + importComments
				+ ", serviceType=" + serviceType + ", serviceDate="
				+ serviceDate + ", serviceDesc=" + serviceDesc
				+ ", customerId=" + customerId + ", loadType=" + loadType
				+ ", driverId=" + driverId + ", truckId=" + truckId
				+ ", trailerId=" + trailerId + ", trailerIdTag=" + trailerIdTag
				+ ", containerId=" + containerId + ", locationIdPickup="
				+ locationIdPickup + ", locationIdDrop=" + locationIdDrop
				+ ", qty1=" + qty1 + ", unit1=" + unit1 + ", qty2=" + qty2
				+ ", unit2=" + unit2 + ", qty3=" + qty3 + ", unit3=" + unit3
				+ ", qty4=" + qty4 + ", unit4=" + unit4 + ", qty5=" + qty5
				+ ", unit5=" + unit5 + ", qty6=" + qty6 + ", unit6=" + unit6
				+ ", qty7=" + qty7 + ", unit7=" + unit7 + ", qty8=" + qty8
				+ ", unit8=" + unit8 + ", docket=" + docket
				+ ", remarksService=" + remarksService + ", delivered="
				+ delivered + ", window1From=" + window1From + ", window1To="
				+ window1To + ", window2From=" + window2From + ", window2To="
				+ window2To + ", batchNo=" + batchNo + ", custReference="
				+ custReference + ", scheduledDate=" + scheduledDate
				+ ", loadNo=" + loadNo + ", locationIdLoad=" + locationIdLoad
				+ ", custClaimAmt=" + custClaimAmt + ", settleDate="
				+ settleDate + ", remarksLoad=" + remarksLoad
				+ ", locationTypeDrop=" + locationTypeDrop
				+ ", locationDescDrop=" + locationDescDrop + ", personIdDrop="
				+ personIdDrop + ", customerIdDrop=" + customerIdDrop
				+ ", locationCodeDrop=" + locationCodeDrop
				+ ", window1FromDrop=" + window1FromDrop + ", window1ToDrop="
				+ window1ToDrop + ", window2FromDrop=" + window2FromDrop
				+ ", window2ToDrop=" + window2ToDrop + ", payZoneIdDrop="
				+ payZoneIdDrop + ", chargeZoneIdDrop=" + chargeZoneIdDrop
				+ ", latitudeDrop=" + latitudeDrop + ", longitudeDrop="
				+ longitudeDrop + ", geofenceDrop=" + geofenceDrop
				+ ", mapSourceIdDrop=" + mapSourceIdDrop
				+ ", mapReferenceDrop=" + mapReferenceDrop + ", address1Drop="
				+ address1Drop + ", address2Drop=" + address2Drop
				+ ", suburbDrop=" + suburbDrop + ", stateDrop=" + stateDrop
				+ ", postCodeDrop=" + postCodeDrop + ", remarksDrop="
				+ remarksDrop + ", truckSizeLimitDrop=" + truckSizeLimitDrop
				+ ", defaultTripSeqDrop=" + defaultTripSeqDrop
				+ ", routeIdDrop=" + routeIdDrop + ", permanentDrop="
				+ permanentDrop + ", containerTypeCont=" + containerTypeCont
				+ ", containerDescCont=" + containerDescCont
				+ ", companyIdCont=" + companyIdCont + ", weightTonnesCont="
				+ weightTonnesCont + ", permanentCont=" + permanentCont
				+ ", importEnteredBy=" + importEnteredBy + ", validateLoad="
				+ validateLoad + ", validateCustomer=" + validateCustomer
				+ ", validateDrop=" + validateDrop + ", validateContainer="
				+ validateContainer + ", promptForServiceDate="
				+ promptForServiceDate + ", validatePickup=" + validatePickup
				+ ", validateTruck=" + validateTruck + ", validateTrailer="
				+ validateTrailer + ", validateTrailerTag="
				+ validateTrailerTag + ", validateDriver=" + validateDriver
				+ ", validatePayZone=" + validatePayZone
				+ ", validateChargeZone=" + validateChargeZone
				+ ", validatePersonDrop=" + validatePersonDrop
				+ ", validateMapSource=" + validateMapSource
				+ ", validateLocationType=" + validateLocationType
				+ ", validateRoute=" + validateRoute
				+ ", validateContainerType=" + validateContainerType
				+ ", validateCompanyCont=" + validateCompanyCont
				+ ", validateLoadType=" + validateLoadType + ", imported="
				+ imported + ", importError=" + importError
				+ ", importServiceId=" + importServiceId + ", validateTrip="
				+ validateTrip + ", tripId=" + tripId + ", tripSeq=" + tripSeq
				+ ", validateService=" + validateService + ", despatchBy="
				+ despatchBy + ", deliveryOpen=" + deliveryOpen
				+ ", deliveryClose=" + deliveryClose + ", serviceGroup="
				+ serviceGroup + ", tripNo=" + tripNo + ", validateDespatch="
				+ validateDespatch + ", validateReturn=" + validateReturn
				+ ", locationIdDespatch=" + locationIdDespatch
				+ ", locationIdReturn=" + locationIdReturn
				+ ", plannedStartTime=" + plannedStartTime
				+ ", plannedEndTime=" + plannedEndTime + ", latitudePickup="
				+ latitudePickup + ", longitudePickup=" + longitudePickup
				+ ", locationCode=" + locationCode + ", locationDesc="
				+ locationDesc + ", locationType=" + locationType
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", mapReference=" + mapReference + ", mapSourceId="
				+ mapSourceId + ", customerIdPickup=" + customerIdPickup
				+ ", personId=" + personId + ", postCode=" + postCode
				+ ", suburb=" + suburb + ", state=" + state
				+ ", truckSizeLimitPickup=" + truckSizeLimitPickup
				+ ", payZoneId=" + payZoneId + ", chargeZoneId=" + chargeZoneId
				+ ", window1FromPickup=" + window1FromPickup
				+ ", window1ToPickup=" + window1ToPickup
				+ ", window2FromPickup=" + window2FromPickup
				+ ", window2ToPickup=" + window2ToPickup + ", geofencePickup="
				+ geofencePickup + ", permanentPickup=" + permanentPickup
				+ ", routeIdPickup=" + routeIdPickup
				+ ", defaultTripSeqPickup=" + defaultTripSeqPickup
				+ ", remarksPickup=" + remarksPickup + ", serviceNo="
				+ serviceNo + ", originSite=" + originSite + ", originLoc="
				+ originLoc + ", destinationSite=" + destinationSite
				+ ", destinationLoc=" + destinationLoc + ", createTrip="
				+ createTrip + ", lastModified=" + lastModified
				+ ", locationIdFinish=" + locationIdFinish + ", dockName="
				+ dockName + ", importBatch=" + importBatch + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
