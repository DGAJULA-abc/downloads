package au.com.tollgroup.a2.sicli.model;

import java.sql.Timestamp;

import oracle.sql.CLOB;

public class InternalEventQueueTO {

	private Long Id;           
	private Long TyptId;           
	private Timestamp LoggedDateTime;  
	private Long siteId;                  
	private String TaskId;                  
	private CLOB Details;                        
	private Long Led;                
	private Long RetryCount;               
	private Timestamp LastRetry;             
	private Long MyToll;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Long getTyptId() {
		return TyptId;
	}
	public void setTyptId(Long typtId) {
		TyptId = typtId;
	}
	public Timestamp getLoggedDateTime() {
		return LoggedDateTime;
	}
	public void setLoggedDateTime(Timestamp loggedDateTime) {
		LoggedDateTime = loggedDateTime;
	}
	public Long getSiteId() {
		return siteId;
	}
	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}
	public String getTaskId() {
		return TaskId;
	}
	public void setTaskId(String taskId) {
		TaskId = taskId;
	}
	public CLOB getDetails() {
		return Details;
	}
	public void setDetails(CLOB details) {
		Details = details;
	}
	public Long getLed() {
		return Led;
	}
	public void setLed(Long led) {
		Led = led;
	}
	public Long getRetryCount() {
		return RetryCount;
	}
	public void setRetryCount(Long retryCount) {
		RetryCount = retryCount;
	}
	public Timestamp getLastRetry() {
		return LastRetry;
	}
	public void setLastRetry(Timestamp lastRetry) {
		LastRetry = lastRetry;
	}
	public Long getMyToll() {
		return MyToll;
	}
	public void setMyToll(Long myToll) {
		MyToll = myToll;
	}                 
}
