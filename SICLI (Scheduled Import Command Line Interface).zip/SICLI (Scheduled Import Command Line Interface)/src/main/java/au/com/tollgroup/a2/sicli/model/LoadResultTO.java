package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;


public class LoadResultTO implements Serializable {

	private static final long serialVersionUID = -5446431870032686634L;
	private Long loadId;
	private Long importedLoadId;

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	public Long getImportedLoadId() {
		return importedLoadId;
	}

	public void setImportedLoadId(Long importedLoadId) {
		this.importedLoadId = importedLoadId;
	}

	@Override
	public String toString() {
		return "BSSLoadResultTO [loadId=" + loadId + ", importedLoadId="
				+ importedLoadId + "]";
	}

}
