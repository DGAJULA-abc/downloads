package au.com.tollgroup.a2.sicli.model;

public class LoadServiceTO {
	
	private long serviceId;
	private boolean ServiceComplete;
	private String ServiceNo;
	private long truckId;
	private long tripId;	
	
	public long getServiceId() {
		return serviceId;
	}
	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}
	public boolean isServiceComplete() {
		return ServiceComplete;
	}
	public void setServiceComplete(boolean serviceComplete) {
		ServiceComplete = serviceComplete;
	}
	public String getServiceNo() {
		return ServiceNo;
	}
	public void setServiceNo(String serviceNo) {
		ServiceNo = serviceNo;
	}
	public long getTruckId() {
		return truckId;
	}
	public void setTruckId(long truckId) {
		this.truckId = truckId;
	}
	public long getTripId() {
		return tripId;
	}
	public void setTripId(long tripId) {
		this.tripId = tripId;
	}

}
