package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

public class LoadTO implements Serializable {

	 

    /**

     * Universal serial id

     */

    private static final long serialVersionUID = -3413771378731711095L;

 

    private Long loadId;

    private String loadNo;

    private Long originSite;

    private String originLocation;

    private Long destinationSite;

    private String destinationLocation;

    private Date scheduledDate;

    private Date despatchByDate;

    private String holdcode;

    private Date vesselEtaDate;

    private Date deliveryOpen;

    private Date deliveryClose;

    private Date dehireDate;

    private Long priority;

    private String loadTypeId;

    private String custReference;

    private String batchNo;

    private String customerId;

    private Long vesselId;

    private String remarks;

    private BigDecimal custClaim;

    private Date settleDate;

    private String dataSourceId; // ignored on UPDATE

    private Boolean complete; // ignored on UPDATE. Needs specific operation (Load Complete/Backout) to change this value.

    private String destination; // CONSIGNMENT_MASTER.LOCATIONID

    private String wharf;

    private String depot;

    private String customerLocation;

    private String park;

    private List<Long> serviceIds;

	public Long getLoadId() {
		return loadId;
	}

	public void setLoadId(Long loadId) {
		this.loadId = loadId;
	}

	public String getLoadNo() {
		return loadNo;
	}

	public void setLoadNo(String loadNo) {
		this.loadNo = loadNo;
	}

	public Long getOriginSite() {
		return originSite;
	}

	public void setOriginSite(Long originSite) {
		this.originSite = originSite;
	}

	public String getOriginLocation() {
		return originLocation;
	}

	public void setOriginLocation(String originLocation) {
		this.originLocation = originLocation;
	}

	public Long getDestinationSite() {
		return destinationSite;
	}

	public void setDestinationSite(Long destinationSite) {
		this.destinationSite = destinationSite;
	}

	public String getDestinationLocation() {
		return destinationLocation;
	}

	public void setDestinationLocation(String destinationLocation) {
		this.destinationLocation = destinationLocation;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Date getDespatchByDate() {
		return despatchByDate;
	}

	public void setDespatchByDate(Date despatchByDate) {
		this.despatchByDate = despatchByDate;
	}

	public String getHoldcode() {
		return holdcode;
	}

	public void setHoldcode(String holdcode) {
		this.holdcode = holdcode;
	}

	public Date getVesselEtaDate() {
		return vesselEtaDate;
	}

	public void setVesselEtaDate(Date vesselEtaDate) {
		this.vesselEtaDate = vesselEtaDate;
	}

	public Date getDeliveryOpen() {
		return deliveryOpen;
	}

	public void setDeliveryOpen(Date deliveryOpen) {
		this.deliveryOpen = deliveryOpen;
	}

	public Date getDeliveryClose() {
		return deliveryClose;
	}

	public void setDeliveryClose(Date deliveryClose) {
		this.deliveryClose = deliveryClose;
	}

	public Date getDehireDate() {
		return dehireDate;
	}

	public void setDehireDate(Date dehireDate) {
		this.dehireDate = dehireDate;
	}

	public Long getPriority() {
		return priority;
	}

	public void setPriority(Long priority) {
		this.priority = priority;
	}

	public String getLoadTypeId() {
		return loadTypeId;
	}

	public void setLoadTypeId(String loadTypeId) {
		this.loadTypeId = loadTypeId;
	}

	public String getCustReference() {
		return custReference;
	}

	public void setCustReference(String custReference) {
		this.custReference = custReference;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getVesselId() {
		return vesselId;
	}

	public void setVesselId(Long vesselId) {
		this.vesselId = vesselId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getCustClaim() {
		return custClaim;
	}

	public void setCustClaim(BigDecimal custClaim) {
		this.custClaim = custClaim;
	}

	public Date getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}

	public String getDataSourceId() {
		return dataSourceId;
	}

	public void setDataSourceId(String dataSourceId) {
		this.dataSourceId = dataSourceId;
	}

	public Boolean getComplete() {
		return complete;
	}

	public void setComplete(Boolean complete) {
		this.complete = complete;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getWharf() {
		return wharf;
	}

	public void setWharf(String wharf) {
		this.wharf = wharf;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public String getCustomerLocation() {
		return customerLocation;
	}

	public void setCustomerLocation(String customerLocation) {
		this.customerLocation = customerLocation;
	}

	public String getPark() {
		return park;
	}

	public void setPark(String park) {
		this.park = park;
	}

	public List<Long> getServiceIds() {
		return serviceIds;
	}

	public void setServiceIds(List<Long> serviceIds) {
		this.serviceIds = serviceIds;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "LoadTO [loadId=" + loadId + ", loadNo=" + loadNo + ", originSite=" + originSite + ", originLocation="
				+ originLocation + ", destinationSite=" + destinationSite + ", destinationLocation="
				+ destinationLocation + ", scheduledDate=" + scheduledDate + ", despatchByDate=" + despatchByDate
				+ ", holdcode=" + holdcode + ", vesselEtaDate=" + vesselEtaDate + ", deliveryOpen=" + deliveryOpen
				+ ", deliveryClose=" + deliveryClose + ", dehireDate=" + dehireDate + ", priority=" + priority
				+ ", loadTypeId=" + loadTypeId + ", custReference=" + custReference + ", batchNo=" + batchNo
				+ ", customerId=" + customerId + ", vesselId=" + vesselId + ", remarks=" + remarks + ", custClaim="
				+ custClaim + ", settleDate=" + settleDate + ", dataSourceId=" + dataSourceId + ", complete=" + complete
				+ ", destination=" + destination + ", wharf=" + wharf + ", depot=" + depot + ", customerLocation="
				+ customerLocation + ", park=" + park + ", serviceIds=" + serviceIds + "]";
	}
    
    
    
    
    
}