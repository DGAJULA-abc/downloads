package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;

public class LocationTO implements Serializable {
	 private Long siteId;
	 private String locationId;
	 private String locationTypeId;
	 private String locationDesc;
	 private String LocationCode;
	 private Long window1From;
	 private Long window1To;
	 private Long window2From;
	 private Long window2To;
	 private String zonePayId;
	 private String zoneChargeId;
	 private double Latitude;
	 private double Longitude;
	 private Integer Geofence;
	 private String MapSourceId;
	 private String MapReference;
	 private String Address1;
	 private String  Address2;
	 private String Suburb;
	 private String State;
	 private String PostCode;
	 private String Remarks;
	 private Double TruckSizeLimit;
	 private Long DefaultTripSeq;
	 private String RouteId;
	 private Boolean Permanent;
	 private Long window3From;
	 private Long window3To;
	public Long getSiteId() {
		return siteId;
	}
	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getLocationTypeId() {
		return locationTypeId;
	}
	public void setLocationTypeId(String locationTypeId) {
		this.locationTypeId = locationTypeId;
	}
	public String getLocationDesc() {
		return locationDesc;
	}
	public void setLocationDesc(String locationDesc) {
		this.locationDesc = locationDesc;
	}
	public String getLocationCode() {
		return LocationCode;
	}
	public void setLocationCode(String locationCode) {
		LocationCode = locationCode;
	}
	public Long getWindow1From() {
		return window1From;
	}
	public void setWindow1From(Long window1From) {
		this.window1From = window1From;
	}
	public Long getWindow1To() {
		return window1To;
	}
	public void setWindow1To(Long window1To) {
		this.window1To = window1To;
	}
	public Long getWindow2From() {
		return window2From;
	}
	public void setWindow2From(Long window2From) {
		this.window2From = window2From;
	}
	public Long getWindow2To() {
		return window2To;
	}
	public void setWindow2To(Long window2To) {
		this.window2To = window2To;
	}
	public String getZonePayId() {
		return zonePayId;
	}
	public void setZonePayId(String zonePayId) {
		this.zonePayId = zonePayId;
	}
	public String getZoneChargeId() {
		return zoneChargeId;
	}
	public void setZoneChargeId(String zoneChargeId) {
		this.zoneChargeId = zoneChargeId;
	}
	public double getLatitude() {
		return Latitude;
	}
	public void setLatitude(double latitude) {
		Latitude = latitude;
	}
	public double getLongitude() {
		return Longitude;
	}
	public void setLongitude(double longitude) {
		Longitude = longitude;
	}
	public Integer getGeofence() {
		return Geofence;
	}
	public void setGeofence(Integer geofence) {
		Geofence = geofence;
	}
	public String getMapSourceId() {
		return MapSourceId;
	}
	public void setMapSourceId(String mapSourceId) {
		MapSourceId = mapSourceId;
	}
	public String getMapReference() {
		return MapReference;
	}
	public void setMapReference(String mapReference) {
		MapReference = mapReference;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getSuburb() {
		return Suburb;
	}
	public void setSuburb(String suburb) {
		Suburb = suburb;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPostCode() {
		return PostCode;
	}
	public void setPostCode(String postCode) {
		PostCode = postCode;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	public Double getTruckSizeLimit() {
		return TruckSizeLimit;
	}
	public void setTruckSizeLimit(Double truckSizeLimit) {
		TruckSizeLimit = truckSizeLimit;
	}
	public Long getDefaultTripSeq() {
		return DefaultTripSeq;
	}
	public void setDefaultTripSeq(Long defaultTripSeq) {
		DefaultTripSeq = defaultTripSeq;
	}
	public String getRouteId() {
		return RouteId;
	}
	public void setRouteId(String routeId) {
		RouteId = routeId;
	}
	public Boolean getPermanent() {
		return Permanent;
	}
	public void setPermanent(Boolean permanent) {
		Permanent = permanent;
	}
	@Override
	public String toString() {
		return "LocationTO [siteId=" + siteId + ", locationId=" + locationId + ", locationTypeId=" + locationTypeId
				+ ", locationDesc=" + locationDesc + ", LocationCode=" + LocationCode + ", window1From=" + window1From
				+ ", window1To=" + window1To + ", window2From=" + window2From + ", window2To=" + window2To
				+ ", zonePayId=" + zonePayId + ", zoneChargeId=" + zoneChargeId + ", Latitude=" + Latitude
				+ ", Longitude=" + Longitude + ", Geofence=" + Geofence + ", MapSourceId=" + MapSourceId
				+ ", MapReference=" + MapReference + ", Address1=" + Address1 + ", Address2=" + Address2 + ", Suburb="
				+ Suburb + ", State=" + State + ", PostCode=" + PostCode + ", Remarks=" + Remarks + ", TruckSizeLimit="
				+ TruckSizeLimit + ", DefaultTripSeq=" + DefaultTripSeq + ", RouteId=" + RouteId + ", Permanent="
				+ Permanent + "]";
	}
	public Long getWindow3From() {
		return window3From;
	}
	public void setWindow3From(Long window3From) {
		this.window3From = window3From;
	}
	public Long getWindow3To() {
		return window3To;
	}
	public void setWindow3To(Long window3To) {
		this.window3To = window3To;
	}
}
