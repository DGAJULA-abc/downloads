package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;



public class PropertiesTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;

	private Map<Long, Long> creationIdMap = new HashMap<Long, Long>();
	private Boolean despatchService;
	private Set<Long> despatchTripIds = new HashSet<Long>();
	private Boolean existingTrip;
	private Date fromWindow;
	private Date lastTripDate;
	private Long lastTripIdEndOfTrip;
	private String lastTripNo;
	private String lastCustomerId;
	private Long lastDriverId;
	private String lastDropLocation;
	private String lastFinish;
	private Long lastLoadId;
	private String lastLoadType;
	private Double[] lastQtys = new Double[8];
	private Date lastServiceDate;
	private String lastServiceType;
	private String lastTrailerId;
	private String lastTrailerIdTag;
	private String lastTruckId;
	private String[] lastUnits = new String[8];
	private Long newDriverId;
	private String newTrailerId;
	private String newTrailerIdTag;
	private String newTruckId;
	private Boolean redespatch;
	private Set<Long> redespatchTripIds = new HashSet<Long>();
	private Long serviceId;
	private Long siteId;
	private Date toWindow;
	private Long tripId;
	private Boolean updateOnly;

	public Boolean getDespatchService() {
		return despatchService;
	}

	public void setDespatchService(Boolean despatchService) {
		this.despatchService = despatchService;
	}

	public Boolean getExistingTrip() {
		return existingTrip;
	}

	public void setExistingTrip(Boolean existingTrip) {
		this.existingTrip = existingTrip;
	}

	public Date getFromWindow() {
		return fromWindow;
	}

	public void setFromWindow(Date fromWindow) {
		this.fromWindow = fromWindow;
	}

	public Date getLastTripDate() {
		return lastTripDate;
	}

	public void setLastTripDate(Date lastTripDate) {
		this.lastTripDate = lastTripDate;
	}

	public Long getLastTripIdEndOfTrip() {
		return lastTripIdEndOfTrip;
	}

	public void setLastTripIdEndOfTrip(Long lastTripIdEndOfTrip) {
		this.lastTripIdEndOfTrip = lastTripIdEndOfTrip;
	}

	public String getLastTripNo() {
		return lastTripNo;
	}

	public void setLastTripNo(String lastTripNo) {
		this.lastTripNo = lastTripNo;
	}

	public String getLastCustomerId() {
		return lastCustomerId;
	}

	public void setLastCustomerId(String lastCustomerId) {
		this.lastCustomerId = lastCustomerId;
	}

	public Long getLastDriverId() {
		return lastDriverId;
	}

	public void setLastDriverId(Long lastDriverId) {
		this.lastDriverId = lastDriverId;
	}

	public String getLastDropLocation() {
		return lastDropLocation;
	}

	public void setLastDropLocation(String lastDropLocation) {
		this.lastDropLocation = lastDropLocation;
	}

	public String getLastFinish() {
		return lastFinish;
	}

	public void setLastFinish(String lastFinish) {
		this.lastFinish = lastFinish;
	}

	public Long getLastLoadId() {
		return lastLoadId;
	}

	public void setLastLoadId(Long lastLoadId) {
		this.lastLoadId = lastLoadId;
	}

	public String getNewTruckId() {
		return newTruckId;
	}

	public void setNewTruckId(String newTruckId) {
		this.newTruckId = newTruckId;
	}

	public String getLastLoadType() {
		return lastLoadType;
	}

	public void setLastLoadType(String lastLoadType) {
		this.lastLoadType = lastLoadType;
	}

	public Double[] getLastQtys() {
		return lastQtys;
	}

	public void setLastQtys(Double[] lastQtys) {
		this.lastQtys = lastQtys;
	}

	public Date getLastServiceDate() {
		return lastServiceDate;
	}

	public void setLastServiceDate(Date lastServiceDate) {
		this.lastServiceDate = lastServiceDate;
	}

	public String getLastServiceType() {
		return lastServiceType;
	}

	public void setLastServiceType(String lastServiceType) {
		this.lastServiceType = lastServiceType;
	}

	public String getLastTrailerId() {
		return lastTrailerId;
	}

	public void setLastTrailerId(String lastTrailerId) {
		this.lastTrailerId = lastTrailerId;
	}

	public String getLastTrailerIdTag() {
		return lastTrailerIdTag;
	}

	public void setLastTrailerIdTag(String lastTrailerIdTag) {
		this.lastTrailerIdTag = lastTrailerIdTag;
	}

	public String getLastTruckId() {
		return lastTruckId;
	}

	public void setLastTruckId(String lastTruckId) {
		this.lastTruckId = lastTruckId;
	}

	public String[] getLastUnits() {
		return lastUnits;
	}

	public void setLastUnits(String[] lastUnits) {
		this.lastUnits = lastUnits;
	}

	public Long getNewDriverId() {
		return newDriverId;
	}

	public void setNewDriverId(Long newDriverId) {
		this.newDriverId = newDriverId;
	}

	public String getNewTrailerId() {
		return newTrailerId;
	}

	public void setNewTrailerId(String newTrailerId) {
		this.newTrailerId = newTrailerId;
	}

	public String getNewTrailerIdTag() {
		return newTrailerIdTag;
	}

	public void setNewTrailerIdTag(String newTrailerIdTag) {
		this.newTrailerIdTag = newTrailerIdTag;
	}
	public Boolean getRedespatch() {
		return redespatch;
	}

	public void setRedespatch(Boolean redespatch) {
		this.redespatch = redespatch;
	}

	public Long getServiceId() {
		return serviceId;
	}

	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Date getToWindow() {
		return toWindow;
	}

	public void setToWindow(Date toWindow) {
		this.toWindow = toWindow;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public Boolean getUpdateOnly() {
		return updateOnly;
	}

	public void setUpdateOnly(Boolean updateOnly) {
		this.updateOnly = updateOnly;
	}

	public Map<Long, Long> getCreationIdMap() {
		return creationIdMap;
	}

	public void setCreationIdMap(Map<Long, Long> creationIdMap) {
		this.creationIdMap = creationIdMap;
	}

	public Set<Long> getDespatchTripIds() {
		return despatchTripIds;
	}

	public void setDespatchTripIds(Set<Long> despatchTripIds) {
		this.despatchTripIds = despatchTripIds;
	}

	public Set<Long> getRedespatchTripIds() {
		return redespatchTripIds;
	}

	public void setRedespatchTripIds(Set<Long> redespatchTripIds) {
		this.redespatchTripIds = redespatchTripIds;
	}



}
