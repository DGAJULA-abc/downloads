package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;


public class ResourceResultTO implements Serializable {

	private static final long serialVersionUID = -5446431870032686634L;
	private Long outDriver;
	private String outTruck;
	private String outTrailer;
	private String outTrailerTag;
	private String outServiceDesc;

	public Long getOutDriver() {
		return outDriver;
	}

	public void setOutDriver(Long outDriver) {
		this.outDriver = outDriver;
	}

	public String getOutTruck() {
		return outTruck;
	}

	public void setOutTruck(String outTruck) {
		this.outTruck = outTruck;
	}

	public String getOutTrailer() {
		return outTrailer;
	}

	public void setOutTrailer(String outTrailer) {
		this.outTrailer = outTrailer;
	}

	public String getOutTrailerTag() {
		return outTrailerTag;
	}

	public void setOutTrailerTag(String outTrailerTag) {
		this.outTrailerTag = outTrailerTag;
	}

	public String getOutServiceDesc() {
		return outServiceDesc;
	}

	public void setOutServiceDesc(String outServiceDesc) {
		this.outServiceDesc = outServiceDesc;
	}

	@Override
	public String toString() {
		return "BSSResourceResultTO [outDriver=" + outDriver + ", outTruck="
				+ outTruck + ", outTrailer=" + outTrailer + ", outTrailerTag="
				+ outTrailerTag + ", outServiceDesc=" + outServiceDesc + "]";
	}

}
