package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement

public class ReturnCreationTO implements Serializable {

    private static final long serialVersionUID = -282615463037165662L;

    private long id;
    private Long siteId;
    private String locationIdDrop;
    private String serviceType;
    private String loadType;
    private String unit1;
    private String qty1;
    private String unit2;
    private String qty2;
    private String unit3;
    private String qty3;
    private String unit4;
    private String qty4;
    private String unit5;
    private String qty5;
    private String unit6;
    private String qty6;
    private String unit7;
    private String qty7;
    private String unit8;
    private String qty8;

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getLoadType() {
        return loadType;
    }

    public void setLoadType(String loadType) {
        this.loadType = loadType;
    }

    public String getLocationIdDrop() {
        return locationIdDrop;
    }

    public void setLocationIdDrop(String locationIdDrop) {
        this.locationIdDrop = locationIdDrop;
    }

    public String getUnit1() {
        return unit1;
    }

    public void setUnit1(String unit1) {
        this.unit1 = unit1;
    }

    public String getQty1() {
        return qty1;
    }

    public void setQty1(String qty1) {
        this.qty1 = qty1;
    }

    public String getUnit2() {
        return unit2;
    }

    public void setUnit2(String unit2) {
        this.unit2 = unit2;
    }

    public String getQty2() {
        return qty2;
    }

    public void setQty2(String qty2) {
        this.qty2 = qty2;
    }

    public String getUnit3() {
        return unit3;
    }

    public void setUnit3(String unit3) {
        this.unit3 = unit3;
    }

    public String getQty3() {
        return qty3;
    }

    public void setQty3(String qty3) {
        this.qty3 = qty3;
    }

    public String getUnit4() {
        return unit4;
    }

    public void setUnit4(String unit4) {
        this.unit4 = unit4;
    }

    public String getQty4() {
        return qty4;
    }

    public void setQty4(String qty4) {
        this.qty4 = qty4;
    }

    public String getUnit5() {
        return unit5;
    }

    public void setUnit5(String unit5) {
        this.unit5 = unit5;
    }

    public String getQty5() {
        return qty5;
    }

    public void setQty5(String qty5) {
        this.qty5 = qty5;
    }

    public String getUnit6() {
        return unit6;
    }

    public void setUnit6(String unit6) {
        this.unit6 = unit6;
    }

    public String getQty6() {
        return qty6;
    }

    public void setQty6(String qty6) {
        this.qty6 = qty6;
    }

    public String getUnit7() {
        return unit7;
    }

    public void setUnit7(String unit7) {
        this.unit7 = unit7;
    }

    public String getQty7() {
        return qty7;
    }

    public void setQty7(String qty7) {
        this.qty7 = qty7;
    }

    public String getUnit8() {
        return unit8;
    }

    public void setUnit8(String unit8) {
        this.unit8 = unit8;
    }

    public String getQty8() {
        return qty8;
    }

    public void setQty8(String qty8) {
        this.qty8 = qty8;
    }

    @Override
    public String toString() {
        return "ReturnCreationTO [siteId=" + siteId + ", locationIdDrop="
                + locationIdDrop + ", serviceType=" + serviceType
                + ", loadType=" + loadType + ", unit1=" + unit1 + ", qty1="
                + qty1 + ", unit2=" + unit2 + ", qty2=" + qty2 + ", unit3="
                + unit3 + ", qty3=" + qty3 + ", unit4=" + unit4 + ", qty4="
                + qty4 + ", unit5=" + unit5 + ", qty5=" + qty5 + ", unit6="
                + unit6 + ", qty6=" + qty6 + ", unit7=" + unit7 + ", qty7="
                + qty7 + ", unit8=" + unit8 + ", qty8=" + qty8 + ", id=" + id
                + "]";
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


}
