package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFilter;


import jakarta.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class ServiceTO implements Serializable{

    public static final String JSON_FILTER_NAME = "ServiceTOFilter";

    /**
     * Universal serial ID
     */
    private static final long serialVersionUID = -1630105957000286389L;

    private Long id;
    private Long siteId;
    private String serviceTypeId;
    private Date serviceDate;
    private String serviceDesc;
    private String customerId;
    private String loadTypeId;
    private Long loadId;
    private Long driverId;
    private String truckId;

    private String trailerId;
    private String containerId;
    private String locationIdPickup;
    private String locationIdDrop;

    private Double qty1;
    private String unit1;
    private Double qty2;
    private String unit2;
    private Double qty3;
    private String unit3;
    private Double qty4;
    private String unit4;
    private Double qty5;
    private String unit5;
    private Double qty6;
    private String unit6;
    private Double qty7;
    private String unit7;
    private Double qty8;
    private String unit8;

    private Boolean offsiderUsed = false;
    private String docket;
    private String rateId;
    private BigDecimal chargeAmt;
    private String remarks;
    private String holdcode;
    private String dataSourceId;
    private Boolean complete = false;
    private String trailerIdTag;
    private Boolean delivered = false;

    private Date window1From;
    private Date window1To;
    private Date window2From;
    private Date window2To;
    private Boolean used = false;
    private String chargeDesc;
    private Boolean exported = false;
    private String enteredBy;
    private Long serviceIdRecharge;
    private Long tripId;

    private Integer tripSeq;
    private String reasonId;

    private String serviceGroup;
    private Date window3From;
    private Date window3To;
    private String serviceNo;
    private Date bookedTimePickup;
    private Date bookedTimeDrop;
    private Date storeETA;
    private Date etaUpdatedTime;
    private Boolean podCreated = false;
    private Integer todFlags = 0;
    private Date usedSet;
    private String locationIdPickupActual;
    private Date replicated;
    private Date created;
    private Short stopSeqDrop;
    private Short stopSeqPickup;

    private String operationType;
    private String loadNo;
    private Short tripNo;
    private String tripIdCust;
    private String loadBatchNo;
    private String loadCustReference;

    private String window1;
    private String window2;
    private String window3;
    private Long originSite;
    private String originLoc;
    private Long destinationSite;
    private String destinationLoc;
    private Date loadScheduledDate;
    private String loadDestination;
    private Date despatchBy;
    private String loadDesc;
    private String loadSuburb;
    private String address;
    private String chargeZonePickup;
    private String dropDesc;
    private String dropSuburb;
    private String chargeZoneDrop;
    private String containerTypeId;
    private String curfewWindow;
    private Long runsheetId;


    private Date deliveryOpen;
    private Date deliveryClose;
    private Date dehireDeadline;
    private Date vesselEta;
    private Long vesselId;
    private Long priority;
    private String wharf;
    private String depot;
    private String customerSite;
    private String dehirePark;

    /**
     * Constructor
     */
    public ServiceTO() {
    }

    
    /**
     * @return the siteId
     */
    public Long getSiteId() {
        return siteId;
    }

    /**
     * @param siteId the siteId to set
     */
    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    /**
     * @return the serviceTypeId
     */
    public String getServiceTypeId() {
        return serviceTypeId;
    }

    /**
     * @param serviceTypeId the serviceTypeId to set
     */
    public void setServiceTypeId(String serviceTypeId) {
        this.serviceTypeId = serviceTypeId;
    }

    /**
     * @return the serviceDate
     */
    public Date getServiceDate() {
        return serviceDate;
    }

    /**
     * @param serviceDate the serviceDate to set
     */
    public void setServiceDate(Date serviceDate) {
        this.serviceDate = serviceDate;
    }

    /**
     * @return the serviceDesc
     */
    public String getServiceDesc() {
        return serviceDesc;
    }

    /**
     * @param serviceDesc the serviceDesc to set
     */
    public void setServiceDesc(String serviceDesc) {
        this.serviceDesc = serviceDesc;
    }

    /**
     * @return the customerId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the loadTypeId
     */
    public String getLoadTypeId() {
        return loadTypeId;
    }

    /**
     * @param loadTypeId the loadTypeId to set
     */
    public void setLoadTypeId(String loadTypeId) {
        this.loadTypeId = loadTypeId;
    }

    /**
     * @return the loadId
     */
    public Long getLoadId() {
        return loadId;
    }

    /**
     * @param loadId the loadId to set
     */
    public void setLoadId(Long loadId) {
        this.loadId = loadId;
    }

    /**
     * @return the driverId
     */
    public Long getDriverId() {
        return driverId;
    }

    /**
     * @param driverId the driverId to set
     */
    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    /**
     * @return the truckId
     */
    public String getTruckId() {
        return truckId;
    }

    /**
     * @param truckId the truckId to set
     */
    public void setTruckId(String truckId) {
        this.truckId = truckId;
    }

    /**
     * @return the trailerId
     */
    public String getTrailerId() {
        return trailerId;
    }

    /**
     * @param trailerId the trailerId to set
     */
    public void setTrailerId(String trailerId) {
        this.trailerId = trailerId;
    }

    /**
     * @return the containerId
     */
    public String getContainerId() {
        return containerId;
    }

    /**
     * @param containerId the containerId to set
     */
    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    /**
     * @return the locationIdPickup
     */
    public String getLocationIdPickup() {
        return locationIdPickup;
    }

    /**
     * @param locationIdPickup the locationIdPickup to set
     */
    public void setLocationIdPickup(String locationIdPickup) {
        this.locationIdPickup = locationIdPickup;
    }

    /**
     * @return the locationIdDrop
     */
    public String getLocationIdDrop() {
        return locationIdDrop;
    }

    /**
     * @param locationIdDrop the locationIdDrop to set
     */
    public void setLocationIdDrop(String locationIdDrop) {
        this.locationIdDrop = locationIdDrop;
    }

    /**
     * @return the qty1
     */
    public Double getQty1() {
        return qty1;
    }

    /**
     * @param qty1 the qty1 to set
     */
    public void setQty1(Double qty1) {
        this.qty1 = qty1;
    }

    /**
     * @return the unit1
     */
    public String getUnit1() {
        return unit1;
    }

    /**
     * @param unit1 the unit1 to set
     */
    public void setUnit1(String unit1) {
        this.unit1 = unit1;
    }

    /**
     * @return the qty2
     */
    public Double getQty2() {
        return qty2;
    }

    /**
     * @param qty2 the qty2 to set
     */
    public void setQty2(Double qty2) {
        this.qty2 = qty2;
    }

    /**
     * @return the unit2
     */
    public String getUnit2() {
        return unit2;
    }

    /**
     * @param unit2 the unit2 to set
     */
    public void setUnit2(String unit2) {
        this.unit2 = unit2;
    }

    /**
     * @return the qty3
     */
    public Double getQty3() {
        return qty3;
    }

    /**
     * @param qty3 the qty3 to set
     */
    public void setQty3(Double qty3) {
        this.qty3 = qty3;
    }

    /**
     * @return the unit3
     */
    public String getUnit3() {
        return unit3;
    }

    /**
     * @param unit3 the unit3 to set
     */
    public void setUnit3(String unit3) {
        this.unit3 = unit3;
    }

    /**
     * @return the qty4
     */
    public Double getQty4() {
        return qty4;
    }

    /**
     * @param qty4 the qty4 to set
     */
    public void setQty4(Double qty4) {
        this.qty4 = qty4;
    }

    /**
     * @return the unit4
     */
    public String getUnit4() {
        return unit4;
    }

    /**
     * @param unit4 the unit4 to set
     */
    public void setUnit4(String unit4) {
        this.unit4 = unit4;
    }

    /**
     * @return the qty5
     */
    public Double getQty5() {
        return qty5;
    }

    /**
     * @param qty5 the qty5 to set
     */
    public void setQty5(Double qty5) {
        this.qty5 = qty5;
    }

    /**
     * @return the unit5
     */
    public String getUnit5() {
        return unit5;
    }

    /**
     * @param unit5 the unit5 to set
     */
    public void setUnit5(String unit5) {
        this.unit5 = unit5;
    }

    /**
     * @return the qty6
     */
    public Double getQty6() {
        return qty6;
    }

    /**
     * @param qty6 the qty6 to set
     */
    public void setQty6(Double qty6) {
        this.qty6 = qty6;
    }

    /**
     * @return the unit6
     */
    public String getUnit6() {
        return unit6;
    }

    /**
     * @param unit6 the unit6 to set
     */
    public void setUnit6(String unit6) {
        this.unit6 = unit6;
    }

    /**
     * @return the qty7
     */
    public Double getQty7() {
        return qty7;
    }

    /**
     * @param qty7 the qty7 to set
     */
    public void setQty7(Double qty7) {
        this.qty7 = qty7;
    }

    /**
     * @return the unit7
     */
    public String getUnit7() {
        return unit7;
    }

    /**
     * @param unit7 the unit7 to set
     */
    public void setUnit7(String unit7) {
        this.unit7 = unit7;
    }

    /**
     * @return the qty8
     */
    public Double getQty8() {
        return qty8;
    }

    /**
     * @param qty8 the qty8 to set
     */
    public void setQty8(Double qty8) {
        this.qty8 = qty8;
    }

    /**
     * @return the unit8
     */
    public String getUnit8() {
        return unit8;
    }

    /**
     * @param unit8 the unit8 to set
     */
    public void setUnit8(String unit8) {
        this.unit8 = unit8;
    }

    /**
     * @return the offsiderUsed
     */
    public Boolean getOffsiderUsed() {
        return offsiderUsed;
    }

    /**
     * @param offsiderUsed the offsiderUsed to set
     */
    public void setOffsiderUsed(Boolean offsiderUsed) {
        this.offsiderUsed = offsiderUsed;
    }

    /**
     * @return the docket
     */
    public String getDocket() {
        return docket;
    }

    /**
     * @param docket the docket to set
     */
    public void setDocket(String docket) {
        this.docket = docket;
    }

    /**
     * @return the rateId
     */
    public String getRateId() {
        return rateId;
    }

    /**
     * @param rateId the rateId to set
     */
    public void setRateId(String rateId) {
        this.rateId = rateId;
    }

    /**
     * @return the chargeAmt
     */
    public BigDecimal getChargeAmt() {
        return chargeAmt;
    }

    /**
     * @param chargeAmt the chargeAmt to set
     */
    public void setChargeAmt(BigDecimal chargeAmt) {
        this.chargeAmt = chargeAmt;
    }

    /**
     * @return the remarks
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * @param remarks the remarks to set
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /**
     * @return the holdcode
     */
    public String getHoldcode() {
        return holdcode;
    }

    /**
     * @param holdcode the holdcode to set
     */
    public void setHoldcode(String holdcode) {
        this.holdcode = holdcode;
    }

    /**
     * @return the datasourceId
     */
    public String getDataSourceId() {
        return dataSourceId;
    }

    /**
     * @param datasourceId the datasourceId to set
     */
    public void setDataSourceId(String datasourceId) {
        this.dataSourceId = datasourceId;
    }

    /**
     * @return the complete
     */
    public Boolean getComplete() {
        return complete;
    }

    /**
     * @param complete the complete to set
     */
    public void setComplete(Boolean complete) {
        this.complete = complete;
    }

    /**
     * @return the trailerIdTag
     */
    public String getTrailerIdTag() {
        return trailerIdTag;
    }

    /**
     * @param trailerIdTag the trailerIdTag to set
     */
    public void setTrailerIdTag(String trailerIdTag) {
        this.trailerIdTag = trailerIdTag;
    }

    /**
     * @return the delivered
     */
    public Boolean getDelivered() {
        return delivered;
    }

    /**
     * @param delivered the delivered to set
     */
    public void setDelivered(Boolean delivered) {
        this.delivered = delivered;
    }

    /**
     * @return the window1From
     */
    public Date getWindow1From() {
        return window1From;
    }

    /**
     * @param window1From the window1From to set
     */
    public void setWindow1From(Date window1From) {
        this.window1From = window1From;
    }

    /**
     * @return the window1To
     */
    public Date getWindow1To() {
        return window1To;
    }

    /**
     * @param window1To the window1To to set
     */
    public void setWindow1To(Date window1To) {
        this.window1To = window1To;
    }

    /**
     * @return the window2From
     */
    public Date getWindow2From() {
        return window2From;
    }

    /**
     * @param window2From the window2From to set
     */
    public void setWindow2From(Date window2From) {
        this.window2From = window2From;
    }

    /**
     * @return the window2To
     */
    public Date getWindow2To() {
        return window2To;
    }

    /**
     * @param window2To the window2To to set
     */
    public void setWindow2To(Date window2To) {
        this.window2To = window2To;
    }

    /**
     * @return the used
     */
    public Boolean getUsed() {
        return used;
    }

    /**
     * @param used the used to set
     */
    public void setUsed(Boolean used) {
        this.used = used;
    }

    /**
     * @return the chargeDesc
     */
    public String getChargeDesc() {
        return chargeDesc;
    }

    /**
     * @param chargeDesc the chargeDesc to set
     */
    public void setChargeDesc(String chargeDesc) {
        this.chargeDesc = chargeDesc;
    }

    /**
     * @return the exported
     */
    public Boolean getExported() {
        return exported;
    }

    /**
     * @param exported the exported to set
     */
    public void setExported(Boolean exported) {
        this.exported = exported;
    }

    /**
     * @return the enteredBy
     */
    public String getEnteredBy() {
        return enteredBy;
    }

    /**
     * @param enteredBy the enteredBy to set
     */
    public void setEnteredBy(String enteredBy) {
        this.enteredBy = enteredBy;
    }

    /**
     * @return the serviceIdRecharge
     */
    public Long getServiceIdRecharge() {
        return serviceIdRecharge;
    }

    /**
     * @param serviceIdRecharge the serviceIdRecharge to set
     */
    public void setServiceIdRecharge(Long serviceIdRecharge) {
        this.serviceIdRecharge = serviceIdRecharge;
    }

    /**
     * @return the tripId
     */
    public Long getTripId() {
        return tripId;
    }

    /**
     * @param tripId the tripId to set
     */
    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    /**
     * @return the tripSeq
     */
    public Integer getTripSeq() {
        return tripSeq;
    }

    /**
     * @param tripSeq the tripSeq to set
     */
    public void setTripSeq(Integer tripSeq) {
        this.tripSeq = tripSeq;
    }

    /**
     * @return the reasonId
     */
    public String getReasonId() {
        return reasonId;
    }

    /**
     * @param reasonId the reasonId to set
     */
    public void setReasonId(String reasonId) {
        this.reasonId = reasonId;
    }

    /**
     * @return the servicegroup
     */
    public String getServiceGroup() {
        return serviceGroup;
    }

    /**
     * @param servicegroup the servicegroup to set
     */
    public void setServiceGroup(String serviceGroup) {
        this.serviceGroup = serviceGroup;
    }

    /**
     * @return the window3from
     */
    public Date getWindow3From() {
        return window3From;
    }

    /**
     * @param window3from the window3from to set
     */
    public void setWindow3From(Date window3from) {
        this.window3From = window3from;
    }

    /**
     * @return the window3to
     */
    public Date getWindow3To() {
        return window3To;
    }

    /**
     * @param window3to the window3to to set
     */
    public void setWindow3To(Date window3to) {
        this.window3To = window3to;
    }

    /**
     * @return the serviceno
     */
    public String getServiceNo() {
        return serviceNo;
    }

    /**
     * @param serviceno the serviceno to set
     */
    public void setServiceNo(String serviceno) {
        this.serviceNo = serviceno;
    }

    /**
     * @return the bookedtimePickup
     */
    public Date getBookedTimePickup() {
        return bookedTimePickup;
    }

    /**
     * @param bookedtimePickup the bookedtimePickup to set
     */
    public void setBookedTimePickup(Date bookedtimePickup) {
        this.bookedTimePickup = bookedtimePickup;
    }

    /**
     * @return the bookedtimeDrop
     */
    public Date getBookedTimeDrop() {
        return bookedTimeDrop;
    }

    /**
     * @param bookedtimeDrop the bookedtimeDrop to set
     */
    public void setBookedTimeDrop(Date bookedtimeDrop) {
        this.bookedTimeDrop = bookedtimeDrop;
    }

    /**
     * @return the storeeta
     */
    public Date getStoreETA() {
        return storeETA;
    }

    /**
     * @param storeeta the storeeta to set
     */
    public void setStoreETA(Date storeeta) {
        this.storeETA = storeeta;
    }

    /**
     * @return the etaupdatedtime
     */
    public Date getEtaUpdatedTime() {
        return etaUpdatedTime;
    }

    /**
     * @param etaupdatedtime the etaupdatedtime to set
     */
    public void setEtaUpdatedTime(Date etaupdatedtime) {
        this.etaUpdatedTime = etaupdatedtime;
    }

    /**
     * @return the podcreated
     */
    public Boolean getPodCreated() {
        return podCreated;
    }

    /**
     * @param podcreated the podcreated to set
     */
    public void setPodCreated(Boolean podcreated) {
        this.podCreated = podcreated;
    }

    /**
     * @return the todflags
     */
    public Integer getTodFlags() {
        return todFlags;
    }

    /**
     * @param todflags the todflags to set
     */
    public void setTodFlags(Integer todflags) {
        this.todFlags = todflags;
    }

    /**
     * @return the usedset
     */
    public Date getUsedSet() {
        return usedSet;
    }

    /**
     * @param usedset the usedset to set
     */
    public void setUsedSet(Date usedset) {
        this.usedSet = usedset;
    }

    /**
     * @return the replicated
     */
    public Date getReplicated() {
        return replicated;
    }

    /**
     * @return the locationIdPickupActual
     */
    public String getLocationIdPickupActual() {
        return locationIdPickupActual;
    }

    /**
     * @param locationIdPickupActual the locationIdPickupActual to set
     */
    public void setLocationIdPickupActual(String locationIdPickupActual) {
        this.locationIdPickupActual = locationIdPickupActual;
    }

    /**
     * @param replicated the replicated to set
     */
    public void setReplicated(Date replicated) {
        this.replicated = replicated;
    }

    /**
     * @return the created
     */
    public Date getCreated() {
        return created;
    }

    /**
     * @param created the created to set
     */
    public void setCreated(Date created) {
        this.created = created;
    }

    /**
     * @return the stopseqDrop
     */
    public Short getStopSeqDrop() {
        return stopSeqDrop;
    }

    /**
     * @param stopseqDrop the stopseqDrop to set
     */
    public void setStopSeqDrop(Short stopseqDrop) {
        this.stopSeqDrop = stopseqDrop;
    }

    /**
     * @return the stopseqPickup
     */
    public Short getStopSeqPickup() {
        return stopSeqPickup;
    }

    /**
     * @param stopseqPickup the stopseqPickup to set
     */
    public void setStopSeqPickup(Short stopseqPickup) {
        this.stopSeqPickup = stopseqPickup;
    }

    /**
     * @return the loadNo
     */
    public String getLoadNo() {
        return loadNo;
    }

    /**
     * @param loadNo the loadNo to set
     */
    public void setLoadNo(String loadNo) {
        this.loadNo = loadNo;
    }

    /**
     * @return the tripNo
     */
    public Short getTripNo() {
        return tripNo;
    }

    /**
     * @param tripNo
     *            the tripNo to set
     */
    public void setTripNo(Short tripNo) {
        this.tripNo = tripNo;
    }

    /**
     * @return the tripIdCust
     */
    public String getTripIdCust() {
        return tripIdCust;
    }

    /**
     * @param tripIdCust
     *            the tripIdCust to set
     */
    public void setTripIdCust(String tripIdCust) {
        this.tripIdCust = tripIdCust;
    }

    /**
     * @return the loadBatchNo
     */
    public String getLoadBatchNo() {
        return loadBatchNo;
    }

    /**
     * @param loadBatchNo
     *            the loadBatchNo to set
     */
    public void setLoadBatchNo(String loadBatchNo) {
        this.loadBatchNo = loadBatchNo;
    }

    /**
     * @return the loadCustReference
     */
    public String getLoadCustReference() {
        return loadCustReference;
    }

    /**
     * @param loadCustReference
     *            the loadCustReference to set
     */
    public void setLoadCustReference(String loadCustReference) {
        this.loadCustReference = loadCustReference;
    }

    /**
     * @return the window1
     */
    public String getWindow1() {
        return window1;
    }

    /**
     * @param window1
     *            the window1 to set
     */
    public void setWindow1(String window1) {
        this.window1 = window1;
    }

    /**
     * @return the window2
     */
    public String getWindow2() {
        return window2;
    }

    /**
     * @param window2
     *            the window2 to set
     */
    public void setWindow2(String window2) {
        this.window2 = window2;
    }

    /**
     * @return the window3
     */
    public String getWindow3() {
        return window3;
    }

    /**
     * @param window3
     *            the window3 to set
     */
    public void setWindow3(String window3) {
        this.window3 = window3;
    }

    /**
     * @return the originSite
     */
    public Long getOriginSite() {
        return originSite;
    }

    /**
     * @param originSite
     *            the originSite to set
     */
    public void setOriginSite(Long originSite) {
        this.originSite = originSite;
    }

    /**
     * @return the originLoc
     */
    public String getOriginLoc() {
        return originLoc;
    }

    /**
     * @param originLoc
     *            the originLoc to set
     */
    public void setOriginLoc(String originLoc) {
        this.originLoc = originLoc;
    }

    /**
     * @return the destinationSite
     */
    public Long getDestinationSite() {
        return destinationSite;
    }

    /**
     * @param destinationSite
     *            the destinationSite to set
     */
    public void setDestinationSite(Long destinationSite) {
        this.destinationSite = destinationSite;
    }

    /**
     * @return the destinationLoc
     */
    public String getDestinationLoc() {
        return destinationLoc;
    }

    /**
     * @param destinationLoc
     *            the destinationLoc to set
     */
    public void setDestinationLoc(String destinationLoc) {
        this.destinationLoc = destinationLoc;
    }

    /**
     * @return the loadScheduledDate
     */
    public Date getLoadScheduledDate() {
        return loadScheduledDate;
    }

    /**
     * @param loadScheduledDate
     *            the loadScheduledDate to set
     */
    public void setLoadScheduledDate(Date loadScheduledDate) {
        this.loadScheduledDate = loadScheduledDate;
    }

    /**
     * @return the loadDestination
     */
    public String getLoadDestination() {
        return loadDestination;
    }

    /**
     * @param loadDestination
     *            the loadDestination to set
     */
    public void setLoadDestination(String loadDestination) {
        this.loadDestination = loadDestination;
    }

    /**
     * @return the despatchBy
     */
    public Date getDespatchBy() {
        return despatchBy;
    }

    /**
     * @param despatchBy
     *            the despatchBy to set
     */
    public void setDespatchBy(Date despatchBy) {
        this.despatchBy = despatchBy;
    }

    /**
     * @return the loadDesc
     */
    public String getLoadDesc() {
        return loadDesc;
    }

    /**
     * @param loadDesc
     *            the loadDesc to set
     */
    public void setLoadDesc(String loadDesc) {
        this.loadDesc = loadDesc;
    }

    /**
     * @return the loadSuburb
     */
    public String getLoadSuburb() {
        return loadSuburb;
    }

    /**
     * @param loadSuburb
     *            the loadSuburb to set
     */
    public void setLoadSuburb(String loadSuburb) {
        this.loadSuburb = loadSuburb;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address
     *            the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the chargeZonePickup
     */
    public String getChargeZonePickup() {
        return chargeZonePickup;
    }

    /**
     * @param chargeZonePickup
     *            the chargeZonePickup to set
     */
    public void setChargeZonePickup(String chargeZonePickup) {
        this.chargeZonePickup = chargeZonePickup;
    }

    /**
     * @return the dropDesc
     */
    public String getDropDesc() {
        return dropDesc;
    }

    /**
     * @param dropDesc
     *            the dropDesc to set
     */
    public void setDropDesc(String dropDesc) {
        this.dropDesc = dropDesc;
    }

    /**
     * @return the dropSuburb
     */
    public String getDropSuburb() {
        return dropSuburb;
    }

    /**
     * @param dropSuburb
     *            the dropSuburb to set
     */
    public void setDropSuburb(String dropSuburb) {
        this.dropSuburb = dropSuburb;
    }

    /**
     * @return the chargeZoneDrop
     */
    public String getChargeZoneDrop() {
        return chargeZoneDrop;
    }

    /**
     * @param chargeZoneDrop
     *            the chargeZoneDrop to set
     */
    public void setChargeZoneDrop(String chargeZoneDrop) {
        this.chargeZoneDrop = chargeZoneDrop;
    }

    /**
     * @return the containerTypeId
     */
    public String getContainerTypeId() {
        return containerTypeId;
    }

    /**
     * @param containerTypeId
     *            the containerTypeId to set
     */
    public void setContainerTypeId(String containerTypeId) {
        this.containerTypeId = containerTypeId;
    }

    /**
     * @return the curfewWindow
     */
    public String getCurfewWindow() {
        return curfewWindow;
    }

    /**
     * @param curfewWindow
     *            the curfewWindow to set
     */
    public void setCurfewWindow(String curfewWindow) {
        this.curfewWindow = curfewWindow;
    }

    /**
     * @return the runsheetId
     */
    public Long getRunsheetId() {
        return runsheetId;
    }

    /**
     * @param runsheetId the runsheetId to set
     */
    public void setRunsheetId(Long runsheetId) {
        this.runsheetId = runsheetId;
    }

   

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    /**
     * @return the loadDeliveryOpen
     */
    public Date getDeliveryOpen() {
        return deliveryOpen;
    }

    /**
     * @param loadDeliveryOpen the loadDeliveryOpen to set
     */
    public void setDeliveryOpen(Date loadDeliveryOpen) {
        this.deliveryOpen = loadDeliveryOpen;
    }

    /**
     * @return the loadDeliveryClose
     */
    public Date getDeliveryClose() {
        return deliveryClose;
    }

    /**
     * @param loadDeliveryClose the loadDeliveryClose to set
     */
    public void setDeliveryClose(Date loadDeliveryClose) {
        this.deliveryClose = loadDeliveryClose;
    }

    /**
     * @return the containerDehireDate
     */
    public Date getDehireDeadline() {
        return dehireDeadline;
    }

    /**
     * @param containerDehireDate the containerDehireDate to set
     */
    public void setDehireDeadline(Date dehireDeadline) {
        this.dehireDeadline = dehireDeadline;
    }

    /**
     * @return the vesselEtaDate
     */
    public Date getVesselEta() {
        return vesselEta;
    }

    /**
     * @param vesselEtaDate the vesselEtaDate to set
     */
    public void setVesselEta(Date vesselEtaDate) {
        this.vesselEta = vesselEtaDate;
    }

    /**
     * @return the vesselId
     */
    public Long getVesselId() {
        return vesselId;
    }

    /**
     * @param vesselId the vesselId to set
     */
    public void setVesselId(Long vesselId) {
        this.vesselId = vesselId;
    }

    /**
     * @return the customerLocation
     */
    public String getCustomerSite() {
        return customerSite;
    }

    /**
     * @param customerLocation the customerLocation to set
     */
    public void setCustomerSite(String customerLocation) {
        this.customerSite = customerLocation;
    }

    /**
     * @return the priority
     */
    public Long getPriority() {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(Long priority) {
        this.priority = priority;
    }

    /**
     * @return the wharfLocation
     */
    public String getWharf() {
        return wharf;
    }

    /**
     * @param wharfLocation the wharfLocation to set
     */
    public void setWharf(String wharfLocation) {
        this.wharf = wharfLocation;
    }

    /**
     * @return the depotLocation
     */
    public String getDepot() {
        return depot;
    }

    /**
     * @param depotLocation the depotLocation to set
     */
    public void setDepot(String depotLocation) {
        this.depot = depotLocation;
    }

    /**
     * @return the parkLocation
     */
    public String getDehirePark() {
        return dehirePark;
    }

    /**
     * @param parkLocation the parkLocation to set
     */
    public void setDehirePark(String parkLocation) {
        this.dehirePark = parkLocation;
    }


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}
}
