package au.com.tollgroup.a2.sicli.model;

 

public class ServiceTypeTO {

    private String UNIT1;

    public String UNIT2;

    public String UNIT3;

    public String UNIT4;

    public String UNIT5;

    public String UNIT6;

    public String UNIT7;

    public String UNIT8;

    public String getUNIT1() {

        return UNIT1;

    }

    public void setUNIT1(String uNIT1) {

        UNIT1 = uNIT1;

    }

    public String getUNIT2() {

        return UNIT2;

    }

    public void setUNIT2(String uNIT2) {

        UNIT2 = uNIT2;

    }

    public String getUNIT3() {

        return UNIT3;

    }

    public void setUNIT3(String uNIT3) {

        UNIT3 = uNIT3;

    }

    public String getUNIT4() {

        return UNIT4;

    }

    public void setUNIT4(String uNIT4) {

        UNIT4 = uNIT4;

    }

    public String getUNIT5() {

        return UNIT5;

    }

    public void setUNIT5(String uNIT5) {

        UNIT5 = uNIT5;

    }

    public String getUNIT6() {

        return UNIT6;

    }

    public void setUNIT6(String uNIT6) {

        UNIT6 = uNIT6;

    }

    public String getUNIT7() {

        return UNIT7;

    }

    public void setUNIT7(String uNIT7) {

        UNIT7 = uNIT7;

    }

    public String getUNIT8() {

        return UNIT8;

    }

    public void setUNIT8(String uNIT8) {

        UNIT8 = uNIT8;

    }

    @Override

    public String toString() {

        return "ServiceTypeTO [UNIT1=" + UNIT1 + ", UNIT2=" + UNIT2 + ", UNIT3=" + UNIT3 + ", UNIT4=" + UNIT4

                + ", UNIT5=" + UNIT5 + ", UNIT6=" + UNIT6 + ", UNIT7=" + UNIT7 + ", UNIT8=" + UNIT8 + "]";

    }

}