package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.List;

public class TrailerResourceTO implements Serializable {

	/**
	 * Universal serial id
	 */
	private static final long serialVersionUID = 8755412579169060529L;

	private String trailerId;
	private Long siteid;
	private String TrailerIdTag;
	private List<TripResourceTO> trips;

	/**
	 * @return the trailerId
	 */
	public String getTrailerId() {
		return trailerId;
	}

	/**
	 * @param trailerId the trailerId to set
	 */
	public void setTrailerId(String trailerId) {
		this.trailerId = trailerId;
	}

	/**
	 * @return the trips
	 */
	public List<TripResourceTO> getTrips() {
		return trips;
	}

	/**
	 * @param trips the trips to set
	 */
	public void setTrips(List<TripResourceTO> trips) {
		this.trips = trips;
	}

	@Override
	public String toString() {
		return "TrailerResourceTO [trailerId=" + trailerId + ", trips=" + trips + "]";
	}

	public Long getSiteid() {
		return siteid;
	}

	public void setSiteid(Long siteid) {
		this.siteid = siteid;
	}

	public String getTrailerIdTag() {
		return TrailerIdTag;
	}

	public void setTrailerIdTag(String trailerIdTag) {
		TrailerIdTag = trailerIdTag;
	}

}
