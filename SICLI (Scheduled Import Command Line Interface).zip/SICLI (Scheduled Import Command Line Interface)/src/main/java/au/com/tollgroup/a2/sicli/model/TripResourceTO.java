package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;



public class TripResourceTO implements Serializable {

    /**
     * Universal serial id 
     */
    private static final long serialVersionUID = 8755412579169060529L;

    private Long tripId;

 

    // private Date tripDate;
    // private Date plannedStartTime;
    // private Date plannedEndTime;

 

    /**
     * @return the tripId
     */
    public Long getTripId() {
        return tripId;
    }

 

    /**
     * @param tripId
     *            the tripId to set
     */
    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

 

    @Override
    public String toString() {
        return "TripResourceTO [tripId=" + tripId + "]";
    }

 

    // /**
    // * @return the tripDate
    // */
    // public Date getTripDate() {
    // return tripDate;
    // }
    //
    // /**
    // * @param tripDate
    // * the tripDate to set
    // */
    // public void setTripDate(Date tripDate) {
    // this.tripDate = tripDate;
    // }
    //
    // /**
    // * @return the plannedStartTime
    // */
    // public Date getPlannedStartTime() {
    // return plannedStartTime;
    // }
    //
    // /**
    // * @param plannedStartTime
    // * the plannedStartTime to set
    // */
    // public void setPlannedStartTime(Date plannedStartTime) {
    // this.plannedStartTime = plannedStartTime;
    // }
    //
    // /**
    // * @return the plannedEndTime
    // */
    // public Date getPlannedEndTime() {
    // return plannedEndTime;
    // }
    //
    // /**
    // * @param plannedEndTime
    // * the plannedEndTime to set
    // */
    // public void setPlannedEndTime(Date plannedEndTime) {
    // this.plannedEndTime = plannedEndTime;
    // }

 



}
