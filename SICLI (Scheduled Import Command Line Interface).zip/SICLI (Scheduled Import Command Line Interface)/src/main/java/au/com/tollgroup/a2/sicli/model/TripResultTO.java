package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.Date;

public class TripResultTO implements Serializable {

	private static final long serialVersionUID = -5446431870032686634L;
	private Long ID;
	private Long outLastTripId;
	private Integer outLastTripSeq;
	private Long outTripId;
	private Integer outTripSeq;
	private Long outNewTripId;
	private Date outServiceDate;

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public Long getOutLastTripId() {
		return outLastTripId;
	}

	public void setOutLastTripId(Long outLastTripId) {
		this.outLastTripId = outLastTripId;
	}

	public Integer getOutLastTripSeq() {
		return outLastTripSeq;
	}

	public void setOutLastTripSeq(Integer outLastTripSeq) {
		this.outLastTripSeq = outLastTripSeq;
	}

	public Long getOutTripId() {
		return outTripId;
	}

	public void setOutTripId(Long outTripId) {
		this.outTripId = outTripId;
	}

	public Integer getOutTripSeq() {
		return outTripSeq;
	}

	public void setOutTripSeq(Integer outTripSeq) {
		this.outTripSeq = outTripSeq;
	}

	public Long getOutNewTripId() {
		return outNewTripId;
	}

	public void setOutNewTripId(Long outNewTripId) {
		this.outNewTripId = outNewTripId;
	}

	public Date getOutServiceDate() {
		return outServiceDate;
	}

	public void setOutServiceDate(Date outServiceDate) {
		this.outServiceDate = outServiceDate;
	}

	@Override
	public String toString() {
		return "BSSTripResultTO [outLastTripId=" + outLastTripId + ", outLastTripSeq=" + outLastTripSeq + ", outTripId="
				+ outTripId + ", outTripSeq=" + outTripSeq + ", outNewTripId=" + outNewTripId + ", outServiceDate="
				+ outServiceDate + "]";
	}

}
