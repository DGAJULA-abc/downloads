package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import oracle.sql.CHAR;


public class TripTO implements Serializable {
	public Long ID;
	public Long SITEID;
	public Timestamp TRIPDATE;
	public String ROUTEID;
	public Long DRIVERID;
	public String TRUCKI;
	public Long TRUCKID;
	public String TRAILERID;
	public String TRAILERID_TAG;
	public Boolean TRIPCOMPLETE;
	public Timestamp PLANNEDSTARTTIME;
	public Timestamp PLANNEDDESPATCHTIME;
	public Timestamp PLANNEDRETURNTIME;
	public Timestamp PLANNEDFINISHTIME;
	public String PICKWAVEREF;
	public Timestamp SETTLEDATE;
	public Long CUSTCLAIMAMT;
	public String LOCATIONID_DESPATCH;
	public String LOCATIONID_RETURN;
	public String ENTEREDBY;
	public String HOLDCODE;
	public String DATASOURCEID;
	public Long TRIPNO;
	public Long DOCKID;
	public String TRIPID_CUST;
	public Boolean DESPATCH;
	public Timestamp ETAUPDATEDTIME;
	public Timestamp ACTUALSTARTTIME;
	public Timestamp ACTUALDESPATCHTIME;
	public Timestamp ACTUALRETURNTIME;
	public Timestamp ACTUALFINISHTIME;
	public String CACHEDSTATUS;
	public Long CACHEDROUTINGQTY;
	public Long CACHEDTRUCKCAPACITY;
	public Long CACHEDTRAILERCAPACITY;
	public Long CACHEDPHASE;
	public Long REVENUE;
	public Timestamp CREATED;
	public Timestamp ENDTIME;
	public Boolean getTRIPCOMPLETE() {
		return TRIPCOMPLETE;
	}

	public void setTRIPCOMPLETE(Boolean tRIPCOMPLETE) {
		TRIPCOMPLETE = tRIPCOMPLETE;
	}

	public Timestamp STARTTIME;
	public String COMMENTS;

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public Long getSITEID() {
		return SITEID;
	}

	public void setSITEID(Long sITEID) {
		SITEID = sITEID;
	}

	public Timestamp getTRIPDATE() {
		return TRIPDATE;
	}

	public void setTRIPDATE(Timestamp tRIPDATE) {
		TRIPDATE = tRIPDATE;
	}

	public String getROUTEID() {
		return ROUTEID;
	}

	public void setROUTEID(String rOUTEID) {
		ROUTEID = rOUTEID;
	}

	public Long getDRIVERID() {
		return DRIVERID;
	}

	public void setDRIVERID(Long dRIVERID) {
		DRIVERID = dRIVERID;
	}
	public Long getTRUCKID() {
		return TRUCKID;
	}

	public void setTRUCKID(Long tRUCKID) {
		TRUCKID = tRUCKID;
	}

	public String getTRUCKI() {
		return TRUCKI;
	}

	public Boolean getDESPATCH() {
		return DESPATCH;
	}

	public void setTRUCKI(String tRUCKI) {
		TRUCKI = tRUCKI;
	}

	public void setDESPATCH(Boolean dESPATCH) {
		DESPATCH = dESPATCH;
	}

	public String getTRAILERID() {
		return TRAILERID;
	}

	public void setTRAILERID(String tRAILERID) {
		TRAILERID = tRAILERID;
	}

	public String getTRAILERID_TAG() {
		return TRAILERID_TAG;
	}

	public String getCACHEDSTATUS() {
		return CACHEDSTATUS;
	}

	public void setCACHEDSTATUS(String cACHEDSTATUS) {
		CACHEDSTATUS = cACHEDSTATUS;
	}

	public void setTRAILERID_TAG(String tRAILERID_TAG) {
		TRAILERID_TAG = tRAILERID_TAG;
	}

	public Timestamp getPLANNEDSTARTTIME() {
		return PLANNEDSTARTTIME;
	}

	public void setPLANNEDSTARTTIME(Timestamp pLANNEDSTARTTIME) {
		PLANNEDSTARTTIME = pLANNEDSTARTTIME;
	}

	public Timestamp getPLANNEDDESPATCHTIME() {
		return PLANNEDDESPATCHTIME;
	}

	public void setPLANNEDDESPATCHTIME(Timestamp pLANNEDDESPATCHTIME) {
		PLANNEDDESPATCHTIME = pLANNEDDESPATCHTIME;
	}

	public Timestamp getPLANNEDRETURNTIME() {
		return PLANNEDRETURNTIME;
	}

	public void setPLANNEDRETURNTIME(Timestamp pLANNEDRETURNTIME) {
		PLANNEDRETURNTIME = pLANNEDRETURNTIME;
	}

	public Timestamp getPLANNEDFINISHTIME() {
		return PLANNEDFINISHTIME;
	}

	public void setPLANNEDFINISHTIME(Timestamp pLANNEDFINISHTIME) {
		PLANNEDFINISHTIME = pLANNEDFINISHTIME;
	}

	public String getPICKWAVEREF() {
		return PICKWAVEREF;
	}

	public void setPICKWAVEREF(String pICKWAVEREF) {
		PICKWAVEREF = pICKWAVEREF;
	}

	public Timestamp getSETTLEDATE() {
		return SETTLEDATE;
	}

	public void setSETTLEDATE(Timestamp sETTLEDATE) {
		SETTLEDATE = sETTLEDATE;
	}

	public Long getCUSTCLAIMAMT() {
		return CUSTCLAIMAMT;
	}

	public void setCUSTCLAIMAMT(Long cUSTCLAIMAMT) {
		CUSTCLAIMAMT = cUSTCLAIMAMT;
	}

	public String getLOCATIONID_DESPATCH() {
		return LOCATIONID_DESPATCH;
	}

	public void setLOCATIONID_DESPATCH(String lOCATIONID_DESPATCH) {
		LOCATIONID_DESPATCH = lOCATIONID_DESPATCH;
	}

	public String getLOCATIONID_RETURN() {
		return LOCATIONID_RETURN;
	}

	public void setLOCATIONID_RETURN(String lOCATIONID_RETURN) {
		LOCATIONID_RETURN = lOCATIONID_RETURN;
	}

	public String getENTEREDBY() {
		return ENTEREDBY;
	}

	public void setENTEREDBY(String eNTEREDBY) {
		ENTEREDBY = eNTEREDBY;
	}

	public String getHOLDCODE() {
		return HOLDCODE;
	}

	public void setHOLDCODE(String hOLDCODE) {
		HOLDCODE = hOLDCODE;
	}

	public String getDATASOURCEID() {
		return DATASOURCEID;
	}

	public void setDATASOURCEID(String dATASOURCEID) {
		DATASOURCEID = dATASOURCEID;
	}

	public Long getTRIPNO() {
		return TRIPNO;
	}

	public void setTRIPNO(Long tRIPNO) {
		TRIPNO = tRIPNO;
	}

	public Long getDOCKID() {
		return DOCKID;
	}

	public void setDOCKID(Long dOCKID) {
		DOCKID = dOCKID;
	}

	public String getTRIPID_CUST() {
		return TRIPID_CUST;
	}

	public void setTRIPID_CUST(String tRIPID_CUST) {
		TRIPID_CUST = tRIPID_CUST;
	}
	public Timestamp getETAUPDATEDTIME() {
		return ETAUPDATEDTIME;
	}

	public void setETAUPDATEDTIME(Timestamp eTAUPDATEDTIME) {
		ETAUPDATEDTIME = eTAUPDATEDTIME;
	}

	public Timestamp getACTUALSTARTTIME() {
		return ACTUALSTARTTIME;
	}

	public void setACTUALSTARTTIME(Timestamp aCTUALSTARTTIME) {
		ACTUALSTARTTIME = aCTUALSTARTTIME;
	}

	public Timestamp getACTUALDESPATCHTIME() {
		return ACTUALDESPATCHTIME;
	}

	public void setACTUALDESPATCHTIME(Timestamp aCTUALDESPATCHTIME) {
		ACTUALDESPATCHTIME = aCTUALDESPATCHTIME;
	}

	public Timestamp getACTUALRETURNTIME() {
		return ACTUALRETURNTIME;
	}

	public void setACTUALRETURNTIME(Timestamp aCTUALRETURNTIME) {
		ACTUALRETURNTIME = aCTUALRETURNTIME;
	}

	public Timestamp getACTUALFINISHTIME() {
		return ACTUALFINISHTIME;
	}

	public void setACTUALFINISHTIME(Timestamp aCTUALFINISHTIME) {
		ACTUALFINISHTIME = aCTUALFINISHTIME;
	}

	public Long getCACHEDROUTINGQTY() {
		return CACHEDROUTINGQTY;
	}

	public void setCACHEDROUTINGQTY(Long cACHEDROUTINGQTY) {
		CACHEDROUTINGQTY = cACHEDROUTINGQTY;
	}

	public Long getCACHEDTRUCKCAPACITY() {
		return CACHEDTRUCKCAPACITY;
	}

	public void setCACHEDTRUCKCAPACITY(Long cACHEDTRUCKCAPACITY) {
		CACHEDTRUCKCAPACITY = cACHEDTRUCKCAPACITY;
	}

	public Long getCACHEDTRAILERCAPACITY() {
		return CACHEDTRAILERCAPACITY;
	}

	public void setCACHEDTRAILERCAPACITY(Long cACHEDTRAILERCAPACITY) {
		CACHEDTRAILERCAPACITY = cACHEDTRAILERCAPACITY;
	}

	public Long getCACHEDPHASE() {
		return CACHEDPHASE;
	}

	public void setCACHEDPHASE(Long cACHEDPHASE) {
		CACHEDPHASE = cACHEDPHASE;
	}

	public Long getREVENUE() {
		return REVENUE;
	}

	public void setREVENUE(Long rEVENUE) {
		REVENUE = rEVENUE;
	}

	public Timestamp getCREATED() {
		return CREATED;
	}

	public void setCREATED(Timestamp cREATED) {
		CREATED = cREATED;
	}

	public Timestamp getENDTIME() {
		return ENDTIME;
	}

	public void setENDTIME(Timestamp eNDTIME) {
		ENDTIME = eNDTIME;
	}

	public Timestamp getSTARTTIME() {
		return STARTTIME;
	}

	public void setSTARTTIME(Timestamp sTARTTIME) {
		STARTTIME = sTARTTIME;
	}

	public String getCOMMENTS() {
		return COMMENTS;
	}

	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}

	@Override
	public String toString() {
		return "TripTO [ID=" + ID + ", SITEID=" + SITEID + ", TRIPDATE=" + TRIPDATE + ", ROUTEID=" + ROUTEID
				+ ", DRIVERID=" + DRIVERID + ", TRUCKI=" + TRUCKI + ", TRAILERID=" + TRAILERID + ", TRAILERID_TAG="
				+ TRAILERID_TAG + ", TRIPCOMPLETE=" + TRIPCOMPLETE + ", PLANNEDSTARTTIME=" + PLANNEDSTARTTIME
				+ ", PLANNEDDESPATCHTIME=" + PLANNEDDESPATCHTIME + ", PLANNEDRETURNTIME=" + PLANNEDRETURNTIME
				+ ", PLANNEDFINISHTIME=" + PLANNEDFINISHTIME + ", PICKWAVEREF=" + PICKWAVEREF + ", SETTLEDATE="
				+ SETTLEDATE + ", CUSTCLAIMAMT=" + CUSTCLAIMAMT + ", LOCATIONID_DESPATCH=" + LOCATIONID_DESPATCH
				+ ", LOCATIONID_RETURN=" + LOCATIONID_RETURN + ", ENTEREDBY=" + ENTEREDBY + ", HOLDCODE=" + HOLDCODE
				+ ", DATASOURCEID=" + DATASOURCEID + ", TRIPNO=" + TRIPNO + ", DOCKID=" + DOCKID + ", TRIPID_CUST="
				+ TRIPID_CUST + ", DESPATCH=" + DESPATCH + ", ETAUPDATEDTIME=" + ETAUPDATEDTIME + ", ACTUALSTARTTIME="
				+ ACTUALSTARTTIME + ", ACTUALDESPATCHTIME=" + ACTUALDESPATCHTIME + ", ACTUALRETURNTIME="
				+ ACTUALRETURNTIME + ", ACTUALFINISHTIME=" + ACTUALFINISHTIME + ", CACHEDSTATUS=" + CACHEDSTATUS
				+ ", CACHEDROUTINGQTY=" + CACHEDROUTINGQTY + ", CACHEDTRUCKCAPACITY=" + CACHEDTRUCKCAPACITY
				+ ", CACHEDTRAILERCAPACITY=" + CACHEDTRAILERCAPACITY + ", CACHEDPHASE=" + CACHEDPHASE + ", REVENUE="
				+ REVENUE + ", CREATED=" + CREATED + ", ENDTIME=" + ENDTIME + ", STARTTIME=" + STARTTIME + ", COMMENTS="
				+ COMMENTS + "]";
	}

}
