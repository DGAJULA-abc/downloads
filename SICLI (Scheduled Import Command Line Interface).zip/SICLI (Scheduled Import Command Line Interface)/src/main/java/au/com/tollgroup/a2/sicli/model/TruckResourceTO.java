package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.List;

 

public class TruckResourceTO implements Serializable {

    /**
     * Universal serial id 
     */
    private static final long serialVersionUID = 8755412579169060529L;

    private String truckId;
    private Long siteid;
    private String TrailerIdTag;
    private List<TripResourceTO> trips;

 

    /**
     * @return the truckId
     */
    public String getTruckId() {
        return truckId;
    }
    /**
     * @param truckId the truckId to set
     */
    public void setTruckId(String truckId) {
        this.truckId = truckId;
    }

    /**
     * @return the trips
     */
    public List<TripResourceTO> getTrips() {
        return trips;
    }

    /**
     * @param trips
     *            the trips to set
     */
    public void setTrips(List<TripResourceTO> trips) {
        this.trips = trips;
    }
    @Override
    public String toString() {
        return "TruckResourceTO [truckId=" + truckId + ", trips=" + trips + "]";
    }
	public Long getSiteid() {
		return siteid;
	}
	public void setSiteid(Long siteid) {
		this.siteid = siteid;
	}
	public String getTrailerIdTag() {
		return TrailerIdTag;
	}
	public void setTrailerIdTag(String trailerIdTag) {
		TrailerIdTag = trailerIdTag;
	}

 


}
