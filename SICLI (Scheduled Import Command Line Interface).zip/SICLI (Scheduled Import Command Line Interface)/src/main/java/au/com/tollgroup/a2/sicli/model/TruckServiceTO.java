package au.com.tollgroup.a2.sicli.model;

import au.com.tollgroup.a2.sicli.util.ImpJobLogTO;

public class TruckServiceTO {
	
	private ImpJobLogTO jobLog;

	public ImpJobLogTO getJobLog() {
		return jobLog;
	}

	public void setJobLog(ImpJobLogTO jobLog) {
		this.jobLog = jobLog;
	}

}
