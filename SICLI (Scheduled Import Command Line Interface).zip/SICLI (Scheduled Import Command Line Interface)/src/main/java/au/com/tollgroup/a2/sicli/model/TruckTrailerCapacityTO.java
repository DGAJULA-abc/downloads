package au.com.tollgroup.a2.sicli.model;

public class TruckTrailerCapacityTO {

  private Double truckcapacity;
  private Double trailer1capacity;
  private Double trailer2capacity;
public Double getTruckcapacity() {
	return truckcapacity;
}
public void setTruckcapacity(Double truckcapacity) {
	this.truckcapacity = truckcapacity;
}
public Double getTrailer1capacity() {
	return trailer1capacity;
}
public void setTrailer1capacity(Double trailer1capacity) {
	this.trailer1capacity = trailer1capacity;
}
public Double getTrailer2capacity() {
	return trailer2capacity;
}
public void setTrailer2capacity(Double trailer2capacity) {
	this.trailer2capacity = trailer2capacity;
}
  
  


}
