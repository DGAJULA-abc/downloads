package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;
import java.util.List;



public class UnitTO implements Serializable {

    /**
     * Universal serial id
     */
    private static final long serialVersionUID = 1974970624968446476L;

    
    private String unitId;

    
    private Long siteId;

    
    private Short decimalPlaces;

    
    private Boolean allowNegative;

    /**
     * no-args constructor
     **/
    public UnitTO() {}
    
    /**
     * args constructor
     **/
    public UnitTO(
    		String unitId,
    		Long siteId,
    		Short decimalPlaces,
    		Boolean allowNegative) {
    	
    	this.unitId = unitId;
    	this.siteId = siteId;
    	this.decimalPlaces = decimalPlaces;
    	this.allowNegative = allowNegative;
    }
    
    /**
     * @return the unitId
     */
    public String getUnitId() {
        return unitId;
    }

    /**
     * @param unitId the unitId to set
     */
    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    /**
     * @return the siteId
     */
    public Long getSiteId() {
        return siteId;
    }

    /**
     * @param siteId the siteId to set
     */
    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    /**
     * @return the decimalPlaces
     */
    public Short getDecimalPlaces() {
        return decimalPlaces;
    }

    /**
     * @param decimalPlaces the decimalPlaces to set
     */
    public void setDecimalPlaces(Short decimalPlaces) {
        this.decimalPlaces = decimalPlaces;
    }

    /**
     * @return the allowNegative
     */
    public Boolean getAllowNegative() {
        return allowNegative;
    }

    /**
     * @param allowNegative the allowNegative to set
     */
    public void setAllowNegative(Boolean allowNegative) {
        this.allowNegative = allowNegative;
    }

	/**
	 * Searches through units ref data for the specified unitId and returns
	 * the decimal places it is configured to have
	 * 
	 * @param units
	 * @param unitId
	 * @return 
	 **/
	public static int findDecimalPlacesForUnit(List<UnitTO> units, String unitId) {

		int decimalPlaces = 0;

		if (units == null || units.isEmpty() || unitId == null) {
			return decimalPlaces;
		}

		for (UnitTO unit : units) {
			if (unitId.equalsIgnoreCase(unit.getUnitId())) {

				if (unit.getDecimalPlaces() != null) {
					decimalPlaces = unit.getDecimalPlaces();
				}
				break;
			}
		}

		return decimalPlaces;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((siteId == null) ? 0 : siteId.hashCode());
        result = prime * result + ((unitId == null) ? 0 : unitId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        UnitTO other = (UnitTO) obj;
        if (siteId == null) {
            if (other.siteId != null) {
                return false;
            }
        } else if (!siteId.equals(other.siteId)) {
            return false;
        }
        if (unitId == null) {
            if (other.unitId != null) {
                return false;
            }
        } else if (!unitId.equals(other.unitId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "UnitTO [unitId=" + unitId + ", siteId=" + siteId
                + ", decimalPlaces=" + decimalPlaces + ", allowNegative="
                + allowNegative + "]";
    }
}
