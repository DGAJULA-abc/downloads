package au.com.tollgroup.a2.sicli.model;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlRootElement;



/**
 * BSS validation result.
 */
@XmlRootElement
public class ValidationResultTO implements Serializable {

	private static final long serialVersionUID = -5446431870032686634L;
	private boolean success;
	private String newResource;
	private Long newDriverId;
	private String sql;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getNewResource() {
		return newResource;
	}

	public void setNewResource(String newResource) {
		this.newResource = newResource;
	}

	public Long getNewDriverId() {
		return newDriverId;
	}

	public void setNewDriverId(Long newDriverId) {
		this.newDriverId = newDriverId;
	}

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}

	@Override
	public String toString() {
		return "BSSValidationResultTO [success=" + success + ", newResource="
				+ newResource + ", newDriverId=" + newDriverId + ", sql=" + sql
				+ "]";
	};

}
