package au.com.tollgroup.a2.sicli.model;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class WindowTO {
	
    private Date Window1From;
    private Date Window1To;
    private Date Window2From;
    private Date Window2To;
    private Date Window3From;
    private Date Window3To;
   // private Long siteId;
   // private String locationId;
   // private String serviceTypeId;
    
    
	public Date getWindow1From() {
		return Window1From;
	}
	public void setWindow1From(Date window1From) {
		Window1From = window1From;
	}
	public Date getWindow1To() {
		return Window1To;
	}
	public void setWindow1To(Date window1To) {
		Window1To = window1To;
	}
	public Date getWindow2From() {
		return Window2From;
	}
	public void setWindow2From(Date window2From) {
		Window2From = window2From;
	}
	public Date getWindow2To() {
		return Window2To;
	}
	public void setWindow2To(Date window2To) {
		Window2To = window2To;
	}
	public Date getWindow3From() {
		return Window3From;
	}
	public void setWindow3From(Date window3From) {
		Window3From = window3From;
	}
	public Date getWindow3To() {
		return Window3To;
	}
	public void setWindow3To(Date window3To) {
		Window3To = window3To;
	}
	@Override
	public String toString() {
		return "WindowTO [Window1From=" + Window1From + ", Window1To=" + Window1To + ", Window2From=" + Window2From
				+ ", Window2To=" + Window2To + ", Window3From=" + Window3From + ", Window3To=" + Window3To + "]";
	}
	
}
