package au.com.tollgroup.a2.sicli.util;

import java.util.Date;

/**
 * Utility methods for BSS Sicli.
 */
public class BSSSicliUtil {

	public static String mStringIf(boolean isDrop, String val1, String val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

	public static Date mDateIf(boolean isDrop, Date val1, Date val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

	public static Long mDateIfAsLong(boolean isDrop, Date val1, Date val2) {
		Date date = mDateIf(isDrop, val1, val2);
		if (date == null) {
			return null;
		} else {
			return date.getTime();
		}
	}

	public static Double mDoubleIf(boolean isDrop, Double val1, Double val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

	public static Integer mIntIf(boolean isDrop, Integer val1, Integer val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

	public static Long mLongIf(boolean isDrop, Long val1, Long val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

	public static Boolean mBoolIf(boolean isDrop, Boolean val1, Boolean val2) {
		if (isDrop) {
			return val1;
		} else {
			return val2;
		}
	}

}
