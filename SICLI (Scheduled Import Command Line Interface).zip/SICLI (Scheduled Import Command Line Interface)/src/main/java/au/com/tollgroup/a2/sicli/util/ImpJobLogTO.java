package au.com.tollgroup.a2.sicli.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;


import au.com.tollgroup.a2.sicli.model.ImpServiceEventTO;

import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * Log object for BSS.
 */
@XmlRootElement
public class ImpJobLogTO implements Serializable {

	private static final long serialVersionUID = 7973942655648262694L;
	private long errorCount;
	private long recentErrorCount;
	private List<ImpServiceEventTO> serviceEvents;
	private String lastError;
	private org.slf4j.Logger log ;
	private long failCount;
	private long processCount;

	public ImpJobLogTO(Logger log) {
		super();
		this.log = log;
		errorCount = 0;
		recentErrorCount = 0;		
		serviceEvents = new ArrayList<ImpServiceEventTO>();
		failCount=0;
		processCount=0;
	}

	/**
	 * Sets the ImpJobLogTO fields when error is being set. Error is stored in
	 * "lastError".
	 * 
	 * @param error
	 */
	public void addError(String error) {
		errorCount++;
		recentErrorCount++;
		ImpServiceEventTO svcEvent = new ImpServiceEventTO(0, error);
		serviceEvents.add(svcEvent);
		lastError = error;
		if (log != null) {
			log.error("ERROR! " + error);
		}
	}

	/**
	 * Retrieves the service event given the index.
	 * 
	 * @param index
	 * @return
	 */
	public ImpServiceEventTO getServiceEvent(int index) {
		if (serviceEvents.size() >= index) {
			return serviceEvents.get(index);
		}
		return null;
	}

	/**
	 * Adds a notice to the list of service events.
	 * 
	 * @param text
	 */
	public void addNotice(String text) {
		ImpServiceEventTO svcEvent = new ImpServiceEventTO(2, text);
		serviceEvents.add(svcEvent);
		if (log != null) {
			log.info("Notice: " + text);
		}
	}

	/**
	 * Adds a warning to the list of service events.
	 * 
	 * @param text
	 */
	public void addWarning(String text) {
		ImpServiceEventTO svcEvent = new ImpServiceEventTO(1, text);
		serviceEvents.add(svcEvent);
		if (log != null) {
			log.warn("Warning! " + text);
		}
	}

	/**
	 * Resets the recent error count.
	 */
	public void resetRecent() {
		recentErrorCount = 0;
	}

	public long getErrorCount() {
		return errorCount;
	}

	public long getEventCount() {
		if (serviceEvents == null) {
			return 0;
		}
		return serviceEvents.size();
	}

	public List<ImpServiceEventTO> getServiceEvents() {
		return serviceEvents;
	}

	public String getLastError() {
		return lastError;
	}

	public long getRecentErrorCount() {
		return recentErrorCount;
	}

	public void incrementFailCount() {
		failCount++;
	}

	public long getFailCount() {
		return failCount;
	}

	public void incrementProcessCount() {
		processCount++;
	}

	public long getProcessCount() {
		return processCount;
	}
}
