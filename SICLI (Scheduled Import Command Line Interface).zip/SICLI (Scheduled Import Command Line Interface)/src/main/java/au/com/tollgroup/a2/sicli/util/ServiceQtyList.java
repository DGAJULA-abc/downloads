package au.com.tollgroup.a2.sicli.util;

import java.io.Serializable;
import java.util.List;

import au.com.tollgroup.a2.sicli.model.ServiceTO;




public class ServiceQtyList implements Serializable {
	
	private Double[] qty;
	private String[] unit;
	
	public ServiceQtyList() {
		super();
		this.qty = new Double[8];
		this.unit = new String[8];
	}

	
	public ServiceTO writeToService(ServiceTO svc) {
		if (this.unit[0] == null || this.unit[0].isEmpty()) {
			svc.setUnit1(null);
			svc.setQty1(null);
		} else {
			svc.setUnit1(this.unit[0]);
			svc.setQty1(this.qty[0]);
		}
		if (this.unit[1] == null || this.unit[1].isEmpty()) {
			svc.setUnit2(null);
			svc.setQty2(null);
		} else {
			svc.setUnit2(this.unit[1]);
			svc.setQty2(this.qty[1]);
		}
		if (this.unit[2] == null || this.unit[2].isEmpty()) {
			svc.setUnit3(null);
			svc.setQty3(null);
		} else {
			svc.setUnit3(this.unit[2]);
			svc.setQty3(this.qty[2]);
		}
		if (this.unit[3] == null || this.unit[3].isEmpty()) {
			svc.setUnit4(null);
			svc.setQty4(null);
		} else {
			svc.setUnit4(this.unit[3]);
			svc.setQty4(this.qty[3]);
		}
		if (this.unit[4] == null || this.unit[4].isEmpty()) {
			svc.setUnit5(null);
			svc.setQty5(null);
		} else {
			svc.setUnit5(this.unit[4]);
			svc.setQty5(this.qty[4]);
		}
		if (this.unit[5] == null || this.unit[5].isEmpty()) {
			svc.setUnit6(null);
			svc.setQty6(null);
		} else {
			svc.setUnit6(this.unit[5]);
			svc.setQty6(this.qty[5]);
		}
		if (this.unit[6] == null || this.unit[6].isEmpty()) {
			svc.setUnit7(null);
			svc.setQty7(null);
		} else {
			svc.setUnit7(this.unit[6]);
			svc.setQty7(this.qty[6]);
		}
		if (this.unit[7] == null || this.unit[7].isEmpty()) {
			svc.setUnit8(null);
			svc.setQty8(null);
		} else {
			svc.setUnit8(this.unit[7]);
			svc.setQty8(this.qty[7]);
		}
		return svc;
	}

	
}
