package au.com.tollgroup.a2.sicli.util;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.tollgroup.a2.sicli.dao.SicliImportDAO2;
import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.ImpServiceTO;
import au.com.tollgroup.a2.sicli.model.ServiceTO;
import au.com.tollgroup.a2.sicli.util.constants.ApplicationConstants;


@Service
public class ServiceUtil {
	
	@Autowired
	private SicliImportDAO2 sicliImportDAO;
	
public static String createinsertQuery(String tablename, List<String> columnval) throws IOException { 
		
		String sql = "INSERT INTO "+ tablename + " (";
		StringBuilder queryBuilder = new StringBuilder();
		String query="";
		
		if(!Objects.isNull(columnval) && !columnval.isEmpty())
	     {
          queryBuilder.append("INSERT INTO ").append(tablename).append(" (");
	    	        for (int i = 0; i < columnval.size(); i++) {
	    	            queryBuilder.append(columnval.get(i));
	    	            if (i < columnval.size() - 1) {
	    	                queryBuilder.append(", ");
	    	            }
	    	        }            
	    	 
	    	 queryBuilder.append(") VALUES (");
		        for (int i = 0; i < columnval.size(); i++) {
		            queryBuilder.append("?");
		            if (i < columnval.size() - 1) {
		                queryBuilder.append(", ");
		            }
		        }
		        queryBuilder.append(")");
		        query = queryBuilder.toString();	
	     }		
		
		return query;
	}

  public static Timestamp convertDateToTimeStamp(java.util.Date date) {
	  
	 return new Timestamp(date.getTime());
	 
  }
  
 

}
