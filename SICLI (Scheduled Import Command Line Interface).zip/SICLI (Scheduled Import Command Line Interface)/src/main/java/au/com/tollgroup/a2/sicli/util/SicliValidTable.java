package au.com.tollgroup.a2.sicli.util;

public enum SicliValidTable {

	COMPANY, CONTAINER_TYPE, LOAD_TYPE, LOCATION, LOCATION_TYPE, MAPSOURCE, ROUTE, TRAILER, TRUCK, UNIT, ZONE_CHARGE, ZONE_PAY;

}
