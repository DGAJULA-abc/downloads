package au.com.tollgroup.a2.sicli.util;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;


import au.com.tollgroup.a2.sicli.dao.*;
import au.com.tollgroup.a2.sicli.util.constants.ApplicationConstants;

/**
 * Provides utility functions to manipulate dates and times with timezones.
 * @author mahilalh
 *
 */
public class TimeUtil {

	private static Logger log = Logger.getLogger(TimeUtil.class);

	public static final int AXIOM_DESPATCH_DATE_YEAR = 2099;
	public static final int AXIOM_DESPATCH_DATE_MONTH = 12;
	public static final int AXIOM_DESPATCH_DATE_DAY = 30;

	/**
	 * Gets a time stamp for yesterday for the specified time zone.
	 * 
	 * @param timeZone - the time zone to get yesterdays date in.
	 **/
	public static Timestamp getYesterdaysTimestamp(String timeZone) {

		if (timeZone == null) {
			return null;
		}

		// Get the current date & time in timeZone
		DateTime dateTime = getCurrentDateTime(timeZone);

		// Go back one day
		dateTime = dateTime.plusDays(-1);

		return new Timestamp(dateTime.toDate().getTime());
	}

	/**
	 * Gets the current date and time in the specified time zone.
	 * 
	 * @param timeZone - the time zone to get the current date and time in
	 **/
	public static DateTime getCurrentDateTime(String timeZone) {

		DateTime dateTime = new DateTime();

		dateTime = dateTime.toDateTime(
				DateTimeZone.forTimeZone(
						TimeZone.getTimeZone(timeZone)))
						.withZoneRetainFields(
								DateTimeZone.forTimeZone(
										TimeZone.getTimeZone(timeZone)));
		return dateTime;
	}

	/**
	 * Gets the current date and time in the specified time zone.
	 * 
	 * @param timeZone - the time zone to get the current date and time in
	 **/
	public static Date getCurrentDateTimeInTimeZone(String toTimeZone) {

		// Get the current date & time in timeZone
		DateTime dateTime = getCurrentDateTime(toTimeZone);
		Date date = convertDateTo(
				dateTime.toDate(), ApplicationConstants.DEFAULT_TIMEZONE_UTC, toTimeZone);
		return date;
	}

	/**
	 * Gets the current time stamp in the specified time zone (without milliseconds).
	 * E.g. 2016-10-24 14:22:45.0
	 * 
	 * @param timeZone - the time zone to get the current time stamp in
	 **/
	public static Timestamp getCurrentTimestampInTimeZone(String toTimeZone) {

		// Get the current date & time in timeZone
		DateTime dateTime = getCurrentDateTime(toTimeZone);
		Date date = convertDateTo(
				dateTime.toDate(), ApplicationConstants.DEFAULT_TIMEZONE_UTC, toTimeZone);

		// Set milliseconds to 0 or Oracle DB will reject a timestamp with milliseconds
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.set(Calendar.MILLISECOND, 0);

		return new Timestamp(c.getTime().getTime());
	}

	/**
	 * Converts the given date in the fromTimeZone to toTimeZone
	 *
	 * @param date
	 * @param fromTimeZone
	 * @param toTimeZone
	 * @return
	 */
	public static Date convertDateTo(Date date,
			String fromTimeZone,
			String toTimeZone) {

		if (date == null || fromTimeZone == null || toTimeZone == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date
						+ "',fromTimeZone:'"
						+ fromTimeZone
						+ "',toTimeZone:'" + toTimeZone + "']");
			}
			return date;
		}

		// // Instantiate a new DateTime with the given date
		// DateTime dt = new DateTime(date);
		//
		// // Change the time zone of the DateTime to the from time zone without
		// // chaging the actual time value
		// DateTime sourceDt = dt.withZoneRetainFields(DateTimeZone
		// .forID(fromTimeZone));
		//
		// // Convert the time value to match to the target timezone. This will
		// // change the time zone
		// Date out =
		// sourceDt.withZone(DateTimeZone.forID(toTimeZone)).toDate();

		// Instantiate a new DateTime with the given date
		DateTime dt = new DateTime(date);

		// Change the time zone of the DateTime to the from time zone without
		// changing the actual time value, and convert the time value to match
		// the target time zone.
		DateTime ndt = dt.toDateTime(
				DateTimeZone.forTimeZone(TimeZone.getTimeZone(toTimeZone)))
				.withZoneRetainFields(
						DateTimeZone.forTimeZone(TimeZone
								.getTimeZone(fromTimeZone)));
		return ndt.toDate();
	}

	/**
	 * Converts the given date to Axiom time
	 *
	 * @param date
	 * @param localTimeZone
	 * @return
	 */
	public static Date convertToAxiomDate(Date date, Long siteId) {
		if (date == null || siteId == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date + "',siteid:'" + siteId + "']");
			}
			return null;
		}
		return convertDateTo(date, ApplicationConstants.DEFAULT_TIMEZONE_UTC,
				ApplicationOptionsDAO.getTimeZone(siteId));
	}

	/**
	 * Converts the given date to RIMS time (Australia/Melbourne)
	 *
	 * @param date
	 * @return
	 */
	public static Date convertToRIMSDate(Date date) {
		if (date == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date + "']");
			}
			return null;
		}
		return convertDateTo(date, ApplicationConstants.DEFAULT_TIMEZONE_UTC,
				ApplicationConstants.DEFAULT_RIMS_TIMEZONE);
	}

	/**
	 * Converts the given date to Axiom db time stamp
	 *
	 * @param date
	 * @param localTimeZone
	 * @return
	 */
	public static Timestamp convertToAxiomTimestamp(Date date, Long siteId) {
		if (date == null || siteId == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date + "',siteid:'" + siteId + "']");
			}
			return null;
		}
		return new Timestamp(convertDateTo(date,
				ApplicationConstants.DEFAULT_TIMEZONE_UTC,
				ApplicationOptionsDAO.getTimeZone(siteId)).getTime());
	}

	/**
	 * Converts the given date to Axiom time
	 *
	 * @param date
	 * @param localTimeZone
	 * @return
	 */
	public static DateTime convertToAxiomDateTime(Date date, Long siteId) {
		if (date == null || siteId == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date + "',siteid:'" + siteId + "']");
			}
			return null;
		}
		DateTime dt = new DateTime(date);
		DateTime ndt = dt
				.toDateTime(
						DateTimeZone.forTimeZone(TimeZone
								.getTimeZone(ApplicationOptionsDAO
										.getTimeZone(siteId))))
										.withZoneRetainFields(
												DateTimeZone.forTimeZone(TimeZone
														.getTimeZone(ApplicationConstants.DEFAULT_TIMEZONE_UTC)));
		return ndt;
	}

	/**
	 * Converts the given date to Axiom time
	 *
	 * @param date
	 * @param localTimeZone
	 * @return
	 */
	public static Date convertFromAxiomDate(Date date, Long siteId) {
		if (date == null || siteId == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because one or more parameters are null [date:'"
						+ date + "',siteId:'" + siteId + "']");
			}
			return null;
		}
		return convertDateTo(date, ApplicationOptionsDAO.getTimeZone(siteId),
				ApplicationConstants.DEFAULT_TIMEZONE_UTC);

	}

	/**
	 * Get the midnight date based on the default timezone.
	 * @param date
	 * @return
	 */
	public static Date resetToMidnight(Date date) {

		return resetToMidnight(date, null);

	}

	/**
	 * Get the midnight date based on the given timezone.
	 * @param date
	 * @param timezone
	 * @return
	 */
	public static Date resetToMidnight(Date date, String timezone) {

		if (date == null) {
			if (log.isDebugEnabled()) {
				log.debug("Unable to convert date because date is null");
			}
			return date;
		}

		DateTime dt;
		if (timezone != null) {
			Date localCurrDate = TimeUtil.convertDateTo(date,
					ApplicationConstants.DEFAULT_TIMEZONE_UTC, timezone);
			dt = new DateTime(localCurrDate);
			dt = dt.withZoneRetainFields(DateTimeZone.forTimeZone(TimeZone
					.getTimeZone(timezone)));
		} else {
			dt = new DateTime(date);
		}
		return dt.withTimeAtStartOfDay().toDate();
	}

	/**
	 * @param date
	 * @param siteId
	 * @return
	 */
	public static Date resetToMidnight(Date date, long siteId) {

		String timezone = ApplicationOptionsDAO.getTimeZone(siteId);
		return resetToMidnight(date, timezone);
	}

	/**
	 * Forms an SQL timestamp object given a long value, which is expected to be
	 * milliseconds within a day.
	 *
	 * @param value milliseconds within a day
	 * @return SQL timestamp value
	 */
	public static Timestamp formTimeStamp(Long value) {
		if (value == null) {
			return null;
		}
		// a day in milliseconds
		if (value.longValue() >= 86400000) {
			// should we throw an exception?
			throw new RuntimeException("Invalid window time provided");
		}
		Timestamp ts = new Timestamp(value);
		return ts;
	}

	/**
	 * Gets the difference of 2 dates in hours (as double). When start date is
	 * greater than end date, then end date will be treated as if it crossed
	 * midnight, and a day will be added to it.
	 * 
	 * @param start
	 * @param end
	 * @return
	 */
	public static double getRunsheetDurationInHours(Date start, Date end) {
		if (start == null || end == null) {
			return 0;
		}
		long startTime = start.getTime();
		long endTime = end.getTime();
		if (startTime > endTime) {
			// add 1 day as it crossed
			endTime = endTime + 86400000;
		}
		long duration = endTime - startTime;
		return duration / 3600000.0;
	}

	/**
	 * Returns the day number of the week for the specified date.
	 * 
	 * @return Calendar.SUNDAY = 1 to Calendar.SATURDAY = 7
	 **/
	public static int getDayOfWeek(Date aDate) {

		if (aDate == null) {
			throw new RuntimeException("Null parameter is not allowed: aDate");
		}

		Calendar c = Calendar.getInstance();
		c.setTime(aDate);

		return c.get(Calendar.DAY_OF_WEEK);
	}

	/**
	 * Sets the time component of <code>targetDt</code> using the 
	 * time from <code>sourceDt</code>
	 * 
	 * @return a date with an updated time component
	 **/
	public static Date copyTimeToDate(Date targetDt, Date sourceDt) {

		if (targetDt == null || sourceDt == null) {
			throw new RuntimeException("Null parameter is not allowed: targetDt or sourceDt");
		}

		Calendar cSource = Calendar.getInstance();
		cSource.setTime(sourceDt);

		Calendar cTarget = Calendar.getInstance();
		cTarget.setTime(targetDt);

		cTarget.set(Calendar.HOUR_OF_DAY, cSource.get(Calendar.HOUR_OF_DAY));
		cTarget.set(Calendar.MINUTE, cSource.get(Calendar.MINUTE));
		cTarget.set(Calendar.SECOND, cSource.get(Calendar.SECOND));
		cTarget.set(Calendar.MILLISECOND, cSource.get(Calendar.MILLISECOND));

		return cTarget.getTime();
	}

	/**
	 * Sets the time component of <code>targetDt</code> using the specified hour and minute
	 * 
	 * @return a date with an updated time component
	 **/
	public static Date updateHoursAndMinutes(Date targetDt, int hourOfDay, int minuteOfHour) {

		if (targetDt == null) {
			throw new RuntimeException("Null parameter is not allowed: targetDt");
		}

		Calendar cTarget = Calendar.getInstance();
		cTarget.setTime(targetDt);

		cTarget.set(Calendar.HOUR_OF_DAY, hourOfDay);
		cTarget.set(Calendar.MINUTE, minuteOfHour);
		cTarget.set(Calendar.SECOND, 0);
		cTarget.set(Calendar.MILLISECOND, 0);

		return cTarget.getTime();
	}

	/**
	 * Adds hours and minutes to the specified date.
	 * 
	 * @return a date with hours added to it
	 **/
	public static Date addHoursAndMinutes(Date targetDt, int numberOfHours, int numberOfMinutes) {

		if (targetDt == null) {
			throw new RuntimeException("Null parameter is not allowed: targetDt");
		}

		Calendar cTarget = Calendar.getInstance();
		cTarget.setTime(targetDt);

		cTarget.add(Calendar.HOUR_OF_DAY, numberOfHours);
		cTarget.add(Calendar.MINUTE, numberOfMinutes);

		return cTarget.getTime();
	}

	/**
	 * Calculates the date from today given the site id, years from today,
	 * months from today, and days from today.
	 * 
	 * @param siteId
	 *            if null, date will be treated as UTC
	 * @param years
	 *            optional
	 * @param months
	 *            optional
	 * @param days
	 *            optional
	 * @return
	 */
	public static Date getDateFromToday(Long siteId, Integer years, Integer months, Integer days) {
		Date date = new Date();
		if (siteId == null) {
			date = resetToMidnight(date);	
		} else {
			date = resetToMidnight(date, siteId);
		}

		Calendar cTarget = addDateTime(years, months, days, date);
		return cTarget.getTime();
	}

	/**
	 * Adds date to the specified date
	 * 
	 * @param date
	 * @param years
	 * @param months
	 * @param days
	 * @return
	 */
	public static Date addToDate(Date date, Integer years, Integer months, Integer days) {
	
		Calendar cTarget = addDateTime(years, months, days, date);
		return cTarget.getTime();
	}
	
	/**
	 * Adds date the specified date years months and/or days to the specified date.
	 * 
	 * @param years
	 * @param months
	 * @param days
	 * @param date
	 * @return
	 */
	private static Calendar addDateTime(Integer years, Integer months, Integer days, Date date) {
		
		Calendar cTarget = Calendar.getInstance();
		cTarget.setTime(date);
		
		if (years != null) {
			cTarget.add(Calendar.YEAR, years);
		}
		if (months != null) {
			cTarget.add(Calendar.MONTH, months);
		}
		if (days != null) {
			cTarget.add(Calendar.DATE, days);
		}
		return cTarget;
	}
	
	/**
	 * Gets the current date time local to the siteTimeZone and resets to midnight
	 * @param siteTimeZone
	 * @return
	 */
	public static Date getLocalSiteDateTimeAtMidnight(String siteTimeZone) {
		
		if (siteTimeZone == null) {
			return null;
		}
		
		Date siteLocalDateTime = TimeUtil
				.convertDateTo(new Date(),
						ApplicationConstants.DEFAULT_TIMEZONE_UTC, siteTimeZone);
		// Reset to midnight
		Date siteLocalDateTimeMidnight = TimeUtil
				.resetToMidnight(siteLocalDateTime);
		
		return siteLocalDateTimeMidnight;
	}
}
