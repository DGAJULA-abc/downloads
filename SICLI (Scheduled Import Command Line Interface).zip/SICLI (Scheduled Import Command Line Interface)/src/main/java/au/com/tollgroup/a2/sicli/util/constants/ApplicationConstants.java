package au.com.tollgroup.a2.sicli.util.constants;

import java.util.Arrays;
import java.util.List;

/**
 * Defines all the constants for application level
 */
public class ApplicationConstants {
	/*********************************/
	/*** Application Configuration ***/
	/*********************************/

	public static final String APP_API_COOKIE_SESSION_ID_NAME = "JSESSIONID";
	
	/**
	 * allocation size of hibernate sequence. Used as there is unexpected
	 * behaviour of hibernate when using sequences. See
	 * https://forum.hibernate.org/viewtopic.php?p=2423054
	 */
	public static final int HIBERNATE_ALLOCATION_SIZE = 1;
	public static final String DEFAULT_TIMEZONE_UTC = "UTC";
	public static final String DEFAULT_RIMS_TIMEZONE = "UTC";
	public static final String DEFAULT_UNIBIS_INTERFACE_TIMEZONE = "Australia/Melbourne";
	// standard values for true or false values in the DB
	public static final int DB_TRUE_FLAG = -1;
	public static final int DB_FALSE_FLAG = 0;
	// standard values for true or false values in stored procedure
	public static final String SP_TRUE_FLAG = "Y";
	public static final String SP_FALSE_FLAG = "N";

	public static final String SYSTEM_SETTINGS_TRUE = "true";
	public static final String SYSTEM_SETTINGS_FALSE = "false";

	// System id that will be set to DATASOURCEID when required, if not set by
	// the UI
	public static final String DATA_SOURCE_A2 = "A2";
	public static final String DATA_SOURCE_EA = "EA";
	public static final String DATA_SOURCE_AM = "AM";
	public static final String DATA_SOURCE_M = "M";
	public static final String A2_SHIFT_ENTRY_DATA_SOURCE = "SE";
	public static final String DATA_SOURCE_RIMS = "RIMS2";

	public static final List<String> EXECUTION_EVENTS_MODIFICATION_ALLOWED_SOURCES = Arrays
			.asList(DATA_SOURCE_A2, DATA_SOURCE_EA, DATA_SOURCE_AM);

	public static final int SEARCH_API_CSV_EXPORT_MAX_RECORD_LIMIT = 5000;

	public static final int RIMS_SEARCH_API_CSV_EXPORT_MAX_RECORD_LIMIT = 5000;

	// In order to login to Axiom Master, you need to have an entry in USERDATA
	// for siteid=0.
	public static final long AXIOM_MASTER_SITEID = 0;

	// Bulk copy - max copy limit
	public static final int BULK_COPY_MAX_LIMIT = 200;
	// A1 client server local timezone. this is needed for server specific
	// dates used in things like EVENT_LOG table entries.
	public static final String SERVER_TIMEZONE = "Australia/Melbourne";

	/* Default for the System Id used in UTYHOME.RECIPIENT */
	public static final String UTYHOME_RECIPIENT_DEFAULT_SYSTEM_ID = "Axiom";
	public static final String UTYHOME_RECIPIENT_TYPE_EMAIL = "EMAIL";
	public static final String UTYHOME_RECIPIENT_TYPE_SMS = "SMS";
	public static final String UTYHOME_RECIPIENT_TYPE_MDTMC = "MDTMC";

	public static final String UTYHOME_ACTION_CLOSEOFF_SUBMIT = "Close Off Submitted";
	public static final String UTYHOME_GROUP_CLOSEOFF_AUTOMATION = "Close Off Automation";
	/* NB: Due to Oracle limitation, maximum value of kServiceBatchCount is 1000 */
	public static final int CLOSE_OFF_BATCH_SIZE = 500;
	public static final String USER_OPTION_DEFAULT_CUSTOMER_ID = "DefaultCustomerId";
	public static final String SITE_OPTION_CLOSE_OFF = "CloseOff";

	// Default first day of week is Sunday, 1
	public static final int DEFAULT_FIRST_DAY_OF_WEEK = 1;

	//Email settings
	public static final String EMAIL_USER_SUFFIX = "@tollgroup.com";
	public static final String EMAIL_SMTP_HOST = "smtp.toll.com.au";
	public static final String EMAIL_FROM_ADDRESS = "axiomd@toll.com.au";
	public static final String EMAIL_FROM_PERSONAL = "Axiom";

	/********************/
	/*** User Options ***/
	/********************/
	// predefined usernames
	public static final String USER_OPT_DEV_USER = "dev";

	// predefined option names
	public static final String USER_OPT_SERVICE_CONSOL_DONT_MATCH_DATES = "ServiceConsol.DontMatchDates";
	public static final String USER_OPT_SERVICE_CONSOL_DONT_MATCH_TYPES = "ServiceConsol.DontMatchTypes";

	// predefined option names that lookup only dev user
	public static final String USER_OPT_RUNSHEET_RESTRICTION = "Runsheet.Restriction";
	public static final String USER_OPT_FIRST_DAY_OF_WEEK = "FirstDayOfWeek";
	public static final String USER_OPT_DRIVER_NAME_FORMAT = "DriverNameFormat";
	public static final String USER_OPT_MANUAL_RUNSHEET_COMPLETION = "ManualRunsheetCompletion";
	public static final String USER_OPT_AXIOM_COMPLETION_DISABLED = "Axiom.CompletionDisabled";
	public static final String USER_OPT_ROUTING_UNIT = "RoutingUnit";
	public static final String USER_OPT_AUTO_FILL_RUNSHEETS = "AutoFillRunsheets";
	public static final String USER_OPT_ORDER_TRIP_BY_DESPATCH = "OrderTripByDespatch";
	public static final String USER_OPT_ALLOCATION_BY_ROUTE_GROUP_BY_LOAD_NO = "AllocationbyRoute.GroupByLoadNo";
	public static final String USER_OPT_SERVICE_CONSOL_DONT_MATCH_LOCS = "ServiceConsol.DontMatchLocs";
	public static final String USER_OPT_DONT_RELEASE_WITH_REASON = "DontReleaseWithReason";
	public static final String USER_OPT_REQ_RUNSHEET_KM = "ReqRunsheetKm";
	public static final String USER_OPT_R_S_L_DUP_LOCS = "RSL.Dup.Locs";
	public static final String USER_OPT_R_S_L_DUP_TIMES = "RSL.Dup.Times";
	public static final String USER_OPT_R_S_L_DUP_LOADS = "RSL.Dup.Loads";
	public static final String USER_OPT_IGNORE_DEFAULT_TRUCK_TRAILER = "IgnoreDefaultTruckTrailer";
	public static final String USER_OPT_TRUCK_TRAILER_I_D = "TruckTrailerID";
	public static final String USER_OPT_MULTIPLE_REASON_CODES = "MultipleReasonCodes";
	public static final String USER_OPT_VOLUME_CONVERSION = "VolumeConversion";
	public static final String USER_OPT_SINGLE_UNLOAD_PER_SERVICE = "SingleUnloadPerService";
	public static final String USER_OPT_TRIP_PRICING = "TripPricing";
	public static final String USER_OPT_TRIP_PRICING_SLOW = "TripPricingSlow";
	public static final String USER_OPT_TRIP_CHARGE_DEFAULT_SERVICE = "TripChargeDefaultService";
	public static final String USER_OPT_TRIP_CHARGE_ALL_MUST_MATCH = "TripChargeAllMustMatch";
	public static final String USER_OPT_PICKLIST_SERVICE_HISTORY_MONTHS = "Picklist.Service.HistoryMonths";
	public static final String USER_OPT_PICKLIST_LOAD_HISTORY_MONTHS = "Picklist.Load.HistoryMonths";
	public static final String USER_OPT_PICKLIST_RUNSHEET_HISTORY_MONTHS = "Picklist.Runsheet.HistoryMonths";
	public static final String USER_OPT_ALLOCATION_BY_ROUTE_EVENT_CHECK_SEQUENCE = "AllocationByRoute.Event.CheckSequence";
	public static final String USER_OPT_S_D_P_DESPATCH_DELAY = "SDP.Despatch.Delay";
	public static final String USER_OPT_S_D_P_DESPATCH_ROUNDING = "SDP.Despatch.Rounding";
	public static final String USER_OPT_REFERENCE_LOCATION_ADD_TO_LIST = "Reference.Location.AddToList";
	public static final String USER_OPT_FUEL_LEVY_DISABLE_OLD_CUSTOMER_LEVY = "FuelLevy.DisableOldCustomerLevy";
	public static final String USER_OPT_FUEL_LEVY_HOURLY_APPLY = "FuelLevy.Hourly.Apply";
	public static final String USER_OPT_FUEL_LEVY_HOURLY_APPLY_CONTRACTOR = "FuelLevy.Hourly.Apply.Contractor";
	public static final String USER_OPT_FUEL_LEVY_HOURLY_APPLY_AGENCY = "FuelLevy.Hourly.Apply.Agency";
	public static final String USER_OPT_FUEL_LEVY_HOURLY_APPLY_TOLL = "FuelLevy.Hourly.Apply.Toll";
	public static final String USER_OPT_RETURNS_CONTAINER_NO_LINE_DATA = "Returns.Container.NoLineData";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_PICKUP_ARRIVE = "MD.LineTimeMap.PickupArrive";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_PICKUP_DOCK = "MD.LineTimeMap.PickupDock";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_PICKUP_READY = "MD.LineTimeMap.PickupReady";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_PICKUP_DEPART = "MD.LineTimeMap.PickupDepart";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_DROP_ARRIVE = "MD.LineTimeMap.DropArrive";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_DROP_DOCK = "MD.LineTimeMap.DropDock";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_DROP_READY = "MD.LineTimeMap.DropReady";
	public static final String USER_OPT_M_D_LINE_TIME_MAP_DROP_DEPART = "MD.LineTimeMap.DropDepart";
	public static final String USER_OPT_TRIP_DONT_APPLY_DATE_TO_SERVICES = "Trip.DontApplyDateToServices";
	public static final String USER_OPT_M_D_RELOCATION_TYPE = "MD.RelocationType";
	public static final String USER_OPT_FINISH_SERVICE_TYPE = "Finish.ServiceType";
	public static final String USER_OPT_ADJUSTMENT_DONT_GUESS_PAY = "Adjustment.DontGuess.Pay";
	public static final String USER_OPT_RATE_DROP_PAY_BONUS = "Rate.DropPayBonus";
	public static final String USER_OPT_RATE_DROP_PAY_BONUS_THRESHOLD = "Rate.DropPayBonus.Threshold";
	public static final String USER_OPT_RATE_DROP_PAY_BONUS_AMOUNT = "Rate.DropPayBonus.Amount";
	public static final String USER_OPT_RATE_DROP_PAY_BONUS_LIMIT_COMPANY_TYPE = "Rate.DropPayBonus.LimitCompanyType";
	public static final String USER_OPT_S_D_P_WARNING_FOR_KM = "SDPWarningForKm";
	public static final String USER_OPT_RETURN_SERVICE_TYPE = "Return.ServiceType";
	public static final String USER_OPT_RETURN_LOAD_TYPE = "Return.LoadType";
	public static final String USER_OPT_ALLOCATION_BY_ROUTE_MIN_REST_PERIOD = "AllocationByRoute.MinRestPeriod";
	public static final String USER_OPT_RUNSHEET_MAX_KM_ALLOWED = "Runsheet.MaxKMAllowed";
	public static final String USER_OPT_ALLOCATION_SCHEDULE_LOCK = "Allocation.ScheduleLock";
	public static final String USER_OPT_IMPORT_USE_DELIVERY_WINDOW = "Import.UseDeliveryWindow";
	public static final String USER_OPT_EXPORT_G_L_CODE = "Export.GLCode";
	public static final String USER_OPT_ALLOC_BY_ROUTE_ALLOW_NEW_LOAD_ON_SPLIT = "AllocByRoute.AllowNewLoadOnSplit";
	public static final String USER_OPT_ALLOC_BY_ROUTE_TRIP_COMP_TRAILER = "AllocByRoute.TripCompTrailer";
	public static final String USER_OPT_ALLOC_BY_ROUTE_TRIP_COMP_DOCK = "AllocByRoute.TripCompDock";
	public static final String USER_OPT_DEFAULT_STICKUP_SERVICE_TYPE = "Default.StickupServiceType";
	public static final String USER_OPT_EVENTS_TRIP_REQUIRE_TRAILER = "Events.Trip.RequireTrailer";
	public static final String USER_OPT_EVENTS_TRIP_REQUIRE_DOCK = "Events.Trip.RequireDock";
	public static final String USER_OPT_RUNSHEET_2_RECYCLE_LOAD_NUMBER_DEFAULT = "Runsheet2.RecycleLoadNumberDefault";
	public static final String USER_OPT_PAY_ADVICE_PAYER_ADDRESS = "PayAdvice.PayerAddress";
	public static final String USER_OPT_PAY_ADVICE_PAYING_SITE_DETAILS = "PayAdvice.PayingSiteDetails";
	public static final String USER_OPT_SUBURB_CHARGE_ZONE = "SuburbChargeZone";
	public static final String USER_OPT_ALLOCATION_REQUEST_DRIVER_SHIFT_START = "Allocation.RequestDriverShift.Start";
	public static final String USER_OPT_ALLOCATION_REQUEST_DRIVER_SHIFT_END = "Allocation.RequestDriverShift.End";
	public static final String USER_OPT_ALLOCATION_BY_ROUTE_HISTORICAL_LOCKDOWN_DAYS = "AllocationByRoute.HistoricalLockdownDays";
	public static final String USER_OPT_MENU_TITLE = "MenuTitle";
	public static final String USER_OPT_LABEL_BATCH_NO = "LabelBatchNo";
	public static final String USER_OPT_LABEL_CUST_REFERENCE = "LabelCustReference";
	public static final String USER_OPT_LABEL_DELIVERY_OPEN = "LabelDeliveryOpen";
	public static final String USER_OPT_LABEL_DELIVERY_CLOSE = "LabelDeliveryClose";
	public static final String USER_OPT_HOME_STATE = "HomeState";
	public static final String USER_OPT_DEFAULT_LOAD_TYPE = "DefaultLoadType";
	public static final String USER_OPT_DEFAULT_SERVICE_TYPE = "DefaultServiceType";
	public static final String USER_OPT_DEFAULT_RUNSHEET_TYPE = "DefaultRunsheetType";
	public static final String USER_OPT_DEFAULT_CUSTOMER_ID = "DefaultCustomerId";
	public static final String USER_OPT_HOME_LOCATION = "HomeLocation";
	public static final String USER_OPT_KM_LIMIT = "KmLimit";
	public static final String USER_OPT_WINDOW_TOLERANCE = "WindowTolerance";
	public static final String USER_OPT_MIN_PURGE_AGE = "MinPurgeAge";
	public static final String USER_OPT_COPY_SERVICE_DATA = "CopyServiceData";
	public static final String USER_OPT_FORWARD_ENTRY_DAYS = "ForwardEntryDays";
	public static final String USER_OPT_BACK_ENTRY_DAYS = "BackEntryDays";
	public static final String USER_OPT_ALLOW_NO_RUNSHEET = "AllowNoRunsheet";
	public static final String USER_OPT_MANUAL_SERVICE_COMPLETION = "ManualServiceCompletion";
	public static final String USER_OPT_ALLOW_ZERO_CHARGE_AMT = "AllowZeroChargeAmt";
	public static final String USER_OPT_ALLOW_ZERO_PAY_AMT = "AllowZeroPayAmt";
	public static final String USER_OPT_EDIT_CHARGE_RATE = "EditChargeRate";
	public static final String USER_OPT_EDIT_CHARGE_AMT = "EditChargeAmt";
	public static final String USER_OPT_EDIT_PAY_RATE = "EditPayRate";
	public static final String USER_OPT_EDIT_PAY_AMT = "EditPayAmt";
	public static final String USER_OPT_EDIT_UNALLOC_INVOICE_LINES = "EditUnallocInvoiceLines";
	public static final String USER_OPT_EDIT_UNALLOC_PAY_ADVICE_LINES = "EditUnallocPayAdviceLines";
	public static final String USER_OPT_EDIT_SERVICE_LOAD = "EditServiceLoad";
	public static final String USER_OPT_PREVENT_ORPHAN_LOADS = "PreventOrphanLoads";
	public static final String USER_OPT_CONTAINER_ADD_TO_LIST = "ContainerAddToList";
	public static final String USER_OPT_RUNSHEET_ADD_BY_LOAD = "RunsheetAddByLoad";
	public static final String USER_OPT_UPDATE_TRUCK_BY_LOAD = "UpdateTruckByLoad";
	public static final String USER_OPT_PRE_ALLOCATE_SERVICES = "PreAllocateServices";
	public static final String USER_OPT_SINGLE_RUNSHEET_PER_DRIVER = "SingleRunsheetPerDriver";
	public static final String USER_OPT_PREVENT_SPLIT_LOADS = "PreventSplitLoads";
	public static final String USER_OPT_COPY_LOAD_ID_ON_RUNSHEET = "CopyLoadIdOnRunsheet";
	public static final String USER_OPT_VALIDATE_ADJ_SVC_VS_EXPORT = "ValidateAdjSvcVsExport";
	public static final String USER_OPT_REFERENCE_INTERFACE = "ReferenceInterface";
	public static final String USER_OPT_SCHEDULE_IMPORT_FOLDER = "ScheduleImportFolder";
	public static final String USER_OPT_DEFAULT_EXPORT_FOLDER = "DefaultExportFolder";
	public static final String USER_OPT_EXTERNAL_REPORTS_U_R_L = "ExternalReportsURL";
	public static final String USER_OPT_SUPPORT_U_R_L = "SupportURL";
	public static final String USER_OPT_DRIVER_ALLOC_FORMAT = "DriverAllocFormat";
	public static final String USER_OPT_DRIVER_ALLOC_BY_USER = "DriverAllocByUser";
	public static final String USER_OPT_EDIT_DOCKET_AS_TIMESLOT = "EditDocketAsTimeslot";
	public static final String USER_OPT_DEFAULT_INV_FORMAT = "DefaultInvFormat";
	public static final String USER_OPT_DEFAULT_C_N_FORMAT = "DefaultCNFormat";
	public static final String USER_OPT_RUNSHEET_FORMAT = "RunsheetFormat";
	public static final String USER_OPT_INVOICE_TEXT = "InvoiceText";
	public static final String USER_OPT_PAYMENT_ADDRESS = "PaymentAddress";
	public static final String USER_OPT_COVER_SHEET_TEXT = "CoverSheetText";
	public static final String USER_OPT_SHOW_ZERO_VALUES = "ShowZeroValues";
	public static final String USER_OPT_INVOICE_UNIT_1 = "InvoiceUnit1";
	public static final String USER_OPT_INVOICE_UNIT_2 = "InvoiceUnit2";
	public static final String USER_OPT_INVOICE_UNIT_3 = "InvoiceUnit3";
	public static final String USER_OPT_INVOICE_UNIT_4 = "InvoiceUnit4";
	public static final String USER_OPT_INVOICE_UNIT_5 = "InvoiceUnit5";
	public static final String USER_OPT_INVOICE_UNIT_6 = "InvoiceUnit6";
	public static final String USER_OPT_INVOICE_UNIT_7 = "InvoiceUnit7";
	public static final String USER_OPT_INVOICE_UNIT_8 = "InvoiceUnit8";
	public static final String USER_OPT_PAY_ADVICE_UNIT_1 = "PayAdviceUnit1";
	public static final String USER_OPT_PAY_ADVICE_UNIT_2 = "PayAdviceUnit2";
	public static final String USER_OPT_PAY_ADVICE_UNIT_3 = "PayAdviceUnit3";
	public static final String USER_OPT_PAY_ADVICE_UNIT_4 = "PayAdviceUnit4";
	public static final String USER_OPT_PAY_ADVICE_UNIT_5 = "PayAdviceUnit5";
	public static final String USER_OPT_PAY_ADVICE_UNIT_6 = "PayAdviceUnit6";
	public static final String USER_OPT_PAY_ADVICE_UNIT_7 = "PayAdviceUnit7";
	public static final String USER_OPT_PAY_ADVICE_UNIT_8 = "PayAdviceUnit8";
	public static final String USER_OPT_TRACKING_UNIT_1_OUT = "TrackingUnit1Out";
	public static final String USER_OPT_TRACKING_UNIT_2_OUT = "TrackingUnit2Out";
	public static final String USER_OPT_TRACKING_UNIT_3_OUT = "TrackingUnit3Out";
	public static final String USER_OPT_TRACKING_UNIT_4_OUT = "TrackingUnit4Out";
	public static final String USER_OPT_TRACKING_UNIT_1_IN = "TrackingUnit1In";
	public static final String USER_OPT_TRACKING_UNIT_2_IN = "TrackingUnit2In";
	public static final String USER_OPT_TRACKING_UNIT_3_IN = "TrackingUnit3In";
	public static final String USER_OPT_TRACKING_UNIT_4_IN = "TrackingUnit4In";
	public static final String USER_OPT_RUNSHEET_UNIT_1 = "RunsheetUnit1";
	public static final String USER_OPT_RUNSHEET_UNIT_2 = "RunsheetUnit2";
	public static final String USER_OPT_RUNSHEET_UNIT_3 = "RunsheetUnit3";
	public static final String USER_OPT_RUNSHEET_UNIT_4 = "RunsheetUnit4";
	public static final String USER_OPT_ON_TIME_RPT_UNIT_1 = "OnTimeRptUnit1";
	public static final String USER_OPT_ON_TIME_RPT_UNIT_2 = "OnTimeRptUnit2";
	public static final String USER_OPT_LOADING_RPT_UNIT_1 = "LoadingRptUnit1";
	public static final String USER_OPT_LOADING_RPT_UNIT_2 = "LoadingRptUnit2";
	public static final String USER_OPT_RUNSHEET_NEW_LINE_AS_TRIP = "Runsheet.NewLineAsTrip";
	public static final String USER_OPT_SHIFT_SUGGESTION_ORDER = "Shift.SuggestionOrder";
	public static final String USER_OPT_COMPLETION_R_M_M_VALIDATION = "Completion.RMMValidation";
	public static final String USER_OPT_AMCOR_DUPLICATE_CHECK = "Amcor.DuplicateCheck";
	public static final String USER_OPT_SERVICES_COPY_TO_CONSIGNMENT = "Services.CopyToConsignment";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_SERVICES = "MD.LoadRequest.MatchServices";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_LOADS = "MD.LoadRequest.MatchLoads";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_TRIPS = "MD.LoadRequest.MatchTrips";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_BATCH = "MD.LoadRequest.MatchBatch";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_CUST_REF = "MD.LoadRequest.MatchCustRef";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_CONTAINER = "MD.LoadRequest.MatchContainer";
	public static final String USER_OPT_M_D_LOAD_REQUEST_MATCH_DOCKET = "MD.LoadRequest.MatchDocket";
	public static final String USER_OPT_M_D_LOAD_REQUEST_DAYS_BEFORE = "MD.LoadRequest.DaysBefore";
	public static final String USER_OPT_M_D_LOAD_REQUEST_DAYS_AFTER = "MD.LoadRequest.DaysAfter";
	public static final String USER_OPT_M_D_LOAD_REQUEST_CREATE_TRIP = "MD.LoadRequest.CreateTrip";
	public static final String USER_OPT_M_D_LOAD_REQUEST_UNDESPATCH = "MD.LoadRequest.Undespatch";
	public static final String USER_OPT_LOGGING_EARLY_DESPATCH_ALERT = "Logging.EarlyDespatchAlert";
	public static final String USER_OPT_M_D_SVC_SIMP_ENABLED = "MD.SvcSimp.Enabled";
	public static final String USER_OPT_M_D_SVC_SIMP_SYSTEM_LOAD_NOS = "MD.SvcSimp.SystemLoadNos";
	public static final String USER_OPT_ALLOCATION_CALCULATE_PLANNED_DESPATCH_TIME = "Allocation.CalculatePlannedDespatchTime";
	public static final String USER_OPT_LOAD_PLAN_SERVICE_TYPES = "LoadPlan.ServiceTypes";
	public static final String USER_OPT_LOAD_PLAN_ENFORCE_SAME_DAY = "LoadPlan.EnforceSameDay";
	public static final String USER_OPT_LOAD_PLAN_CREATE_FINISH = "LoadPlan.CreateFinish";
	public static final String USER_OPT_LOAD_PLAN_FINISH_LOCATION = "LoadPlan.FinishLocation";
	public static final String USER_OPT_ROSTER_PROMPT_DETAILS = "Roster.PromptDetails";
	public static final String USER_OPT_ROSTER_DEFAULT_SHIFT = "Roster.DefaultShift";
	public static final String USER_OPT_ROSTER_BREAK_TIME = "Roster.BreakTime";
	public static final String USER_OPT_AXIOM_ALLOCATION_RETURN_TO_PROMPT = "Axiom.Allocation.ReturnToPrompt";
	public static final String USER_OPT_JOB_ACTIVITY_REF_TYPE = "JobActivity.RefType";
	public static final String USER_OPT_M_D_ALLOW_UNDESPATCH = "MD.AllowUndespatch";
	public static final String USER_OPT_AXIOM_LASTLOGIN = "Axiom.LastLogin";

	// predefined option values
	public static final String USER_OPT_DRIVER_NAME_FORMAT_FIRST_LAST = "First Last";
	public static final String USER_OPT_DRIVER_NAME_FORMAT_LAST_FIRST = "Last First";
	public static final String USER_OPT_ROUTING_UNIT_DEFAULT_VALUE = "TONNES";
	public static final String USER_OPT_CSV_APP_URL = "csvApplicationURL";

	/********************/
	/*** System Options ***/
	/********************/
	public static final String SYSTEM_OPT_AXIOM_LOAD_PRIORITY = "Axiom.Load.Priority";
	public static final String SYSTEM_OPT_AXIOM_REPORT_FORMATS_INVOICE = "Axiom.Report.Formats.Invoice";
	public static final String SYSTEM_OPT_AXIOM_REPORT_FORMATS_CREDIT_NOTE = "Axiom.Report.Formats.CreditNote";
	public static final String SYSTEM_OPT_AXIOM_REPORT_FORMATS_DRIVER_SUMMARY = "Axiom.Report.Formats.DriverSummary";
	public static final String SYSTEM_OPT_AXIOM_REPORT_FORMATS_PAY_ADVICE = "Axiom.Report.Formats.PayAdvice";
	public static final String SYSTEM_OPT_AXIOM_REPORT_RUNSHEET = "Axiom.Report.Formats.Runsheet";
	public static final String SYSTEM_OPT_AXIOM_RUNSHEET_CALCULATION_TYPES = "Axiom.Runsheet.Calculation.Types";

	public static final String SYSTEM_OPT_MOBILEDATA_TRACKING_PREFERENCE_OPTIONS = "MobileData.TrackingPreference.Options";

	// A2 defined system option
	public static final String SYSTEM_OPT_AXIOM_INVOICE_REMARKS_MODE = "Axiom.Customer.Invoice.Remarks.Mode";
	public static final String SYSTEM_OPT_AXIOM_CREATE_DEMURRAGE = "Runsheet.CreateDemurrage";
	public static final String SYSTEM_OPT_AXIOM_CREATE_DEMURRAGE_TOLERANCE = "Runsheet.CreateDemurrageTolerance";

	/********************************/
	/*** Chain Commands Constants ***/
	/********************************/
	public static final String CHAIN_COMMAND_DATA_REASON_ID = "reasonId";

	/***************************/
	/*** Application Options ***/
	/***************************/
	public static final String APP_OPTION_TIMEZONE_NAME = "timezone";
	public static final String APP_OPTION_REPORT_SERVICE_URL_NAME = "report.service.url";
	public static final String APP_OPTION_UNIBIS_REPORT_SERVICE_URL_NAME = "report.unibis.url";
	public static final String APP_OPTION_REPORT_TRIPSHEET_NAME = "report.tripsheet.name";
	public static final String APP_OPTION_REPORT_AUTO_CLOSEOFF_URL = "report.autocloseoff.url";
	public static final String APP_OPTION_QLR_REPORT_ENABLED_SERVER_NAME = "qlr.report.server.enabled";
	public static final String APP_OPTION_ETA_EVENT_ENABLED = "ETAEventEnabled";
	public static final String APP_OPTION_CSV_UPLOAD_ENABLED = "csvUploadEnabled";
	public static final String APP_OPTION_RATE_ARCHIVE_CUT_OFF = "rateArchiveCutOff";
	public static final String APP_OPTION_CSV_APP_URL = "csvApplicationURL";

	/*** Event Types ***/
	// The A1 event type id for despatch event
	public final static int EVENT_TYPE_ID_DESPATCH = 8;
	// The A1 event type id for undespatch event
	public final static int EVENT_TYPE_ID_UNDESPATCH = 50;
	// The A1 event type id for trip complete event
	public final static int EVENT_TYPE_ID_TRIP_COMPLETE = 6;
	// The A1 event type id for returned to base event
	public final static int EVENT_TYPE_ID_RETURNED = 5;
	// The A1 event type id for Load Ready event
	public final static int EVENT_TYPE_ID_LOAD_READY = 18;
	// The A1 event type id for Paperwork Ready event
	public final static int EVENT_TYPE_ID_PAPERWORK_READY = 19;
	// The A1 event type id for ETA Updated event
	public final static int EVENT_TYPE_ID_ETA_UPDATED = 46;
	// The A1 event type id for Resource Changed event
	public final static int EVENT_TYPE_ID_REDESPATCHED = 52; 
	// The A1 event type id for Resource Changed event
	public final static int EVENT_TYPE_ID_RESOURCE_CHANGED = 51;
	// The A1 event type id for MDT Login
	public final static int EVENT_TYPE_ID_MDT_LOGIN = 17;
	// The A1 event type id for Shift End
	public final static int EVENT_TYPE_ID_SHIFT_END = 7;
	// The A1 event type id for Pickup Arrive
	public final static int EVENT_TYPE_ID_PICKUP_ARRIVE = 11;
	// The A1 event type id for Drop Arrive
	public final static int EVENT_TYPE_ID_DROP_ARRIVE = 13;
	// The A1 event type id for Pickup Depart
	public final static int EVENT_TYPE_ID_PICKUP_DEPART = 12;
	// The A1 event type id for Drop Depart
	public final static int EVENT_TYPE_ID_DROP_DEPART = 14;
	// The A1 event type id for Pickup Completed
	public final static int EVENT_TYPE_ID_PICKUP_COMPLETED = 15;
	// The A1 event type id for Drop Completed
	public final static int EVENT_TYPE_ID_DROP_COMPLETED = 16;
	// The A1 event type id for Service Rejected
	public final static int EVENT_TYPE_ID_SERVICE_REJECTED = 37;
	// The A1 event type id for Load Request
	public final static int EVENT_TYPE_ID_LOAD_REQUEST = 36;

	/*********************/
	/*** Service Types ***/
	/*********************/
	// The default Service Type for RETURN services
	public final static String SERVICE_TYPE_ID_RETURNS = "RETURNS";
	public final static String SERVICE_TYPE_ID_RETURN = "RETURN";
	// The default Service Type for FINISH lines
	public final static String SERVICE_TYPE_ID_FINISH = "FINISH";
	public final static String SERVICE_TYPE_ID_IMPORT = "IMPORT";
	public final static String SERVICE_TYPE_ID_EMPTY = "EMPTY";
	public final static String SERVICE_TYPE_ID_EXPORT = "EXPORT";
	public final static String SERVICE_TYPE_ID_DEHIRE = "DEHIRE";
	public final static String SERVICE_TYPE_ID_LOCAL = "LOCAL";
	public final static String SERVICE_TYPE_ID_UNLADEN = "UNLADEN";
	public final static String SERVICE_TYPE_ID_DELIVERY = "DELIVERY";
	public final static String SERVICE_TYPE_ID_DEMURRAGE = "DEMURRAGE";
	public final static String SERVICE_TYPE_ID_RELOCATE = "RELOCATE";

	/*********************/
	/*** Load Types ***/
	/*********************/
	public final static String LOAD_TYPE_ID_EMPTY = "EMPTY";
	public final static String LOAD_TYPE_ID_EXPORT = "EXPORT";
	public final static String LOAD_TYPE_ID_DEHIRE = "DEHIRE";
	public final static String LOAD_TYPE_ID_IMPORT = "IMPORT";
	public final static String LOAD_TYPE_ID_LOCAL = "LOCAL";
	public final static String LOAD_TYPE_ID_UNLADEN = "UNLADEN";
	public final static String LOAD_TYPE_ID_DELIVERY = "DELIVERY";
	public final static String LOAD_TYPE_ID_PICKUP = "PICKUP";
	public final static String LOAD_TYPE_ID_HIRE = "HIRE";

	/**********************/
	/*** Location Types ***/
	/**********************/
	public final static String LOCATION_TYPE_ID_PARK = "PARK";

	/********************/
	/*** Site Options ***/
	/********************/
	// The A1 site option to enable the mobile device
	public final static String SITE_OPTION_MOBILE_DATA_ENABLED = "Axiom.MobileData.Enabled";
	public final static String SITE_OPTION_AUTO_RUNSHEETS_ENABLED = "Axiom.AutoRunsheets.Enabled";
	public final static String SITE_OPTION_ZONE_ID = "Axiom.Time.ZoneID";
	public final static String SITE_OPTION_SEG_TB_MAX_DURATION_MINS = "SEG.TrackingBuffer.MaxDurationMins";
	public final static String SITE_OPTION_MD_SVCSIMP_ENABLED = "MD.SvcSimp.Enabled";

	/**********************************/
	/** Adjustments-related constants */
	/**********************************/
	// internal use
	public static final int ADJUSTMENTS_DECIMAL_PLACES_FOR_DIVIDE = 6;
	public static final String ADJUSTMENTS_ADJUSTMENT_DATASOURCEID = "AH";
	public static final String ADJUSTMENTS_RECHARGE_DATASOURCEID = "RC";
	public static final String ADJUSTMENTS_PERIODIC_CHARGE_DATASOURCEID = "PC";
	public static final String ADJUSTMENTS_RECHARGE_HOLDCODE_MARK_FOR_COMPLETION = "RequiresA2Complete";

	/**********************************/
	/** Invoice-related constants **/
	/**********************************/
	public static final String INVOICE_INVOICE_STATUS_READY = "READY";
	public static final String INVOICE_DOCUMENT_TYPE_INVOICE = "Invoice";
	public static final String INVOICE_DOCUMENT_TYPE_CREDIT_NOTE = "Credit Note";
	public static final String INVOICE_STATUS_ID_PRINTED = "PRINTED";
	public static final String INVOICE_INVOICE_STATUS_HOLD = "HOLD";

	/***********************************/
	/** Invoice line-related constants */
	/***********************************/
	public static final String INVOICE_LINE_INVOICE_PERIOD_CURRENT = "Current";
	public static final String INVOICE_LINE_INVOICE_PERIOD_PREVIOUS = "Previous";

	/**********************************/
	/** KeyGenDAO-related constants **/
	/**********************************/
	public static final String KEY_GEN_SERVICE_KEY = "SERVICE";
	public static final String KEY_GEN_CUSTLOAD_KEY = "LOAD";
	public static final String KEY_GEN_TRIP_KEY = "TRIP";

	/**********************************/
	/** Pay Advice-related constants **/
	/**********************************/
	public static final String PAY_ADVICE_STATUS_ID_READY = "READY";
	public static final String PAY_ADVICE_STATUS_ID_PRINTED = "PRINTED";
	public static final String PAY_ADVICE_STATUS_ID_HOLD = "HOLD";

	/** PERMISSION table-related constants */
	public static final long PERMISSION_SUPERUSER_GROUPID = 1;
	// Plan constants
	/**
	 * Used to verify read-write permissions for the allocation screen.
	 */
	public static final String PERMISSION_PLAN_ALLOCATION_BY_ROUTE = "AllocationByRoute";
	// Permission IDs used in Reconcile
	public static final String PERMISSION_SERVICE_TRIP_SEARCH = "TripServiceSearch";
	public static final String PERMISSION_RUNSHEET_SEARCH = "RunsheetSearch";
	public static final String PERMISSION_ENTER_RUNSHEETS = "EnterRunsheets";
	public static final String PERMISSION_RUNSHEET2 = "Runsheet2";
	public static final String PERMISSION_SHIFT_LIST = "ShiftList";
	public static final String PERMISSION_SERVICE_LIST = "ServiceList";
	public static final String PERMISSION_RUNSHEET_LIST = "RunsheetList";
	public static final String PERMISSION_RELEASE_RUNSHEETS_ON_HOLD = "ReleaseRunsheetsOnHold";
	public static final String PERMISSION_AUTO_COMPLETE_RUNSHEETS = "AutoCompleteRunsheets";
	public static final String PERMISSION_ENTER_ADJUSTMENTS = "EnterAdjustments";
	public static final String PERMISSION_LIST_PERIODIC_CHARGES = "ListPeriodicCharges";
	public static final String PERMISSION_LIST_PERIODIC_PAYS = "ListPeriodicPays";
	public static final String PERMISSION_CREATE_INVOICES = "CreateInvoices";
	public static final String PERMISSION_CREATE_PAY_ADVICES = "CreatePayAdvices";
	public static final String PERMISSION_INVOICE_PRINT = "InvoicePrint";
	public static final String PERMISSION_PAY_ADVICE_PRINT = "PayAdvicePrint";
	public static final String PERMISSION_DUPLICATE_ADJUSTMENTS = "DuplicateAdjustments";
	public static final String PERMISSION_APPLY_PERIODIC_CHARGES = "ApplyPeriodicCharges";
	public static final String PERMISSION_APPLY_PERIODIC_PAYS = "ApplyPeriodicPays";
	// Close Off permissions
	public static final String PERMISSION_CLOSE_OFF = "CloseOff";
	public static final String PERMISSION_CLOSE_OFF_IMMEDIATE = "CloseOffImmediate";
	public static final String PERMISSION_CLOSE_OFF_LOG = "CloseOffLog";
	public static final String PERMISSION_CLOSE_OFF_SAME_WEEK = "CloseOffSameWeek";
	public static final String PERMISSION_CLOSE_OFF_CHANGE_WEEK = "CloseOffChangeWeek";

	// Report permissions
	public static final String PERMISSION_QLR_MENU_LAUNCH = "QLRMenuLaunch";

	// Setup permissions
	public static final String PERMISSION_ADJUSTMENT_TYPE_LIST = "AdjustmentTypeList";
	public static final String PERMISSION_CHARGE_DECISION = "ChargeDecision";
	public static final String PERMISSION_CHARGE_ZONE_LIST = "ChargeZoneList";
	public static final String PERMISSION_COMPANY_TYPE_LIST = "CompanyTypeList";
	public static final String PERMISSION_CONTAINER_STATUS_LIST = "ContainerStatusList";
	public static final String PERMISSION_CONTAINER_TRACKING = "ContainerTracking";
	public static final String PERMISSION_CONTAINER_TYPE_LIST = "ContainerTypeList";
	public static final String PERMISSION_CUSTOMER_SETTINGS = "CustomerSettings";
	public static final String PERMISSION_DELIVERY_WINDOW_LIST = "DeliveryWindowList";
	public static final String PERMISSION_DISCOUNT_DECISION_TABLE = "DiscountDecisionTable";
	public static final String PERMISSION_PAY_DECISION = "PayDecision";
	public static final String PERMISSION_FUEL_DECISION_TABLE = "FuelDecisionTable";
	public static final String PERMISSION_GEOCODER_LAUNCH = "GeocoderLaunch";
	public static final String PERMISSION_LOAD_TYPE_LIST = "LoadTypeList";
	public static final String PERMISSION_LOCATION_TYPE_LIST = "LocationTypeList";
	public static final String PERMISSION_MAP_SOURCE_LIST = "MapSourceList";
	public static final String PERMISSION_MISC_REPORTS = "MiscReports";
	public static final String PERMISSION_PAY_ZONE_LIST = "PayZoneList";
	public static final String PERMISSION_RATE_LIST = "RateList";
	public static final String PERMISSION_REASONCODE_LIST = "ReasonCodeList";
	public static final String PERMISSION_RUNSHEET_TYPE_LIST = "RunsheetTypeList";
	public static final String PERMISSION_SERVICE_TYPE_LIST = "ServiceTypeList";
	public static final String PERMISSION_TASK_TYPE_LIST = "TaskTypeList";
	public static final String PERMISSION_TRAILER_TYPE_LIST = "TrailerTypeList";
	public static final String PERMISSION_TRUCK_SIZE = "TruckSizeList";
	public static final String PERMISSION_TRUCK_TYPE_LIST = "TruckTypeList";
	public static final String PERMISSION_UNIT_LIST = "UnitList";
	public static final String PERMISSION_INVOICE_DELETION = "InvoiceDeletion";
	public static final String PERMISSION_PRINTED_INVOICE_DELETION = "DeletePrintedInvoices";
	public static final String PERMISSION_PAYADV_DELETION = "PayAdviceDeletion";
	public static final String PERMISSION_PRINTED_PAYADV_DELETION = "DeletePrintedPayAdv";
	public static final String PERMISSION_USER_LIST = "UserList";
	public static final String PERMISSION_PARTIAL_RUNSHEET_COMPLETION = "PartialRunsheetCompletion";
	public static final String PERMISSION_DELETION_COMPLETION_LOG = "DelCompLog";
	public static final String PERMISSION_SYSTEM_SETTINGS = "SystemSettings";
	public static final String PERMISSION_NOTIFICATIONS_EXTEMAIL = "Notifications.ExtEmail";
	public static final String PERMISSION_NOTIFICATIONS_SMS = "Notifications.SMS";

	// Reference permissions
	public static final String PERMISSION_RATE_CATEGORY_TYPE_LIST = "rateCategoriesList";
	public static final String PERMISSION_RATE_METHOD_TYPE_LIST = "rateMethodsList";
	public static final String PERMISSION_RATE_METHOD_FIELD_MAPPINGS_LIST = "rateMethodFldMapgList";
	public static final String PERMISSION_BREAK_TYPE_LIST = "BreakTypeList";
	public static final String PERMISSION_COMPANY_LIST = "CompanyList";
	public static final String PERMISSION_CONTACT_SEARCH = "ContactSearch";
	public static final String PERMISSION_CONTAINER_LIST = "ContainerList";
	public static final String PERMISSION_CURFEW_WINDOW_LIST = "CurfewWindowList";
	public static final String PERMISSION_CUSTOMER_GROUP_LIST = "CustomerGroupList";
	public static final String PERMISSION_CUSTOMER_LIST = "CustomerList";
	public static final String PERMISSION_ROUTE_LIST = "RouteList";
	public static final String PERMISSION_DOCK_LIST = "DockList";
	public static final String PERMISSION_DRIVER_LIST = "DriverList";
	public static final String PERMISSION_FLEET_MAINT = "FleetMaint";
	public static final String PERMISSION_HOME_LOCATION = "HomeLocation";
	public static final String PERMISSION_LOCATION_LIST = "LocationList";
	public static final String PERMISSION_FLEET_MAINT_TYPE = "FleetMaintType";
	public static final String PERMISSION_MD_MESSAGE_LISTS = "MDMessageLists";
	public static final String PERMISSION_PAY_BASIS_LIST = "PayBasisList";
	public static final String PERMISSION_MD_SITE_PHONEBOOK = "MDSitePhonebook";
	public static final String PERMISSION_POINT_KM = "PointKM";
	public static final String PERMISSION_PUBLIC_HOLIDAYS_LIST = "PublicHolidayList";
	public static final String PERMISSION_REGION_LIST = "RegionList";
	public static final String PERMISSION_TRAILER_LIST = "TrailerList";
	public static final String PERMISSION_TRUCK_LIST = "TruckList";
	public static final String PERMISSION_VESSELS = "Vessels";
	public static final String PERMISSION_WORK_GROUPS_LIST = "WorkgroupList";
	public static final String PERMISSION_KEY_GENERATION = "KeyGeneration";
	public static final String PERMISSION_WORK_TASK_TYPE_LIST = "TaskTypeList";

	// Search permissions
	public static final String PERMISSION_LOAD_SERVICE_SEARCH = "LoadServiceSearch";
	public static final String PERMISSION_TRIP_SERVICE_SEARCH = "TripServiceSearch";
	public static final String PERMISSION_INVOICE_SEARCH = "InvoiceSearch";
	public static final String PERMISSION_PAY_ADVICE_SEARCH = "PayAdviceSearch";
	public static final String PERMISSION_ADJUSTMENT_SEARCH = "AdjustmentSearch";
	public static final String PERMISSION_PERIODIC_SEARCH = "PeriodicSearch";
	public static final String PERMISSION_UNALLOCATED_INVOICE_LINE_SEARCH = "InvoiceLineUnallocated";
	public static final String PERMISSION_UNALLOCATED_PAY_ADVICE_LINE_SEARCH = "PayAdviceLineUnallocated";

	// RIMS permissions
	public static final String PERMISSION_RIMS = "RIMS";
	public static final String PERMISSION_ALLERGY_TYPES = "RIMS_Ref_Allergies";
	public static final String PERMISSION_LICENCE_TYPES = "RIMS_Ref_Licences";
	public static final String PERMISSION_INDUCTION_TYPES = "RIMS_Ref_Inductions";
	public static final String PERMISSION_INSURANCE_TYPES = "RIMS_Ref_InsTypes";
	public static final String PERMISSION_MEDICAL_TYPES = "RIMS_Ref_MedTypes";
	public static final String PERMISSION_MEDICAL_PROVIDERS = "RIMS_Ref_MedProviders";
	public static final String PERMISSION_RIMS_REF_SITES = "RIMS_Ref_Sites";
	public static final String PERMISSION_EMPLOYEE_STATUSES = "RIMS_Ref_EmpStatus";
	public static final String PERMISSION_EMPLOYEE_TYPES = "RIMS_Ref_EmpTypes";
	public static final String PERMISSION_POSITION_CATEGORIES = "RIMS_Ref_PosCats";
	public static final String PERMISSION_POSITION_TYPES = "RIMS_Ref_PosTypes";
	public static final String PERMISSION_ROLE_TYPES = "RIMS_Ref_RoleTypes";
	public static final String PERMISSION_PERSON_CONTACTS = "RIMS_Ref_Contacts";
	public static final String PERMISSION_USER_SETUP = "RIMS_Ref_UserSetup";
	public static final String PERMISSION_COURSE_CATEGORIES = "RIMS_Course_Category";
	public static final String PERMISSION_COURSE_PROVIDERS = "RIMS_Course_Provider";
	public static final String PERMISSION_COURSE_TYPES = "RIMS_Course_Type";
	public static final String PERMISSION_PERSONNEL_SEARCH = "RIMS_Emp_Search";
	public static final String PERMISSION_RIMS_EMPLOYEE = "RIMS_Emp";
	public static final String PERMISSION_RIMS_ENTITY = "RIMS_Entity";
	public static final String PERMISSION_RIMS_BUSINESS = "RIMS_Business";
	public static final String PERMISSION_RIMS_BUSINESS_TYPE = "RIMS_Business_Type";
	public static final String PERMISSION_RIMS_SUPER = "RIMS_Super";
	public static final String PERMISSION_RIMS_EMP_HISTORY = "RIMS_Emp_History";
	public static final String PERMISSION_MASTER_VENDORS = "Master_Vendors";
	public static final String PERMISSION_MASTER_CUSTOMERS = "Master_Customers";
	public static final String PERMISSION_MASTER_SECURITY = "Master_Security";

	public static final String PERMISSION_FREE_ACCESS = "FREE_ACCESS";

	// Accounts permissions
	public static final String PERMISSION_ACCOUNTS_UI_LOGIN = "UI_Login";
	public static final String PERMISSION_ACCOUNTS_UI_ADMIN = "UI_Admin";
	public static final String PERMISSION_ACCOUNTS_UI_SETTINGS = "UI_Settings";
	public static final String PERMISSION_ACCOUNTS_UI_AP_EXPORT = "UI_AP_Export";
	public static final String PERMISSION_ACCOUNTS_UI_AP_RESET = "UI_AP_Reset";
	public static final String PERMISSION_ACCOUNTS_UI_AR_EXPORT= "UI_AR_Export";
	public static final String PERMISSION_ACCOUNTS_UI_AR_RESET = "UI_AR_Reset";


	/*********************************/
	/** Runsheet-related constants **/
	/*********************************/
	public static final String RUNSHEET_HOLDCODE_REQUIRES_A2_RATING = "RequiresA2Rating";
	public static final String RUNSHEET_HOLDCODE_REQUIRES_A2_COMPLETE = "RequiresA2Complete";
	public static final String RUNSHEET_HOLDCODE_COMPLETING = "Completing";
	public static final String RUNSHEET_HOLDCODE_REQUIRES_AUTO_RATING = "RequiresAutoRating";
	public static final String RUNSHEET_HOLDCODE_REQUIRES_AUTO_VALIDATE = "RequiresAutoValidate";
	public static final String RUNSHEET_HOLDCODE_REQUIRES_AUTO_COMPLETE = "RequiresAutoComplete";

	public static final String A2_RATING_ENABLED = "A2.Rating.Enabled";
	public static final String A2_COMPLETION_ENABLED = "A2.Completion.Enabled";
	
	public static final String EVENT_LOG_AXIOM_USER = "axiom";
	public static final String EVENT_LOG_OFFLINE_USER = "offline";
	public static final String EVENT_LOG_OFFLINE_RATING = "OFFLINERATING";
	public static final String EVENT_LOG_OFFLINE_RATING_START = "RUNSHEET-RATING-START";
	public static final String EVENT_LOG_OFFLINE_RATING_FINISH = "RUNSHEET-RATING-FINISH";

	/******************************/
	/** Shift-related constants **/
	/******************************/
	public static final String SHIFT_DATASOURCE_RUNSHEET = "RS";
	public static final String SHIFT_STATUS_ACC = "ACC";
	public static final String SHIFT_STATUS_INPROC = "INPROC";
	public static final String SHIFT_STATUS_ERR = "ERR";

	/****************************/
	/** Trip related constants **/
	/****************************/
	public static final String TRIP_CACHED_STATUS_TRIP_PLANNING = "P ";
	public static final String TRIP_CACHED_STATUS_TRIP_COMPLETED = "CP";
	public static final String TRIP_FIELD_NAME_RETURNTOLOCATIONID = "returnLocationId";

	/*******************************/
	/** Service related constants **/
	/*******************************/
	public static final String SERVICE_HOLDCODE_VERIFY = "RequiresA2Verify";
	public static final Long SERVICE_DYNON_MAX_LOAD = 20L;
	public static final Long SERVICE_CONTAINER_MAX_LOAD = 50L;

	/******************************/
	/** Report related constants **/
	/******************************/
	public static final String REPORT_NAME_INVOICE = "Invoice";
	public static final String REPORT_NAME_CREDIT_NOTE = "CreditNote";
	public static final String REPORT_NAME_PAYADVICE = "payadvice";


	/****************************/
	/** Special employee role constants **/
	/****************************/
	public static final String ROLE_TYPE_BUS_MGR = "Business Manager";
	public static final String ROLE_TYPE_OPS_MGR = "Operations Manager";
	public static final String ROLE_TYPE_OHS_SUPERVISOR = "OHS Supervisor";

	/********************************/
	/** Periodic related constants **/
	/********************************/
	public enum PeriodicType {
		PAY, CHARGE
	}
	public enum PeriodicPeriod {
		Day, Week, Month
	}

	/*************************************/
	/** Auto Runsheet Completion Status **/
	/*************************************/
	public enum AutoRunCompStatus {
		COMPLETED, FAILED, SKIPPED
	}

	/**************************************/
	/** Runsheet Completion process type **/
	/**************************************/
	public enum RunCompProcessType {
		AUTO, MANUAL
	}

	/**************************************/
	/** Leopard event queue types **/
	/**************************************/
	public enum LeopardQueueType {
		INBOUND, OUTBOUND
	}

	/**********************************/
	/** Unit table related constants **/
	/**********************************/
	public static final String UNIT_TONNES = "TONNES";
	public static final String UNIT_PALLETS = "PALLETS";
	public static final String UNIT_CAGES = "CAGES";

	/*************************************************************/
	/** ReferenceDataTO field names                             **/
	/** - These should match the field names in ReferenceDataTO **/
	/*************************************************************/
	public static final String REFERENCE_METADATA_A2TYPENAME_RATE_CATEGORY_TYPES = "rateCategories";
	public static final String REFERENCE_METADATA_A2TYPENAME_RATE_METHOD_TYPES = "rateMethods";
	public static final String REFERENCE_METADATA_A2TYPENAME_RATE_METHOD_FIELD_MAPPINGS = "rateMethodFieldMapgs";
	public static final String REFERENCE_METADATA_A2TYPENAME_ACTIVITY_TYPES = "activityTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_ADJUSTMENT_TYPES = "adjustmentTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_BREAK_TYPES = "breakTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_COMPANY_MASTERS = "companyMasters";
	public static final String REFERENCE_METADATA_A2TYPENAME_COMPANYS = "companys";
	public static final String REFERENCE_METADATA_A2TYPENAME_COMPANY_TYPES = "companyTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_CONTAINERS = "containers";
	public static final String REFERENCE_METADATA_A2TYPENAME_CONTAINER_TYPES = "containerTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_CONTAINER_STATUSES = "containerStatuses";
	public static final String REFERENCE_METADATA_A2TYPENAME_CURFEW_WINDOWS = "curfewWindows";
	public static final String REFERENCE_METADATA_A2TYPENAME_CUSTOMER_GROUPS = "customerGroups";
	public static final String REFERENCE_METADATA_A2TYPENAME_CUSTOMERS = "customers";
	public static final String REFERENCE_METADATA_A2TYPENAME_DOCKS = "docks";
	public static final String REFERENCE_METADATA_A2TYPENAME_DRIVERS = "drivers";
	public static final String REFERENCE_METADATA_A2TYPENAME_EVENT_TYPES = "eventTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_HOME_LOCATIONS = "homeLocations";
	public static final String REFERENCE_METADATA_A2TYPENAME_INVOICE_STATUSES = "invoiceStatuses";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOAD_TYPES = "loadTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATIONS = "locations";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATIONS_WHARF = "locationsWharf";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATIONS_DEPOT = "locationsDepot";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATIONS_CUSTOMER = "locationsCustomer";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATIONS_DEHIRE = "locationsDehire";
	public static final String REFERENCE_METADATA_A2TYPENAME_HOME_LOCATIONS_UNUSED = "homeLocationsUnused";
	public static final String REFERENCE_METADATA_A2TYPENAME_LOCATION_TYPES = "locationTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_PAY_BASES = "payBases";
	public static final String REFERENCE_METADATA_A2TYPENAME_PERSONS = "persons";
	public static final String REFERENCE_METADATA_A2TYPENAME_PERSONSV2 = "personsV2";
	public static final String REFERENCE_METADATA_A2TYPENAME_POINT_KMS = "pointKMs";
	public static final String REFERENCE_METADATA_A2TYPENAME_REASONS = "reasons";
	public static final String REFERENCE_METADATA_A2TYPENAME_REF_PERMISSION_SITES = "refPermissionSites";
	public static final String REFERENCE_METADATA_A2TYPENAME_REF_SITES = "sites";
	public static final String REFERENCE_METADATA_A2TYPENAME_REGIONS = "regions";
	public static final String REFERENCE_METADATA_A2TYPENAME_REST_API_PERMISSIONS = "restAPIPermissions";
	public static final String REFERENCE_METADATA_A2TYPENAME_ROUTES = "routes";
	public static final String REFERENCE_METADATA_A2TYPENAME_RUNSHEET_TYPES = "runsheetTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_SERVICE_TYPES = "serviceTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_SITE_OPTIONS = "siteOptions";
	public static final String REFERENCE_METADATA_A2TYPENAME_SYSTEM_OPTONS = "systemOptions";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRAILERS = "trailers";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRAILER_TYPES = "trailerTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRUCK_SIZES = "truckSizes";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRUCKS = "trucks";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRUCK_TYPES = "truckTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_UNITS = "units";
	public static final String REFERENCE_METADATA_A2TYPENAME_USERDATA = "userData";
	public static final String REFERENCE_METADATA_A2TYPENAME_VESSELS = "vessels";
	public static final String REFERENCE_METADATA_A2TYPENAME_WINDOWS = "windows";
	public static final String REFERENCE_METADATA_A2TYPENAME_ZONE_CHARGES = "zoneCharges";
	public static final String REFERENCE_METADATA_A2TYPENAME_ZONE_PAYS = "zonePays";
	public static final String REFERENCE_METADATA_A2TYPENAME_MAP_SOURCES = "mapSources";
	public static final String REFERENCE_METADATA_A2TYPENAME_ACTIVITY_CATEGORIES = "activityCategories";
	public static final String REFERENCE_METADATA_A2TYPENAME_USER_OPTIONS = "userOptions";
	public static final String REFERENCE_METADATA_A2TYPENAME_WORK_GROUPS = "workGroups";
	public static final String REFERENCE_METADATA_A2TYPENAME_KEY_GENS = "keyGens";
	public static final String REFERENCE_METADATA_A2TYPENAME_TASK_TYPES = "taskTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_RUNSHEET_CALCULATION_TYPES = "runsheetCalculationTypes";
	public static final String REFERENCE_METADATA_A2TYPENAME_FUELLEVIES = "fuelLevies";
	public static final String REFERENCE_METADATA_A2TYPENAME_DISCOUNTS = "discounts";
	public static final String REFERENCE_METADATA_A2TYPENAME_QLR_REPORTS = "qlrReports";
	public static final String REFERENCE_METADATA_A2TYPENAME_QLR_FOLDERS = "qlrFolders";
	public static final String REFERENCE_METADATA_A2TYPENAME_QLR_SERVERS = "qlrServers";
	public static final String REFERENCE_METADATA_A2TYPENAME_RATES = "rates";
	public static final String REFERENCE_METADATA_A2TYPENAME_RATE_CHARGES = "rateCharges";
	public static final String REFERENCE_METADATA_A2TYPENAME_RATE_PAYS = "ratePays";
	public static final String REFERENCE_METADATA_A2TYPENAME_ALL_MULTILEG_ORIGIN_SITES = "allMultiLegSitesOrigin";
	public static final String REFERENCE_METADATA_A2TYPENAME_ALL_MULTILEG_DESTINATION_SITES = "allMultiLegSitesDestination";
	public static final String REFERENCE_METADATA_A2TYPENAME_MULTILEG_ORIGIN_LOCATIONS = "multilegOriginLocations";
	public static final String REFERENCE_METADATA_A2TYPENAME_MULTILEG_DESTINATION_LOCATIONS = "multilegDestinationLocations";
	public static final String REFERENCE_METADATA_A2TYPENAME_PUBLIC_HOLIDAYS = "publicHolidays";
	public static final String REFERENCE_METADATA_A2TYPENAME_SITE_USERS = "siteUsers";
	public static final String REFERENCE_METADATA_A2TYPENAME_PERMISSION_GROUPS = "permissionGroups";
	public static final String REFERENCE_METADATA_A2TYPENAME_STATES = "states";

	//fields not in ReferenceDataTO.
	public static final String REFERENCE_METADATA_A2TYPENAME_DAY_OF_WEEK = "dayOfWeek";
	public static final String REFERENCE_METADATA_A2TYPENAME_SAME_END_DAY = "sameEndDay";
	public static final String REFERENCE_METADATA_A2TYPENAME_DAY_OF_WEEK_HOLIDAY = "dayOfWeekHoliday";




	// These 2 states ref types are currently stored in UI
	public static final String REFERENCE_METADATA_A2TYPENAME_STATES_ONLY = "statesOnly";
	public static final String REFERENCE_METADATA_A2TYPENAME_STATES_NATIONAL = "statesNational";
	// This title ref type is currently stored in UI
	public static final String REFERENCE_METADATA_A2TYPENAME_TITLE_ONLY = "titlesOnly";

	public static final String REFERENCE_METADATA_A2TYPENAME_LOAD_PRIORITIES = "loadPriorities";
	public static final String REFERENCE_METADATA_A2TYPENAME_CREDIT_NOTE_REPORT_FORMATS = "creditNoteReportFormats";
	public static final String REFERENCE_METADATA_A2TYPENAME_DRIVER_SUMMARY_REPORT_FORMATS = "driverSummaryReportFormats";
	public static final String REFERENCE_METADATA_A2TYPENAME_INVOICE_REPORT_FORMATS = "invoiceReportFormats";
	public static final String REFERENCE_METADATA_A2TYPENAME_PAY_ADVICE_REPORT_FORMATS = "payAdviceReportFormats";
	public static final String REFERENCE_METADATA_A2TYPENAME_RUNSHEET_REPORT_FORMATS = "runsheetReportFormats";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRACKING_PREFERENCE_OPTIONS = "trackingPreferenceOptions";
	public static final String REFERENCE_METADATA_A2TYPENAME_INVOICE_REMARKS_MODES = "invoiceRemarksModes";

	public static final String REFERENCE_METADATA_A2TYPENAME_PAY_ADVICE_SEARCH_RESULTS = "payAdviceSearchResults";
	public static final String REFERENCE_METADATA_A2TYPENAME_INVOICE_SEARCH_RESULTS = "invoiceSearchResults";
	public static final String REFERENCE_METADATA_A2TYPENAME_RUNSHEET_SEARCH_RESULTS = "runsheetSearchResults";
	public static final String REFERENCE_METADATA_A2TYPENAME_SERVICE_SEARCH_RESULTS = "serviceSearchResults";
	public static final String REFERENCE_METADATA_A2TYPENAME_TRIP_SEARCH_RESULTS = "tripSearchResults";
	public static final String REFERENCE_METADATA_A2TYPENAME_ADJUSTMENT_SEARCH_RESULTS = "adjustmentSearchResults";

	// RIMS specific
	public static final String REFERENCE_METADATA_RIMSTYPENAME_ALLERGY_TYPES = "allergyTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_INDUCTION_TYPES = "inductionTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_LICENCE_TYPES = "licenceTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_MEDICAL_TYPES = "medicalTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_MEDICAL_PROVIDERS = "medicalProviders";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_EMPLOYEE_STATUSES = "employeeStatuses";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_EMPLOYEE_TYPES = "employeeTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_POSITION_CATEGORIES = "positionCategories";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_POSITION_TYPES = "positionTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_INSURANCE_TYPES = "insuranceTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_ROLE_TYPES = "roleTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COURSE_CATEGORIES = "courseCategories";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COURSE_TYPES = "courseTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COURSE_PROVIDERS = "courseProviders";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_BUSINESSES = "businesses";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_BUSINESS_TYPES = "businessTypes";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_MEDICAL_LIST = "medicalLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_INDUCTION_LIST = "inductionLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COURSE_LIST = "courseLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_ALLERGY_LIST = "allergyLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_LICENCE_LIST = "licenceLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_PERSONNEL_CONTACT = "personnelContacts";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_PERSONNEL_DETAILS = "personnelDetails";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_SITE_POSITIONS = "sitePositions";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_MDT_EXCEPTIONS = "mdtExceptions";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_PERSONNEL_HISTORY = "personnelHistories";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_SITE_POSITION_HISTORIES = "sitePositionHistories";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_SUBORDINATES = "subordinates";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_REF_SITES = "refSites";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_INSURANCE_LIST = "insuranceLists";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COMPANY_ACTIVE_HIST = "companyActiveHistories";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_COMPANY_MASTERS = "companyMasters";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_ENTITY_DRIVERS = "entityDrivers";
	public static final String REFERENCE_METADATA_RIMSTYPENAME_SITE_ENTRIES = "siteEntities";

	// RIMS Search
	public static final String REFERENCE_METADATA_A2TYPENAME_ATTENDANCE_SEARCH_RESULTS = "courseLists";
	public static final String REFERENCE_METADATA_A2TYPENAME_PERSONNEL_SEARCH_RESULTS = "personnelSearchResults";
	public static final String RIMS_PA_FORMAT_DESC = "paFormatDesc";
	public static final String RIMS_PA_FORMAT = "paFormat";

	// RIMS Constants
	public static final long RIMS_CODE_RANGE_START = 500000;
	public static final long RIMS_CODE_RANGE_END = 799999;

	public static final String RIMS_SITE_OPT_LEOPARD_ORG_PK = "MD.Leopard.OrganisationPK";
	public static final String RIMS_SYS_OPT_LEOPARD_DRIVER_ROLE_PK = "MD.Leopard.DriverRolePK";
	public static final String RIMS_DEFAULT_LEOPARD_PASSWORD = "0F-03-75-84-C9-9E-7F-D4-F4-F8-C5-95-50-F8-F5-07";
	public static final String RIMS_DEFAULT_LEOPARD_DRIVER_ROLE_PK = "3833382D-CD93-48BC-908B-EC90FCCECEAA";
	public static final String RIMS_LEOPARD_PROXY_API_URL_OPTION = "leopard.proxy.api.url";
	public static final String RIMS_DRIVER_EMPLOYEE_POSITION = "Driver";
	public static final String RIMS_DEFAULT_MDT_PIN = "1234";

	// Axiom Master specific
	public static final String REFERENCE_METADATA_MASTERTYPENAME_DESPATCH_DECISIONS = "despatchDecisions";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_SITES = "multiLegSites";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_TRANSLATES = "multiLegTranslates";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_EXCLUDES = "multiLegExcludes";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_TRIPS = "multiLegTrips";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_IDS = "multiLegIds";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MULTILEG_CREATES = "multiLegCreates";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_RETURN_DECISIONS = "returnDecisions";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_RETURN_CREATIONS = "returnCreations";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_COMPANY_MASTERS = "companyMasters";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_CUSTOMER_MASTERS = "customerMasters";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_MASTER_USERS = "masterUsers";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_PERMISSION_GROUPS = "permissionGroups";
	public static final String REFERENCE_METADATA_MASTERTYPENAME_PERMISSIONS = "permissions";

	// Axiom Master permissions
	public static final String PERMISSION_PUBLIC_HOLIDAYS = "PublicHolidayList";
	public static final String PERMISSION_DESPATCH_DECISIONS = "DespatchDecision";
	public static final String PERMISSION_MULTILEG_SITES = "MultilegSites";
	public static final String PERMISSION_MULTILEG_TRANSLATES = "MultilegTranslate";
	public static final String PERMISSION_MULTILEG_EXCLUDES = "MultilegExclude";
	public static final String PERMISSION_MULTILEG_TRIPS = "MultilegTrip";
	public static final String PERMISSION_MULTILEG_IDS = "MultilegId";
	public static final String PERMISSION_MULTILEG_CREATES = "MultilegCreate";
	public static final String PERMISSION_RETURN_DECISIONS = "ReturnDecision";
	public static final String PERMISSION_RETURN_CREATIONS = "ReturnCreation";
	public static final String PERMISSION_MASTER_COMPANY_MASTERS = "Master_Vendors";
	public static final String PERMISSION_MASTER_CUSTOMER_MASTERS = "Master_Customers";

	// eRunsheets aka e-M@te
	public static final String EMATE_DEVICE_USER = "e-M@te Device";
	public static final String EMATE_PORTAL_USER = "e-M@te Portal";

	// DB messages
	public static final String DB_INTEGRITY_CONSTRAINT_VIOLATION_ON_DELETE = "cannot be deleted. Please un-select this type for all personnel.";
	public static final String DB_INTEGRITY_CONSTRAINT_VIOLATION_ON_CREATE = "Could not create record. Record already exists.";

	/*************************************************************************************/
	/** Accounts constants - Accounts Payable, Receivable & UNIBIS related **************/
	/*************************************************************************************/
	public static final String UI_LOG_MODULE_ACCOUNTS_RECEIVABLE_UPLOAD = "AR Upload";
	public static final String UI_LOG_MODULE_ACCOUNTS_PAYABLE_UPLOAD = "AP Upload";
	public static final String UI_LOG_MODULE_ACCOUNTS_RECEIVABLE_UPLOAD_RESET = "AR Upload Reset";
	public static final String UI_LOG_MODULE_ACCOUNTS_PAYABLE_UPLOAD_RESET = "AP Upload Reset";
	public static final String UI_CONFIG_METADATA_ACCOUNTS_RECEIVABLE = "ARState";
	public static final String UI_CONFIG_METADATA_ACCOUNTS_PAYABLE = "APState";
	public static final String SITE_OPTION_EXPORTABLE_ACCOUNTS_RECEIVABLE = "ARExportable";
	public static final String SITE_OPTION_EXPORTABLE_ACCOUNTS_PAYABLE = "APExportable";
	// Accounts Settings Identifiers
	public static final String ACCOUNTS_SETTING_SITES = "Sites";
	public static final String ACCOUNTS_SETTING_STATES = "States";
	public static final String ACCOUNTS_SETTING_STATE_CODES = "StateCodes";
	public static final String ACCOUNTS_SETTING_WAREHOUSE = "Warehouse";
	public static final String ACCOUNTS_SETTING_CUST_TYPE_DIVISION = "CustTypeDivision";
	public static final String ACCOUNTS_SETTING_COMP_TYPE_CONTRACT = "CompTypeContract";
	public static final String ACCOUNTS_SETTING_FIN_WEEK_START = "FinWeekStart";
	public static final String ACCOUNTS_SETTING_FIN_YEAR_START_MONTH = "FinYearStartMonth";
	public static final String ACCOUNTS_SETTING_FIN_YEAR_START_DAY = "FinYearStartDay";
	public static final String ACCOUNTS_SETTING_DEBUG_MODE = "DebugMode";
	public static final String ACCOUNTS_SETTING_SINGLE_STATE = "SingleState";
	// Accounts settings defaults
	public static final String ACCOUNTS_SETTING_DEFAULT_FIN_YEAR_START_MONTH = "7";
	public static final String ACCOUNTS_SETTING_DEFAULT_FIN_YEAR_START_DAY = "1";
	public static final String ACCOUNTS_SETTING_DEFAULT_FIN_WEEK_START_DAY = "1";
	// Accounts file
	public static final String ACCOUNTS_FILE_ELEMENT_SEPARATOR = " ";
	public static final String ACCOUNTS_FILE_ELEMENT_NAME_BATCH_HEADER = "BCH";
	public static final String ACCOUNTS_FILE_DEFAULT_SOURCE_CODE = "0BH";
	public static final String ACCOUNTS_FILE_VOUCHER_HEADER_CODE = "VCH";
	public static final String ACCOUNTS_FILE_JOURNAL_HEADER_CODE = "JNL";
	public static final String ACCOUNTS_FILE_STATUS_NO = "No";
	public static final double GST_RATE = 0.1;
	public static final int ACCOUNTS_FILE_DEFAULT_NUMERIC_VALUE = 0;
	public static final String ACCOUNTS_FILE_DEFAULT_DATE_VALUE = "?";
	public static final String ACCOUNTS_FILE_DEFAULT_STRING_VALUE = "";
	public static final String ACCOUNTS_FILE_DEFAULT_CURRENCY_VALUE = "AUD";
	public static final String ACCOUNTS_FILE_DEFAULT_APPROVAL_INDICATOR = "Y";
	public static final String ACCOUNTS_FILE_TOS_CODE_GST = "GST";
	public static final String ACCOUNTS_FILE_TOS_CODE_NA = "N/A";
	public static final String ACCOUNTS_FILE_TOS_CODE_SAD = "SAD";
	public static final String ACCOUNTS_FILE_TOS_CODE_SAL = "SAL";
	// Accounts formatting
	public static final String ACCOUNTS_UNIBIS_TEXT_FILE_NEW_LINE_CHARS = "\r\n";
	public static final String ACCOUNTS_FORMATTING_DATE_FORMAT_DD_MM_YYYY = "dd/MM/yy";
	public static final String ACCOUNTS_FORMATTING_DECIMAL_FORMAT_CURRENCY = "0.######";
	// Accounts validation
	public static final String ACCOUNTS_VALIDATION_NUMBER_TYPE_INTEGER = "Integer";
	public static final String ACCOUNTS_VALIDATION_NUMBER_TYPE_DECIMAL = "Decimal";

	// Accounts success messages
	public static final String SUCCESS_MSG_ACCTS_RESET_BATCH_COMPLETE = "All sites in Batch No %s have been reset.  "
			+ "The file %s is no longer valid, be sure to delete all copies of it!  The sites that were in batch %s "
			+ "will need to be exported again.";
	public static final String SUCCESS_MSG_ACCTS_RECONCILE_NO_DIFFERENCES_FOUND = 		
			"There were no differences found between site data and warehouse data";
	// Accounts warning messages
	public static final String WARNING_MSG_ACCTS_ELEMENT_TOO_LONG_TRUNCATED =
			"%s too long, truncated";
	public static final String WARNING_MSG_ACCTS_ELEMENT_TOO_SMALL =
			"%s too small";
	public static final String WARNING_MSG_ACCTS_ELEMENT_TOO_LARGE =
			"%s too large";
	public static final String WARNING_MSG_ACCTS_NO_BATCH_SUMMARY =
			"No records obtained for batch summary";
	public static final String WARNING_MSG_ACCTS_NO_INVOICE_METHOD =
			"Customer %s has no specified invoicing method, assuming consolidated";
	public static final String WARNING_MSG_ACCTS_PAYABLE_NO_PAY_ADVICE_DTL =
			"No records obtained for pay advice detail";
	public static final String WARNING_MSG_ACCTS_PAYABLE_FAKE_GL_CODE =
			"GL code set manually.  Once file is created this code cannot be changed";
	public static final String WARNING_MSG_ACCTS_RECEIVABLE_NO_INVOICE_DTL =
			"No records obtained for invoice detail";
	// Accounts error messages
	public static final String ERROR_MSG_ACCTS_ELEMENT_TOO_LONG =
			"%s too long";
	public static final String ERROR_MSG_ACCTS_ELEMENT_TOO_SHORT =
			"%s too short";
	public static final String ERROR_MSG_ACCTS_ELEMENT_NULL =
			"%s cannot be empty";
	public static final String ERROR_MSG_ACCTS_ELEMENT_EMPTY =
			"%s cannot be empty";
	public static final String ERROR_MSG_ACCTS_NO_FILE_LINES =
			"No file lines to validate.";
	public static final String ERROR_MSG_ACCTS_ILLEGAL_TOTAL_LINE_ELEMENTS =
			"Line number \"%s\" has %s elements.  Expected total elements for this line = %s";
	public static final String ERROR_MSG_ACCTS_ILLEGAL_LINE_NAME =
			"Line type id \"%s\" on line %s is unknown";
	public static final String ERROR_MSG_ACCTS_ILLEGAL_ELEMENT_NAME =
			"Element name \"%s\" is unknown";
	public static final String ERROR_MSG_ACCTS_ILLEGAL_DATE_FORMAT =
			"Invalid date format.  Required format: %s";
	public static final String ERROR_MSG_ACCTS_ILLEGAL_NUMBER_FORMAT =
			"Invalid number format.  Required format: %s";
	public static final String ERROR_MSG_ACCTS_EXPORT_REPORT_MISSING_GL_CODE =
			"The CSV report cannot be created until all GL Codes have been entered";
	public static final String ERROR_MSG_ACCTS_EXPORT_REPORT_NULL_REPORT_ID =
			"There was an error retrieving the report data. Please contact support.";
	public static final String ERROR_MSG_ACCTS_EXPORT_REPORT_SERVER_ERROR =
			"There was an error contacting the report server. Please contact support.";
	public static final String ERROR_MSG_ACCTS_NO_BATCH_HEADER_FOUND =
			"Error retrieving records for batch header";
	public static final String ERROR_MSG_ACCTS_DIFFERENT_BATCH_TOTALS =
			"You're trying to recreate a previous batch, but the new Control Total ($%s) "
					+ "is different from the existing one ($%s).  If you wish to export with the "
					+ "new data, you must reset the export flag and create a new batch.";
	public static final String ERROR_MSG_ACCTS_SAVED_GL_CODE_NULL =
			"The GLCode retrieved from DB is null.";
	public static final String ERROR_MSG_ACCTS_INVOICING_METHOD_INVALID =
			"Customer %s has an invalid invoicing method";
	public static final String ERROR_MSG_ACCTS_INVOICING_NO_LINES =
			"Error retrieving records for detailed invoice lines: "
					+ "Invoice ID = %s ApplyTo = %s";
	public static final String ERROR_MSG_ACCTS_NO_SITES_SELECTED =
			"There are no sites selected for %s.  Place a tick next to the sites you "
					+ "wish to %s before trying again.";
	public static final String ERROR_MSG_ACCTS_EXPORT_MULTI_STATE_NOT_ALLOWED =
			"Cannot Export.  You cannot select sites across multiple states for export.  " +
					"Please select sites from only one state for this export batch.";
	public static final String ERROR_MSG_ACCTS_EXPORT_HAS_VALIDATION_ERRORS =
			"The file cannot be created as there are one or more errors in the data.  " +
					"If a GL Code is missing, double-click the problematic line to add one.  All other errors " +
					"must be resolved externally, or the problematic site excluded from the export";
	public static final String ERROR_MSG_ACCTS_PAYABLE_NO_PAY_ADVICES_FOUND =
			"Error retrieving records for pay advice detail";
	public static final String ERROR_MSG_ACCTS_PAYABLE_NO_STATE_SET =
			"Site %s has no state set";
	public static final String ERROR_MSG_ACCTS_PAYABLE_NO_STATE_CODE_SET =
			"No state code set for %s";
	public static final String ERROR_MSG_ACCTS_RECEIVABLE_NO_STATE_CODE_SET =
			"No state code set for %s";
	public static final String ERROR_MSG_ACCTS_RECEIVABLE_NO_INVOICES_FOUND =
			"Error retrieving records for invoice detail";
	public static final String ERROR_MSG_ACCTS_RECEIVABLE_DOC_NO_NULL =
			"The DocNo retrieved from the DB is null.";
	public static final String ERROR_MSG_ACCTS_RECONCILE_NO_DATA_IN_WAREHOUSE_DB = 
			"No data in warehouse for site %s for %s";
	public static final String ERROR_MSG_ACCTS_RECONCILE_NO_DATA_IN_SITES_DB = 
			"No data in site %s for %s";
	public static final String ERROR_MSG_ACCTS_RECONCILE_NO_COST_CODE_IN_WAREHOUSE_DB = 
			"Cost Code is in site data but not in warehouse";
	public static final String ERROR_MSG_ACCTS_RECONCILE_NO_COST_CODE_IN_SITES_DB = 
			"Cost Code is in data warehouse but not in site";
	public static final String ERROR_MSG_ACCTS_RECONCILE_TOTAL_AMOUNT_MISMATCH = 
			"Total amount mismatches between site and warehouse";
	// Export status messages
	public static final String ERROR_MSG_ACCTS_EXPORT_STATUS = 
			"Error retrieving %s export status";
	public static final String WARNING_MSG_ACCTS_EXPORT_STATUS = 
			"%s Export incomplete for week %s";
	public static final String SUCCESS_MSG_ACCTS_EXPORT_STATUS = 
			"%s Export completed for week %s";

	// Accounts receivable
	public static final int ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_INVOICE = 0;
	public static final int ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_ADJUSTMENT = 1;
	public static final int ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_CREDIT_NOTE = 2;
	public static final String ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_CODE_INVOICE = "INV";
	public static final String ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_CODE_ADJUSTMENT = "ADJ";
	public static final String ACCOUNTS_RECEIVABLE_TRANSACTION_TYPE_CODE_CREDIT_NOTE = "CRN";
	public static final String ACCOUNTS_RECEIVABLE_INVOICE_METHOD_ID_CONSOLIDATED = "Consolidated";
	public static final String ACCOUNTS_RECEIVABLE_INVOICE_METHOD_ID_DETAILED = "Detailed";
	// Accounts payable
	public static final int ACCOUNTS_PAYABLE_TRANSACTION_TYPE_VCH = 3;
	// Unibis file element names
	public static final String UNIBIS_FILE_ELEMENT_NAME_INVOICE_HEADER = "Invoice Header";
	public static final String UNIBIS_FILE_ELEMENT_NAME_BATCH_NUMBER = "Batch Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_BATCH_HEADER = "Batch Header";
	public static final String UNIBIS_FILE_ELEMENT_NAME_PERIOD = "Period";
	public static final String UNIBIS_FILE_ELEMENT_NAME_YEAR = "Year";
	public static final String UNIBIS_FILE_ELEMENT_NAME_FOR_DATE = "For Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_CONTROL_TOTAL = "Control Total $";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DIVISION_TABLE_CODE = "Division Table Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_STATUS = "Status";
	public static final String UNIBIS_FILE_ELEMENT_NAME_PROJECT_NUMBER = "Project Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_COST_CODE = "Cost Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_AMOUNT = "Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_GL_CODE = "General Ledger Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DESCRIPTION = "Description";
	public static final String UNIBIS_FILE_ELEMENT_NAME_REFERENCE = "Reference";
	public static final String UNIBIS_FILE_ELEMENT_NAME_TOS_CODE = "GST Type of Service Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_JOURNAL_HEADER = "Journal Header";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DIVISION_TBL_CODE = "Division Table Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_VENDOR = "Vendor";
	public static final String UNIBIS_FILE_ELEMENT_NAME_SOURCE = "Source";
	public static final String UNIBIS_FILE_ELEMENT_NAME_INVOICE_NUMBER = "Invoice Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_INVOICE_DATE = "Invoice Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_INVOICE_AMOUNT = "Invoice Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_FREIGHT_AMOUNT = "Freight Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_MISC_AMOUNT = "Misc Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_TAX_AMOUNT = "Tax Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_PPS_TAX = "PPS Tax";
	public static final String UNIBIS_FILE_ELEMENT_NAME_NON_DISCOUNT_AMOUNT = "Non Discount Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DISCOUNT_PERCENTAGE = "Discount %";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DISCOUNT_DATE = "Discount Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DUE_PERCENTAGE = "Due %";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DUE_DATE = "Due Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_CURRENCY = "Currency";
	public static final String UNIBIS_FILE_ELEMENT_NAME_EXCHANGE_RATE = "Exchange Rate";
	public static final String UNIBIS_FILE_ELEMENT_NAME_APPROVAL_INDICATOR = "Approval Indicator";
	public static final String UNIBIS_FILE_ELEMENT_NAME_BANK_ID = "Bank Id";
	public static final String UNIBIS_FILE_ELEMENT_NAME_CHEQUE_NUMBER = "Cheque Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_CHEQUE_DATE = "Cheque Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DISCOUNT_TAKEN = "Discount Taken";
	public static final String UNIBIS_FILE_ELEMENT_NAME_PO_NUMBER = "Purchase Order Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DIST_TYPE = "Distribution Type";
	public static final String UNIBIS_FILE_ELEMENT_NAME_CUSTOMER_CODE = "Customer Code";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DOC_AMOUNT = "Document Amount";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DOC_DATE = "Document Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DOC_NUMBER = "Document Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_DOC_NUMBER_SUFFIX = "Document Number Suffix";
	public static final String UNIBIS_FILE_ELEMENT_NAME_APPLY_TO_NUMBER = "Apply To Number";
	public static final String UNIBIS_FILE_ELEMENT_NAME_APPLY_TO_NUMBER_SUFFIX = "Apply To Number Suffix";
	public static final String UNIBIS_FILE_ELEMENT_NAME_COMMENT = "Comment";
	public static final String UNIBIS_FILE_ELEMENT_NAME_TODAY_DATE = "Todays Date";
	public static final String UNIBIS_FILE_ELEMENT_NAME_USER_ID = "User ID";
	public static final String UNIBIS_FILE_ELEMENT_NAME_SITES = "Sites";

	/************************/
	/** Geocoder constants **/
	/************************/
    public static final String GEOCODER_APP_ID = "geocoderAppId";
    public static final String GEOCODER_API_KEY = "geocoderApiKey";
    public static final String GEOCODER_BATCH_APP_ID = "geocoderBatchAppId";
    public static final String GEOCODER_BATCH_API_KEY = "geocoderBatchApiKey";
	public static final String GEOCODER_BATCH_URL = "geocoderBatchUrl";
	public static final String GEOCODER_GEOCODE_URL = "geocoderGeocodeUrl";
	public static final String GEOCODER_REVERSE_GEOCODE_URL = "geocoderReverseGeocoderUrl";
	public static final String GEOCODER_ROUTE_URL = "geocoderRouteUrl";

	/************************/
	/** Rating constants **/
	/************************/
	public static final String RUNSHEET_PAY_RATE_GPS_RUNSHEET_KM = "GPSRunsheetKm";
	public static final String RUNSHEET_PAY_RATE_HOURLY_GENERAL = "HourlyGeneral";
	public static final String RUNSHEET_PAY_RATE_HOURLY_GENERAL_WITHOUT_PENALTY = "HourlyGeneralWOPenalty";
	public static final String RUNSHEET_PAY_RATE_HOURLY_STANDARD = "HourlyStandard";
	public static final String RUNSHEET_PAY_RATE_STEPPED_HOURLY_WEEKEND = "SteppedHourlyWeekend";
	public static final String RUNSHEET_PAY_RATE_RUNSHEET_KM = "RunsheetKm";
	public static final String RUNSHEET_PAY_RATE_PER_HOUR = "PerHour";
	public static final String RUNSHEET_PAY_RATE_PER_DAY = "PerDay";
	public static final String RUNSHEET_PAY_RATE_PER_KM = "PerKm";
	public static final String RUNSHEET_PAY_RATE_SHIFT_TIMES = "ShiftTimes";
	public static final String RUNSHEET_PAY_RATE_ZERO_PAY = "ZeroPay";
	public static final String RUNSHEET_PAY_RATE_ZERO = "Zero";
	// Rate explanations
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_STEPPED_HOURLY_RATE = "Stepped Hourly Rate";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_ZERO_PAY = "Zero Pay";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_HOURS = "%s Hours X $%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_SHIFT_TIMES = "%s +%shrs X $%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_SHIFT_TIMES_ALLOWANCES = "%s +$%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_KM = "%s Km X $%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_KM_MIN = "Min %s Km X $%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_KM_MIN_PAY = "Min Pay $%s";
	public static final String RUNSHEET_PAY_RATE_EXPLANATION_KM_ALLOWANCE = "%s + Allowance $%s";
	public static final String EXPLANATION_CASE_PALLET_DROP_NON_RTN_UNIT = "%s +%s %s";
	public static final String EXPLANATION_CASE_PALLET_DROP_RTN_1 = "%s (-%s)";
	public static final String EXPLANATION_CASE_PALLET_DROP_RTN_2 = "%s X $%s";
	public static final String EXPLANATION_CASE_RANGE = "%s %s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_CASE_1 = "Minimum %s";
	public static final String EXPLANATION_PER_CASE_2 = "%s Cases X $%s";
	public static final String EXPLANATION_PER_HOUR_1 = "Min %s Hours X $%s";
	public static final String EXPLANATION_PER_HOUR_2 = "%s Hours X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_KM_1 = "%s Km X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_KM_2 = "%s +%s Drops >%s X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_KM_3 = "%s +$%s (Own Trailer)";
	public static final String RATING_EXPLANATION_PER_LOAD_1 = "Load rate $%s";
	public static final String RATING_EXPLANATION_PER_LOAD_2 = "%s Loads X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PAY_ZERO = "Pay Zero";
	public static final String EXPLANATION_HIGHEST_UNIT = "Highest Unit: %s | %s x $%s";
	public static final String RATING_EXPLANATION_PER_MINUTE_1 = "Min %s Minutes X $%s";
	public static final String RATING_EXPLANATION_PER_MINUTE_2 = "%s Minutes X $%s";
	public static final String EXPLANATION_PER_TONNE_1 = "Min %s Tonnes";
	public static final String EXPLANATION_PER_TONNE_2 = "%s Tonnes";
	public static final String EXPLANATION_PER_TONNE_3 = "Min %s $%s";
	public static final String EXPLANATION_PER_TONNE_4 = "%s X $%s";
	public static final String EXPLANATION_TONNE_RANGE_1 = "%s Zero Tonnes";
	public static final String EXPLANATION_TONNE_RANGE_2 = "%s $%s";
	public static final String EXPLANATION_TONNE_RANGE_3 = "%s + %s Tonnes X $%s";
	public static final String EXPLANATION_TONNE_RANGE_4 = "%s (%s-%s range)";
	public static final String EXPLANATION_TONNE_RANGE_5 = "%s (Incl Cont)";
	public static final String EXPLANATION_PER_PALLET_1 = "Min %s";
	public static final String EXPLANATION_PER_PALLET_2 = "%s Pallets X $%s (Own Trailer)";
	public static final String EXPLANATION_PER_PALLET_3 = "%s Pallets X $%s";
	public static final String EXPLANATION_PER_SPACE_1 = "Min %s";
	public static final String EXPLANATION_PER_SPACE_2 = "%s Spaces X $%s (Own Trailer)";
	public static final String EXPLANATION_PER_SPACE_3 = "%s Spaces X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_1 = "Sunday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_2 = "%s %s X Sunday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_3 = "Saturday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_4 = "%s %s X Saturday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_5 = "Weekday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_DAY_6 = "%s %s X Weekday Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_TLR_1 = "Load rate $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_TLR_2 = "%s Loads X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_TLR_3 = "%s +%s Pallets X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_TLR_4 = "%s +$%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_LOAD_TLR_5 = "%s +%s Drops >%s X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_1 = "%s Pallets (Min %s) X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_2 = "%s Cages (Min %s) X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_3 = "%s %s Pallets (Min %s) X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_4 = "%s Pallets X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_5 = "%s +%s Cages X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PALLET_CAGE_6 = "%s +$%s (Own Trailer)";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_ZERO_PALLETS = "Zero Pallets";
	public static final String EXPLANATION_UNIT_SCALE_1 = "Zero %s";
	public static final String EXPLANATION_UNIT_SCALE_2 = "%s-%s %s range";
	public static final String EXPLANATION_UNIT_SCALE_3 = "%s +%s %s X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_FLAT_PLUS_UNIT_2 = "%s($%s@Min %s %s)";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_FLAT_PLUS_UNIT_3 = "%s+%s %s X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_FLAT_PLUS_UNIT_4 = "%s(%s-%s range)";
	public static final String EXPLANATION_UNIT_ZERO_UNIT = "Zero %s";
	public static final String EXPLANATION_UNIT_PLUS_ZERO_UNIT = "%s +Zero %s";
	public static final String EXPLANATION_UNIT_UNKNOWN_RATE = "%sUnknown rate";
	public static final String EXPLANATION_UNIT_RANGE_UNIT = "%s +%s %s X $%s";
	public static final String EXPLANATION_UNIT_RANGE_1 = "%s%s %s X $%s";
	public static final String EXPLANATION_UNIT_RANGE_2 = "%s +$%s";
	public static final String EXPLANATION_UNIT_RANGE_3 = "%s (%s-%s range)";
	public static final String EXPLANATION_UNIT_RANGE_X2_1 = "%sUnknown range (Unit %s)";
	public static final String EXPLANATION_UNIT_RANGE_X2_2 = "%s +%s %s X $%s";
	public static final String EXPLANATION_PER_UNIT_1 = "%s +Min %s %s X $%s";
	public static final String EXPLANATION_PER_UNIT_2 = "%s +%s %s X $%s";
	public static final String RUNSHEET_PAY_LINE_EXPLANATION_PER_UNIT_3 = "%s +$%s";
	public static final String EXPLANATION_PER_UNIT_4 = "Min %s $%s";
	public static final String TRIP_RATE_EXPLANATION_2 = "$%s (Trip $%s)";
	public static final String TRIP_RATE_EXPLANATION_1 = "%s (Trip $%s)";
	public static final String STOP_BONUS_D_EXPLANATION_PER_TRIP = "%s + (%s stp x $%s)";
	public static final String TRIP_RATE_EXPLANATION_UNIT_PER_TRIP_1 = "%sMin.";
	public static final String TRIP_RATE_EXPLANATION_UNIT_PER_TRIP_2 = "%s%s %s x $%s)";
	public static final String TRIP_RATE_EXPLANATION_UNIT_PER_TRIP_3 = "Min. $%s";
	public static final String TRIP_RATE_EXPLANATION_BS_ALLOWANCED_UNIT_PER_TRIP_1 = "%s + (%s %s x $%s)";
	public static final String TRIP_RATE_EXPLANATION_POINT_KM_1 = "Point-Point-KM %s X $%s";
	public static final String TRIP_RATE_EXPLANATION_POINT_KM_2 = "%s (Incl. Return to %s)";
	public static final String DEFAULT_EXPLANATION = "";
	public static final String RATE_TYPE_PAY = "pay";
	public static final String RATE_TYPE_CHARGE = "charge";
	public static final String SERVICE_CHARGE_EXPLANATION_PER_UNIT_1 = "Flat rate $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_CHARGE_ZERO = "Zero Charge";
	public static final String SERVICE_CHARGE_EXPLANATION_SERVICE_STATION = "%s + %st %s X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_RANGE_1 = "%s $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_RANGE_2 = "%s + %s Pallets X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_RANGE_3 = "%s (%s-%s range)";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_0 = "%s %s (Min %s) X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_1 = "%s %s (Min %s) X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_2 = "%s Zero %s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_3 = "%s + %s %s X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_4 = "%s + %s Drops > %s X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_PALLET_CAGE_5 = "%s %s X $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_DRIVER_COST_0 = "%s + $%s (%s)";
	public static final String SERVICE_CHARGE_EXPLANATION_DRIVER_COST_1 = "$%s";
	public static final String SERVICE_CHARGE_EXPLANATION_DRIVER_COST_2 = "%s = $%s";
	public static final String SERVICE_CHARGE_EXPLANATION_DRIVER_COST_3 = "%s + %s%%";
	public static final String SERVICE_CHARGE_EXPLANATION_DRIVER_COST_4 = "%s + $%s";

	// Shift descriptions
	public static final String RUNSHEET_PAY_RATE_SHIFT_NIGHT = "Night";
	public static final String RUNSHEET_PAY_RATE_SHIFT_DAY = "Day";
	public static final String RUNSHEET_PAY_RATE_SHIFT_ARVO = "Arvo";
	// Formatting
	public static final String DECIMAL_FORMAT_3_DPS = "0.###";
	public static final String DECIMAL_FORMAT_6_DPS = "0.######";
	// Trip
	public static final String TRIP_RATE_UNIT_PER_TRIP = "UnitPerTrip";
	public static final String TRIP_RATE_PER_TRIP = "PerTrip";
	public static final String TRIP_RATE_UNIT_PER_TRIP_STP_ALLOW = "UnitPerTripStpAllow";
	public static final String TRIP_RATE_UNIT_PER_TRIP_STP_ALLOW_NG = "UnitPerTripStpAllowNG";
	public static final String TRIP_RATE_POINT_TO_POINT_KM = "PointToPointKM";
	public static final String TRIP_RATE_POINT_TO_POINT_KM_W_RETURN = "PointToPointKMwReturn";
	public static final String TRIP_RATE_UNIT_RANGE = "UnitRange";
	// Runsheet Line
	public static final String LINE_RATE_CASE_RANGE = "CaseRange";
	public static final String LINE_RATE_PER_UNIT = "PerUnit";
	public static final String LINE_RATE_UNIT_RANGE = "UnitRange";
	public static final String LINE_RATE_UNIT_RANGE_X2= "UnitRangeX2";
	public static final String LINE_RATE_UNIT_SCALE =  "UnitScale";
	public static final String LINE_RATE_PER_PALLET = "PerPallet";
	public static final String LINE_RATE_PER_SPACE = "PerSpace";
	public static final String LINE_RATE_PER_CASE = "PerCase";
	public static final String LINE_RATE_PER_TONNE = "PerTonne";
	public static final String LINE_RATE_TONNE_RANGE = "TonneRange";
	public static final String LINE_RATE_PALLET_RANGE = "PalletRange";
	public static final String LINE_RATE_PER_LOAD = "PerLoad";
	public static final String LINE_RATE_PER_HOUR = "PerHour";
	public static final String LINE_RATE_PER_MINUTE = "PerMinute";
	public static final String LINE_RATE_PER_LOAD_TLR = "PerLoadTlr";
	public static final String LINE_RATE_PER_KM = "PerKm";
	public static final String LINE_RATE_PALLET_CAGE = "PalletCage";
	public static final String LINE_RATE_CASE_DROP = "CaseDrop";
	public static final String LINE_RATE_PALLET_DROP = "PalletDrop";
	public static final String LINE_RATE_ZERO_PAY = "ZeroPay";
	public static final String LINE_RATE_ZERO = "Zero";
	public static final String LINE_RATE_HIGHEST_UNIT = "HighestUnit";
	public static final String LINE_RATE_FLAT_PLUS_UNIT = "FlatPlusUnit";
	public static final String LINE_RATE_PER_LOAD_DAY = "PerLoadDay";
	// Service
	public static final String SERVICE_RATE_PALLET_CAGE = "PalletCage";
	public static final String SERVICE_RATE_DRIVER_COST = "DriverCost";
	public static final String SERVICE_RATE_CASE_RANGE = "CaseRange";
	public static final String SERVICE_RATE_PER_UNIT = "PerUnit";
	public static final String SERVICE_RATE_UNIT_RANGE = "UnitRange";
	public static final String SERVICE_RATE_UNIT_RANGE_X2 = "UnitRangeX2";
	public static final String SERVICE_RATE_UNIT_SCALE = "UnitScale";
	public static final String SERVICE_RATE_PER_PALLET = "PerPallet";
	public static final String SERVICE_RATE_PER_SPACE = "PerSpace";
	public static final String SERVICE_RATE_PER_CASE = "PerCase";
	public static final String SERVICE_RATE_PER_TONNE = "PerTonne";
	public static final String SERVICE_RATE_TONNE_RANGE = "TonneRange";
	public static final String SERVICE_RATE_PALLET_RANGE = "PalletRange";
	public static final String SERVICE_RATE_SERVICE_STN = "ServiceStn";
	public static final String SERVICE_RATE_PER_LOAD = "PerLoad";
	public static final String SERVICE_RATE_PER_HOUR = "PerHour";
	public static final String SERVICE_RATE_PER_MINUTE = "PerMinute";
	public static final String SERVICE_RATE_CASE_DROP = "CaseDrop";
	public static final String SERVICE_RATE_PALLET_DROP = "PalletDrop";
	public static final String SERVICE_RATE_ZERO_CHARGE = "ZeroCharge";
	public static final String SERVICE_RATE_ZERO = "Zero";
	public static final String SERVICE_RATE_HIGHEST_UNIT = "HighestUnit";

	// Unit types
	public static final String UNIT_TYPE_VOLUME = "Volume";
	public static final String UNIT_TYPE_TONNES = "Tonnes";
	public static final String UNIT_TYPE_LOADS = "Loads";
	public static final String UNIT_TYPE_KM = "Km";
	public static final String UNIT_TYPE_HOURS = "Hours";
	public static final String UNIT_TYPE_MINUTES = "Minutes";
	public static final String UNIT_TYPE_PALLETS = "Pallets";
	public static final String UNIT_TYPE_SPACES = "Spaces";
	public static final String UNIT_TYPE_CASES = "Cases";
	public static final String UNIT_TYPE_DROPS = "Drops";
	public static final String UNIT_TYPE_CAGES = "Cages";
	public static final String UNIT_TYPE_RTN_PALLETS = "Rtn Pallets";
	public static final String UNIT_TYPE_RTN_CASES = "Rtn Cases";
	public static final String UNIT_TYPE_RTN_DROPS = "Rtn Drops";
	public static final String UNIT_TYPE_ULP = "ULP";
	public static final String UNIT_TYPE_PREM_ULP = "PremULP";
	public static final String UNIT_TYPE_LRP = "LRP";
	public static final String UNIT_TYPE_DIESEL = "Diesel";

	// Case ranges
	public static final String CASE_RANGE_1_TO_9 = "(1-9 range)";
	public static final String CASE_RANGE_10_TO_19 = "(10-19 range)";
	public static final String CASE_RANGE_20_TO_29 = "(20-29 range)";
	public static final String CASE_RANGE_30_TO_39 = "(30-39 range)";
	public static final String CASE_RANGE_40_TO_47 = "(40-47 range)";
	public static final String CASE_RANGE_48_TO_59 = "(48-59 range)";
	public static final String CASE_RANGE_60_TO_71 = "(60-71 range)";
	public static final String CASE_RANGE_72_TO_95 = "(72-95 range)";
	public static final String CASE_RANGE_96_TO_119 = "(96-119 range)";
	public static final String CASE_RANGE_120_TO_143 = "(120-143 range)";
	public static final String CASE_RANGE_144_TO_191 = "(144-191 range)";
	public static final String CASE_RANGE_192_TO_239 = "(192-239 range)";
	public static final String CASE_RANGE_240_PLUS = "(240+ range)";
	/************************/
	/** Currency constants **/
	/************************/
	public static final int DEFAULT_CURRENCY_DECIMAL_PLACES = 2;

	/********************/
	/** Time constants **/
	/********************/
	public static final double MINUTES_PER_HOUR_DOUBLE = 60d;
	public static final int MINUTES_PER_HOUR = 60;
	public static final double MILLIS_PER_HOUR_DOUBLE = 3600000d;
	public static final int MILLIS_PER_HOUR = 3600000;
	public static final double MILLIS_PER_MINUTE_DOUBLE = 60000d;
	public static final int MILLIS_PER_MINUTE = 60000;
	public static final double MILLIS_PER_DAY_DOUBLE = 86400000d;
	public static final int MILLIS_PER_DAY = 86400000;

	/*******************************/
	/** Rate completion constants **/
	/*******************************/

	// Completion error messages
	public static final String RC_ERROR_HDR_MANUAL_LOAD_COMPLETION = 
			"Load Completion";
	public static final String RC_ERROR_MSG_MANUAL_LOAD_COMPLETION = 
			"Load Completion failed for at least one load.";

	public static final String RC_ERROR_HDR_MANUAL_RUNSHEET_COMPLETION_NOT_ALLOWED = 
			"Manual Runsheet Completion";
	public static final String RC_ERROR_MSG_MANUAL_RUNSHEET_COMPLETION_NOT_ALLOWED = 
			"Sorry, you cannot complete runsheet %s because manual runsheet completion has been disabled.  "
					+ "If you believe this is incorrect, please advise your system administrator.";

	public static final String RC_ERROR_HDR_COMPLETION_NOT_ALLOWED = 
			"Completion Disabled by Axiom Support";
	public static final String RC_ERROR_MSG_COMPLETION_NOT_ALLOWED = 
			"Completions at this site have been disabled.  Please contact Axiom Support.  Completions are "
					+ "usually disabled to allow for rate updates and maintenance.  This is controlled by the Axiom "
					+ "Support team on a site-by-site basis.";

	public static final String RC_ERROR_HDR_COMPLETION_HOLD_CODE_RAISED = 
			"Runsheet Completion";
	public static final String RC_ERROR_MSG_COMPLETION_HOLD_CODE_RAISED = 
			"Sorry, the runsheet %s cannot be completed.%s. A hold code of %s was "
					+ "raised during the last completion attempt.";

	public static final String RC_ERROR_HDR_COMPLETION_LOCKED_RECORDS = 
			"Locked Records";
	public static final String RC_ERROR_MSG_COMPLETION_LOCKED_RECORDS = 
			"Sorry, the runsheet cannot be completed at this time because one or more constituent services "
					+ "are locked for editing by another user.  Please try again in a few minutes.";

	public static final String RC_ERROR_HDR_COMPLETION_HAS_PAY_ADVICE_LINES = 
			"Completion";
	public static final String RC_ERROR_MSG_COMPLETION_HAS_PAY_ADVICE_LINES = 
			"Sorry, the runsheet %s couldn't be completed because there are already one or more pay "
					+ "advice lines for this runsheet.  Please contact your supervisor or Business Solutions "
					+ "via axiom@toll.com.au or the IT Helpdesk to resolve this issue.";

	public static final String RC_ERROR_HDR_COMPLETION_FATAL = 
			"Runsheet Completion";
	public static final String RC_ERROR_MSG_COMPLETION_FATAL = 
			"Completion of runsheet %s has failed!!  The following fatal SQL error has occurred: %s";

	public static final String RC_ERROR_HDR_COMPLETION_RUNSHEET_KPIS = 
			"Runsheet Completion";
	public static final String RC_ERROR_MSG_COMPLETION_RUNSHEET_KPIS = 
			"Completion of runsheet %s has failed!!  Fatal error calculating runsheet KPIs";

	public static final String SC_ERROR_HDR_COMPLETE_SERVICE = "Service Completion";
	public static final String SC_ERROR_MSG_COMPLETE_SERVICE = "Sorry, not all service(s) will be completed. "
			+ "Invoice lines have been found in the system for one or more incomplete services. "
			+ "Please report this issue to help desk or your system administrator so it can be corrected.";

	public static final String SC_ERROR_MSG_ENTITY_COMPLETION_RESULT = "Completed %s of %s %s attempted";

	public static final String SC_ERROR_HDR_SERVICE_VERIFICATION = "Service Verification";
	public static final String SC_ERROR_MSG_SERVICE_VERIFICATION_SUCCESS = "The service %s will complete successfully.";
	public static final String SC_ERROR_MSG_SERVICE_VERIFICATION_FAIL = "Sorry, the service %s cannot be completed. "
			+ "A hold code of %s was raised during verification.";

	// Completion success messages
	public static final String RC_SUCCESS_HDR_RUNSHEET_COMPLETION = 
			"Runsheet Completion";
	public static final String RC_SUCCESS_MSG_RUNSHEET_COMPLETION = 
			"The runsheet %s was completed successfully.";

	// Completion result messages
	public static final String RC_COMPLETION_RESULT_MSG_DEFAULT = "";
	public static final String RC_COMPLETION_RESULT_MSG_NO_RUNSHEET = 
			"Runsheet cannot be found.";
	public static final String RC_COMPLETION_RESULT_MSG_LOCKED = 
			"Locked";
	public static final String RC_COMPLETION_RESULT_MSG_RUNSHEET_ON_HOLD = 
			"Runsheet is on hold";
	public static final String RC_COMPLETION_RESULT_MSG_PAY_LINES = 
			"PayLines";
	public static final String RC_COMPLETION_RESULT_MSG_NO_RUNSHEET_LINES = 
			"No Runsheet Lines present";
	public static final String RC_COMPLETION_RESULT_MSG_DRIVER_NOT_SPECIFIED = 
			"Driver not specified";
	public static final String RC_COMPLETION_RESULT_MSG_DELIVERY_DATE_NOT_SPECIFIED = 
			"Delivery date not specified";
	public static final String RC_COMPLETION_RESULT_MSG_START_END_TIMES_NOT_SPECIFIED = 
			"Start/End times not specified";
	public static final String RC_COMPLETION_RESULT_MSG_START_END_KMS_NOT_SPECIFIED = 
			"Start/End kilometres not specified";
	public static final String RC_COMPLETION_RESULT_MSG_START_END_KMS_SWAPPED =
			"Start/End kilometres are around the wrong way";
	public static final String RC_COMPLETION_RESULT_MSG_RS_KM_EXCEEDS_MAX =
			"Runsheet KM exceeds maximum allowed";
	public static final String RC_COMPLETION_RESULT_MSG_DRIVER_PAY_NOT_CALCULATED =
			"Driver pay not calculated";
	public static final String RC_COMPLETION_RESULT_MSG_ZERO_PAY_NOT_ALLOWED =
			"Zero pay not allowed";
	public static final String RC_COMPLETION_RESULT_MSG_QTY_MISSING =
			"Qty Missing";
	public static final String RC_COMPLETION_RESULT_MSG_TRUCK_NOT_SPECIFIED =
			"Truck not specified";
	public static final String RC_COMPLETION_RESULT_MSG_SERVICES =
			"Services";
	public static final String RC_COMPLETION_RESULT_MSG_RMM_VALIDATION_FAILED =
			"Runsheet Matching Module failed to validate the runsheet";
	public static final String RC_COMPLETION_ERROR_KPI_SAVE_FAILED = 
			"An error occurred calculating KPIs for runsheet %s.  Runsheet completion will continue normally, "
					+ "but KPIs for this runsheet will not show up in reports.";

	// Logging
	public static final String RC_COMPLETION_LOG_MSG_RUNSHEET_ON_HOLD = "Error:Runsheet on hold";
	public static final String RC_COMPLETION_LOG_MSG_PAY_LINES = "Error: Already some pay advice lines";
	public static final String RC_COMPLETION_LOG_MSG_PAY_ADVICE_INSERT_FAILED = "Error:Pay advice insert failed";
	public static final String RC_COMPLETION_LOG_MSG_RUNSHEET_KPI_CALC_FAILED = "Error:Runsheet KPI calculation failed";
	public static final String RC_COMPLETION_LOG_MSG_RUNSHEET_INSERT_FAILED = "Error:Runsheet insert failed";
	public static final String RC_COMPLETION_LOG_MSG_TOO_MANY_PAY_LINES = "Error:Too many pay lines";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_START = "RUNSHEET-COMPLETION-START";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_STOP = "RUNSHEET-COMPLETION-STOP";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_FINISH = "RUNSHEET-COMPLETION-FINISH";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_FORMAT_1 = "%s,%s,%s,%s";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_FINISH_CALC_LOAD_FORMAT = "%s,%s,%s";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_REASON_FORMAT = "%s,%s,%s,%s,%s";
	public static final String RC_COMPLETION_LOG_EVENT_DESC_HOLDCODE_FORMAT = "%s,%s,%s,%s,HoldCode:%s";
	// Hold Codes
	public static final String RUNSHEET_HOLDCODE_DEFAULT = "";
	public static final String RUNSHEET_HOLDCODE_RUNSHEET_LINES = "RunsheetLines";
	public static final String RUNSHEET_HOLDCODE_DRIVER = "Driver";
	public static final String RUNSHEET_HOLDCODE_DELIVERY_DATE = "DeliveryDate";
	public static final String RUNSHEET_HOLDCODE_START_END_TIME = "StartEndTime";
	public static final String RUNSHEET_HOLDCODE_START_END_KM = "StartEndKM";
	public static final String RUNSHEET_HOLDCODE_START_END_KM_SWAPPED = "StartEndKMSwapped";
	public static final String RUNSHEET_HOLDCODE_RS_KM_EXCEEDS_MAX = "RSKM";
	public static final String RUNSHEET_HOLDCODE_DRIVER_PAY_NOT_CALCULATED = "Pay";
	public static final String RUNSHEET_HOLDCODE_ZERO = "Zero";
	public static final String RUNSHEET_HOLDCODE_QTY_MISSING = "Qty Missing";
	public static final String RUNSHEET_HOLDCODE_TRUCK = "Truck";
	public static final String RUNSHEET_HOLDCODE_SERVICES = "Services";
	public static final String RUNSHEET_HOLDCODE_RMM_VALIDATION = "RMMValidation";
	public static final String RUNSHEET_HOLDCODE_RUNSHEET_HOLD = "RunsheetHold";
	public static final String RUNSHEET_HOLDCODE_TRIP_COMPLETION = "TripCompletion";

	// RMM Validation
	public static final String RC_RMM_VALIDATION_OPT_VAL_DISABLED = "Disabled";
	public static final String RC_RMM_VALIDATION_OPT_VAL_ENABLED = "Enabled";
	public static final String RC_RMM_VALIDATION_OPT_VAL_PROMPTED = "Prompted";
	public static final String RC_RMM_VALIDATION_OPT_VAL_REQUIRED = "Required";

	public static final String DATASOURCE_MANUAL_COMPLETION = "MC";
	public static final String DATASOURCE_AUTO_COMPLETION = "AC";

	public static final String COMPANY_TYPE_TOLL = "Toll";
	public static final String COMPANY_TYPE_AGENCY = "Agency";
	public static final String COMPANY_TYPE_CONTRACTOR = "Contractor";

	/*************************/
	/** BSS SICLI constants **/
	/*************************/
	public static final String BSS_SICLI_MODE = "a2SicliMode";
	public static final String BSS_SICLI_MODE_MULTILEG_ONLY_0 = "IM0";
	public static final String BSS_SICLI_MODE_MULTILEG_ONLY_1 = "IM1";
	public static final String BSS_SICLI_MODE_AUTO_DESPATCH = "/D";
	public static final String BSS_SICLI_ENABLED = "a2SicliEnabled";
	public static final String BSS_SICLI_VALIDATION_MODE_EXIST = "E";
	public static final Integer BSS_SICLI_IMPORTED_SUCCCESS = -1;
	public static final Integer BSS_SICLI_IMPORTED_FAILURE = -2;

	/******************************************************/
	/** Service Type RUNSHEETCALC method types constants **/
	/******************************************************/
	public static final String SERVICE_TYPE_RUNSHEET_CALC_HOURS = "Hours";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_MINUTES = "Minutes";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_VOLTRAILER = "VolTrailer";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_VOLTRUCK = "VolTruck";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_VOLTRUCKNTRAILER = "VolTruckNTrailer";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_VOLGLOBAL = "VolGlobal";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_DAYHOURS = "DayHours";
	public static final String SERVICE_TYPE_RUNSHEET_CALC_ESP = "ESP";


	/**
	 * Leopard Event Constants
	 */
	public static final String LEOPARD_SIGNATURE = "LSGN";
	public static final String LEOPARD_USER_ID = "Leopard";
	public static final String LEOPARD_DATASOURCE_ID = "ED";
	public static final String LEOPARD_DATASOURCE_ID_DR = "DR";
	public static final String LEOPARD_MESSAGE_ROOT_ELEMENT_NAME_MSG = "MSG";
	public static final String LEOPARD_MESSAGE_EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
	public static final String LEOPARD_RECONNECT_LOGIN_MESSAGE = "Reconnect Login Message";
	public static final String SESSION_STATUS_VEHICLE_CHANGED = "Vehicle Changed";
	public static final String SESSION_STATUS_TRAILER_CHANGED = "Trailer Changed";

	/**
	 * Internal Event Queue Constants
	 */
	public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_DO_DESPATCH = 1;
	public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_UNDO_DESPATCH = 2;
	public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_TEXT_MESSAGE = 4;
	public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_RESEND_TRIPS = 5;
    public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_CREATE_USER = 6;
    public static final int IEQ_OUTBOUND_EVENT_TYPE_ID_UPDATE_USER = 7;

	/**
	 * LED Action status'
	 */
	public static final String LED_DEFAULT_ACTION_STATUS = "ACC";
	public static final String LED_ARRIVE_ACTION_STATUS = "OST";
	public static final String LED_COMPLETE_ACTION_STATUS = "DEP";
	public static final String LED_DEPART_ACTION_STATUS = "CPL";

	public static final String LED_NEW_LINE_CHARS = "\r\n";
	public static final String DETAILS_KEY_TRIP_ID = "TripId";
	public static final String DETAILS_KEY_LOCATION_ID = "LocationId";
	public static final String DETAILS_KEY_SITE_ID = "SiteId";
	public static final String DETAILS_KEY_DRIVER_ID = "DriverId";

	/**
	 * Oracle error codes
	 */
	public static final String ORACLE_PRIMARY_KEY_ERROR = "ORA-00001";

    /******************************************************/
    /** Track and Trace constants **/
    /******************************************************/

    public static final String TT_RESOURCE_TYPE_TRUCK = "TRUCK";
    public static final String TT_RESOURCE_TYPE_TRAILER = "TRAILER";	
}
