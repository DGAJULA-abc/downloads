package au.com.tollgroup.a2.sicli.util.constants;

/**
 * Place holder for defining all the constants related to the DB model
 *
 * @author mahilalh
 *
 */
@Deprecated
public class DBModelConstants {

}
