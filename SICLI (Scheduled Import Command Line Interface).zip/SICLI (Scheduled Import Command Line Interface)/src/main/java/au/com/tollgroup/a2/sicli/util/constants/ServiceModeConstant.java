package au.com.tollgroup.a2.sicli.util.constants;


public class ServiceModeConstant {
	
	public final static String kValidationModeExist ="E";
    public final static String kValidationModeAmcor ="A";
    public final static String kValidationModeCreate="C";
    public final static String kValidationModeCreateIfNull="N";
    public final static String kValidationModeNotExist="X";
    public final static String kValidationModeNullIfMissing="M";
    public final static String kValidationModeRecycle="G";
    public final static String kValidationModeUpdate="U";

}

