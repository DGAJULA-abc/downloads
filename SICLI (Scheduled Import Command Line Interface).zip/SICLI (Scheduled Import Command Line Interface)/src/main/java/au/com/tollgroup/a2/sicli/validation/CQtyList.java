package au.com.tollgroup.a2.sicli.validation;

import java.util.ArrayList;
import java.util.List;

import au.com.tollgroup.a2.sicli.model.ImpServiceTO;
import au.com.tollgroup.a2.sicli.model.ServiceTypeTO;
import au.com.tollgroup.a2.sicli.validation.*;

public class CQtyList {

	List<String> pQty = new ArrayList<>();
	List<String> PUnit = new ArrayList<>();
	String pExtra = "";

	public void InitWithRS(List<ServiceTypeTO> serviceTypeTos) {
		// Add null to the list for each element
		for (int i = 0; i < 8; i++) {
			pQty.add(null);
		}

		for (ServiceTypeTO serviceTypeTO : serviceTypeTos) {

			PUnit.add(checkNull(serviceTypeTO.getUNIT1(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT2(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT3(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT4(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT5(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT6(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT7(), ""));
			PUnit.add(checkNull(serviceTypeTO.getUNIT8(), ""));
		}

	}

	public void ReadFromRS(ImpServiceTO rs, boolean includeExtra) {
		int i, j;
		for (i = 0; i < 8; i++) {
			for (j = 0; j < 8; j++) {
				String unitJ = "rs.getUnit" + (j + 1);
				String unitI = "rs.getUnit" + (i + 1);
				if (checkNull(unitJ, "").equals(checkNull(unitI, ""))) {
					String Qty = "rs.getQty" + (i + 1);
					pQty.set(i, Qty);
				}
			}
		}

		if (includeExtra) {
//			pExtra = nvl(rs.getQtyExtra(), "");
			pExtra = "";
		}
	}

	public String checkNull(String value, String nullValue) {
		if (value == null) {
			return nullValue;
		}
		return value;
	}

}
