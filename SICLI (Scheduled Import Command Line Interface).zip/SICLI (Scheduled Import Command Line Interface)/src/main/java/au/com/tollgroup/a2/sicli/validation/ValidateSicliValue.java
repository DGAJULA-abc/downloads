package au.com.tollgroup.a2.sicli.validation;

import static au.com.tollgroup.a2.sicli.util.BSSSicliUtil.mBoolIf;
import static au.com.tollgroup.a2.sicli.util.BSSSicliUtil.mDateIfAsLong;
import static au.com.tollgroup.a2.sicli.util.BSSSicliUtil.mDoubleIf;
import static au.com.tollgroup.a2.sicli.util.BSSSicliUtil.mIntIf;
import static au.com.tollgroup.a2.sicli.util.BSSSicliUtil.mStringIf;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.tollgroup.a2.sicli.util.constants.ApplicationConstants;
import au.com.tollgroup.a2.sicli.util.constants.ServiceModeConstant;
import au.com.tollgroup.a2.silci.service.StandardAxiomImport;
import ch.qos.logback.core.util.TimeUtil;
import oracle.jdbc.OracleDatabaseException;
import au.com.tollgroup.a2.sicli.dao.SicliImportDAO2;
import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.PropertiesTO;
import au.com.tollgroup.a2.sicli.model.ResourceResultTO;
import au.com.tollgroup.a2.sicli.model.TripResultTO;
import au.com.tollgroup.a2.sicli.model.CompanyTO;
import au.com.tollgroup.a2.sicli.model.ContainerTO;
import au.com.tollgroup.a2.sicli.model.CustomerTO;
import au.com.tollgroup.a2.sicli.model.DriverResourceTO;
import au.com.tollgroup.a2.sicli.model.ImpLoadTO;
import au.com.tollgroup.a2.sicli.model.ImpServiceTO;
import au.com.tollgroup.a2.sicli.model.LoadResultTO;
import au.com.tollgroup.a2.sicli.model.LoadTO;
import au.com.tollgroup.a2.sicli.model.LocationTO;
import au.com.tollgroup.a2.sicli.model.ServiceTO;
import au.com.tollgroup.a2.sicli.model.ServiceTypeTO;
import au.com.tollgroup.a2.sicli.model.TrailerResourceTO;
import au.com.tollgroup.a2.sicli.model.TripTO;
import au.com.tollgroup.a2.sicli.model.TruckResourceTO;
import au.com.tollgroup.a2.sicli.model.ValidationResultTO;
import au.com.tollgroup.a2.sicli.util.ImpJobLogTO;
import au.com.tollgroup.a2.sicli.util.SicliValidTable;
import au.com.tollgroup.a2.sicli.util.*;
import au.com.tollgroup.a2.sicli.dao.*;

@Service
public class ValidateSicliValue extends AbstractDAO {

	private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SicliImportDAO2 sicliImportDAO;

	@Autowired
	private DataSource dataSource;

	CQtyList cqtylist = new CQtyList();

	public boolean verifyServiceProcessing(ImpServiceTO impservice, ImpJobLogTO jobLog) throws NotImplementedException {

		String validateService = impservice.getValidateService();
		Long serviceId = impservice.getImportServiceId();

		if (validateService == null)
			validateService = ServiceModeConstant.kValidationModeExist;

		if (validateService.equalsIgnoreCase(ServiceModeConstant.kValidationModeNotExist)
				|| validateService.equalsIgnoreCase(ServiceModeConstant.kValidationModeAmcor)) {

		} else if (validateService.equalsIgnoreCase(ServiceModeConstant.kValidationModeExist)) {
			if (serviceId == null) {
				jobLog.addError("Service required for routing");
				rejectImpServiceRecord(impservice, jobLog);
				return false;
			}
		} else {
			jobLog.addError("Service validation; unknown validation mode: ");
			rejectImpServiceRecord(impservice, jobLog);
			return false;
		}
		return true;
	}

	public void rejectImpServiceRecord(ImpServiceTO svc, ImpJobLogTO jobLog) throws NotImplementedException {
		if (svc == null) {
			return;
		}
		jobLog.incrementFailCount();
		String lastErrorText = "";
		if (jobLog != null) {
			lastErrorText = jobLog.getLastError();
		}

		int errorTextSizeLimit = 50;
		if (lastErrorText != null && lastErrorText.length() > errorTextSizeLimit) {
			lastErrorText = lastErrorText.substring(0, errorTextSizeLimit);
		}
		svc.setImportError(lastErrorText);
		svc.setImported(ApplicationConstants.BSS_SICLI_IMPORTED_FAILURE);

		jobLog.incrementProcessCount();
		try {
			sicliImportDAO.rejectImpService(svc.getImportId(), svc.getImportError(), svc.getImported());
		} catch (SQLException e) {
			e.printStackTrace();
			jobLog.addError("SQL error updating IMP_SERVICE record with error message");
		}
	}

	public boolean validateCustomer(ImpJobLogTO jobLog, String description, String validationMode, String customerId,
			long siteId) throws NotImplementedException, SQLException {
		// always allow NULL values
		if (customerId == null) {
			return true;
		}

		// check for empty string
		if (customerId.isEmpty()) {
			jobLog.addError("Empty string in " + description);
			return false;
		}

		// get validation mode
		String validateMode = getValidationMode(validationMode);
		List<CustomerTO> customers = sicliImportDAO.custListService(customerId, siteId);

		boolean customerFound = false;
		if (customers != null && !customers.isEmpty())
			customerFound = true;

		CustomerTO cust = new CustomerTO();
		cust.setCUSTOMERID(customerId);
		cust.setSITEID(siteId);
		cust.setACTIVE((long) -1);

		// validate customer according to validation mode
		if (!customerFound) {
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError(description + " doesn't exist");
				return false;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				// create customer
				try {
					if (sicliImportDAO.addCustomerWithMinimalData(cust) == null) {
						jobLog.addError("Couldn't create " + description);
						return false;
					}
				} catch (SQLException e) {
					e.printStackTrace();
					jobLog.addError("Couldn't create " + description + "; SQL error " + e.getMessage());
					return false;
				}
				jobLog.addWarning("Validated " + description + "; inserted record into table");

				// add the record to our list, as we will not be obtaining the
				// reference data again
				if (customers == null) {
					customers = new ArrayList<>();
				}
				customers.add(cust);

				return true;
			} else {
				jobLog.addError("Validating " + description + "; unknown validation mode: " + validateMode);
				return false;
			}
		} else {
			// customer already exists
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				return true;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError(description + " already exists and cannot be used/imported again");
				return false;
			} else {
				jobLog.addError("Validation " + description + "; unknown validation mode: " + validateMode);
				return false;
			}
		}
	}

	private String getValidationMode(String validationMode) {

		if (validationMode == null) {
			validationMode = ServiceModeConstant.kValidationModeExist;
		}

		return validationMode;

	}

///////////////////////////////////////////////VALID - COLOUM - VALUE//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean ValidColoumValue(ImpJobLogTO jobLog, String inKeyDesc, String inValidationMode, String inTableName,
			String string, String inKeyValue, long siteID) throws NotImplementedException, SQLException {

		String tValidateMode, tSid;
		String pNew_TruckId = null;
		String pNew_TrailerId = null;
		String pNew_TrailerId_Tag = null;

		// allow NULL values
		if (inKeyValue == null) {
			return true;
		}
		// don't allow empty string
		if (inKeyValue.isEmpty()) {
			jobLog.addError("Empty string in " + inKeyDesc);
			return false;
		}

		// default validation mode
		//String kValidationModeExist = null;
		tValidateMode = checkNull(inValidationMode, ServiceModeConstant.kValidationModeExist);
        System.out.println("tValidateMode========================"+tValidateMode);
        System.out.println("inValidationMode========================"+inValidationMode);
        //System.out.println("kValidationModeExist========================"+kValidationModeExist);
		// lookup foreign key value in master table
		switch (inKeyDesc) {
		case "Location Type":
			tSid = "";
			break;
		default:
			tSid = " AND SITEID=?";
			break;
		}

		switch (inKeyDesc) {
		case "Truck":
			pNew_TruckId = inKeyValue;
			break;
		case "Trailer":
			pNew_TrailerId = inKeyValue;
			break;
		case "Tag Trailer":
			pNew_TrailerId_Tag = inKeyValue;
			break;
		default:
			break;
		}

		List<Object> ColounValidation = sicliImportDAO.validColumnValue(string, inTableName, tSid, inKeyValue,siteID);
System.out.println("");
		// validate result of lookup according to validation mode
		if (ColounValidation==null) {
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeAmcor:
				return true;
			case ServiceModeConstant.kValidationModeExist:
				jobLog.addError(inKeyDesc + " doesn't exist");
				return false;
			case ServiceModeConstant.kValidationModeNullIfMissing:
				switch (inKeyDesc) {
				case "Truck":
					pNew_TruckId = null;
					return true;
				case "Trailer":
					pNew_TrailerId = null;
					return true;
				case "Tag Trailer":
					pNew_TrailerId_Tag = null;
					return true;
				default:
					jobLog.addError("Validating " + inKeyDesc + "; unknown validation mode: " + tValidateMode);
					return false;
				}
				// Here it mean for all 3 case we have to do same thing
			case ServiceModeConstant.kValidationModeNotExist:
			case ServiceModeConstant.kValidationModeCreate:
			case ServiceModeConstant.kValidationModeUpdate:
				try {
				String sql = "INSERT INTO " + inTableName + " (" + string + ", SITEID) VALUES (?, ?)";
				System.out.println("inTableName================"+inTableName);
				System.out.println("string================"+string);
				Connection conn = dataSource.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, inKeyValue);
				pstmt.setLong(2, siteID);

				int rowsAffected = pstmt.executeUpdate();
				pstmt.close();

				if (rowsAffected == 0) {
					jobLog.addError("Couldn't insert new record into table " + inTableName);
					return false;
				}
				}
				catch (Exception  e) {
					 System.out.println("==========================inside catch");
				}
				jobLog.addWarning("Validated " + inKeyDesc + "; inserted record into table " + inTableName);
				return true;
			default:
				jobLog.addError("Validating " + inKeyDesc + "; unknown validation mode: " + tValidateMode);
				return false;

			}
		}
		if (!ColounValidation.isEmpty()) {
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeExist:
			case ServiceModeConstant.kValidationModeCreate:
			case ServiceModeConstant.kValidationModeUpdate:
			case ServiceModeConstant.kValidationModeAmcor:
				return true;
			case ServiceModeConstant.kValidationModeNotExist:
				jobLog.addError(inKeyDesc + " already exists and cannot be used/imported again");
				return false;
			default:
				jobLog.addError("Validating " + inKeyDesc + "; unknown validation mode: " + tValidateMode);
				return false;
			}
		}
		// assume all foreign keys are invalid unless explicitly defined otherwise!
		jobLog.addError("Validating " + inKeyDesc + "; undefined validation case");
		return false;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public String checkNull(String value, String nullValue) {
		if (value == null) {
			return nullValue;
		}
		return value;
	}

	public java.util.Date checkNullDate(java.util.Date date, Date date2) {
		if (date == null) {
			return date2;
		}
		return date;
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void verifyContainer(ImpJobLogTO jobLog, ImpServiceTO rsImp, long SiteID)
			throws NotImplementedException, SQLException {

		String tValidateMode, theSQL;
		// allow NULL container ID
		if (rsImp.getContainerId() == null) {
			return;
		}
		// don't allow empty string contrainer ID
		if (rsImp.getContainerId() != null && rsImp.getContainerId().isEmpty()) {
			jobLog.addError("Empty string in Container");
			return;
		}
		// default validation mode
		tValidateMode = checkNull(rsImp.getValidateContainer(), ServiceModeConstant.kValidationModeExist);

		List<ContainerTO> containerTos = sicliImportDAO.verifyContainer(rsImp, SiteID);

		if (containerTos.isEmpty()) {
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeExist:
				jobLog.addError("Container not found");
				return;
			case ServiceModeConstant.kValidationModeNotExist:
			case ServiceModeConstant.kValidationModeCreate:
			case ServiceModeConstant.kValidationModeUpdate:
				if (jobLog.getRecentErrorCount() == 0) {
					ValidCompany(jobLog, "Container Company", rsImp.getValidateCompanyCont(), rsImp.getCompanyIdCont(),
							SiteID);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Container Type", rsImp.getValidateContainerType(), "CONTAINER_TYPE",
							"ContainerTypeID", rsImp.getContainerDescCont(), SiteID);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					Connection conn = dataSource.getConnection();
					String insertQuery = "INSERT INTO CONTAINER (SiteId, ContainerId, ContainerTypeID, ContainerDesc, CompanyId, WeightTonnes, Permanent) VALUES (?, ?, ?, ?, ?, ?, ?)";
					try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
						pstmt.setLong(1, SiteID);
						pstmt.setString(2, rsImp.getContainerId());
						pstmt.setString(3, rsImp.getContainerTypeCont());
						pstmt.setString(4, rsImp.getContainerDescCont());
						pstmt.setString(5, rsImp.getCompanyIdCont());
						pstmt.setDouble(6, rsImp.getWeightTonnesCont());
						pstmt.setBoolean(7, rsImp.getPermanentPickup());

						int rowsAffected = pstmt.executeUpdate();
						if (rowsAffected == 0) {
							jobLog.addWarning("Couldn't add new container; SQL error: No rows affected");
						}
					}
				}
				jobLog.addWarning("Added new container " + rsImp.getContainerId());
				return;
			default:
				jobLog.addError("Container validation; unknown validation mode: " + tValidateMode);
				return;
			}
		}
		if (!containerTos.isEmpty()) {
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeExist:
			case ServiceModeConstant.kValidationModeCreate:
				return;
			case ServiceModeConstant.kValidationModeNotExist:
				jobLog.addError("Container exists already and cannot be used again");
				return;
			case ServiceModeConstant.kValidationModeUpdate:
				if (jobLog.getRecentErrorCount() == 0) {
					ValidCompany(jobLog, "Container Company", rsImp.getValidateCompanyCont(), rsImp.getCompanyIdCont(),
							SiteID);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Container Type", rsImp.getValidateContainerType(), "CONTAINER_TYPE",
							"ContainerTypeID", rsImp.getContainerDescCont(), SiteID);
				}

				String theSQL1 = "UPDATE CONTAINER SET " + "ContainerTypeID = ?, ContainerDesc = ?, "
						+ "CompanyId = ?, WeightTonnes = ?, " + "Permanent = ? " + "WHERE ContainerId = ?";

				try (Connection conn = dataSource.getConnection();
						PreparedStatement pstmt = conn.prepareStatement(theSQL1)) {
					pstmt.setString(1, rsImp.getContainerId());
					pstmt.setString(2, rsImp.getContainerDescCont());
					pstmt.setString(3, rsImp.getCompanyIdCont());
					pstmt.setDouble(4, rsImp.getWeightTonnesCont());
					pstmt.setBoolean(5, rsImp.getPermanentPickup());
					pstmt.setString(6, rsImp.getContainerId());

					int rowsAffected = pstmt.executeUpdate();
					if (rowsAffected == 0) {
						jobLog.addWarning("Couldn't update Container ID " + rsImp.getContainerId() + "; SQL error: "
								+ pstmt.getWarnings().getMessage());
					}
				}

				jobLog.addWarning("Updated Container " + rsImp.getContainerId());
				return;
			default:
				jobLog.addError("Container validation; unknown validation mode: " + tValidateMode);
				return;
			}

		}
		// default to failure if the situation isn't handled
		jobLog.addError("Container validation; unhandled case");
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public boolean ValidCompany(ImpJobLogTO jobLog, String inDesc, String inValidationMode, String inValue, long SiteID)
			throws NotImplementedException, SQLException {

		String tValidateMode;

		if (inValue == null)
			return true;

		if (inValue == "") {
			jobLog.addError("Empty string in " + inDesc);
			return false;
		}
		// Get validation mode
		tValidateMode = checkNull(inValidationMode, ServiceModeConstant.kValidationModeExist);

		List<CompanyTO> companyTos = sicliImportDAO.ValidCompany(inValue, SiteID);

		if (companyTos.isEmpty()) {
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeExist:
				jobLog.addError(inDesc + " doesn't exist");
				return false;

			case ServiceModeConstant.kValidationModeNotExist:
			case ServiceModeConstant.kValidationModeCreate:
			case ServiceModeConstant.kValidationModeUpdate:
				// Create company
				// Insert query
				String tableName = "COMPANY";
				String insertQuery = "INSERT INTO " + tableName + " (CompanyID, SiteID, Active) VALUES (?, ?, ?)";
				try (Connection conn = dataSource.getConnection();
						PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
					pstmt.setString(1, inValue);
					pstmt.setLong(2, SiteID);
					pstmt.setBoolean(3, true);

					int rowsAffected = pstmt.executeUpdate();

					if (rowsAffected > 0) {
						jobLog.addWarning("Validated " + inDesc + "; inserted record into table " + tableName);
						return true;
					}
				}
				jobLog.addWarning("Validated " + inDesc + "; inserted record into table ");
				return true;
			default:
				jobLog.addError("Validating " + inDesc + "; unknown validation mode: " + tValidateMode);
				return false;
			}
		}
		if (!companyTos.isEmpty()) {
			// Company already exists
			switch (tValidateMode) {
			case ServiceModeConstant.kValidationModeExist:
			case ServiceModeConstant.kValidationModeCreate:
			case ServiceModeConstant.kValidationModeUpdate:
				return true;

			case ServiceModeConstant.kValidationModeNotExist:
				jobLog.addError(inDesc + " already exists and cannot be used/imported again");
				return false;

			default:
				jobLog.addError("Validating " + inDesc + "; unknown validation mode: " + tValidateMode);
				return false;
			}

		}
		// Couldn't determine what to do
		jobLog.addError("Validating " + inDesc + "; undefined validation case");
		return false;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void verifyServiceType(ImpJobLogTO jobLog, ImpServiceTO rsImp, long SiteID) throws SQLException {

		List<ServiceTypeTO> ServiceTypeTos = sicliImportDAO.VerifyServiceType(rsImp.getServiceType(), SiteID);

		if (!ServiceTypeTos.isEmpty()) {
			jobLog.addError("Service type " + rsImp.getServiceType() + " not found");
			return;
		}

		cqtylist.InitWithRS(ServiceTypeTos);

		cqtylist.ReadFromRS(rsImp, false);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public LoadResultTO verifyMLLoadNo(ImpJobLogTO jobLog, ImpServiceTO rsImp, Long outLoadId, Long tImportedLoadID,
			boolean pIsMultileg, long SiteID) throws SQLException, NotImplementedException {

		String tValidateMode;
		String theSql;
		LoadResultTO result = new LoadResultTO();

		// Check essential fields
		if (rsImp.getLoadNo() == null) {
			jobLog.addError("Missing Load No.");
			return null;
		} else if (rsImp.getLoadNo() == "") {
			jobLog.addError("Empty string in Load No.");
			return null;
		}

		// Get validation mode
		tValidateMode = checkNull(rsImp.getValidateLoad(), ServiceModeConstant.kValidationModeExist);
        System.out.println("rsImp.getValidateLoad()======="+rsImp.getValidateLoad());
        System.out.println("ServiceModeConstant.kValidationModeExist======="+ServiceModeConstant.kValidationModeExist);
		// Run query in LoadNo fetch here n check
		List<ImpLoadTO> tLoadQry = sicliImportDAO.getExistingLoadRecord(rsImp.getCustomerId(), rsImp.getLoadNo(),
				SiteID, (rsImp.getScheduledDate() == null ? rsImp.getServiceDate() : rsImp.getScheduledDate()));

		if (!tLoadQry.isEmpty()) {
			if (jobLog.getRecentErrorCount() == 0) {
				ValidColoumValue(jobLog, "Load Location", tValidateMode, "LOCATION", "LocationId",
						rsImp.getLocationIdLoad(), SiteID);
			}
			if (jobLog.getRecentErrorCount() == 0) {
				outLoadId = mCreateLoad(jobLog, rsImp, SiteID);
				result.setLoadId(outLoadId);
				return result;
			} else {
				// Found existing load record
				// tLoadQry.first();
				for (ImpLoadTO impLoad : tLoadQry) {
					outLoadId = impLoad.getLoadId();
					result.setLoadId(outLoadId);
				}
				return result;
			}

		}
		// Couldn't determine what to do
		jobLog.addError("Load validation; unhandled case");
		return result;

	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private Long mCreateLoad(ImpJobLogTO jobLog, ImpServiceTO rsImp, long SiteID)
			throws SQLException, NotImplementedException {
		Long tMasterID; // varients
		String tLoadNo = sicliImportDAO.nextKey(SiteID, "LOAD");
		Long ID1;
		// Check once the tLoad method !!

		if (tLoadNo == "") {
			jobLog.addError("Couldn't create new load identifier.");
			return null;
		}

		// Generate ID using a separate method

		String sql = "INSERT INTO CONSIGNMENT_MASTER (ID, LoadNo, SiteID_Origin, CustomerID, ScheduledDate, BatchNo, CustReference, LocationID, CustClaimAmt, SettleDate, Remarks, DataSourceID, Complete, EnteredBy, DespatchBy, DeliveryOpen, DeliveryClose) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = dataSource.getConnection(); PreparedStatement statement = conn.prepareStatement(sql)) {
			Long ID = getNextSequenceNumber("CONSIGNMENT_MASTER_SEQ", conn);
			// Set parameter values
			statement.setLong(1, ID);
			statement.setString(2, tLoadNo);
			statement.setLong(3, SiteID);
			statement.setString(4, rsImp.getCustomerId());
			statement.setDate(5, (Date) rsImp.getScheduledDate());
			checkNullDate(rsImp.getScheduledDate(), (Date) rsImp.getServiceDate());
			statement.setTimestamp(5, checkNullTimestamp(ServiceUtil.convertDateToTimeStamp(rsImp.getScheduledDate()),
					ServiceUtil.convertDateToTimeStamp(rsImp.getServiceDate())));
			statement.setString(6, rsImp.getBatchNo());
			statement.setString(7, rsImp.getCustReference());
			statement.setString(8, rsImp.getLocationIdLoad());
			statement.setDouble(9, rsImp.getCustClaimAmt());
			statement.setDate(10, (Date) rsImp.getSettleDate());
			statement.setTimestamp(10, ServiceUtil.convertDateToTimeStamp(rsImp.getSettleDate()));
			statement.setString(11, rsImp.getRemarksLoad());
			statement.setString(12, "IS");
			statement.setBoolean(13, false);
			statement.setString(14, rsImp.getImportEnteredBy());
			statement.setDate(15, (Date) rsImp.getDespatchBy());
			statement.setDate(16, (Date) rsImp.getDeliveryOpen());
			statement.setDate(17, (Date) rsImp.getDeliveryClose());
			statement.setTimestamp(15, ServiceUtil.convertDateToTimeStamp(rsImp.getDespatchBy()));
			statement.setTimestamp(16, ServiceUtil.convertDateToTimeStamp(rsImp.getDeliveryOpen()));
			statement.setTimestamp(17, ServiceUtil.convertDateToTimeStamp(rsImp.getDeliveryClose()));

			// Execute the insert statement
			int rowsAffected = statement.executeUpdate();

			if (rowsAffected < 0) {
				// Insertion successful
				jobLog.addError("Couldn't create new load in system; SQL error");
				return null;
			}
			tMasterID = ID;

			String sql1 = "INSERT INTO CUSTLOAD (ID, SiteID, LoadNo, LoadTypeID, ImportedBy, HoldCode, Complete, MasterID, ScheduledDate, OriginSite, OriginLoc, DestinationSite, DestinationLoc, CreateTrip, LocationId_Wharf, LocationId_Depot, LocationId_Customer, LocationId_Park) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			try (Connection conn1 = dataSource.getConnection();
					PreparedStatement statement1 = conn.prepareStatement(sql1)) {
				ID1 = getNextSequenceNumber("CUSTLOAD_SEQ", conn);
				// Set parameter values
				statement.setLong(1, ID1);
				statement.setLong(2, rsImp.getSiteId());
				statement.setString(3, tLoadNo);
				statement.setString(4, rsImp.getLoadType());
				// Check this APP
				// App.Session.GetUserID()
				statement.setString(5, "");
				statement.setString(6, null);
				statement.setBoolean(7, false);
				statement.setLong(8, tMasterID);
				statement.setTimestamp(9,
						checkNullTimestamp(ServiceUtil.convertDateToTimeStamp(rsImp.getScheduledDate()),
								ServiceUtil.convertDateToTimeStamp(rsImp.getServiceDate())));
				statement.setLong(10, rsImp.getOriginSite());
				statement.setString(11, rsImp.getOriginLoc());
				statement.setLong(12, rsImp.getDestinationSite());
				statement.setString(13, rsImp.getDestinationLoc());
				statement.setInt(14, checkNullInteger(convertBooleanToInt(rsImp.isCreateTrip()), -1));

				// inMultilegRow As IDataRecordSet = Nil
				// SO no use of this code
//		            If inMultilegRow <> Nil Then
//		            tStmt.LocationId_Wharf = inMultilegRow.LocationId_Wharf
//		            tStmt.LocationId_Depot = inMultilegRow.LocationId_Depot
//		            tStmt.LocationId_Customer = inMultilegRow.LocationId_Customer
//		            tStmt.LocationId_Park = inMultilegRow.LocationId_Park
//		          End If
				int rowsAffected1 = statement.executeUpdate();
			}

		}
		return ID1;
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int checkNullInteger(Integer value, int nullValue) {
		if (value == null) {
			return nullValue;
		}
		return value;
	}

	public static int convertBooleanToInt(boolean value) {
		return value ? 1 : 0;
	}

	public static Timestamp checkNullTimestamp(Timestamp timestamp, Timestamp timestamp2) {
		if (timestamp == null) {
			return timestamp2;
		}
		return timestamp;
	}

//=========================================valid Driver===================================================
	public boolean validDriver(ImpJobLogTO jobLog, ImpServiceTO impservice, Long ldriverId, Long siteid)
			throws SQLException, NotImplementedException {
		boolean driverFound = false;

		if (ldriverId == null) {
			System.out.println("ldriverIdldriverIdldriverIdldriverId====="+ldriverId);
			return true;
		}
		System.out.println("Afre   ldriverIdldriverIdldriverIdldriverId====="+ldriverId);
		String driverId = ldriverId.toString();
		// always allow NULL values

		// check for empty string
		if (driverId.isEmpty()) {
			jobLog.addError("Empty string in Driver");

			return false;
		}
		

		// get validation mode
		String validateMode = getValidationMode(impservice.getValidateDriver());

		if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
				|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
				|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
			// we can't create or update drivers.

			return false;
		}

		// using driver "Train"
		boolean varifyTrainDriver = false;
		if ("Train".equals(driverId)) {
			varifyTrainDriver = sicliImportDAO.traindriverService(driverId, siteid);

			if (varifyTrainDriver) {
				return true;
			} else {
				if (ServiceModeConstant.kValidationModeNullIfMissing.equalsIgnoreCase(validateMode)) {
					return false;
				} else {
					// if driver id is an integer, assume it's the employee_site.id.
					// either the driver is meant to exist and doesn't, or SICLI is
					// meant to create it (which is impossible)
					jobLog.addError("Driver " + driverId + " doesn't exist in site");

					return false;
				}
			}
		}
		if (StringUtils.isNumeric(driverId)) {
			long newResource = Long.parseLong(driverId);
			// find driver
			DriverResourceTO driver = new DriverResourceTO();
			driver.setId(newResource);
			driver.setMASTER_SITEID(siteid);
			driver.setActive(true);

			if (driver != null) {

				driverFound = true;

			}
		}
		// Find driver

		varifyTrainDriver = sicliImportDAO.findDriverService(driverId, siteid);

		// validate customer according to validation mode
		if (!driverFound) {
			// driver not found
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError("contact doesn't exist");
				return false;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				// create driver
				// NOTE: this is dead code as we already returned false because
				// we should not be creating drivers.
				return false;
			} else {
				jobLog.addError("Validating driver; unknown validation mode: " + validateMode);
				return false;
			}
		} else {
			// driver already exists
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				return true;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError("driver already exists and cannot be used/imported again");
				return false;
			} else {
				jobLog.addError("Validating driver; unknown validation mode: " + validateMode);
				return false;
			}
		}

	}

	// ======================================verifyLocation========================================================
	public void verifyLocation(ImpJobLogTO jobLog, boolean isDrop, ImpServiceTO impservice, long siteid)
			throws SQLException, NotImplementedException {
		if (impservice == null) {
			return;
		}
		String desc = mStringIf(isDrop, "Drop Location", "Pickup Location");
		String id = mStringIf(isDrop, impservice.getLocationIdDrop(), impservice.getLocationIdPickup());

		// allow NULL location
		if (id == null) {
			return;
		}

		// // always prevent empty drop location
		if (id.isEmpty()) {
			jobLog.addError("Empty string in " + desc);
			return;
		}
		boolean locationFound = false;
		// default validation mode
		String validateMode = mStringIf(isDrop, impservice.getValidateDrop(), impservice.getValidatePickup());
		locationFound = sicliImportDAO.locationInfo(id, siteid);

		if (!locationFound) {
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError(desc + "not found");
				return;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				// validate location type
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Location Type", "", impservice.getValidateLocationType(),
							SicliValidTable.LOCATION_TYPE.toString(),
							mStringIf(isDrop, impservice.getLocationTypeDrop(), impservice.getLocationType()), siteid);
				}
				// validate pay zone
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Pay Zone", "", impservice.getValidatePayZone(),
							SicliValidTable.ZONE_PAY.toString(),
							mStringIf(isDrop, impservice.getPayZoneIdDrop(), impservice.getPayZoneId()), siteid);
				}
				// validate charge zone
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Charge Zone", "", impservice.getValidateChargeZone(),
							SicliValidTable.ZONE_CHARGE.toString(),
							mStringIf(isDrop, impservice.getChargeZoneIdDrop(), impservice.getChargeZoneId()), siteid);
				}
				// validate map source
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Map Source", "", impservice.getValidateMapSource(),
							SicliValidTable.MAPSOURCE.toString(),
							mStringIf(isDrop, impservice.getMapSourceIdDrop(), impservice.getMapSourceId()), siteid);
				}
				// validate route
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Route", "", impservice.getValidateRoute(),
							SicliValidTable.ROUTE.toString(),
							mStringIf(isDrop, impservice.getRouteIdDrop(), impservice.getRouteIdPickup()), siteid);
				}
				// validate location customer
				if (jobLog.getRecentErrorCount() == 0) {
					validateCustomer(jobLog, "Location Customer", impservice.getValidateCustomer(),
							mStringIf(isDrop, impservice.getCustomerIdDrop(), impservice.getCustomerId()), siteid);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					LocationTO location = new LocationTO();
					location.setSiteId(siteid);
					location.setLocationId(id);
					location.setLocationTypeId(
							mStringIf(isDrop, impservice.getLocationTypeDrop(), impservice.getLocationType()));
					String locStr = impservice.getLocationDescDrop();
					int locStrLen = 0;
					if (locStr != null && !locStr.isEmpty()) {
						locStrLen = locStr.length() > 50 ? 50 : locStr.length();
						locStr = locStr.substring(0, locStrLen);
					}
					String impSource = impservice.getImportSource();
					if (impSource != null && impSource.trim().equalsIgnoreCase("VAX Excel Import")) {
						locStrLen = locStr.length() > 47 ? 47 : locStr.length();
						locStr = "VX-" + locStr.substring(0, locStrLen);
					}
					location.setLocationDesc(locStr);
					location.setLocationCode(
							mStringIf(isDrop, impservice.getLocationCodeDrop(), impservice.getLocationCode()));
					location.setWindow1From(
							mDateIfAsLong(isDrop, impservice.getWindow1FromDrop(), impservice.getWindow1FromPickup()));
					location.setWindow1To(
							mDateIfAsLong(isDrop, impservice.getWindow1ToDrop(), impservice.getWindow1ToPickup()));
					location.setWindow2From(
							mDateIfAsLong(isDrop, impservice.getWindow2FromDrop(), impservice.getWindow2FromPickup()));
					location.setWindow2To(
							mDateIfAsLong(isDrop, impservice.getWindow2ToDrop(), impservice.getWindow2ToPickup()));
					location.setZonePayId(mStringIf(isDrop, impservice.getPayZoneIdDrop(), impservice.getPayZoneId()));
					location.setZoneChargeId(
							mStringIf(isDrop, impservice.getChargeZoneIdDrop(), impservice.getChargeZoneId()));
					location.setLatitude(
							mDoubleIf(isDrop, impservice.getLatitudeDrop(), impservice.getLatitudePickup()));
					location.setLongitude(
							mDoubleIf(isDrop, impservice.getLongitudeDrop(), impservice.getLongitudePickup()));
					location.setGeofence(mIntIf(isDrop, impservice.getGeofenceDrop(), impservice.getGeofencePickup()));
					location.setMapSourceId(
							mStringIf(isDrop, impservice.getMapSourceIdDrop(), impservice.getMapSourceId()));
					location.setMapReference(
							mStringIf(isDrop, impservice.getMapReferenceDrop(), impservice.getMapReference()));
					location.setAddress1(mStringIf(isDrop, impservice.getAddress1Drop(), impservice.getAddress1()));
					location.setAddress2(mStringIf(isDrop, impservice.getAddress2Drop(), impservice.getAddress2()));
					location.setSuburb(mStringIf(isDrop, impservice.getSuburbDrop(), impservice.getSuburb()));
					location.setState(mStringIf(isDrop, impservice.getStateDrop(), impservice.getState()));
					location.setPostCode(mStringIf(isDrop, impservice.getPostCodeDrop(), impservice.getPostCode()));
					location.setRemarks(mStringIf(isDrop, impservice.getRemarksDrop(), impservice.getRemarksPickup()));
					location.setTruckSizeLimit(mDoubleIf(isDrop, impservice.getTruckSizeLimitDrop(),
							impservice.getTruckSizeLimitPickup()));
					Integer defTripSeq = mIntIf(isDrop, impservice.getDefaultTripSeqDrop(),
							impservice.getDefaultTripSeqPickup());
					location.setDefaultTripSeq(defTripSeq == null ? null : defTripSeq.longValue());
					location.setRouteId(mStringIf(isDrop, impservice.getRouteIdDrop(), impservice.getRouteIdPickup()));
					location.setPermanent(
							mBoolIf(isDrop, impservice.isPermanentDrop(), impservice.getPermanentPickup()));

					if (sicliImportDAO.addLocationdata(location) == null) {
						jobLog.addWarning("Couldn't add new " + desc);
					}
					jobLog.addWarning("Added new location " + id);
				}
				return;
			} else {
				jobLog.addError(desc + " validation; unknown validation mode: " + validateMode);
				return;
			}
		}

		else {
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)) {
				return;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError(desc + " exists already and cannot be used again");
				return;
			} else if (ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				// validate location type
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Location Type", "", impservice.getValidateLocationType(),
							SicliValidTable.LOCATION_TYPE.toString(),
							mStringIf(isDrop, impservice.getLocationTypeDrop(), impservice.getLocationType()), siteid);
				}
				// validate pay zone
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Pay Zone", "", impservice.getValidatePayZone(),
							SicliValidTable.ZONE_PAY.toString(),
							mStringIf(isDrop, impservice.getPayZoneIdDrop(), impservice.getPayZoneId()), siteid);
				}
				// validate charge zone
				if (jobLog.getRecentErrorCount() == 0) {
					// NEED TO PASS EXISTING METHODS HERE NEEDS TO CHECK NAME
					ValidColoumValue(jobLog, "Charge Zone", "", impservice.getValidateChargeZone(),
							SicliValidTable.ZONE_CHARGE.toString(),
							mStringIf(isDrop, impservice.getChargeZoneIdDrop(), impservice.getChargeZoneId()), siteid);
				}
				// validate map source
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Map Source", "", impservice.getValidateMapSource(),
							SicliValidTable.MAPSOURCE.toString(),
							mStringIf(isDrop, impservice.getMapSourceIdDrop(), impservice.getMapSourceId()), siteid);
				}
				// validate route
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Route", "", impservice.getValidateRoute(),
							SicliValidTable.ROUTE.toString(),
							mStringIf(isDrop, impservice.getRouteIdDrop(), impservice.getRouteIdPickup()), siteid);
				}
				// validate location customer

				if (jobLog.getRecentErrorCount() == 0) {
					validateCustomer(jobLog, "Location Customer", impservice.getValidateCustomer(),
							mStringIf(isDrop, impservice.getCustomerIdDrop(), impservice.getCustomerId()), siteid);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					// update location reference
					LocationTO location = new LocationTO();
					location.setSiteId(siteid);
					location.setLocationId(id);

					location.setLocationTypeId(
							mStringIf(isDrop, impservice.getLocationTypeDrop(), impservice.getLocationType()));
					String locStr = impservice.getLocationDescDrop();
					int locStrLen = 0;
					if (locStr != null && !locStr.isEmpty()) {
						locStrLen = locStr.length() > 50 ? 50 : locStr.length();
						locStr = locStr.substring(0, locStrLen);
					}
					String impSource = impservice.getImportSource();
					if (impSource != null && impSource.trim().equalsIgnoreCase("VAX Excel Import")) {
						locStrLen = locStr.length() > 47 ? 47 : locStr.length();
						locStr = "VX-" + locStr.substring(0, locStrLen);
					}
					location.setLocationDesc(locStr);
					location.setLocationCode(
							mStringIf(isDrop, impservice.getLocationCodeDrop(), impservice.getLocationCode()));
					location.setWindow1From(
							mDateIfAsLong(isDrop, impservice.getWindow1FromDrop(), impservice.getWindow1FromPickup()));
					location.setWindow1To(
							mDateIfAsLong(isDrop, impservice.getWindow1ToDrop(), impservice.getWindow1ToPickup()));
					location.setWindow2From(
							mDateIfAsLong(isDrop, impservice.getWindow2FromDrop(), impservice.getWindow2FromPickup()));
					location.setWindow2To(
							mDateIfAsLong(isDrop, impservice.getWindow2ToDrop(), impservice.getWindow2ToPickup()));
					location.setZonePayId(mStringIf(isDrop, impservice.getPayZoneIdDrop(), impservice.getPayZoneId()));
					location.setZoneChargeId(
							mStringIf(isDrop, impservice.getChargeZoneIdDrop(), impservice.getChargeZoneId()));
					location.setLatitude(
							mDoubleIf(isDrop, impservice.getLatitudeDrop(), impservice.getLatitudePickup()));
					location.setLongitude(
							mDoubleIf(isDrop, impservice.getLongitudeDrop(), impservice.getLongitudePickup()));
					location.setGeofence(mIntIf(isDrop, impservice.getGeofenceDrop(), impservice.getGeofencePickup()));
					location.setMapSourceId(
							mStringIf(isDrop, impservice.getMapSourceIdDrop(), impservice.getMapSourceId()));
					location.setMapReference(
							mStringIf(isDrop, impservice.getMapReferenceDrop(), impservice.getMapReference()));
					location.setAddress1(mStringIf(isDrop, impservice.getAddress1Drop(), impservice.getAddress1()));
					location.setAddress2(mStringIf(isDrop, impservice.getAddress2Drop(), impservice.getAddress2()));
					location.setSuburb(mStringIf(isDrop, impservice.getSuburbDrop(), impservice.getSuburb()));
					location.setState(mStringIf(isDrop, impservice.getStateDrop(), impservice.getState()));
					location.setPostCode(mStringIf(isDrop, impservice.getPostCodeDrop(), impservice.getPostCode()));
					location.setRemarks(mStringIf(isDrop, impservice.getRemarksDrop(), impservice.getRemarksPickup()));
					location.setTruckSizeLimit(mDoubleIf(isDrop, impservice.getTruckSizeLimitDrop(),
							impservice.getTruckSizeLimitPickup()));
					Integer defTripSeq = mIntIf(isDrop, impservice.getDefaultTripSeqDrop(),
							impservice.getDefaultTripSeqPickup());
					location.setDefaultTripSeq(defTripSeq == null ? null : defTripSeq.longValue());
					location.setRouteId(mStringIf(isDrop, impservice.getRouteIdDrop(), impservice.getRouteIdPickup()));
					location.setPermanent(
							mBoolIf(isDrop, impservice.isPermanentDrop(), impservice.getPermanentPickup()));

					// update query needs to write pending from query side
					boolean locationUpdate = false;
					locationUpdate = sicliImportDAO.locationUpdate(location.getLocationId());
					if (!locationUpdate) {
						jobLog.addWarning("Updated Location " + id);
					}
				}
				return;
			} else {
				jobLog.addError(desc + " validation; unknown validation mode: " + validateMode);
				return;
			}
		}
	}

	// ========================VerifyLoadNo=====================================================================
	public LoadResultTO verifyLoadNo(ImpJobLogTO jobLog, ImpServiceTO impservice, Long outLoadId,
			Long outImportedLoadId, long siteId) throws NotImplementedException, SQLException {

		outLoadId = null;
		outImportedLoadId = null;
		LoadResultTO result = new LoadResultTO();
		Long tDriverId = null;
		String tTruckId = null;
		String tTrailerId = null;
		String tTrailerIdTag = null;
		String tServiceDesc = null;
		boolean updServiceDate = false;
		boolean updScheduledDate = false;
		boolean updTripDate = false;
		boolean updDriverId = false;
		boolean updTruckId = false;
		boolean updTrailerId = false;
		boolean updTrailerIdTag = false;
		boolean updServiceDesc = false;
		PropertiesTO props = new PropertiesTO();
		List<DriverResourceTO> drivers = new ArrayList<>();
		List<TrailerResourceTO> trailers = new ArrayList<>();
		List<TruckResourceTO> trucks = new ArrayList<>();
		if (impservice == null) {
			return result;
		}
		// Check essential fields
		if (impservice.getCustomerId() == null) {
			jobLog.addError("Missing Customer");
			return result;
		} else if (impservice.getCustomerId().isEmpty()) {
			jobLog.addError("Empty string in Customer");
			return result;
		}
		// Get validation mode
		String validateMode = getValidationMode(impservice.getValidateLoad());
		// AONE-1318
		// Regardless of validation mode, if IMP_MULTILEG.LoadId is specified, link to
		List<ImpLoadTO> loads = null;

		// NOTE: The following validation mode (MODE_RECYCLE) is for Orora
		// only!!! Therefore, BSS will not use this.
		if (ServiceModeConstant.kValidationModeRecycle.equalsIgnoreCase(validateMode)) {
			// handle recycle validation mode; maps to either create or update
			// modes as appropriate
			if (impservice.getLoadNo() == null) {
				// load number missing
				jobLog.addError("Load number missing; required for Recycle validation mode");
				return result;
			}
			try {
				loads = sicliImportDAO.getExistingLoadRecord(impservice.getCustomerId(), impservice.getLoadNo(), siteId,
						(impservice.getScheduledDate() == null ? impservice.getServiceDate()
								: impservice.getScheduledDate()));
				if (loads == null || loads.isEmpty()) {
					// load number for specified date doesn't exit, create new
					validateMode = ServiceModeConstant.kValidationModeCreate;
				} else {
					// load number for specified date exists in system, update
					// it
					validateMode = ServiceModeConstant.kValidationModeUpdate;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				validateMode = ServiceModeConstant.kValidationModeCreate;
			}
		}
		// create if null
		if (ServiceModeConstant.kValidationModeCreateIfNull.equalsIgnoreCase(validateMode)
				&& impservice.getLoadNo() == null) {
			outLoadId = mCreateLoad(jobLog, impservice, siteId);
			outImportedLoadId = outLoadId;
			result.setLoadId(outLoadId);
			result.setImportedLoadId(outImportedLoadId);
			return result;
		}
		// check essential fields
		if (impservice.getLoadNo() == null) {
			// load number missing
			jobLog.addError("Missing Load No.");
			return result;
		} else if (impservice.getLoadNo().isEmpty()) {
			jobLog.addError("Empty string in Load No.");
			return result;
		}
		// try to find existing load record
		if (loads == null || loads.isEmpty()) {
			try {
				loads = sicliImportDAO.getExistingLoadRecord(impservice.getDocket(), impservice.getTripSeq(),
						impservice.getLoadNo(), siteId, null);
			} catch (SQLException e) {
				// do nothing
				e.printStackTrace();
			}
		}
		if (loads == null || loads.isEmpty()) {
			// couldn't find existing load record
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError("Load " + impservice.getLoadNo() + " not found");
				outLoadId = null;
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)
					|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				if (jobLog.getRecentErrorCount() == 0) {
					ValidColoumValue(jobLog, "Load Location", "", validateMode, SicliValidTable.LOCATION.toString(),
							impservice.getLocationIdLoad(), siteId);
				}
				if (jobLog.getRecentErrorCount() == 0) {
					outLoadId = mCreateLoad(jobLog, impservice, siteId);
				}
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			} else {
				jobLog.addError("Load validation; unknown validation mode: " + validateMode);
				outLoadId = null;
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			}
		} else {
			ImpLoadTO impLoad = loads.get(0);
			// found existing load record
			outLoadId = impLoad.getLoadId();
			if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			} else if (ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)) {
				ValidColoumValue(jobLog, "Load Location", "", impservice.getValidateDrop(),
						SicliValidTable.LOCATION.toString(), impservice.getLocationIdLoad(), siteId);

				if (jobLog.getRecentErrorCount() == 0) {
					outLoadId = mCreateLoad(jobLog, impservice, siteId);
				}
				jobLog.addWarning("Added duplicate Load No. " + outLoadId);
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)) {
				jobLog.addError("Load No. already exists and cannot be used again");
				outLoadId = null;
				result.setLoadId(outLoadId);
				result.setImportedLoadId(outImportedLoadId);
				return result;
			} else if (ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
				ValidColoumValue(jobLog, "Load Location", "", validateMode, SicliValidTable.LOCATION.toString(),
						impservice.getLocationIdLoad(), siteId);
				if (jobLog.getRecentErrorCount() == 0) {
					if (impLoad.getRunsheetId() == null) {

						ResourceResultTO allocResult = sicliImportDAO.bssAllocation(jobLog, impservice, siteId, trucks,
								drivers, trailers);
						tDriverId = allocResult.getOutDriver();
						tTruckId = allocResult.getOutTruck().toString();
						tTrailerId = allocResult.getOutTrailer().toString();
						tTrailerIdTag = allocResult.getOutTrailerTag();
						tServiceDesc = allocResult.getOutServiceDesc();
						if (!impLoad.isDespatch()) {
							updServiceDate = true;
							updScheduledDate = true;
							updTripDate = true;

							if (impLoad.gettDriverId() == null
									|| !(impLoad.gettDriverId().equals(impLoad.getsDriverId()))) {
								updDriverId = true;
								props.setNewDriverId(tDriverId);
							} else {
								props.setNewDriverId(impLoad.gettDriverId());
							}
							if (impLoad.gettTruckId() == null
									|| !(impLoad.gettTruckId().equals(impLoad.getsTruckId()))) {
								updTruckId = true;
								props.setNewTruckId(tTruckId);
							} else {
								props.setNewTruckId(impLoad.gettTruckId());
							}
							if (impLoad.gettTrailerId() == null
									|| !(impLoad.gettTrailerId().equals(impLoad.getsTrailerId()))) {
								updTrailerId = true;
								props.setNewTrailerId(tTrailerId);
							} else {
								props.setNewTrailerId(impLoad.gettTrailerId());
							}
							if (impLoad.gettTrailerIdTag() == null
									|| !(impLoad.gettTrailerIdTag().equals(impLoad.getsTrailerIdTag()))) {
								updTrailerIdTag = true;
								props.setNewTrailerIdTag(tTrailerIdTag);
							} else {
								props.setNewTrailerIdTag(impLoad.gettTrailerIdTag());
							}
						}
						if (impLoad.getServiceDesc() == null) {
							updServiceDesc = true;
						}

						try {
							if (impservice.getImportServiceId() == null) {
								impservice.setImportServiceId(impLoad.getServiceId());
							}
							sicliImportDAO.updateService(impservice, siteId, tDriverId, tTruckId, tTrailerId,
									tTrailerIdTag, tServiceDesc, updServiceDate, updDriverId, updTruckId, updTrailerId,
									updTrailerIdTag, updServiceDesc);
						} catch (SQLException e) {
							e.printStackTrace();
							jobLog.addWarning("Couldn't update Load " + outLoadId);
						}
						// update custload
						try {
							sicliImportDAO.updateCustload(impservice.getLoadNo(), impservice.getLoadType(),
									impservice.getImportEnteredBy(), impservice.getScheduledDate(), outLoadId, siteId,
									updScheduledDate);
						} catch (SQLException e) {
							e.printStackTrace();
							jobLog.addWarning("Couldn't update Load " + outLoadId);
						}

						// update consignment master
						// NOTE: we use the consignment id instead of the
						// outLoadId as the data is already available to us. the
						// original intention for consignment and custload is
						// for them to have a 1 to 1 relationship.
						try {
							sicliImportDAO.updateConsignment(impservice.getLoadNo(), impservice.getCustomerId(),
									impservice.getBatchNo(), impservice.getLocationIdDrop(),
									impservice.getImportEnteredBy(), impservice.getScheduledDate(),
									impLoad.getConsignmentId(), siteId, updScheduledDate);
						} catch (SQLException e) {
							e.printStackTrace();
							jobLog.addWarning("Couldn't update Load " + outLoadId);
						}
					}

					props.setServiceId(impLoad.getServiceId());
					props.setTripId(impLoad.getTripId());
					props.setUpdateOnly(true);
				}
				jobLog.addWarning("Updated Load " + outLoadId);
			} else {
				jobLog.addError("Load validation; unknown validation mode: " + validateMode);
				outLoadId = null;
			}

		}
		result.setLoadId(outLoadId);
		result.setImportedLoadId(outImportedLoadId);
		return result;

	}

	// ================================verify trip==============================
	public TripResultTO verifyTrip(ImpJobLogTO jobLog, ImpServiceTO impservice, Long inLastTripId,
			Integer inLastTripSeq, Long inTripId, Integer inTripSeq, Long inNewTripId, Timestamp inServiceDate) {

		TripResultTO result = new TripResultTO();
		PropertiesTO props = new PropertiesTO();
		if (impservice == null) {
			return result;
		}

		if (!impservice.isCreateTrip()) {
			jobLog.addNotice(
					"A trip for the imported service will not be created. The service will remain unallocated");
			result.setOutTripId(null);
			return result;
		}

		// initialize the result
		result.setOutLastTripId(inLastTripId);
		result.setOutLastTripSeq(inLastTripSeq);
		result.setOutNewTripId(inNewTripId);
		result.setOutServiceDate(inServiceDate);
		result.setOutTripId(inTripId);
		result.setOutTripSeq(inTripSeq);

		// always allow NULL trip
		if (impservice.getTripId() == null) {
			TripTO trip = null;
			try {
				try {
					trip = sicliImportDAO.getTripByTripNo(impservice.getTripNo(), impservice.getSiteId());
				} catch (NotImplementedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (trip != null) {
				result.setID(trip.getID());
				result.setOutTripId(trip.getID());
				result.setOutTripSeq(impservice.getTripSeq());
				result.setOutNewTripId(trip.getID());
				result.setOutLastTripId(trip.getID());
				result.setOutLastTripSeq(impservice.getTripSeq());
				props.setDespatchService(trip.getDESPATCH());
				props.setExistingTrip(true);
				props.setNewDriverId(trip.getDRIVERID());
				props.setNewTruckId(trip.getTRUCKID().toString());
				props.setNewTrailerId(trip.getTRAILERID());
				props.setNewTrailerIdTag(trip.getTRAILERID_TAG());
				return result;
			}

			// if trip no or trip seq are specified, create trips
			// accordingly
			if (((impservice.getTripNo() != null && !impservice.getTripNo().equalsIgnoreCase(props.getLastTripNo()))
					|| (props.getLastTripNo() != null
							&& !props.getLastTripNo().equalsIgnoreCase(impservice.getTripNo())))
					|| (impservice.getTripSeq() != null
							&& (inLastTripSeq == null || impservice.getTripSeq() <= inLastTripSeq))
					|| (props.getLastTripDate() != null && (impservice.getServiceDate() == null
							|| (impservice.getServiceDate().getTime() != props.getLastTripDate().getTime())))) {
				// create a new trip
				props.setLastTripNo(impservice.getTripNo());
				props.setLastTripDate(impservice.getServiceDate());

				String custTripId = null;
				if (impservice.getTripNo() == null) {
					try {
						try {
							custTripId = sicliImportDAO.nextKey(impservice.getSiteId(), "TRIP");
						} catch (NotImplementedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (custTripId == null) {
						jobLog.addError("Couldn't create new Trip; generating unique ID failed");
						result.setOutTripId(null);
						return result;
					}
				} else {
					custTripId = impservice.getTripNo();
				}

				TripTO newTrip = new TripTO();
				newTrip.setTRIPID_CUST(custTripId);
				newTrip.setTRIPDATE(inServiceDate);
				newTrip.setPLANNEDSTARTTIME((new Timestamp(impservice.getPlannedStartTime().getTime())));
				newTrip.setPLANNEDFINISHTIME((new Timestamp(impservice.getPlannedEndTime().getTime())));
				newTrip.setPLANNEDDESPATCHTIME((new Timestamp(impservice.getDespatchBy().getTime())));
				newTrip.setENTEREDBY(impservice.getImportEnteredBy());
				newTrip.setSITEID(impservice.getSiteId());
				newTrip.setDRIVERID(props.getNewDriverId());
				newTrip.setTRUCKID(Long.parseLong(props.getNewTruckId()));
				newTrip.setTRAILERID(props.getNewTrailerId());
				newTrip.setTRAILERID_TAG(props.getNewTrailerIdTag());
				newTrip.setCACHEDPHASE(0L);
				newTrip.setTRIPCOMPLETE(false);
				newTrip.setCACHEDSTATUS("P");
				newTrip.setDESPATCH(false);

				try {
					newTrip = sicliImportDAO.createtrip(jobLog, newTrip, impservice.getSiteId());
				} catch (SQLException e) {
					e.printStackTrace();
					jobLog.addError("Couldn't add new trip; SQL error: " + e.getMessage());
					result.setOutTripId(null);
					return result;
				}

				inTripSeq = 1;
				inLastTripSeq = 1;
				result.setOutTripId(newTrip.getID());
				result.setOutLastTripId(newTrip.getID());
				result.setOutTripSeq(inTripSeq);
				result.setOutLastTripSeq(inLastTripSeq);
				result.setOutNewTripId(newTrip.getID());
				jobLog.addWarning("Added new trip " + newTrip.getID());
			}
			// NOTE: Following is dead code in RB.
			// else {
			// // assign to existing trip. otherwise the trip seq is
			// // incremented without a trip id... thus the imported services
			// // don't fall into a trip but still have incrementing seq
			// // numbers...
			// if (outTripId != null) {
			// outTripSeq = (outTripSeq == null ? 1 : outTripSeq + 1);
			// result.setOutTripSeq(outTripSeq);
			// }
			// }
			inLastTripSeq = inTripSeq;
			result.setOutLastTripSeq(inLastTripSeq);
			return result;
		}

		// check for empty string
		if (impservice.getTripId() == null) {
			jobLog.addError("Empty string in Trip");
			return result;
		}

		// get validation mode
		String validateMode = getValidationMode(impservice.getValidateTrip());

		if (ServiceModeConstant.kValidationModeCreate.equalsIgnoreCase(validateMode)) {
			if ((impservice.getTripId() != null && inLastTripId == null)
					|| (inLastTripId != null && impservice.getTripId() == null)
					|| (impservice.getTripId().longValue() != inLastTripId.longValue())) {
				// create new trip
				inLastTripId = impservice.getTripId();
				inTripSeq = 1;
				result.setOutLastTripId(inLastTripId);
				result.setOutTripSeq(inTripSeq);

				String custTripId = null;
				if (impservice.getTripNo() == null) {
					try {
						custTripId = sicliImportDAO.nextKey(impservice.getSiteId(), "TRIP");
					} catch (SQLException | NotImplementedException e) {
						e.printStackTrace();
					}
					if (custTripId == null) {
						jobLog.addError("Couldn't create new Trip; generating unique ID failed");
						result.setOutTripId(null);
						return result;
					}
				} else {
					custTripId = impservice.getTripNo();
				}

				TripTO newTrip = new TripTO();
				newTrip.setTRIPID_CUST(custTripId);
				newTrip.setTRIPDATE(inServiceDate);
				newTrip.setPLANNEDSTARTTIME((new Timestamp(impservice.getPlannedStartTime().getTime())));
				newTrip.setPLANNEDFINISHTIME((new Timestamp(impservice.getPlannedEndTime().getTime())));
				newTrip.setPLANNEDDESPATCHTIME((new Timestamp(impservice.getDespatchBy().getTime())));
				newTrip.setENTEREDBY(impservice.getImportEnteredBy());
				newTrip.setSITEID(impservice.getSiteId());
				newTrip.setDRIVERID(props.getNewDriverId());
				newTrip.setTRUCKI(props.getNewTruckId());
				newTrip.setTRAILERID(props.getNewTrailerId());
				newTrip.setTRAILERID_TAG(props.getNewTrailerIdTag());
				newTrip.setCACHEDPHASE(0L);
				newTrip.setTRIPCOMPLETE(false);
				newTrip.setCACHEDSTATUS("P");
				newTrip.setDESPATCH(false);

				try {
					newTrip = sicliImportDAO.createtrip(jobLog, newTrip, impservice.getSiteId());
				} catch (SQLException e) {
					e.printStackTrace();
					jobLog.addError("Couldn't add new trip; SQL error: " + e.getMessage());
					result.setOutTripId(null);
					return result;
				}
				inTripId = newTrip.getID();
				result.setOutTripId(newTrip.getID());
				result.setOutNewTripId(newTrip.getID());
				result.setOutLastTripId(newTrip.getID());
				jobLog.addWarning("Added new trip " + newTrip.getID());
			} else {
				// add line to previous trip
				inTripId = inNewTripId;
				inTripSeq = (inTripSeq == null ? 1 : inTripSeq + 1);
				result.setOutTripId(inTripId);
				result.setOutTripSeq(inTripSeq);
			}
		} else {
			// reset trip creation for future records
			inLastTripId = null;
			result.setOutLastTripId(inLastTripId);

			boolean foundTrip = false;
			// try to find trip record
			try {
				foundTrip = (sicliImportDAO.getTripCountById(impservice.getTripId()) == 0 ? false : true);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (NotImplementedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (!foundTrip) {
				// couldn't find trip
				if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)) {
					jobLog.addError("Trip not found");
					return result;
				} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)
						|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
					String custTripId = null;
					if (impservice.getTripNo() == null) {
						try {
							custTripId = sicliImportDAO.nextKey(impservice.getSiteId(), "TRIP");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NotImplementedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						if (custTripId == null) {
							jobLog.addError("Couldn't create new Trip; generating unique ID failed");
							result.setOutTripId(null);
							return result;
						}
					} else {
						custTripId = impservice.getTripNo();
					}
					TripTO newTrip = new TripTO();
					newTrip.setTRIPID_CUST(custTripId);
					// newTrip.setTripDate(outServiceDate);
					newTrip.setPLANNEDSTARTTIME((new Timestamp(impservice.getPlannedStartTime().getTime())));
					newTrip.setPLANNEDFINISHTIME((new Timestamp(impservice.getPlannedEndTime().getTime())));
					newTrip.setPLANNEDDESPATCHTIME((new Timestamp(impservice.getDespatchBy().getTime())));
					newTrip.setENTEREDBY(impservice.getImportEnteredBy());
					newTrip.setSITEID(impservice.getSiteId());
					newTrip.setDRIVERID(props.getNewDriverId());
					newTrip.setTRUCKI(props.getNewTruckId());
					newTrip.setTRAILERID(props.getNewTrailerId());
					newTrip.setTRAILERID_TAG(props.getNewTrailerIdTag());
					newTrip.setCACHEDPHASE(0L);
					newTrip.setTRIPCOMPLETE(false);
					newTrip.setCACHEDSTATUS("P");
					newTrip.setDESPATCH(false);

					try {
						newTrip = sicliImportDAO.createtrip(jobLog, newTrip, impservice.getSiteId());
						jobLog.addWarning("Added new trip " + newTrip.getID());
						inTripId = newTrip.getID();
						result.setOutTripId(inTripId);
					} catch (SQLException e) {
						e.printStackTrace();
						jobLog.addError("Couldn't add new trip; SQL error: " + e.getMessage());
						result.setOutTripId(null);
					}
					result.setOutTripSeq(impservice.getTripSeq());
					return result;
				} else {
					jobLog.addError("Trip validation; unknown validation mode: " + validateMode);
					return result;
				}
			} else {
				// found existing trip
				if (ServiceModeConstant.kValidationModeExist.equalsIgnoreCase(validateMode)
						|| ServiceModeConstant.kValidationModeUpdate.equalsIgnoreCase(validateMode)) {
					result.setOutTripId(impservice.getTripId());
					result.setOutTripSeq(impservice.getTripSeq());
					return result;
				} else if (ServiceModeConstant.kValidationModeNotExist.equalsIgnoreCase(validateMode)) {
					jobLog.addError("Trip exists and cannot be used again");
					return result;
				} else {
					jobLog.addError("Trip validation; unknown validation mode: " + validateMode);
					return result;
				}
			}
		}
		return result;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////
	public void mDespatchTrip(Long inTripId, int SiteId) throws SQLException, NotImplementedException {

		TripTO tripTo = sicliImportDAO.getmDespatchTrip(inTripId);

		String insertQuery = "INSERT INTO EVENT (EventTypeID, LoggedDateTime, TripId, DriverId, TrailerId, TrailerId_Tag, TruckId, DataSourceId, SiteID, IDGenerator) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		Connection conn = dataSource.getConnection();
		Long ID = getNextSequenceNumber("CUSTLOAD_SEQ", conn);

		try {
			PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);
			preparedStatement.setInt(1, 8);
			preparedStatement.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis())); // LoggedDateTime
			preparedStatement.setLong(3, inTripId); // TripId
			preparedStatement.setLong(4, tripTo.getDRIVERID()); // DriverId
			preparedStatement.setString(5, tripTo.getTRAILERID()); // TrailerId
			preparedStatement.setString(6, tripTo.getTRAILERID_TAG()); // TrailerId_Tag
			preparedStatement.setLong(7, tripTo.getTRUCKID()); // TruckId
			preparedStatement.setString(8, "AM"); // DataSourceId
			preparedStatement.setInt(9, SiteId); // SiteID
			preparedStatement.setLong(10, ID); // IDGenerator

			int rowsInserted = preparedStatement.executeUpdate();
			if (rowsInserted > 0) {
				return;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		List<String> locationId_Pickup = sicliImportDAO.getmDespatchTrip1(inTripId);

		String insertQuery1 = "INSERT INTO TRIP (Despatch,ActualDespatchTime,LocationId_Despatch,IDGenerator) VALUES (?, ?, ?, ?)";
		Long ID1 = getNextSequenceNumber("CUSTLOAD_SEQ", conn);

		try {
			PreparedStatement preparedStatement = conn.prepareStatement(insertQuery1);
			preparedStatement.setBoolean(1, true); // Despatch
			preparedStatement.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis())); // ActualDespatchTime
			if (!locationId_Pickup.isEmpty()) {
				preparedStatement.setString(3, locationId_Pickup.get(0)); // LocationId_Despatch (initialize to null)
			}
			preparedStatement.setLong(4, ID1); // ID

			int rowsInserted1 = preparedStatement.executeUpdate();
			if (rowsInserted1 > 0) {
				return;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

/////////////////////////////////////////////////////////////////////////////////////////////////
	public TripResultTO mVerifyTripRecycle(ImpJobLogTO jobLog, ImpServiceTO impservice) throws SQLException {
		int Result;
		Result = -1;

		TripResultTO tripresultTo = new TripResultTO();

		List<TripTO> TripTos = sicliImportDAO.VerifyTripRecycle(impservice.getTripNo(),
				ServiceUtil.convertDateToTimeStamp(impservice.getServiceDate()));
		if (!TripTos.isEmpty()) {
			for (TripTO tripto : TripTos) {
				tripresultTo.setID(tripto.getID());
				tripresultTo.setOutTripId(tripto.getID());

			}
		}

		return tripresultTo;
	}
}