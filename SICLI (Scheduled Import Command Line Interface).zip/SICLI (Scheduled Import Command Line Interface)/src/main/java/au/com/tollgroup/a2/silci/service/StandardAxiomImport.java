package au.com.tollgroup.a2.silci.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.tollgroup.a2.sicli.dao.SicliImportDAO2;
import au.com.tollgroup.a2.sicli.dao.SilciDispatchDAO;
import au.com.tollgroup.a2.sicli.exception.NotImplementedException;
import au.com.tollgroup.a2.sicli.model.AxiomServiceReturnTO;
import au.com.tollgroup.a2.sicli.model.DespatchDecisionTO;
import au.com.tollgroup.a2.sicli.model.EventTO;
import au.com.tollgroup.a2.sicli.model.ImpServiceTO;
import au.com.tollgroup.a2.sicli.model.LoadResultTO;
import au.com.tollgroup.a2.sicli.model.LoadServiceTO;
import au.com.tollgroup.a2.sicli.model.ReturnCreationTO;
import au.com.tollgroup.a2.sicli.model.ServiceTO;
import au.com.tollgroup.a2.sicli.model.TripResultTO;
import au.com.tollgroup.a2.sicli.model.TripTO;
import au.com.tollgroup.a2.sicli.model.TruckTrailerCapacityTO;
import au.com.tollgroup.a2.sicli.model.UnitTO;
import au.com.tollgroup.a2.sicli.model.WindowTO;
import au.com.tollgroup.a2.sicli.util.ImpJobLogTO;
import au.com.tollgroup.a2.sicli.util.ServiceQtyList;
import au.com.tollgroup.a2.sicli.util.ServiceUtil;
import au.com.tollgroup.a2.sicli.util.constants.ServiceModeConstant;
import au.com.tollgroup.a2.sicli.validation.ValidateSicliValue;


@Service
public class StandardAxiomImport {

	@Autowired
	private SicliImportDAO2 sicliImportDAO;
	
	@Autowired
	private SilciDispatchDAO silciDispatchDAO;
	
	@Autowired
	private ValidateSicliValue validateSicliValue;

	private String userOptionSwitch = "Import.UseDeliveryWindow";

	private final org.slf4j.Logger log = LoggerFactory.getLogger(this.getClass());

	public void standardImport(long siteid, Date inportdate, boolean onlyMultyLeg, boolean autoDespatch)
			throws SQLException, NotImplementedException, IOException {
		System.out.println("inside standardImport===========");
		Map<Long, Long> idmap = new LinkedHashMap<>();
		Map<Long, Long> dispatchtripmap = new LinkedHashMap<>();

		boolean multilegstatus = sicliImportDAO.isSiteMultilegEnabled(siteid);

		List<ImpServiceTO> impServList = sicliImportDAO.getImportServicesBySite(siteid, multilegstatus);

		ImpJobLogTO jobLog = new ImpJobLogTO(log);
		Long driverid=null;
		int totalservice=impServList.size();

		for (ImpServiceTO impservice : impServList) {
			 driverid=impservice.getDriverId();
			System.out.println("driverid========================="+impservice);
			Date serviceDate = null;
			Date minDate=null;
			Long loadId = null;
			Long importedLoadID = null;
			Long tripId=null;
			
			//trip processing
			Long lastTripId = null;
			Integer lastTripSeq = null;
			Integer tripSeq = null;
			Long newTripId = null;
			
			boolean bvserv = validateSicliValue.verifyServiceProcessing(impservice, jobLog);
			if(!bvserv) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean bcustvalidation = validateSicliValue.validateCustomer(jobLog, "Customer",
					impservice.getValidateCustomer(), impservice.getCustomerId(), siteid);
			if(!bcustvalidation) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validLoadType=validateSicliValue.ValidColoumValue(jobLog, "Load Type",impservice.getValidateLoadType() , "LOAD_TYPE", "LoadTypeID", impservice.getLoadType(),siteid);
			if(!validLoadType) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validLocation=validateSicliValue.ValidColoumValue(jobLog, "Location",impservice.getValidatePickup() , "LOCATION", "LocationID", impservice.getLocationIdPickup(),siteid); 
			if(!validLocation) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validTruck=validateSicliValue.ValidColoumValue(jobLog, "Truck",impservice.getValidateTruck() , "TRUCK", "TruckID", impservice.getTruckId(),siteid);
			if(!validTruck) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validTrailer=validateSicliValue.ValidColoumValue(jobLog, "Trailer",impservice.getValidateTrailer() , "TRAILER", "TrailerID", impservice.getTrailerId(),siteid);
			if(!validTrailer) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validTag_Trailer=validateSicliValue.ValidColoumValue(jobLog, "Tag Trailer",impservice.getValidateTrailerTag() , "TRAILER", "TrailerID", impservice.getTrailerIdTag(),siteid);
			if(!validTag_Trailer) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			boolean validDriver=validateSicliValue.validDriver(jobLog,impservice,driverid,siteid);
			if(!validDriver) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			validateSicliValue.ValidColoumValue(jobLog, "Unit (1)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit1(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (2)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit2(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (3)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit3(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (4)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit4(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (5)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit5(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (6)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit6(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (7)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit7(),siteid);
			
			validateSicliValue.ValidColoumValue(jobLog, "Unit (8)",ServiceModeConstant.kValidationModeCreate, "UNIT", "UnitID", impservice.getUnit8(),siteid);
			if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			
			validateSicliValue.verifyServiceType(jobLog, impservice, siteid);
			if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			
			validateSicliValue.verifyContainer(jobLog, impservice, siteid);
			if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			validateSicliValue.verifyLocation(jobLog,true, impservice, siteid);
			if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
			validateSicliValue.verifyLocation(jobLog,false, impservice, siteid);
			if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
		    
		    // verify load no
		    if(ServiceModeConstant.kValidationModeAmcor.equals(impservice.getValidateLoad())) {		    	     
		    	LoadResultTO mlload=validateSicliValue.verifyMLLoadNo(jobLog, impservice, loadId,importedLoadID , multilegstatus, siteid);
		    	 if(mlload != null) {
		    		 loadId=mlload.getLoadId();
		    		 importedLoadID=mlload.getImportedLoadId();
		    		 
		    	 } 
		     }else {
		    	 LoadResultTO load=validateSicliValue.verifyLoadNo(jobLog, impservice, loadId, importedLoadID, siteid);
		    	 if(load != null) {
		    		 loadId=load.getLoadId();
		    		 importedLoadID=load.getImportedLoadId();
		    	 } 
		    	 
		     }
		    if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}
		    
		    
		    // verify service field		    
		    if (minDate == null) {
				serviceDate = impservice.getServiceDate();
			} else if (impservice.getServiceDate() == null) {
				serviceDate = minDate;
			} else if (impservice.getServiceDate().getTime() < minDate.getTime()) {
				serviceDate = minDate;
			} else {
				serviceDate = impservice.getServiceDate();
			}

			if (serviceDate == null) {
				jobLog.addError("Missing service date");
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);				
			}
			
			// Validate Trip id
			
			if(ServiceModeConstant.kValidationModeRecycle.equals(impservice.getValidateTrip())) {
				TripResultTO trip=validateSicliValue.mVerifyTripRecycle(jobLog, impservice);		    	
		    	 if(trip != null) {
		    		 tripId=trip.getID();
		    	 }
		    	 else {
		    		 TripResultTO ttrip=validateSicliValue.verifyTrip(jobLog,impservice,lastTripId,
		    				 lastTripSeq, tripId,tripSeq, newTripId, ServiceUtil.convertDateToTimeStamp( serviceDate));
		    	 
		    		 if(ttrip != null) {
			    		 tripId=ttrip.getID();
			    	 }
		    	 }	    	 
		     }
		    if(jobLog.getRecentErrorCount()>0) {
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}  	    
		    
			
			proceeServiceRecord(jobLog,impservice,siteid,idmap,dispatchtripmap,
					serviceDate,tripId,loadId,importedLoadID);
			
			addReturnLegs(jobLog, idmap, siteid);
			autoDispatch(jobLog, dispatchtripmap,siteid);
			
			// results
			log.info(
					"Finished importing " + totalservice + " services. " + jobLog.getProcessCount() + " records processed. "
							+ (jobLog.getProcessCount() - jobLog.getFailCount()) + " services created successfully.");
			if (totalservice > 0) {
				makeNotification("Services Imported", "Services were imported into the Axiom site", siteid,
						"Import Complete", "B2B Import");
			}
			
			
		}

	}

	private void proceeServiceRecord(ImpJobLogTO jobLog, ImpServiceTO impservice, long siteId, Map<Long, Long> idmap,
			Map<Long, Long> dispatchtripmap,Date serviceDate,Long tripId, Long loadId,
			Long importedLoadID)throws NotImplementedException, SQLException, IOException {

		String idgeneratorType = "SERVICE_SEQ";
		
		Long serviceId = null;		
		Integer tripSeq = null;
		

		jobLog.resetRecent();
		jobLog.addNotice("Importing row " + impservice.getImportId());

		Long newDriverId = null;
		String newTrailerId = null;
		String newTrailerIdTag = null;
		String newTruckId = null;

		boolean addedNewService = false;
		//Long importedLoadID = null;
		ServiceTO newService = new ServiceTO();

		if (ServiceModeConstant.kValidationModeNotExist.equals(impservice.getValidateService())) {
			// add a new service record (rely on the error handling to
			// avoid duplicates)
			String serviceNo = impservice.getServiceNo();
			if (serviceNo == null) {
				try {
					serviceNo = sicliImportDAO.nextKey(siteId, "SERVICE");

				} catch (SQLException e) {
					// failed to get the next key; RB code doesn't handle
					// this scenario.
					e.printStackTrace();
                    
				}

			}

			ServiceQtyList serviceQtyList = new ServiceQtyList();

			newService.setServiceNo(serviceNo);
			newService.setServiceGroup(impservice.getServiceGroup());
			// loadid from verifying load
			newService.setLoadId(loadId);
			// validate service date
			newService.setServiceDate(serviceDate);
			newService.setServiceTypeId(impservice.getServiceType());
			String svcDesc = (impservice.getServiceDesc() == null ? ""
					: (impservice.getServiceDesc().length() > 80 ? impservice.getServiceDesc().substring(0, 80)
							: impservice.getServiceDesc()));
			newService.setServiceDesc(svcDesc);
			newService.setCustomerId(impservice.getCustomerId());
			newService.setLoadTypeId(impservice.getLoadType());
			newService.setDriverId(newDriverId);
			newService.setTruckId(newTruckId);
			newService.setTrailerId(newTrailerId);
			newService.setTrailerIdTag(newTrailerIdTag);
			newService.setContainerId(impservice.getContainerId());
			newService.setLocationIdPickup(impservice.getLocationIdPickup());
			newService.setLocationIdDrop(impservice.getLocationIdDrop());
			newService = serviceQtyList.writeToService(newService);
			newService.setDocket(impservice.getDocket());
			newService.setTripId(tripId);
			newService.setTripSeq(tripSeq);
			newService.setRemarks(impservice.getRemarksService());
			newService.setDelivered(impservice.isDelivered());
			newService.setOffsiderUsed(false);
			newService.setTodFlags(0);
			newService.setDelivered(false);
			newService.setUsed(false);
			newService.setExported(false);
			newService.setPodCreated(false);
			newService.setComplete(false);
            	if (userOptionSwitch.equalsIgnoreCase("Import.UseDeliveryWindow")) {
				// set delivery window
				List<WindowTO> deliveryWinList = sicliImportDAO.setDeliveryWindow(impservice.getLocationIdDrop(),
						impservice.getLoadType(), impservice.getServiceType(), impservice.getServiceDate(),
						impservice.getLocationIdPickup(), impservice.getCustomerId());

				if (!(deliveryWinList == null) && deliveryWinList.size() > 0) {
					for (WindowTO deliveryWin : deliveryWinList) {
						newService.setWindow1From(deliveryWin.getWindow1From());
						newService.setWindow1To(deliveryWin.getWindow1To());
						newService.setWindow2From(deliveryWin.getWindow2From());
						newService.setWindow2To(deliveryWin.getWindow2To());
					}
				} else {
					newService.setWindow1From(impservice.getWindow1From());
					newService.setWindow1To(impservice.getWindow1To());
					newService.setWindow2From(impservice.getWindow2From());
					newService.setWindow2To(impservice.getWindow2To());
				}
			}
			newService.setEnteredBy(impservice.getImportEnteredBy());
			newService.setSiteId(siteId);

			try {

				newService = sicliImportDAO.insertImportServices(newService, siteId, idgeneratorType);
			} catch (SQLException e) {
				e.printStackTrace();
				jobLog.addError("Couldn't create new service; SQL error: " + e.getMessage());

				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);

			}
			serviceId = newService.getId();
			if (serviceId != -1) {
				addedNewService = true;
			}
			makeNotification("Service Imported",
					"Service " + newService.getServiceNo() + " was imported into the Axiom site", siteId,
					"Service Imported", "B2B Import");			
			if (tripId != null) {
				cacheTripContentAggs(tripId);

			}
		} else if (ServiceModeConstant.kValidationModeExist.equals(impservice.getValidateService())) {
			// find the routing details for the service
			serviceId = impservice.getImportServiceId();

			ImpServiceTO existnewSvc = null;
			try {
				existnewSvc = sicliImportDAO.getServiceById(serviceId);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (existnewSvc == null) {
				jobLog.addError("Service not found");
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);

			}
			// update service if it is found
			try {
				sicliImportDAO.updateServiceQtyDetails(impservice, siteId, serviceId, tripId, tripSeq);
			} catch (SQLException e) {
				e.printStackTrace();
				jobLog.addError("Couldn't update service");
				validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
			}

			if (tripId != null) {
				if (!existnewSvc.isDelivered()) {
					try {
						sicliImportDAO.updateServiceTripDetails(impservice, tripId);
					} catch (SQLException e) {
						e.printStackTrace();
						jobLog.addError("Couldn't update Trip");
						validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
					}
				}
				cacheTripContentAggs(tripId);
			}

		} else if (ServiceModeConstant.kValidationModeAmcor.equals(impservice.getValidateService())) {

			
			if (loadId != null) {
				LoadServiceTO loadService = sicliImportDAO.getRoutingDetailService(siteId, loadId,
						impservice.getLocationIdPickup(), impservice.getLocationIdDrop());
				if (loadService == null) {
					try {
						Long newserviceId = sicliImportDAO.insertNewServices(impservice, serviceDate, loadId, tripId,
								tripSeq, siteId, idgeneratorType);
					} catch (SQLException e) {
						e.printStackTrace();
						jobLog.addError("Couln't create new service; SQL error");
						validateSicliValue.rejectImpServiceRecord(impservice, jobLog);

					}
				} else if (loadService.isServiceComplete()) {
					jobLog.addError("Couln't update service, it's complete");
					makeNotification("Service cannot be updated",
							"Service " + loadService.getServiceNo()
									+ " could not be updated because it has been completed.",
							siteId, "Service Import Failed", "B2B Import");
					validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
				} else {
					Long newserviceIdwithPickup = null;
					LoadServiceTO loadservicepickup = sicliImportDAO.getRoutingPickupDetailService(siteId, loadId,
							impservice.getLocationIdPickup(), impservice.getLocationIdDrop());
					if (loadservicepickup == null) {
						try {
							newserviceIdwithPickup = sicliImportDAO.insertNewServices(impservice, serviceDate, loadId,
									tripId, tripSeq, siteId, idgeneratorType);
							if (newserviceIdwithPickup != -1)
								addedNewService = true;
						} catch (SQLException e) {
							e.printStackTrace();
							jobLog.addError("Couln't create new service; SQL error");
							validateSicliValue.rejectImpServiceRecord(impservice, jobLog);

						}

					} else {
						// update service
						ImpJobLogTO newjobLog = sicliImportDAO.updateServiceTruckDetais(jobLog, impservice,
								loadservicepickup, newserviceIdwithPickup, tripId, tripSeq);
						if (newjobLog.getRecentErrorCount() > 0) {
							validateSicliValue.rejectImpServiceRecord(impservice, jobLog);
						}
					}
				}
			}
		}

		
		Long creationId = null;
		
		// add return to base leg
		if (loadId != null && addedNewService) {
			boolean isLastLeg = false;
			if (impservice.getDestinationLoc() != null && impservice.getDestinationSite() != null) {
				if (impservice.getDestinationLoc().equalsIgnoreCase(impservice.getLocationIdDrop())
						&& impservice.getDestinationSite().intValue() == (int) siteId) {
					isLastLeg = true;
				}
			}
			try {
				creationId = sicliImportDAO.getCreationID(impservice, isLastLeg);

				idmap.put(serviceId, creationId);

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// auto despatching
		boolean isAutoDespatch = false;
		if (isAutoDespatch) {
			if (loadId != null && tripId != null) {
				Integer despatchtripid = willDespatch(jobLog, loadId, siteId, impservice, newService);
				if (despatchtripid != null) {
					dispatchtripmap.put(tripId, despatchtripid.longValue());

				}
			}
		}

		try {
			sicliImportDAO.updateImportServiceStatus(idmap.get(serviceId),
					impservice.getImportId(), importedLoadID);
		} catch (SQLException e) {
			e.printStackTrace();
			jobLog.addError("Couldn't update status of import record");
			validateSicliValue.rejectImpServiceRecord(impservice, jobLog);

		}

		
	}

	public boolean makeNotification(String subject, String message, long siteId, String action, String actionGroup)
			throws NotImplementedException {
		try {
			sicliImportDAO.createNotification(action, actionGroup, siteId, subject, message, false);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private void addReturnLegs(ImpJobLogTO jobLog, Map<Long, Long> idmap, long siteId)
			throws NotImplementedException, SQLException {
		if (idmap == null || idmap.isEmpty()) {
			return;
		}

		Iterator<Map.Entry<Long, Long>> it = idmap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<Long, Long> pair = it.next();
			Long serviceId = pair.getKey();
			Long creationId = pair.getValue();
			if (serviceId != null && creationId == null) {
					return;
				}
				ReturnCreationTO rc = sicliImportDAO.getReturnCreationById(creationId);
				if (rc == null) {
					return;
				}
				AxiomServiceReturnTO asr = sicliImportDAO.getServiceReturnDetailsById(serviceId, siteId);
				if (asr == null) {
					return;
				}
				ServiceTO svc = new ServiceTO();
				svc.setServiceTypeId(rc.getServiceType());
				svc.setLoadTypeId(rc.getLoadType());
				svc.setLoadId(asr.getLoadId());
				svc.setLocationIdPickup(asr.getLocationIdPickup());
				String strLoc = null;
				if (rc.getLocationIdDrop() != null) {
					if ("**PICKUP".equalsIgnoreCase(rc.getLocationIdDrop())) {
						strLoc = asr.getLocationIdPickup();
					} else if ("**HOMELOCATION".equalsIgnoreCase(rc.getLocationIdDrop())) {
						strLoc = asr.getHomeLocationId();
					} else
						strLoc = null;

				} else {
					// generate ANS exception
					String notificationSubject = "Drop location (" + rc.getLocationIdDrop()
							+ ") is not validated. Import process failure";
					String notification = notificationSubject + ". Creation id=" + creationId + ", loadid="
							+ asr.getLoadId() + ", siteid=" + siteId + ".";
					if (!makeNotification(notificationSubject, notification, siteId, "Service Import Failed",
							"B2B Import")) {
						jobLog.addWarning("Couldn't add notification (Action id = 2) into ANS");
					}
				}

				svc.setLocationIdDrop(strLoc);
				svc.setUnit1(calcUnitField(jobLog, rc.getUnit1(), asr.getUnit1(), siteId));
				svc.setQty1(calcQtyField(jobLog, rc.getQty1(), asr.getQty1(), siteId));
				svc.setUnit2(calcUnitField(jobLog, rc.getUnit2(), asr.getUnit2(), siteId));
				svc.setQty2(calcQtyField(jobLog, rc.getQty2(), asr.getQty2(), siteId));
				svc.setUnit3(calcUnitField(jobLog, rc.getUnit3(), asr.getUnit3(), siteId));
				svc.setQty3(calcQtyField(jobLog, rc.getQty3(), asr.getQty3(), siteId));
				svc.setUnit4(calcUnitField(jobLog, rc.getUnit4(), asr.getUnit4(), siteId));
				svc.setQty4(calcQtyField(jobLog, rc.getQty4(), asr.getQty4(), siteId));
				svc.setUnit5(calcUnitField(jobLog, rc.getUnit5(), asr.getUnit5(), siteId));
				svc.setQty5(calcQtyField(jobLog, rc.getQty5(), asr.getQty5(), siteId));
				svc.setUnit6(calcUnitField(jobLog, rc.getUnit6(), asr.getUnit6(), siteId));
				svc.setQty6(calcQtyField(jobLog, rc.getQty6(), asr.getQty6(), siteId));
				svc.setUnit7(calcUnitField(jobLog, rc.getUnit7(), asr.getUnit7(), siteId));
				svc.setQty7(calcQtyField(jobLog, rc.getQty7(), asr.getQty7(), siteId));
				svc.setUnit8(calcUnitField(jobLog, rc.getUnit8(), asr.getUnit8(), siteId));
				svc.setQty8(calcQtyField(jobLog, rc.getQty8(), asr.getQty8(), siteId));
				svc.setRateId(null);
				svc.setChargeAmt(null);
				svc.setRemarks("Return logistics for Service " + asr.getServiceNo());
				svc.setDataSourceId("RL");
				svc.setTripId(asr.getTripId());
				if (asr.getTripId() != null) {
					svc.setTripSeq(sicliImportDAO.getNextTripSeq(asr.getTripId(), siteId));
				}
				svc.setSiteId(siteId);
				svc.setServiceDate(asr.getServiceDate());
				svc.setServiceDesc(asr.getServiceDesc());
				svc.setCustomerId(asr.getCustomerId());
				svc.setDriverId(asr.getDriverId());
				svc.setTruckId(asr.getTruckId());
				svc.setTrailerId(asr.getTrailerId());
				svc.setContainerId(svc.getContainerId());
				svc.setOffsiderUsed(asr.getOffsiderUsed());
				svc.setDocket(asr.getDocket());
				svc.setTrailerIdTag(asr.getTrailerIdTag());
				List<WindowTO> deliveryWinList = sicliImportDAO.setDeliveryWindow(asr.getLocationIdDrop(),
						asr.getLoadTypeId(), asr.getServiceTypeId(), asr.getServiceDate(), asr.getLocationIdPickup(),
						asr.getCustomerId());

				if (!(deliveryWinList == null) && deliveryWinList.size() > 0) {
					for (WindowTO deliveryWin : deliveryWinList) {
						svc.setWindow1From(deliveryWin.getWindow1From());
						svc.setWindow1To(deliveryWin.getWindow1To());
						svc.setWindow2From(deliveryWin.getWindow2From());
						svc.setWindow2To(deliveryWin.getWindow2To());
					}
				}
				svc.setEnteredBy(asr.getEnteredBy());

				try {
					svc = sicliImportDAO.insertImportServices(svc, siteId, "SERVICE_SEQ");
					jobLog.addNotice("Return logistics for Service " + asr.getServiceNo() + " is created");
				} catch (Exception e) {
					jobLog.addWarning("Return logistics for Service " + asr.getServiceNo()
							+ " is not created. SQL ERROR: " + e.getMessage());
				}
			}

		}
private boolean cacheTripContentAggs(long tripId) throws NotImplementedException {
	// obtain routing quantity aggregate
	String routingUnit = "RoutingUnit";
	Double routingQty = 0.0D;
	Double truckCapacity=0.0D;
	Double trailercapacity=0.0D;

	try {
		// obtain all services
		List<ServiceTO> services = sicliImportDAO.getServicesByTrip(tripId);
		if (services != null && routingUnit != null) {
			for (ServiceTO service : services) {
				routingQty += qtyForUnitFromService(service, routingUnit);
			}	
		}

		// Lookup truck and trailer capacity
		TruckTrailerCapacityTO ttcap=sicliImportDAO.getTruckTralerCapacityByTripID(tripId);
		if (services != ttcap ) {
				
			truckCapacity = ttcap.getTruckcapacity() == null ? 0.0d
					: ttcap.getTruckcapacity();
			Double trailer1Capacity = ttcap.getTrailer1capacity() == null ? 0.0d
					: ttcap.getTrailer1capacity();
			Double trailer2Capacity = ttcap.getTrailer2capacity() == null ? 0.0d
					: ttcap.getTrailer2capacity();
			trailercapacity=trailer1Capacity+trailer2Capacity;
			
		}	

		// cache aggregates
		sicliImportDAO.updateAggregateWithTripID(routingQty, truckCapacity, trailercapacity, tripId);
		
    
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	}
	return true;
}

	private Integer willDespatch(ImpJobLogTO jobLog, long loadId, long siteId, ImpServiceTO rsImp, ServiceTO svc)
			throws NotImplementedException, SQLException {
		int driverType = 0;
		if (svc.getDriverId() != null) {
			driverType = sicliImportDAO.getDriverTyeByID(svc.getDriverId());
		}
		Integer willDespatch = null;

		try {
			List<DespatchDecisionTO> despatchDecisions = sicliImportDAO.getDespatchDecision(rsImp, svc, driverType,
					siteId);

			if (despatchDecisions != null && !despatchDecisions.isEmpty()) {
				DespatchDecisionTO dec = despatchDecisions.get(0);
				if (!dec.getUsesTimeTable()) {
					willDespatch = -1;
				} else {
					// checking RailDays table
					Date railDate = sicliImportDAO.getRailDayDate(rsImp.getCustReference(), rsImp.getBatchNo());
					if (railDate != null) {
						if (System.currentTimeMillis() > railDate.getTime()) {
							// it's not clear yet
						} else {
							willDespatch = -1;
						}
					} else {
						// error, the record should be on the table
						jobLog.addError("A timetabled job is not in RAILDAYS.");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return willDespatch;
	}

	private Double calcQtyField(ImpJobLogTO jobLog, String val1, Double val2, long siteId)
			throws NotImplementedException {
		Double result = null;
		boolean validQty = false;
		if (val1 == null) {
			validQty = true;
		} else {
			if ("**COPY".equalsIgnoreCase(val1)) {
				result = val2;
			} else {
				// check if val1 is numeric
				try {
					result = Double.parseDouble(val1);
					validQty = true;
				} catch (Exception e) {
					log.error("error in calculating quantity field");
					e.printStackTrace();
				}
			}
		}

		if (!validQty) {
			// generate ANS exception
			String subject = "Qty (" + val1 + ") is not validated. Import process failure";
			String message = subject;
			result = null;
			if (!makeNotification(subject, message, siteId, "Service Import Failed", "B2B Import")) {
				jobLog.addWarning("Couldn't add notification (Action id = 2) into ANS");
			}
		}
		return result;
	}

	private String calcUnitField(ImpJobLogTO jobLog, String val1, String val2, long siteId)
			throws SQLException, NotImplementedException {

		String result = null;
		if (val1 != null) {
			if ("**COPY".equalsIgnoreCase(val1)) {
				result = val2;
			} else {
				result = val1;
			}
		}

		List<UnitTO> unitlist = sicliImportDAO.getUnitListBYSiteId(siteId, result);

		boolean validUnit = false;
		if (result != null) {
			if (unitlist != null && !unitlist.isEmpty()) {
				for (UnitTO unit : unitlist) {
					if (unit.getUnitId().equalsIgnoreCase(result)) {
						validUnit = true;
						break;
					}
				}
			}
		} else {
			// not having a Unit value is valid
			validUnit = true;
		}

		if (!validUnit) {
			// generate ANS exception
			String subject = "Unit (" + result + ") is not validated. Import process failure";
			String message = subject;
			result = null;
			if (!makeNotification(subject, message, siteId, "Service Import Failed", "B2B Import")) {
				jobLog.addWarning("Couldn't add notification (Action id = 2) into ANS");
			}
		}
		return result;
	}
	
	private Double qtyForUnitFromService(ServiceTO service, String unit) {
		if (service == null || unit == null) {
			return 0.0D;
		}
		Double result = 0.0D;
		if (unit.equalsIgnoreCase(service.getUnit1())
				&& service.getQty1() != null) {
			result += service.getQty1();
		}
		if (unit.equalsIgnoreCase(service.getUnit2())
				&& service.getQty2() != null) {
			result += service.getQty2();
		}
		if (unit.equalsIgnoreCase(service.getUnit3())
				&& service.getQty3() != null) {
			result += service.getQty3();
		}
		if (unit.equalsIgnoreCase(service.getUnit4())
				&& service.getQty4() != null) {
			result += service.getQty4();
		}
		if (unit.equalsIgnoreCase(service.getUnit5())
				&& service.getQty5() != null) {
			result += service.getQty5();
		}
		if (unit.equalsIgnoreCase(service.getUnit6())
				&& service.getQty6() != null) {
			result += service.getQty6();
		}
		if (unit.equalsIgnoreCase(service.getUnit7())
				&& service.getQty7() != null) {
			result += service.getQty7();
		}
		if (unit.equalsIgnoreCase(service.getUnit8())
				&& service.getQty8() != null) {
			result += service.getQty8();
		}
		return result;
	}
	
	private void autoDispatch(ImpJobLogTO jobLog, Map<Long, Long> dispatchtripmap, long siteId)
			throws NotImplementedException, SQLException {
		if (dispatchtripmap == null || dispatchtripmap.isEmpty()) {
			return;
		}

		Iterator<Map.Entry<Long, Long>> it = dispatchtripmap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<Long, Long> pair = it.next();
			Long despatchTripId = pair.getKey();
			String strdespatchTripId=despatchTripId.toString();
			if(strdespatchTripId==null)
				strdespatchTripId="0";
			//Long creationId = pair.getValue();
			if (silciDispatchDAO.validTripDispatch(strdespatchTripId, siteId)==1) {
				
				String details=silciDispatchDAO.getServicesDetailsByTrip(strdespatchTripId);
				silciDispatchDAO.addServicesEventQueSeq(details,strdespatchTripId, siteId);
				sicliImportDAO.getmDespatchTrip(despatchTripId);
				cacheTripStatus(despatchTripId,siteId);
            }
		}
	}
	
	////////////////////////////////////////////////////////////
	
	private TripTO cacheTripStatus(Long tripdispachid,Long siteid) throws NotImplementedException, SQLException {
		
		TripTO trip=silciDispatchDAO.getCurrentTripDetails(tripdispachid);		
		
		String status = trip.getCACHEDSTATUS();
		String originalStatus = trip.getCACHEDSTATUS();
		Long phase = trip.getCACHEDPHASE();
		Long driverId=trip.getDRIVERID();
		
		String returnServiceType=silciDispatchDAO.returnServiceType(siteid,"Return.ServiceType");

		// is the trip status F (finished)?
		if ("F".equalsIgnoreCase(status)) {
			// don't change status
			return trip;
		}

		// are there any service cancelled events for the trip?
		int serviceCancelledEventCnt = 0;
		try {
			serviceCancelledEventCnt =silciDispatchDAO.getServiceCancelledEventCountByTrip(tripdispachid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (serviceCancelledEventCnt > 0) {
			status = "C";
			phase = 2L;
		} else {
			// obtain latest event for trip for a set of recognised events
			EventTO event = null;
			try {
				event = silciDispatchDAO.getLatestEventTrip(tripdispachid,siteid
						);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			if (event == null) {
				status = "P";
				phase = 0L;
			} else {
				boolean noReturnServices = true;
				switch (event.getEventTypeId()) {
				case 16:
					
					try {
						if (tripdispachid != null && silciDispatchDAO.getReturnServiceCountByTrip(tripdispachid, returnServiceType) > 0) {
							status = "CP";
							phase = 2L;
							noReturnServices = false;
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (noReturnServices) {
						status = "UD";
						phase = 1L;
					}
					break;
				case 13:
					// drop arrive
					// are there any services on trip with returns service type?
					try {
						if (returnServiceType != null && silciDispatchDAO.getReturnServiceCountByTrip(
								tripdispachid, returnServiceType) > 0) {
							status = "CR";
							phase = 2L;
							noReturnServices = false;
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (noReturnServices) {
						status = "U";
						phase = 1L;
					}
					break;
				case 14:
					// drop depart
					// are there any undelivered services on the trip?
					boolean noUndeliveredServices = true;
					try {
						if (silciDispatchDAO.getUndeliveredServiceCountTrip(tripdispachid) > 0) {
							status = "CP";
							phase = 2L;
							noUndeliveredServices = false;
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (noUndeliveredServices) {
						// are there any services on trip with returns service
						// type?
						try {
							if (returnServiceType != null
									&& silciDispatchDAO.getReturnServiceCountByTrip(
											tripdispachid, returnServiceType) > 0) {
								status = "R";
								phase = 2L;
								noReturnServices = false;
							}
						} catch (SQLException e) {
							e.printStackTrace();
						}
						if (noReturnServices) {
							status = "T";
							phase = 1L;
						}
					}
					break;
				case 12:
					// pickup depart
					status = "T";
					phase = 1L;
					break;
				case 15:
					// pickup completed
					// is event for first service of trip?
					try {
						Long firstServiceId = silciDispatchDAO
								.getFirstServiceIdByTrip(tripdispachid);
						if (firstServiceId != null
								&& event.getServiceId() != null
								&& firstServiceId.longValue() == event
								.getServiceId().longValue()) {
							status = "LD";
							phase = 1L;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 11:
					// pickup arrive
					status = "L";
					phase = 1L;
					break;
				case 47:
					// service received
					status = "RC";
					phase = 1L;
					break;
				case 39:
					// allocated
					status = "A";
					phase = 0L;
					break;
				case 18:
					// load ready
					status = "Y";
					phase = 0L;
					break;
				case 19:
					// papwerwork ready
					status = "Y";
					phase = 0L;
					break;
				case 8:
					// despatched
					status = "D";
					phase = 0L;
					break;
				default:
					status = "P";
					phase = 0L;
				}
			}
		}

		// don't change status back to an earlier status incorrectly due to
		// out-of-sequence events
		if ("CP".equalsIgnoreCase(originalStatus)
				&& !"F".equalsIgnoreCase(status)) {
			return trip;
		}
		if ("CR".equalsIgnoreCase(originalStatus)
				&& !("CP".equalsIgnoreCase(status))
				&& !("F".equalsIgnoreCase(status))) {
			return trip;
		}
		// cache status and phase
		trip.setCACHEDSTATUS(status);
		trip.setCACHEDPHASE(phase);
		return trip;
	}

}
