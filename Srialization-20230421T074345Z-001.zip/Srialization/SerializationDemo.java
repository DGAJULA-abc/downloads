package Srialization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable {
	int id;
	String name;
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
}
public class SerializationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Student s= new Student(101,"dinesh");
      try {
    	  File f = new File("course.txt");
      FileOutputStream fout = new FileOutputStream(f);
      ObjectOutputStream out= new  ObjectOutputStream(fout);
      out.writeObject(s);
      out.close();
      fout.close();
      System.out.println("done");
      }catch(Exception e) {
    	  e.printStackTrace();
      }
      
	}
	}


