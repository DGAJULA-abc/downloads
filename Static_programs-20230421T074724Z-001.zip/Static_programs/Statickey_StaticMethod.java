package Static_programs;

class Student{
	int id;
	String name;
	static String clg="ALTS";//static variable
	 
	static void show() {//static method
	clg="SVIT";
	}
	


	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	void display() {
		System.out.println(id+" "+name+" "+clg);
	}
}


public class Statickey_StaticMethod {
public static void main(String args[]) {
	Student.show();
	Student s= new Student(1,"Dinesh");
	Student s1= new Student(2,"Dileep");
	Student s2= new Student(3,"yoga");
	s.display();
	s1.display();
	s2.display();
}
}


