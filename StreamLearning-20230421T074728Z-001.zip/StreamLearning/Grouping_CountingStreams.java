  package StreamLearning;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Grouping_CountingStreams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        List<String> key=Arrays.asList("Dinesh","Dileep","yoga","keeru","pandu","kavya","Dinesh","Dileep","yoga","keeru","pandu","kavya");
	  Map<String, List<String>> groupByWordsMap = key.stream().collect(Collectors.groupingBy(word->word));
	  System.out.println( groupByWordsMap );
	  
	  
	  Map<String, Long> counting=key.stream()
	  .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	  
	  counting.forEach((name, count)-> System.out.println(name + " -> "+ count));
	}

}
