package StreamLearning;

import java.util.Optional;

public class User {
	private String userName;
	
	public Optional<String> getUserName() {
		return Optional.ofNullable(userName);
	}
}
