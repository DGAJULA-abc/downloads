package Strings;

public class DuplicateElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String s="Dinesh Dileep yoga keeru padu kavya";
        char A[]=s.toCharArray();
        System.out.println(s);
        for(int i=1;i<s.length();i++) {
        	for(int j=i+1;j<s.length();j++) {
        		if(A[i]==A[j]) {
        			System.out.println(A[j]+"");
        			break;
        		}
        	}
        }
	}

}
