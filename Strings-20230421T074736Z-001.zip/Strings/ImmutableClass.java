package Strings;

public final class ImmutableClass {
    private final int id;
    private final String name;
    
    public int getId() {
    	return id;
    }
    public String getName() {
    	return name;
    }
    public ImmutableClass(int i, String s) {
    	this.id=i;
    	this.name=s;
    	
    }
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ImmutableClass a=new ImmutableClass(1,"Dinesh"); 
        System.out.println(a.name=="Dinesh");
        
      //  a.id=17;
        System.out.println(a.id);
	}

}
