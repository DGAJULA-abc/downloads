package Strings;

public class StringBuffer_StringBuilder {
public static void main(String args[]) {
	StringBuffer saw= new StringBuffer("dinesh");
	saw.reverse();
	saw.append(123);
	
	System.out.println(saw);
	StringBuilder s=new StringBuilder("Flipkart Training");
	s.reverse();
	System.out.println(s);
}
}
