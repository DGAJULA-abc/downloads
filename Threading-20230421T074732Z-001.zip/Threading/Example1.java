package Threading;
class MyThread extends Thread {
	int a[]= {6,4,8,9,3};
	public void run() {
		for(int i=0;i<a.length;i++) {
			a[i]=a[i]*2;
			System.out.println(a[i]);
		}
	}
}
public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   MyThread dd=new MyThread();
  // Thread t1=dd.currentThread();
   dd.start();
	}

}
