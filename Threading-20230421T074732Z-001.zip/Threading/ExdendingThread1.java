package Threading;
class O extends Thread{
	public void run() {
		System.out.println("this is dinesh");
	}
}
public class ExdendingThread1 {
public static void main(String args[]) {
	O d1=new O();
	//Thread t1=d1.currentThread();
	
	d1.start();
}
}
