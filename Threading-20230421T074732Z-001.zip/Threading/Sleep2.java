package Threading;

class Student extends Thread {
	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("hi");
			try {
				Thread.sleep(400);
			} catch (Exception e) {
				System.out.println(e);
			}
			;

		}
	}
}

class Dine extends Thread {
	public void run() {
		for (int j = 1; j <= 5; j++) {
			System.out.println("Hello");
			try {
				Thread.sleep(400);
			} catch (Exception e) {
				System.out.println(e);
			}

		}
	}
}

public class Sleep2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student t1 = new Student();
		t1.start();
		Dine t2 = new Dine();

		// try{Thread.sleep(400);}catch(Exception e) {}
		t2.start();

	}

}
