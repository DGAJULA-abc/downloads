package basic;

public class SumofDegits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int b;
         int n=1234;
         int sum=0;
         while(n!=0) {
        	 b=n%10;
        	 sum=sum+b;
        	 n=n/10;
         }
         System.out.println(sum);
	}

}
