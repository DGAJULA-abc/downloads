import { Pipe, PipeTransform } from '@angular/core';
import { AssignCourse } from '../models/assigncourse';


@Pipe({
  name: 'assignsearch'
})

export class AssignCourseSearch implements PipeTransform {
  transform(assignCourse:AssignCourse[], searchText:string): AssignCourse[] {
    if (!assignCourse || !searchText) {
      return assignCourse;
    }
    return assignCourse.filter(res =>
      res.courseName.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim()) ||
      res.courseUrl.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim()));
  }

}