import { Pipe, PipeTransform } from '@angular/core';
import { EmployeeDetails } from '../models/employee-details';


@Pipe({
  name: 'employeedetailssearch'
})

export class EmployeeSearchPipe implements PipeTransform {
  transform(dataSource:EmployeeDetails[], searchText:string): EmployeeDetails[] {
    if (!dataSource || !searchText) {
      return dataSource;
    }
    return dataSource.filter(res =>
      res.empName.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim()) ||
      res.learningHoursMeter.toString().toLocaleLowerCase().trim().includes(searchText.toString().toLocaleLowerCase().trim()));
  }

}