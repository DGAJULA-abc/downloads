import { Pipe, PipeTransform } from '@angular/core';
import { Course } from '../models/course.model';

@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {
  transform(allcourses:Course[], searchText:string): Course[] {
    if (!allcourses || !searchText) {
      return allcourses;
    }
    return allcourses.filter(res =>
      res.courseName.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim()) ||
      res.courseUrl.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim()))
  }

}