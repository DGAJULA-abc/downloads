import { Pipe, PipeTransform } from '@angular/core';
import { courses } from '../models/courses';


@Pipe({
  name: 'searchpipe'
})

export class SearchpipePipe implements PipeTransform {

  transform(courseList:courses[], searchText:string): courses[] {
    if (!courseList || !searchText) {
      return courseList;
    }
    return courseList.filter(res =>
      res.courseName.toLocaleLowerCase().trim().includes(searchText.toLocaleLowerCase().trim())); 
  }

}