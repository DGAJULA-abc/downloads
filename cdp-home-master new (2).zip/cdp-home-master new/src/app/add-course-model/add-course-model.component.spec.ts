import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCourseModelComponent } from './add-course-model.component';

describe('AddCourseModelComponent', () => {
  let component: AddCourseModelComponent;
  let fixture: ComponentFixture<AddCourseModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCourseModelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCourseModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
