import { Component, Input, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Course, CourseModel } from '../models/course.model';
import { CourseAssignmentModel } from '../models/courseAssignment.model';
import { Param } from '../models/param';
import { AddCourseService } from '../services/addCourse.service';

@Component({
  selector: 'app-add-course-model',
  templateUrl: './add-course-model.component.html',
  styleUrls: ['./add-course-model.component.css'],
})

/* prepared by Sri Sai Mahesh Sankurathri and Sai Kasimsha
  */
export class AddCourseModelComponent implements OnInit {
  @Input() course?: Course;
  minDate: any = '';
  disabledValue: boolean = false;
  formValue: FormGroup;
  courseModel: CourseModel = new CourseModel();
  courses: Course[];
  allcourses :Course[] ;
  assignments: CourseAssignmentModel[];
  categoryList: Param[] ;
  trainingPlatformList: Param[] ;
  constructor(
    private addCourseService: AddCourseService,
    private router:Router,
    private snackBar: MatSnackBar,
    public activeModal: NgbActiveModal
  ) {}

  ngOnInit(): void {
    this.findAllRecordsByCategory();
    this.findAllRecordsByTrainingPlatform();
    this.getCourses();
    const reg =
      /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
      this.formValue = new FormGroup({
        trainingPlatform: new FormControl(null, Validators.required),
        courseName: new FormControl(null, Validators.required),
        courseUrl: new FormControl(null,[ Validators.required,Validators.pattern(reg)]),
        learningHours: new FormControl(null, Validators.required),
        startDate: new FormControl(null, Validators.required),
        endDate: new FormControl(null, Validators.required),
        category: new FormControl(null, Validators.required),
        trainingType: new FormControl(null),
        priority: new FormControl(null),
      });
    if (this.course) {
      this.disabledValue = true;
      this.formValue.controls['trainingPlatform'].setValue(
        this.course.trainingPlatform
      );
      this.formValue.controls['courseName'].setValue(this.course.courseName);
      this.formValue.controls['courseUrl'].setValue(this.course.courseUrl);
      this.formValue.controls['learningHours'].setValue(
        this.course.learningHours
      );
      this.formValue.controls['category'].setValue(this.course.category);
      if (this.course.trainingType == "External")
        this.formValue.controls['trainingType'].setValue(true
        );
        if (this.course.priority == "Mandatory")
      this.formValue.controls['priority'].setValue(true
      );
      this.courseModel.course.courseId = this.course.courseId;
    }
  }

  findAllRecordsByCategory() {
    this.addCourseService.findAllRecordsByParamName("category").subscribe(res => {
      this.categoryList = res;
      console.log(this.categoryList);
    })
    return;
  }

  findAllRecordsByTrainingPlatform() {
    this.addCourseService.findAllRecordsByParamName("trainingPlatform").subscribe(res => {
      this.trainingPlatformList = res;
      console.log(this.trainingPlatformList);

    })
    return;
  }

  get trainingPlatform() {
    return this.formValue.get('trainingPlatform');
  }

  get courseName() {
    return this.formValue.get('courseName');
  }


  get courseUrl() {
    return this.formValue.get('courseUrl');
  }

  get learningHours() {
    return this.formValue.get('learningHours');
  }

  get startDate() {
    return this.formValue.get('startDate');
  }

  get endDate() {
    return this.formValue.get('endDate');
  }

  get category() {
    return this.formValue.get('category');
  }

  postCourseDetails() {
    console.log("postcourseDetails");
    this.courseModel.courseAssignment.startDate =
      this.formValue.value.startDate;
    this.courseModel.courseAssignment.endDate = this.formValue.value.endDate;
    this.courseModel.course.category = this.formValue.value.category;
    if(this.formValue.value.trainingType==true)
      this.courseModel.course.trainingType = "External";
    if(this.formValue.value.priority==true)
      this.courseModel.course.priority = "Mandatory";
    this.courseModel.course.courseName = this.formValue.value.courseName.trim();
    this.courseModel.course.trainingPlatform =
      this.formValue.value.trainingPlatform;
    this.courseModel.course.courseUrl = this.formValue.value.courseUrl;
    this.courseModel.course.learningHours = this.formValue.value.learningHours;
    let findUrl = this.courses ? this.courses.filter(course => (course.courseUrl == this.formValue.value.courseUrl)) : [];
    if (findUrl.length > 0) {
      this.openSnackBar('This course already exists', 'close');
      return;
    }
    this.addCourseService
      .addNewCourse(this.courseModel, this.courseModel.courseAssignment.userId)
      .subscribe((res) => {
        this.openSnackBar('Course added sucessfully', 'Done');
        this.router.navigate(['/home/employee']);
        this.formValue.reset();  
      });
   }

  postAssignmentDetails() {
    this.courseModel.courseAssignment.startDate =
      this.formValue.value.startDate;
    this.courseModel.courseAssignment.endDate = this.formValue.value.endDate;
    this.courseModel.course.category = this.formValue.value.category;
    if(this.formValue.value.trainingType==true)
      this.courseModel.course.trainingType = "External";
    if(this.formValue.value.priority==true)
      this.courseModel.course.priority = "Mandatory";
    this.courseModel.course.courseName = this.formValue.value.courseName.trim();
    this.courseModel.course.trainingPlatform =
    this.formValue.value.trainingPlatform;
   
    this.courseModel.course.courseUrl = this.formValue.value.courseUrl;
    this.courseModel.course.learningHours = this.formValue.value.learningHours;
    
    this.addCourseService
      .addNewAssignment(
        this.courseModel,
        this.courseModel.courseAssignment.userId
      )
      .subscribe((res) => {
        this.openSnackBar('Course added sucessfully', 'Done');
        this.formValue.reset();
        this.getCourses();
        this.router.navigate(['/home/employee']);
        
      });
  }

  getCourses() {
    this.addCourseService.getAllCourses().subscribe((res) => {
      this.courses = res;
    });
  }

  openSnackBar(message: string, action: string) {
    if (action == 'Done') {
      this.snackBar.open(message, action, {
        duration: 5000,
        panelClass: ['mat-success'],
      });
    } else {
      this.snackBar.open(message, action, {
        duration: 5000,
      });

    }
  }

  OnSubmit() {
    this.activeModal.close(); //It closes successfully
  }

}