import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CourseModel, Course } from 'src/app/models/course.model';
import { AddCourseService } from 'src/app/services/addCourse.service';
import { AddCourseModelComponent } from '../add-course-model/add-course-model.component';
import { CourseAssignmentModel } from '../models/courseAssignment.model';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css'],
  providers: [AddCourseService],

})

/* prepared by Sri Sai Mahesh Sankurathri and Sai Kasimsha
  */
export class AddCourseComponent implements OnInit {
  searchText: string;
  courses: Course[];
  allcourses: Course[]=[];
  assignments: CourseAssignmentModel[];
  formValue: FormGroup;
  courseModel: CourseModel = new CourseModel();
  status:string="Enrolled";

  constructor(
    private addCourseService: AddCourseService,
    private snackBar: MatSnackBar,
    public modalService: NgbModal,
   
  ) {}

  ngOnInit(): void {
    this.getCourseByUserId();
    this.getCoursesByEnroll();
    
  }

  onEdit(row: any) {
    this.courseModel.course = row;
    let findId = this.assignments.filter(
      (assignment) => assignment.courseId == row.courseId
    );
    if (findId.length <= 0) {
      const modalRef = this.modalService.open(AddCourseModelComponent,{backdrop: 'static',size: 'lg', keyboard: false});
      modalRef.componentInstance.course = this.courseModel.course;
      modalRef.result.then(data=> {
        setTimeout(()=>{
        this.getCourseByUserId();
        this.getCoursesByEnroll();
        }
        , 1000);
      });
      return;
    }
    this.openSnackBar('This course already exists', 'Error');
  }

  getCoursesByEnroll() {
    this.addCourseService
      .getAllCoursesByUserIdBasedOnEnroll(
        this.courseModel.courseAssignment.userId
      )
      .subscribe((res) => {
        this.allcourses = res;
      });  
  }

  getCourseByUserId() {
    this.addCourseService
      .getCoursesByUserId(this.courseModel.courseAssignment.userId)
      .subscribe((res) => {
        this.assignments = res;
      });
  }
  
 
 
  resetForm() {
    this.modalService.open(
      AddCourseModelComponent, 
      {backdrop: 'static',size: 'lg', keyboard: false}
      ).result.then(data=> {
      setTimeout(()=>{
      this.getCoursesByEnroll();
      }
      , 1000);
    });
  }

  openSnackBar(message: string, action: string) {
    if (action == 'Done') {
      this.snackBar.open(message, action, {
        duration: 5000,
        panelClass: ['mat-success'],
  
      });

    } else {
      this.snackBar.open(message, action, {
        duration: 5000,
      });
    }
  }
}
