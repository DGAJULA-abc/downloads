import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCourseComponent } from './add-course/add-course.component';
import { CanactivateGuard} from './canactive.guard';
import { EmployeeComponent } from './employee/employee.component';
import { GetallcoursesComponent } from './getallcourses/getallcourses.component';
import { HomeComponent } from './home/home.component';
import { LeadershipComponent } from './leadership/leadership.component';
import { LoginComponent } from './login/login.component';
import { ManagerAddCourseComponent } from './manager-add-course/manager-add-course.component';
import { ManagerComponent } from './manager/manager.component';
import { RoleguardGuard } from './roleguard.guard';

import { SideNavComponent } from './side-nav/side-nav.component';
import { TableComponent } from './table/table.component';
import { TrainingDetailsComponent } from './training-details/training-details.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [CanactivateGuard],
    children: [
      {
        path: 'employee',
        component: EmployeeComponent,
        canActivate: [CanactivateGuard],
      },
      {
        path: 'manager',
        component: ManagerComponent,
        canActivate: [RoleguardGuard],
      },
      // {
      //   path: 'leadership',
      //   component: LeadershipComponent,
      //   canActivate: [CanactivateGuard],
      // },
      {
        path: 'addcourse',
        component: AddCourseComponent,
        canActivate: [CanactivateGuard],
      },
      {
        path: 'sidenav',
        component: SideNavComponent,
        canActivate: [CanactivateGuard],
      },
      {
        path: 'manager-add-course',
        component: ManagerAddCourseComponent,
        canActivate: [RoleguardGuard],
      },
      {
        path: 'rewards',
        component: TableComponent,
        canActivate: [CanactivateGuard],
      },
      {
        path: 'courselist',
        component: GetallcoursesComponent,
        canActivate: [CanactivateGuard],
      },
      {
        path: 'leadership',
        component: TrainingDetailsComponent,
        canActivate: [RoleguardGuard],
      },
    ],
  },
  {
    path: 'login',
    component: LoginComponent,
  },

  { path: '', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
