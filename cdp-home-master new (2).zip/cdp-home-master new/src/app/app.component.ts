import { Component, ViewEncapsulation } from '@angular/core';
import { RoleService } from './services/role.service';
import { Router } from '@angular/router';
import jwt_decode, { JwtPayload } from 'jwt-decode';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AppComponent {
  title = 'cdp-home';
  url: any;
  userId: string = 'mdineshv';

  constructor(private roleService: RoleService, public router: Router) {}

  ngOnInit() {
    //this.tokenExtraction();
    localStorage.setItem('userId', this.userId);
    // console.log(localStorage.getItem('active')!)

    if (!localStorage.getItem('foo')) {
      localStorage.setItem('foo', 'no reload');

      location.reload();
    } else {
      localStorage.removeItem('foo');
    }
    // this.createRole();
    // this.autoLogout();
  }
  tokenExtraction() {
    const url = window.location.href;
    const urlParams = url ? url.split('?')[1] : window.location.search.slice(1);
    const encodeToken = urlParams;
    if (encodeToken != null || encodeToken != undefined) {
      const decodeToken: any = jwt_decode(encodeToken);
      const userId = decodeToken.sub;
      const expTime = decodeToken.exp;
      localStorage.setItem('userId', userId);
      localStorage.setItem('token', encodeToken);
    }
    this.createRole();
    this.autoLogout();
  }

  autoLogout(): boolean {
    if (this.checkTokenExpiration()) {
      return true;
    }

    alert('Session expired please login again');
    this.url = new URL('https://10.24.161.103:9090/APACWorld');
    window.location.href = this.url;
    localStorage.clear();
    return false;
  }
  createRole() {
    this.roleService.createRole().subscribe(
      (date) => {
        //console.log('Role Assigned');
      },
      (error) => {
        console.log('Exception', error);
      }
    );
  }

  checkTokenExpiration(): boolean {
    const encodeToken = localStorage.getItem('token');
    const decodeToken: any = jwt_decode(encodeToken!);
    if (decodeToken.exp === undefined) {
      return false;
    }

    const date = new Date(0);
    let tokenExpDate = date.setUTCSeconds(decodeToken.exp);
    if (tokenExpDate.valueOf() > new Date().valueOf()) {
      return true;
    }
    return false;
  }
}
