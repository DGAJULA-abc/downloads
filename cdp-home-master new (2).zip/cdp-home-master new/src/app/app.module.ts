import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import { MatSidenavModule } from '@angular/material/sidenav';
import { EmployeeComponent } from './employee/employee.component';
import { ManagerComponent } from './manager/manager.component';
import { LeadershipComponent } from './leadership/leadership.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { ToolBarComponent } from './tool-bar/tool-bar.component';
import { FooterComponent } from './footer/footer.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { EmployeeprofileComponent } from './employeeprofile/employeeprofile.component';
import { GetallcoursesComponent } from './getallcourses/getallcourses.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatButtonModule } from '@angular/material/button';
import { ProgressComponent } from './progress/progress.component';
import { WorkloadComponent } from './workload/workload.component';
import {
  CommonModule,
  HashLocationStrategy,
  LocationStrategy,
} from '@angular/common';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { jqxSchedulerModule } from 'jqwidgets-ng/jqxscheduler';
import { AddCourseComponent } from './add-course/add-course.component';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { HomeComponent } from './home/home.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {
  NgbAlertModule,
  NgbModule,
  NgbPaginationModule,
} from '@ng-bootstrap/ng-bootstrap';
import { ModalModule } from 'ngx-bootstrap/modal';
import { MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { SortPipe } from './Pipes/sort.pipe';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCardModule } from '@angular/material/card';
import { AddCourseModelComponent } from './add-course-model/add-course-model.component';
import { MatSelectModule } from '@angular/material/select';
import { ProgressBarModule } from 'angular-progress-bar';
import { ProgressbarComponent } from './progressbar/progressbar.component';
import { NdetailsComponent } from './ndetails/ndetails.component';
import { ManagerAddCourseComponent } from './manager-add-course/manager-add-course.component';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { BsDropdownModule, BsDropdownConfig } from 'ngx-bootstrap/dropdown';
import { AssigncourseComponent } from './assigncourse/assigncourse.component';
import { ListofemployeeComponent } from './listofemployee/listofemployee.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { TableComponent } from './table/table.component';
import { InboxComponent } from './inbox/inbox.component';
import { CalendarEventsComponent } from './calendar-events/calendar-events.component';
import { MatNativeDateModule } from '@angular/material/core';
import { MatBadgeModule } from '@angular/material/badge';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { MaterialCalendarModule } from 'material-calendar';
import { CalendarComponent } from './calendar/calendar.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import {
  NgxUiLoaderHttpModule,
  NgxUiLoaderModule,
  SPINNER,
} from 'ngx-ui-loader';
import { SearchfilterPipe } from './Pipes/searchfilter';
import { SearchpipePipe } from './Pipes/searchpipe';
import { EmployeeSearchPipe } from './Pipes/employesearch';
import { AssignCourseSearch } from './Pipes/assignsearch';
import {MatRadioModule} from '@angular/material/radio';
import { BasicAuthHttpInterceptorService } from './basic-auth-http-interceptor.service';
import { LoginComponent } from './login/login.component';
import { TrainingDetailsComponent } from './training-details/training-details.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    ManagerComponent,
    LeadershipComponent,
    SideNavComponent,
    ToolBarComponent,
    FooterComponent,
    EmployeeprofileComponent,
    GetallcoursesComponent,
    ProgressComponent,
    WorkloadComponent,
    AddCourseComponent,
    HomeComponent,
    SortPipe,
    AddCourseModelComponent,
    ProgressbarComponent,
    NdetailsComponent,
    ManagerAddCourseComponent,
    AssigncourseComponent,
    ListofemployeeComponent,
    TableComponent,
    InboxComponent,
    CalendarEventsComponent,
    CalendarComponent,
    ConfirmationComponent,
    SearchfilterPipe,
    SearchpipePipe,
    EmployeeSearchPipe,
    AssignCourseSearch,
    LoginComponent,
    TrainingDetailsComponent,
  ],
  imports: [
    MatTableModule,
    MatNativeDateModule,
    MaterialCalendarModule,
    MatDatepickerModule,
    NgxPaginationModule,
    ProgressBarModule,
    BsDropdownModule,
    MatButtonModule,
    MatTooltipModule,
    MatCardModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatSidenavModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatProgressBarModule,
    FormsModule,
    MatButtonModule,
    MatDialogModule,
    jqxSchedulerModule,
    CommonModule,
    MatMenuModule,
    NgCircleProgressModule,
    MatCheckboxModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ScrollingModule,
    NgbPaginationModule,
    NgbAlertModule,
    MatRadioModule,
    HttpClientModule,
    BrowserAnimationsModule,
    Ng2OrderModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatTableModule,
    MatSlideToggleModule,
    MatSliderModule,
    MatCardModule,
    MatSortModule,
    MatIconModule,
    MatBadgeModule,
    NgCircleProgressModule.forRoot(),
    ModalModule.forRoot(),
    NgbModule,
    NgxUiLoaderModule.forRoot({
      fgsType: SPINNER.circle,
    }),

    NgxUiLoaderHttpModule.forRoot({
      showForeground: true,
    }),
  ],
  providers: [
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: BasicAuthHttpInterceptorService,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
