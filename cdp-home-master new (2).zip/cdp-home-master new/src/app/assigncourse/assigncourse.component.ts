import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ListofemployeeComponent } from '../listofemployee/listofemployee.component';
import { AssignCoursesService } from '../services/assigncourse.service';
import { AssignCourse } from '../models/assigncourse';
import { Employee, SortedList } from '../models/employee';
import { AddCourseService } from '../services/addCourse.service';
import { EmployeeDetailsService } from '../services/employee-details.service';
import { EmployeeDetails } from '../models/employee-details';

@Component({
  selector: 'app-assigncourse',
  templateUrl: './assigncourse.component.html',
  styleUrls: ['./assigncourse.component.css'],
  providers: [AssignCoursesService],
})


export class AssigncourseComponent implements OnInit {
  assignCourse: Array<AssignCourse>;
  checked = false;
  viewType:string;
  key = '';
  disableBtn:boolean;
  reverse: boolean = false;
  managerCondition: boolean;
  p: number = 1;
  value: boolean;
  category:string;
  dataSource1: EmployeeDetails[] = [];
  dataSource2: EmployeeDetails[] = [];
  localEmployeeId:number=parseInt(localStorage.getItem('localEmployeeId')!);
  employeeList: SortedList = {
    sortedList: new Array<Employee>(),
  };
  searchText: any;


  constructor(
    private assignCourseService: AssignCoursesService,
    private addcourseService:AddCourseService,
    private employeeDetailsService: EmployeeDetailsService,
    public dialog: MatDialog
  ) {
    this.assignCourse = new Array<AssignCourse>();
  }
  @HostListener('document:keyup', ['$event'])
  handleKeydown(event: KeyboardEvent) {
    if (event.keyCode === 8) {
      console.log('checking');
      event.preventDefault;
      event.stopPropagation;
    }
  }

  ngOnInit(): void {
   
    this.addcourseService.getCourse().subscribe(status =>{
      if(status !== 'courseAdded'){
        this.assignCourseService.getViewType().subscribe((message: string) => {
          if (message == 'supervisor') {
               this.getAllCoursesUnderSupervisor();
          } else {
           this.getAllCourses();
          }
        });
      }else {
        this.assignCourseService.getViewType().subscribe((message: string) => {
          if (message == 'supervisor' ) {
               this.getAllCoursesUnderSupervisor();
          } else {
           this.getAllCourses();
          }
        });
      }
    })
   
  }
   
  getAllCourses() {
    this.assignCourseService.getAllCourses().subscribe((data) => {
      this.assignCourse = data;
      if(this.employeeList.sortedList !=null){
      this.assignCourse.map((course) => {
        const empDetails = this.localEmployeeId+'/' + course.courseId;
        this.assignCourseService
          .getAllEmployee(empDetails)
          .subscribe((data) => {
            this.employeeList = data;
            course.asignedAll = this.employeeList.sortedList.every(
              (employee) => employee.assigned == true
            ); 
          });
      });
      }
    });
  }
  getAllCoursesUnderSupervisor() {
    this.assignCourseService.getAllCourses().subscribe((data) => {
      this.assignCourse = data;
      this.assignCourse.map((course) => {
        const empDetails = this.localEmployeeId+'/' + course.courseId;
        this.assignCourseService
          .getAllEmployeeUnderSupervisor(empDetails)
          .subscribe((data) => {
            this.employeeList = data;
           
            if(this.employeeList.sortedList !=null){
            course.asignedAll = this.employeeList.sortedList.every(
              (employee) => employee.assigned == true
            );
            }
          });
      });

    });
  }

  
  openManager() {
    this.category="manager"
    this.assignCourseService.setViewType('manager'); 
  }

  openSupervisor() {
    this.category="supervisor"
    this.assignCourseService.setViewType('supervisor');
  }
 
  openDialog(courseId: Number, assignAll: boolean, managerCondition: boolean) {
      let dialogRef = this.dialog.open(ListofemployeeComponent, {
        data: { courseId: courseId, assignAll: assignAll, category: this.category },
      });
      dialogRef.afterClosed().subscribe((result) => {
        this.checked = result;
        
        if(this.category=='supervisor'){
          this.getAllCoursesUnderSupervisor();
        } else{
          this.getAllCourses();
        } 
      });
  }
  search() {
    if (this.searchText != '') {
      this.assignCourse = this.assignCourse.filter((res) => {
        return (
          res.courseName
            .toLocaleLowerCase().trim()
            .match(this.searchText.toLocaleLowerCase().trim()) ||
          res.trainingPlatform
            .toLocaleLowerCase().trim()
            .match(this.searchText.toLocaleLowerCase().trim())
        );
      });
    } else if (this.searchText == '') {
      this.ngOnInit();
    }
  }

  sort(key: any) {
    this.key = key;
    this.reverse = !this.reverse;
  }

 /* for button disabling purpose */
  getDeatilsUnderSupervisor() {
    this.employeeDetailsService.getEmployeeUnderSupervisor(this.localEmployeeId).subscribe(
      (data) => {
        this.dataSource2 = data;
      },
      (error) => console.log(error)
    );
  }

  getDetails() {
    this.employeeDetailsService.getEmployeeDetails(this.localEmployeeId).subscribe(
      (data) => {
        this.dataSource1 = data;
        
      },
      (error) => console.log(error)
    );
  }
}



