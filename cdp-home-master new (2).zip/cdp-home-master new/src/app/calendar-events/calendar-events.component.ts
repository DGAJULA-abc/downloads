import { Component, ComponentFactoryResolver, Input, OnInit } from '@angular/core';
import { addevents } from '../models/addevents';
import { AddeventsServices } from '../services/addevents.services';
import { MatCalendarCellCssClasses } from '@angular/material/datepicker';
import { CoursesService } from '../services/course.service';
@Component({
  selector: 'app-calendar-events',
  templateUrl: './calendar-events.component.html',
  styleUrls: ['./calendar-events.component.css'],
})

/* prepared by k yaswanth kumar and Gajula Dinesh
*/

export class CalendarEventsComponent implements OnInit {
  @Input() courseUpdated: boolean;
  title = 'Calendar';
  selectedDate: any;
  courses: any = ' ';
  courseList: Array<addevents>;
  todayEvents: Array<addevents>;
  mandatory: any = [];
  nonMandatory: any = [];
  overlappingDates: any = [];
  startDates: any = [];
  endDates: any = [];
  specialDates = [];
  endDate: any = [];
  flag = false;
  courseName: any;

  userId:string=localStorage.getItem('userId')!;
  calenderList: any;
  constructor(private addeventsService: AddeventsServices, private courseService:CoursesService) {
    this.courseList = new Array<addevents>();
  }

  ngOnInit(): void {
    this.getCalendar();
  }

  getCalendar(){
    this.addeventsService.getAllCourses(this.userId).subscribe((data: any) => {
      this.courseList = data.filter((course:addevents)=>course.courseStatus =="InComplete");
      this.getCourseDates(this.courseList);
      this.todayEvents = this.todaysEvents(this.courseList);
    });
  }
  DateRange(startDate: any, endDate: any) {
    let courseDates = [];
    const dateMove = new Date(startDate);
    let strDate = startDate;
    while (strDate < endDate) {
      strDate = dateMove.toISOString().slice(0, 10);
      courseDates.push(strDate);
      dateMove.setDate(dateMove.getDate() + 1);
    }
    if (startDate == endDate) {
      courseDates.push(strDate);
    }
    return courseDates;
  }
  getCourseDates(courseList: addevents[]) {
    courseList.map(
      (course: { priority: string; startDate: any; endDate: any }) => {
        let dates = this.DateRange(course.startDate, course.endDate);
        if (course.priority == 'Non-Mandatory') {
          this.nonMandatory = this.nonMandatory.concat(dates);
        }
        if (course.priority == 'Mandatory') {
          this.mandatory = this.mandatory.concat(dates);
        }
        this.startDates.push(course.startDate);
        this.endDates.push(course.endDate);
      }
    );

    const allDates = this.mandatory.concat(this.nonMandatory);
    const unique = [
      ...new Set(
        allDates.map(
          (propYoureChecking: { mandatory: any }) => propYoureChecking.mandatory
        )
      ),
    ];
    this.overlappingDates = this.mandatory.filter((element: any, i: any, a: any)=> this.nonMandatory.includes(element) || a.indexOf(element) !==i);
    this.flag = true;
  }
 

  dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      const highlightDate = this.mandatory
        .map((startDate: any) => new Date(startDate))
        .some(
          (d: any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );

      const nonMandHighlight = this.nonMandatory
        .map((startDate: any) => new Date(startDate))
        .some(
          (d: any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
      const overLap = this.overlappingDates
        .map((startDate: any) => new Date(startDate))
        .some(
          (d: any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
      const startDatesList = this.startDates
        .map((startDate: any) => new Date(startDate))
        .some(
          (d: any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
      const endDatesList = this.endDates
        .map((startDate: any) => new Date(startDate))
        .some(
          (d: any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
      let highlightsList = startDatesList
        ? 'startDates '
        : endDatesList
        ? 'endDates '
        : '';
      return (
        highlightsList +
        (overLap
          ? 'overlapDates'
          : highlightDate
          ? 'Mandatory'
          : nonMandHighlight
          ? 'Non-Mandatory'
          : '')
      );
    };
  }

  dateCheck(from: any, to: any): boolean {
    let today = new Date().toISOString().slice(0, 10);
    let fDate, lDate, cDate;
    fDate = Date.parse(from);
    lDate = Date.parse(to);
    cDate = Date.parse(today);
    if (cDate <= lDate && cDate >= fDate) {
      return true;
    }
    return false;
  }
  todaysEvents(courseList: addevents[]): addevents[] {
    let courses = courseList.filter((course: addevents) =>
      this.dateCheck(course.startDate, course.endDate)
    );
    return courses;
  }

}
