import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Route, Router } from '@angular/router';
import { courses } from '../models/courses';

import { CoursesService } from '../services/course.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css'],
})

/*prepared by P Aneesh and M D V Ajay kumar
 */
export class ConfirmationComponent implements OnInit {
  completedStatus: boolean = false;
  msg: string = '';
  condition: boolean;
  courseList: Array<courses>;
  userId: string = localStorage.getItem('userId')!;
  confirm: boolean = false;
  constructor(
    private courseService: CoursesService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public router: Router,
    public dialog: MatDialog,
    private matDialogRef: MatDialogRef<ConfirmationComponent>
  ) {}

  ngOnInit(): void {}
  setStatusOfUser() {
    this.courseService
      .setStatus(this.data.courseId, this.userId)
      .subscribe((data) => {
        this.msg = data;
        this.condition = true;
        this.confirm = true;
        this.courseService.setStatus1(data);
        this.matDialogRef.close({ confirm: this.confirm });
      });
  }
}
