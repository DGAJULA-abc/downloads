export const URLS = {
  getCourseByUser:
    'http://localhost:8080/api/addassignment/coursebyuserid',
  updateCourseStatus: 'http://localhost:8080/api/addassignment',
  getAllCourses: 'http://localhost:8080/api/course/findallcourses',
  getAllEmployee: 'http://localhost:8080/api/addassignment/employee',
  getAllEmployeeUnderSupervisor:
    'http://localhost:8080/api/addassignment/employeeundersupervisor',
  addCourseToEmployee:
    'http://localhost:8080/api/addassignment/assign',
  addCourseToEmployeeBySupervisor:
    'http://localhost:8080/api/addassignment/assignbysupervisor',
  getEmployeeDetails: 'http://localhost:8080/api/getEmployeeDetails',
  getEmployee: 'http://localhost:8080/api/getDetails',
  getEmployeeUnderSupervisor:
    'http://localhost:8080/api/getEmployeebysupervisor',
  getInboxDetails: 'http://localhost:8080/api/inbox/getInboxView',
  getLeaderBoard:
    'http://localhost:8080/api/teamleaderboard/getTeamLeaderboard',
  getProgress: 'http://localhost:8080/api/manager/allemployees',
  getSupervisorProgress:
    'http://localhost:8080/api/manager/supervisor',
  getEmployeeProgress:
    'http://localhost:8080/api/addassignment/courses',
  createRole: 'http://localhost:8080/role/create',
  getRoleByUserId: 'http://localhost:8080/getrole',
  getWorkLoadPercentage:
    'http://localhost:8080/api/learningmeter/getmeter',
  getView: 'http://localhost:8080/api/viewstatus/courses',
  addNewAssignment:
    'http://localhost:8080/api/addassignment/createassignment',
  addNewCourse: 'http://localhost:8080/api/addassignment/create',
  getCoursesByUserId:
    'http://localhost:8080/api/addassignment/coursesofuser',
  createCourse: 'http://localhost:8080/api/course/create',
  getAllCoursesByUserIdBasedOnEnroll:
    'http://localhost:8080/api/course/courses',
  findAllRecordsByParamName: 'http://localhost:8080/api/course/param',
  getEnrolledDetails:
    'http://localhost:8080/api/addassignment/leadershipView/enrolled',
  getCompletedDetails:
    'http://localhost:8080/api/addassignment/leadershipView/completed',
  getProgressLeadershipview:
    'http://localhost:8080/api/Leader/findTotalCourses',
};
