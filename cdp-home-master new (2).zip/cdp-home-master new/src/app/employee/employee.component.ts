import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../services/course.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
})
export class EmployeeComponent implements OnInit {
  courseStatus: boolean = false;

  constructor(private courseService: CoursesService) {}

  ngOnInit(): void {
    localStorage.setItem('active', 'employee');
    this.courseService.setStatus1("ajay");
  }

  getCourseStatus(event: any) {
    if (event) {
      console.log(event);
      this.courseStatus = !this.courseStatus;
    }
  }
}
