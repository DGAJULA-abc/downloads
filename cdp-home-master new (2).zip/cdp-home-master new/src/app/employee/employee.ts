export class Employee {
    userId?:string;
    password?:string;
    conformPassword?:string;

    constructor(){}
}
