
import { Component, OnInit } from '@angular/core';
import { profileCard } from '../models/profileCard';
import { EmployeeDetailsService } from '../services/employee-details.service';

@Component({
  selector: 'app-employeeprofile',
  templateUrl: './employeeprofile.component.html',
  styleUrls: ['./employeeprofile.component.css'],
})
/* prepared by P Ravikanth and B Rajesh */
export class EmployeeprofileComponent implements OnInit {
  profilecard = new profileCard();
  employeeId = '';
  globalEmployeeId = '';
  fullName = '';
  designation = '';
  emailId = '';
  n1EmployeeId = '';
  n1EmployeeName = '';
  supervisorId = '';
  supervisorName = '';
  location = '';
  userId:string=localStorage.getItem("userId")!
  constructor(private employeeService: EmployeeDetailsService) {}

  ngOnInit(): void {
    this.getEmployeeDetails();
  }

  getEmployeeDetails() {
    this.employeeService.getEmployee(this.userId).subscribe(
      (data) => {
        localStorage.setItem("userId",data.userIds )
        localStorage.setItem('localEmployeeId', data.localEmpIds);
        localStorage.setItem('globalEmployeeId', data.globalEmpIds);
        localStorage.setItem('fullName', data.fullNames);
        localStorage.setItem('designation', data.designations);
        localStorage.setItem('emailId', data.emailIds);
        localStorage.setItem('n1EmployeeId', data.n1EmpIds);
        localStorage.setItem('n1EmployeeName', data.n1EmpNames);
        localStorage.setItem('supervisorId', data.supervisorLocalIds);
        localStorage.setItem('supervisorName', data.supervisorNames);
        localStorage.setItem('location', data.citys);
        this.fullName=data.fullNames;
        this.designation=data.designations;
        this.emailId=data.emailIds;
        this.globalEmployeeId=data.globalEmpIds;
        this.employeeId=data.localEmpIds;
        this.n1EmployeeId=data.n1EmpIds;
        this.n1EmployeeName=data.n1EmpNames;
        this.supervisorId=data.supervisorLocalIds;
        this.supervisorName=data.supervisorNames;
        this.userId=data.userIds;
        this.location=data.citys;
      
      },
      (error) => {
        console.log('No data found');
      }
    );
  }
}
