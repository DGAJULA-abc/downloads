import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { courses } from 'src/app/models/courses';
import { ConfirmationComponent } from '../confirmation/confirmation.component';
import { CoursesService } from '../services/course.service';
import { RoleService } from '../services/role.service';

@Component({
  selector: 'app-courses',
  templateUrl: './getallcourses.component.html',
  styleUrls: ['./getallcourses.component.css'],
  providers: [CoursesService],
})
export class GetallcoursesComponent implements OnInit {
  @Output() courseCompleted = new EventEmitter();
  courseList: Array<courses>;
  SortbyParam = '';
  dayLeftValue: boolean;
  SortDirection = 'asc';
  date: Date;
  number: number;
  msg: string = '';
  checkbox: any;
  searchText: string;
  p: number = 1;
  value: number;
  listEmpty: boolean = false;
  items = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);
  userId: string = localStorage.getItem('userId')!;

  constructor(
    private courseService: CoursesService,
    public dialog: MatDialog,
    private roleService: RoleService
  ) {
    this.courseList = new Array<courses>();
    this.date = new Date();
    this.number = 0;
  }

  ngOnInit(): void {
    this.getAllCourses();
  }
  getAllCourses() {
    this.courseService.getAllCourses(this.userId).subscribe((data) => {
      this.courseList = data;
      if (this.courseList.length > 0) {
        this.listEmpty = true;
      }
    });
  }

  onSortDirection() {
    if (this.SortDirection === 'desc') {
      this.SortDirection = 'asc';
    } else {
      this.SortDirection = 'desc';
    }
  }

  onSortbyParam() {
    this.SortbyParam = 'priority';
    this.SortDirection = 'asc';
   
  }
  onSortbyParam1() {
    this.SortbyParam = 'priority';
    this.SortDirection = 'desc';
    
  }
  onSortbyParam2() {
    this.SortbyParam = 'endDate';
    this.SortDirection = 'desc';
   
  }
  onSortbyParam3() {
    this.SortbyParam = 'endDate';
    this.SortDirection = 'asc';
   
  }

  calculateDiff(enddate: Date) {
    let currentDate = new Date();
    enddate = new Date(enddate);

    this.value = Math.floor(
      (Date.UTC(enddate.getFullYear(), enddate.getMonth(), enddate.getDate()) -
        Date.UTC(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate()
        )) /
        (1000 * 60 * 60 * 24)
    );
    if (this.value < 0) {
      this.dayLeftValue = true;
      return this.value;
    } else {
      return this.value;
    }
  }

  search() {
    if (this.searchText != '') {
      this.courseList = this.courseList.filter((res) => {
        return res.courseName
          .toLocaleLowerCase()
          .trim()
          .match(this.searchText.toLocaleLowerCase().trim());
      });
    } else if (this.searchText == '') {
      this.ngOnInit();
    }
  }
  openDialog(courseId: any, event: any) {
    let dialogRef = this.dialog.open(ConfirmationComponent, {
      data: { courseId: courseId },
    });
    dialogRef.afterClosed().subscribe((result) => {
  
      if (result) {
        this.courseCompleted.emit(true);
        this.getAllCourses();
     
      } else {
        event.target.checked = false;
      }
    });
  }
}
