import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';

import { NotificationInterface } from '../models/notificationinterface';
import { AddCourseService } from '../services/addCourse.service';
import { CoursesService } from '../services/course.service';
import { NotificationService } from '../services/notification.service';
import { RoleService } from '../services/role.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  @ViewChild(MatSidenav)
  sidenav!: MatSidenav;
  @Input() insideSideNav!: MatSidenav;
  notificationList: Array<NotificationInterface> = [];
  count: any;
  userId: string = localStorage.getItem('userId')!;
  url: any;
  isAuthenticated: boolean;
  userInfo: any;
  idToken: any;
  currentDate: any;
  employeeCondition: boolean;
  // value =localStorage.setItem('active', 'employee');
  active: string = localStorage.getItem('active')!;

  //  active:string="employee";

  public authService: any;
  condition: boolean;
  myVar: boolean = false;
  constructor(
    private notificationService: NotificationService,
    private observer: BreakpointObserver,
    private roleService: RoleService,
    private router: Router,
    private addCourseService: AddCourseService,
    private courseService: CoursesService
  ) {
    this.count = 0;
  }
  ngOnInit(): void {
    this.courseService.getStatus1().subscribe((status) => {
      this.count = 0;
      this.getAllCourses();
    });
    this.currentDate = new Date();
     this.courseService.getStatus1().subscribe((status) => {
      this.active = localStorage.getItem('active')!;
     });
  }

  parseIdToken(idToken: string) {
    if (typeof idToken !== 'string') {
      idToken = JSON.stringify(idToken);
    }
    const idTokenSplit = idToken.split('.');
    const idTokenObject = {
      encoded: [] as any,
      decoded: [] as any,
    };
    idTokenSplit.forEach((element) => {
      idTokenObject.encoded.push(element);
    });
    idTokenObject.decoded.push(JSON.parse(atob(idTokenObject.encoded[0])));
    idTokenObject.decoded.push(JSON.parse(atob(idTokenObject.encoded[1])));
    this.userId = JSON.parse(atob(idTokenObject.encoded[1])).sub;
    localStorage.setItem('userId', this.userId);
    return idTokenObject;
  }

  mangerCheck() {
    this.condition = true;
    this.roleService.getRoleByUserId(this.userId).subscribe(
      (data) => {
        if (data.roleName === 'Manager') {
          this.active = 'manager';
          //  localStorage.setItem('active', 'manager');
          localStorage.setItem('active', 'manager');
          this.router.navigate(['/home/manager']);
          this.myVar = true;
        } else {
          alert('No Access, Please Contact Admin');
        }
      },
      (error) => {
        alert('No Access');
        console.log(error);
      }
    );
  }
leadershipCheck(){
  this.condition = true;
    this.roleService.getRoleByUserId(this.userId).subscribe(
      (data) => {
        if (data.roleName === 'Manager') {
          this.active = 'leadership';
          //  localStorage.setItem('active', 'manager');
          localStorage.setItem('active', 'leadership');
          this.router.navigate(['/home/leadership']);
          this.myVar = true;
        } else {
          alert('No Access, Please Contact Admin');
        }
      },
      (error) => {
        alert('No Access');
        console.log(error);
      }
    );


}


  employeeCheck() {
    this.employeeCondition = !this.employeeCondition;
    localStorage.setItem('active', 'employee');
  }
  // leadershipCheckCondition() {
  //   this.employeeCondition = !this.employeeCondition;
  //   localStorage.setItem('active', 'manager');
  // }

  logoutEmployee() {
    localStorage.clear();
    this.url = new URL('https://10.24.161.103:9090/APACWorld');
    window.location.href = this.url;
    alert('Signout Successfull..!');
  }

  getAllCourses() {
    this.notificationService.getAllCourses(this.userId).subscribe((data) => {
      this.notificationList = data;
      this.notificationList = this.notificationList.filter(
        (notification) => notification.courseStatus === 'InComplete'
      );
      this.notificationList.map((notification) => {
        notification.RemainingDays = this.calculateDiff(notification.endDate);
        if (
          notification.RemainingDays >= 1 &&
          notification.RemainingDays <= 5
        ) {
          this.count++;
        }
      });
    });
  }
  calculateDiff(enddate: Date) {
    let currentDate = new Date();
    enddate = new Date(enddate);
    let value = Math.floor(
      (Date.UTC(enddate.getFullYear(), enddate.getMonth(), enddate.getDate()) -
        Date.UTC(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate()
        )) /
        (1000 * 60 * 60 * 24)
    );
    if (value < 0) {
      return 0;
    } else {
      return value;
    }
  }
}
