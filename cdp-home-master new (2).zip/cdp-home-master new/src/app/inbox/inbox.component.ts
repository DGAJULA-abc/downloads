import { Component, OnInit } from '@angular/core';
import { Inbox } from '../models/inbox';
import { InboxService } from '../services/inbox.service';


@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
  /* prepared by S Brunda and ch pushpaLatha */
export class InboxComponent implements OnInit {
  toggle:boolean=true;
 inboxDetails:Inbox[]=[];
 userId:string=localStorage.getItem('userId')!;

  constructor( private inboxService:InboxService) { }

  ngOnInit(): void {
   this.getInboxDetails();
   
  }

  getInboxDetails(){
    this.inboxService.getInboxDetails(this.userId).subscribe(
      data=>{
        this.inboxDetails=data;
      },
      error=>{
        console.log(error);
      }
    );
  }
  
  messageSeen(){
  this.toggle=false;

  }
 

}
