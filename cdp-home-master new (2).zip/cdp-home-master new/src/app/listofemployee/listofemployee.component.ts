import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AssigncourseComponent } from '../assigncourse/assigncourse.component';
import { CalendarComponent } from '../calendar/calendar.component';
import { Assign } from '../models/assign';
import { SortedList } from '../models/employee';
import { AssignCoursesService } from '../services/assigncourse.service';

@Component({
  selector: 'app-listofemployee',
  templateUrl: './listofemployee.component.html',
  styleUrls: ['./listofemployee.component.css'],
  providers: [AssignCoursesService],
})

/* prepared by P Aneesh and M D V Ajay kumar */
export class ListofemployeeComponent implements OnInit {
  employeeList: SortedList = {
    sortedList:[],
  };
  
  searchText: string;
  assignList: Assign = {
    courseId: 0,
    userIds: new Array<string>(),
    endDate: new Date(),
    managerName: '',
    supervisorId:0,
    managerId:0,
    supervisorName:''
  };
  minDate: any;
  dateFormat: Date = this.assignList.endDate;
  checkboxDisableCondition: boolean;
  localEmployeeId:number=parseInt(localStorage.getItem('localEmployeeId')!);
  constructor(
    private assignCourseService: AssignCoursesService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<AssigncourseComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
  ) {}

  ngOnInit(): void {
    this.getDate();
    if(this.data.category=="supervisor"){
      this.getAllEmployeesSupervisor(this.data.courseId, this.data.assignAll)
      this.assignList.courseId = this.data.courseId;
    } else {
      this.getAllEmployees(this.data.courseId, this.data.assignAll);
      this.assignList.courseId = this.data.courseId;
     }
  }
 

  getAllEmployees(courseId: Number, assignAll: boolean) {
    const empDetails = this.localEmployeeId+'/' + courseId;
    this.assignCourseService.getAllEmployee(empDetails).subscribe((data) => {
      this.employeeList = data;
      if (assignAll) {
        this.assignToAll();
      }
    });
  }

  getAllEmployeesSupervisor(courseId: Number, assignAll: boolean) {
    const empDetails1 = this.localEmployeeId+'/' +courseId;
    this.assignCourseService
      .getAllEmployeeUnderSupervisor(empDetails1)
      .subscribe((data) => {
        this.employeeList = data;
        if (assignAll) {
          this.assignToAll();
        }
      });
  }

  search() {
    if (this.searchText != '') {
      this.employeeList.sortedList = this.employeeList.sortedList.filter(
        (res) => {
          return res.fullName
            .toLocaleLowerCase().trim()
            .match(this.searchText.toLocaleLowerCase().trim());
        }
      );
    } else if (this.searchText == '') {
       this.ngOnInit();
    }
  }

  addEmployees(userIds: string, managerName: string,managerId:number,supervisorId:number, supervisorName:string) {
    if(this.data.category=="supervisor" ){
         if (this.assignList.userIds.includes(userIds)) {
        const indexx = this.assignList.userIds.indexOf(userIds);
        this.assignList.userIds.splice(indexx, 1);
      } else {
        this.assignList.userIds.push(userIds);
      }
      this.assignList.supervisorName = supervisorName;
      this.assignList.supervisorId = supervisorId;
    } else {
     if (this.assignList.userIds.includes(userIds)) {
        const indexx = this.assignList.userIds.indexOf(userIds);
        this.assignList.userIds.splice(indexx, 1);
      } else {
        this.assignList.userIds.push(userIds);
      }
      this.assignList.managerName = managerName;
      this.assignList.managerId=managerId;
      this.assignList.supervisorId =supervisorId;
    
     }
  }

  openSnackBar(message: string, action: string) {
    if (action == 'Done') {
      this.snackBar.open(message, action, {
        duration: 5000,
        panelClass: ['mat-success'],
      });
    } else {
      this.snackBar.open(message, action, {
        duration: 5000,
      });
    }
  }

  getDate() {
    var date: any = new Date();
    var toDate: any = date.getDate();
    if (toDate < 10) {
      toDate = '0' + toDate;
    }
    var month = date.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    var year = date.getFullYear();
    this.minDate = year + '-' + month + '-' + toDate;
  }

  assignToEmployees(snack:boolean) {
    if (this.assignList.endDate == this.dateFormat || this.assignList.userIds.length == 0) {
      if ( this.assignList.endDate === this.dateFormat ) {
        this.openSnackBar('Add an Expected EndDate', 'Error');
      } else {
        this.openSnackBar('Add an Employee', "Error");
      }
    } else {
      if(this.data.category=="supervisor"){
           if (this.assignList.userIds.length != 0 && this.assignList.endDate != this.dateFormat) {
           this.assignCourseService
            .addCourseToEmployeeBySupervisor(this.assignList)
            .subscribe((datas) => {
              this.assignList.userIds = new Array<string>();
              this.getAllEmployeesSupervisor(
                this.data.courseId,
                this.data.assignAll
              );
            });
    
          this.openSnackBar('Course assigned successfully', 'Done');
        }
      } else {
          if (this.assignList.userIds.length != 0 && this.assignList.endDate != this.dateFormat) {
              this.assignCourseService
                .addCourseToEmployee(this.assignList)
                .subscribe((datas) => {
                  this.assignList.userIds = new Array<string>();
                  this.getAllEmployees(this.data.courseId, this.data.assignAll);
                });
           
              this.openSnackBar('Course assigned successfully', 'Done');
            }
          }
        }
  }
  assignToAll() {
    if(this.data.category=="supervisor") {
            if(this.employeeList.sortedList !=null){
              this.assignList.userIds = this.employeeList.sortedList
                .filter((i) => i.assigned == false)
                .map((item) => {
                return item.userId;
                });
               }
              this.checkboxDisableCondition = true;
             if(this.employeeList.sortedList !=null){
              this.assignList.supervisorName =
              this.employeeList.sortedList[0].supervisorName;
              this.assignList.supervisorId = this.employeeList.sortedList[0].supervisorId;
            }
              
     } else {
  
              this.assignList.userIds = this.employeeList.sortedList
                .filter((i) => i.assigned == false)
                .map((item) => {
                  return item.userId;
                });
              this.checkboxDisableCondition = true;
              this.assignList.managerName = this.employeeList.sortedList[0].n1EmpName;
              this.assignList.managerId=this.employeeList.sortedList[0].n1EmpId;
          }
    }

    /* navigation  for employee calendar */
  openDialog(userId: string) {
    this.dialog.open(CalendarComponent, { data: { userId: userId } });
  }

}
