import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoleService } from '../services/role.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  url:any
  constructor(private roleService: RoleService, private router:Router) { }

  ngOnInit(): void {
    if(this.roleService.isUserLoggedIn()){
         this.router.navigate(['/home/employee'])
         localStorage.setItem('active', 'employee');
    }else{
      this.url=new URL("http://10.51.108.242:9090/mg-login");
      window.location.href=this.url;
    }
  }

}
