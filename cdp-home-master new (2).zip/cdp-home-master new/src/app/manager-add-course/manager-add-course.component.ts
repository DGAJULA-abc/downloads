import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Course, CourseModel } from 'src/app/models/course.model';
import { AddCourseService } from 'src/app/services/addCourse.service';
import { Param } from '../models/param';


@Component({
  selector: 'app-manager-add-course',
  templateUrl: './manager-add-course.component.html',
  styleUrls: ['./manager-add-course.component.css'],
  providers: [AddCourseService],
})
export class ManagerAddCourseComponent implements OnInit {
  courses: Course[] = [];
  categoryList: Param[] = [];
  trainingPlatformList: Param[] = [];
  formValue: FormGroup;
  courseModel: CourseModel = new CourseModel();
  course: Course = new Course();


  constructor(private addCourseService: AddCourseService, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.getCourses();
    this.findAllRecordsByCategory();
    this.findAllRecordsByTrainingPlatform();
    const reg =/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
    this.formValue = new FormGroup({
      trainingPlatform: new FormControl(null, Validators.required),
      courseName: new FormControl(null, Validators.required),
      courseUrl: new FormControl(null,[ Validators.required,Validators.pattern(reg)]),
      learningHours: new FormControl(null, Validators.required),
      category: new FormControl(null, Validators.required),
      trainingType: new FormControl(null),
      priority: new FormControl(null),
    
    });
     
  }

  openSnackBar(message: string, action: string) {
    if (action == 'Done') {
      this.snackBar.open(message, action, {
        duration: 5000,
        panelClass: ['mat-success'],
      });

    } else {
      this.snackBar.open(message, action, {
        duration: 5000,
      });

    }
  }

  managerAddCourse() {
    this.course.category = this.formValue.value.category;
    if(this.formValue.value.trainingType==true)
      this.course.trainingType = "External";
    if(this.formValue.value.priority==true)
      this.course.priority = "Mandatory";
    this.course.courseName = this.formValue.value.courseName.trim();
    this.course.trainingPlatform = this.formValue.value.trainingPlatform;
    this.course.courseUrl = this.formValue.value.courseUrl;
    this.course.learningHours = this.formValue.value.learningHours;
    let findUrl = this.courses ? this.courses.filter(course => (course.courseUrl == this.formValue.value.courseUrl)) : [];
      if (findUrl.length > 0) {
        this.openSnackBar('Course already exists', 'close');
        return;
      }
    this.addCourseService.createCourse(this.course).subscribe(
        (res) => {
          this.openSnackBar('Course added sucessfully', 'Done');
          this.addCourseService.setCourse(res)
          this.formValue.reset();
          this.getCourses();
        }
      );  
  } 

  getCourses() {
      this.addCourseService.getAllCourses().subscribe(res => {
        this.courses = res;
      })
      return;
  }

  findAllRecordsByCategory() {
    this.addCourseService.findAllRecordsByParamName("category").subscribe(res => {
      this.categoryList = res;
    })
    return;
  }

  findAllRecordsByTrainingPlatform() {
    this.addCourseService.findAllRecordsByParamName("trainingPlatform").subscribe(res => {
      this.trainingPlatformList = res;
    })
    return;
  }

  get trainingPlatform() {
    return this.formValue.get('trainingPlatform');
  }
  get courseName() {
    return this.formValue.get('courseName');
  }
  get courseUrl() {
    return this.formValue.get('courseUrl');
  }
  get learningHours() {
    return this.formValue.get('learningHours');
  } 
  get trainingType() {
    return this.formValue.get('trainingType');
  }
  get priority() {
    return this.formValue.get('priority');
  }
  get category() {
    return this.formValue.get('category');

  }
}