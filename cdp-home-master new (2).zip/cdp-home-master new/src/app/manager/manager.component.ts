import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../services/course.service';
@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css'],
})
export class ManagerComponent implements OnInit {
  constructor(private courseService: CoursesService) {}

  ngOnInit(): void {
    localStorage.setItem('active', 'manager');
    this.courseService.setStatus1('ajay');
  }
}
