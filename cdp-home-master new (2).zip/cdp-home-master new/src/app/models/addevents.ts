export interface addevents {
  courseId?: number;
  courseName: string;
  platformName: string;
  trainingPlatform: string;
  startDate: Date;
  endDate: Date;
  priority: string;
  category:string;
  courseStatus: string;
  completedDateTime: Date;
}
