export interface AssignCourse {
  courseId: number;
  trainingPlatform: string;
  courseName: string;
  platformName: string;
  courseUrl: string;
  learningHours: number;
  assigned: boolean;
  paginator: any;
  asignedAll?: boolean;
}