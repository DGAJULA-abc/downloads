export interface AssignSupervisor {
    courseId: number;
    userIds: Array<string>;
    endDate: Date;
    managerName: string;
    supervisorName:string;
    supervisorId:number;
    managerId:number;
  }