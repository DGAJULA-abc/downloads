import { CourseAssignmentModel } from './courseAssignment.model';
export class CourseModel {
  courseAssignment: CourseAssignmentModel = {
    startDate: new Date(0),
    endDate: new Date(0),
    courseId: 0,
    userId:localStorage.getItem('userId')!,
    assignedBy: '',
  };

  course: Course = {
    trainingPlatform: '',
    courseName: '',
    courseUrl: '',
    learningHours: 0,
    category: '',
    status:'',
    trainingType: 'Internal',
    priority:'Non-Mandatory'
  };

}

export class Course {
  courseId?: number;
  trainingPlatform: string;
  courseName: string;
  courseUrl: string;
  learningHours: number;
  category: string;
  trainingType: string = "Internal";
  priority: string="Non-Mandatory";
  status: string;
}