export class CourseAssignmentModel {
  assignmentId?: number;
  startDate: Date;
  endDate: Date;
  courseId: number;
  userId: string;
  assignedBy: string;
}
