export interface courses {
  courseId?: number;
  courseName: string;
  trainingPlatform: string;
  startDate: Date;
  endDate: Date;
  priority: string;
  courseStatus: string;
  completedDateTime: Date;
  assignedBy:string;
  courseUrl:string
}
