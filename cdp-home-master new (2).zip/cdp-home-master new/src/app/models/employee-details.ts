export class EmployeeDetails {
  empId: number;
  empName: string;
  subBus: string;
  unifiedGrade: string;
  primarySkill: string;
  coursesEnrolled: number;
  learningHoursMeter: number;
  userId: string;
}
