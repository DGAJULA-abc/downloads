export interface enrolleddetails {
  trainingType: string;
  trainingName: string;
  qtr1: number;
  qtr2: number;
  qtr3: number;
  qtr4: number;
  total: number;
  percentage: number;
}
