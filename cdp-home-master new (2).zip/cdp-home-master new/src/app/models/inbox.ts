export class Inbox {
  assignedBy: string;
  courses: string[];
}
