export class LearningMeter{
    startDate:Date;
    endDate:Date;
    learningHours:number;
    learningMeter:number;
}