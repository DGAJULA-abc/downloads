export interface progress{
    totalEmployees : Number;
    totalMandatoryCourses : Number;
    mandatoryCoursesCompletion : Number;
}