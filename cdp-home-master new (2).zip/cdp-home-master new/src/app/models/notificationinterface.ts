export interface NotificationInterface {
    courseName:string,
    startDate:Date,
    endDate:Date,
    assignmentId: Number,
    userId: String,        
    courseId: Number,
    courseStatus: String,
    completedDateTime:Date,
    assignedBy: String,
    RemainingDays ?: Number
 }