export class Param {
    paramId?: number;
    paramNane: string;
    paramCode: number;
    paramValue: string;
  }