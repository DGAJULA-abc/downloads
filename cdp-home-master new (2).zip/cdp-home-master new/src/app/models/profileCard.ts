export class profileCard {
    empId: number;
    userId: string;
    title: string;
    fullName: string;
    gender: string;
    designation: string;
    emailId: string;
    n1EmpId: number;
    n1EmpName: string;
    supervisorId: number;
    supervisorName: string;
    assigned: boolean;
  }
  