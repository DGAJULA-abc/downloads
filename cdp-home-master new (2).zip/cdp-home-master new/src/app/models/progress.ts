export interface progress {
  totalEnrolledCourses: Number;
  inProgressCourses: Number;
  completedCourses: Number;
  assignedCourses: Number;
}
