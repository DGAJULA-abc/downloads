export class TeamLeaderboard {
  employeeName: string;
  gradePoints: number;
  employeeId: number;
  completedDateTime: any;
  completedCourse: number;
  certificate: number;
  rank: number;
}
