export class leaderprogress {
  averageLearningHrs: any = Number;
  uniqueResourcesUpskilled: any = Number;
  internalTrainings: any = Number;
  externalTrainings: any = Number;
}
