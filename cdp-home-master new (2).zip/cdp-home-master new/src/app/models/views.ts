export interface Views {
    courseId: number;
    courseName: string;
    courseStatus: string;
    designations: string;
    endDate: Date;
    startDate: Date;
    userId: string;
  }
  