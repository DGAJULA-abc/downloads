import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdetailsComponent } from './ndetails.component';

describe('NdetailsComponent', () => {
  let component: NdetailsComponent;
  let fixture: ComponentFixture<NdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
