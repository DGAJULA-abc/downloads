import {
  Component,
  Input,
  OnInit,
} from '@angular/core';
import { EmployeeDetails } from '../models/employee-details';
import { Views } from '../models/views';
import { EmployeeDetailsService } from '../services/employee-details.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { ViewsService } from '../services/views.service';

@Component({
  selector: 'app-ndetails',
  templateUrl: './ndetails.component.html',
  styleUrls: ['./ndetails.component.css'],
})
export class NdetailsComponent implements OnInit {
  displayedColumns: string[] = [
    'empId',
    'empName',
    'email',
    'coursesEnrolled',
    'learningHoursMeter',
    'ViewCourseStatus',
  ];
  dataSource: EmployeeDetails[] = [];
  closeResult = '';
  views = new Array<Views>();
  Completed: any = '';
  InProgress: any = '';
  searchText: any;
  p: number = 1;
  viewType:string;
  toggleColor: boolean ;
  disableBtn: boolean=false ;
  disableBtn2: boolean=false ;
 localEmployeeId:number=parseInt(localStorage.getItem("localEmployeeId")!)
 key = '';
 reverse: boolean = false;
  @Input()
  userName: string;
  constructor(
    private employeeDetailsService: EmployeeDetailsService,
    private viewservice: ViewsService,
    private modalService: NgbModal,
    private router: Router
  ) {}

  open(content: any, userId: string) {
    this.views = [];
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title' })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;
        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
    this.viewservice.getview(userId).subscribe(
      (data) => {
        this.views = data;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  ngOnInit(): void {
    this.getDetails();

    this.employeeDetailsService.getEmployeeUnderSupervisor(this.localEmployeeId).subscribe(
      (data) => {
       if (data.length==0){
         this.disableBtn= !this.disableBtn;
       }
      },
      (error) => console.log(error)
    );
  }
  
  getDetails() {
    this.toggleColor=true;
    this.employeeDetailsService.setViewType('manager');
    this.employeeDetailsService.getEmployeeDetails(this.localEmployeeId).subscribe(
      (data) => {
        this.dataSource = data;
        if(data.length==0){
          this.disableBtn2= !this.disableBtn2;
        }
       
      },
      (error) => console.log(error)
    );
  }
  getDeatilsUnderSupervisor() {
    this.toggleColor= !this.toggleColor;
    this.employeeDetailsService.setViewType('supervisor');
    this.employeeDetailsService.getEmployeeUnderSupervisor(this.localEmployeeId).subscribe(
      (data) => {
        this.dataSource = data;
       if (this.dataSource.length==0){
         this.disableBtn=true;
       }
      },
      (error) => console.log(error)
    );
  }
 
  getview(userId: string) {
    const views1 = userId;
    this.viewservice.getview(views1).subscribe((data) => {
      this.views = data;
    });
  }

  goToViewStatus() {
    this.router.navigate(['/viewstatus']);
  }

 
  sort(key: any) {
    this.key = key;

    this.reverse = !this.reverse;
  }
}
