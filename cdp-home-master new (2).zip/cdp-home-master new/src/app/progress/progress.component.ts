import { Component, OnInit } from '@angular/core';
import { progress } from '../models/progress';
import { CoursesService } from '../services/course.service';
import { ProgressService } from '../services/progress.service';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css'],
})

/* prepared by P Ravikanth and B Rajesh */
export class ProgressComponent implements OnInit {
  progresss!: progress;
  constructor(
    private service: ProgressService,
    private courseService: CoursesService
  ) {}

  ngOnInit(): void {
    this.courseService.getStatus1().subscribe((status) => {
      this.getProgress();
    });
  }

  getProgress() {
    this.service.getProgress().subscribe((data) => {
      this.progresss = data;
    });
  }
}
