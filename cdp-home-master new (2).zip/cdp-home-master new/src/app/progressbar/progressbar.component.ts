import { Component, OnInit } from '@angular/core';
import { progress } from '../models/managerprogress';
import { EmployeeDetailsService } from '../services/employee-details.service';
import { ProgressService } from '../services/managerprogress.service';

@Component({
  selector: 'app-progressbar',
  templateUrl: './progressbar.component.html',
  styleUrls: ['./progressbar.component.css'],
})

/* prepared by P Ravikanth and B Rajesh */

export class ProgressbarComponent implements OnInit {
  progresses!: progress;
  localEmployeeId:number=parseInt(localStorage.getItem("localEmployeeId")!)

  constructor(
    private service: ProgressService,
    private employeeDetailsService: EmployeeDetailsService) {}

  ngOnInit(): void {
    this.employeeDetailsService.getViewType().subscribe((message: string) => {
      if (message == 'manager') {
        this.managerAssignCourse();
      } else {
        this.supervisorAssignCourse();
      }
    });

  }

  managerAssignCourse() {
    this.service.getProgress(this.localEmployeeId).subscribe((data) => {
      this.progresses = data;
    });
  }

  supervisorAssignCourse() {
    this.service.getSupervisorProgress(this.localEmployeeId).subscribe((data) => {
      this.progresses = data;
    });

  }
}
  
