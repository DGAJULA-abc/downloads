import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { RoleService } from './services/role.service';
@Injectable({
  providedIn: 'root',
})
export class RoleguardGuard implements CanActivate {
  url: any;
  roleCreate: string = localStorage.getItem('active')!;
  constructor(
    private _service: RoleService,
    private snackBar: MatSnackBar,
    private router: Router
  ) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (this._service.isUserLoggedIn() && this.roleCreate != 'employee') {
      return true;
    }
    this.snackBar.open('No access', 'close', {
      duration: 3000,
      verticalPosition: 'top',
    });

    // this.router.navigate(['/home/manager']);
    return false;
  }
}

