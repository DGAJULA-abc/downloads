import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AppComponent } from '../app.component';
import { RoleService } from '../services/role.service';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationGuard implements CanActivate {
  url:any
  userId:string=localStorage.getItem("userId")!
  roleName:string
  constructor(private authenticationService:AuthenticationService, private router: Router,public appCompoment:AppComponent,private roleService:RoleService) { }


canActivate(
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree
  {
   this.roleService.getRoleByUserId(this.userId).subscribe(data=>{
     this.roleName=data.roleName;
   })
    if(this.roleName=="Manager"){
      this.router.navigate(["/home/manager"]);
    return true;
    
    }else{
       alert("Please enter credentials to login");
      this.router.navigate(["/home/employee"]);
     return false;
   }
  } 
  

}
