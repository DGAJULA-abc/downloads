import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { CourseAssignmentModel } from '../models/courseAssignment.model';
import { Course, CourseModel } from '../models/course.model';
import { URLS } from '../constants/constants.url';

const headers = new HttpHeaders().set('Content-Type', 'application/json');

@Injectable({ providedIn: 'root' })
export class AddCourseService {
  
  courseAssignment: CourseAssignmentModel = new CourseAssignmentModel();
  courseModel: CourseModel;
  course: Course;
  // naming should be proper and this shouldbe moved to respective env files

  private subject = new Subject<any>();
  private statusObs = new BehaviorSubject<any>('courseAdded');

  setCourse(data: any) {
    this.statusObs.next(data);
  }
  getCourse() {
    return this.statusObs;
  }
 
  constructor(private httpClient: HttpClient) {}

  //course assignment Api's

  addNewAssignment(courseModel: CourseModel, userId: any): Observable<Object> {
    return this.httpClient
      .post(`${URLS.addNewAssignment}/${userId}`, courseModel,{headers})
      .pipe(
        map((res: any) => {
          return res;
        })
      );
  }

  addNewCourse(courseModel: CourseModel, userId: any): Observable<Object> {
    return this.httpClient
      .post(`${URLS.addNewCourse}/${userId}`, courseModel,{headers})
      .pipe(
        map((res: any) => {
          return res;
        })
      );
  }

  getCoursesByUserId(userId: any) {
    return this.httpClient
      .get<any>(
        `${URLS.getCoursesByUserId}/${userId}`,{headers}
      )
      .pipe(
        map((res: any) => {
          return res;
        })
      );
  }

  //course apis

  createCourse(course: Course): Observable<Object> {
    return this.httpClient.post(`${URLS.createCourse}`, course,{headers}).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  getAllCourses() {
    return this.httpClient.get<any>(`${URLS.getAllCourses}`,{headers}).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  getAllCoursesByUserIdBasedOnEnroll(userId: any) {
    return this.httpClient
      .get<any>(`${URLS.getAllCoursesByUserIdBasedOnEnroll}/${userId}`,{headers})
      .pipe(
        map((res: any) => {
          return res;
        })
      );
  }
  
  findAllRecordsByParamName(name:any) {
    return this.httpClient
      .get<any>(`${URLS.findAllRecordsByParamName}/${name}`,{headers})
      .pipe(
        map((res: any) => {
         return res;
        })
      );
  }
}
