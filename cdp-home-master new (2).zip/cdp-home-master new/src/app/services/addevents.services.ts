import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { addevents } from '../models/addevents';
import { URLS } from '../constants/constants.url';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})

export class AddeventsServices {
  constructor(private httpClient: HttpClient) {}
  getAllCourses(userId: any): Observable<addevents[]> {
    return this.httpClient.get<addevents[]>(`${URLS.getCourseByUser}/${userId}`,{headers});
  }

}
