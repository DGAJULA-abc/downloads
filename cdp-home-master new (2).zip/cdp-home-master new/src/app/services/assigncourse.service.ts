import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AssignCourse } from '../models/assigncourse';
import { SortedList } from '../models/employee';
import { Assign } from '../models/assign';
import { AssignSupervisor } from '../models/assignsupervisor';
import { URLS } from '../constants/constants.url';


const headers = new HttpHeaders().set('Content-Type', 'application/json');
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
};

@Injectable({
  providedIn: 'root',
})
export class AssignCoursesService {
  private viewType = new BehaviorSubject<string>('manager');
  
   getViewType(): any {
     return this.viewType.asObservable();
  }

  constructor(private httpClient: HttpClient) {
    
  }
  setViewType(viewType: string) {
     this.viewType.next(viewType);
  }

  getAllCourses(): Observable<AssignCourse[]> {
    return this.httpClient.get<AssignCourse[]>(
      `${URLS.getAllCourses}`,{headers}
    );
  }

  getAllEmployee(empDetails: String): Observable<SortedList> {
    return this.httpClient.get<SortedList>(
     `${URLS.getAllEmployee}/`+empDetails,{headers}
    );
  }

  getAllEmployeeUnderSupervisor(empDetails1: String): Observable<SortedList> {
    return this.httpClient.get<SortedList>(
     `${URLS.getAllEmployeeUnderSupervisor}/`+
        empDetails1,{headers}
    );
  }

  addCourseToEmployee(assigns: Assign): Observable<Assign> {
    return this.httpClient.post<Assign>(
      `${URLS.addCourseToEmployee}`,
      JSON.stringify(assigns),{headers}
      
    );
  }
  addCourseToEmployeeBySupervisor(assigns: AssignSupervisor): Observable<Assign> {
    return this.httpClient.post<Assign>(
      `${URLS.addCourseToEmployeeBySupervisor}`,
      JSON.stringify(assigns),
      {headers}
    );
  }
}
