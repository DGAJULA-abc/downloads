import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { courses } from '../models/courses';
import { URLS } from '../constants/constants.url';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    
  }),
};
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class CoursesService {
  private subject = new Subject<any>();
  private statusObs = new BehaviorSubject<any>(null);
  private viewObs = new BehaviorSubject<any>(null);

  constructor(private httpClient: HttpClient) {}

  setStatus1(data: any) {
    this.statusObs.next(data);
  }

  getStatus1() {
    return this.statusObs;
  }

  setViewType(data: any) {
    this.viewObs.next(data);
  }

  getViewType() {
   return this.viewObs;
  }

  getAllCourses(userId: any): Observable<courses[]> {
    return this.httpClient.get<courses[]>(`${URLS.getCourseByUser}/${userId}`, {
      headers,
    });
  }

  setStatus(courseId: any, userId: any): Observable<string> {
    return this.httpClient.put<string>(
      `${URLS.updateCourseStatus}/${courseId}/${userId}`,
      { headers }
    );
  }
  
}
