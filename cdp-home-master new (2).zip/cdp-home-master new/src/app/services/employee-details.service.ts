import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
import { EmployeeDetails } from '../models/employee-details';


const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class EmployeeDetailsService {
  private viewType = new BehaviorSubject<string>('manager');
  getViewType(): any {
    return this.viewType.asObservable();
  }
  constructor(private http: HttpClient) {}
  setViewType(viewType: string) {
    this.viewType.next(viewType);
  }
  getEmployeeDetails(localEmployeeId:number): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(
      `${URLS.getEmployeeDetails}/${localEmployeeId}`,{headers}
    );
  }
 
  getEmployee(userId:string): Observable<any> {
    return this.http.get<any>(
      `${URLS.getEmployee}/${userId}`,{headers}
    );

  }
  getEmployeeUnderSupervisor(localEmployeeId:number): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(
      `${URLS.getEmployeeUnderSupervisor}/${localEmployeeId}`,{headers}

    );
  }
}