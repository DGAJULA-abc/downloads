import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
import { completiondetails } from '../models/completedmodel';
import { enrolleddetails } from '../models/enrolledmodel';

const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class EnrolledService {
  // getEnrolled(){
  //    return this.http.get<any>("http://localhost:8080/api/addassignment/leadershipView/enrolled/CSD/Compliance/2022")
  //    .pipe(map((res:any)=>{
  //         return res;
  //    }))
  // }

  constructor(private http: HttpClient) {}
  getEnrolled(
    serviceLine: string,
    category: string,
      year:number,
      columnName: string,
 commonCounter:number
  ): Observable<enrolleddetails> {
    return this.http.get<enrolleddetails>(
      `${URLS.getEnrolledDetails}/${serviceLine}/${category}/${year}/${columnName}/${commonCounter}`,{headers}
      // `http://localhost:8080/api/addassignment/leadershipView/enrolled/${serviceLine}/${category}/2022`
    );
  }

  getCompleted(
    serviceLine: string,
    category: string,
    year:number,
    columnName: string,
 commonCounter:number
  ): Observable<completiondetails> {
    return this.http.get<completiondetails>(
       `${URLS.getCompletedDetails}/${serviceLine}/${category}/${year}/${columnName}/${commonCounter}`,{headers}
      // `http://localhost:8080/api/addassignment/leadershipView/completed/${serviceLine}/${category}/2022`
    );
  }
}
