import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
import { Inbox } from '../models/inbox';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class InboxService {
  constructor(private http: HttpClient) {}

  getInboxDetails(userId: string): Observable<Inbox[]> {
    return this.http.get<Inbox[]>(
      `${URLS.getInboxDetails}/${userId}`,{headers}
    );
  }
  
}
