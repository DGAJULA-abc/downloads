import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { leaderprogress } from '../models/trainingdetailsmodel';
import { URLS } from '../constants/constants.url';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class LeadershipService {
  constructor(private http: HttpClient) {}
  getProgress(): Observable<leaderprogress> {
    return this.http.get<leaderprogress>(
     `${URLS.getProgressLeadershipview}`,{headers} 
      // 'http://localhost:8080/api/Leader/findTotalCourses'
    );
  }
}
