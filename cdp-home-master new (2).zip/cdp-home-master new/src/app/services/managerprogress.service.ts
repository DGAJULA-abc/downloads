import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, JsonpClientBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
import { progress } from '../models/managerprogress';
import { URLS } from '../constants/constants.url';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class ProgressService {
  constructor(private http: HttpClient) {}

  getProgress(localEmployeeId:number): Observable<progress> {
    return this.http.get<progress>(
      `${URLS.getProgress}/${localEmployeeId}`,{headers}
    );
  }
  getSupervisorProgress(localEmployeeId:number):Observable<progress>{
    return this.http.get<progress>(
      `${URLS.getSupervisorProgress}/${localEmployeeId}`,{headers}

    );

  }
}
