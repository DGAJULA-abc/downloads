import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { NotificationInterface } from '../models/notificationinterface';
import { URLS } from '../constants/constants.url';


const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private httpClient: HttpClient) { }

  getAllCourses(userId: any): Observable<NotificationInterface[]> {
    return this.httpClient.get<NotificationInterface[]>(
      `${URLS.getCourseByUser}/${userId}`,{headers}
    );
  }
}