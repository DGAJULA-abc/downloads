import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
import { progress } from '../models/progress';

const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root'

})

export class ProgressService {
  constructor(private http:HttpClient) { }

  getProgress() : Observable<progress>{
    return this.http.get<progress>(`${URLS.getEmployeeProgress}`+

    '/' +

    localStorage.getItem('userId'),{headers});
   }

}