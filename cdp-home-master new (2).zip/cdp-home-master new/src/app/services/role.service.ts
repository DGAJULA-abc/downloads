import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class RoleService {
  userId: string = localStorage.getItem('userId')!;
  constructor(private http: HttpClient) {}

  public createRole() {
    console.log(this.userId);
    return this.http.post<any>(
      `${URLS.createRole}`,
      { userIds: this.userId },
      { headers }
    );
  }
  public getRoleByUserId(userId: String): Observable<any> {
    return this.http.get<any>(`${URLS.getRoleByUserId}/${userId}`, { headers });
  }

  isUserLoggedIn() {
    let userId = localStorage.getItem('userId');
    let token = localStorage.getItem('token');
    return !(userId === null && token === null);
  }
  
}
