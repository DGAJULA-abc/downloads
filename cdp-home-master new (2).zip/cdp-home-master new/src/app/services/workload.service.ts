import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URLS } from '../constants/constants.url';
import { LearningMeter } from '../models/learningmeter';
const headers = new HttpHeaders().set('Content-Type', 'application/json');
@Injectable({
  providedIn: 'root',
})
export class WorkloadService {
  constructor(private _http: HttpClient) {}

  getWorkloadPercentage(userId: string): Observable<LearningMeter> {
    return this._http.get<LearningMeter>(
      `${URLS.getWorkLoadPercentage}/${userId}`,{headers}
    );
  }
}
