import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoleService } from '../services/role.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {
  userId:String=localStorage.getItem('userId')!;
  condition:boolean
  constructor(private roleService:RoleService, private router: Router) { }

  ngOnInit(){
    
  }

  mangerCheck(){
     this.condition =true
    this.roleService.getRoleByUserId(this.userId).subscribe(
      (data)=>{        
        if (data.roleName === "Manager") {
          this.router.navigate(['/home/manager']);
         
        } else{
          alert("No Access, Please Contact Admin")
        }
      },
      error=>{
        alert("No Access")
        console.log(error);
      }
      
    );
  }
  
  employeeCheck(){
   this.condition =false
  }

}
