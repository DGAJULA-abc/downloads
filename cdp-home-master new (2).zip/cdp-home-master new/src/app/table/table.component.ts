import { Component, OnInit } from '@angular/core';
import { TeamLeaderboard } from '../models/team-leaderboard';
import { LeaderboardService } from '../services/leaderboard.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
})

/* prepared by S Brunda and Ch PushpaLatha */

export class TableComponent implements OnInit {
  constructor(private leaderboardService: LeaderboardService) {}
  teamLeaderboard: TeamLeaderboard[];
  colorCodes: string[] = ['#FFD700', '#c0c0c0', '#CD7F32'];
  ngOnInit(): void {
    this.leaderboardService.getLeaderboard().subscribe(
      (data) => {
        this.teamLeaderboard = data;
        console.log(data);
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
