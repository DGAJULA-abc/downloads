import { Component, Input, OnInit } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { NotificationInterface } from '../models/notificationinterface';
import { AddCourseService } from '../services/addCourse.service';
import { CoursesService } from '../services/course.service';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-tool-bar',
  templateUrl: './tool-bar.component.html',
  styleUrls: ['./tool-bar.component.css'],
})
export class ToolBarComponent implements OnInit {
  @Input() insideSideNav!: MatSidenav;
  notificationList: Array<NotificationInterface> = [];
  count: any;
  userId: string = localStorage.getItem('userId')!;
  url: any;

  constructor(
    private notificationService: NotificationService,
    public router: Router,
  ) {
    this.count = 0;
  }

  ngOnInit(): void {
     this.getAllCourses()
  }

  getAllCourses() {
    this.notificationService.getAllCourses(this.userId).subscribe((data) => {
      
      this.notificationList = data.filter(
        (notification) => notification.courseStatus === 'InComplete'
      );
      this.notificationList.map((notification) => {
        notification.RemainingDays = this.calculateDiff(notification.endDate);
        if (
          notification.RemainingDays >= 1 &&
          notification.RemainingDays <= 5
        ) {
          this.count++;
        }
      });
    });
    
  }

  calculateDiff(enddate: Date) {
    let currentDate = new Date();
    enddate = new Date(enddate);
    let value = Math.floor(
      (Date.UTC(enddate.getFullYear(), enddate.getMonth(), enddate.getDate()) -
        Date.UTC(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate()
        )) /
        (1000 * 60 * 60 * 24)
    );
    if (value < 0) {
      return 0;
    } else {
      return value;
    }
  }
  logoutEmployee() {
    localStorage.clear();
    this.url = new URL('http://10.24.161.103:9090/mg-login');
    window.location.href = this.url;
    alert('Signout Successfull..!');
  }
}
