import { Component, OnInit } from '@angular/core';
import { enrolleddetails } from '../models/enrolledmodel';
import { CoursesService } from '../services/course.service';
import { EnrolledService } from '../services/enrolled.service';
import { LeadershipService } from '../services/leadership.service';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-training-details',
  templateUrl: './training-details.component.html',
  styleUrls: ['./training-details.component.css'],
})
export class TrainingDetailsComponent implements OnInit {


  fileName: string = '';
  completedFileName: string = '';
  isShownEnrolled: boolean = true;
  isShownCompleted: boolean = false;
  isEmpty: boolean = false;
  board:string="All"
 serviceLine: string = 'All';
  category: string = 'All';
  columnName:string='Training Name';
  active2:string='All';

  ctrTrainingName:number=1; 
  ctrTrainingType:number=0;
  ctrQtr1: number = 0;
  ctrQtr2: number = 0;
  ctrQtr3: number = 0;
  ctrQtr4: number = 0;
  ctrTotal: number = 0;
  ctrPercentage: number = 0;
commonCounter:number=1;
  //selectCheckBox(targetType: CheckBoxType) {
  // If the checkbox was already checked, clear the currentlyChecked variable
  //if(this.currentlyChecked === targetType) {
  // this.currentlyChecked = CheckBoxType.NONE;
  //return;
  //}]

  //this.currentlyChecked = targetType;
  //}

  // serviceLine:any[];
  // serviceLine:['Windstorm','Bombasto','Magneta','Tornado'];
  enrolledList: Array<enrolleddetails>;

  //enrolled
  isEnrolled: boolean = true;
  //   checkEnrolled() {
  //   // this.isShown = ! this.isShown;
  // this.isEnrolled=true;
  // this.isCompleted=false;
  // this.isShownEnrolled=true;
  // this.isShownCompleted=false;
  //   }
  //completion
  // isCompleted: boolean =false ;
  // checkCompleted() {
  //   // this.isShown1 = ! this.isShown1
  //   this.isCompleted=true;
  //   this.isEnrolled=false;
  // }

  //   onChange(e:any)
  // {
  //   if (e.target.id == "enrolled-checkbox") {
  //       this.isEnrolled= true;
  //       this.isCompleted= false;
  //     }
  //   if (e.target.id == "completion-checkbox") {
  //       this.isCompleted= true;
  //       this.isEnrolled= false;
  //     }

  // }

  p: number = 1;
  //enrolled!:any;

  progresses!: any;
  key: string = 'i';
  reverse: boolean = false;
  enrolled!: any;
  completed!: any;
  value!:any;
  total:number=0;
  board1: number = 2022;
  year: number=2022;
  // coloumn:string;

  constructor(
    private service: EnrolledService,
    private service1: LeadershipService,
    private courseService: CoursesService,
  ) {
    this.enrolledList = new Array<enrolleddetails>();
    // this.serviceLine=['CSD','ORACLE','TESTING','JAVA']
  }

  ngOnInit(): void {
    // this.service.getEnrolled("JAVA","Compliance").subscribe((data:any)=>{
    //   this.enrolledList=data;
    //   console.log(this.enrolledList)
    // })

    // this.api.getCompleted("JA").subscribe((data:any)=>{
    //   this.completed=data;
    //    console.log(this.completed)
    // })
    this.toggleShowCompleted();
    this.toggleShowEnrolled();

    this.service1.getProgress().subscribe((data: any) => {
      this.progresses = data;
      // console.log(this.progresses);
    });
    localStorage.setItem('active', 'leadership');
    this.courseService.setStatus1('ajay');
  }

  //   getEnrolled(serviceLine:any){
  //     console.log(serviceLine);
  //     this.service.getEnrolled(serviceLine,"Compliance").subscribe((data:any)=>{
  //       this.enrolledList=data;
  //       console.log(this.enrolledList);

  //   })
  // }
  get2023() {

    this.year = 2023;
    this.board1 = 2023;

    // console.log(this.serviceLine);

    // console.log(this.category);

    if (this.isShownEnrolled === true) {

      // this.toggleShowEnrolled();

      // this.toggleShowCompleted();

      this.toggleShowEnrolled();

      this.service

        .getEnrolled(this.serviceLine, this.category, this.year,this.columnName,this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

    if (this.isShownCompleted === true) {

      // this.toggleShowCompleted();

      // this.toggleShowEnrolled();

      this.toggleShowCompleted();

      this.service

        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

  }
  get2022() {

    this.year = 2022;

    this.board1 = 2022;

    // console.log(this.serviceLine);

    // console.log(this.category);

    if (this.isShownEnrolled === true) {

      // this.toggleShowEnrolled();

      // this.toggleShowCompleted();

      this.toggleShowEnrolled();

      this.service

        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

    if (this.isShownCompleted === true) {

      // this.toggleShowCompleted();

      // this.toggleShowEnrolled();

      this.toggleShowCompleted();

      this.service

        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

  }
  get2021() {

    this.year = 2021;

    this.board1 = 2021;

    // console.log(this.serviceLine);

    // console.log(this.category);

    if (this.isShownEnrolled === true) {

      // this.toggleShowEnrolled();

      // this.toggleShowCompleted();

      this.toggleShowEnrolled();

      this.service

        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

    if (this.isShownCompleted === true) {

      // this.toggleShowCompleted();

      // this.toggleShowEnrolled();

      this.toggleShowCompleted();

      this.service

        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

  }
  get2020() {

    this.year = 2020;

    this.board1 = 2020;

    // console.log(this.serviceLine);

    // console.log(this.category);

    if (this.isShownEnrolled === true) {

      // this.toggleShowEnrolled();

      // this.toggleShowCompleted();

      this.toggleShowEnrolled();

      this.service

        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

    if (this.isShownCompleted === true) {

      // this.toggleShowCompleted();

      // this.toggleShowEnrolled();

      this.toggleShowCompleted();

      this.service

        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

        .subscribe((data: any) => {

          this.enrolledList = data;

          // console.log(this.enrolledList);

        });

    }

  }
//download data  

exportexcel(): void {
this.fileName='EnrolledDetails_'+this.serviceLine+'_'+this.category+'_'+this.year+'.xlsx';
this.completedFileName='CompletedDetails_'+this.serviceLine+'_'+this.category+'_'+this.year+'.xlsx';

    let element;
if( this.isShownEnrolled===true){
element = document.getElementById('enrolled-table');
}
  if(this.isShownCompleted===true) {
    element = document.getElementById('completed-table');
  }  

    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  if( this.isShownEnrolled===true){
 XLSX.writeFile(wb, this.fileName);
  }
  if(this.isShownCompleted===true){
    XLSX.writeFile(wb, this.completedFileName);

  }
   
  }
        
    //  completedexportexcel(): void {
    // let element = document.getElementById('completed');
    //  const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element); 
    //  const wb: XLSX.WorkBook = XLSX.utils.book_new();
    //   XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    //    XLSX.writeFile(wb, this.completedFileName);}
  getAllServiceLines() {
    this.serviceLine = 'All';
    this.board='All';
    // console.log(this.serviceLine);
    // console.log(this.category);

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  getCsd() {
    this.serviceLine = 'CSD';
    this.board='CSD';
    console.log(this.serviceLine);
    console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      // this.service
      //   .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
      //   .subscribe((data: any) => {
      //     this.enrolledList = data;
      //      console.log(this.enrolledList);
        // });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      // this.service
      //   .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
      //   .subscribe((data: any) => {
      //     this.enrolledList = data;
      //     // console.log(this.enrolledList);
      //   });
    }
  }

  getOracle() {
    this.enrolledList=[];
    console.log(this.enrolledList);
    this.serviceLine = 'ORACLE';
    this.board='ORACLE';
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      // this.service
      //   .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
      //   .subscribe((data: any) => {
      //     this.enrolledList = data;
      //     //  console.log(this.enrolledList);
      //   });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
     this.toggleShowCompleted();
      // this.service
      //   .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
      //   .subscribe((data: any) => {
      //     this.enrolledList = data;
      //     // console.log(this.enrolledList);
      //   });
    }
  }

  getTesting() {
    this.serviceLine = 'TESTING';
    this.board='TESTING';
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  getJava() {
    this.serviceLine = 'JAVA';
    this.board='JAVA';
    // console.log(this.serviceLine);
    // console.log(this.category);

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  getAllCategories(category: any) {
    this.category = 'All';
    // console.log(this.serviceLine);
    // console.log(this.category);
     this.active2='All';
    // console.log(this.isShownEnrolled);
    // console.log(this.isShownCompleted);

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }


  
  getCompliance(category: any) {
    this.category = 'Compliance';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Compliance';

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }
  
  getTechnical(category: any) {
    this.category = 'Technical';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Technical';

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  
  getFunctional(category: any) {
    this.category = 'Functional';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Functional';

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  getSoftSkill(category: any) {
    this.category = 'Soft Skill';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Soft Skill';

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }

  
  getLeadership(category: any) {
    this.category = 'Leadership';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Leadership';

    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          // console.log(this.enrolledList);
        });
    }
  }
  getSector(category: any) {
    this.category = 'Sector';
    // console.log(this.serviceLine);
    // console.log(this.category);
    this.active2='Sector';
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
         
          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if(null===data)
          {
            this.isEmpty=true;
          }
          else{
            this.isEmpty=false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }


  getTrainingName(columnName: any) {
    this.columnName = 'Training Name';
    this.ctrTrainingName = this.ctrTrainingName+1;
    this.ctrTrainingType=0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage = 0;
    this.commonCounter=this.ctrTrainingName%2; 
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter )
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }


  getPercentage(columnName: any) {
    this.columnName = 'Percentage';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage = this.ctrPercentage+1;
    this.commonCounter = this.ctrPercentage % 2; 
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getTrainingType(columnName: any) {
    this.columnName = 'Training Type';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = this.ctrTrainingType+1;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage = 0;
    this.commonCounter = this.ctrTrainingType % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getQtr1(columnName: any) {
    this.columnName = 'Qtr1';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = this.ctrQtr1+1;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage = 0;
    this.commonCounter = this.ctrQtr1 % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getQtr2(columnName: any) {
    this.columnName = 'Qtr2';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = this.ctrQtr2+1;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage =0;
    this.commonCounter = this.ctrQtr2 % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getQtr3(columnName: any) {
    this.columnName = 'Qtr3';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = this.ctrQtr3+1;
    this.ctrQtr4 = 0;
    this.ctrTotal = 0;
    this.ctrPercentage = 0;
    this.commonCounter = this.ctrQtr3 % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getQtr4(columnName: any) {
    this.columnName = 'Qtr4';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = this.ctrQtr4+1;
    this.ctrTotal = 0;
    this.ctrPercentage = 0;
    this.commonCounter = this.ctrQtr4 % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }

  getTotal(columnName: any) {
    this.columnName = 'Total';
    this.ctrTrainingName = 0;
    this.ctrTrainingType = 0;
    this.ctrQtr1 = 0;
    this.ctrQtr2 = 0;
    this.ctrQtr3 = 0;
    this.ctrQtr4 = 0;
    this.ctrTotal = this.ctrTotal+1;
    this.ctrPercentage = 0;
    this.commonCounter = this.ctrTotal % 2;
    console.log(this.columnName);
    console.log(this.commonCounter);
    // console.log(this.serviceLine);
    // console.log(this.category);
    if (this.isShownEnrolled === true) {
      // this.toggleShowEnrolled();
      // this.toggleShowCompleted();
      this.toggleShowEnrolled();
      this.service
        .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;

          //  console.log(this.enrolledList);
        });
    }
    if (this.isShownCompleted === true) {
      // this.toggleShowCompleted();
      // this.toggleShowEnrolled();
      this.toggleShowCompleted();
      this.service
        .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
        .subscribe((data: any) => {
          this.enrolledList = data;
          if (null === data) {
            this.isEmpty = true;
          }
          else {
            this.isEmpty = false;
          }
          // console.log(this.enrolledList);
          // console.log(this.isEmpty);
        });
    }
  }


  sort(key: string) {
    // if(this.value!='null')
    // {
     if(key==='trainingName')  {
this.key = key;
this.reverse = !this.reverse;
this.total=0;
     }
       if(key==='trainingType')  {
this.key = key;
this.reverse = !this.reverse;
this.total=0;
     }
       if(key==='total')  {
this.key = key;
this.reverse = !this.reverse;
this.total=0;
     }
       if(key==='percentage')  {
this.key = key;
this.reverse = !this.reverse;
this.total=0;
     }
if(key==='qtr1')
{
  this.findsumforqtr1();
  if(this.total!=0){
this.key = key;
this.reverse = !this.reverse;
this.total=0;
  }
}
if(key==='qtr2')
{
  this.findsumforqtr2();
  if(this.total!=0){
this.key = key;
this.reverse = !this.reverse;
this.total=0;
  }
}if(key==='qtr3')
{
  this.findsumforqtr3();
  if(this.total!=0){
this.key = key;
this.reverse = !this.reverse;
this.total=0;
  }
}if(key==='qtr4')
{
  this.findsumforqtr4();
  if(this.total!=0){
this.key = key;
this.reverse = !this.reverse;
// this.total=0;
console.log(this.total)
  }
}
    // }
   
  }
  toggleShowCompleted() {
    //    this.isShownCompleted=true;

    //  this.isShownEnrolled = false;
this.completed=[];
    this.service
      .getCompleted(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)
      .subscribe((data) => {
        // console.log(data);
        this.completed = data;
        this.value=data;

        this.isShownCompleted = true;

        this.isShownEnrolled = false;
         if(null===data)
          {
            this.completed=[];
            this.isEmpty=true;
          }
          else{
            this.isEmpty=false;
          }
         
          // console.log(this.isEmpty);
      });
  }

  toggleShowEnrolled() {
    this.enrolled=[];
    console.log(this.enrolled);
    this.service
      .getEnrolled(this.serviceLine, this.category, this.year, this.columnName, this.commonCounter)

      .subscribe((res) => {
        // console.log(res);
        this.enrolled = res;
        this.value=res;
        this.isShownCompleted = false;
        this.isShownEnrolled = true;
console.log(this.enrolled);
         if(null===res)
          {
            this.enrolled=[];
            this.isEmpty=true;
          }
          else{
            this.isEmpty=false;
          }
         
          
      });
  }

findsumforqtr1(){
  
  for(let j=0;j<this.value.length;j++){   
       this.total+= this.value[j].qtr1;
       
  }  

}
findsumforqtr2(){
 
  for(let j=0;j<this.value.length;j++){   
       this.total+= this.value[j].qtr2;
        
  }  

}
findsumforqtr3(){
  
  for(let j=0;j<this.value.length;j++){   
       this.total+= this.value[j].qtr3;
       
  }  

}
findsumforqtr4(){
for(let j=0;j<this.value.length;j++){   
       this.total+= this.value[j].qtr4;
       
  }  

}

}
