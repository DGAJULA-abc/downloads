import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../services/course.service';
import { WorkloadService } from '../services/workload.service';

@Component({
  selector: 'app-workload',
  templateUrl: './workload.component.html',
  styleUrls: ['./workload.component.css']
})

/* prpepared by S Brunda and CH PushpaLatha*/

export class WorkloadComponent implements OnInit {
  userId:string=localStorage.getItem('userId')!;
  constructor(private workloadService:WorkloadService, private courseService:CoursesService) { }
  workload:number=0;
  totalHours:number=0;
  ngOnInit(): void {
   this.courseService.getStatus1().subscribe(status=>{
    if (status !== null) {
      this.getWorkLoadPercentage();
    } else{
       this.getWorkLoadPercentage();
    }
 });

}

getWorkLoadPercentage(){
  this.workloadService.getWorkloadPercentage(this.userId).subscribe(
    data => {
        this.workload=data.learningMeter;
        this.totalHours=data.learningHours;
    },
    error=>{console.log(error);
    this.workload=0;
    this.totalHours=0;}
  );
 }

}