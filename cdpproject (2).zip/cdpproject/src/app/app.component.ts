import { Component, Input, OnInit } from '@angular/core';
import  dayGridPlugin from "@fullcalendar/daygrid";
import  timeGridPlugin from "@fullcalendar/timegrid";
import  interactionPlugin from "@fullcalendar/interaction";
import esLocale from '@fullcalendar/core/locales/es';
import { EventsService } from './events.service';
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'easyfullcalendar';
@Input() events: any;
  errorMsg: any;
constructor(private _eventsServices: EventsService){

}
ngOnInit(): void{
    
       setTimeout(() => {
         $("#calendar").fullCalendar({  
           plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
           initialView: 'dayGridWeek',
             header:{
                 right: 'prev,next',
                 center: 'title',
                 left: 'dayGridMonth,timeGridWeek,timeGridDay'
               },
              
                        navLinks   : true,
                         editable   : true,
                         eventLimit : true,
                  // request to load current events
    });

     }, 100);
      this._eventsServices.getEvents()
      .subscribe((data) => this.events = data);
     
    
    }
   }


  


