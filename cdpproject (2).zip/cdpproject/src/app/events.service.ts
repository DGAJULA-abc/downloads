import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { eventsInterface } from './events'; 


@Injectable({
  providedIn: 'root'
})
export class EventsService {
  
  constructor(private _http: HttpClient) { }
 

  getEvents():Observable<eventsInterface[]>{
   return this._http.get<eventsInterface[]>('http://localhost:3000/events') ;
                           
   }
  //  errorHanler(error: HttpErrorResponse){
  //            return Observable.throw(error.message || "server Error")
             
  //  }
  }

