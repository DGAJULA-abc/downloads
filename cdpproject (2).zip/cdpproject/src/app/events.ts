export interface eventsInterface{
    title: string,
    start: string,
    color: string,
    end: string
}