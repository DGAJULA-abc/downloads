import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcoursestatusComponent } from './viewcoursestatus.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
imports: [
  HttpClientModule
]
providers: [HttpClient]
describe('ViewcoursestatusComponent', () => {
  let component: ViewcoursestatusComponent;
  let fixture: ComponentFixture<ViewcoursestatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewcoursestatusComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcoursestatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it("testing function", () => {
    expect(component.getview.toString)
  })
  it("testing html element", () => {
    const data = fixture.nativeElement;
    expect(data.querySelector(".views").textContent).toContain(ViewcoursestatusComponent)
  })
});
