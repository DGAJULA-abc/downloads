import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Views } from '../views';
import { ViewsService } from '../views.service';
@Component({
  selector: 'app-viewcoursestatus',
  templateUrl: './viewcoursestatus.component.html',
  styleUrls: ['./viewcoursestatus.component.css']
})
export class ViewcoursestatusComponent implements OnInit {

  closeResult = '';
  views = new Views();
 Completed: any ='';
 InProgress: any ='';
  constructor(private viewservice: ViewsService, private modalService: NgbModal) {
  }

  open(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  ngOnInit(): void {
    this.viewservice.getview('DGAJULA').subscribe(data => {
      this.views = data;
      console.log(this.views);
    });
  }
  getview(userId: string) {

    const views = userId;

    this.viewservice.getview(views).subscribe((data) => {
      this.views = data;

      console.log(this.views);

    })
  }
}







