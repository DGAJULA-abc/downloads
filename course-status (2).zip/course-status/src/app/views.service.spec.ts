import { inject, async, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { ViewsService } from './views.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

describe('HttpClient testing', () => {
  let service: ViewsService;
  let http: HttpClient;
  let httpController: HttpTestingController
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ViewsService],

    });
    service = TestBed.inject(ViewsService);
    http = TestBed.inject(HttpClient);
    httpController = TestBed.inject(HttpTestingController);
  });

  it('should be created', inject([ViewsService], (service: ViewsService) => {
    expect(service).toBeDefined();
  }));
  it('courses api', inject([ViewsService], (service: ViewsService) => {

  }));
});
