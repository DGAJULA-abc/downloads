import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Views } from './views';

@Injectable({
  providedIn: 'root'
})
export class ViewsService {

  constructor(private http : HttpClient) { }
//url : string ="http://localhost:8080/api/courses";
url: string ="http://localhost:3000/view"
getview(userId: any): Observable<Views>{
  return this.http.get<Views>(this.url +'/'+ userId);
  // return this.http.get<Views>(this.url );
}

}

