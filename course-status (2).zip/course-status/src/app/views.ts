
export interface ViewCourses {
    courseId: string;
    courseName: string;
    courseStatus: string;
    startDate: Date;
    endDate: Date;
}
export class Views{
    id: number;
    userId: string;
    course: ViewCourses[]
    
}
