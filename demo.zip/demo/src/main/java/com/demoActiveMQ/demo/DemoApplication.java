package com.demoActiveMQ.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@ConfigurationPropertiesScan
public class DemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(DemoApplication.class, args);
		 JmsProducer jmsProducer = context.getBean(JmsProducer.class);

	        jmsProducer.sendMessageToQueue("Message to Queue");
	        jmsProducer.sendMessageToTopic("Message to Topic");
	}

}
