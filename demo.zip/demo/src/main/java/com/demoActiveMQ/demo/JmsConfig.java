package com.demoActiveMQ.demo;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;
import javax.jms.Topic;

import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JmsConfig {
	 @Value("${spring.activemq.broker-url}")
	    private String brokerUrl;

	    @Value("${spring.activemq.user}")
	    private String username;

	    @Value("${spring.activemq.password}")
	    private String password;
    @Bean
    public Queue myQueue() {
        return new ActiveMQQueue("myQueue");
    }

    @Bean
    public Topic myTopic() {
        return new ActiveMQTopic("myTopic");
    }
    @Bean
    public ConnectionFactory connectionFactory() {
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        //connectionFactory.setBrokerURL(brokerUrl);
        connectionFactory.setUserName(username);
        connectionFactory.setPassword(password);
        return connectionFactory;
    }
    @Bean
    public BrokerService brokerService() throws Exception {
        BrokerService broker = new BrokerService();
        broker.addConnector("tcp://localhost:61616");
        broker.setPersistent(false); // Set to true for persistence
        return broker;
    }
}