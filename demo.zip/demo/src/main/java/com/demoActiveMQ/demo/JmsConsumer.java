package com.demoActiveMQ.demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class JmsConsumer {

    @JmsListener(destination = "myQueue")
    public void receiveMessageFromQueue(String message) {
        System.out.println("Received message from queue: " + message);
    }

    @JmsListener(destination = "myTopic")
    public void receiveMessageFromTopic(String message) {
        System.out.println("Received message from topic: " + message);
    }
}