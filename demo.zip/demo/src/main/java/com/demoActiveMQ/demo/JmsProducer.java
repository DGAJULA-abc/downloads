package com.demoActiveMQ.demo;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import javax.jms.Queue;
import javax.jms.Topic;

@Component
public class JmsProducer {

    private final JmsTemplate jmsTemplate;
    private final Queue myQueue;
    private final Topic myTopic;

    public JmsProducer(JmsTemplate jmsTemplate, Queue myQueue, Topic myTopic) {
        this.jmsTemplate = jmsTemplate;
        this.myQueue = myQueue;
        this.myTopic = myTopic;
    }

    public void sendMessageToQueue(String message) {
        jmsTemplate.convertAndSend(myQueue, message);
    }

    public void sendMessageToTopic(String message) {
        jmsTemplate.convertAndSend(myTopic, message);
    }
}