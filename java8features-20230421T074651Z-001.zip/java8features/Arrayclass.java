package java8features;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.Consumer;
public class Arrayclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> a1= new ArrayList<String>();
		a1.add("ddd");
		a1.add("didi");
		a1.add("yyy");
		a1.add("kkk");
		//Iterator i2 = a1.iterator();	
		//while(i2.hasNext()) {
		//	System.out.println(i2.next());
		//}
		
		//Consumer<String> c1 = (i) ->{
		//	System.out.println(i);
		//};
		
		//a1.forEach(c1);
		
		Consumer<String> m1 = Arrayclass::method1;
		a1.forEach(m1);                                      
		
	}
	
	public static void method1(String str) {
		System.out.println(str);
	}
}
