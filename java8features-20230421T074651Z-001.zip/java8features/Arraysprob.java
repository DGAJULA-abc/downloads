package java8features;

import java.util.Scanner;

public class Arraysprob {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		System.out.println("enter array values");	
	Scanner sc= new Scanner(System.in);

    int r[]= new int[5];
    for(int i=0;i<r.length;i++) {
    	r[i]=sc.nextInt();
    }
    for(int i=0;i<r.length;i++) {
    	System.out.println(r[i]);
    }
    
    
    
	}

}
