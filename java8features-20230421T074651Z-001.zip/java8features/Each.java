package java8features;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Each {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Map<String, String> map = new HashMap<String, String>();
			
		map.put("dinesh","1");
		map.put("dileep", "2");
		
		map.forEach((k,v) -> {
			System.out.println("k"+k+"v"+v);
		});
		
	}
}
