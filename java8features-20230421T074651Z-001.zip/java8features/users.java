package java8features;

public class users {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      User o = ( id, name) -> "dinesh gajula";
      System.out.println(o.run("id", "name"));
      
    
		
		//User o = new User() {
			//public void run() {
			//System.out.println("dinesh");
		//}
	//};
	//o.run();
	}

}
