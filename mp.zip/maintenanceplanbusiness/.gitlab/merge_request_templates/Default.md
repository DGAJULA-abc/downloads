### Summary

Merge %{source_branch} into %{target_branch}

%{co_authored_by}

### Description

*<Describe here what you did>*

%{all_commits}

### Conformity

- [ ] Make sure you are opening from a **topic/feature/bugfix** branch and not the main branch!
- [ ] Ensure that the pull request title represents the desired changelog entry
- [ ] Please describe what you did
- [ ] Link to relevant issues on DevOps or Jira
- [ ] Ensure you have provided tests - that demonstrates feature works or fixes the issue
- [ ] Ensure you have updated User Documentation or Architecture Dossier if relevant
- [ ] Ensure Jenkins build is successful and Sonar audit is passing

### Review checklist

- [ ] Is the code located in the right file/folder/package?
- [ ] Is the code sufficiently documented on the important items?
- [ ] Can the code have vulnerabilities?
- [ ] Does the code follow code naming and writing conventions?
- [ ] Don't new imported libraries increase assembly size excessively?
- [ ] Is error handling done the correct way?
- [ ] Is data retrieved from external APIs or libraries checked for security issues?
- [ ] Have automated tests been added, or have related ones been updated to cover the change?
