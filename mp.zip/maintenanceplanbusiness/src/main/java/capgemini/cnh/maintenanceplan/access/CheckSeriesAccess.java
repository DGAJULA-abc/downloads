/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.business.CheckSeriesBusiness;
import capgemini.cnh.maintenanceplan.dto.CheckSeriesDto;

/**
 * @author langlade
 *
 */
public class CheckSeriesAccess extends OracleAccess<CheckSeriesDto> {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public CheckSeriesAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * 
	 * @throws SQLException an exception
	 * 
	 * @return a Dto
	 */
	protected CheckSeriesDto rs2Dto(final ResultSet arg0) throws SQLException {
		// New dto
		final CheckSeriesDto dto = new CheckSeriesDto();

		dto.setBrandIceCode(getStringIfExists("CHECKSER_APP_BRA"));
		dto.setTypeIceCode(getStringIfExists("CHECKSER_APP_TYP"));
		dto.setProductIceCode(getStringIfExists("CHECKSER_APP_PRO"));
		dto.setSeriesIceCode(getStringIfExists("CHECKSER_APP_SER"));

		dto.setProjectName(getStringIfExists("CHECKSER_PROJECT_NAME"));
		dto.setProjectNumber(getStringIfExists("CHECKSER_PROJECT_NUMBER"));
		dto.setProjectVersion(getIntIfExists("CHECKSER_PROJECT_VERSION"));

		dto.setStart(getDateIfExists("CHECKSER_START"));
		dto.setEnd(getDateIfExists("CHECKSER_END"));

		dto.setForRelease(getIntIfExists("CHECKSER_IS_FOR_RELEASE").equals(1));
		dto.setStatus(getIntIfExists("CHECKSER_STATUS").byteValue());
		dto.setReport(getStringIfExists("CHECKSER_REPORT"));

		// Saved parameters for call to save project after release on warn
		dto.setIdProject(getStringIfExists("CHECKSER_SELECTEDID"));
		dto.setSelectedstatus(getStringIfExists("CHECKSER_SELECTEDSTATUS"));
		dto.setAppliId(getStringIfExists("CHECKSER_SELECTEDAPPLIID"));
		dto.setPersonalizedProject(getStringIfExists("CHECKSER_PERSONALIZED"));
		dto.setOldstatus(getStringIfExists("CHECKSER_OLDSTATUS"));
		dto.setStandardOils(getStringIfExists("CHECKSER_STANDARDOILS"));
		dto.setLastModifier(getStringIfExists("CHECKSER_LASTMODIFIER"));
		dto.setHasContract(getStringIfExists("CHECKSER_HASCONTRACT"));
		dto.setReleaseType(getStringIfExists("CHECKSER_RELEASETYPE"));
		dto.setIsUcr(getStringIfExists("CHECKSER_ISUCR"));
		dto.setCustomer(getStringIfExists("CHECKSER_CUSTOMER"));

		return dto;
	}

	/**
	 * Get the List of check series.
	 * 
	 * @return the list of check series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<CheckSeriesDto> getList() throws SystemException {
		// Create the query
		final String query = "select * from MP_CHECK_SERIES";

		// Execute the query and get the result list
		final List<CheckSeriesDto> lstFound = executeQueryN(query);

		return lstFound;
	}

	/**
	 * Get the check series from the ice code.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @return The check series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public CheckSeriesDto getFromIceCode(
			final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode) throws SystemException {
		// Create the query
		final StringBuilder query = new StringBuilder("select * from MP_CHECK_SERIES");
		query.append(" where CHECKSER_APP_BRA = ").append(formatString(brandIceCode));
		query.append(" and CHECKSER_APP_TYP = ").append(formatString(typeIceCode));
		query.append(" and CHECKSER_APP_PRO = ").append(formatString(productIceCode));
		query.append(" and CHECKSER_APP_SER = ").append(formatString(seriesIceCode));

		// Execute the query and get the result
		final CheckSeriesDto checkSeries = executeQuery1(query.toString());

		return checkSeries;
	}

	/**
	 * Create the check series.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * @param projectName name of the project
	 * @param projectNumber number of the project
	 * @param projectVersion version of the project
	 * @param isForRelease is for release the project
	 * 
	 * @return Inserted dto
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public CheckSeriesDto insert(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode,
			final String projectName, final String projectNumber, final Integer projectVersion,
			final boolean isForRelease) throws SystemException {
		CheckSeriesDto checkSeries = null;

		// Create the query
		final StringBuilder query = new StringBuilder(
				"insert into MP_CHECK_SERIES(CHECKSER_APP_BRA, CHECKSER_APP_TYP, CHECKSER_APP_PRO, CHECKSER_APP_SER, CHECKSER_PROJECT_NAME, CHECKSER_PROJECT_NUMBER, CHECKSER_PROJECT_VERSION, CHECKSER_START, CHECKSER_IS_FOR_RELEASE)");
		query.append(" values(").append(formatString(brandIceCode)).append(",");
		query.append(" ").append(formatString(typeIceCode)).append(",");
		query.append(" ").append(formatString(productIceCode)).append(",");
		query.append(" ").append(formatString(seriesIceCode)).append(",");
		if (projectName == null)
		{
			query.append(" NULL,");
		}
		else
		{
			query.append(" ").append(formatString(projectName)).append(",");
		}
		if (projectNumber == null)
		{
			query.append(" NULL,");
		}
		else
		{
			query.append(" ").append(formatString(projectNumber)).append(",");
		}
		if (projectVersion == null)
		{
			query.append(" NULL,");
		}
		else
		{
			query.append(" ").append(projectVersion).append(",");
		}
		query.append(" SYSDATE,");
		query.append(" ").append(isForRelease ? 1 : 0).append(")");

		// Execute the query and create the dto
		if (executeQueryI(query.toString()) != 0)
		{
			checkSeries = new CheckSeriesDto();
			checkSeries.setBrandIceCode(brandIceCode);
			checkSeries.setTypeIceCode(typeIceCode);
			checkSeries.setProductIceCode(productIceCode);
			checkSeries.setSeriesIceCode(seriesIceCode);
			checkSeries.setProjectName(projectName);
			checkSeries.setForRelease(isForRelease);
			checkSeries.setStatus(CheckSeriesBusiness.STATUS_PENDING);
			checkSeries.setReport(null);
		}

		return checkSeries;
	}

	/**
	 * Update the check series.
	 * 
	 * @param checkSeries Check series to update
	 * @param status New status
	 * @param selectedId project id
	 * @param selectedstatus project status
	 * @param selectedAppliId appli id
	 * @param personalized personalized
	 * @param oldstatus old porject status
	 * @param standardOils std oil string containing the data
	 * @param lastModifier last modifier
	 * @param hasContract has contract
	 * @param releaseType release type
	 * @param isUcr is UCR
	 * @param customer customer
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean update(final CheckSeriesDto checkSeries, final byte status,
			String selectedId, String selectedstatus, String selectedAppliId, String personalized,
			String oldstatus, String standardOils, String lastModifier, String hasContract,
			String releaseType, String isUcr, String customer) throws SystemException {
		// Create the query
		final StringBuilder query = new StringBuilder("update MP_CHECK_SERIES");
		query.append(" set CHECKSER_END = SYSDATE,"); // because of update is performed when setting in warning or error (at the end of process)
		query.append(" CHECKSER_STATUS = ").append(status).append(",");
		// Saved parameters for call to save project after release on warn
		query.append(" CHECKSER_SELECTEDID = ").append(formatString(selectedId)).append(",");
		query.append(" CHECKSER_SELECTEDSTATUS = ").append(formatString(selectedstatus)).append(",");
		query.append(" CHECKSER_SELECTEDAPPLIID = ").append(formatString(selectedAppliId)).append(",");
		query.append(" CHECKSER_PERSONALIZED = ").append(formatString(personalized)).append(",");
		query.append(" CHECKSER_OLDSTATUS = ").append(formatString(oldstatus)).append(",");
		query.append(" CHECKSER_STANDARDOILS = ").append(formatString(standardOils)).append(",");
		query.append(" CHECKSER_LASTMODIFIER = ").append(formatString(lastModifier)).append(",");
		query.append(" CHECKSER_HASCONTRACT = ").append(formatString(hasContract)).append(",");
		query.append(" CHECKSER_RELEASETYPE = ").append(formatString(releaseType)).append(",");
		query.append(" CHECKSER_ISUCR = ").append(formatString(isUcr)).append(",");
		query.append(" CHECKSER_CUSTOMER = ").append(formatString(customer));

		query.append(" where CHECKSER_APP_BRA = ").append(formatString(checkSeries.getBrandIceCode()));
		query.append(" and CHECKSER_APP_TYP = ").append(formatString(checkSeries.getTypeIceCode()));
		query.append(" and CHECKSER_APP_PRO = ").append(formatString(checkSeries.getProductIceCode()));
		query.append(" and CHECKSER_APP_SER = ").append(formatString(checkSeries.getSeriesIceCode()));

		// Execute the query and update the dto
		if (executeQueryI(query.toString()) != 0)
		{
			checkSeries.setStatus(status);
			//we should set other fields, but not useful for the moment
			return true;
		}

		return false;
	}

	/**
	 * Update the report.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * @param report report
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean updateReport(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode,
			final String report) throws SystemException {
		// Create the query
		final StringBuilder query = new StringBuilder("update MP_CHECK_SERIES");
		query.append(" set CHECKSER_REPORT = ").append(formatString(report));

		query.append(" where CHECKSER_APP_BRA = ").append(formatString(brandIceCode));
		query.append(" and CHECKSER_APP_TYP = ").append(formatString(typeIceCode));
		query.append(" and CHECKSER_APP_PRO = ").append(formatString(productIceCode));
		query.append(" and CHECKSER_APP_SER = ").append(formatString(seriesIceCode));

		// Execute the query and update the dto
		if (executeQueryI(query.toString()) != 0)
		{
			return true;
		}

		return false;
	}

	/**
	 * Delete the check series.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean delete(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode) throws SystemException {
		// Create the query
		final StringBuilder query = new StringBuilder("delete from MP_CHECK_SERIES");
		query.append(" where CHECKSER_APP_BRA = ").append(formatString(brandIceCode));
		query.append(" and CHECKSER_APP_TYP = ").append(formatString(typeIceCode));
		query.append(" and CHECKSER_APP_PRO = ").append(formatString(productIceCode));
		query.append(" and CHECKSER_APP_SER = ").append(formatString(seriesIceCode));

		// Execute the query
		return executeQueryI(query.toString()) != 0;
	}
}
