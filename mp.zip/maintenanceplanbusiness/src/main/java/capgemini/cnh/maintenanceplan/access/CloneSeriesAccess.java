/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.CloneSeriesDto;

/**
 * @author mamestoy
 *
 */
public class CloneSeriesAccess extends OracleAccess<CloneSeriesDto> {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public CloneSeriesAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected CloneSeriesDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		CloneSeriesDto dto = new CloneSeriesDto();

		dto.setIdProjectSrc(getLongIfExists("MP_PROJECT_ID_SRC"));
		dto.setIdProjectDest(getLongIfExists("MP_PROJECT_ID_DEST"));
		dto.setExtIdDest(getLongIfExists("MP_PLAN_EXT_ID_SRC"));
		dto.setExtIdDest(getLongIfExists("MP_PLAN_EXT_ID_DEST"));

		return dto;
	}

	/**
	 * add cloneseries projects/plans.
	 * 
	 * @param dto to save
	 * @return created id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long add(CloneSeriesDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		Long id = null;

		query.append("INSERT INTO MP_CLONE_SERIES (MP_PROJECT_ID_SRC, MP_PROJECT_ID_DEST, MP_PLAN_EXT_ID_SRC, MP_PLAN_EXT_ID_DEST) values (");
		query.append(dto.getIdProjectSrc());
		query.append(",");
		query.append(dto.getIdProjectDest());
		query.append(",");
		query.append(dto.getExtIdSrc());
		query.append(",");
		query.append(dto.getExtIdDest());
		query.append(")");

		executeQueryI("MP_CLONE_SERIES", query.toString());

		return id;
	}

	/**
	 * Get the corresponding record for project id src and plan ext id src .
	 * 
	 * @param dto the dto to get
	 * @return the list of clone series for prj/plan
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public CloneSeriesDto getRecordCloneForPrjPlanSrc(CloneSeriesDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("  select distinct MP_CLONE_SERIES.* ");
		query.append("  from MP_CLONE_SERIES ");
		query.append("  where MP_PROJECT_ID_SRC=");
		query.append(dto.getIdProjectSrc());
		query.append("  and MP_PLAN_EXT_ID_SRC=");
		query.append(dto.getExtIdSrc());

		// Execute the query and get the result
		CloneSeriesDto result = (CloneSeriesDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get the corresponding record for project id src and plan ext id src .
	 * 
	 * @param dto the dto to get
	 * @return the list of clone series for prj/plan
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public CloneSeriesDto getRecordCloneForPrjPlanDest(CloneSeriesDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("  select distinct MP_CLONE_SERIES.* ");
		query.append("  from MP_CLONE_SERIES ");
		query.append("  where MP_PROJECT_ID_DEST=");
		query.append(dto.getIdProjectDest());
		query.append("  and MP_PLAN_EXT_ID_DEST=");
		query.append(dto.getExtIdDest());

		// Execute the query and get the result
		CloneSeriesDto result = (CloneSeriesDto) executeQuery1(query.toString());

		return result;
	}

}
