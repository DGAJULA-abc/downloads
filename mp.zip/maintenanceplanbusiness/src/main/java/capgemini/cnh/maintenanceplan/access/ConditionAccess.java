/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class ConditionAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public ConditionAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		ConditionDto dto = new ConditionDto();

		dto.setIdCondition(getLongIfExists("COND_ID"));
		dto.setIdPerformance(getLongIfExists("COND_PERF_ID"));
		dto.setIdPlan(getLongIfExists("COND_PLAN_ID"));

		UsageDto usageDto = new UsageDto();
		usageDto.setValueId(getLongIfExists("COND_USAGE_VALUE"));
		dto.setUsage(usageDto);
		return dto;

	}

	/**
	 * add operation condition.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void addOperationCondition(ConditionDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getIdCondition() == null)
		{
			dto.setIdCondition(getPerformanceConditionNextId());
			query.append("INSERT INTO mp_operation_condition (  COND_ID, COND_PERF_ID, COND_USAGE_VALUE) values (");
			query.append(dto.getIdCondition().toString());
			query.append(",");

			query.append(dto.getIdPerformance().toString());
			query.append(",");

			String value = "null";
			if (dto.getUsage() != null)
			{
				if (dto.getUsage().getValueId() != null)
				{
					value = dto.getUsage().getValueId().toString();
				}
			}
			query.append(value);
			query.append(")");

			executeQueryI("mp_operation_condition", query.toString());
		}

	}

	/**
	 * add plan condition.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void addPlanCondition(ConditionDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getIdCondition() == null)
		{
			dto.setIdCondition(getPlanConditionNextId());
			query.append("INSERT INTO MP_MAINTENANCE_CONDITION (  COND_ID, COND_PLAN_ID, COND_USAGE_VALUE) values (");
			query.append(dto.getIdCondition().toString());
			query.append(",");

			query.append(dto.getIdPlan().toString());
			query.append(",");

			String value = "null";
			if (dto.getUsage() != null)
			{
				if (dto.getUsage().getValueId() != null)
				{
					value = dto.getUsage().getValueId().toString();
				}
			}
			query.append(value);
			query.append(")");

			executeQueryI("MP_MAINTENANCE_CONDITION", query.toString());
		}

	}

	/**
	 * add operation condition.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updateOperationCondition(ConditionDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getIdCondition() != null)
		{
			query.append("update mp_operation_condition set ");
			query.append("COND_USAGE_VALUE = ");
			if (dto.getUsage() != null)
			{
				if (dto.getUsage().getValueId() != null)
				{

					query.append(dto.getUsage().getValueId().toString());
				}
				else
				{
					query.append("null");
				}
			}
			else
			{
				query.append("null");
			}

			query.append(" WHERE COND_ID = ");
			query.append(dto.getIdCondition().toString());

			executeQueryI("mp_operation_condition", query.toString());
		}

	}

	/**
	 * check if condition already exists .
	 * 
	 * @param dto to check
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long existOperationCondition(ConditionDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		query.append("select count(*) as NB from mp_operation_condition where ");
		if (dto.getUsage() != null)
		{
			if (dto.getUsage().getValueId() != null)
			{
				query.append("COND_USAGE_VALUE = ");
				query.append(dto.getUsage().getValueId().toString());
			}
			else
			{
				query.append(" COND_USAGE_VALUE is null ");
			}
		}
		else
		{
			query.append(" COND_USAGE_VALUE is null ");
		}

		query.append(" and COND_ID = ");
		query.append(dto.getIdCondition().toString());

		return executeQueryCount(query.toString(), "NB");

	}

	/**
	 * add plan condition.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updatePlanCondition(ConditionDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getIdCondition() != null)
		{
			query.append("update MP_MAINTENANCE_CONDITION set ");
			query.append("COND_USAGE_VALUE = ");
			if (dto.getUsage() != null)
			{
				if (dto.getUsage().getValueId() != null)
				{
					query.append(dto.getUsage().getValueId().toString());
				}
				else
				{
					query.append("null");
				}
			}
			else
			{
				query.append("null");
			}

			query.append(" WHERE COND_ID = ");
			query.append(dto.getIdCondition().toString());

			executeQueryI("MP_MAINTENANCE_CONDITION", query.toString());
		}

	}

	/**
	 * delete operation condition.
	 * 
	 * @param idCondition to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteOperationCondition(String idCondition) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete mp_operation_condition  WHERE COND_ID = ");
		query.append(idCondition);

		executeQueryI("mp_operation_condition", query.toString());

	}

	/**
	 * delete plan condition.
	 * 
	 * @param idPlan to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deletePlanCondition(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete MP_MAINTENANCE_CONDITION  WHERE COND_PLAN_ID = ");
		query.append(idPlan);

		executeQueryI("MP_MAINTENANCE_CONDITION", query.toString());

	}

	/**
	 * delete for a given project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_MAINTENANCE_CONDITION where COND_PLAN_ID in (select distinct PLAN_ID from  MP_MAINTENANCE_PLAN  WHERE PLAN_PROJECT_ID = ");
		query.append(idProject);
		query.append(" )");

		executeQueryI("MP_PLAN_APPLICABILITY", query.toString());
	}

	/**
	 * delete operation condition.
	 * 
	 * @param idPerformance to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteOperationConditionByPerf(String idPerformance) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete mp_operation_condition  WHERE COND_PERF_ID = ");
		query.append(idPerformance);

		executeQueryI("mp_operation_condition", query.toString());

	}

	/**
	 * delete operation condition.
	 * 
	 * @param idOperationSeries to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteOperationConditionBySeries(String idOperationSeries) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete mp_operation_condition  WHERE cond_perf_id  in (select perf_id from mp_operation_performance where perf_ope_ser_id = ");
		query.append(idOperationSeries);
		query.append(")");

		executeQueryI("mp_operation_condition", query.toString());

	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param operationPerfId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ConditionDto> getListOperationCondition(String operationPerfId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_operation_condition where cond_perf_id = ");
		query.append(operationPerfId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<ConditionDto> result = new ArrayList<ConditionDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((ConditionDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param maintenancePlanId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ConditionDto> getListMaintenanceCondition(String maintenancePlanId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_maintenance_condition where cond_plan_id = ");
		query.append(maintenancePlanId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<ConditionDto> result = new ArrayList<ConditionDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((ConditionDto) dto);
		}

		return result;
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getPlanConditionNextId() throws SystemException {
		String query = "Select SQ_MP_MAINTENANCE_CONDITION.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getPerformanceConditionNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_CONDITION.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

}
