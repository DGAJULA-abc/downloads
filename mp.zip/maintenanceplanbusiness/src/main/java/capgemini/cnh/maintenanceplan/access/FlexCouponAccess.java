package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.MpFlexCouponDto;

/**
 * 
 * @author mmartel
 *
 */
public class FlexCouponAccess extends OracleAccess<MpFlexCouponDto> {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public FlexCouponAccess() throws SystemException {
		super();
	}

	/**
	 * get list of potential flexible coupons.
	 * 
	 * @return get list of potential flexible coupons.
	 * @throws SystemException system exception
	 */
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT COUPON_CODE FROM MP_COUPON_FLEX");
		return executeQueryN(query.toString());
	}

	@Override
	protected MpFlexCouponDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpFlexCouponDto dto = new MpFlexCouponDto();

		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		return dto;
	}

}
