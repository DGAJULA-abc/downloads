/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.common.util.Constants;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.IntervalDto;

/**
 * @author sdomecq
 *
 */
public class IntervalAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public IntervalAccess() throws SystemException {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	//	public IntervalAccess(Access dbAccess) throws SystemException {
	//		super(dbAccess);
	//	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		IntervalDto dto = new IntervalDto();

		dto.setId(getLongIfExists("INT_ID"));
		dto.setIdPlan(getLongIfExists("INT_PLAN_ID"));

		dto.setStartValueKm(getLongIfExists("INT_START_VALUE_KM"));
		dto.setStartValueMonth(getLongIfExists("INT_START_VALUE_MONTH"));
		dto.setStartValueHour(getLongIfExists("INT_START_VALUE_HOUR"));

		dto.setAfterValueKm(getLongIfExists("INT_AFTER_VALUE_KM"));
		dto.setAfterValueMonth(getLongIfExists("INT_AFTER_VALUE_MONTH"));
		dto.setAfterValueHour(getLongIfExists("INT_AFTER_VALUE_HOUR"));

		dto.setType(getStringIfExists("INT_TYPE"));
		dto.setCode(getStringIfExists("INT_CODE"));
		dto.setRepairTime(getLongIfExists("INT_REPAIR_TIME"));

		dto.setGroup(getLongIfExists("INT_GROUP"));

		dto.setComment(getStringIfExists("INT_COMMENT"));
		dto.setCommentId(getLongIfExists("INT_COMMENT_ID"));
		dto.setCustomer(getBooleanIfExists("INT_CUSTOMER"));

		if (getBooleanIfExists("INT_FLAG_COUPON") != null)
		{
			dto.setFlag(getBooleanIfExists("INT_FLAG_COUPON").booleanValue());
		}

		// only to deduce interval from performances
		dto.setOperationBySeriesId(getLongIfExists("OPE_SER_ID"));

		return dto;
	}

	/**
	 * Get the List of intervals .
	 * 
	 * @param idPlan filter
	 * @param language id of the lang
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getList(String idPlan, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	);
		query.append(" select distinct MP_INTERVAL.*, t.message INT_COMMENT ");
		query.append(" from MP_INTERVAL, table_title t  ");
		query.append(" where INT_PLAN_ID=");
		query.append(formatString(idPlan));
		query.append("  and INT_COMMENT_ID = t.idref_table_title(+) ");
		query.append("  and (t.idlanguage =");
		query.append(formatString(language));
		query.append("   or t.idlanguage is null)");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of intervals .
	 * 
	 * @param idPlan filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getIntervalsList(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	);
		query.append(" select DISTINCT MP_INTERVAL.* ");
		query.append(" from MP_INTERVAL ");
		query.append(" where INT_PLAN_ID=");
		query.append(formatString(idPlan));

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * delete interval by id.
	 * 
	 * @param idInterval to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String idInterval) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL where INT_ID = ");
		query.append(idInterval);

		executeQueryI("MP_INTERVAL", query.toString());
	}

	/**
	 * delete interval by plan id.
	 * 
	 * @param idPlan to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByPlan(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL where INT_PLAN_ID = ");
		query.append(idPlan);

		executeQueryI("MP_INTERVAL", query.toString());
	}

	/**
	 * delete interval by plan id.
	 * 
	 * @param idPlan to filter
	 * @param idIntervalToKeep to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByPlanAndKeepInterval(String idPlan, String idIntervalToKeep) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL where INT_PLAN_ID = ");
		query.append(idPlan);
		if (!idIntervalToKeep.equals(""))
		{
			query.append(" and INT_ID not in (");
			query.append(idIntervalToKeep);
			query.append(")");
		}
		executeQueryI("MP_INTERVAL", query.toString());
	}

	/**
	 * add interval.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(IntervalDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			dto.setId(getNextId());
			query.append(
					"INSERT INTO MP_INTERVAL ( INT_ID, INT_PLAN_ID, INT_CODE, INT_COMMENT_ID, INT_TYPE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_REPAIR_TIME, INT_FLAG_COUPON");
			if (dto.isCustomer() != null)
			{
				query.append(", INT_CUSTOMER");
			}
			query.append(") values (");
			query.append(dto.getId().toString());
			query.append(",");
			query.append(dto.getIdPlan().toString());
			query.append(",");
			query.append(formatString(dto.getCode()));
			query.append(",");
			if (dto.getCommentId() != null)
			{
				query.append(dto.getCommentId().toString());
			}
			else
			{
				query.append("null ");
			}
			query.append(",");
			query.append(formatString(dto.getType()));
			query.append(",");
			query.append(dto.getStartValueKm());
			query.append(",");
			query.append(dto.getStartValueMonth());
			query.append(",");
			query.append(dto.getStartValueHour());
			query.append(",");
			query.append(dto.getAfterValueKm());
			query.append(",");
			query.append(dto.getAfterValueMonth());
			query.append(",");
			query.append(dto.getAfterValueHour());
			query.append(",");
			query.append(dto.getGroup());
			query.append(",");
			query.append(dto.getRepairTime());
			query.append(",");
			if (dto.isFlag())
			{
				query.append(1);
			}
			else
			{
				query.append(0);
			}
			if (dto.isCustomer() != null)
			{
				query.append(",");
				if (dto.isCustomer())
				{
					query.append("1");
				}
				else
				{
					query.append("0");
				}
			}

			query.append(")");

			executeQueryI("MP_INTERVAL", query.toString());
		}

	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_INTERVAL.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * update interval.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(IntervalDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			query.append("update MP_INTERVAL set");
			query.append(" INT_TYPE = ");
			query.append(formatString(dto.getType()));
			query.append(" , INT_CODE = ");
			query.append(formatString(dto.getCode()));

			query.append(" , INT_REPAIR_TIME = ");

			query.append(dto.getRepairTime().toString());

			query.append(" , INT_COMMENT_ID = ");
			if (dto.getCommentId() != null)
			{
				query.append(dto.getCommentId().toString());
			}
			else
			{
				query.append("null ");
			}

			query.append(", INT_FLAG_COUPON = ");
			if (dto.isFlag())
			{
				query.append(1);
			}
			else
			{
				query.append(0);
			}

			query.append(" WHERE INT_ID = ");
			query.append(dto.getId().toString());

			executeQueryI("MP_INTERVAL", query.toString());
		}

	}

	/**
	 * update interval with WU.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updatewithWU(IntervalDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("update MP_INTERVAL set");
		query.append(" INT_REPAIR_TIME = ");
		query.append(dto.getRepairTime());

		query.append(" WHERE INT_PLAN_ID = ");
		query.append(dto.getIdPlan());
		query.append(" AND INT_CODE = ");
		query.append(formatString(dto.getCode()));

		executeQueryI("MP_INTERVAL", query.toString());
	}

	/**
	 * delete for a given project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL where INT_PLAN_ID in (select distinct PLAN_ID from  MP_MAINTENANCE_PLAN  WHERE PLAN_PROJECT_ID  = ");
		query.append(idProject);
		query.append(" )");

		executeQueryI("MP_INTERVAL", query.toString());
	}

	/**
	 * deduce intervals from performances.
	 * 
	 * @param listPerf : liste of performance to filter
	 * @param idPlan : max or harm
	 * @param idPerf filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @return list of intervals
	 */
	public List<IntervalDto> deduceFromPerformance(List<Long> listPerf, String idPerf, String idPlan, Boolean isIveco) throws SystemException {

		StringBuilder query = new StringBuilder();
		int i = 0;
		query.append(" select distinct OPE_SER_ID, ");
		query.append(idPlan);
		query.append(" AS INT_PLAN_ID,  ");
		query.append(" PERF_" + idPerf + "_START_VALUE_KM INT_START_VALUE_KM, PERF_" + idPerf + "_START_VALUE_MONTH INT_START_VALUE_MONTH, PERF_" + idPerf + "_START_VALUE_HOUR INT_START_VALUE_HOUR,");
		query.append(" PERF_" + idPerf + "_AFTER_VALUE_KM INT_AFTER_VALUE_KM, PERF_" + idPerf + "_AFTER_VALUE_MONTH INT_AFTER_VALUE_MONTH, PERF_" + idPerf
				+ "_AFTER_VALUE_HOUR INT_AFTER_VALUE_HOUR,  PERF_" + idPerf + "_GROUP INT_GROUP ");

		if (isIveco != null && !isIveco)
		{
			// If CV, the int_customer should always be null
			// If ope_made_bycustomer ==  0 --> customer coupon, else dealer&customer in contract coupon 
			query.append(",");
			query.append(" DECODE (mp_operation_performance.ope_made_bycustomer, 0, 1, 1, 0, 2, 0) as int_customer ");
		}

		query.append(" from  mp_operation_series , mp_operation_performance ");
		query.append(" where OPE_SER_ID = PERF_OPE_SER_ID ");
		if (listPerf.size() != 0)
		{
			query.append(" AND PERF_ID IN (");
			for (Long perf : listPerf)
			{
				query.append(perf);
				if (i != listPerf.size() - 1)
				{
					query.append(",");
				}
				i++;
			}
			query.append(")");
		}
		query.append("  order by 6, 7, 8, 9, 3, 4, 5 ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());;

		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * Get the id in interval list for the plan.
	 * 
	 * @param dto to filter
	 * @return the next id
	 * @throws SystemException system exception
	 */
	public IntervalDto findInterval(IntervalDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT distinct * from MP_INTERVAL  ");
		query.append(" where INT_PLAN_ID = ");
		query.append(dto.getIdPlan().toString());

		if (dto.getStartValueKm() == null)
		{
			query.append(" and INT_START_VALUE_KM is null ");
		}
		else
		{
			query.append(" and INT_START_VALUE_KM = ");
			query.append(dto.getStartValueKm().toString());
		}

		if (dto.getStartValueMonth() == null)
		{
			query.append(" and INT_START_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" and INT_START_VALUE_MONTH = ");
			query.append(dto.getStartValueMonth().toString());
		}

		if (dto.getStartValueHour() == null)
		{
			query.append(" and INT_START_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" and INT_START_VALUE_HOUR = ");
			query.append(dto.getStartValueHour().toString());
		}

		if (dto.getAfterValueKm() == null)
		{
			query.append(" and INT_AFTER_VALUE_KM is null ");
		}
		else
		{
			query.append(" and INT_AFTER_VALUE_KM = ");
			query.append(dto.getAfterValueKm().toString());
		}

		if (dto.getAfterValueMonth() == null)
		{
			query.append(" and INT_AFTER_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" and INT_AFTER_VALUE_MONTH = ");
			query.append(dto.getAfterValueMonth().toString());
		}

		if (dto.getAfterValueHour() == null)
		{
			query.append(" and INT_AFTER_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" and INT_AFTER_VALUE_HOUR = ");
			query.append(dto.getAfterValueHour().toString());
		}
		if (dto.getGroup() == null)
		{
			query.append(" and INT_GROUP is null ");
		}
		else
		{
			query.append(" and INT_GROUP = ");
			query.append(dto.getGroup().toString());
		}
		if (dto.isCustomer() == null)
		{
			query.append(" and INT_CUSTOMER is null ");
		}
		else
		{
			int customerValue = 0;
			if (dto.isCustomer())
			{
				customerValue = 1;
			}
			query.append(" and INT_CUSTOMER = ");
			query.append(customerValue);
		}

		IntervalDto result = (IntervalDto) executeQuery1(query.toString());
		return result;
	}

	/**
	 * Get the List of intervals for operation duplication .
	 * 
	 * @param idPlan filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getListForOperationDuplication(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(
				" select INT_ID, INT_AFTER_VALUE_KM,INT_AFTER_VALUE_MONTH,INT_AFTER_VALUE_HOUR, INT_GROUP from MP_INTERVAL where INT_START_VALUE_KM is null and INT_START_VALUE_MONTH is null and INT_START_VALUE_HOUR is null and INT_PLAN_ID=");
		query.append(idPlan);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of comments by plan .
	 * 
	 * @param idPlan filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getCommentListByPlan(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		select distinct mp_interval.int_comment_id  from mp_maintenance_project, mp_maintenance_plan, mp_interval 
		//		where mp_maintenance_project.MP_ID = 54
		//		and mp_maintenance_plan.plan_project_id = mp_maintenance_project.MP_ID
		//		and mp_interval.int_plan_id = mp_maintenance_plan.plan_id
		//		and mp_interval.int_comment_id is not null;

		// Create the query	
		query.append(" select distinct mp_interval.int_comment_id from mp_maintenance_project, mp_maintenance_plan, mp_interval ");
		query.append(" where mp_maintenance_project.MP_ID = ");
		query.append(idPlan);
		query.append(" and mp_maintenance_plan.plan_project_id = mp_maintenance_project.MP_ID ");
		query.append(" and mp_interval.int_plan_id = mp_maintenance_plan.plan_id ");
		query.append(" and mp_interval.int_comment_id is not null ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * Get all the interval codes used in the project.
	 * 
	 * @param idProject project id
	 * @return the interval code list
	 * @throws SystemException SystemException
	 */
	public List<IntervalDto> getIntervalCodesByProject(String idProject, Integer status) throws SystemException {

		/* Query:
		 * select distinct int_code from MP_MAINTENANCE_PLAN, mp_interval where plan_project_id = 190 and int_plan_id = plan_id and plan_status = <status>;
		 */
		StringBuilder query = new StringBuilder();

		query.append("select distinct int_code from MP_MAINTENANCE_PLAN, mp_interval where plan_project_id = ");
		query.append(formatString(idProject));
		query.append(" and plan_status = ");
		query.append(status);
		query.append(" and int_plan_id = plan_id ");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the List of intervals .
	 * 
	 * @param idComment filter
	 * @return the list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getIntervalsListByComment(String idComment) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	);
		query.append(" select DISTINCT MP_INTERVAL.* ");
		query.append(" from MP_INTERVAL ");
		query.append(" where INT_COMMENT_ID=");
		query.append(formatString(idComment));

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalDto> result = new ArrayList<IntervalDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalDto) dto);
		}

		return result;
	}

	/**
	 * Get the the first interval .
	 * 
	 * @param commentLbl filter
	 * @return the first interval
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public IntervalDto getFirstIntervalComment(String commentLbl) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query
		query.append(" select INT_COMMENT_ID ");
		query.append(" from table_title, mp_interval ");
		query.append(" where IDREF_TABLE_TITLE = INT_COMMENT_ID ");
		query.append(" and message = ");
		query.append(formatString(commentLbl));
		query.append(" and tthidden = " + Constants.NOT_HIDDEN);

		// Execute the query and get the result list
		return (IntervalDto) executeQuery1(query.toString());
	}
}
