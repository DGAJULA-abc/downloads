/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.IntervalDto;
import capgemini.cnh.maintenanceplan.dto.IntervalFrequencyDto;

/**
 * @author mamestoy
 *
 */
public class IntervalFrequencyAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public IntervalFrequencyAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		IntervalFrequencyDto dto = new IntervalFrequencyDto();

		dto.setCode(getStringIfExists("MPIF_INT_CODE"));
		dto.setStartValueSpecificUnit(getLongIfExists("MPIF_START_VALUE_SPECIFIC_UNIT"));
		dto.setStartValueMonth(getLongIfExists("MPIF_START_VALUE_MONTH"));
		dto.setStartValueHour(getLongIfExists("MPIF_START_VALUE_HOUR"));
		dto.setAfterValueSpecificUnit(getLongIfExists("MPIF_AFTER_VALUE_SPECIFIC_UNIT"));
		dto.setAfterValueMonth(getLongIfExists("MPIF_AFTER_VALUE_MONTH"));
		dto.setAfterValueHour(getLongIfExists("MPIF_AFTER_VALUE_HOUR"));
		dto.setSpecificUnitKey(getStringIfExists("MPIF_SPECIFIC_UNIT_KEY"));

		return dto;
	}

	/**
	 * find interval code.
	 * 
	 * @param dto to find
	 * @param specificUnitKey Key of the specific unit
	 * @return interval FRequency
	 * @throws SystemException system exception
	 */
	public IntervalFrequencyDto findIntervalCode(IntervalDto dto, String specificUnitKey) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT distinct * from MP_INTERVAL_FREQUENCY  ");
		query.append(" where ");

		if (dto.getStartValueKm() == null)
		{
			query.append(" MPIF_START_VALUE_SPECIFIC_UNIT is null ");
		}
		else
		{
			query.append(" MPIF_START_VALUE_SPECIFIC_UNIT = ");
			query.append(dto.getStartValueKm().toString());
		}

		if (dto.getStartValueMonth() == null)
		{
			query.append(" and MPIF_START_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" and MPIF_START_VALUE_MONTH = ");
			query.append(dto.getStartValueMonth().toString());
		}

		if (dto.getStartValueHour() == null)
		{
			query.append(" and MPIF_START_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" and MPIF_START_VALUE_HOUR = ");
			query.append(dto.getStartValueHour().toString());
		}

		if (dto.getAfterValueKm() == null)
		{
			query.append(" and MPIF_AFTER_VALUE_SPECIFIC_UNIT is null ");
		}
		else
		{
			query.append(" and MPIF_AFTER_VALUE_SPECIFIC_UNIT = ");
			query.append(dto.getAfterValueKm().toString());
		}

		if (dto.getAfterValueMonth() == null)
		{
			query.append(" and MPIF_AFTER_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" and MPIF_AFTER_VALUE_MONTH = ");
			query.append(dto.getAfterValueMonth().toString());
		}

		if (dto.getAfterValueHour() == null)
		{
			query.append(" and MPIF_AFTER_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" and MPIF_AFTER_VALUE_HOUR = ");
			query.append(dto.getAfterValueHour().toString());
		}

		if ((dto.getStartValueKm() != null || dto.getAfterValueKm() != null)
				&& specificUnitKey != null)
		{
			query.append(" and MPIF_SPECIFIC_UNIT_KEY = '").append(specificUnitKey).append("'");
		}

		IntervalFrequencyDto result = (IntervalFrequencyDto) executeQuery1(query.toString());
		return result;
	}

}
