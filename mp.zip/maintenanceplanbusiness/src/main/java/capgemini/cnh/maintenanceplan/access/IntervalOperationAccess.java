/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationDto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public IntervalOperationAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		IntervalOperationDto dto = new IntervalOperationDto();

		dto.setIdOperation(getLongIfExists("OPE_OPERATION_ID"));

		dto.setIdOperationSeries(getLongIfExists("DEF_OPE_SERIES_ID"));
		dto.setIntervalId(getLongIfExists("DEF_INTERVAL_ID"));

		dto.setIntervalCode(getStringIfExists("INT_CODE"));
		dto.setOperationLabel(getStringIfExists("OPE_LABEL"));

		dto.setMicroOperation(getStringIfExists("OPE_CODE"));
		dto.setSrtOperation(getStringIfExists("OPE_SRT"));

		dto.setWithConsumable(getStringIfExists("WITH_CONS"));
		dto.setWithParts(getStringIfExists("WITH_PARTS"));
		dto.setWithPerf(getStringIfExists("WITH_PERF"));

		return dto;
	}

	/**
	 * Get the List of intervals for a given operation on a series.
	 * 
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOfIntervalOperation(String operationSeriesId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select def_interval_id, INT_CODE ");
		query.append(" from mp_interval_operation, mp_interval ");
		query.append(" where def_ope_series_id = ");
		query.append(operationSeriesId);
		query.append(" and def_interval_id=mp_interval.int_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of operations on a series for a given interval.
	 * 
	 * @param intervalId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOfOperationInterval(String intervalId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select OPE_OPERATION_ID, DEF_INTERVAL_ID, DEF_OPE_SERIES_ID, OPE_CODE, OPE_SRT ");
		query.append(" from mp_interval_operation, MP_OPERATION_SERIES, MP_OPERATION ");
		query.append(" where OPE_SER_ID = DEF_OPE_SERIES_ID and OPE_OPERATION_ID = OPE_ID ");
		query.append(" and def_interval_id = ");
		query.append(intervalId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;

	}

	/**
	 * Get the operation on a series for a given interval and a given operation.
	 * 
	 * @param intervalId to filter
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public IntervalOperationDto getListForOperationInterval(String intervalId, String operationSeriesId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select def_ope_series_id ");
		query.append(" from mp_interval_operation ");
		query.append(" where def_ope_series_id = ");
		query.append(operationSeriesId);
		query.append(" and def_interval_id = ");
		query.append(intervalId);

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (IntervalOperationDto) found;

	}

	/**
	 * Get the List of operations on a series for a given interval.
	 * 
	 * @param intervalId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOfOperationIntervalNotReleased(String intervalId) throws SystemException {

		StringBuilder query = new StringBuilder();

		/* Select Os1.Ope_Operation_Id, Def_Interval_Id, Os1.Ope_Ser_Id, Ope_Code, Ope_Srt ,Os2.Ope_Ser_Id --Os2.*, Os2.*,MP_OPERATION.*
		 from mp_interval_operation, MP_OPERATION_SERIES os1, MP_OPERATION , MP_OPERATION_SERIES os2
		 Where Os1.Ope_Ser_Id = Def_Ope_Series_Id And Os1.Ope_Operation_Id = Ope_Id 
		 And Os1.Ope_Operation_Id = Os2.Ope_Operation_Id 	
		 And Def_Interval_Id =  	2554
		 And Os2.Ope_Mp_Id Is Null
		 and Os2.ope_app_bra=Os1.ope_app_bra and  Os2.ope_app_typ=Os1.ope_app_typ and Os2.ope_app_pro=Os1.ope_app_pro and Os2.ope_app_ser=Os1.ope_app_ser;*/

		query.append(" Select Os1.Ope_Operation_Id, Def_Interval_Id, Os2.Ope_Ser_Id as DEF_OPE_SERIES_ID, Ope_Code, Ope_Srt  ");
		query.append("  from mp_interval_operation, MP_OPERATION_SERIES os1, MP_OPERATION , MP_OPERATION_SERIES os2 ");
		query.append(" where Os1.Ope_Ser_Id = Def_Ope_Series_Id And Os1.Ope_Operation_Id = Ope_Id  ");
		query.append(" And Os1.Ope_Operation_Id = Os2.Ope_Operation_Id ");
		query.append(" and def_interval_id = ");
		query.append(intervalId);
		query.append(" And Os2.Ope_Mp_Id Is Null  ");
		query.append(" And Os2.ope_app_bra=Os1.ope_app_bra and  Os2.ope_app_typ=Os1.ope_app_typ and Os2.ope_app_pro=Os1.ope_app_pro and Os2.ope_app_ser=Os1.ope_app_ser ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of operations on a series for a given interval Id (Source) and a given plan Id (Dest).
	 * 
	 * @param intervalIdSrc id of interval to get the operations from
	 * @param planIdDest the id of the current plan to get the project id
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOfOperationIntervalByIntAndPlan(Long intervalIdSrc, Long planIdDest) throws SystemException {

		StringBuilder query = new StringBuilder();

		/* Select opSrc.Ope_Operation_Id, Def_Interval_Id, opDest.Ope_Ser_Id as DEF_OPE_SERIES_ID, Ope_Code, Ope_Srt
			from mp_interval_operation, MP_OPERATION_SERIES opSrc, MP_OPERATION , MP_OPERATION_SERIES opDest, mp_maintenance_plan
			Where opSrc.Ope_Ser_Id = Def_Ope_Series_Id 
			And opSrc.Ope_Operation_Id = Ope_Id 
			And Def_Interval_Id =  2554
			And opDest.Ope_Mp_Id = plan_project_id
			and plan_id = XXX
			And opSrc.Ope_Operation_Id = opDest.Ope_Operation_Id 	
			and opDest.ope_app_bra=opSrc.ope_app_bra 
			and  opDest.ope_app_typ=opSrc.ope_app_typ 
			and opDest.ope_app_pro=opSrc.ope_app_pro 
			and opDest.ope_app_ser=opSrc.ope_app_ser;*/

		query.append(" Select opSrc.Ope_Operation_Id, Def_Interval_Id, opDest.Ope_Ser_Id as DEF_OPE_SERIES_ID, Ope_Code, Ope_Srt ");
		query.append(" from mp_interval_operation, MP_OPERATION_SERIES opSrc, MP_OPERATION , MP_OPERATION_SERIES opDest, mp_maintenance_plan ");
		query.append(" Where opSrc.Ope_Ser_Id = Def_Ope_Series_Id  ");
		query.append(" And opSrc.Ope_Operation_Id = Ope_Id  ");
		query.append(" And Def_Interval_Id =   ");
		query.append(intervalIdSrc);
		query.append(" And opDest.Ope_Mp_Id = plan_project_id ");
		query.append(" and plan_id =  ");
		query.append(planIdDest);
		query.append(" And opSrc.Ope_Operation_Id = opDest.Ope_Operation_Id 	 ");
		query.append(" and opDest.ope_app_bra=opSrc.ope_app_bra  ");
		query.append(" and  opDest.ope_app_typ=opSrc.ope_app_typ  ");
		query.append(" and opDest.ope_app_pro=opSrc.ope_app_pro  ");
		query.append(" and opDest.ope_app_ser=opSrc.ope_app_ser ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operations/interval by plan.
	 * 
	 * @param planId to filter
	 * @param language for translation
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListByPlan(String planId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		select OPE_CODE || ' - ' || message as OPE_LABEL, INT_CODE, DEF_OPE_SERIES_ID,
		//	     decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_CONS,
		//	     decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_PARTS,
		//	     decode((select count(*) from mp_operation_performance where perf_ope_ser_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_PERF		
		//		from mp_interval_operation, mp_interval, mp_operation_series, mp_operation, table_title
		//		where def_interval_id=mp_interval.int_id
		//		and int_plan_id = 10
		//		and def_ope_series_id=ope_ser_id
		//		and ope_operation_id=ope_id
		//		and ope_title_id=idref_table_title
		//		and idlanguage = 'IT'

		query.append(" select nvl(OPE_CODE, OPE_SRT) || ' - ' || message || '%(' || ope_loc_fam || '.' || ope_loc_gro || '.' || ope_loc_sug || ')' as OPE_LABEL, INT_CODE, DEF_OPE_SERIES_ID,  ");
		query.append(" decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_CONS, ");
		query.append(" decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_PARTS, ");
		query.append(" decode((select count(*) from mp_operation_performance where perf_ope_ser_id = DEF_OPE_SERIES_ID), 0, '', '*')  as WITH_PERF, DEF_INTERVAL_ID ");
		query.append(" from mp_interval_operation, mp_interval, mp_operation_series, mp_operation, table_title ");
		query.append(" where def_interval_id=mp_interval.int_id ");
		query.append(" and int_plan_id =");
		query.append(planId);
		query.append(" and def_ope_series_id=ope_ser_id ");
		query.append(" and ope_operation_id=ope_id ");
		query.append(" and ope_title_id=idref_table_title");
		query.append(" and idlanguage =");
		query.append(formatString(language));

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of operations/interval by plan.
	 * 
	 * @param planId to filter
	 * @param language to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOpIntervalByPlan(String planId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		select OPE_CODE, OPE_SRT, INT_CODE, message OPE_LABEL 
		//		from mp_interval_operation, mp_interval, mp_operation_series, mp_operation, table_title
		//		where def_interval_id=mp_interval.int_id
		//		and int_plan_id = 10
		//		and def_ope_series_id=ope_ser_id
		//		and ope_operation_id=ope_id
		//		and ope_title_id = idref_table_title(+) 
		//		and (idlanguage= 'IT') or idlanguage is null

		query.append(" select COALESCE(OPE_CODE, '') || '$$' || COALESCE(OPE_LOC_FAM, '') || '.' || COALESCE(OPE_LOC_GRO, '') || '.' || COALESCE(OPE_LOC_SUG, '') AS OPE_CODE");
		query.append(", COALESCE(OPE_SRT, '') || '$$' || COALESCE(OPE_LOC_FAM, '') || '.' || COALESCE(OPE_LOC_GRO, '') || '.' || COALESCE(OPE_LOC_SUG, '') AS OPE_SRT");
		query.append(", INT_CODE, message OPE_LABEL ");
		query.append(" from mp_interval_operation, mp_interval, mp_operation_series, mp_operation, table_title ");
		query.append(" where def_interval_id=mp_interval.int_id ");
		query.append(" and int_plan_id =");
		query.append(formatString(planId));
		query.append(" and def_ope_series_id=ope_ser_id ");
		query.append(" and ope_operation_id=ope_id ");
		query.append(" AND ope_title_id = idref_table_title(+) and (idlanguage= ");
		query.append(formatString(language));
		query.append(" or idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationDto> result = new ArrayList<IntervalOperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationDto) dto);
		}

		return result;

	}

	/**
	 * delete for a given project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL_OPERATION where DEF_INTERVAL_ID in (select INT_ID from  MP_INTERVAL  WHERE INT_PLAN_ID in ");
		query.append(" (select PLAN_ID from MP_MAINTENANCE_PLAN where PLAN_PROJECT_ID = ");
		query.append(formatString(idProject));
		query.append(" ))");

		executeQueryI("MP_INTERVAL_OPERATION", query.toString());

	}

	/**
	 * delete for a given plan.
	 * 
	 * @param idPlan to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public void deleteByPlanId(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_INTERVAL_OPERATION where DEF_INTERVAL_ID in (select distinct INT_ID from  MP_INTERVAL WHERE INT_PLAN_ID = ");
		query.append(formatString(idPlan));
		query.append(")");

		executeQueryI("MP_INTERVAL_OPERATION", query.toString());

	}

	/**
	 * add interval/operation link.
	 * 
	 * @param interval to save
	 * @param operationSeries to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(String interval, String operationSeries) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO MP_INTERVAL_OPERATION ( DEF_INTERVAL_ID, DEF_OPE_SERIES_ID) values (");
		query.append(interval);
		query.append(",");
		query.append(operationSeries);
		query.append(")");

		executeQueryI("MP_INTERVAL_OPERATION", query.toString());

	}

	/**
	 * duplicate interval/operation link (if not exists).
	 * 
	 * @param intervalSource to save
	 * @param intervalDestination to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void duplicate(String intervalSource, String intervalDestination) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" INSERT INTO MP_INTERVAL_OPERATION ( DEF_INTERVAL_ID, DEF_OPE_SERIES_ID)  ");
		query.append(" select ");
		query.append(intervalDestination);
		query.append(" , DEF_OPE_SERIES_ID from MP_INTERVAL_OPERATION where (");
		query.append(intervalDestination);
		query.append(", DEF_OPE_SERIES_ID) not in (select * from MP_INTERVAL_OPERATION where DEF_INTERVAL_ID =");
		query.append(intervalDestination);
		query.append(" ) and DEF_INTERVAL_ID=");
		query.append(intervalSource);

		executeQueryI("MP_INTERVAL_OPERATION", query.toString());

	}

	/**
	 * update interval of a project released.
	 * 
	 * @param oldOpeSeries : old link.
	 * @param newOpeSeries : new link.
	 * @param projectId : project Id.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updateIntervalProjectRelease(Long oldOpeSeries, Long newOpeSeries, Long projectId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("update  MP_INTERVAL_OPERATION Mp Set   Def_Ope_Series_Id = ");
		query.append(newOpeSeries);
		query.append(" where   Def_Ope_Series_Id = ");
		query.append(oldOpeSeries);
		query.append(" and def_interval_id in (select int_id ");
		query.append(" From Mp_Interval_Operation,Mp_Interval, Mp_Maintenance_Plan ");
		query.append(" where def_interval_id = int_id and int_plan_id=plan_id and plan_project_id = ");
		query.append(projectId);
		query.append(" )");
		executeQueryI("MP_INTERVAL_OPERATION", query.toString());

	}
}
