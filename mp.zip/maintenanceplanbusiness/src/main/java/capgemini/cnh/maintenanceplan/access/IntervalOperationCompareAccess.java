/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationCompareDto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationCompareAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public IntervalOperationCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		IntervalOperationCompareDto dto = new IntervalOperationCompareDto();

		dto.setIdOperation(getLongIfExists("OPE_OPERATION_ID"));

		dto.setIdOperationSeries(getLongIfExists("DEF_OPE_SERIES_ID"));
		dto.setIntervalId(getLongIfExists("DEF_INTERVAL_ID"));

		dto.setIntervalCode(getStringIfExists("INT_CODE"));
		dto.setOperationLabel(getStringIfExists("OPE_LABEL"));

		dto.setMicroOperation(getStringIfExists("OPE_CODE"));
		dto.setSrtOperation(getStringIfExists("OPE_SRT"));

		dto.setWithConsumable(getStringIfExists("WITH_CONS"));
		dto.setWithParts(getStringIfExists("WITH_PARTS"));
		dto.setWithPerf(getStringIfExists("WITH_PERF"));

		dto.setStartValueKm(getLongIfExists("INT_START_VALUE_KM"));
		dto.setStartValueMonth(getLongIfExists("INT_START_VALUE_MONTH"));
		dto.setStartValueHour(getLongIfExists("INT_START_VALUE_HOUR"));

		dto.setAfterValueKm(getLongIfExists("INT_AFTER_VALUE_KM"));
		dto.setAfterValueMonth(getLongIfExists("INT_AFTER_VALUE_MONTH"));
		dto.setAfterValueHour(getLongIfExists("INT_AFTER_VALUE_HOUR"));

		dto.setRepairTime(getLongIfExists("INT_REPAIR_TIME"));

		return dto;
	}

	/**
	 * Get the List of intervals for a given operation on a series.
	 * 
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationCompareDto> getListOfIntervalOperation(String operationSeriesId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select def_interval_id, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH,INT_START_VALUE_HOUR, ");
		query.append(" INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_REPAIR_TIME ");
		query.append(" from mp_interval_operation, mp_interval ");
		query.append(" where def_ope_series_id = ");
		query.append(formatString(operationSeriesId));
		query.append(" and def_interval_id=mp_interval.int_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<IntervalOperationCompareDto> result = new ArrayList<IntervalOperationCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((IntervalOperationCompareDto) dto);
		}

		return result;

	}

}
