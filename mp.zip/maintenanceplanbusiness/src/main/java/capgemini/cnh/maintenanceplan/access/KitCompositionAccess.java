/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.dto.KitCompositionDto;

/**
 * @author MAY
 *
 */
public class KitCompositionAccess extends OracleAccess<KitCompositionDto> {

	/** Define a logger for this class. */
	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public KitCompositionAccess() throws SystemException {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public KitCompositionAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected KitCompositionDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		KitCompositionDto dto = new KitCompositionDto();

		// Set Dto
		//dto.setCompKitCode(getStringIfExists("COMP_KIT_CODE"));
		dto.setCompPnCode(getStringIfExists("COMP_PN_CODE"));
		//dto.setCompDate(Util.dateToString(getDateIfExists("COMP_DATE")));
		dto.setCompPnQty(getLongIfExists("COMP_PN_QTY"));
		dto.setCompPnLabel(getStringIfExists("COMP_PN_LABEL"));

		return dto;
	}

	/**
	 * Get the composition (list of part number) of a kit.
	 * 
	 * @param selectedKitId to search
	 * @return a list of associated part number
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<KitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT COMP_PN_CODE, COMP_PN_LABEL, COMP_PN_QTY");
		query.append(" FROM MP_KIT_COMPOSITION");
		query.append(" WHERE COMP_KIT_CODE = ");
		query.append(formatString(selectedKitId));

		return executeQueryN(query.toString());
	}

}
