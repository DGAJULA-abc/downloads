package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.TransactionAccess;
import capgemini.cnh.framework.common.Constantes;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.MpOperationPerformanceTextDto;

/**
 * 
 * 
 * Class to get informations from SAP_SRT_DEFECT table.
 * This table is used by SRT IVECO.
 */
public class MpOperationPerformanceTextAccess extends OracleAccess<MpOperationPerformanceTextDto> {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationPerformanceTextAccess() throws SystemException {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationPerformanceTextAccess(TransactionAccess dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * Check if the translation exists in TABLE_TITLE oracle Table.
	 * 
	 * @param label label for the Performance
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpOperationPerformanceTextDto> isTranslationExist(String label) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select * ");
		query.append(" from table_title, mp_operation_performance_text ");
		query.append(" where IDREF_TABLE_TITLE = FREE_TEXT ");
		query.append(" and message = ");
		query.append(formatString(label));
		query.append(" and SOURCE = 'MP' ");
		query.append(" and HIDECOMMENT = ");
		query.append(formatString(Constantes.MP_PERFORMANCE));

		return selectSome(query.toString());
	}

	/**
	 * Find the records where the Free Text ID is equals to @param freeTextId.
	 * 
	 * @param freeTextId Free Text ID
	 * @return List of records
	 * @throws SystemException System Exception
	 */
	public List<MpOperationPerformanceTextDto> findByFreeTextId(Long freeTextId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT MP_OPERATION_PERFORMANCE_TEXT.*, TABLE_TITLE.MESSAGE ");
		query.append(" FROM MP_OPERATION_PERFORMANCE_TEXT, TABLE_TITLE ");
		query.append(" WHERE FREE_TEXT = ");
		query.append(freeTextId);
		query.append(" AND IDREF_TABLE_TITLE = FREE_TEXT ");
		query.append(" AND SOURCE = 'MP' ");
		query.append(" and HIDECOMMENT = ");
		query.append(formatString(Constantes.MP_PERFORMANCE));

		return selectSome(query.toString());
	}

	/**
	 * Get the list of the performances with label for an operation series.
	 * 
	 * @param opeSerId id of the oepration series
	 * @return the list of the performances with label for an operation series
	 * @throws SystemException System Exception
	 */
	public List<MpOperationPerformanceTextDto> getListByOperationSeriesId(Long opeSerId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("select MP_OPERATION_PERFORMANCE_TEXT.*, TABLE_TITLE.MESSAGE from mp_operation_performance_text, TABLE_TITLE where IDREF_TABLE_TITLE = FREE_TEXT and perf_ope_ser_id = ");
		query.append(opeSerId);

		return selectSome(query.toString());
	}

	/**
	 * Get the list of the performances without label for an operation series.
	 * 
	 * @param opeSerId id of the oepration series
	 * @return the list of the performances without label for an operation series
	 * @throws SystemException System Exception
	 */
	public List<MpOperationPerformanceTextDto> getListByOperationSeriesIdWithoutLabel(Long opeSerId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("select MP_OPERATION_PERFORMANCE_TEXT.* from mp_operation_performance_text where perf_ope_ser_id = ");
		query.append(opeSerId);

		return selectSome(query.toString());
	}

	/**
	 * Not used.
	 * RsDto is used for generic CRUD function like findByDto, findAll...
	 * 
	 * @param rs resultset
	 * @return an SapSrtDefectDto instance
	 * @throws SQLException sql exception
	 */
	@Override
	protected MpOperationPerformanceTextDto rs2Dto(ResultSet rs) throws SQLException {

		return null;
	}
}
