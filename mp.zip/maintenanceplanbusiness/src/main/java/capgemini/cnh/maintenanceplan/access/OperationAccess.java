/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationDto;

/**
 * @author sdomecq
 *
 */
public class OperationAccess extends OracleAccess {

	/**
	 * Date Format.
	 */
	private String date_format = "dd/mm/yyyy";

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationDto dto = new OperationDto();

		dto.setId(getLongIfExists("OPE_ID"));

		dto.setCodeMicroOperation(getStringIfExists("OPE_CODE"));
		dto.setCodeSrt(getStringIfExists("OPE_SRT"));

		dto.setTitle(getStringIfExists("OPE_LABEL"));
		dto.setTitleId(getLongIfExists("OPE_TITLE_ID"));

		dto.setDescription(getStringIfExists("OPE_DESCRIPTION"));
		dto.setDescriptionId(getLongIfExists("OPE_DESCRIPTION_TITLE_ID"));

		dto.setStatus(getIntIfExists("OPE_STATUS"));
		dto.setModifDate(dateToString(getDateIfExists("OPE_DATE_MODIF")));
		dto.setLastModifier(getStringIfExists("OPE_LAST_MODIFIER"));

		dto.setLocationFamilyIceCode(getStringIfExists("OPE_LOC_FAM"));
		dto.setLocationGroupIceCode(getStringIfExists("OPE_LOC_GRO"));
		dto.setLocationSubGroupIceCode(getStringIfExists("OPE_LOC_SUG"));

		dto.setInfotypeTopicIceCode(getStringIfExists("OPE_INF_TOP"));
		dto.setInfotypeSubTopicIceCode(getStringIfExists("OPE_INF_SUT"));
		dto.setInfotypeCategoryIceCode(getStringIfExists("OPE_INF_CAT"));
		dto.setInfotypeInfotypeIceCode(getStringIfExists("OPE_INF_INF"));

		dto.setLocationLabel(getStringIfExists("OPE_LOCATION_LABEL"));
		dto.setInfotypeLabel(getStringIfExists("OPE_INFOTYPE_LABEL"));

		dto.setOperationCurrentSerie(getIntIfExists("NB_SERIES") != null && getIntIfExists("NB_SERIES") > 0);

		return dto;

	}

	/**
	 * Get the List of operation .
	 * 
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationDto> getList(String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION from MP_OPERATION o, table_title t1, table_title t2
		//		where 
		//		o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage= 'IT' or t1.idlanguage is null)
		//		and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= 'IT' or t2.idlanguage is null)

		query.append(" select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION from MP_OPERATION o, table_title t1, table_title t2 where ");
		query.append(" o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= ");
		query.append(formatString(language));
		query.append("  or t2.idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationDto> result = new ArrayList<OperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operation .
	 * 
	 * @param language for translated texts
	 * @param selectedSeriesIceCode for series actions check
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationDto> getList(String language, String selectedSeriesIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		String appli[] = selectedSeriesIceCode.split("[.]", 4);
		String brand = appli[0];
		String type = appli[1];
		String product = appli[2];
		String series = appli[3];

		// Create the query	

		query.append(" select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION, ");

		query.append("(select count(*) from MP_OPERATION_SERIES os where os.OPE_OPERATION_ID = o.OPE_ID ");
		query.append(" and os.OPE_APP_BRA =  ");
		query.append(formatString(brand));
		query.append(" and os.OPE_APP_TYP =  ");
		query.append(formatString(type));
		query.append(" and os.OPE_APP_PRO =  ");
		query.append(formatString(product));
		query.append(" and os.OPE_APP_SER =  ");
		query.append(formatString(series));
		query.append(") as NB_SERIES");

		query.append(" from MP_OPERATION o, table_title t1, table_title t2 where ");
		query.append(" o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= ");
		query.append(formatString(language));
		query.append("  or t2.idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationDto> result = new ArrayList<OperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationDto) dto);
		}

		return result;
	}

	/**
	 * Get one association operation/series.
	 * 
	 * @param idSeriesOperation to get
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto get(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select mp_operation.* from mp_operation, mp_operation_series ");
		query.append(" where ope_ser_id = ");
		query.append(idSeriesOperation);
		query.append(" and ope_operation_id = ope_id ");

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationDto) found;
	}

	/**
	 * Get the List of operation .
	 * 
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationDto> getListExport(String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		/*
		 * Query IAZ:
		 *	SELECT LANG, OPE_ID, OPE_LABEL, OPE_DESCRIPTION, OPE_LOCATION_LABEL, OPE_INFOTYPE_LABEL FROM (
		        SELECT
		        ROW_NUMBER() OVER (PARTITION BY op.OPE_ID ORDER BY CASE WHEN lo.lang = 'ES' THEN 1 ELSE 2 END) AS rnk,
		        op.OPE_ID, 
		        lo.lang, 
		        t1.message AS OPE_LABEL, 
		        t2.message AS OPE_DESCRIPTION, 
		        lo.sgroup_name AS OPE_LOCATION_LABEL, 
		        nf.inf_name AS OPE_INFOTYPE_LABEL 
		        FROM 
		        MP_OPERATION op 
		        LEFT OUTER JOIN table_title t1 ON (op.ope_title_id = t1.idref_table_title) 
		        LEFT OUTER JOIN table_title t2 ON (op.ope_description_title_id = t2.idref_table_title) 
		        INNER JOIN view_locations lo ON (op.ope_loc_fam = lo.fam_icecode AND op.ope_loc_gro = lo.group_icecode AND op.ope_loc_sug = lo.sgroup_icecode)
		        INNER JOIN view_infotypes nf ON (op.ope_inf_top = nf.top_icecode AND op.ope_inf_sut = nf.stop_icecode AND op.ope_inf_cat =  nf.cat_icecode AND op.ope_inf_inf = nf.inf_icecode)
		        WHERE 
		        ((t1.idlanguage = 'IT' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'IT' OR t2.idlanguage IS NULL) AND (lo.lang = 'IT') AND (nf.lang = 'IT')) OR
		        ((t1.idlanguage = 'ES' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'ES' OR t2.idlanguage IS NULL) AND (lo.lang = 'ES') AND (nf.lang = 'ES'))
			) WHERE rnk = 1;
			
			Query DBN:
			select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION, loc.sgroup_name OPE_LOCATION_LABEL, inf.inf_name OPE_INFOTYPE_LABEL
			from MP_OPERATION o, table_title t1, table_title t2, view_locations loc, view_infotypes inf, mp_operation_series opeser
		 	where o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage (+)= 'AR') 
			and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage(+)= 'AR') and (loc.lang(+) = 'AR'
		  	and loc.fam_icecode(+) = o.ope_loc_fam and loc.group_icecode(+) = o.ope_loc_gro and loc.sgroup_icecode(+) = o.ope_loc_sug) and (inf.lang(+) = 'AR'
		  	and inf.top_icecode(+) = o.ope_inf_top and inf.stop_icecode(+) = o.ope_inf_sut and inf.cat_icecode(+) = o.ope_inf_cat and inf.inf_icecode(+) = o.ope_inf_inf)
			and o.ope_id = opeser.ope_operation_id
		;      
		 */
		/*
		query.append(" SELECT LANG, OPE_ID, OPE_LABEL, OPE_DESCRIPTION, OPE_LOCATION_LABEL, OPE_INFOTYPE_LABEL FROM (");
		query.append(" SELECT");
		query.append(" ROW_NUMBER() OVER (PARTITION BY op.OPE_ID ORDER BY CASE WHEN lo.lang = 'ES' THEN 1 ELSE 2 END) AS rnk,");
		query.append(" op.OPE_ID, ");
		query.append(" lo.lang, ");
		query.append(" t1.message AS OPE_LABEL, ");
		query.append(" t2.message AS OPE_DESCRIPTION, ");
		query.append(" lo.sgroup_name AS OPE_LOCATION_LABEL, ");
		query.append(" nf.inf_name AS OPE_INFOTYPE_LABEL ");
		query.append(" FROM ");
		query.append(" MP_OPERATION op ");
		query.append(" LEFT OUTER JOIN table_title t1 ON (op.ope_title_id = t1.idref_table_title) ");
		query.append(" LEFT OUTER JOIN table_title t2 ON (op.ope_description_title_id = t2.idref_table_title) ");
		query.append(" INNER JOIN view_locations lo ON (op.ope_loc_fam = lo.fam_icecode AND op.ope_loc_gro = lo.group_icecode AND op.ope_loc_sug = lo.sgroup_icecode)");
		query.append(" INNER JOIN view_infotypes nf ON (op.ope_inf_top = nf.top_icecode AND op.ope_inf_sut = nf.stop_icecode AND op.ope_inf_cat =  nf.cat_icecode AND op.ope_inf_inf = nf.inf_icecode) ");
		query.append(" WHERE ");
		query.append(" ((t1.idlanguage = 'IT' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'IT' OR t2.idlanguage IS NULL) AND (lo.lang = 'IT') AND (nf.lang = 'IT')) OR");
		query.append(" ((t1.idlanguage = ");
		query.append(formatString(language));
		query.append(" OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'ES' OR t2.idlanguage IS NULL) AND (lo.lang = 'ES') AND (nf.lang = 'ES'))");
		query.append(" ) WHERE rnk = 1;");
		*/

		query.append(" select distinct o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION, loc.sgroup_name OPE_LOCATION_LABEL, inf.inf_name OPE_INFOTYPE_LABEL");
		query.append(" from MP_OPERATION o, table_title t1, table_title t2, view_locations loc, view_infotypes inf, mp_operation_series opeser ");
		query.append(" where o.ope_title_id = t1.idref_table_title(+) and t1.idlanguage(+)= ");
		query.append(formatString(language));
		query.append("  and o.ope_description_title_id = t2.idref_table_title(+) and t2.idlanguage(+)= ");
		query.append(formatString(language));
		query.append("  and loc.lang(+) = ");
		query.append(formatString(language));
		query.append("  and loc.fam_icecode(+) = o.ope_loc_fam and loc.group_icecode(+) = o.ope_loc_gro and loc.sgroup_icecode(+) = o.ope_loc_sug and inf.lang(+) = ");
		query.append(formatString(language));
		query.append("  and inf.top_icecode(+) = o.ope_inf_top and inf.stop_icecode(+) = o.ope_inf_sut and inf.cat_icecode(+) = o.ope_inf_cat and inf.inf_icecode(+) = o.ope_inf_inf ");
		query.append(" and o.ope_id = opeser.ope_operation_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationDto> result = new ArrayList<OperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of micro-operation .
	 * 
	 * @param language for translated texts
	 * @return the list of micro-operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationDto> getListExportMicro(String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		/*
		 * Query IAZ:
		 *	SELECT LANG, OPE_ID, OPE_LABEL, OPE_DESCRIPTION, OPE_LOCATION_LABEL, OPE_INFOTYPE_LABEL FROM (
		        SELECT
		        ROW_NUMBER() OVER (PARTITION BY op.OPE_ID ORDER BY CASE WHEN lo.lang = 'ES' THEN 1 ELSE 2 END) AS rnk,
		        op.OPE_ID, 
		        lo.lang, 
		        t1.message AS OPE_LABEL, 
		        t2.message AS OPE_DESCRIPTION, 
		        lo.sgroup_name AS OPE_LOCATION_LABEL, 
		        nf.inf_name AS OPE_INFOTYPE_LABEL 
		        FROM 
		        MP_OPERATION op 
		        LEFT OUTER JOIN table_title t1 ON (op.ope_title_id = t1.idref_table_title) 
		        LEFT OUTER JOIN table_title t2 ON (op.ope_description_title_id = t2.idref_table_title) 
		        INNER JOIN view_locations lo ON (op.ope_loc_fam = lo.fam_icecode AND op.ope_loc_gro = lo.group_icecode AND op.ope_loc_sug = lo.sgroup_icecode)
		        INNER JOIN view_infotypes nf ON (op.ope_inf_top = nf.top_icecode AND op.ope_inf_sut = nf.stop_icecode AND op.ope_inf_cat =  nf.cat_icecode AND op.ope_inf_inf = nf.inf_icecode)
		        WHERE 
		        ((t1.idlanguage = 'IT' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'IT' OR t2.idlanguage IS NULL) AND (lo.lang = 'IT') AND (nf.lang = 'IT')) OR
		        ((t1.idlanguage = 'ES' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'ES' OR t2.idlanguage IS NULL) AND (lo.lang = 'ES') AND (nf.lang = 'ES'))
			) WHERE rnk = 1;
			
			Query DBN:
			select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION, loc.sgroup_name OPE_LOCATION_LABEL, inf.inf_name OPE_INFOTYPE_LABEL
			from MP_OPERATION o, table_title t1, table_title t2, view_locations loc, view_infotypes inf 
		 	where o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage (+)= 'AR') 
			and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage(+)= 'AR') and (loc.lang(+) = 'AR'
		  	and loc.fam_icecode(+) = o.ope_loc_fam and loc.group_icecode(+) = o.ope_loc_gro and loc.sgroup_icecode(+) = o.ope_loc_sug) and (inf.lang(+) = 'AR'
		  	and inf.top_icecode(+) = o.ope_inf_top and inf.stop_icecode(+) = o.ope_inf_sut and inf.cat_icecode(+) = o.ope_inf_cat and inf.inf_icecode(+) = o.ope_inf_inf)
			AND o.ope_code is not null;      
		 */
		/*
		query.append(" SELECT LANG, OPE_ID, OPE_LABEL, OPE_DESCRIPTION, OPE_LOCATION_LABEL, OPE_INFOTYPE_LABEL FROM (");
		query.append(" SELECT");
		query.append(" ROW_NUMBER() OVER (PARTITION BY op.OPE_ID ORDER BY CASE WHEN lo.lang = 'ES' THEN 1 ELSE 2 END) AS rnk,");
		query.append(" op.OPE_ID, ");
		query.append(" lo.lang, ");
		query.append(" t1.message AS OPE_LABEL, ");
		query.append(" t2.message AS OPE_DESCRIPTION, ");
		query.append(" lo.sgroup_name AS OPE_LOCATION_LABEL, ");
		query.append(" nf.inf_name AS OPE_INFOTYPE_LABEL ");
		query.append(" FROM ");
		query.append(" MP_OPERATION op ");
		query.append(" LEFT OUTER JOIN table_title t1 ON (op.ope_title_id = t1.idref_table_title) ");
		query.append(" LEFT OUTER JOIN table_title t2 ON (op.ope_description_title_id = t2.idref_table_title) ");
		query.append(" INNER JOIN view_locations lo ON (op.ope_loc_fam = lo.fam_icecode AND op.ope_loc_gro = lo.group_icecode AND op.ope_loc_sug = lo.sgroup_icecode)");
		query.append(" INNER JOIN view_infotypes nf ON (op.ope_inf_top = nf.top_icecode AND op.ope_inf_sut = nf.stop_icecode AND op.ope_inf_cat =  nf.cat_icecode AND op.ope_inf_inf = nf.inf_icecode) ");
		query.append(" WHERE ");
		query.append(" ((t1.idlanguage = 'IT' OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'IT' OR t2.idlanguage IS NULL) AND (lo.lang = 'IT') AND (nf.lang = 'IT')) OR");
		query.append(" ((t1.idlanguage = ");
		query.append(formatString(language));
		query.append(" OR t1.idlanguage IS NULL) AND (t2.idlanguage = 'ES' OR t2.idlanguage IS NULL) AND (lo.lang = 'ES') AND (nf.lang = 'ES'))");
		query.append(" ) WHERE rnk = 1;");
		*/

		query.append(" select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION, loc.sgroup_name OPE_LOCATION_LABEL, inf.inf_name OPE_INFOTYPE_LABEL");
		query.append(" from MP_OPERATION o, table_title t1, table_title t2, view_locations loc, view_infotypes inf ");
		query.append(" where o.ope_title_id = t1.idref_table_title(+) and t1.idlanguage(+)= ");
		query.append(formatString(language));
		query.append("  and o.ope_description_title_id = t2.idref_table_title(+) and t2.idlanguage(+)= ");
		query.append(formatString(language));
		query.append("  and loc.lang(+) = ");
		query.append(formatString(language));
		query.append("  and loc.fam_icecode(+) = o.ope_loc_fam and loc.group_icecode(+) = o.ope_loc_gro and loc.sgroup_icecode(+) = o.ope_loc_sug and inf.lang(+) = ");
		query.append(formatString(language));
		query.append("  and inf.top_icecode(+) = o.ope_inf_top and inf.stop_icecode(+) = o.ope_inf_sut and inf.cat_icecode(+) = o.ope_inf_cat and inf.inf_icecode(+) = o.ope_inf_inf ");
		query.append(" AND o.ope_code is not null");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationDto> result = new ArrayList<OperationDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationDto) dto);
		}

		return result;
	}

	/**
	 * Get an operation .
	 * 
	 * @param idOperation to get
	 * @param language for translated texts
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto get(String idOperation, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION from MP_OPERATION o, table_title t1, table_title t2
		//		where 
		//		o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage= 'IT' or t1.idlanguage is null)
		//		and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= 'IT' or t2.idlanguage is null)

		query.append(" select o.*, t1.message OPE_LABEL, t2.message OPE_DESCRIPTION from MP_OPERATION o, table_title t1, table_title t2 where ");
		query.append(" o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= ");
		query.append(formatString(language));
		query.append("  or t2.idlanguage is null) ");
		query.append(" and OPE_ID = ");
		query.append(idOperation);

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationDto) found;
	}

	/**
	 * Get an operation without labels .
	 * 
	 * @param idOperation to get
	 * @param language for translated texts
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto getWarrantyOperationWithoutLabels(String idOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		/*		select OPE_ID,OPE_CODE,OPE_SRT,OPE_TITLE_ID,OPE_DESCRIPTION_TITLE_ID,OPE_STATUS,OPE_DATE_MODIF,OPE_LAST_MODIFIER,OPE_LOC_FAM,OPE_LOC_GRO,OPE_LOC_SUG,OPE_INF_TOP,
		OPE_INF_SUT,OPE_INF_CAT,OPE_INF_INF 
		from MP_OPERATION 
		where ope_srt is not null and OPE_ID = <id> */

		query.append(" select OPE_ID,OPE_CODE,OPE_SRT,OPE_TITLE_ID,OPE_DESCRIPTION_TITLE_ID,OPE_STATUS,OPE_DATE_MODIF,OPE_LAST_MODIFIER,OPE_LOC_FAM,OPE_LOC_GRO,OPE_LOC_SUG, ");
		query.append(" OPE_INF_TOP,OPE_INF_SUT,OPE_INF_CAT,OPE_INF_INF ");
		query.append(" from MP_OPERATION  ");
		query.append(" where ope_srt is not null and OPE_ID = ");
		query.append(idOperation);

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationDto) found;
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);

			query.append(
					"INSERT INTO MP_OPERATION ( OPE_CODE, OPE_SRT, OPE_TITLE_ID, OPE_DESCRIPTION_TITLE_ID, OPE_DATE_MODIF, OPE_STATUS, OPE_LOC_FAM, OPE_LOC_GRO, OPE_LOC_SUG, OPE_INF_TOP, OPE_INF_SUT, OPE_INF_CAT, OPE_INF_INF, OPE_LAST_MODIFIER) values (");
			query.append(formatString(dto.getCodeMicroOperation()));
			query.append(",");
			query.append(formatString(dto.getCodeSrt()));
			query.append(",");
			query.append(dto.getTitleId());
			query.append(",");
			query.append(dto.getDescriptionId());
			query.append(",");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(",");
			query.append(dto.getStatus());
			query.append(",");
			query.append(formatString(dto.getLocationFamilyIceCode()));
			query.append(",");
			query.append(formatString(dto.getLocationGroupIceCode()));
			query.append(",");
			query.append(formatString(dto.getLocationSubGroupIceCode()));
			query.append(",");
			query.append(formatString(dto.getInfotypeTopicIceCode()));
			query.append(",");
			query.append(formatString(dto.getInfotypeSubTopicIceCode()));
			query.append(",");
			query.append(formatString(dto.getInfotypeCategoryIceCode()));
			query.append(",");
			query.append(formatString(dto.getInfotypeInfotypeIceCode()));
			query.append(",");
			query.append(formatString(dto.getLastModifier()));
			query.append(")");

			executeQueryI("MP_OPERATION", query.toString());
		}

	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(OperationDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);

			query.append("update MP_OPERATION set");
			query.append(" OPE_CODE = ");
			query.append(formatString(dto.getCodeMicroOperation()));
			query.append(", OPE_SRT = ");
			query.append(formatString(dto.getCodeSrt()));
			query.append(", OPE_TITLE_ID = ");
			query.append(dto.getTitleId());
			query.append(", OPE_DESCRIPTION_TITLE_ID = ");
			query.append(dto.getDescriptionId());
			query.append(", OPE_DATE_MODIF = ");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(", OPE_STATUS = ");
			query.append(dto.getStatus());
			query.append(", OPE_LOC_FAM = ");
			query.append(formatString(dto.getLocationFamilyIceCode()));
			query.append(", OPE_LOC_GRO = ");
			query.append(formatString(dto.getLocationGroupIceCode()));
			query.append(", OPE_LOC_SUG = ");
			query.append(formatString(dto.getLocationSubGroupIceCode()));
			query.append(", OPE_INF_TOP = ");
			query.append(formatString(dto.getInfotypeTopicIceCode()));
			query.append(", OPE_INF_SUT = ");
			query.append(formatString(dto.getInfotypeSubTopicIceCode()));
			query.append(", OPE_INF_CAT = ");
			query.append(formatString(dto.getInfotypeCategoryIceCode()));
			query.append(",OPE_INF_INF = ");
			query.append(formatString(dto.getInfotypeInfotypeIceCode()));
			query.append(",OPE_LAST_MODIFIER = ");
			query.append(formatString(dto.getLastModifier()));
			query.append(" WHERE OPE_ID = ");
			query.append(dto.getId().toString());

			executeQueryI("MP_OPERATION", query.toString());
		}

	}

	/**
	 * delete operation in MP_OPERATION table.
	 * 
	 * @param operationId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteSelectedOperation(String operationId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_OPERATION  WHERE OPE_ID = ");
		query.append(operationId);

		executeQueryI("MP_OPERATION", query.toString());
	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
			result = sdf.format(myDate);
			//result = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + l_currentDate.get(Calendar.YEAR);
		}

		return result;
	}

	/**
	 * Get an operation .
	 * 
	 * @param id current element
	 * @param code of micro operation or warranty
	 * @param language for translated texts
	 * @param family of location
	 * @param group of location
	 * @param subGroup of location
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto getOperationByCodeAndByLocation(String id, String code, String family, String group, String subGroup, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select * from MP_OPERATION o, table_title t1, table_title t2 where ");
		query.append(" o.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and o.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= ");
		query.append(formatString(language));
		query.append("  or t2.idlanguage is null) ");
		query.append(" and (OPE_CODE = ");
		query.append(formatString(code));
		query.append(" or OPE_SRT = ");
		query.append(formatString(code));
		query.append(" ) and OPE_LOC_FAM = ");
		query.append(formatString(family));
		query.append(" and OPE_LOC_GRO = ");
		query.append(formatString(group));
		query.append(" and OPE_LOC_SUG = ");
		query.append(formatString(subGroup));
		if (id != null && !id.equals(""))
		{
			query.append(" and OPE_id != ");
			query.append(id);
		}

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationDto) found;
	}

	/**
	 * Get an operation based on its code.
	 * 
	 * @param code of micro operation or warranty
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationDto> getOperationByCode(String code) throws SystemException {
		List<OperationDto> list = new ArrayList<OperationDto>();
		StringBuilder query = new StringBuilder();

		query.append(" select * from MP_OPERATION ");
		query.append(" where (OPE_CODE = ");
		query.append(formatString(code));
		query.append(" or OPE_SRT = ");
		query.append(formatString(code));
		query.append(")");

		// Execute the query and get the result list
		List<Dto> found = executeQueryN(query.toString());
		for (Dto history : found)
		{
			list.add((OperationDto) history);
		}

		return list;
	}

	/**
	 * Get an operation based on its code.
	 * 
	 * @param code of micro operation or warranty
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto getOperationById(Long id) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select * from MP_OPERATION ");
		query.append(" where OPE_ID = ");
		query.append(id);

		// Execute the query and get the result list
		return (OperationDto) executeQuery1(query.toString());
	}
}
