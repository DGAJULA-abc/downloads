/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableDto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationConsumableAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationConsumableDto dto = new OperationConsumableDto();

		dto.setId(getLongIfExists("OPE_CONS_ID"));

		dto.setIdOperationSeries(getLongIfExists("OPE_CONS_OPE_SERIES_ID"));

		dto.setIdConsumable(getLongIfExists("OPE_CONS_CN_ID"));
		dto.setConsumable(getStringIfExists("CN_NAME"));
		dto.setConsumableDescription(getStringIfExists("CN_DESCRIPTION"));

		dto.setQuantity(getDoubleIfExists("OPE_CONS_QTY"));
		dto.setUnit(getStringIfExists("OPE_CONS_UNIT"));

		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		return dto;

	}

	/**
	 * Get the List of consumables for a given operation on a series depending on the brand of the consumable.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationConsumableDto> getList(String idSeriesOperation, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		/* Create the query	
				select distinct mp_operation_consumable.*, consumables.cn_group|| ' - ' ||consumables.CN_TECH_CHARACTERISTIC CN_NAME, cn_description, 
				decode((select count(*) from mp_consumable_applicability where appli_cons_id = ope_cons_id), 0, '', '*')  as WITH_APPLI
				from mp_operation_consumable, consumables, mp_operation_series
				where 33 = ope_ser_id 
				and ope_ser_id = ope_cons_ope_series_id
				and ope_cons_cn_id = cn_id
				and cn_lg = 'IT';
		*/
		query.append(" select distinct mp_operation_consumable.*, consumables.cn_group|| ' - ' ||consumables.CN_TECH_CHARACTERISTIC cn_name, cn_description, ");
		query.append(" decode((select count(*) from mp_consumable_applicability where appli_cons_id = ope_cons_id), 0, '', '*')  as WITH_APPLI ");
		query.append(" from mp_operation_consumable, consumables, mp_operation_series ");
		query.append(" where consumables.cn_id = mp_operation_consumable.ope_cons_cn_id ");
		query.append(" and consumables.cn_lg =");
		query.append(formatString(language));
		query.append(" and ope_ser_id = ");
		query.append(idSeriesOperation);
		query.append(" and ope_cons_ope_series_id = ope_ser_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationConsumableDto> result = new ArrayList<OperationConsumableDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationConsumableDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of consumables for a given operation on a series without language.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationConsumableDto> getList(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append("SELECT OPE_CONS_ID, OPE_CONS_OPE_SERIES_ID, OPE_CONS_CN_ID, OPE_CONS_QTY, OPE_CONS_UNIT ");
		query.append("FROM MP_OPERATION_CONSUMABLE WHERE OPE_CONS_OPE_SERIES_ID = ");
		query.append(idSeriesOperation);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationConsumableDto> result = new ArrayList<OperationConsumableDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationConsumableDto) dto);
		}

		return result;
	}

	/**
	 * add consumable for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationConsumableDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			dto.setId(getNextId());
			query.append("INSERT INTO mp_operation_consumable ( OPE_CONS_ID, OPE_CONS_OPE_SERIES_ID, OPE_CONS_CN_ID, OPE_CONS_QTY, OPE_CONS_UNIT) values (");
			query.append(dto.getId());
			query.append(",");
			query.append(dto.getIdOperationSeries());
			query.append(",");
			query.append(dto.getIdConsumable());
			query.append(",");
			query.append(dto.getQuantity());
			query.append(",");
			query.append(formatString(dto.getUnit()));
			query.append(")");

		}

		executeQueryI("mp_operation_consumable", query.toString());
	}

	/**
	 * update consumable for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(OperationConsumableDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			query.append("UPDATE mp_operation_consumable set OPE_CONS_CN_ID = ");
			query.append(dto.getIdConsumable());
			query.append(", OPE_CONS_QTY=");
			query.append(dto.getQuantity());
			query.append(", OPE_CONS_UNIT=");
			query.append(formatString(dto.getUnit()));
			query.append(" WHERE OPE_CONS_ID =");
			query.append(dto.getId());

		}

		executeQueryI("mp_operation_consumable", query.toString());
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_consumable where OPE_CONS_OPE_SERIES_ID = ");
		query.append(idSeriesOperation);

		executeQueryI("mp_operation_consumable", query.toString());
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_consumable where OPE_CONS_ID = ");
		query.append(id);

		executeQueryI("mp_operation_consumable", query.toString());
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_CONSUMABLE.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

}
