/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.common.util.Constants;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableApplicabilityDto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableApplicabilityAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationConsumableApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationConsumableApplicabilityDto dto = new OperationConsumableApplicabilityDto();

		dto.setId(getLongIfExists("APPLI_ID"));

		dto.setIdOperationConsumable(getLongIfExists("APPLI_CONS_ID"));
		dto.setIdOperationSeries(getLongIfExists("OPE_CONS_OPE_SERIES_ID"));

		dto.setModel(getStringIfExists("APPLI_MOD"));
		dto.setTt(getStringIfExists("APPLI_TT"));
		dto.setMarket(getLongIfExists("APPLI_MARKET"));
		dto.setConfig(getStringIfExists("APPLI_CONFIG"));
		return dto;

	}

	/**
	 * add consumable for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationConsumableApplicabilityDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO mp_consumable_applicability (  APPLI_CONS_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG) values (");
		query.append(dto.getIdOperationConsumable());
		query.append(",");
		query.append(formatString(dto.getModel()));
		query.append(",");
		query.append(formatString(dto.getTt()));
		query.append(",");
		query.append(dto.getMarket());
		query.append(",");
		query.append(formatString(dto.getConfig()));
		query.append(")");

		executeQueryI("mp_consumable_applicability", query.toString());
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_consumable_applicability where APPLI_CONS_ID = ");
		query.append(id.toString());

		executeQueryI("mp_consumable_applicability", query.toString());
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_consumable_applicability where APPLI_CONS_ID in (select OPE_CONS_ID from mp_operation_consumable where ope_cons_ope_series_id= ");
		query.append(idSeriesOperation.toString());

		query.append(" )");

		executeQueryI("mp_consumable_applicability", query.toString());
	}

	/**
	 * delete consumables applicability when consumable is removed.
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeriesWithoutConsumable() throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  delete from mp_consumable_applicability where APPLI_CONS_ID not in (select ope_CONS_ID from mp_operation_consumable  )");

		executeQueryI("mp_consumable_applicability", query.toString());
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idOpeCons to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableApplicabilityDto> getListApplicabilityByCons(String idOpeCons) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_consumable_applicability, mp_operation_consumable where APPLI_CONS_ID= ");
		query.append(idOpeCons);
		query.append(" and mp_consumable_applicability.appli_cons_id=mp_operation_consumable.ope_cons_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationConsumableApplicabilityDto> result = new ArrayList<OperationConsumableApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationConsumableApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of consumables for a given plan.
	 * 
	 * @param planId plan id
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ApplicabilityDto> getListForPlan(String planId) throws SystemException, ApplicativeException {

		/*
		 Query:
		 select distinct OPE_cons_OPE_SERIES_ID, appli_mod, appli_tt, appli_market, appli_config 
		from MP_OPERATION_CONSUMABLE, MP_CONSUMABLE_APPLICABILITY , mp_interval, mp_interval_operation, mp_operation_series
		where int_plan_id = 12000 
		and def_interval_id = int_id
		and DEF_OPE_SERIES_ID = ope_ser_id
		and ope_ser_id = OPE_PN_OPE_SERIES_ID 
		and APPLI_PN_ID(+) = ope_pn_id 
		and ope_pn_in_kit = 0
		order by 1,2,3,4;
		 
		 */
		StringBuilder query = new StringBuilder();

		query.append("  select distinct OPE_cons_OPE_SERIES_ID, appli_mod, appli_tt, appli_market, appli_config  ");
		query.append(" from MP_OPERATION_CONSUMABLE, MP_CONSUMABLE_APPLICABILITY , mp_interval, mp_interval_operation, mp_operation_series ");
		query.append(" where int_plan_id = ");
		query.append(planId);
		query.append(" and def_interval_id = int_id ");
		query.append(" and DEF_OPE_SERIES_ID = ope_ser_id ");
		query.append(" and ope_ser_id = OPE_CONS_OPE_SERIES_ID  ");
		query.append(" and APPLI_CONS_ID(+) = ope_CONS_id ");
		query.append(" order by 1,2,3,4 ");

		// Execute the query and get the result list
		List<ApplicabilityDto> result = executeQueryN(query.toString());

		return result;
	}

	/**
	 * Get the applicability of the consumables of a project.
	 * 
	 * @param projectId project id
	 * @return a list of consumable applicabilities
	 * @throws SystemException SystemException
	 */
	public List<OperationConsumableApplicabilityDto> getApplicabilityListByProject(String projectId) throws SystemException {
		/*
		 Query:
		 	select distinct APPLI_ID, APPLI_CONS_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG 
			from mp_maintenance_project, mp_maintenance_plan, mp_interval, mp_interval_operation, mp_operation_series, mp_operation_consumable, mp_consumable_applicability 
			where mp_id = plan_project_id 
			and plan_id = int_plan_id 
			and int_id = def_interval_id 
			and def_ope_series_id = ope_ser_id 
			and ope_cons_ope_series_id = ope_ser_id 
			and appli_cons_id = ope_cons_id 
			and mp_id = 453
		 
		 */

		StringBuilder query = new StringBuilder();

		query.append("select distinct APPLI_ID, APPLI_CONS_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG  ");
		query.append("from mp_maintenance_project, mp_operation_series, mp_operation_consumable, mp_consumable_applicability ");
		query.append("where mp_id = ope_mp_id ");
		query.append("and ope_cons_ope_series_id = ope_ser_id ");
		query.append("and appli_cons_id = ope_cons_id ");
		query.append("and mp_id =  ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}

	/**
	 * Get the applicability of the consumables of a project.
	 * 
	 * @param projectId project id
	 * @param mode RELEASED or DRAFT
	 * @return a list of consumable applicabilities
	 * @throws SystemException SystemException
	 */
	public List<OperationConsumableApplicabilityDto> getApplicabilityListByProject(String projectId, String mode) throws SystemException {
		/*
		 Query:
		 	select distinct APPLI_ID, APPLI_CONS_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG 
			from mp_maintenance_project, mp_maintenance_plan, mp_interval, mp_interval_operation, mp_operation_series, mp_operation_consumable, mp_consumable_applicability 
			where mp_id = plan_project_id 
			and plan_id = int_plan_id 
			and plan_status = '1'
			and int_id = def_interval_id 
			and def_ope_series_id = ope_ser_id 
			and ope_cons_ope_series_id = ope_ser_id 
			and appli_cons_id = ope_cons_id 
			and mp_id = 453
		 
		 */

		StringBuilder query = new StringBuilder();

		query.append("select distinct APPLI_ID, APPLI_CONS_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG  ");
		query.append("from mp_maintenance_project, mp_maintenance_plan, mp_operation_series, mp_operation_consumable, mp_consumable_applicability ");
		query.append("where mp_id = plan_project_id ");
		query.append(" and ope_mp_id = mp_id ");
		if (mode != null)
		{
			if (mode.equals(Constants.RELEASED_MODE))
			{
				query.append(" and plan_status = '1' ");
			}
			else if (mode.equals(Constants.DRAFT_MODE))
			{
				query.append(" and plan_status = '0' ");
			}
		}
		query.append("and ope_cons_ope_series_id = ope_ser_id ");
		query.append("and appli_cons_id = ope_cons_id ");
		query.append("and mp_id =  ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}

	/**
	 * Get the List of applicability by project.
	 * 
	 * @param projectId The project Id
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableApplicabilityDto> getListApplicabilityByProject(String projectId) throws SystemException, ApplicativeException {
		/*
		 Query:
		 	select APPLI_ID, APPLI_cons_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG  from mp_operation_series,  mp_operation_consumable, MP_consumable_APPLICABILITY 
			where ope_ser_id = ope_cons_ope_series_id 
			and ope_cons_id = appli_cons_id 
			and (ope_app_bra ||'.'|| ope_app_typ ||'.'|| ope_app_pro ||'.'|| ope_app_ser) = '2.1.40.210' and ope_mp_id is null
		 * 
		 */
		StringBuilder query = new StringBuilder();

		query.append("select APPLI_ID, APPLI_cons_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG ");
		query.append("from mp_operation_series, mp_operation_consumable, MP_consumable_APPLICABILITY  ");
		query.append("where ope_ser_id = ope_cons_ope_series_id ");
		query.append("and ope_cons_id = appli_cons_id  ");
		query.append("and ope_mp_id = ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}
}
