/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableCompareAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationConsumableCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationConsumableCompareDto dto = new OperationConsumableCompareDto();

		dto.setId(getLongIfExists("OPE_CONS_ID"));

		dto.setIdOperationSeries(getLongIfExists("OPE_CONS_OPE_SERIES_ID"));

		dto.setIdConsumable(getLongIfExists("OPE_CONS_CN_ID"));
		dto.setConsumable(getStringIfExists("CN_NAME"));

		dto.setQuantity(getDoubleIfExists("OPE_CONS_QTY"));
		dto.setUnit(getStringIfExists("OPE_CONS_UNIT"));

		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		dto.setModelAppli(getStringIfExists("APPLI_MOD"));
		dto.setTtAppli(getStringIfExists("APPLI_TT"));
		dto.setMarketAppli(getLongIfExists("APPLI_MARKET"));
		dto.setConfigAppli(getStringIfExists("APPLI_CONFIG"));

		return dto;

	}

	/**
	 * Get the List of consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationConsumableCompareDto> getList(String idSeriesOperation, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		select distinct mp_operation_consumable.*, consumables.cn_group|| ' - ' ||consumables.CN_TECH_CHARACTERISTIC CN_NAME, 
		//	    decode((select count(*) from mp_consumable_applicability where appli_cons_id = ope_cons_id), 0, '', '*')  as WITH_APPLI
		//		,mp_consumable_applicability.appli_mod, mp_consumable_applicability.appli_tt,
		//		mp_consumable_applicability.appli_market, mp_consumable_applicability.appli_config
		//		from mp_operation_consumable, consumables,  mp_consumable_applicability
		//		where consumables.cn_id = mp_operation_consumable.ope_cons_cn_id 
		//		and consumables.cn_lg = 'IT' 
		//		and ope_cons_ope_series_id = 999
		//		and mp_consumable_applicability.appli_cons_id(+) = mp_operation_consumable.ope_cons_id

		query.append(" select distinct mp_operation_consumable.*, consumables.cn_group|| ' - ' ||consumables.cn_tech_characteristic cn_name, ");
		query.append(" decode((select count(*) from mp_consumable_applicability where appli_cons_id = ope_cons_id), 0, '', '*')  as WITH_APPLI ");
		query.append(" ,mp_consumable_applicability.appli_mod, mp_consumable_applicability.appli_tt, ");
		query.append(" mp_consumable_applicability.appli_market, mp_consumable_applicability.appli_config ");
		query.append(" from mp_operation_consumable, consumables,  mp_consumable_applicability ");
		query.append(" where consumables.cn_id = mp_operation_consumable.ope_cons_cn_id ");
		query.append(" and consumables.cn_lg =");
		query.append(formatString(language));
		query.append(" and ope_cons_ope_series_id =");
		query.append(idSeriesOperation);
		query.append(" and mp_consumable_applicability.appli_cons_id(+) = mp_operation_consumable.ope_cons_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationConsumableCompareDto> result = new ArrayList<OperationConsumableCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationConsumableCompareDto) dto);
		}

		return result;
	}

}
