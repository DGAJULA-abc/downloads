/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationIuLinkDto;

/**
 * @author mamestoy
 *
 */
public class OperationIuLinkAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationIuLinkAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto

		OperationIuLinkDto dto = new OperationIuLinkDto();

		dto.setId(getLongIfExists("IU_OPE_ID"));
		dto.setIdOperationSeries(getLongIfExists("IU_OPE_SER_ID"));
		dto.setIuId(getStringIfExists("IU_ID"));
		dto.setIuTitle(getStringIfExists("IU_TITLE"));
		dto.setIuLocation(getStringIfExists("IU_LOCATION"));
		dto.setIuInfotype(getStringIfExists("IU_INFOTYPE"));

		return dto;

	}

	/**
	 * Get the List of IUs for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of IUs
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationIuLinkDto> getList(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select IU_OPE_ID, IU_OPE_SER_ID, IU_ID, IU_TITLE, IU_LOCATION, IU_INFOTYPE ");
		query.append(" from MP_OPERATION_IULINK ");
		query.append(" where IU_OPE_SER_ID = ");
		query.append(idSeriesOperation);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationIuLinkDto> result = new ArrayList<OperationIuLinkDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationIuLinkDto) dto);
		}

		return result;
	}

	/**
	 * delete iu link for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_OPERATION_IULINK where IU_OPE_ID = ");
		query.append(id);

		executeQueryI("MP_OPERATION_IULINK", query.toString());
	}

	/**
	 * add iu link for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationIuLinkDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			dto.setId(getNextId());
			query.append("INSERT INTO MP_OPERATION_IULINK (IU_OPE_ID, IU_OPE_SER_ID, IU_ID, IU_TITLE, IU_LOCATION, IU_INFOTYPE) values (");
			query.append(dto.getId());
			query.append(",");
			query.append(dto.getIdOperationSeries());
			query.append(",");
			query.append(formatString(dto.getIuId()));
			query.append(",");
			query.append(formatString(dto.getIuTitle()));
			query.append(",");
			query.append(formatString(dto.getIuLocation()));
			query.append(",");
			query.append(formatString(dto.getIuInfotype()));
			query.append(")");

		}

		executeQueryI("MP_OPERATION_IULINK", query.toString());
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_IULINK.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * Get a link IU/operation series Id.
	 * 
	 * @param opSerId operation series Id
	 * @param IuId IU id
	 * @param location iu location
	 * @param infotype iu infotype
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationIuLinkDto getLinkForIuSeries(String opSerId, String IuId, String location, String infotype) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select * from MP_OPERATION_IULINK ");
		query.append(" where IU_OPE_SER_ID = ");
		query.append(formatString(opSerId));
		query.append(" and IU_ID = ");
		query.append(formatString(IuId));
		query.append(" and IU_LOCATION = ");
		query.append(formatString(location));
		query.append(" and IU_INFOTYPE = ");
		query.append(formatString(infotype));

		// Execute the query and get the result list
		return (OperationIuLinkDto) executeQuery1(query.toString());
	}

}
