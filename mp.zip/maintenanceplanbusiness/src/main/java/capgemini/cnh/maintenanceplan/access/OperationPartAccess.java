/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationPartDto;

/**
 * @author sdomecq
 *
 */
public class OperationPartAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPartAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPartDto dto = new OperationPartDto();

		dto.setId(getLongIfExists("OPE_PN_ID"));

		dto.setIdOperationSeries(getLongIfExists("OPE_PN_OPE_SERIES_ID"));

		dto.setCodePart(getStringIfExists("OPE_PN_CODE"));
		dto.setPartLabel(getStringIfExists("PN_LABEL"));

		dto.setPartLabelOrigin(getStringIfExists("PN_LABEL_ORIGIN"));

		dto.setNote(getStringIfExists("OPE_PN_NOTE"));

		dto.setQuantity(getDoubleIfExists("OPE_PN_QTY"));

		dto.setGroup(getIntIfExists("OPE_PN_GROUP"));

		if (getBooleanIfExists("OPE_PN_IN_KIT") != null)
		{
			dto.setInKit(getBooleanIfExists("OPE_PN_IN_KIT").booleanValue());
		}

		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		return dto;

	}

	/**
	 * Get the List of parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPartDto> getList(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		select distinct mp_operation_part_number.* , PN_LABEL,
		//		decode((select count(*) from mp_part_applicability where appli_pn_id = ope_pn_id), 0, '', '*')  as WITH_APPLI
		//		from mp_operation_part_number,  model, ice_technical_type, config_value, config_item, mp_part_number
		//		where ope_pn_ope_series_id = 999
		//	    and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code		

		query.append(" select distinct mp_operation_part_number.* , PN_LABEL , PN_LABEL_ORIGIN, ");
		query.append(" decode((select count(*) from mp_part_applicability where appli_pn_id = ope_pn_id), 0, '', '*')  as WITH_APPLI ");
		query.append(" from mp_operation_part_number,  mp_part_number ");
		query.append(" where ope_pn_ope_series_id = ");
		query.append(idSeriesOperation);
		query.append(" and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPartDto> result = new ArrayList<OperationPartDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPartDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of part (no Kits) for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartDto> getNonKitList(String idSeriesOperation) throws SystemException, ApplicativeException {

		StringBuilder query = new StringBuilder();

		/* Create the query	
				select distinct mp_operation_part_number.* , PN_LABEL
				from mp_operation_part_number, mp_part_number
				where ope_pn_ope_series_id = 22594
			    and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code
		        and ope_pn_in_kit = 0;		
		*/
		query.append(" select distinct mp_operation_part_number.* , PN_LABEL ");
		query.append(" from mp_operation_part_number,  mp_part_number ");
		query.append(" where ope_pn_ope_series_id = ");
		query.append(idSeriesOperation);
		query.append(" and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code and ope_pn_in_kit = 0 ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPartDto> result = new ArrayList<OperationPartDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPartDto) dto);
		}

		return result;
	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationPartDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			dto.setId(getNextId());

			query.append("INSERT INTO mp_operation_part_number ( OPE_PN_ID, OPE_PN_OPE_SERIES_ID, OPE_PN_CODE, OPE_PN_NOTE, OPE_PN_QTY, OPE_PN_GROUP, OPE_PN_IN_KIT) values (");
			query.append(dto.getId());
			query.append(",");
			query.append(dto.getIdOperationSeries());
			query.append(",");
			query.append(formatString(dto.getCodePart()));
			query.append(",");
			query.append(formatString(dto.getNote()));
			query.append(",");
			query.append(dto.getQuantity());
			query.append(",");
			query.append(dto.getGroup());
			query.append(",");
			if (dto.getInKit())
			{
				query.append(1);
			}
			else
			{
				query.append(0);
			}
			query.append(")");
		}

		executeQueryI("mp_operation_part_number", query.toString());
	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(OperationPartDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			query.append("UPDATE mp_operation_part_number set OPE_PN_CODE=");
			query.append(formatString(dto.getCodePart()));
			query.append(", OPE_PN_NOTE=");
			query.append(formatString(dto.getNote()));
			query.append(", OPE_PN_QTY=");
			query.append(dto.getQuantity());
			query.append(", OPE_PN_GROUP=");
			query.append(dto.getGroup());
			query.append(", OPE_PN_IN_KIT = ");
			if (dto.getInKit())
			{
				query.append(1);
			}
			else
			{
				query.append(0);
			}
			query.append(" where OPE_PN_ID = ");
			query.append(dto.getId().toString());
		}

		executeQueryI("mp_operation_part_number", query.toString());
	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_part_number where OPE_PN_OPE_SERIES_ID = ");
		query.append(idSeriesOperation);

		executeQueryI("mp_operation_part_number", query.toString());
	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_part_number where OPE_PN_ID = ");
		query.append(id);

		executeQueryI("mp_operation_part_number", query.toString());
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_PART_NUMBER.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

}
