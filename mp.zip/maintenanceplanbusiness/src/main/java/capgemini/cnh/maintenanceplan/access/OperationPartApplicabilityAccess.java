/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationPartApplicabilityDto;

/**
 * @author sdomecq
 *
 */
public class OperationPartApplicabilityAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPartApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPartApplicabilityDto dto = new OperationPartApplicabilityDto();

		dto.setId(getLongIfExists("APPLI_ID"));

		dto.setIdOperationPart(getLongIfExists("APPLI_PN_ID"));
		dto.setIdOperationSeries(getLongIfExists("OPE_PN_OPE_SERIES_ID"));

		dto.setModel(getStringIfExists("APPLI_MOD"));
		dto.setTt(getStringIfExists("APPLI_TT"));
		dto.setMarket(getLongIfExists("APPLI_MARKET"));
		dto.setConfig(getStringIfExists("APPLI_CONFIG"));

		return dto;

	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationPartApplicabilityDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO mp_part_applicability (   APPLI_PN_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG) values (");
		query.append(dto.getIdOperationPart());
		query.append(",");
		query.append(formatString(dto.getModel()));
		query.append(",");
		query.append(formatString(dto.getTt()));
		query.append(",");
		query.append(dto.getMarket());
		query.append(",");
		query.append(formatString(dto.getConfig()));
		query.append(")");

		executeQueryI("mp_part_applicability", query.toString());
	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_part_applicability where APPLI_PN_ID = ");
		query.append(id.toString());

		executeQueryI("mp_part_applicability", query.toString());
	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_part_applicability where APPLI_PN_ID in (select OPE_PN_ID from MP_OPERATION_PART_NUMBER where OPE_PN_OPE_SERIES_ID= ");
		query.append(idSeriesOperation.toString());

		query.append(" )");

		executeQueryI("mp_part_applicability", query.toString());
	}

	/**
	 * delete parts applicability when part is removed.
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeriesWithoutPart() throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  delete from mp_part_applicability where APPLI_PN_ID not in (select ope_pn_ID from mp_operation_part_number  )");

		executeQueryI("mp_part_applicability", query.toString());
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idOpePart to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartApplicabilityDto> getListApplicabilityByPart(String idOpePart) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append("  select mp_part_applicability.* from mp_part_applicability, mp_operation_part_number where APPLI_PN_ID= ");
		query.append(idOpePart);
		query.append(" and mp_operation_part_number.ope_pn_id = mp_part_applicability.appli_pn_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPartApplicabilityDto> result = new ArrayList<OperationPartApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPartApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of part for a given operation on a series with applicability information.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ApplicabilityDto> getListNonKitWithApplicabilityForPlan(String planId) throws SystemException, ApplicativeException {

		/*
		 Query:
		 select distinct OPE_PN_OPE_SERIES_ID, appli_mod, appli_tt, appli_market, appli_config 
		from MP_OPERATION_PART_NUMBER, MP_PART_APPLICABILITY , mp_interval, mp_interval_operation, mp_operation_series
		where int_plan_id = 12000 
		and def_interval_id = int_id
		and DEF_OPE_SERIES_ID = ope_ser_id
		and ope_ser_id = OPE_PN_OPE_SERIES_ID 
		and APPLI_PN_ID(+) = ope_pn_id 
		and ope_pn_in_kit = 0
		order by 1,2,3,4;
		 
		 */
		StringBuilder query = new StringBuilder();

		query.append("  select distinct OPE_PN_OPE_SERIES_ID, appli_mod, appli_tt, appli_market, appli_config  ");
		query.append(" from MP_OPERATION_PART_NUMBER, MP_PART_APPLICABILITY , mp_interval, mp_interval_operation, mp_operation_series ");
		query.append(" where int_plan_id = ");
		query.append(planId);
		query.append(" and def_interval_id = int_id ");
		query.append(" and DEF_OPE_SERIES_ID = ope_ser_id ");
		query.append(" and ope_ser_id = OPE_PN_OPE_SERIES_ID  ");
		query.append(" and APPLI_PN_ID(+) = ope_pn_id and ope_pn_in_kit = 0 ");
		query.append(" order by 1,2,3,4 ");

		// Execute the query and get the result list
		List<ApplicabilityDto> result = executeQueryN(query.toString());

		return result;
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idOpePart to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartApplicabilityDto> getListApplicabilityByPartExport(String idOpePart) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append("  select mp_part_applicability_migrate.* from mp_part_applicability_migrate, mp_operation_part_number where APPLI_PN_ID= ");
		query.append(idOpePart);
		query.append(" and mp_operation_part_number.ope_pn_id = mp_part_applicability_migrate.appli_pn_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPartApplicabilityDto> result = new ArrayList<OperationPartApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPartApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of applicability by project.
	 * 
	 * @param projectId project Id
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartApplicabilityDto> getListApplicabilityByProject(String projectId) throws SystemException, ApplicativeException {
		/*
		 Query:
		 	select MP_PART_APPLICABILITY.* from mp_operation_series, mp_operation_part_number, MP_PART_APPLICABILITY 
			where ope_ser_id = ope_pn_ope_series_id 
			and ope_pn_id = appli_pn_id 
			and (ope_app_bra ||'.'|| ope_app_typ ||'.'|| ope_app_pro ||'.'|| ope_app_ser) = '2.1.40.210' and ope_mp_id is null
		 * 
		 */
		StringBuilder query = new StringBuilder();

		query.append("select APPLI_ID, APPLI_PN_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG ");
		query.append("from mp_operation_series, mp_operation_part_number, MP_PART_APPLICABILITY  ");
		query.append("where ope_ser_id = ope_pn_ope_series_id ");
		query.append("and ope_pn_id = appli_pn_id  ");
		query.append("and ope_mp_id = ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}
}
