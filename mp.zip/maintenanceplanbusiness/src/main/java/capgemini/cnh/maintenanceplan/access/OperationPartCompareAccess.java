/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationPartCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationPartCompareAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPartCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPartCompareDto dto = new OperationPartCompareDto();

		dto.setId(getLongIfExists("OPE_PN_ID"));

		dto.setIdOperationSeries(getLongIfExists("OPE_PN_OPE_SERIES_ID"));

		dto.setCodePart(getStringIfExists("OPE_PN_CODE"));
		dto.setPartLabel(getStringIfExists("PN_LABEL"));

		dto.setQuantity(getDoubleIfExists("OPE_PN_QTY"));

		if (getBooleanIfExists("OPE_PN_IN_KIT") != null)
		{
			dto.setInKit(getBooleanIfExists("OPE_PN_IN_KIT").booleanValue());
		}

		dto.setWithAppli(getStringIfExists("WITH_APPLI"));
		dto.setModelAppli(getStringIfExists("APPLI_MOD"));
		dto.setTtAppli(getStringIfExists("APPLI_TT"));
		dto.setMarketAppli(getLongIfExists("APPLI_MARKET"));
		dto.setConfigAppli(getStringIfExists("APPLI_CONFIG"));

		return dto;

	}

	/**
	 * Get the List of parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPartCompareDto> getList(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		select distinct mp_operation_part_number.* , PN_LABEL,
		//		decode((select count(*) from mp_part_applicability where appli_pn_id = ope_pn_id), 0, '', '*')  as WITH_APPLI
		//		, mp_part_applicability.appli_mod, mp_part_applicability.appli_tt, mp_part_applicability.appli_market, mp_part_applicability.appli_config
		//		from mp_operation_part_number, mp_part_number, mp_part_applicability
		//		where ope_pn_ope_series_id = 999
		//	    and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code
		//		and mp_part_applicability.appli_pn_id(+) = mp_operation_part_number.ope_pn_id

		query.append(" select distinct mp_operation_part_number.* , PN_LABEL , ");
		query.append(" decode((select count(*) from mp_part_applicability where appli_pn_id = ope_pn_id), 0, '', '*')  as WITH_APPLI ");
		query.append(" , mp_part_applicability.appli_mod, mp_part_applicability.appli_tt, mp_part_applicability.appli_market,");
		query.append(" mp_part_applicability.appli_config");
		query.append(" from mp_operation_part_number,  mp_part_number, mp_part_applicability ");
		query.append(" where ope_pn_ope_series_id = ");
		query.append(idSeriesOperation);
		query.append(" and mp_operation_part_number.ope_pn_code = mp_part_number.pn_code ");
		query.append(" and mp_part_applicability.appli_pn_id(+) = mp_operation_part_number.ope_pn_id");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPartCompareDto> result = new ArrayList<OperationPartCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPartCompareDto) dto);
		}

		return result;
	}

}
