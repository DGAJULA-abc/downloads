/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceCompareDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author mamestoy
 *
 */
public class OperationPerfCompareAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPerfCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPerformanceCompareDto dto = new OperationPerformanceCompareDto();

		dto.setIdPerformance(getLongIfExists("PERF_ID"));
		dto.setIdOperationSeries(getLongIfExists("PERF_OPE_SER_ID"));
		dto.setPerformanceLabel(getStringIfExists("PERF_NAME"));

		dto.setMaxStartValueKm(getLongIfExists("PERF_MAX_START_VALUE_KM"));
		dto.setMaxStartValueMonth(getLongIfExists("PERF_MAX_START_VALUE_MONTH"));
		dto.setMaxStartValueHour(getLongIfExists("PERF_MAX_START_VALUE_HOUR"));

		dto.setMaxAfterValueKm(getLongIfExists("PERF_MAX_AFTER_VALUE_KM"));
		dto.setMaxAfterValueMonth(getLongIfExists("PERF_MAX_AFTER_VALUE_MONTH"));
		dto.setMaxAfterValueHour(getLongIfExists("PERF_MAX_AFTER_VALUE_HOUR"));

		dto.setHarmStartValueKm(getLongIfExists("PERF_HARM_START_VALUE_KM"));
		dto.setHarmStartValueMonth(getLongIfExists("PERF_HARM_START_VALUE_MONTH"));
		dto.setHarmStartValueHour(getLongIfExists("PERF_HARM_START_VALUE_HOUR"));

		dto.setHarmAfterValueKm(getLongIfExists("PERF_HARM_AFTER_VALUE_KM"));
		dto.setHarmAfterValueMonth(getLongIfExists("PERF_HARM_AFTER_VALUE_MONTH"));
		dto.setHarmAfterValueHour(getLongIfExists("PERF_HARM_AFTER_VALUE_HOUR"));

		dto.setMaxGroup(getLongIfExists("PERF_MAX_GROUP"));
		dto.setHarmGroup(getLongIfExists("PERF_HARM_GROUP"));

		if (getLongIfExists("COND_ID") != null)
		{
			ConditionDto condition = new ConditionDto();
			condition.setIdCondition(getLongIfExists("COND_ID"));
			condition.setIdPerformance(getLongIfExists("PERF_ID"));

			if (getStringIfExists("COND_USAGE_VALUE") != null)
			{
				UsageDto usage = new UsageDto();
				usage.setValueId(getLongIfExists("COND_USAGE_VALUE"));
				usage.setValueTitle(getStringIfExists("VALUE_TITLE"));
				usage.setItemTitle(getStringIfExists("ITEM_TITLE"));

				condition.setUsage(usage);
			}

			dto.setCondition(condition);
		}
		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		dto.setModelAppli(getStringIfExists("APPLI_MOD"));
		dto.setTtAppli(getStringIfExists("APPLI_TT"));
		dto.setMarketAppli(getLongIfExists("APPLI_MARKET"));
		dto.setConfigAppli(getStringIfExists("APPLI_CONFIG"));

		return dto;

	}

	/**
	 * Get the List of performances .
	 * 
	 * @param operationSeriesId filter
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPerformanceCompareDto> getList(String operationSeriesId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		select distinct mp_operation_performance.* , perf_name, 
		//		 decode((select count(*) from mp_ope_perf_applicability where appli_perf_id = perf_id), 0, '', '*')  as WITH_APPLI 
		//		 , mp_ope_perf_applicability.appli_mod, mp_ope_perf_applicability.appli_tt, mp_ope_perf_applicability.appli_market,
		//		 mp_ope_perf_applicability.appli_config
		//		  from mp_operation_performance, mp_ope_perf_applicability, mp_operation_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv
		//		  where perf_ope_ser_id=
		//		<>
		//		  and mp_operation_performance.perf_id = mp_ope_perf_applicability.appli_perf_id (+) 
		//		  and mp_operation_performance.perf_id = mp_operation_condition.cond_perf_id(+) 
		//		  and mp_operation_condition.cond_usage_value = v.us_value_id(+) 
		//		  and v.us_item_id = i.us_item_id (+) 
		//		  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) 
		//		  and (ti.idlanguage =
		//		'EN'
		//		   or ti.idlanguage is null) 
		//		 and v.US_TITLE_ID = tv.idref_table_title(+) 
		//		 and (tv.idlanguage =
		//		'EN'
		//		  or tv.idlanguage is null) 

		// Create the query	
		query.append("  select distinct mp_operation_performance.* , perf_name, mp_operation_condition.*, v.*, ");
		query.append(" decode((select count(*) from mp_ope_perf_applicability where appli_perf_id = perf_id), 0, '', '*')  as WITH_APPLI ");
		query.append(" , mp_ope_perf_applicability.appli_mod, mp_ope_perf_applicability.appli_tt, mp_ope_perf_applicability.appli_market,");
		query.append(" mp_ope_perf_applicability.appli_config");
		query.append("  from mp_operation_performance, mp_ope_perf_applicability, mp_operation_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv");
		query.append("  where perf_ope_ser_id=");
		query.append(operationSeriesId);
		query.append("  and mp_operation_performance.perf_id = mp_ope_perf_applicability.appli_perf_id (+) ");
		query.append("  and mp_operation_performance.perf_id = mp_operation_condition.cond_perf_id(+) ");
		query.append("  and mp_operation_condition.cond_usage_value = v.us_value_id(+) ");
		query.append("  and v.us_item_id = i.us_item_id (+) ");
		query.append("  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) ");
		query.append("  and (ti.idlanguage =");
		query.append(formatString(language));
		query.append("   or ti.idlanguage is null) ");
		query.append("  and v.US_TITLE_ID = tv.idref_table_title(+) ");
		query.append("  and (tv.idlanguage =");
		query.append(formatString(language));
		query.append("   or tv.idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceCompareDto> result = new ArrayList<OperationPerformanceCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceCompareDto) dto);
		}

		return result;
	}

}
