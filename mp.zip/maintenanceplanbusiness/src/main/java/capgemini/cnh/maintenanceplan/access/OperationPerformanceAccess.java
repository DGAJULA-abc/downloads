/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import capgemini.cnh.common.util.Util;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class OperationPerformanceAccess extends OracleAccess {

	/**
	 * Date Format.
	 */
	private String date_format = "dd/MM/yyyy HH24:MI:SS";

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPerformanceAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPerformanceDto dto = new OperationPerformanceDto();

		dto.setIdPerformance(getLongIfExists("PERF_ID"));
		dto.setIdOperationSeries(getLongIfExists("PERF_OPE_SER_ID"));
		dto.setOperationCode(getStringIfExists("OPE_CODE"));
		dto.setPerformanceLabel(getStringIfExists("PERF_NAME"));

		dto.setMaxStartValueKm(getLongIfExists("PERF_MAX_START_VALUE_KM"));
		dto.setMaxStartValueMonth(getLongIfExists("PERF_MAX_START_VALUE_MONTH"));
		dto.setMaxStartValueHour(getLongIfExists("PERF_MAX_START_VALUE_HOUR"));

		dto.setMaxAfterValueKm(getLongIfExists("PERF_MAX_AFTER_VALUE_KM"));
		dto.setMaxAfterValueMonth(getLongIfExists("PERF_MAX_AFTER_VALUE_MONTH"));
		dto.setMaxAfterValueHour(getLongIfExists("PERF_MAX_AFTER_VALUE_HOUR"));

		dto.setHarmStartValueKm(getLongIfExists("PERF_HARM_START_VALUE_KM"));
		dto.setHarmStartValueMonth(getLongIfExists("PERF_HARM_START_VALUE_MONTH"));
		dto.setHarmStartValueHour(getLongIfExists("PERF_HARM_START_VALUE_HOUR"));

		dto.setHarmAfterValueKm(getLongIfExists("PERF_HARM_AFTER_VALUE_KM"));
		dto.setHarmAfterValueMonth(getLongIfExists("PERF_HARM_AFTER_VALUE_MONTH"));
		dto.setHarmAfterValueHour(getLongIfExists("PERF_HARM_AFTER_VALUE_HOUR"));

		dto.setMaxGroup(getLongIfExists("PERF_MAX_GROUP"));
		dto.setHarmGroup(getLongIfExists("PERF_HARM_GROUP"));

		dto.setModifDate(dateToString(getDateIfExists("PERF_DATE_MODIF")));

		if (getLongIfExists("COND_ID") != null)
		{
			ConditionDto condition = new ConditionDto();
			condition.setIdCondition(getLongIfExists("COND_ID"));
			condition.setIdPerformance(getLongIfExists("PERF_ID"));

			if (getStringIfExists("COND_USAGE_VALUE") != null)
			{
				UsageDto usage = new UsageDto();
				usage.setValueId(getLongIfExists("COND_USAGE_VALUE"));
				usage.setValueTitle(getStringIfExists("VALUE_TITLE"));
				usage.setItemTitle(getStringIfExists("ITEM_TITLE"));

				condition.setUsage(usage);
			}

			dto.setCondition(condition);
		}
		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		dto.setByCustomer(getLongIfExists("OPE_MADE_BYCUSTOMER"));

		return dto;

	}

	/**
	 * Get the List of performances .
	 * 
	 * @param operationSeriesId filter
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPerformanceDto> getList(String operationSeriesId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("  select distinct mp_operation_performance.* , ti.message ITEM_TITLE, tv.message VALUE_TITLE, mp_operation_condition.*, ");
		query.append(" decode((select count(*) from mp_ope_perf_applicability where appli_perf_id = perf_id), 0, '', '*')  as WITH_APPLI ");
		query.append("  from mp_operation_performance, mp_operation_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv");
		query.append("  where perf_ope_ser_id=");
		query.append(operationSeriesId);
		query.append("  and mp_operation_performance.perf_id = mp_operation_condition.cond_perf_id(+) ");
		query.append("  and mp_operation_condition.cond_usage_value = v.us_value_id(+) ");
		query.append("  and v.us_item_id = i.us_item_id (+) ");
		query.append("  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) ");
		query.append("  and (ti.idlanguage =");
		query.append(formatString(language));
		query.append("   or ti.idlanguage is null) ");
		query.append("  and v.US_TITLE_ID = tv.idref_table_title(+) ");
		query.append("  and (tv.idlanguage =");
		query.append(formatString(language));
		query.append("   or tv.idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceDto> result = new ArrayList<OperationPerformanceDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of performances without language.
	 * 
	 * @param operationSeriesId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPerformanceDto> getList(String operationSeriesId) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query		 
		query.append("SELECT * FROM MP_OPERATION_PERFORMANCE WHERE PERF_OPE_SER_ID = ");
		query.append(operationSeriesId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceDto> result = new ArrayList<OperationPerformanceDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of performances modified since the last release of a project in the series.
	 * 
	 * @param operationSeriesId filter
	 * @param language for translated texts
	 * @parm selectedSeriesIceCode ice code of the series
	 * @return the list of performances
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public List<OperationPerformanceDto> getListModifiedPerf(String operationSeriesId, String language, String selectedSeriesIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		String appli[] = selectedSeriesIceCode.split("[.]", 4);

		// Create the query		 
		query.append("  select distinct mp_operation_performance.* , ti.message ITEM_TITLE, tv.message VALUE_TITLE, mp_operation_condition.*, ");
		query.append("  decode((select count(*) from mp_ope_perf_applicability where appli_perf_id = perf_id), 0, '', '*')  as WITH_APPLI ");
		query.append("  from mp_operation_performance, mp_operation_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv");
		query.append("  where perf_ope_ser_id=");
		query.append(operationSeriesId);
		query.append("  and PERF_DATE_MODIF >= (SELECT MAX(MP_DATE_MODIF) from MP_MAINTENANCE_PROJECT, mp_project_applicability where ");
		query.append("  mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id and MP_STATUS=1 ");
		query.append("  and mp_app_bra = ");
		query.append(formatString(appli[0]));
		query.append("  and mp_app_typ = ");
		query.append(formatString(appli[1]));
		query.append("  and mp_app_pro = ");
		query.append(formatString(appli[2]));
		query.append("  and mp_app_ser = ");
		query.append(formatString(appli[3]));
		query.append(")");
		query.append("  and mp_operation_performance.perf_id = mp_operation_condition.cond_perf_id(+) ");
		query.append("  and mp_operation_condition.cond_usage_value = v.us_value_id(+) ");
		query.append("  and v.us_item_id = i.us_item_id (+) ");
		query.append("  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) ");
		query.append("  and (ti.idlanguage =");
		query.append(formatString(language));
		query.append("   or ti.idlanguage is null) ");
		query.append("  and v.US_TITLE_ID = tv.idref_table_title(+) ");
		query.append("  and (tv.idlanguage =");
		query.append(formatString(language));
		query.append("   or tv.idlanguage is null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceDto> result = new ArrayList<OperationPerformanceDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceDto) dto);
		}

		return result;
	}

	/**
	 * delete performance for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_performance where PERF_OPE_SER_ID = ");
		query.append(idSeriesOperation);

		executeQueryI("mp_operation_performance", query.toString());
	}

	/**
	 * delete performance for a given id.
	 * 
	 * @param idPerformance to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String idPerformance) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from mp_operation_performance where PERF_ID = ");
		query.append(idPerformance);

		executeQueryI("mp_operation_performance", query.toString());
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @return created id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long add(OperationPerformanceDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		Long id = null;
		String currentDate = dto.getModifDate();
		if (currentDate == null)
		{
			currentDate = Util.getNowDate(true);
			//			Calendar l_currentDate = Calendar.getInstance();
			//			l_currentDate.setTimeInMillis(System.currentTimeMillis());
			//			currentDate = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);
		}

		if (dto.getIdPerformance() == null)
		{
			id = getNextId();
			query.append(
					"INSERT INTO mp_operation_performance ( PERF_ID, PERF_OPE_SER_ID, PERF_NAME, PERF_MAX_START_VALUE_KM, PERF_MAX_START_VALUE_MONTH, PERF_MAX_START_VALUE_HOUR, PERF_MAX_AFTER_VALUE_KM, PERF_MAX_AFTER_VALUE_MONTH, PERF_MAX_AFTER_VALUE_HOUR, PERF_MAX_GROUP, PERF_HARM_START_VALUE_KM, PERF_HARM_START_VALUE_MONTH, PERF_HARM_START_VALUE_HOUR, PERF_HARM_AFTER_VALUE_KM, PERF_HARM_AFTER_VALUE_MONTH, PERF_HARM_AFTER_VALUE_HOUR, PERF_HARM_GROUP, PERF_DATE_MODIF, OPE_MADE_BYCUSTOMER) values (");
			query.append(id.toString());
			query.append(",");
			query.append(dto.getIdOperationSeries().toString());
			query.append(",");
			query.append(formatString(dto.getPerformanceLabel()));
			query.append(",");
			query.append(dto.getMaxStartValueKm());
			query.append(",");
			query.append(dto.getMaxStartValueMonth());
			query.append(",");
			query.append(dto.getMaxStartValueHour());
			query.append(",");
			query.append(dto.getMaxAfterValueKm());
			query.append(",");
			query.append(dto.getMaxAfterValueMonth());
			query.append(",");
			query.append(dto.getMaxAfterValueHour());
			query.append(",");
			query.append(dto.getMaxGroup());
			query.append(",");
			query.append(dto.getHarmStartValueKm());
			query.append(",");
			query.append(dto.getHarmStartValueMonth());
			query.append(",");
			query.append(dto.getHarmStartValueHour());
			query.append(",");
			query.append(dto.getHarmAfterValueKm());
			query.append(",");
			query.append(dto.getHarmAfterValueMonth());
			query.append(",");
			query.append(dto.getHarmAfterValueHour());
			query.append(",");
			query.append(dto.getHarmGroup());
			query.append(",");
			query.append(" TO_DATE (" + formatString(currentDate) + ", " + formatString(date_format) + ") ");
			query.append(",");
			query.append(dto.getByCustomer());
			query.append(")");

			executeQueryI("mp_operation_performance", query.toString());
		}

		return id;
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_PERFORMANCE.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(OperationPerformanceDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		Calendar l_currentDate = Calendar.getInstance();
		l_currentDate.setTimeInMillis(System.currentTimeMillis());

		String currentDate = Util.getNowDate(true);

		if (dto.getIdPerformance() != null)
		{
			query.append("update mp_operation_performance set");
			query.append(" PERF_NAME = ");
			query.append(formatString(dto.getPerformanceLabel()));
			query.append(", PERF_MAX_START_VALUE_KM = ");
			query.append(formatString(dto.getMaxStartValueKm()));
			query.append(", PERF_MAX_START_VALUE_MONTH = ");
			query.append(formatString(dto.getMaxStartValueMonth()));
			query.append(", PERF_MAX_START_VALUE_HOUR = ");
			query.append(formatString(dto.getMaxStartValueHour()));

			query.append(", PERF_MAX_AFTER_VALUE_KM = ");
			query.append(formatString(dto.getMaxAfterValueKm()));
			query.append(", PERF_MAX_AFTER_VALUE_MONTH = ");
			query.append(formatString(dto.getMaxAfterValueMonth()));
			query.append(", PERF_MAX_AFTER_VALUE_HOUR = ");
			query.append(formatString(dto.getMaxAfterValueHour()));
			query.append(", PERF_MAX_GROUP = ");
			query.append(formatString(dto.getMaxGroup()));

			query.append(", PERF_HARM_START_VALUE_KM = ");
			query.append(formatString(dto.getHarmStartValueKm()));
			query.append(", PERF_HARM_START_VALUE_MONTH = ");
			query.append(formatString(dto.getHarmStartValueMonth()));
			query.append(", PERF_HARM_START_VALUE_HOUR = ");
			query.append(formatString(dto.getHarmStartValueHour()));
			query.append(", PERF_HARM_GROUP = ");
			query.append(formatString(dto.getHarmGroup()));

			query.append(", PERF_HARM_AFTER_VALUE_KM = ");
			query.append(formatString(dto.getHarmAfterValueKm()));
			query.append(", PERF_HARM_AFTER_VALUE_MONTH = ");
			query.append(formatString(dto.getHarmAfterValueMonth()));
			query.append(", PERF_HARM_AFTER_VALUE_HOUR = ");
			query.append(formatString(dto.getHarmAfterValueHour()));

			query.append(", PERF_DATE_MODIF = ");
			query.append(" TO_DATE (" + formatString(currentDate) + ", " + formatString(date_format) + ") ");

			query.append(", OPE_MADE_BYCUSTOMER = ");
			query.append(dto.getByCustomer());

			query.append(" WHERE PERF_ID = ");
			query.append(dto.getIdPerformance().toString());

			executeQueryI("mp_operation_performance", query.toString());
		}
	}

	/**
	 * update MP_OPERATION_PERFORMANCE OPE_MADE_BYCUSTOMER.
	 * 
	 * @param dto to update
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updatePerfByCustomer(OperationPerformanceDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		if (dto.getIdPerformance() != null)
		{
			query.append("update mp_operation_performance set");
			query.append(" OPE_MADE_BYCUSTOMER = ");
			query.append(dto.getByCustomer().toString());
			query.append(" WHERE PERF_ID = ");
			query.append(dto.getIdPerformance().toString());

			executeQueryI("mp_operation_performance", query.toString());
		}
	}

	/**
	 * update performance name.
	 * 
	 * @param dto to update
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updatePerfName(OperationPerformanceDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		if (dto.getIdPerformance() != null)
		{
			query.append("update mp_operation_performance set");
			query.append(" PERF_NAME = ");
			query.append(formatString(dto.getPerformanceLabel()));
			query.append(", OPE_MADE_BYCUSTOMER = ");
			query.append(dto.getByCustomer());
			query.append(" WHERE PERF_ID = ");
			query.append(dto.getIdPerformance().toString());

			executeQueryI("mp_operation_performance", query.toString());
		}
	}

	/**
	 * update modification date.
	 * 
	 * @param performanceId to update
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updateModificationDate(Long performanceId) throws SystemException {

		StringBuilder query = new StringBuilder();

		String currentDate = Util.getNowDate(true);
		{
			query.append("update mp_operation_performance set");
			query.append(" PERF_DATE_MODIF = ");
			query.append(" TO_DATE (" + formatString(currentDate) + ", " + formatString(date_format) + ") ");

			query.append(" WHERE PERF_ID = ");
			query.append(performanceId);

			executeQueryI("mp_operation_performance", query.toString());
		}
	}

	/**
	 * check if the performance already exists.
	 * 
	 * @param dto to check
	 * @return if exists
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long existPerformance(OperationPerformanceDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("select count(*) as NB from mp_operation_performance where");
		if (dto.getMaxStartValueKm() == null)
		{
			query.append(" PERF_MAX_START_VALUE_KM is null ");
		}
		else
		{
			query.append(" PERF_MAX_START_VALUE_KM = ");
			query.append(formatString(dto.getMaxStartValueKm()));
		}
		if (dto.getMaxStartValueMonth() == null)
		{
			query.append(" AND PERF_MAX_START_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_START_VALUE_MONTH = ");
			query.append(formatString(dto.getMaxStartValueMonth()));
		}
		if (dto.getMaxStartValueHour() == null)
		{
			query.append(" AND PERF_MAX_START_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_START_VALUE_HOUR = ");
			query.append(formatString(dto.getMaxStartValueHour()));
		}
		if (dto.getMaxAfterValueKm() == null)
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_KM is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_KM = ");
			query.append(formatString(dto.getMaxAfterValueKm()));
		}
		if (dto.getMaxAfterValueMonth() == null)
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_MONTH = ");
			query.append(formatString(dto.getMaxAfterValueMonth()));

		}
		if (dto.getMaxAfterValueHour() == null)
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_AFTER_VALUE_HOUR = ");
			query.append(formatString(dto.getMaxAfterValueHour()));
		}
		if (dto.getMaxGroup() == null)
		{
			query.append(" AND PERF_MAX_GROUP is null ");
		}
		else
		{
			query.append(" AND PERF_MAX_GROUP = ");
			query.append(formatString(dto.getMaxGroup()));
		}
		if (dto.getHarmStartValueKm() == null)
		{
			query.append(" AND PERF_HARM_START_VALUE_KM is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_START_VALUE_KM = ");
			query.append(formatString(dto.getHarmStartValueKm()));
		}
		if (dto.getHarmStartValueMonth() == null)
		{
			query.append(" AND PERF_HARM_START_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_START_VALUE_MONTH = ");
			query.append(formatString(dto.getHarmStartValueMonth()));
		}
		if (dto.getHarmStartValueHour() == null)
		{
			query.append(" AND PERF_HARM_START_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_START_VALUE_HOUR = ");
			query.append(formatString(dto.getHarmStartValueHour()));
		}
		if (dto.getHarmGroup() == null)
		{
			query.append(" AND PERF_HARM_GROUP is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_GROUP = ");
			query.append(formatString(dto.getHarmGroup()));
		}
		if (dto.getHarmAfterValueKm() == null)
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_KM is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_KM = ");
			query.append(formatString(dto.getHarmAfterValueKm()));
		}
		if (dto.getHarmAfterValueMonth() == null)
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_MONTH is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_MONTH = ");
			query.append(formatString(dto.getHarmAfterValueMonth()));
		}
		if (dto.getHarmAfterValueHour() == null)
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_HOUR is null ");
		}
		else
		{
			query.append(" AND PERF_HARM_AFTER_VALUE_HOUR = ");
			query.append(formatString(dto.getHarmAfterValueHour()));
		}

		query.append(" AND PERF_ID = ");
		query.append(dto.getIdPerformance().toString());

		return executeQueryCount(query.toString(), "NB");

	}

	/**
	 * Get the List of performances with the operation code.
	 * 
	 * @param listPerf list of performance to retrieve the operation code/label
	 * @return the list of performance
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationPerformanceDto> getListPerformance(List<Long> listPerf) throws SystemException {

		StringBuilder query = new StringBuilder();
		int index = 0;
		// Create the query		 
		query.append("SELECT PERF_NAME, DECODE(OPE_CODE,null,OPE_SRT,OPE_CODE) as OPE_CODE ");
		query.append(" FROM MP_OPERATION, MP_OPERATION_SERIES, MP_OPERATION_PERFORMANCE ");
		query.append(" WHERE PERF_OPE_SER_ID=OPE_SER_ID AND OPE_OPERATION_ID=OPE_ID AND PERF_ID in (  ");
		for (Long id : listPerf)
		{
			query.append(id);
			if (index < listPerf.size() - 1)
			{
				query.append(",");
			}
			index++;
		}
		query.append(" ) ORDER BY OPE_CODE");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceDto> result = new ArrayList<OperationPerformanceDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceDto) dto);
		}

		return result;
	}

	/**
	 * Get a performance.
	 * 
	 * @param idPerf id of the performance to get
	 * @return the perf
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationPerformanceDto getPerformance(String idPerf) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select * from MP_OPERATION_PERFORMANCE where PERF_ID = ");
		query.append(idPerf);

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationPerformanceDto) found;
	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY HH:mm:ss");
			result = sdf.format(myDate);
			//result = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + l_currentDate.get(Calendar.YEAR);
		}

		return result;
	}

}
