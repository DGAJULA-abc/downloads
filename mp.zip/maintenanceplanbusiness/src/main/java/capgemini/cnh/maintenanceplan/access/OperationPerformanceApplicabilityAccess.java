/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceApplicabilityDto;

/**
 * @author sdomecq
 *
 */
public class OperationPerformanceApplicabilityAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationPerformanceApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationPerformanceApplicabilityDto dto = new OperationPerformanceApplicabilityDto();

		dto.setId(getLongIfExists("APPLI_ID"));
		dto.setIdPerformance(getLongIfExists("APPLI_PERF_ID"));

		dto.setModel(getStringIfExists("APPLI_MOD"));
		dto.setTt(getStringIfExists("APPLI_TT"));
		dto.setMarket(getLongIfExists("APPLI_MARKET"));
		dto.setConfig(getStringIfExists("APPLI_CONFIG"));
		dto.setConfigItem(getIntIfExists("APPLI_CONFIG_ITEM"));

		dto.setModelPlan(getStringIfExists("APPLI_MOD_PLAN"));
		dto.setTtPlan(getStringIfExists("APPLI_TT_PLAN"));
		dto.setMarketPlan(getLongIfExists("APPLI_MARKET_PLAN"));
		dto.setConfigPlan(getStringIfExists("APPLI_CONFIG_PLAN"));
		dto.setConfigItemPlan(getIntIfExists("APPLI_CONFIG_ITEM_PLAN"));

		return dto;

	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationPerformanceApplicabilityDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO MP_OPE_PERF_APPLICABILITY (  APPLI_PERF_ID, APPLI_MOD, APPLI_TT, APPLI_MARKET, APPLI_CONFIG) values (");
		query.append(dto.getIdPerformance());
		query.append(",");
		query.append(formatString(dto.getModel()));
		query.append(",");
		query.append(formatString(dto.getTt()));
		query.append(",");
		query.append(dto.getMarket());
		query.append(",");
		query.append(formatString(dto.getConfig()));
		query.append(")");

		executeQueryI("MP_OPE_PERF_APPLICABILITY", query.toString());
	}

	/**
	 * check if app exits.
	 * 
	 * @param dto to check
	 * @return true if app exits
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long existPerfApplicability(OperationPerformanceApplicabilityDto dto) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT COUNT(*) AS NB FROM MP_OPE_PERF_APPLICABILITY WHERE APPLI_PERF_ID =");
		query.append(dto.getIdPerformance());
		if (dto.getModel() == null)
		{
			query.append(" AND APPLI_MOD is null ");
		}
		else
		{
			query.append(" AND APPLI_MOD = ");
			query.append(formatString(dto.getModel()));
		}
		if (dto.getTt() == null)
		{
			query.append(" AND APPLI_TT is null ");

		}
		else
		{
			query.append(" AND APPLI_TT = ");
			query.append(formatString(dto.getTt()));

		}
		if (dto.getMarket() == null)
		{
			query.append(" AND APPLI_MARKET is null ");
		}
		else
		{
			query.append(" AND APPLI_MARKET = ");
			query.append(dto.getMarket());
		}
		if (dto.getConfig() == null)
		{
			query.append(" AND APPLI_CONFIG is null ");
		}
		else
		{
			query.append(" AND APPLI_CONFIG = ");
			query.append(formatString(dto.getConfig()));
		}

		return executeQueryCount(query.toString(), "NB");

	}

	/**
	 * delete for a given performance.
	 * 
	 * @param idPerformance to filter
	 * @return nb Element deleted
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long deleteByPerf(String idPerformance) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_OPE_PERF_APPLICABILITY where APPLI_PERF_ID = ");
		query.append(idPerformance);

		return executeQueryI("MP_OPE_PERF_APPLICABILITY", query.toString());
	}

	/**
	 * delete for a given series.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteBySeries(String operationSeriesId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete MP_OPE_PERF_APPLICABILITY  WHERE APPLI_PERF_ID  in (select perf_id from mp_operation_performance where perf_ope_ser_id = ");
		query.append(operationSeriesId);
		query.append(")");

		executeQueryI("mp_operation_condition", query.toString());

	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idPerformance to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListApplicabilityByPerf(String idPerformance) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_ope_perf_applicability where appli_perf_id= ");
		query.append(idPerformance);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceApplicabilityDto> result = new ArrayList<OperationPerformanceApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idPerformance to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListApplicabilityByPerfExport(String idPerformance) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append("  select  * from mp_ope_perf_applic_migrate where appli_perf_id= ");
		query.append(idPerformance);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceApplicabilityDto> result = new ArrayList<OperationPerformanceApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of performances applicable (but not at configuration level) .
	 * 
	 * @param idPlan to filter
	 * @param perfsList : List of perfs to check
	 * @param perfType harm or max
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListPerformanceApplicableToPlan(String idPlan, String perfsList, String perfType) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append(" select distinct PERF_ID AS APPLI_PERF_ID,  ");
		query.append(" Appli_Mod, Appli_Tt, Appli_Market,Appli_Config, ");
		query.append(" Plan_Mod as APPLI_MOD_PLAN, Plan_Tt as APPLI_TT_PLAN, Plan_Market as APPLI_MARKET_PLAN, plan_Config as APPLI_CONFIG_PLAN ");
		query.append(
				" from mp_maintenance_plan p1, mp_operation_series , mp_operation_performance p2, mp_maintenance_condition c1, mp_operation_condition c2, mp_plan_applicability a1, mp_ope_perf_applicability a2 ");
		query.append(" where p1.PLAN_ID= ");
		query.append(idPlan);
		query.append(" and ope_mp_id = p1.plan_project_id ");
		query.append(" and OPE_SER_ID = PERF_OPE_SER_ID");
		query.append(" and cond_plan_id(+) = p1.plan_id and cond_perf_id(+) = p2.perf_id ");
		query.append(" and (c1.cond_usage_value = c2.cond_usage_value or c1.cond_usage_value  is null or c2.cond_usage_value is null) ");
		query.append(" and a1.plan_id(+) = p1.plan_id and a2.appli_perf_id(+) = p2.perf_id ");
		query.append(" and (a1.plan_mod = a2.appli_mod or a1.plan_mod is null or a2.appli_mod is null) ");
		query.append(" and (a1.plan_tt = a2.appli_tt or a1.plan_tt is null or a2.appli_tt is null) ");
		query.append(" and (a1.plan_market = a2.appli_market or a1.plan_market is null or a2.appli_market is null) ");
		query.append(" and (PERF_" + perfType + "_START_VALUE_KM is not null or  PERF_" + perfType + "_START_VALUE_MONTH is not null or  PERF_" + perfType + "_START_VALUE_HOUR is not null or ");
		query.append(" PERF_" + perfType + "_AFTER_VALUE_KM is not null  or PERF_" + perfType + "_AFTER_VALUE_MONTH is not null or  PERF_" + perfType
				+ "_AFTER_VALUE_HOUR is not null) ");
		if (!perfsList.equals(""))
		{
			query.append(" and p2.perf_id in (");
			query.append(perfsList);
			query.append(")");
		}
		query.append("  order by 1, 2, 3, 4, 5, 6, 7, 8, 9");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceApplicabilityDto> result = new ArrayList<OperationPerformanceApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceApplicabilityDto) dto);
		}

		return result;

	}

	/**
	 * Get the List of performance applicable (but not at configuration level) .
	 * 
	 * @param planId to filter
	 * @return the list of applicability
	 * @param idPerf : max or harm
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListPerformanceApplicableWithoutConfig(String planId, String idPerf) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();

		query.append(" select distinct PERF_ID AS APPLI_PERF_ID,  ");
		query.append(" Appli_Mod, Appli_Tt, Appli_Market,Appli_Config, ");
		query.append(" Plan_Mod as APPLI_MOD_PLAN, Plan_Tt as APPLI_TT_PLAN, Plan_Market as APPLI_MARKET_PLAN, plan_Config as APPLI_CONFIG_PLAN ");
		query.append(
				" from mp_maintenance_plan p1, mp_operation_series , mp_operation_performance p2, mp_maintenance_condition c1, mp_operation_condition c2, mp_plan_applicability a1, mp_ope_perf_applicability a2 ");
		query.append(" where p1.PLAN_ID= ");
		query.append(planId);
		query.append(" and ope_mp_id=p1.plan_project_id ");
		query.append(" and OPE_SER_ID = PERF_OPE_SER_ID");
		query.append(" and cond_plan_id(+) = p1.plan_id and cond_perf_id(+) = p2.perf_id ");
		query.append(" and (c1.cond_usage_value = c2.cond_usage_value or c1.cond_usage_value  is null or c2.cond_usage_value is null) ");
		query.append(" and a1.plan_id(+) = p1.plan_id and a2.appli_perf_id(+) = p2.perf_id ");
		query.append(" and (a1.plan_mod = a2.appli_mod or a1.plan_mod is null or a2.appli_mod is null) ");
		query.append(" and (a1.plan_tt = a2.appli_tt or a1.plan_tt is null or a2.appli_tt is null) ");
		query.append(" and (a1.plan_market = a2.appli_market or a1.plan_market is null or a2.appli_market is null) ");
		query.append(" and (PERF_" + idPerf + "_START_VALUE_KM is not null or  PERF_" + idPerf + "_START_VALUE_MONTH is not null or  PERF_" + idPerf + "_START_VALUE_HOUR is not null or ");
		query.append(" PERF_" + idPerf + "_AFTER_VALUE_KM is not null  or PERF_" + idPerf + "_AFTER_VALUE_MONTH is not null or  PERF_" + idPerf
				+ "_AFTER_VALUE_HOUR is not null) ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationPerformanceApplicabilityDto> result = new ArrayList<OperationPerformanceApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationPerformanceApplicabilityDto) dto);
		}

		return result;

	}

}
