/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.cnhadmin.CnhAdminContext;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesDto;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationSeriesAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationSeriesDto dto = new OperationSeriesDto();

		ProjectDto dtoProject = new ProjectDto();
		dtoProject.setModifDate(dateToString(getDateIfExists("MP_DATE_MODIF")));
		dtoProject.setId(getLongIfExists("MP_ID"));
		dtoProject.setName(getStringIfExists("MP_NAME"));
		dtoProject.setVersion(getIntIfExists("MP_VERSION"));
		dtoProject.setNumber(getStringIfExists("MP_NUMBER"));

		dto.setId(getLongIfExists("OPE_SER_ID"));

		dto.setIdOperation(getLongIfExists("OPE_OPERATION_ID"));

		dto.setIdOperationLinkInt(getLongIfExists("OPE_SER_ID_LK_INT"));

		// operation detail
		OperationDto operation = new OperationDto();
		operation.setId(getLongIfExists("OPE_OPERATION_ID"));
		operation.setCodeMicroOperation(getStringIfExists("ope_code"));
		operation.setCodeSrt(getStringIfExists("ope_srt"));

		operation.setTitle(getStringIfExists("OPE_TITLE"));
		operation.setTitleId(getLongIfExists("OPE_TITLE_ID"));
		operation.setDescription(getStringIfExists("OPE_DESCRIPTION"));
		operation.setDescriptionId(getLongIfExists("OPE_DESCRIPTION_TITLE_ID"));

		operation.setLocationFamilyIceCode(getStringIfExists("OPE_LOC_FAM"));
		operation.setLocationGroupIceCode(getStringIfExists("OPE_LOC_GRO"));
		operation.setLocationSubGroupIceCode(getStringIfExists("OPE_LOC_SUG"));

		operation.setInfotypeTopicIceCode(getStringIfExists("OPE_INF_TOP"));
		operation.setInfotypeSubTopicIceCode(getStringIfExists("OPE_INF_SUT"));
		operation.setInfotypeCategoryIceCode(getStringIfExists("OPE_INF_CAT"));
		operation.setInfotypeInfotypeIceCode(getStringIfExists("OPE_INF_INF"));

		dto.setOperation(operation);

		dto.setProject(dtoProject);

		dto.setApplicabilityBrandIceCode(getStringIfExists("OPE_APP_BRA"));
		dto.setApplicabilityTypeIceCode(getStringIfExists("OPE_APP_TYP"));
		dto.setApplicabilityProductIceCode(getStringIfExists("OPE_APP_PRO"));
		dto.setApplicabilitySeriesIceCode(getStringIfExists("OPE_APP_SER"));
		dto.setApplicabilitySeriesId(getStringIfExists("A_ID"));
		dto.setApplicabilityLabel(getStringIfExists("OPE_SER_LABEL"));

		dto.setRepairTime(getIntIfExists("OPE_REPAIR_TIME"));
		if (getBooleanIfExists("OPE_MADE_BYCUSTOMER") != null)
		{
			dto.setByCustomer(getLongIfExists("OPE_MADE_BYCUSTOMER"));
		}

		dto.setWithConsumable(getStringIfExists("WITH_CONS"));
		dto.setWithParts(getStringIfExists("WITH_PARTS"));
		dto.setWithPerf(getStringIfExists("WITH_PERF"));
		dto.setWithIus(getStringIfExists("WITH_IU"));
		dto.setLabelId(getLongIfExists("OPE_LABEL"));

		return dto;

	}

	/**
	 * Get the List of operation .
	 * 
	 * @param language for translated texts
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getList(String language, String brand, String type, String product, String series) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		SELECT MP_OPERATION_SERIES.*, SERIE.A_ID, serie.a_name OPE_SER_LABEL, mp_operation.*, t1.message OPE_TITLE , t2.message OPE_DESCRIPTION,
		//	     decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_CONS,
		//	     decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_PARTS,
		//	     decode((select count(*) from mp_operation_performance where perf_ope_ser_id = OPE_SER_ID), 0, '', '*')  as WITH_PERF
		//		FROM  MP_OPERATION_SERIES,BRAND, TYPE, PRODUCT, SERIE, mp_operation, table_title t1, table_title t2
		//		 WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID  
		//		 and OPE_OPERATION_ID = OPE_ID
		//		 and ope_Title_ID=t1.id_title  and t1.idlanguage= 'IT'
		//		 and ope_description_title_id = t2.id_title(+) and (t2.idlanguage= 'IT'  or t2.idlanguage is null)
		//		 AND (BRAND.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_BRA 
		//		 AND TYPE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_TYP
		//		 AND PRODUCT.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_PRO
		//		 AND SERIE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_SER )

		query.append(" SELECT MP_OPERATION_SERIES.*, SERIE.A_ID, serie.a_name OPE_SER_LABEL, mp_operation.*, t1.message OPE_TITLE , t2.message OPE_DESCRIPTION, ");

		query.append(" decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_CONS, ");
		query.append(" decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_PARTS, ");
		query.append(" decode((select count(*) from mp_operation_performance where perf_ope_ser_id = OPE_SER_ID), 0, '', '*')  as WITH_PERF, ");
		query.append(" decode((select count(*) from MP_OPERATION_IULINK where IU_OPE_SER_ID = OPE_SER_ID), 0, '', '*')  as WITH_IU ");
		query.append(" FROM  MP_OPERATION_SERIES,BRAND, TYPE, PRODUCT, SERIE, mp_operation, table_title t1, table_title t2 ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" and OPE_OPERATION_ID = OPE_ID  ");
		query.append(" and ope_Title_ID=t1.idref_table_title  and t1.idlanguage= ");
		query.append(formatString(language));
		query.append("   and ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage=  ");
		query.append(formatString(language));
		query.append("   or t2.idlanguage is null)");
		query.append(" AND (BRAND.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_BRA  ");
		query.append("     AND TYPE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_TYP ");
		query.append("     AND PRODUCT.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_PRO");
		query.append("     AND SERIE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_SER )");
		query.append(" and OPE_APP_BRA =  ");
		query.append(formatString(brand));
		query.append(" and OPE_APP_TYP =  ");
		query.append(formatString(type));
		query.append(" and OPE_APP_PRO =  ");
		query.append(formatString(product));
		query.append(" and OPE_APP_SER =  ");
		query.append(formatString(series));
		query.append(" and OPE_MP_ID is null ");
		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	//TODO CR103
	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @param projectId : Id of the selected project
	 *
	 * @return the list of operations
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getOpListForProject(String language, String projectId) throws SystemException, ApplicativeException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT MP_OPERATION_SERIES.*, MP_MAINTENANCE_PROJECT.*, SERIE.A_ID, serie.a_name OPE_SER_LABEL, mp_operation.*, t1.message OPE_TITLE , t2.message OPE_DESCRIPTION, ");
		query.append(" decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_CONS, ");
		query.append(" decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, '', '*')  as WITH_PARTS, ");
		query.append(" decode((select count(*) from mp_operation_performance where perf_ope_ser_id = OPE_SER_ID), 0, '', '*')  as WITH_PERF, ");
		query.append(" decode((select count(*) from MP_OPERATION_IULINK where IU_OPE_SER_ID = OPE_SER_ID), 0, '', '*')  as WITH_IU ");
		query.append(" FROM  MP_OPERATION_SERIES,BRAND, MP_MAINTENANCE_PROJECT, TYPE, PRODUCT, SERIE, mp_operation, table_title t1, table_title t2 ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" and MP_ID = OPE_MP_ID ");
		query.append(" and OPE_OPERATION_ID = OPE_ID  ");
		query.append(" and ope_Title_ID=t1.idref_table_title  and t1.idlanguage= ");
		query.append(formatString(language));
		query.append("   and ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage=  ");
		query.append(formatString(language));
		query.append("   or t2.idlanguage is null)");
		query.append(" AND (BRAND.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_BRA  ");
		query.append("     AND TYPE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_TYP ");
		query.append("     AND PRODUCT.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_PRO");
		query.append("     AND SERIE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_SER )");
		query.append(" and OPE_MP_ID  = ");
		query.append(formatString(projectId));
		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(OperationSeriesDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			dto.setId(getNextId());
			query.append(
					"INSERT INTO MP_OPERATION_SERIES (OPE_SER_ID,  OPE_OPERATION_ID, OPE_APP_BRA, OPE_APP_TYP, OPE_APP_PRO, OPE_APP_SER, OPE_REPAIR_TIME, OPE_MADE_BYCUSTOMER, OPE_MP_ID, OPE_LABEL) values (");
			query.append(dto.getId().toString());
			query.append(",");
			query.append(dto.getIdOperation().toString());
			query.append(",");
			query.append(formatString(dto.getApplicabilityBrandIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilityTypeIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilityProductIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilitySeriesIceCode()));
			query.append(",");
			query.append(dto.getRepairTime());
			query.append(",");
			if (!CnhAdminContext.isIvecoCustomer())
			{
				query.append(new Long(2));
			}
			else
			{
				query.append(dto.getByCustomer());
			}

			query.append(",");
			query.append(dto.getMPId());
			query.append(",");
			query.append(dto.getLabelId());
			query.append(")");

			executeQueryI(query.toString());
		}

	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(OperationSeriesDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			query.append("update MP_OPERATION_SERIES set");
			query.append(" OPE_REPAIR_TIME = ");
			query.append(dto.getRepairTime());

			query.append(", OPE_MADE_BYCUSTOMER = ");
			query.append(dto.getByCustomer());
			query.append(", OPE_LABEL = ");
			query.append(dto.getLabelId());

			query.append(" WHERE OPE_SER_ID = ");
			query.append(dto.getId().toString());

			executeQueryI("MP_OPERATION_SERIES", query.toString());
		}

	}

	/**
	 * delete operation.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String operationSeriesId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_OPERATION_SERIES  WHERE OPE_SER_ID = ");
		query.append(operationSeriesId);

		executeQueryI("MP_OPERATION_SERIES", query.toString());
	}

	/**
	 * Get the List of series associated to an operation.
	 * 
	 * @param idOperation to filter
	 * @return the list of associated series
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOfSeries(String idOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append(" select distinct mp_operation_series.ope_ser_id, serie.a_name ope_ser_label ");
		query.append(" from mp_operation_series, BRAND, TYPE, PRODUCT, SERIE ");
		query.append(" WHERE  BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  ");
		query.append(" AND TYPE.A_ID = SERIE.TYP_A_ID  and (BRAND.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_BRA  ");
		query.append("     AND TYPE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_TYP ");
		query.append("     AND PRODUCT.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_PRO");
		query.append("     AND SERIE.A_ICE_CODE = MP_OPERATION_SERIES.OPE_APP_SER )");
		query.append(" and ope_operation_id = ");
		query.append(idOperation);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operations in a series.
	 * 
	 * @param dto OperationSeriesDto
	 * @param idLang id of the language
	 * @return the list of associated series
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOfSeriesForOneOp(OperationSeriesDto dto, String idLang) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append(" select distinct opeser.*, ope.*, t1.message OPE_TITLE");
		query.append(" from mp_operation_series opeser, mp_operation ope, table_title t1");
		query.append(" WHERE ope_operation_id = ");
		query.append(dto.getIdOperation());
		query.append(" AND OPE_APP_BRA = ");
		query.append(formatString(dto.getApplicabilityBrandIceCode()));
		query.append(" AND OPE_APP_TYP = ");
		query.append(formatString(dto.getApplicabilityTypeIceCode()));
		query.append(" AND OPE_APP_PRO = ");
		query.append(formatString(dto.getApplicabilityProductIceCode()));
		query.append(" AND OPE_APP_SER = ");
		query.append(formatString(dto.getApplicabilitySeriesIceCode()));
		query.append(" AND ope.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(idLang));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dtoOp : lstFound)
		{
			result.add((OperationSeriesDto) dtoOp);
		}

		return result;
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_OPERATION_SERIES.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * Get one association operation/series.
	 * 
	 * @param idSeriesOperation to get
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationSeriesDto get(String idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select * from mp_operation_series where ope_ser_id = ");
		query.append(idSeriesOperation);

		// Execute the query and get the result list
		Dto found = executeQuery1(query.toString());

		return (OperationSeriesDto) found;
	}

	/**
	 * Get the list of operations by plan.
	 * 
	 * @param isPlan Plan id
	 * @return the list of Operations by Series for the plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByPlan(Long planId) throws SystemException, ApplicativeException {

		/*
		 Query:
		 Select distinct OPE_SER_ID,OPE_OPERATION_ID,OPE_APP_BRA,OPE_APP_TYP,OPE_APP_PRO,OPE_APP_SER,OPE_REPAIR_TIME,OPE_MADE_BYCUSTOMER,OPE_MP_ID 
		 from mp_maintenance_plan plan, mp_interval inter, mp_interval_operation intope, mp_operation_series opeser, mp_operation ope
		 where plan.plan_id = 44470
		 and inter.int_plan_id = plan.plan_id 
		 and intope.def_interval_id = inter.int_id 
		 and intope.def_ope_series_id = opeser.ope_ser_id 
		 and opeser.ope_operation_id = ope.ope_id
		 
		 */

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" Select distinct OPE_SER_ID,OPE_OPERATION_ID,OPE_APP_BRA,OPE_APP_TYP,OPE_APP_PRO,OPE_APP_SER,OPE_REPAIR_TIME,OPE_MADE_BYCUSTOMER,OPE_MP_ID, OPE_CODE, OPE_SRT ");
		query.append(" from mp_maintenance_plan plan, mp_interval inter, mp_interval_operation intope, mp_operation_series opeser, mp_operation ope ");
		query.append(" where plan.plan_id =  ");
		query.append(planId);
		query.append(" and inter.int_plan_id = plan.plan_id  ");
		query.append("  and intope.def_interval_id = inter.int_id  ");
		query.append("  and intope.def_ope_series_id = opeser.ope_ser_id ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProjectExcelExport(String idProject, String language) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct opeser.*, ope.*, t1.message OPE_TITLE, t2.message OPE_DESCRIPTION, ");
		query.append(" decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_CONS, ");
		query.append(" decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_PARTS, ");
		query.append(" decode((select count(*) from mp_operation_performance where perf_ope_ser_id = OPE_SER_ID), 0, ' ', '*')  as WITH_PERF ");
		query.append(" FROM  mp_maintenance_project proj, mp_maintenance_plan plan, mp_interval inter, ");
		query.append(" mp_interval_operation intope, mp_operation_series opeser, mp_operation ope, table_title t1, table_title t2 ");
		query.append(" WHERE proj.MP_ID = ");
		query.append(formatString(idProject));
		query.append(" AND ope.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" AND ope.ope_description_title_id = t2.idref_table_title(+) and (t2.idlanguage= ");
		query.append(formatString(language));
		query.append("  or t2.idlanguage is null) ");
		query.append(" and plan.plan_project_id = proj.mp_id ");
		query.append(" and inter.int_plan_id = plan.plan_id ");
		query.append(" and intope.def_interval_id = inter.int_id ");
		query.append(" and intope.def_ope_series_id = opeser.ope_ser_id ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Get the list of operations by project.
	 * 
	 * @param dto : ProjectDto
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(ProjectDto dto) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("SELECT OPE_SER_ID, OPE_OPERATION_ID, OPE_APP_BRA, OPE_APP_TYP, OPE_APP_PRO, ");
		query.append("OPE_APP_SER, OPE_REPAIR_TIME, OPE_MADE_BYCUSTOMER FROM MP_OPERATION_SERIES MPOS, ");
		query.append("MP_PROJECT_APPLICABILITY MPPA WHERE ");
		query.append(dto.getId().toString());
		query.append("=MPPA.MP_PROJECT_ID AND ");
		query.append(formatString(dto.getApplicabilityBrandIceCode()));
		query.append("=MPOS.OPE_APP_BRA AND ");
		query.append(formatString(dto.getApplicabilityTypeIceCode()));
		query.append("=MPOS.OPE_APP_TYP AND ");
		query.append(formatString(dto.getApplicabilityProductIceCode()));
		query.append("=MPOS.OPE_APP_PRO AND ");
		query.append(formatString(dto.getApplicabilitySeriesIceCode()));
		query.append("=MPOS.OPE_APP_SER");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto tempDto : lstFound)
		{
			result.add((OperationSeriesDto) tempDto);
		}

		return result;
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(Long idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(
				" SELECT distinct opeser.*, proj.mp_date_modif, ope.ope_code, ope.ope_srt, proj.MP_ID, proj.MP_NAME, ope.ope_code, ope.ope_srt, ope.ope_loc_fam, ope.ope_loc_gro, ope.ope_loc_sug ");
		query.append(" FROM  mp_maintenance_project proj, mp_maintenance_plan plan, mp_interval inter, ");
		query.append(" mp_interval_operation intope, mp_operation_series opeser, mp_operation ope");
		query.append(" WHERE proj.MP_ID = ");
		query.append(formatString(idProject));
		query.append(" and plan.plan_project_id = proj.mp_id ");
		query.append(" and inter.int_plan_id = plan.plan_id ");
		query.append(" and intope.def_interval_id = inter.int_id ");
		query.append(" and intope.def_ope_series_id = opeser.ope_ser_id ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Get the list of operations for a project linked to perf free text.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProjectLinkedToPerfFreeText(Long idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct opeser.*, proj.mp_date_modif, ope.*, proj.MP_ID, proj.MP_NAME ");
		query.append(" FROM  mp_maintenance_project proj, mp_operation_series opeser, mp_operation ope, MP_OPERATION_PERFORMANCE_TEXT perftext");
		query.append(" WHERE proj.MP_ID = ");
		query.append(formatString(idProject));
		query.append(" and opeser.ope_mp_id = proj.mp_id ");
		query.append(" and perftext.perf_ope_ser_id = opeser.ope_ser_id and opeser.OPE_OPERATION_ID = ope.OPE_ID ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Get the list of operations for a series to perf free text.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesLinkedToPerfFreeText(Long idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct opeser.*, proj.mp_date_modif, ope.*, proj.MP_ID, proj.MP_NAME ");
		query.append(" FROM  mp_maintenance_project proj, mp_operation_series opeser, mp_operation ope, MP_OPERATION_PERFORMANCE_TEXT perftext");
		query.append("  WHERE proj.MP_ID = ");
		query.append(idProject);
		query.append(" and opeser.OPE_MP_ID= proj.MP_ID ");
		query.append(" and perftext.perf_ope_ser_id = opeser.ope_ser_id ");
		query.append(" and opeser.OPE_OPERATION_ID = ope.OPE_ID");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesDto> result = new ArrayList<OperationSeriesDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesDto) dto);
		}

		return result;
	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
			result = sdf.format(myDate);
			//result = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + l_currentDate.get(Calendar.YEAR);
		}

		return result;
	}

	/**
	 * delete operation.
	 * 
	 * @param projectId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(Long projectd) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_OPERATION_SERIES  WHERE OPE_MP_ID = ");
		query.append(projectd);

		executeQueryI("MP_OPERATION_SERIES", query.toString());
	}

}
