/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.OperationDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesPartCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesPartCompareAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OperationSeriesPartCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		OperationSeriesPartCompareDto dto = new OperationSeriesPartCompareDto();

		dto.setId(getLongIfExists("OPE_SER_ID"));

		dto.setIdOperation(getLongIfExists("OPE_OPERATION_ID"));

		dto.setIdOperationLinkInt(getLongIfExists("OPE_SER_ID_LK_INT"));

		// operation detail
		OperationDto operation = new OperationDto();
		operation.setId(getLongIfExists("OPE_OPERATION_ID"));
		operation.setCodeMicroOperation(getStringIfExists("ope_code"));
		operation.setCodeSrt(getStringIfExists("ope_srt"));

		operation.setTitle(getStringIfExists("OPE_TITLE"));
		operation.setTitleId(getLongIfExists("OPE_TITLE_ID"));
		operation.setDescription(getStringIfExists("OPE_DESCRIPTION"));
		operation.setDescriptionId(getLongIfExists("OPE_DESCRIPTION_TITLE_ID"));

		operation.setLocationFamilyIceCode(getStringIfExists("OPE_LOC_FAM"));
		operation.setLocationGroupIceCode(getStringIfExists("OPE_LOC_GRO"));
		operation.setLocationSubGroupIceCode(getStringIfExists("OPE_LOC_SUG"));

		operation.setInfotypeTopicIceCode(getStringIfExists("OPE_INF_TOP"));
		operation.setInfotypeSubTopicIceCode(getStringIfExists("OPE_INF_SUT"));
		operation.setInfotypeCategoryIceCode(getStringIfExists("OPE_INF_CAT"));
		operation.setInfotypeInfotypeIceCode(getStringIfExists("OPE_INF_INF"));

		dto.setOperation(operation);

		dto.setApplicabilityBrandIceCode(getStringIfExists("OPE_APP_BRA"));
		dto.setApplicabilityTypeIceCode(getStringIfExists("OPE_APP_TYP"));
		dto.setApplicabilityProductIceCode(getStringIfExists("OPE_APP_PRO"));
		dto.setApplicabilitySeriesIceCode(getStringIfExists("OPE_APP_SER"));
		dto.setApplicabilitySeriesId(getStringIfExists("A_ID"));
		dto.setApplicabilityLabel(getStringIfExists("OPE_SER_LABEL"));

		dto.setRepairTime(getIntIfExists("OPE_REPAIR_TIME"));
		if (getBooleanIfExists("OPE_MADE_BYCUSTOMER") != null)
		{
			dto.setByCustomer(getBooleanIfExists("OPE_MADE_BYCUSTOMER").booleanValue());
		}

		dto.setWithConsumable(getStringIfExists("WITH_CONS"));
		dto.setWithParts(getStringIfExists("WITH_PARTS"));
		dto.setWithPerf(getStringIfExists("WITH_PERF"));

		return dto;

	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesPartCompareDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException {

		//		Query:
		//		
		//		SELECT distinct opeser.ope_ser_id, opeser.ope_operation_id, opeser.ope_repair_time, opeser.ope_made_bycustomer, 
		//		opeser.ope_mp_id, opeser.OPE_APP_BRA, opeser.OPE_APP_TYP, opeser.OPE_APP_PRO, opeser.OPE_APP_SER, serie.a_name, ope.ope_code, ope.ope_srt, t1.message OPE_TITLE,
		//		decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_CONS, 
		//		decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_PARTS
		//		FROM  mp_maintenance_project proj, mp_maintenance_plan plan, mp_interval inter, 
		//		mp_interval_operation intope, mp_operation_series opeser, mp_operation ope, table_title t1, serie
		//			WHERE proj.MP_ID = 
		//		'91'
		//		AND ope.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  
		//		'IT'
		//		or t1.idlanguage is null) 
		//		and plan.plan_project_id = proj.mp_id 
		//		and inter.int_plan_id = plan.plan_id 
		//		and intope.def_interval_id = inter.int_id 
		//		and intope.def_ope_series_id = opeser.ope_ser_id 
		//		and opeser.ope_operation_id = ope.ope_id
		//		and opeser.ope_app_bra = serie.bra_a_id
		//		and opeser.ope_app_typ = serie.typ_a_id
		//		and opeser.ope_app_pro = serie.pro_a_id
		//		and opeser.ope_app_ser = serie.a_id;

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct opeser.ope_ser_id, opeser.ope_operation_id, opeser.ope_repair_time, opeser.ope_made_bycustomer, ");
		query.append(" opeser.ope_mp_id, opeser.OPE_APP_BRA, opeser.OPE_APP_TYP, opeser.OPE_APP_PRO, opeser.OPE_APP_SER,  ");
		query.append(" ope.ope_code, ope.ope_srt, t1.message OPE_TITLE, ");
		query.append(" decode((select count(*) from mp_operation_consumable where ope_cons_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_CONS, ");
		query.append(" decode((select count(*) from mp_operation_part_number where ope_pn_ope_series_id = OPE_SER_ID), 0, ' ', '*')  as WITH_PARTS ");
		query.append(" FROM  mp_maintenance_project proj, mp_maintenance_plan plan, mp_interval inter, ");
		query.append(" mp_interval_operation intope, mp_operation_series opeser, mp_operation ope,table_title t1 ");
		query.append(" WHERE proj.MP_ID = ");
		query.append(formatString(idProject));
		query.append(" AND ope.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and plan.plan_project_id = proj.mp_id ");
		query.append(" and inter.int_plan_id = plan.plan_id ");
		query.append(" and intope.def_interval_id = inter.int_id ");
		query.append(" and intope.def_ope_series_id = opeser.ope_ser_id ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<OperationSeriesPartCompareDto> result = new ArrayList<OperationSeriesPartCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((OperationSeriesPartCompareDto) dto);
		}

		return result;
	}

	/**
	 * Get the operations.
	 * 
	 * @param opeSerId : opeSerId
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationSeriesPartCompareDto getOperationSeries(Long opeSerId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct opeser.ope_ser_id, opeser.ope_operation_id, opeser.ope_repair_time, opeser.ope_made_bycustomer, ");
		query.append(" opeser.ope_mp_id, opeser.OPE_APP_BRA, opeser.OPE_APP_TYP, opeser.OPE_APP_PRO, opeser.OPE_APP_SER,  ");
		query.append(" ope.ope_code, ope.ope_srt, t1.message OPE_TITLE ");
		query.append(" FROM mp_operation_series opeser, mp_operation ope,table_title t1 ");
		query.append(" WHERE opeser.ope_ser_id = ");
		query.append(opeSerId);
		query.append(" AND ope.ope_title_id = t1.idref_table_title(+) and (t1.idlanguage=  ");
		query.append(formatString(language));
		query.append("  or t1.idlanguage is null) ");
		query.append(" and opeser.ope_operation_id = ope.ope_id ");

		// Execute the query and get the result list
		// Execute the query and get the result list
		return (OperationSeriesPartCompareDto) executeQuery1(query.toString());
	}

}
