/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.PartDto;

/**
 * @author sdomecq
 *
 */
public class PartAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public PartAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		PartDto dto = new PartDto();

		dto.setCodePart(getStringIfExists("PN_CODE"));
		dto.setPartLabel(getStringIfExists("PN_LABEL"));
		dto.setPartLabelOrigin(getStringIfExists("PN_LABEL_ORIGIN"));

		dto.setLocationFamilyIceCode(getStringIfExists("PN_LOC_FAM"));
		dto.setLocationGroupIceCode(getStringIfExists("PN_LOC_GRO"));
		dto.setLocationSubGroupIceCode(getStringIfExists("PN_LOC_SUG"));

		dto.setLocationLabel(getStringIfExists("LOC_LABEL"));

		dto.setLanguage(getStringIfExists("Desc_Language"));

		return dto;

	}

	/**
	 * Get the List of parts .
	 * 
	 * @return the list of consumables
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PartDto> getList() throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append("  select MP_PART_NUMBER.* from MP_PART_NUMBER");
		query.append(" ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PartDto> result = new ArrayList<PartDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PartDto) dto);
		}

		return result;
	}

	public List<PartDto> getList(String currentLang, String defaultLang) throws SystemException {

		StringBuilder query = new StringBuilder();

		//		Query:
		//		Select ope_Pn_Code, Description as PN_LABEL, Desc_Language
		//		From (Select ope_Pn_Code, DESCRIPTION, Desc_Language, ROW_NUMBER() OVER 
		//		(PARTITION BY ope_Pn_Code ORDER BY CASE WHEN DESC_LANGUAGE = 'EN' THEN 1 ELSE 2 END) AS rnk
		//		From Mp_Part_Description 
		//		Right Outer Join Mp_Operation_Part_Number On (Desc_Pn_Code = ope_Pn_Code) 
		//		Where Desc_Language= 'IT'
		//		Or Desc_Language= 'EN')
		//		where rnk = 1 order by ope_Pn_Code; 
		//		

		// Create the query	

		query.append("  Select Ope_Pn_Code as PN_CODE, Description as PN_LABEL, Desc_Language");
		query.append(" From (");
		query.append(" Select Ope_Pn_Code, DESCRIPTION, Desc_Language, ROW_NUMBER() OVER (PARTITION BY Ope_Pn_Code ORDER BY CASE WHEN DESC_LANGUAGE = ");
		query.append(formatString(currentLang));
		query.append("  THEN 1 ELSE 2 END) AS rnk From Mp_Part_Description ");
		query.append(" 	Right Outer Join Mp_Operation_Part_Number On (Desc_Pn_Code = Ope_Pn_Code) ");
		query.append(" Where Desc_Language= ");
		query.append(formatString(defaultLang));
		query.append("  Or Desc_Language= ");
		query.append(formatString(currentLang));
		query.append(" ) where rnk = 1 order by Ope_Pn_Code");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PartDto> result = new ArrayList<PartDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PartDto) dto);
		}

		return result;
	}

	/**
	 * add part.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(PartDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (exists(dto.getCodePart()) == false)
		{
			query.append("INSERT INTO MP_PART_NUMBER ( PN_CODE, PN_LABEL, PN_LOC_FAM, PN_LOC_GRO, PN_LOC_SUG, PN_LABEL_ORIGIN) values (");
			query.append(formatString(dto.getCodePart()));
			query.append(",");
			query.append(formatString(dto.getPartLabel()));
			query.append(",");
			query.append(formatString(dto.getLocationFamilyIceCode()));
			query.append(",");
			query.append(formatString(dto.getLocationGroupIceCode()));
			query.append(",");
			query.append(formatString(dto.getLocationSubGroupIceCode()));
			query.append(",");
			query.append(formatString(dto.getPartLabelOrigin()));
			query.append(")");

			executeQueryI("MP_PART_NUMBER", query.toString());
		}
		else
		{
			query.append("UPDATE MP_PART_NUMBER set PN_LABEL = ");
			query.append(formatString(dto.getPartLabel()));
			query.append(" , PN_LABEL_ORIGIN = ");
			query.append(formatString(dto.getPartLabelOrigin()));
			query.append(" WHERE PN_CODE = ");
			query.append(formatString(dto.getCodePart()));

			executeQueryI("MP_PART_NUMBER", query.toString());
		}

	}

	/**
	 * check if part number code already exist.
	 * 
	 * @param code to search
	 * @return if part number caode exists
	 * @throws SystemException Cannot execute query or access to database.
	 */
	private boolean exists(String code) throws SystemException {
		boolean result = false;
		StringBuilder query = new StringBuilder();

		query.append(" select count(PN_CODE) NB from MP_PART_NUMBER where PN_CODE=");
		query.append(formatString(code));

		Long nb = executeQueryCount(query.toString(), "NB");
		if (nb != null)
		{
			if (nb.intValue() > 0)
			{
				result = true;
			}
		}

		return result;
	}

	/**
	 * Get the part.
	 * 
	 * @param pnCode : part number Code
	 * @return the part number
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public PartDto getPartByCode(String pnCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" select MP_PART_NUMBER.* from MP_PART_NUMBER");
		query.append(" WHERE PN_CODE = ");
		query.append(formatString(pnCode));

		// Execute the query and get the result list
		return (PartDto) executeQuery1(query.toString());
	}
}
