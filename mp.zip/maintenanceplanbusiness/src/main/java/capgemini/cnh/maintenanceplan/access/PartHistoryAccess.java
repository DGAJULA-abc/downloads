/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.common.util.Util;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.BindDto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.dto.PartHistoryDto;

/**
 * @author mmartel
 *
 */
public class PartHistoryAccess extends OracleAccess<PartHistoryDto> {

	/** Define a logger for this class. */
	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public PartHistoryAccess() throws SystemException {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public PartHistoryAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected PartHistoryDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		PartHistoryDto dto = new PartHistoryDto();

		// Set Dto
		dto.setHistPnCode(getStringIfExists("HIST_PN_CODE"));
		dto.setHistSubstitutePnCode(getStringIfExists("HIST_SUBSTITUTE_PN_CODE"));
		dto.setHistSupersessionDate(Util.dateToString(getDateIfExists("HIST_SUPERSESSION_DATE")));
		dto.setHistSupersessionQty(getLongIfExists("HIST_SUPERSESSION_QTY"));
		dto.setHistSupersessionType(getStringIfExists("HIST_SUPERSESSION_TYPE"));

		return dto;
	}

	/**
	 * Get the substitute if exists for a list of part.
	 * 
	 * @param listPart to search
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PartHistoryDto> getSubstitute(List<String> listPart) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select HIST_PN_CODE, HIST_SUBSTITUTE_PN_CODE, HIST_SUPERSESSION_DATE from MP_PART_HISTORY hist1 where hist1.HIST_PN_CODE in (SELECT COLUMN_VALUE FROM TABLE(?))");
		query.append(" and hist1.HIST_SUPERSESSION_DATE in (SELECT max(mp_hist2.hist_supersession_date) from mp_part_history mp_hist2 where mp_hist2.HIST_PN_CODE = hist1.HIST_PN_CODE) ");
		query.append(" order by hist1.HIST_PN_CODE");

		BindDto bind = new BindDto(Access.STRING_ARRAY_TYPE, listPart.toArray());
		List<BindDto> bindList = new ArrayList<BindDto>();
		bindList.add(bind);

		return executeQueryNWithBind(query.toString(), bindList);
	}

	/**
	 * Get the original part if exists for a list of part.
	 * 
	 * @param listPart to search
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PartHistoryDto> getOriginal(List<String> listPart) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select HIST_PN_CODE, HIST_SUBSTITUTE_PN_CODE, HIST_SUPERSESSION_DATE from MP_PART_HISTORY hist1 where hist1.HIST_SUBSTITUTE_PN_CODE in (SELECT COLUMN_VALUE FROM TABLE(?))");
		query.append(
				" and hist1.HIST_SUPERSESSION_DATE in (SELECT max(mp_hist2.hist_supersession_date) from mp_part_history mp_hist2 where mp_hist2.HIST_SUBSTITUTE_PN_CODE = hist1.HIST_SUBSTITUTE_PN_CODE) ");
		query.append(" order by hist1.HIST_PN_CODE");

		BindDto bind = new BindDto(Access.STRING_ARRAY_TYPE, listPart.toArray());
		List<BindDto> bindList = new ArrayList<BindDto>();
		bindList.add(bind);

		return executeQueryNWithBind(query.toString(), bindList);
	}

	/**
	 * Get the substitute if exists for a list of part after the date.
	 * 
	 * @param part the part to search
	 * @param date the date after
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PartHistoryDto> getSubstituteAfterDate(String part, String date) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select HIST_PN_CODE, HIST_SUBSTITUTE_PN_CODE, HIST_SUPERSESSION_DATE from MP_PART_HISTORY hist1 where hist1.HIST_PN_CODE = ");
		query.append(formatString(part));
		query.append(" and hist1.HIST_SUPERSESSION_DATE > TO_DATE(");
		query.append(formatString(date));
		query.append(", 'DD/MM/YYYY HH24: MI: SS') ");
		query.append(" order by hist1.HIST_PN_CODE");

		return executeQueryN(query.toString());
	}

}
