/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import capgemini.cnh.common.util.Constants;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.BindDto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.PlanDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class PlanAccess extends OracleAccess<PlanDto> {

	/**
	 * Date Format.
	 */
	private String date_format = "dd/mm/yyyy";

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public PlanAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected PlanDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		PlanDto dto = new PlanDto();

		dto.setId(getLongIfExists("PLAN_ID"));
		dto.setIdProject(getLongIfExists("PLAN_PROJECT_ID"));
		dto.setName(getStringIfExists("PLAN_NAME"));

		if (getBooleanIfExists("PLAN_STANDARD") != null)
		{
			dto.setStandard(getBooleanIfExists("PLAN_STANDARD").booleanValue());
		}

		dto.setStatus(getIntIfExists("PLAN_STATUS"));
		dto.setModifDate(dateToString(getDateIfExists("PLAN_DATE_MODIF")));
		dto.setLastModifier(getStringIfExists("PLAN_LAST_MODIFIER"));

		if (getLongIfExists("COND_ID") != null)
		{
			ConditionDto condition = new ConditionDto();
			condition.setIdCondition(getLongIfExists("COND_ID"));
			condition.setIdPlan(getLongIfExists("PLAN_ID"));

			if (getStringIfExists("COND_USAGE_VALUE") != null)
			{
				UsageDto usage = new UsageDto();
				usage.setValueId(getLongIfExists("COND_USAGE_VALUE"));
				usage.setValueTitle(getStringIfExists("VALUE_TITLE"));
				usage.setItemTitle(getStringIfExists("ITEM_TITLE"));

				condition.setUsage(usage);
			}

			dto.setCondition(condition);
		}

		dto.setPerformanceType(getStringIfExists("PLAN_PERF_TYPE"));
		dto.setWithAppli(getStringIfExists("WITH_APPLI"));

		dto.setExtId(getLongIfExists("PLAN_EXT_ID"));
		dto.setOldExtId(getLongIfExists("PLAN_OLD_EXT_ID"));

		return dto;

	}

	/**
	 * Get the List of plan .
	 * 
	 * @param planProjectId filter
	 * @param language for translated texts
	 * @param mode to find the status of plans
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanDto> getList(String planProjectId, String language, String mode) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("  select distinct mp_maintenance_plan.* , ti.message ITEM_TITLE, tv.message VALUE_TITLE, mp_maintenance_condition.*, ");
		query.append(" decode((select count(*) from mp_plan_applicability where mp_plan_applicability.plan_id = mp_maintenance_plan.plan_id), 0, '', '*')  as WITH_APPLI ");
		query.append("  from mp_maintenance_plan, mp_maintenance_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv");
		if (mode != null)
		{
			query.append(" , mp_maintenance_project ");
		}
		query.append("  where plan_project_id=");
		query.append(formatString(planProjectId));
		if (mode != null)
		{
			if (mode.equals(Constants.RELEASED_MODE))
			{
				query.append(" and plan_status = '1' ");
			}
			else if (mode.equals(Constants.DRAFT_MODE))
			{
				query.append(" and plan_status = '0' ");
			}
			query.append(" and mp_personalized = '0' ");
		}
		query.append("  and mp_maintenance_plan.plan_id = mp_maintenance_condition.cond_plan_id(+) ");
		query.append("  and mp_maintenance_condition.cond_usage_value = v.us_value_id(+) ");
		query.append("  and v.us_item_id = i.us_item_id (+) ");
		query.append("  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) ");
		query.append("  and (ti.idlanguage =");
		query.append(formatString(language));
		query.append("   or ti.idlanguage is null) ");
		query.append("  and v.US_TITLE_ID = tv.idref_table_title(+) ");
		query.append("  and (tv.idlanguage =");
		query.append(formatString(language));
		query.append("   or tv.idlanguage is null) ");

		// Execute the query and get the result list
		List<PlanDto> result = executeQueryN(query.toString());

		return result;
	}

	/**
	 * Get the valid plans from other versions of a project linked by external id.
	 * 
	 * @param id id of the plan
	 * @param extId External id of the plan
	 * @return the list of valid plans
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getValidPlansPreviousVersion(String id, String extId) throws SystemException {

		/*
		 
		select PLAN_ID,	PLAN_PROJECT_ID,PLAN_NAME,PLAN_STATUS,PLAN_LAST_MODIFIER,PLAN_DATE_MODIF,PLAN_STANDARD,	PLAN_PERF_TYPE,	PLAN_EXT_ID 
		from MP_MAINTENANCE_PLAN, MP_MAINTENANCE_PROJECT 
		where (PLAN_EXT_ID = '9163' or plan_id ='9163')
		and plan_project_id = mp_id 
		and plan_status = '1' 
		and mp_status = '1' 
		and plan_id <> '9164';
		
		 */
		List<BindDto> bindList = new ArrayList<BindDto>();

		StringBuilder query = new StringBuilder();

		query.append("select PLAN_ID,	PLAN_PROJECT_ID,PLAN_NAME,PLAN_STATUS,PLAN_LAST_MODIFIER,PLAN_DATE_MODIF,PLAN_STANDARD,	PLAN_PERF_TYPE,	PLAN_EXT_ID ");
		query.append(" from MP_MAINTENANCE_PLAN, MP_MAINTENANCE_PROJECT, MP_PROJECT_APPLICABILITY ");
		query.append(" where (PLAN_EXT_ID = ? ");

		BindDto bind = new BindDto(Access.STRING_TYPE, extId);
		bindList.add(bind);

		query.append(" or PLAN_ID = ? ");

		BindDto bind2 = new BindDto(Access.STRING_TYPE, extId);
		bindList.add(bind2);

		query.append(" ) and plan_id <> ? ");

		BindDto bind3 = new BindDto(Access.STRING_TYPE, id);
		bindList.add(bind3);

		query.append(" and plan_project_id = mp_id ");
		query.append(" and plan_status = '1' ");
		query.append(" and mp_id = mp_project_id and mp_app_bra = '2' ");
		query.append(" and mp_status = '1' ");

		List<PlanDto> result = executeQueryNWithBind(query.toString(), bindList);

		return result;
	}

	/**
	 * Get the draft plans linked to thsi plan that have already been exported to SAP.
	 * 
	 * @param id plan id
	 * @return the list of previously exported plans.
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getDraftPlansAlreadyExported(String id, Long extId) throws SystemException {
		/*
		 
		-- If ext_id <> 0 
		select mp_maintenance_plan.* from mp_maintenance_plan, mp_export_request 
		where plan_status = 0 and plan_project_id = exp_project_id and exp_project_status = 0 and plan_ext_id = '7064';
		
		-- if ext_id == 0
		select mp_maintenance_plan.* from mp_maintenance_plan, mp_export_request 
		where plan_status = 0 and plan_project_id = exp_project_id and exp_project_status = 0 and plan_id = '20026' ;
		
		 */
		List<BindDto> bindList = new ArrayList<BindDto>();

		StringBuilder query = new StringBuilder();

		query.append(" select PLAN_ID, PLAN_PROJECT_ID,PLAN_NAME,PLAN_STATUS,PLAN_LAST_MODIFIER,PLAN_DATE_MODIF,PLAN_STANDARD,PLAN_PERF_TYPE,PLAN_EXT_ID ");
		query.append(" from mp_maintenance_plan, mp_export_request ");
		query.append(" where plan_status = 0 and plan_project_id = exp_project_id and exp_project_status = 0 ");
		if (extId != null)
		{
			query.append(" and plan_ext_id = ? ");
			BindDto bind = new BindDto(Access.LONG_TYPE, extId);
			bindList.add(bind);
		}
		else
		{
			query.append(" and plan_id = ? ");
			BindDto bind3 = new BindDto(Access.STRING_TYPE, id);
			bindList.add(bind3);
		}

		List<PlanDto> result = executeQueryNWithBind(query.toString(), bindList);

		return result;
	}

	/**
	 * delete plan for a given id.
	 * 
	 * @param idPlan to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_MAINTENANCE_PLAN where PLAN_ID = ");
		query.append(idPlan);

		executeQueryI("MP_MAINTENANCE_PLAN", query.toString());
	}

	/**
	 * delete plan for a given project id.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deletePlanForProject(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_MAINTENANCE_PLAN where PLAN_PROJECT_ID = ");
		query.append(idProject);

		executeQueryI("MP_MAINTENANCE_PLAN", query.toString());
	}

	/**
	 * add plan.
	 * 
	 * @param dto to save
	 * @return created id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long add(PlanDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();
		Long id = null;

		if (dto.getId() == null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);

			id = getNextId();
			query.append("INSERT INTO MP_MAINTENANCE_PLAN ( PLAN_ID, PLAN_PROJECT_ID, PLAN_NAME, PLAN_STATUS, PLAN_LAST_MODIFIER, PLAN_DATE_MODIF, PLAN_STANDARD, PLAN_PERF_TYPE) values (");
			query.append(id.toString());
			query.append(",");
			query.append(dto.getIdProject().toString());
			query.append(",");
			query.append(formatString(dto.getName()));
			query.append(",");
			query.append(dto.getStatus().toString());
			query.append(",");
			query.append(formatString(dto.getLastModifier()));
			query.append(",");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(",");
			if (dto.getStandard())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			query.append(",");
			query.append(formatString(dto.getPerformanceType()));
			query.append(")");

			executeQueryI("MP_MAINTENANCE_PLAN", query.toString());
		}

		return id;
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_MAINTENANCE_PLAN.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(PlanDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);

			query.append("update MP_MAINTENANCE_PLAN set");
			query.append(" PLAN_NAME = ");
			query.append(formatString(dto.getName()));
			query.append(" , PLAN_STATUS = ");
			query.append(dto.getStatus().toString());
			query.append(" , PLAN_LAST_MODIFIER = ");
			query.append(formatString(dto.getLastModifier()));
			query.append(" , PLAN_DATE_MODIF = ");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(" , PLAN_STANDARD = ");
			if (dto.getStandard())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			/*
			query.append(" , PLAN_COMMENT_ID = ");
			if (dto.getCommentId() != null)
			{
				query.append(dto.getCommentId().toString());
			}
			else
			{
				query.append("null ");
			}
			*/
			query.append(" , PLAN_PERF_TYPE = ");
			query.append(formatString(dto.getPerformanceType()));
			if (dto.getExtId() == null)
			{
				query.append(" , PLAN_EXT_ID = null ");
			}
			if (dto.getOldExtId() != null)
			{
				query.append(" , PLAN_OLD_EXT_ID =  ");
				query.append(dto.getOldExtId());
			}
			else
			{
				query.append(" , PLAN_OLD_EXT_ID = null ");
			}

			query.append(" WHERE PLAN_ID = ");
			query.append(dto.getId().toString());

			executeQueryI("MP_MAINTENANCE_PLAN", query.toString());
		}

	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
			result = sdf.format(myDate);
			//result = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + l_currentDate.get(Calendar.YEAR);
		}

		return result;
	}

	/**
	 * Get the plan .
	 * 
	 * @param planId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public PlanDto getPlanById(String planId) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append("  select distinct mp_maintenance_plan.* ");
		query.append("  from mp_maintenance_plan ");
		query.append("  where plan_id=");
		query.append(planId);

		// Execute the query and get the result
		PlanDto result = (PlanDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * update Last Modifier and Modif date of MP_MAINTENANCE_PLAN.
	 * 
	 * @param idPlan id of the plan to update
	 * @param lastModifier modifier for the update
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(String idPlan, String lastModifier) throws SystemException {

		StringBuilder query = new StringBuilder();

		Calendar l_currentDate = Calendar.getInstance();
		l_currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date 
		String l_strDateCurrent = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/" + l_currentDate.get(Calendar.YEAR);

		query.append("update MP_MAINTENANCE_PLAN set");
		query.append(" PLAN_LAST_MODIFIER = ");
		query.append(formatString(lastModifier));
		query.append(" , PLAN_DATE_MODIF = ");
		query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
		query.append(" WHERE PLAN_ID = ");
		query.append(formatString(idPlan));

		executeQueryI("MP_MAINTENANCE_PLAN", query.toString());
	}

	/**
	 * Update the external id of a plan
	 * 
	 * @param intId the id of the plan
	 * @param extId the external id of the plan
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updateExtId(Long intId, Long extId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("update MP_MAINTENANCE_PLAN ");
		query.append(" set PLAN_EXT_ID = ");
		query.append(extId);
		query.append(" where PLAN_ID = ");
		query.append(intId);

		executeQuery0(query.toString());
	}

	/**
	 * Get the valid plans from the previous released project version.
	 * 
	 * @param projectId project id
	 * @param projectNumber project Number
	 * @return the valid plans from the previous released project version.
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getValidPlansPreviousProject(String projectId, String projectNumber) throws SystemException {
		/*
		 
		 SELECT MP_MAINTENANCE_plan.* 
		 FROM MP_MAINTENANCE_plan, MP_MAINTENANCE_PROJECT pr1 
		 where PLAN_PROJECT_ID = mp_id 
		 and mp_number = '0012' 
		 and mp_id <> 135 
		 and mp_status = 1 and plan_status = 1
		 and mp_version = (select max(pr2.mp_version)
			               from MP_MAINTENANCE_PROJECT pr2
			               where pr2.mp_NUMBER = pr1.mp_NUMBER and pr2.mp_STATUS = 1 and mp_id <> 135)
		 */
		StringBuilder query = new StringBuilder();

		query.append("select PLAN_ID, PLAN_PROJECT_ID, PLAN_NAME, PLAN_STATUS, PLAN_LAST_MODIFIER, PLAN_DATE_MODIF, PLAN_STANDARD, PLAN_PERF_TYPE, PLAN_EXT_ID, PLAN_OLD_EXT_ID ");
		query.append(" FROM MP_MAINTENANCE_plan, MP_MAINTENANCE_PROJECT pr1  ");
		query.append(" where PLAN_PROJECT_ID = mp_id  ");
		query.append(" and mp_number = ");
		query.append(formatString(projectNumber));
		query.append(" and mp_id <> ");
		query.append(formatString(projectId));
		query.append(" and mp_status = 1 and plan_status = 1 ");
		query.append(" and mp_version = (select max(pr2.mp_version) ");
		query.append(" from MP_MAINTENANCE_PROJECT pr2 ");
		query.append(" where pr2.mp_NUMBER = pr1.mp_NUMBER and pr2.mp_STATUS = 1 and mp_id <> ");
		query.append(formatString(projectId));
		query.append(" )");

		return executeQueryN(query.toString());
	}

}
