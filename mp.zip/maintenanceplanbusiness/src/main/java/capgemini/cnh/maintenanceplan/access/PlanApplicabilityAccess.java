/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.common.util.Constants;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.PlanApplicabilityDto;

/**
 * @author sdomecq
 *
 */
public class PlanApplicabilityAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public PlanApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		PlanApplicabilityDto dto = new PlanApplicabilityDto();

		dto.setId(getLongIfExists("PLAN_APP_ID"));
		dto.setIdPlan(getLongIfExists("PLAN_ID"));

		dto.setModel(getStringIfExists("PLAN_MOD"));
		dto.setTt(getStringIfExists("PLAN_TT"));
		dto.setMarket(getLongIfExists("PLAN_MARKET"));
		dto.setConfig(getStringIfExists("PLAN_CONFIG"));

		return dto;

	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(PlanApplicabilityDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO MP_PLAN_APPLICABILITY ( PLAN_ID, PLAN_MOD, PLAN_TT, PLAN_MARKET, PLAN_CONFIG) values (");
		query.append(dto.getIdPlan());
		query.append(",");
		query.append(formatString(dto.getModel()));
		query.append(",");
		query.append(formatString(dto.getTt()));
		query.append(",");
		query.append(dto.getMarket());
		query.append(",");
		query.append(formatString(dto.getConfig()));
		query.append(")");

		executeQueryI("MP_PLAN_APPLICABILITY", query.toString());
	}

	/**
	 * delete for a given plan.
	 * 
	 * @param idPlan to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByPlanId(String idPlan) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_PLAN_APPLICABILITY where PLAN_ID = ");
		query.append(idPlan);

		executeQueryI("MP_PLAN_APPLICABILITY", query.toString());
	}

	/**
	 * delete for a given project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_PLAN_APPLICABILITY where PLAN_ID in (select distinct PLAN_ID from  MP_MAINTENANCE_PLAN  WHERE PLAN_PROJECT_ID = ");
		query.append(idProject);
		query.append(" )");

		executeQueryI("MP_PLAN_APPLICABILITY", query.toString());
	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param maintenanceAppId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanApplicabilityDto> getListMaintenanceApplicability(String maintenanceAppId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_plan_applicability where plan_id = ");
		query.append(maintenanceAppId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PlanApplicabilityDto> result = new ArrayList<PlanApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PlanApplicabilityDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param maintenanceAppId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanApplicabilityDto> getListMaintenanceApplicabilityOrdered(String maintenanceAppId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_plan_applicability where plan_id = ");
		query.append(maintenanceAppId);
		query.append("  order by 2,3,4,5 ");

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PlanApplicabilityDto> result = new ArrayList<PlanApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PlanApplicabilityDto) dto);
		}

		return result;
	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param maintenanceAppId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanApplicabilityDto> getListMaintenanceApplicabilityExport(String maintenanceAppId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("  select * from mp_plan_applicability_migrate where plan_id = ");
		query.append(maintenanceAppId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PlanApplicabilityDto> result = new ArrayList<PlanApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PlanApplicabilityDto) dto);
		}

		return result;
	}

	/**
	 * Get the plan applicabilities by project.
	 * 
	 * @param projectId project id
	 * @return the list of plan applicability
	 * @throws SystemException SystemException
	 */
	public List<PlanApplicabilityDto> getApplicabilityListByProject(String projectId) throws SystemException {

		/*
		 Query:
		 	select PLAN_APP_ID,	MP_PLAN_APPLICABILITY.PLAN_ID, PLAN_MOD, PLAN_TT, PLAN_MARKET, PLAN_CONFIG 
		 	from mp_maintenance_plan, MP_PLAN_APPLICABILITY 
		 	where mp_maintenance_plan.plan_id =  MP_PLAN_APPLICABILITY.plan_id 
		 	and plan_project_id = 453;
		 * 
		 */
		StringBuilder query = new StringBuilder();

		query.append("select PLAN_APP_ID,	MP_PLAN_APPLICABILITY.PLAN_ID, PLAN_MOD, PLAN_TT, PLAN_MARKET, PLAN_CONFIG ");
		query.append("from mp_maintenance_plan, MP_PLAN_APPLICABILITY  ");
		query.append("where mp_maintenance_plan.plan_id =  MP_PLAN_APPLICABILITY.plan_id  ");
		query.append("and plan_project_id = ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}

	/**
	 * Get the plan applicabilities by project and status.
	 * 
	 * @param projectId project id
	 * @param mode RELEASED or DRAFT
	 * @return the list of plan applicability
	 * @throws SystemException SystemException
	 */
	public List<PlanApplicabilityDto> getApplicabilityListByProject(String projectId, String mode) throws SystemException {

		/*
		 Query:
		 	select PLAN_APP_ID,	MP_PLAN_APPLICABILITY.PLAN_ID, PLAN_MOD, PLAN_TT, PLAN_MARKET, PLAN_CONFIG 
		 	from mp_maintenance_plan, MP_PLAN_APPLICABILITY 
		 	where mp_maintenance_plan.plan_id =  MP_PLAN_APPLICABILITY.plan_id 
		 	and plan_status = 1
		 	and plan_project_id = 453;
		 * 
		 */
		StringBuilder query = new StringBuilder();

		query.append("select PLAN_APP_ID,	MP_PLAN_APPLICABILITY.PLAN_ID, PLAN_MOD, PLAN_TT, PLAN_MARKET, PLAN_CONFIG ");
		query.append("from mp_maintenance_plan, MP_PLAN_APPLICABILITY  ");
		query.append("where mp_maintenance_plan.plan_id =  MP_PLAN_APPLICABILITY.plan_id  ");
		if (mode != null)
		{
			if (mode.equals(Constants.RELEASED_MODE))
			{
				query.append(" and plan_status = '1' ");
			}
			else if (mode.equals(Constants.DRAFT_MODE))
			{
				query.append(" and plan_status = '0' ");
			}
		}
		query.append("and plan_project_id = ");
		query.append(projectId);

		return executeQueryN(query.toString());
	}
}
