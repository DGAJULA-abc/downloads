/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.PlanCompareDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class PlanCompareAccess extends OracleAccess {

	/**
	 * Date Format.
	 */
	private String date_format = "dd/mm/yyyy";

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public PlanCompareAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		PlanCompareDto dto = new PlanCompareDto();

		dto.setId(getLongIfExists("PLAN_ID"));
		dto.setIdProject(getLongIfExists("PLAN_PROJECT_ID"));
		dto.setName(getStringIfExists("PLAN_NAME"));

		if (getBooleanIfExists("PLAN_STANDARD") != null)
		{
			dto.setStandard(getBooleanIfExists("PLAN_STANDARD").booleanValue());
		}

		dto.setStatus(getIntIfExists("PLAN_STATUS"));
		dto.setLastModifier(getStringIfExists("PLAN_LAST_MODIFIER"));

		if (getLongIfExists("COND_ID") != null)
		{
			ConditionDto condition = new ConditionDto();
			condition.setIdCondition(getLongIfExists("COND_ID"));
			condition.setIdPlan(getLongIfExists("PLAN_ID"));

			if (getStringIfExists("COND_USAGE_VALUE") != null)
			{
				UsageDto usage = new UsageDto();
				usage.setValueId(getLongIfExists("COND_USAGE_VALUE"));
				usage.setValueTitle(getStringIfExists("VALUE_TITLE"));
				usage.setItemTitle(getStringIfExists("ITEM_TITLE"));

				condition.setUsage(usage);
			}

			dto.setCondition(condition);
		}

		dto.setPerformanceType(getStringIfExists("PLAN_PERF_TYPE"));
		dto.setModelApp(getStringIfExists("PLAN_MOD"));
		dto.setTtApp(getStringIfExists("PLAN_TT"));
		dto.setMarketApp(getLongIfExists("PLAN_MARKET"));
		dto.setConfigApp(getStringIfExists("PLAN_CONFIG"));
		return dto;

	}

	/**
	 * Get the List of plan .
	 * 
	 * @param planProjectId filter
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanCompareDto> getList(String planProjectId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append("  select distinct mp_maintenance_plan.* , ti.message ITEM_TITLE, tv.message VALUE_TITLE, mp_maintenance_condition.*, ");
		query.append(" papp.PLAN_MOD, papp.PLAN_TT , papp.PLAN_MARKET , papp.PLAN_CONFIG");
		query.append(
				"  from mp_maintenance_plan, mp_maintenance_condition, mp_usage_value v, mp_usage_item i, table_title ti, table_title tv, mp_plan_applicability papp ");
		query.append("  where plan_project_id=");
		query.append(planProjectId);
		query.append("  and mp_maintenance_plan.plan_id = mp_maintenance_condition.cond_plan_id(+) ");
		query.append("  and mp_maintenance_condition.cond_usage_value = v.us_value_id(+) ");
		query.append("  and v.us_item_id = i.us_item_id (+) ");
		query.append("  and i.US_ITEM_TITLE_ID = ti.idref_table_title(+) ");
		query.append("  and (ti.idlanguage =");
		query.append(formatString(language));
		query.append("   or ti.idlanguage is null) ");
		query.append("  and v.US_TITLE_ID = tv.idref_table_title(+) ");
		query.append("  and (tv.idlanguage =");
		query.append(formatString(language));
		query.append("   or tv.idlanguage is null) ");
		query.append(" AND mp_maintenance_plan.plan_id               = papp.PLAN_ID(+)");
		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<PlanCompareDto> result = new ArrayList<PlanCompareDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((PlanCompareDto) dto);
		}

		return result;
	}

}
