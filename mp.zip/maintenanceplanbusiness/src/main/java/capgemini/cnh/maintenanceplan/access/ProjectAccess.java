/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationDto;
import capgemini.cnh.maintenanceplan.dto.PlanDto;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;
import capgemini.cnh.maintenanceplan.dto.UsageDto;
import capgemini.cnh.maintenanceplan.util.Util;

/**
 * @author sdomecq
 *
 */
public class ProjectAccess extends OracleAccess<ProjectDto> {

	/**
	 * Date Format.
	 */
	private String date_format = "dd/MM/yyyy HH24:MI:SS";

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public ProjectAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected ProjectDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto

		//t2.message as Usage,
		ProjectDto dto = new ProjectDto();
		PlanDto planDto = new PlanDto();
		IntervalOperationDto intervalOpDto = new IntervalOperationDto();

		dto.setId(getLongIfExists("MP_ID"));

		dto.setName(getStringIfExists("MP_NAME"));
		dto.setRepairTime(getLongIfExists("INT_REPAIR_TIME"));

		dto.setStatus(getIntIfExists("MP_STATUS"));
		dto.setStatusLabel(getStringIfExists("MP_STATUS_LABEL"));
		dto.setModifDate(dateToString(getDateIfExists("MP_DATE_MODIF")));
		dto.setModifDateWithHour(dateToStringWithHour(getDateIfExists("MP_DATE_MODIF")));
		dto.setCreationDate(dateToString(getDateIfExists("MP_DATE_CREATION")));
		dto.setLastModifierName(getStringIfExists("idlang_name"));
		dto.setLastModifierId(getStringIfExists("mp_last_modifier"));
		dto.setVersion(getIntIfExists("MP_VERSION"));
		dto.setComment(getStringIfExists("MP_COMMENT"));
		dto.setNumber(getStringIfExists("MP_NUMBER"));

		if (getBooleanIfExists("MP_IS_SELECTED") != null)
		{
			dto.setSelected(getBooleanIfExists("MP_IS_SELECTED").booleanValue());
		}

		if (getBooleanIfExists("MP_PERSONALIZED") != null)
		{
			dto.setPersonalized(getBooleanIfExists("MP_PERSONALIZED").booleanValue());
		}

		if (getBooleanIfExists("MP_HAS_CONTRACT") != null)
		{
			dto.setHasContract(getBooleanIfExists("MP_HAS_CONTRACT").booleanValue());
		}

		dto.setReleaseType(getLongIfExists("MP_RLS_TYPE"));

		dto.setApplicabilityId(getLongIfExists("MP_APPLI_ID"));
		dto.setApplicabilityBrandIceCode(getStringIfExists("MP_APP_BRA"));
		dto.setApplicabilityTypeIceCode(getStringIfExists("MP_APP_TYP"));
		dto.setApplicabilityProductIceCode(getStringIfExists("MP_APP_PRO"));
		dto.setApplicabilitySeriesIceCode(getStringIfExists("MP_APP_SER"));
		dto.setApplicabilitySeriesId(getLongIfExists("A_ID"));
		dto.setApplicabilityLabel(getStringIfExists("SER_LABEL"));

		if (getBooleanIfExists("MP_IS_UCR") != null)
		{
			dto.setUcr(getBooleanIfExists("MP_IS_UCR").booleanValue());
		}

		dto.setLastReport(getStringIfExists("MP_LAST_REPORT"));

		ConditionDto condition = new ConditionDto();
		UsageDto usage = new UsageDto();
		usage.setValueTitle(getStringIfExists("Usage"));
		condition.setUsage(usage);

		// Plan
		planDto.setId(getLongIfExists("plan_id"));
		planDto.setName(getStringIfExists("plan_name"));
		planDto.setStatus(getIntIfExists("plan_status"));
		planDto.setPerformanceType(getStringIfExists("PERFORMANCE"));
		planDto.setCondition(condition);
		dto.setPlan(planDto);

		// Operation
		intervalOpDto.setMicroOperation(getStringIfExists("ope_code"));
		intervalOpDto.setSrtOperation(getStringIfExists("ope_srt"));
		intervalOpDto.setIntervalCode(getStringIfExists("int_code"));

		if (getStringIfExists("Label") != null)
		{
			intervalOpDto.setOperationLabel(getStringIfExists("Label"));
		}
		else
		{
			intervalOpDto.setOperationLabel(getStringIfExists("Message"));
		}

		dto.setOperation(intervalOpDto);

		return dto;

	}

	/**
	 * Get the List of project .
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @param statusList Status of prj to be filtered if needed ?
	 * @param isPrjSelected Project displayed in tab or not ?
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getList(String brand, String type, String product, String series, String statusList, Boolean isPrjSelected, String projectId) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name MP_SER_LABEL, idlang_name
		//		FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage
		//		 WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID  
		//		 AND (BRAND.A_ICE_CODE = MP_APP_BRA 
		//		 AND TYPE.A_ICE_CODE = MP_APP_TYP
		//		 AND PRODUCT.A_ICE_CODE = MP_APP_PRO
		//		 AND SERIE.A_ICE_CODE = MP_APP_SER )
		//       and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id
		//		and mp_maintenance_project.mp_last_modifier=idlang_user

		query.append(" SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name SER_LABEL, idlang_name ");
		query.append(" FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" AND (BRAND.A_ICE_CODE = MP_APP_BRA ");
		query.append(" AND TYPE.A_ICE_CODE = MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = MP_APP_PRO ");
		query.append(" AND SERIE.A_ICE_CODE = MP_APP_SER )");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");
		if (brand != null && !brand.equals(""))
		{
			query.append(" and MP_APP_BRA =  ");
			query.append(formatString(brand));
		}
		if (type != null && !type.equals(""))
		{
			query.append(" and MP_APP_TYP =  ");
			query.append(formatString(type));
		}
		if (product != null && !product.equals(""))
		{
			query.append(" and MP_APP_PRO =  ");
			query.append(formatString(product));
		}
		if (series != null && !series.equals(""))
		{
			query.append(" and MP_APP_SER =  ");
			query.append(formatString(series));
		}
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user ");

		if (statusList != null && !statusList.equals(""))
		{
			query.append(" and mp_status in " + statusList);
		}
		if (isPrjSelected)
		{
			query.append(" and MP_IS_SELECTED = 1 ");
		}
		if (projectId != null)
		{
			query.append(" and MP_ID <> ");
			query.append(formatString(projectId));
		}
		query.append(" order by MP_NUMBER asc, MP_VERSION desc");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the List of released projects .
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getListReleased(String brand, String type, String product, String series) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name MP_SER_LABEL, idlang_name
		//		FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage
		//		 WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID  
		//		 AND (BRAND.A_ICE_CODE = MP_APP_BRA 
		//		 AND TYPE.A_ICE_CODE = MP_APP_TYP
		//		 AND PRODUCT.A_ICE_CODE = MP_APP_PRO
		//		 AND SERIE.A_ICE_CODE = MP_APP_SER )
		//       and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id
		//		and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '1' 

		query.append(" SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name SER_LABEL, idlang_name ");
		query.append(" FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" AND (BRAND.A_ICE_CODE = MP_APP_BRA ");
		query.append(" AND TYPE.A_ICE_CODE = MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = MP_APP_PRO ");
		query.append(" AND SERIE.A_ICE_CODE = MP_APP_SER )");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");
		if (brand != null && !brand.equals(""))
		{
			query.append(" and MP_APP_BRA =  ");
			query.append(formatString(brand));
		}
		if (type != null && !type.equals(""))
		{
			query.append(" and MP_APP_TYP =  ");
			query.append(formatString(type));
		}
		if (product != null && !product.equals(""))
		{
			query.append(" and MP_APP_PRO =  ");
			query.append(formatString(product));
		}
		if (series != null && !series.equals(""))
		{
			query.append(" and MP_APP_SER =  ");
			query.append(formatString(series));
		}
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '1' ");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the List of released projects .
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getListReleasedForMaxVersion(String brand, String type, String product, String series) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name SER_LABEL, idlang_name ");
		query.append(" FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" AND (BRAND.A_ICE_CODE = MP_APP_BRA ");
		query.append(" AND TYPE.A_ICE_CODE = MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = MP_APP_PRO ");
		query.append(" AND SERIE.A_ICE_CODE = MP_APP_SER )");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '1' ");
		if (brand != null && !brand.equals(""))
		{
			query.append(" and MP_APP_BRA =  ");
			query.append(formatString(brand));
		}
		if (type != null && !type.equals(""))
		{
			query.append(" and MP_APP_TYP =  ");
			query.append(formatString(type));
		}
		if (product != null && !product.equals(""))
		{
			query.append(" and MP_APP_PRO =  ");
			query.append(formatString(product));
		}
		if (series != null && !series.equals(""))
		{
			query.append(" and MP_APP_SER =  ");
			query.append(formatString(series));
		}
		query.append(" and (mp_number, mp_version) in (select mp_number, max(mp_version) from MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID  ");
		query.append(" AND (BRAND.A_ICE_CODE = MP_APP_BRA ");
		query.append(" AND TYPE.A_ICE_CODE = MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = MP_APP_PRO ");
		query.append(" AND SERIE.A_ICE_CODE = MP_APP_SER) ");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '1' ");
		if (brand != null && !brand.equals(""))
		{
			query.append(" and MP_APP_BRA =  ");
			query.append(formatString(brand));
		}
		if (type != null && !type.equals(""))
		{
			query.append(" and MP_APP_TYP =  ");
			query.append(formatString(type));
		}
		if (product != null && !product.equals(""))
		{
			query.append(" and MP_APP_PRO =  ");
			query.append(formatString(product));
		}
		if (series != null && !series.equals(""))
		{
			query.append(" and MP_APP_SER =  ");
			query.append(formatString(series));
		}
		query.append(" group by mp_number)");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the List of Preliminary projects .
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getListDraft(String brand, String type, String product, String series) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name MP_SER_LABEL, idlang_name
		//		FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage
		//		 WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID  
		//		 AND (BRAND.A_ICE_CODE = MP_APP_BRA 
		//		 AND TYPE.A_ICE_CODE = MP_APP_TYP
		//		 AND PRODUCT.A_ICE_CODE = MP_APP_PRO
		//		 AND SERIE.A_ICE_CODE = MP_APP_SER )
		//       and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id
		//		and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '0' 

		query.append(" SELECT MP_Maintenance_project.*, mp_project_applicability.*, SERIE.A_ID, serie.a_name SER_LABEL, idlang_name ");
		query.append(" FROM  MP_Maintenance_project, BRAND, TYPE, PRODUCT, SERIE, mp_project_applicability, userlanguage ");
		query.append(" WHERE BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  AND TYPE.A_ID = SERIE.TYP_A_ID ");
		query.append(" AND (BRAND.A_ICE_CODE = MP_APP_BRA ");
		query.append(" AND TYPE.A_ICE_CODE = MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = MP_APP_PRO ");
		query.append(" AND SERIE.A_ICE_CODE = MP_APP_SER )");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");
		if (brand != null && !brand.equals(""))
		{
			query.append(" and MP_APP_BRA =  ");
			query.append(formatString(brand));
		}
		if (type != null && !type.equals(""))
		{
			query.append(" and MP_APP_TYP =  ");
			query.append(formatString(type));
		}
		if (product != null && !product.equals(""))
		{
			query.append(" and MP_APP_PRO =  ");
			query.append(formatString(product));
		}
		if (series != null && !series.equals(""))
		{
			query.append(" and MP_APP_SER =  ");
			query.append(formatString(series));
		}
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user and mp_status = '0' ");

		return executeQueryN(query.toString());
	}

	/**
	 * add operation.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(ProjectDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() == null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = Util.getNowDate(true);
			dto.setId(getNextId());
			query.append(
					"INSERT INTO MP_Maintenance_project ( MP_NUMBER, MP_ID,  MP_NAME, MP_LAST_MODIFIER, MP_STATUS, MP_PERSONALIZED, MP_HAS_CONTRACT, MP_RLS_TYPE, MP_DATE_CREATION, MP_DATE_MODIF, MP_VERSION, MP_COMMENT, MP_IS_UCR, MP_IS_SELECTED) values (");
			query.append(formatString(dto.getNumber()));
			query.append(",");
			query.append(dto.getId().toString());
			query.append(",");
			query.append(formatString(dto.getName()));
			query.append(",");
			query.append(formatString(dto.getLastModifierId()));
			query.append(",");
			query.append(dto.getStatus().toString());
			query.append(",");
			if (dto.getPersonalized())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			query.append(",");
			if (dto.hasContract())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			query.append(",");
			query.append(dto.getReleaseType());
			query.append(",");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(",");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(",");
			query.append(dto.getVersion().toString());
			query.append(",");
			query.append(formatString(dto.getComment()));
			query.append(",");
			query.append((dto.isUcr()) ? "1" : "0");
			query.append(",");
			query.append((dto.isSelected()) ? "1" : "0");
			query.append(")");

			executeQueryI("MP_Maintenance_project", query.toString());
		}

	}

	/**
	 * update project.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void update(ProjectDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getId() != null)
		{
			Calendar l_currentDate = Calendar.getInstance();
			l_currentDate.setTimeInMillis(System.currentTimeMillis());

			// Format current date --> used for ST_TECH_DATE_CREATION in case of insert, used for ST_TECH_DATE_CANCEL, ST_TECH_DATE_LASTMODIF in case of update
			String l_strDateCurrent = Util.getNowDate(true);
			query.append(" update MP_Maintenance_project set ");
			query.append(" MP_NAME = ");
			query.append(formatString(dto.getName()));
			query.append(", MP_LAST_MODIFIER = ");
			query.append(formatString(dto.getLastModifierId()));
			query.append(", MP_STATUS = ");
			query.append(dto.getStatus().toString());
			query.append(", MP_PERSONALIZED = ");
			if (dto.getPersonalized())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			query.append(", MP_HAS_CONTRACT = ");
			if (dto.hasContract())
			{
				query.append("1");
			}
			else
			{
				query.append("0");
			}
			query.append(", MP_RLS_TYPE = ");
			query.append(dto.getReleaseType());
			query.append(", MP_DATE_MODIF = ");
			query.append(" TO_DATE (" + formatString(l_strDateCurrent) + ", " + formatString(date_format) + ") ");
			query.append(", MP_VERSION = ");
			query.append(dto.getVersion().toString());
			query.append(", MP_IS_UCR = ");
			query.append((dto.isUcr()) ? "1" : "0");
			query.append(", MP_IS_SELECTED = ");
			query.append((dto.isSelected()) ? "1" : "0");

			query.append(" WHERE MP_ID = ");
			query.append(dto.getId().toString());

			executeQueryI("MP_Maintenance_project", query.toString());
		}

	}

	/**
	 * add project comment.
	 * 
	 * @param projectId to filter
	 * @param comment to set
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updateComment(String projectId, String comment) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" update MP_Maintenance_project set ");
		query.append(" MP_COMMENT = ");
		query.append(formatString(comment));

		query.append(" WHERE MP_ID = ");
		query.append(projectId);

		executeQueryI("MP_Maintenance_project", query.toString());

	}

	/**
	 * get project comment.
	 * 
	 * @param projectId to filter
	 * @return comment
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getComment(String projectId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT MP_COMMENT FROM MP_Maintenance_project  ");
		query.append(" WHERE MP_ID = ");
		query.append(projectId);

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * delete project.
	 * 
	 * @param projectId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(String projectId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_Maintenance_project  WHERE MP_ID = ");
		query.append(projectId);
		executeQueryI("MP_Maintenance_project", query.toString());

	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_MAINTENANCE_PROJECT.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
			result = sdf.format(myDate);
			//result = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + l_currentDate.get(Calendar.YEAR);
		}

		return result;
	}

	/**
	 * Format date.
	 * 
	 * @param myDate to format
	 * @return formatted date
	 */
	private String dateToStringWithHour(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY HH:mm:ss");
			result = sdf.format(myDate);
		}

		return result;
	}

	/**
	 * Get the project applicability.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getMaintenanceProjectApp(String idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct mp_maintenance_project.*, mp_project_applicability.mp_appli_id, idlang_name");
		query.append(" FROM  mp_maintenance_project, mp_project_applicability, userlanguage ");
		query.append(" WHERE MP_ID = ");
		query.append(formatString(idProject));
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user ");
		query.append(" and mp_maintenance_project.mp_id = mp_project_applicability.mp_project_id ");

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get the project.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getMaintenanceProject(String idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct mp_maintenance_project.*, idlang_name");
		query.append(" FROM  mp_maintenance_project, userlanguage ");
		query.append(" WHERE MP_ID = ");
		query.append(formatString(idProject));
		query.append(" and mp_maintenance_project.mp_last_modifier=idlang_user ");

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get the project
	 * 
	 * @param number : project number
	 * @param version : version of the project
	 * @return the project
	 * @throws SystemException system exception
	 */
	public ProjectDto getProjectForNumberAndVersion(String number, String version) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct mp_maintenance_project.*");
		query.append(" FROM  mp_maintenance_project ");
		query.append(" WHERE MP_NUMBER = ");
		query.append(formatString(number));
		query.append(" and MP_VERSION = ");
		query.append(version);

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get the maintenance project to export for the WU.
	 * 
	 * @param idProject : id of the project
	 * @param languageId : EN for AG&CE, IT for CV
	 * @return the list of the project/plans
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getMaintenancePlansProjectforWUToExport(String idProject, String languageId) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();
		int i = 0;

		query.append("select distinct");
		query.append(
				" MP_NUMBER, MP_VERSION, MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name, plan_status, plan_perf_type as PERFORMANCE, t2.message as Usage,  int_code ");
		query.append(" from mp_maintenance_project, ");
		query.append(" mp_project_applicability, ");

		query.append(" mp_maintenance_plan p  , mp_plan_applicability app, mp_interval,mp_maintenance_condition, mp_usage_value, table_title t2 ");
		query.append(" where plan_project_id = mp_id ");

		query.append(" and mp_id = MP_PROJECT_ID ");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and app.plan_id = p.plan_id ");
		query.append(" and p.plan_id=INT_PLAN_ID ");
		query.append(" and p.plan_id = cond_plan_id and us_value_id = COND_USAGE_VALUE ");
		query.append(" and t2.IDREF_TABLE_TITLE= US_TITLE_ID and t2.IDLANGUAGE= ");
		query.append(formatString(languageId));

		query.append(" union ");
		query.append(" select distinct ");
		query.append(
				" MP_NUMBER, MP_VERSION,  MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status , plan_perf_type as PERFORMANCE, ' ' as Usage,  int_code ");
		query.append(" from mp_maintenance_project, ");
		query.append(" mp_project_applicability, ");
		query.append(" mp_maintenance_plan p  , mp_plan_applicability app, mp_interval,mp_maintenance_condition ");
		query.append(" where plan_project_id = mp_id ");
		query.append(" and mp_id = MP_PROJECT_ID ");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and app.plan_id = p.plan_id ");
		query.append(" and p.plan_id=INT_PLAN_ID ");
		query.append(" and p.plan_id = cond_plan_id ");
		query.append(" and COND_USAGE_VALUE is null ");

		query.append(" union ");

		query.append(" select distinct ");

		query.append(
				" MP_NUMBER,  MP_VERSION, MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status, plan_perf_type as PERFORMANCE,  decode(t2.IDREF_TABLE_TITLE,'78','Heavy-Duty','79','Long distances','80','Road') as Usage, int_code ");
		query.append(" from mp_maintenance_project, ");
		query.append(" mp_project_applicability, ");
		query.append(" mp_maintenance_plan p ,mp_interval, mp_maintenance_condition,mp_usage_value,table_title t2 ");
		query.append(" where plan_project_id = mp_id ");
		query.append(" and mp_id = MP_PROJECT_ID ");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and  p.plan_id not in (select plan_id from mp_plan_applicability ) ");
		query.append(" and p.plan_id = cond_plan_id and us_value_id = COND_USAGE_VALUE ");
		query.append(" and t2.IDREF_TABLE_TITLE= US_TITLE_ID and t2.IDLANGUAGE= ");
		query.append(formatString(languageId));
		query.append(" and p.plan_id=INT_PLAN_ID ");

		query.append(" union ");

		query.append(" select distinct ");
		query.append(
				" MP_NUMBER, MP_VERSION,  MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status, plan_perf_type as PERFORMANCE,  ' ' as Usage, int_code ");
		query.append(" from mp_maintenance_project, ");
		query.append(" mp_project_applicability, ");
		query.append(" mp_maintenance_plan p ,mp_interval, mp_maintenance_condition ");
		query.append(" where plan_project_id = mp_id ");
		query.append(" and COND_USAGE_VALUE is null ");
		query.append(" and mp_id = MP_PROJECT_ID ");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and p.plan_id not in (select plan_id from mp_plan_applicability ) ");
		query.append(" and p.plan_id=INT_PLAN_ID ");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the maintenance project (With operations) to export for the WU.
	 * 
	 * @param idProject : id of the project
	 * @param languageId : EN for AG&CE, IT for CV
	 * @return the list of the project/plans
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getMaintenancePlansProjectWithOpforWUToExport(String idProject, String languageId) throws SystemException, ApplicativeException {
		StringBuilder query = new StringBuilder();
		int i = 0;

		// Create the query	
		query.append(" select distinct");
		query.append(" MP_NUMBER, MP_VERSION, MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status,");
		query.append(" plan_perf_type as PERFORMANCE, t2.message as Usage,  int_code, ope_code, ope_srt, t1.message as Message, t3.message as Label");
		query.append(
				" from mp_maintenance_project, mp_maintenance_plan p  , mp_plan_applicability app, mp_interval,mp_maintenance_condition, mp_usage_value, mp_interval_operation,mp_operation_series,");
		query.append(" mp_operation, table_title t2, table_title t1, table_title t3");
		query.append(" where plan_project_id  = mp_id");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and app.plan_id = p.plan_id");
		query.append(" and  p.plan_id=INT_PLAN_ID");
		query.append(" and p.plan_id = cond_plan_id and us_value_id = COND_USAGE_VALUE");
		query.append(" and t2.IDREF_TABLE_TITLE= US_TITLE_ID and t2.IDLANGUAGE= ");
		query.append(formatString(languageId));
		query.append(" and int_id = def_interval_id");
		query.append(" and def_ope_series_id = ope_ser_id");
		query.append(" and ope_operation_id = ope_id");
		query.append(" and ope_title_id = t1.IDREF_TABLE_TITLE");
		query.append(" and t1.IDLANGUAGE=");
		query.append(formatString(languageId));
		query.append(" and ope_label = t3.IDREF_TABLE_TITLE(+)");
		query.append(" and t3.IDLANGUAGE(+)=");
		query.append(formatString(languageId));

		query.append(" union");
		query.append(" select distinct");
		query.append(
				" MP_NUMBER, MP_VERSION,  MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status,");
		query.append(" plan_perf_type as PERFORMANCE, ' ' as Usage,  int_code, ope_code, ope_srt, t1.message as Message, t3.message as Label");
		query.append(
				" from mp_maintenance_project,mp_maintenance_plan p  , mp_plan_applicability app, mp_interval,mp_maintenance_condition,  mp_interval_operation,mp_operation_series, mp_operation, table_title t1, table_title t3");
		query.append(" where plan_project_id  = mp_id");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and app.plan_id = p.plan_id");
		query.append(" and p.plan_id=INT_PLAN_ID");
		query.append(" and p.plan_id = cond_plan_id");
		query.append(" and COND_USAGE_VALUE is null");
		query.append(" and int_id = def_interval_id");
		query.append(" and def_ope_series_id = ope_ser_id");
		query.append(" and ope_operation_id = ope_id");
		query.append(" and ope_title_id = t1.IDREF_TABLE_TITLE");
		query.append(" and t1.IDLANGUAGE=");
		query.append(formatString(languageId));
		query.append(" and ope_label = t3.IDREF_TABLE_TITLE(+)");
		query.append(" and t3.IDLANGUAGE(+)=");
		query.append(formatString(languageId));

		query.append(" union");
		query.append(" select distinct");
		query.append(
				" MP_NUMBER,  MP_VERSION, MP_NAME, mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status, plan_perf_type as PERFORMANCE,");
		query.append(" decode(t2.IDREF_TABLE_TITLE,'78','Heavy-Duty','79','Long distances','80','Road') as Usage, int_code, ope_code, ope_srt, t1.message as Message, t3.message as Label");
		query.append(
				" from mp_maintenance_project,mp_maintenance_plan p ,mp_interval, mp_maintenance_condition,mp_usage_value,table_title t2,mp_interval_operation,mp_operation_series, mp_operation, table_title t1, table_title t3");
		query.append(" where plan_project_id = mp_id");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and p.plan_id not in (select plan_id from mp_plan_applicability )");
		query.append(" and p.plan_id = cond_plan_id and us_value_id = COND_USAGE_VALUE");
		query.append(" and  t2.IDREF_TABLE_TITLE= US_TITLE_ID and t2.IDLANGUAGE=");
		query.append(formatString(languageId));
		query.append(" and  p.plan_id=INT_PLAN_ID");
		query.append(" and int_id = def_interval_id");
		query.append(" and def_ope_series_id = ope_ser_id");
		query.append(" and ope_operation_id = ope_id");
		query.append(" and ope_title_id = t1.IDREF_TABLE_TITLE");
		query.append(" and t1.IDLANGUAGE= ");
		query.append(formatString(languageId));
		query.append(" and ope_label = t3.IDREF_TABLE_TITLE(+)");
		query.append(" and t3.IDLANGUAGE(+)=");
		query.append(formatString(languageId));

		query.append(" union");
		query.append(
				" select distinct MP_NUMBER, MP_VERSION,  MP_NAME , mp_interval.INT_REPAIR_TIME, decode(MP_STATUS,0,'PRELIMINARY',1,'RELEASED',2,'OBSOLETE') as MP_STATUS_LABEL, p.plan_id, plan_name,plan_status,");
		query.append(" plan_perf_type as PERFORMANCE,  ' ' as Usage, int_code, ope_code, ope_srt, t1.message as Message, t3.message as Label");
		query.append(
				" from mp_maintenance_project, mp_maintenance_plan p ,mp_interval, mp_maintenance_condition,mp_interval_operation,mp_operation_series, mp_operation, table_title t1, table_title t3");
		query.append(" where COND_USAGE_VALUE is null");
		query.append(" and plan_project_id = mp_id");
		query.append(" AND  mp_id = ");
		query.append(formatString(idProject));
		query.append(" and p.plan_id not in (select plan_id from mp_plan_applicability )");
		query.append(" and p.plan_id=INT_PLAN_ID");
		query.append(" and int_id = def_interval_id");
		query.append(" and def_ope_series_id = ope_ser_id");
		query.append(" and ope_operation_id = ope_id");
		query.append(" and ope_title_id = t1.IDREF_TABLE_TITLE");
		query.append(" and t1.IDLANGUAGE= ");
		query.append(formatString(languageId));
		query.append(" and ope_label = t3.IDREF_TABLE_TITLE(+)");
		query.append(" and t3.IDLANGUAGE(+)=");
		query.append(formatString(languageId));

		return executeQueryN(query.toString());
	}

	/**
	 * Get the project without user information.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getMaintenanceProjectWithoutUser(String idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct mp_maintenance_project.* ");
		query.append(" FROM  mp_maintenance_project ");
		query.append(" WHERE MP_ID = ");
		query.append(formatString(idProject));

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get next id for version.
	 * 
	 * @param mpNumber : MP number
	 * @return the next id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long getNextId(String mpNumber) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT (MAX(MP_VERSION) +1) AS ID FROM MP_MAINTENANCE_PROJECT ");
		query.append("WHERE MP_NUMBER = ");
		query.append(formatString(mpNumber));

		return executeQueryCount(query.toString(), "ID");
	}

	/**
	 * Get max MP_NUMERO to calculate the next one.
	 * 
	 * @return the next project number
	 * @throws SystemException system exception
	 */
	public Long searchExistingMPNumber() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" select max(to_number(MP_NUMBER)) as MP_NUMBER");
		query.append(" from MP_MAINTENANCE_PROJECT");

		return executeQueryCount(query.toString(), "MP_NUMBER");
	}

	/**
	 * Get the List of existing projects with same number and version.
	 * 
	 * @param number filter
	 * @param version filter
	 * @param id filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 */
	public List<ProjectDto> getListForNumberAndVersion(String number, String version, String id) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" SELECT MP_Maintenance_project.* ");
		query.append(" FROM  MP_Maintenance_project ");
		query.append(" WHERE MP_NUMBER = ");
		query.append(formatString(number));
		query.append(" AND MP_VERSION = ");
		query.append(formatString(version));
		query.append(" AND MP_ID <> ");
		query.append(id);

		return executeQueryN(query.toString());
	}

	/**
	 * Get released project()s with a higher version.
	 * 
	 * @param number : number of the project
	 * @param version : version of the project
	 * @return the project(s) with a higher version already exported.
	 * @throws SystemException System exception
	 */
	public List<ProjectDto> getReleasedProjectsWithHigherVersion(String number, String version) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("Select MP_Maintenance_project.* ");
		query.append(" from MP_Maintenance_project ");
		query.append(" where MP_NUMBER = ");
		query.append(formatString(number));
		query.append(" and MP_VERSION > ");
		query.append(formatString(version));
		query.append(" and MP_STATUS = 1 ");

		return executeQueryN(query.toString());
	}

	/**
	 * Get the last version project, Released or Preliminary.
	 * 
	 * @param project the current project
	 * @return the previous project exported
	 * @throws SystemException SystemException
	 */
	public ProjectDto getLastVersion(ProjectDto project) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(
				"select distinct MP_NUMBER, MP_ID,  MP_NAME, MP_LAST_MODIFIER, MP_STATUS, MP_PERSONALIZED, MP_HAS_CONTRACT, MP_RLS_TYPE, MP_DATE_CREATION, MP_DATE_MODIF, MP_VERSION, MP_COMMENT ");
		query.append("from MP_Maintenance_project exp1 ");
		query.append("where MP_NUMBER =  ");
		query.append(formatString(project.getNumber()));
		query.append(" and MP_VERSION = (select max(exp2.MP_VERSION) ");
		query.append(" from MP_Maintenance_project exp2 ");
		query.append(" where exp2.MP_NUMBER = exp1.MP_NUMBER) ");

		return executeQuery1(query.toString());
	}

	/**
	 * Update release type of all the versions of the project that are in Preliminary.
	 * 
	 * @param projectNumber the project number
	 * @throws SystemException SystemException
	 */
	public void updateReleaseTypeOfAllVersionsForProject(ProjectDto project) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" update MP_Maintenance_project set ");
		query.append(" MP_RLS_TYPE = ");
		query.append(project.getReleaseType());
		query.append(" WHERE MP_number = ");
		query.append(formatString(project.getNumber()));

		executeQueryI("MP_Maintenance_project", query.toString());
	}

	/**
	 * Set the last report generated for check consistency.
	 * 
	 * @param idProject the project id
	 * @param fileName the report file name
	 * 
	 * @throws SystemException SystemException
	 */
	public void setLastReport(Long idProject, String fileName) throws SystemException {
		StringBuilder query = new StringBuilder("update MP_MAINTENANCE_PROJECT");
		query.append(" set MP_LAST_REPORT = ").append(formatString(fileName));
		query.append(" WHERE MP_ID = ").append(idProject);

		executeQueryI(query.toString());
	}

	/**
	 * Set the flag to true/false if a project must be displayed or not in tabs (for a selected series).
	 * 
	 * @param flag the flag to put
	 * @param projectId the id of the project
	 * 
	 * @throws SystemException SystemException
	 */
	public void updateLink(Boolean flag, String projectId) throws SystemException {
		StringBuilder query = new StringBuilder("update MP_MAINTENANCE_PROJECT");
		if (flag)
		{
			query.append(" set MP_IS_SELECTED = ").append("1");
		}
		else
		{
			query.append(" set MP_IS_SELECTED = ").append("0");
		}
		query.append(" WHERE MP_ID = ").append(projectId);

		executeQueryI(query.toString());
	}

	/**
	 * Get the List of projects associated to an operation.
	 * (used for the delete of an operation)
	 * 
	 * @param idOperation to filter
	 * @return the list of associated projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<ProjectDto> getListOfProjectsLinkedToAnOp(String idOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append(" select distinct mp_id, mp_name, mp_number, mp_version ");
		query.append(" from mp_maintenance_project , mp_operation_series ");
		query.append(" WHERE  mp_id = ope_mp_id  ");
		query.append(" AND ope_operation_id = ");
		query.append(idOperation);

		return executeQueryN(query.toString());
	}

	/**
	 * Get the project associated to a given operation and an project Id.
	 * 
	 * @param idOperation to filter
	 * @param idPrj to filter
	 * @return the associated project
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getProjectLinkedToAnOpAndPrjId(String idOperation, String idPrj) throws SystemException, ApplicativeException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" select distinct mp_id ");
		query.append(" from mp_maintenance_project , mp_operation_series ");
		query.append(" WHERE  mp_id = ope_mp_id  ");
		query.append(" AND ope_operation_id = ");
		query.append(idOperation);
		query.append(" AND mp_id = ");
		query.append(idPrj);
		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * set the project selected in tab.
	 * 
	 * @param projectId to filter
	 * @param isSelected : is_selected to set
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void updatePrjSelected(String projectId, Boolean isSelected) throws SystemException {

		StringBuilder query = new StringBuilder("update MP_MAINTENANCE_PROJECT");
		if (isSelected)
		{
			query.append(" set MP_IS_SELECTED = ").append("1");
		}
		else
		{
			query.append(" set MP_IS_SELECTED = ").append("0");
		}
		query.append(" WHERE MP_ID = ").append(projectId);

		executeQueryI("MP_Maintenance_project", query.toString());

	}

	/**
	 * Get all preliminary projects.
	 * 
	 * @return the list of projects
	 * @throws SystemException
	 */
	public List<ProjectDto> getAllPreliminaryProjects() throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	

		query.append(" select * from mp_project_applicability, mp_maintenance_project  where mp_status = 0 and mp_id = mp_project_id order by 3,4,5,6 ");

		return executeQueryN(query.toString());

	}

}
