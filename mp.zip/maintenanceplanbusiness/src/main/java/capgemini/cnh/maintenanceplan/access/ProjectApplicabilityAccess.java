/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;

/**
 * @author sdomecq
 *
 */
public class ProjectApplicabilityAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public ProjectApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		ProjectDto dto = new ProjectDto();

		dto.setApplicabilityId(getLongIfExists("MP_APPLI_ID"));

		dto.setId(getLongIfExists("MP_PROJECT_ID"));

		dto.setApplicabilityBrandIceCode(getStringIfExists("MP_APP_BRA"));
		dto.setApplicabilityTypeIceCode(getStringIfExists("MP_APP_TYP"));
		dto.setApplicabilityProductIceCode(getStringIfExists("MP_APP_PRO"));
		dto.setApplicabilitySeriesIceCode(getStringIfExists("MP_APP_SER"));

		dto.setApplicabilityLabel(getStringIfExists("SER_LABEL"));

		dto.setTimesheet(getLongIfExists("MP_ID"));
		dto.setTimesheetColumn(getStringIfExists("MP_TIMESHEET"));

		return dto;

	}

	/**
	 * add project applicability.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(ProjectDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		if (dto.getApplicabilityId() == null)
		{
			dto.setApplicabilityId(getNextId());
			query.append("INSERT INTO MP_PROJECT_APPLICABILITY ( MP_APPLI_ID, MP_PROJECT_ID, MP_APP_BRA, MP_APP_TYP, MP_APP_PRO, MP_APP_SER) values (");
			query.append(dto.getApplicabilityId().toString());
			query.append(",");
			query.append(dto.getId().toString());
			query.append(",");
			query.append(formatString(dto.getApplicabilityBrandIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilityTypeIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilityProductIceCode()));
			query.append(",");
			query.append(formatString(dto.getApplicabilitySeriesIceCode()));

			query.append(")");

			executeQueryI("MP_PROJECT_APPLICABILITY", query.toString());
		}

	}

	/**
	 * delete applicability by project.
	 * 
	 * @param projectId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String projectId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_PROJECT_APPLICABILITY  WHERE MP_PROJECT_ID = ");
		query.append(projectId);

		executeQueryI("MP_PROJECT_APPLICABILITY", query.toString());
	}

	/**
	 * Get the next id in the sequence.
	 * 
	 * @return the next id
	 * @throws SystemException system exception
	 */
	private Long getNextId() throws SystemException {
		String query = "Select SQ_MP_PROJECT_APPLICABILITY.nextval as NEXT from dual";
		return executeQueryCount(query, "NEXT");
	}

	/**
	 * Get the project applicability.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getApp(String idProject) throws SystemException {
		StringBuilder query = new StringBuilder();

		// Create the query	
		query.append(" SELECT distinct mp_project_applicability.*, serie.a_name SER_LABEL ");
		query.append(" FROM  mp_project_applicability, BRAND, TYPE, PRODUCT, SERIE ");
		query.append(" WHERE  BRAND.A_ID = SERIE.BRA_A_ID AND PRODUCT.A_ID = SERIE.PRO_A_ID  ");
		query.append(" AND TYPE.A_ID = SERIE.TYP_A_ID  and (BRAND.A_ICE_CODE = mp_project_applicability.MP_APP_BRA  ");
		query.append(" AND TYPE.A_ICE_CODE = mp_project_applicability.MP_APP_TYP ");
		query.append(" AND PRODUCT.A_ICE_CODE = mp_project_applicability.MP_APP_PRO");
		query.append(" AND SERIE.A_ICE_CODE = mp_project_applicability.MP_APP_SER )");
		query.append(" AND MP_PROJECT_ID = ");
		query.append(formatString(idProject));

		ProjectDto result = (ProjectDto) executeQuery1(query.toString());

		return result;
	}

}
