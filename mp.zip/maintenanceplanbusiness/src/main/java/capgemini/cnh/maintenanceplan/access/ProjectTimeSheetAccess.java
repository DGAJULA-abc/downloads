/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.ProjectTimeSheetDto;

/**
 * @author sdomecq
 *
 */
public class ProjectTimeSheetAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public ProjectTimeSheetAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		ProjectTimeSheetDto dto = new ProjectTimeSheetDto();

		dto.setIdApplicability(getLongIfExists("MP_ID"));

		dto.setTimesheet(getStringIfExists("MP_TIMESHEET"));
		dto.setColumn(getLongIfExists("MP_TIMESHEET_COLUMN"));

		return dto;

	}

	/**
	 * add project time sheet.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(ProjectTimeSheetDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO MP_APPLICABILITY_TS ( MP_ID, MP_TIMESHEET, MP_TIMESHEET_COLUMN) values (");
		query.append(dto.getIdApplicability().toString());
		query.append(", ");
		query.append(formatString(dto.getTimesheet()));
		query.append(", ");
		if (dto.getColumn() != null)
		{
			query.append(dto.getColumn().toString());
		}
		else
		{
			query.append("null");
		}

		query.append(")");

		executeQueryI("MP_APPLICABILITY_TS", query.toString());

	}

	/**
	 * delete applicability by project.
	 * 
	 * @param projectId to delete
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String projectId) throws SystemException {
		StringBuilder query = new StringBuilder();

		//delete from MP_APPLICABILITY_TS where mp_id in (select distinct MP_APPLI_ID from  MP_PROJECT_APPLICABILITY  WHERE MP_PROJECT_ID=3)

		query.append("delete from MP_APPLICABILITY_TS where mp_id in (select distinct MP_APPLI_ID from  MP_PROJECT_APPLICABILITY  WHERE MP_PROJECT_ID = ");
		query.append(projectId);
		query.append(" )");

		executeQueryI("MP_APPLICABILITY_TS", query.toString());
	}

}
