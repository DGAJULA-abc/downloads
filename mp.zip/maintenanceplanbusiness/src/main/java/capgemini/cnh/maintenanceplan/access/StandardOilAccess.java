package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.StandardOilDto;

/**
 * Access class for the standard oils.
 * 
 * @author mdaudign
 */
public class StandardOilAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public StandardOilAccess() throws SystemException {
		super();
	}

	/**
	 * Check if an oil is standard for a project.
	 * 
	 * @param oilId the id of the oil
	 * @param projectId the id of the project
	 * @return a StandardOilDto if the oil is standard, null if not
	 * @throws SystemException Cannot execute query or access to database
	 * @throws ApplicativeException application exception
	 */
	public StandardOilDto isStandard(String projectId, Long oilId) throws SystemException, ApplicativeException {
		StandardOilDto result = null;
		StringBuilder query = new StringBuilder();

		query.append(" select OIL_STD_ID, OIL_PROJECT, OIL_ID");
		query.append(" from MP_STD_OIL");
		query.append(" where OIL_ID = ");
		query.append(oilId);
		query.append(" and OIL_PROJECT = ");
		query.append(projectId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		if (lstFound.size() > 0)
		{
			result = (StandardOilDto) lstFound.get(0);
		}
		return result;
	}

	/**
	 * Add a standard oil.
	 * 
	 * @param dto the oil
	 * @throws SystemException Cannot execute query or access to database
	 */
	public void addStandardOil(StandardOilDto dto) throws SystemException {
		StringBuilder query = new StringBuilder();

		if (dto.getOilStdId() == null)
		{
			query.append("insert into MP_STD_OIL (OIL_PROJECT, OIL_ID) values (");
			query.append(dto.getProjectId());
			query.append(",");
			query.append(dto.getOilId());
			query.append(")");

			executeQueryI("MP_STD_OIL", query.toString());
		}
	}

	/**
	 * Delete a standard oil.
	 * 
	 * @param dto the oil
	 * @throws SystemException Cannot execute query or access to database
	 */
	public void deleteStandardOil(StandardOilDto dto) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("delete from MP_STD_OIL where OIL_PROJECT = ");
		query.append(dto.getProjectId());
		query.append(" and OIL_ID = ");
		query.append(dto.getOilId());

		executeQueryI("MP_STD_OIL", query.toString());
	}

	/**
	 * Get the standard oils for a project.
	 * 
	 * @param projectId the id of the project
	 * @return a list of standard oils
	 * @throws SystemException Cannot execute query or access to database
	 */
	public List<StandardOilDto> getListOilsByProject(String projectId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select OIL_STD_ID, OIL_PROJECT, OIL_ID");
		query.append(" from MP_STD_OIL");
		query.append(" where OIL_PROJECT = ");
		query.append(projectId);

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<StandardOilDto> result = new ArrayList<StandardOilDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((StandardOilDto) dto);
		}

		return result;
	}

	/**
	 * Delete the standard oils for a project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_STD_OIL where OIL_PROJECT = ");
		query.append(idProject);

		executeQueryI("MP_STD_OIL", query.toString());
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		StandardOilDto dto = new StandardOilDto();

		dto.setOilStdId(getLongIfExists("OIL_STD_ID"));
		dto.setProjectId(getIntIfExists("OIL_PROJECT"));
		dto.setOilId(getLongIfExists("OIL_ID"));

		return dto;
	}
}
