package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.StandardOilApplicabilityDto;

/**
 * Access class for the standard oil applicability.
 * 
 * @author mdaudign
 */
public class StandardOilApplicabilityAccess extends OracleAccess {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public StandardOilApplicabilityAccess() throws SystemException {
		super();
	}

	/**
	 * Add applicability for a standard oil.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void add(StandardOilApplicabilityDto dto) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("INSERT INTO MP_STD_OIL_APPLICABILITY (OIL_STD_ID, OIL_MOD, OIL_TT, OIL_MARKET, OIL_CONFIG) values (");
		query.append(dto.getIdStdOil());
		query.append(",");
		query.append(formatString(dto.getModel()));
		query.append(",");
		query.append(formatString(dto.getTt()));
		query.append(",");
		query.append(dto.getMarket());
		query.append(",");
		query.append(formatString(dto.getConfig()));
		query.append(")");

		executeQueryI("MP_STD_OIL_APPLICABILITY", query.toString());
	}

	/**
	 * Delete applicability for a standard oil.
	 * 
	 * @param idOil to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByOilId(String idOil) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_STD_OIL_APPLICABILITY where OIL_STD_ID = ");
		query.append(idOil);

		executeQueryI("MP_STD_OIL_APPLICABILITY", query.toString());
	}

	/**
	 * Delete for a given project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void deleteByProjectId(String idProject) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("delete from MP_STD_OIL_APPLICABILITY where OIL_STD_ID in (select distinct OIL_STD_ID from MP_STD_OIL where OIL_PROJECT = ");
		query.append(idProject);
		query.append(" )");

		executeQueryI("MP_STD_OIL_APPLICABILITY", query.toString());
	}

	/**
	 * Get the List of applicability for an oil.
	 * 
	 * @param idStdOil oil id filter
	 * @return the list of applicabilities
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<StandardOilApplicabilityDto> getListOilApplicability(String idStdOil) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("select * from MP_STD_OIL_APPLICABILITY");
		query.append(" where MP_STD_OIL_APPLICABILITY.OIL_STD_ID = ");
		query.append(formatString(idStdOil));

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<StandardOilApplicabilityDto> result = new ArrayList<StandardOilApplicabilityDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((StandardOilApplicabilityDto) dto);
		}

		return result;
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		StandardOilApplicabilityDto dto = new StandardOilApplicabilityDto();

		dto.setId(getLongIfExists("OIL_APP_ID"));
		dto.setIdStdOil(getLongIfExists("OIL_STD_ID"));
		dto.setModel(getStringIfExists("OIL_MOD"));
		dto.setTt(getStringIfExists("OIL_TT"));
		dto.setMarket(getLongIfExists("OIL_MARKET"));
		dto.setConfig(getStringIfExists("OIL_CONFIG"));

		return dto;
	}
}
