/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.UnitSeriesDto;

/**
 * @author langlade
 *
 */
public class UnitSeriesAccess extends OracleAccess<UnitSeriesDto> {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public UnitSeriesAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * 
	 * @throws SQLException an exception
	 * 
	 * @return a Dto
	 */
	protected UnitSeriesDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		UnitSeriesDto dto = new UnitSeriesDto();

		dto.setBrandIceCode(getString("UNITSER_APP_BRA"));
		dto.setTypeIceCode(getString("UNITSER_APP_TYP"));
		dto.setProductIceCode(getString("UNITSER_APP_PRO"));
		dto.setSeriesIceCode(getString("UNITSER_APP_SER"));
		dto.setUnit(getString("UNITSER_UNIT"));
		dto.setUnitKey(getString("UNITSER_UNIT_KEY"));

		return dto;
	}

	/**
	 * Get the List of unit series.
	 * 
	 * @return the list of unit series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<UnitSeriesDto> getList() throws SystemException {

		// Create the query
		String query = "select * from MP_UNIT_SERIES";

		// Execute the query and get the result list
		List<UnitSeriesDto> lstFound = executeQueryN(query);

		return lstFound;
	}

	/**
	 * Get the special unit for the ice code.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @return The special unit
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public UnitSeriesDto getFromIceCode(
			String brandIceCode, String typeIceCode,
			String productIceCode, String seriesIceCode) throws SystemException {

		// Create the query
		StringBuilder query = new StringBuilder("select * from MP_UNIT_SERIES");
		query.append(" where UNITSER_APP_BRA = '").append(brandIceCode).append("'");
		query.append(" and UNITSER_APP_TYP = '").append(typeIceCode).append("'");
		query.append(" and UNITSER_APP_PRO = '").append(productIceCode).append("'");
		query.append(" and UNITSER_APP_SER = '").append(seriesIceCode).append("'");

		// Execute the query and get the result list
		UnitSeriesDto unitSeries = executeQuery1(query.toString());

		return unitSeries;
	}

	/**
	 * Delete a specific unit.
	 * 
	 * @param unitSeries The unit series to delete
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean delete(UnitSeriesDto unitSeries) throws SystemException {
		StringBuilder query = new StringBuilder("delete from MP_UNIT_SERIES ");
		query.append("where UNITSER_APP_BRA = '").append(unitSeries.getBrandIceCode()).append("' ");
		query.append("and UNITSER_APP_TYP = '").append(unitSeries.getTypeIceCode()).append("' ");
		query.append("and UNITSER_APP_PRO = '").append(unitSeries.getProductIceCode()).append("' ");
		query.append("and UNITSER_APP_SER = '").append(unitSeries.getSeriesIceCode()).append("' ");
		query.append("and UNITSER_UNIT_KEY = '").append(unitSeries.getUnitKey()).append("'");

		return executeQueryI(query.toString()).equals(1L);
	}

	/**
	 * Clone an original specific unit to a destination specific unit.
	 * 
	 * @param originalUnitSeries the original specific unit to clone
	 * @param brandIceCodeDestination brand ice code of the series of the destination specific unit
	 * @param typeIceCodeDestination type ice code of the series of the destination specific unit
	 * @param productIceCodeDestination product ice code of the series of the destination specific unit
	 * @param seriesIceCodeDestination series ice code of the series of the destination specific unit
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean clone(
			UnitSeriesDto originalUnitSeries,
			String brandIceCodeDestination, String typeIceCodeDestination,
			String productIceCodeDestination, String seriesIceCodeDestination) throws SystemException {
		StringBuilder query = new StringBuilder("insert into MP_UNIT_SERIES ");
		query.append("(UNITSER_APP_BRA, UNITSER_APP_TYP, UNITSER_APP_PRO, UNITSER_APP_SER, ");
		query.append("UNITSER_UNIT_KEY, UNITSER_UNIT, UNITSER_TOLERANCE_DELTA, UNITSER_TOLERANCE_FAR) ");
		query.append("select '").append(brandIceCodeDestination).append("', '");
		query.append(typeIceCodeDestination).append("', '");
		query.append(productIceCodeDestination).append("', '");
		query.append(seriesIceCodeDestination).append("', ");
		query.append("UNITSER_UNIT_KEY, UNITSER_UNIT, UNITSER_TOLERANCE_DELTA, UNITSER_TOLERANCE_FAR ");
		query.append("from MP_UNIT_SERIES ");
		query.append("where UNITSER_APP_BRA = '").append(originalUnitSeries.getBrandIceCode()).append("' ");
		query.append("and UNITSER_APP_TYP = '").append(originalUnitSeries.getTypeIceCode()).append("' ");
		query.append("and UNITSER_APP_PRO = '").append(originalUnitSeries.getProductIceCode()).append("' ");
		query.append("and UNITSER_APP_SER = '").append(originalUnitSeries.getSeriesIceCode()).append("'");

		return ! executeQueryI(query.toString()).equals(0L);
	}
}
