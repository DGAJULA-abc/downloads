/**
 * 
 */
package capgemini.cnh.maintenanceplan.access;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class UsageAccess extends OracleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public UsageAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected Dto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		UsageDto dto = new UsageDto();

		dto.setValueId(getLongIfExists("US_VALUE_ID"));
		dto.setValueTitle(getStringIfExists("VALUE_TITLE"));
		dto.setValueTitleId(getLongIfExists("US_TITLE_ID"));

		dto.setItemId(getLongIfExists("US_ITEM_ID"));
		dto.setItemTitle(getStringIfExists("ITEM_TITLE"));
		dto.setItemTitleId(getLongIfExists("US_ITEM_TITLE_ID"));

		return dto;

	}

	/**
	 * Get the List of usages .
	 * 
	 * @param language to display
	 * @return the list of usages
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<UsageDto> getList(String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		// Create the query	
		//		select i.US_ITEM_ID, i.US_ITEM_TITLE_ID, ti.message ITEM_TITLE, v.US_VALUE_ID, v.US_TITLE_ID , tv.message VALUE_TITLE
		//		from mp_usage_item i, mp_usage_value v, table_title ti, table_title tv
		//		where v.us_item_id=i.us_item_id
		//		and i.US_ITEM_TITLE_ID = ti.idref_table_title
		//		and ti.idlanguage = 'IT'
		//		and v.US_TITLE_ID = tv.idref_table_title
		//		and tv.idlanguage = 'IT';

		query.append(" select i.US_ITEM_ID, i.US_ITEM_TITLE_ID, ti.message ITEM_TITLE, v.US_VALUE_ID, v.US_TITLE_ID , tv.message VALUE_TITLE ");
		query.append(" from mp_usage_item i, mp_usage_value v, table_title ti, table_title tv ");
		query.append(" where v.us_item_id=i.us_item_id ");
		query.append(" and i.US_ITEM_TITLE_ID = ti.idref_table_title ");
		query.append(" and ti.idlanguage = ");
		query.append(formatString(language));
		query.append(" and v.US_TITLE_ID = tv.idref_table_title ");
		query.append("and tv.idlanguage = ");
		query.append(formatString(language));

		// Execute the query and get the result list
		List<Dto> lstFound = executeQueryN(query.toString());
		List<UsageDto> result = new ArrayList<UsageDto>(lstFound.size());

		for (Dto dto : lstFound)
		{
			result.add((UsageDto) dto);
		}

		return result;
	}

}
