/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.access.CheckSeriesAccess;
import capgemini.cnh.maintenanceplan.dto.CheckSeriesDto;

/**
 * @author langlade
 *
 */
public class CheckSeriesBusiness extends Business<CheckSeriesDto> {

	/**
	 * Pending status.
	 */
	public static final byte STATUS_PENDING = 0;
	/**
	 * Warn status.
	 */
	public static final byte STATUS_WARN = -2;
	/**
	 * Error status.
	 */
	public static final byte STATUS_ERROR = -1;

	/**
	 * Define a logger.
	 */
	private static final TIDBLogger LOGGER = TIDBLogger.getLogger(CheckSeriesBusiness.class);

	/**
	 * Data source access.
	 */
	private final CheckSeriesAccess access;

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public CheckSeriesBusiness() throws SystemException {
		this(new CheckSeriesAccess());
	}

	/**
	 * Constructor.
	 * 
	 * @param access Data source access
	 * 
	 * @throws SystemException system exception
	 */
	private CheckSeriesBusiness(final CheckSeriesAccess access) throws SystemException {
		super(access);
		this.access = access;
	}

	/**
	 * Get the List of check series.
	 * 
	 * @return the list of check series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<CheckSeriesDto> getList() throws SystemException, ApplicativeException {
		final List<CheckSeriesDto> result = access.getList();
		return result;
	}

	/**
	 * Get the check series from the ice code.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @return The check series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public CheckSeriesDto getCheckSeries(
			final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode) throws SystemException {
		final CheckSeriesDto result = access.getFromIceCode(brandIceCode, typeIceCode, productIceCode, seriesIceCode);
		return result;
	}

	/**
	 * Create the check series.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * @param projectName name of the project
	 * @param projectNumber number of the project
	 * @param projectVersion version of the project
	 * @param isForRelease is for release the project
	 * 
	 * @return Inserted dto
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public CheckSeriesDto create(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode,
			final String projectName, final String projectNumber, final Integer projectVersion,
			final boolean isForRelease) throws SystemException {
		final CheckSeriesDto checkSeries = access.insert(brandIceCode, typeIceCode, productIceCode, seriesIceCode, projectName, projectNumber, projectVersion, isForRelease);

		if (checkSeries == null)
		{
			LOGGER.error("create : error creating the check series");
		}

		return checkSeries;
	}

	/**
	 * Set the check series report.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * @param report check series report
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void setReport(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode,
			final String report) throws SystemException {
		if (! access.updateReport(brandIceCode, typeIceCode, productIceCode, seriesIceCode, report))
		{
			LOGGER.error("setReport : error updating the check series");
		}
	}

	/**
	 * Set the check series in warn status.
	 * 
	 * @param checkSeries Check series to update
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void setWarn(final CheckSeriesDto checkSeries) throws SystemException {
		if (! access.update(checkSeries, STATUS_WARN,
				null, null, null, null, null, null, null, null, null, null, null))
		{
			LOGGER.error("setWarn : error updating the check series");
		}
	}

	/**
	 * Set the check series in warn status, with the given parameters for save.
	 * 
	 * @param checkSeries Check series to update
	 * @param selectedId project id
	 * @param selectedstatus project status
	 * @param selectedAppliId appli id
	 * @param personalized personalized
	 * @param oldstatus old porject status
	 * @param standardOils std oil string containing the data
	 * @param lastModifier last modifier
	 * @param hasContract has contract
	 * @param releaseType release type
	 * @param isUcr is UCR
	 * @param customer customer
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void setWarnForRelease(final CheckSeriesDto checkSeries,
			String selectedId, String selectedstatus, String selectedAppliId, String personalized,
			String oldstatus, String standardOils, String lastModifier, String hasContract,
			String releaseType, String isUcr, String customer) throws SystemException {
		if (! access.update(checkSeries, STATUS_WARN,
				selectedId, selectedstatus, selectedAppliId, personalized,
				oldstatus, standardOils, lastModifier, hasContract,
				releaseType, isUcr, customer))
		{
			LOGGER.error("setWarnForRelease : error updating the check series");
		}
	}

	/**
	 * Set the check series in error status.
	 * 
	 * @param checkSeries Check series to update
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void setError(final CheckSeriesDto checkSeries) throws SystemException {
		if (! access.update(checkSeries, STATUS_ERROR,
				null, null, null, null, null, null, null, null, null, null, null))
		{
			LOGGER.error("setWarn : error updating the check series");
		}
	}

	/**
	 * Delete the check series.
	 * 
	 * @param checkSeries Check series finished with success
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void finishedSuccess(final CheckSeriesDto checkSeries) throws SystemException {
		if (! access.delete(checkSeries.getBrandIceCode(), checkSeries.getTypeIceCode(), checkSeries.getProductIceCode(), checkSeries.getSeriesIceCode()))
		{
			LOGGER.error("finishedSuccess : error deleting the check series");
		}
	}

	/**
	 * Delete the check series.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public void delete(final String brandIceCode, final String typeIceCode,
			final String productIceCode, final String seriesIceCode) throws SystemException {
		if (! access.delete(brandIceCode, typeIceCode, productIceCode, seriesIceCode))
		{
			LOGGER.error("delete : error deleting the check series");
		}
	}
}
