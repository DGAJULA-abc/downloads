/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.CloneSeriesAccess;
import capgemini.cnh.maintenanceplan.dto.CloneSeriesDto;

/**
 * @author mamestoy
 *
 */
public class CloneSeriesBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public CloneSeriesBusiness() throws SystemException {
		super();
	}

	/**
	 * save projects and plans for the cloning.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(CloneSeriesDto dto) throws SystemException, ApplicativeException {
		new CloneSeriesAccess().add(dto);
	}

	/**
	 * Get the corresponding record for project id src and plan ext id src .
	 * 
	 * @param dto the dto to get
	 * @return the list of clone series for prj/plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public CloneSeriesDto getRecordCloneForPrjPlanSrc(CloneSeriesDto dto) throws SystemException, ApplicativeException {

		return new CloneSeriesAccess().getRecordCloneForPrjPlanSrc(dto);
	}

	/**
	 * Get the corresponding record for project id dest and plan ext id dest .
	 * 
	 * @param dto the dto to get
	 * @return the list of clone series for prj/plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public CloneSeriesDto getRecordCloneForPrjPlanDest(CloneSeriesDto dto) throws SystemException, ApplicativeException {

		return new CloneSeriesAccess().getRecordCloneForPrjPlanDest(dto);
	}

}
