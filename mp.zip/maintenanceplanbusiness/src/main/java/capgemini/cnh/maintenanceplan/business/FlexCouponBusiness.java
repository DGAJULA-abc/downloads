package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.FlexCouponAccess;
import capgemini.cnh.maintenanceplan.dto.MpFlexCouponDto;

/**
 * @author mmartel
 *
 */
public class FlexCouponBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public FlexCouponBusiness() throws SystemException {
		super();
	}

	/**
	 * get list of potential flexible coupons.
	 * 
	 * @return get list of potential flexible coupons.
	 * @throws SystemException system exception
	 */
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		return new FlexCouponAccess().getFlexibleCoupons();
	}

}
