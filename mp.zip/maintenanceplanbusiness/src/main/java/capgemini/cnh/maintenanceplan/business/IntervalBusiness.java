/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import capgemini.cnh.cnhadmin.util.UtilConfiguration;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ResourceLabel;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.icedata.dto.IceElementDto;
import capgemini.cnh.location.business.SubGroupsBusiness;
import capgemini.cnh.maintenanceplan.access.IntervalAccess;
import capgemini.cnh.maintenanceplan.access.IntervalOperationAccess;
import capgemini.cnh.maintenanceplan.dto.ApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.ConfigurationDto;
import capgemini.cnh.maintenanceplan.dto.IntervalDto;
import capgemini.cnh.maintenanceplan.dto.IntervalFrequencyDto;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceApplicabilityDto;

/**
 * @author sdomecq
 *
 */
public class IntervalBusiness extends Business {

	/**
	 * Define a logger.
	 */
	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public IntervalBusiness() throws SystemException {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	//	public IntervalBusiness(TransactionAccess dbAccess) {
	//		super();
	//		this.dbAccess = dbAccess;
	//	}

	/**
	 * Get the List of interval .
	 * 
	 * @param idPlan filter
	 * @param lang source
	 * @return the list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalDto> getList(String idPlan, String lang) throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();
		List<IntervalDto> result = access.getList(idPlan, lang);
		return result;
	}

	/**
	 * deduce intervals from performances.
	 * 
	 * @param listPerf : liste of performance to filter
	 * @param idPlan : id of the plan
	 * @param perfType : max or harm
	 * @return list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalDto> deduceFromOnePerformance(List<Long> listPerf, String idPlan, String perfType) throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();
		List<IntervalDto> result = access.deduceFromPerformance(listPerf, perfType, idPlan, null);
		return result;
	}

	/**
	 * find intervals.
	 * 
	 * @param dto to find
	 * @return interval
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public IntervalDto findInterval(IntervalDto dto) throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();
		IntervalDto result = access.findInterval(dto);
		return result;
	}

	/**
	 * Get the List of intervals .
	 * 
	 * @param idPlan filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<IntervalDto> getIntervalsList(String idPlan) throws SystemException {
		IntervalAccess access = new IntervalAccess();
		List<IntervalDto> result = access.getIntervalsList(idPlan);
		return result;
	}

	/**
	 * Get all the interval codes used in the project.
	 * 
	 * @param idProject project id
	 * @param planStatus status of the plan
	 * @return the interval code list
	 * @throws SystemException SystemException
	 */
	public List<String> getIntervalCodesByProject(String idProject, Integer planStatus) throws SystemException {
		List<String> returnList = new ArrayList<String>();
		List<IntervalDto> intervalList = new IntervalAccess().getIntervalCodesByProject(idProject, planStatus);

		for (IntervalDto interval : intervalList)
		{
			if (!returnList.contains(interval.getCode()))
			{
				returnList.add(interval.getCode());
			}
		}

		return returnList;
	}

	/**
	 * Get the List of interval .
	 * 
	 * @param idPlan filter
	 * @param idPerf filter
	 * @param lang source
	 * @param configList config List
	 * @param listWarningPerf return the list of warning performance
	 * @param isIveco is IVECO customer
	 * @param locale locale
	 * @param specificUnitKey Key of the specific unit
	 * @return the list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalDto> getUpdatedList(String idPlan, String idPerf, String lang, Map<Long, Long> configList, List<Long> listWarningPerf, Boolean isIveco, Locale locale, String specificUnitKey)
			throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();
		List<IntervalDto> result = access.getList(idPlan, lang);
		// deduce intervals from performances
		if (result.size() == 0)
		{
			// deduce intervals from performances
			List<Long> resultListWarning = deduceIntervalFromPerformance(idPlan, idPerf, configList, lang, isIveco);
			listWarningPerf.addAll(resultListWarning);

			// get new generated data
			result = access.getList(idPlan, lang);

			// For AG&CE : For each Interval, get the Interval Code according to the performance
			if (!isIveco)
			{
				setIntervalCode(result, lang, locale, specificUnitKey);
			}
		}
		return result;
	}

	/**
	 * Set interval code according to the frequency.
	 * 
	 * @param list intervals list
	 * @param langId lang Id
	 * @param locale locale
	 * @param specificUnitKey Key of the specific unit
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void setIntervalCode(List<IntervalDto> list, String langId, Locale locale, String specificUnitKey) throws ApplicativeException, SystemException {

		IntervalFrequencyDto intFreqDto;

		if (list != null && list.size() >= 1)
		{
			// Check if the interval code belongs to the list of interval codes
			List<IceElementDto> sgList = new ArrayList<IceElementDto>();
			List<String> codeList = new ArrayList<String>();
			String mpIceCode = Context.getStringProperty("mp.code.location.ice.code");
			sgList = new SubGroupsBusiness().getSubGroupsByIceCodeGroup(mpIceCode, langId);
			for (IceElementDto dto : sgList)
			{
				codeList.add(dto.getDtoName().getName());
			}

			for (IntervalDto intDto : list)
			{
				intFreqDto = new IntervalFrequencyBusiness().findIntervalCode(intDto, specificUnitKey);
				if (intFreqDto != null)
				{
					if (codeList.contains(intFreqDto.getCode()))
					{
						intDto.setCode(intFreqDto.getCode());
						ResourceLabel ressource = ResourceLabel.getInstance();
						intDto.setType("X");
						//label.interval.type.x=AG&CE Interval
						String labelInt = ressource.getLabel("label.interval.type." + "x", locale);
						intDto.setTypeLabel(labelInt);
					}
					else
					{
						intDto.setCode("");
					}
				}
			}
		}
	}

	/**
	 * delete records for a given plan id.
	 * 
	 * @param idPlan to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteByPlan(String idPlan) throws SystemException, ApplicativeException {
		new IntervalAccess().deleteByPlan(idPlan);
	}

	/**
	 * save intervals.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(IntervalDto dto) throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();

		// try to find the same interval for update ...
		IntervalDto interval = access.findInterval(dto);
		if (interval != null)
		{
			dto.setId(interval.getId());
		}

		if (dto.getId() == null)
		{
			access.add(dto);
		}

	}

	/**
	 * save intervals defined by ser.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void update(IntervalDto dto) throws SystemException, ApplicativeException {
		new IntervalAccess().update(dto);
	}

	/**
	 * update interval with WU.
	 * 
	 * @param dto to save
	 * @param transaction
	 * @throws SystemException Cannot execute query or access to database.
	 */
	//	public void updatewithWU(IntervalDto dto, TransactionAccess transaction) throws SystemException, ApplicativeException {
	//		new IntervalAccess(transaction).updatewithWU(dto);
	//	}

	public void updatewithWU(IntervalDto dto) throws SystemException, ApplicativeException {
		new IntervalAccess().updatewithWU(dto);
	}

	/**
	 * update the List of interval from performance.
	 * 
	 * @param idPlan filter
	 * @param idPerf filter
	 * @param lang id of the lang
	 * @param configList configuration list
	 * @param listWarningPerf return the list of warning performance
	 * @return the list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalDto> updateFromPerformance(String idPlan, String idPerf, String lang, Map<Long, Long> configList, List<Long> listWarningPerf, Boolean isIveco)
			throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();

		// delete exiting data
		// MP_INTERVAL_OPERATION
		new IntervalOperationAccess().deleteByPlanId(idPlan);

		// deduce intervals from performances
		List<Long> listResultWarning = deduceIntervalFromPerformance(idPlan, idPerf, configList, lang, isIveco);
		listWarningPerf.addAll(listResultWarning);

		// get new generated data
		return access.getList(idPlan, lang);
	}

	/**
	 * deduce intervals from performances.
	 * 
	 * @param idPlan filter
	 * @param idPerf filter
	 * @param configList List
	 * @param isIveco is IVECO customer
	 * @return return the list of warning performance
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	private List<Long> deduceIntervalFromPerformance(String idPlan, String idPerf, Map<Long, Long> configList, String lang, Boolean isIveco)
			throws SystemException, ApplicativeException {
		List<Long> intervalIdList = new ArrayList<Long>();
		IntervalAccess access = new IntervalAccess();
		IntervalOperationAccess accessOperation = new IntervalOperationAccess();

		String toKeep = "";

		List<Long> listWarningPerf = new ArrayList<Long>();
		List<Long> performanceList = getApplicablePerformance(idPlan, configList, listWarningPerf, idPerf, isIveco);
		if (listWarningPerf.size() > 0)
		{
			access.deleteByPlan(idPlan);
		}
		else
		{
			long tps = System.currentTimeMillis();
			if (performanceList != null && performanceList.size() > 0)
			{
				//get intervals
				List<IntervalDto> intervals = access.deduceFromPerformance(performanceList, idPerf, idPlan, isIveco);
				for (IntervalDto interval : intervals)
				{
					boolean okTosave = false;

					if ((interval.getStartValueKm() != null) && (interval.getStartValueKm().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getStartValueMonth() != null) && (interval.getStartValueMonth().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getStartValueHour() != null) && (interval.getStartValueHour().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getAfterValueKm() != null) && (interval.getAfterValueKm().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getAfterValueMonth() != null) && (interval.getAfterValueMonth().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getAfterValueHour() != null) && (interval.getAfterValueHour().intValue() != 0))
					{
						okTosave = true;
					}
					if ((interval.getGroup() != null) && (interval.getGroup().intValue() != 0))
					{
						okTosave = true;
					}

					if (okTosave)
					{
						save(interval);
						if (interval.getId() != null)
						{
							if (!intervalIdList.contains(interval.getId()))
							{
								intervalIdList.add(interval.getId());
							}

							if (interval.getOperationBySeriesId() != null)
							{
								accessOperation.add(interval.getId().toString(), interval.getOperationBySeriesId().toString());
							}
						}
					}
				}

				// remove interval no more deduced.
				for (Long id : intervalIdList)
				{
					if (!toKeep.equals(""))
					{
						toKeep += ",";
					}
					toKeep += id.toString();
				}
			}
			logger.error("##################");
			logger.error("##################");
			logger.error("################## DEDUCE FROM PERFORMANCE: " + (System.currentTimeMillis() - tps) + "##################");
			logger.error("##################");
			logger.error("##################");

			// delete exiting data no more needed
			// MP_INTERVAL
			access.deleteByPlanAndKeepInterval(idPlan, toKeep);

			if (isIveco)
			{
				duplicateOperation(idPlan);
			}

		}
		return listWarningPerf;
	}

	/**
	 * get list of performance applicable.
	 * 
	 * @param idPlan filter
	 * @param configList configuration List
	 * @param listWarningPerf : contains as the result the performance in warning
	 * @param idPerf : max or harm
	 * @return the list of applicable perf
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	private List<Long> getApplicablePerformance(String idPlan, Map<Long, Long> configList, List<Long> listWarningPerf, String idPerf, Boolean isIveco) throws SystemException, ApplicativeException {

		//get list of all performance with the applicability and the corresponding applicability of the plan that matches
		long tps1 = System.currentTimeMillis();
		List<OperationPerformanceApplicabilityDto> listPerfApp = new OperationPerformanceBusiness().getListPerformanceApplicableWithoutConfig(idPlan, idPerf);

		Comparator<OperationPerformanceApplicabilityDto> comparatorByCols = Comparator.comparing(OperationPerformanceApplicabilityDto::getIdPerformance)
				.thenComparing(OperationPerformanceApplicabilityDto::getModel)
				.thenComparing(OperationPerformanceApplicabilityDto::getTt)
				.thenComparing(OperationPerformanceApplicabilityDto::getMarket)
				.thenComparing(OperationPerformanceApplicabilityDto::getConfig)
				.thenComparing(OperationPerformanceApplicabilityDto::getModelPlan)
				.thenComparing(OperationPerformanceApplicabilityDto::getTtPlan)
				.thenComparing(OperationPerformanceApplicabilityDto::getMarketPlan)
				.thenComparing(OperationPerformanceApplicabilityDto::getConfigPlan);

		listPerfApp = listPerfApp.stream().sorted(comparatorByCols).collect(Collectors.toList());

		logger.error("##################");
		logger.error("##################");
		logger.error("################## TIME TO GET PERFORMANCE APPLICABILITY: " + (System.currentTimeMillis() - tps1) + "##################");
		logger.error("##################");
		logger.error("##################");

		List<Long> listPerf = new ArrayList<Long>();

		long tps2 = System.currentTimeMillis();
		listPerf = getListApplicablePerformance(listPerfApp, configList, listWarningPerf, isIveco);
		logger.error("##################");
		logger.error("##################");
		logger.error("################## TIME TO GET APPLICABLE PERFORMANCE TO PLAN: " + (System.currentTimeMillis() - tps2) + "##################");
		logger.error("##################");
		logger.error("##################");
		return listPerf;
	}

	/**
	 * get list of performance applicable.
	 * 
	 * @param idPlan filter
	 * @param configList configuration List
	 * @param listWarningPerf : contains as the result the performance in warning
	 * @param listPerf : performances to check
	 * @param perfType harm or max
	 * @return the list of applicable perf
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<Long> getListApplicablePerfToPlan(String idPlan, Map<Long, Long> configList, List<Long> listWarningPerf, String listPerf, String perfType, Boolean isIveco)
			throws SystemException, ApplicativeException {

		//get list of all performance with the applicability and the corresponding applicability of the plan that matches
		List<OperationPerformanceApplicabilityDto> listPerfApp = new OperationPerformanceBusiness().getListPerformanceApplicableToPlan(idPlan, listPerf, perfType);

		List<Long> listPerfApplicable = new ArrayList<Long>();

		listPerfApplicable = getListApplicablePerformance(listPerfApp, configList, listWarningPerf, isIveco);
		return listPerfApplicable;
	}

	/**
	 * Get the List of applicable perfs.
	 * 
	 * @param listPerfApp list of all performance with the applicability and the corresponding applicability of the plan that matches
	 * @param configList list of configs
	 * @param listWarningPerf contains as the result the performance in warning
	 * @return the list of applicable perf
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException an Applicative Exception
	 */
	public List<Long> getListApplicablePerformance(List<OperationPerformanceApplicabilityDto> listPerfApp, Map<Long, Long> configList, List<Long> listWarningPerf, Boolean isIveco)
			throws SystemException, ApplicativeException {
		Long currentPerf = 0L;
		Long currentMarketPlan = 0L;
		Long currentMarket = 0L;

		boolean configOk = false;
		boolean loadPlanApp = true;
		boolean appChange = false;

		String currentModel = "";
		String resultCheck = "";
		String perfConfigsByApp = "";
		String currentModelPlan = "";
		String currentTtPlan = "";
		String currentConfigPlan = "0";
		String currentTt = "";
		String currentConfig = "0";

		List<ApplicabilityDto> mpApps = new ArrayList<ApplicabilityDto>();

		List<Long> listPerf = new ArrayList<Long>();

		ApplicabilityDto appDto = new ApplicabilityDto();

		for (OperationPerformanceApplicabilityDto app : listPerfApp)
		{
			if (currentPerf != null && !currentPerf.equals(app.getIdPerformance()))
			{
				//check config when the performance changes
				if (!configOk && (currentModel == null || !currentModel.equals("")))
				{
					resultCheck = checkConfig(perfConfigsByApp, mpApps, configList, isIveco);

					if (isIveco)
					{
						if (resultCheck.equals("true"))
						{
							listPerf.add(currentPerf);
							listWarningPerf.remove(currentPerf);
						}
						else if (resultCheck.equals("warning"))
						{
							if (!listWarningPerf.contains(currentPerf))
							{
								listWarningPerf.add(currentPerf);
							}
						}
					}
					else
					{
						if (resultCheck.equals("true"))
						{
							listPerf.add(currentPerf);
							listWarningPerf.remove(currentPerf);
						}
					}
				}
				currentPerf = app.getIdPerformance();
				//re-init
				currentModel = "";
				currentTt = "";
				currentMarket = 0L;
				currentConfig = "0";
				configOk = false;
				loadPlanApp = true;

				currentModelPlan = "";
				currentTtPlan = "";
				currentMarketPlan = 0L;
				currentConfigPlan = "0";
				perfConfigsByApp = "";
				mpApps.clear();
			}
			else
			{
				// when one app match for the configuration, jump to the next performance
				if (configOk)
				{
					continue;
				}
			}
			appChange = false;
			if (currentModel != null && !currentModel.equals(app.getModel()) || currentTt != null && !currentTt.equals(app.getTt()) || currentMarket != null && !currentMarket.equals(app.getMarket()))
			{
				//check config when the performance applicability changes
				if (!currentModel.equals(""))
				{
					resultCheck = checkConfig(perfConfigsByApp, mpApps, configList, isIveco);

					if (isIveco)
					{
						if (resultCheck.equals("true"))
						{
							listPerf.add(app.getIdPerformance());
							listWarningPerf.remove(app.getIdPerformance());
							configOk = true;
							continue;
						}
						else
						{
							//reset
							loadPlanApp = true;
							currentModelPlan = "";
							currentTtPlan = "";
							currentMarketPlan = 0L;
							currentConfigPlan = "0";
							perfConfigsByApp = "";
							mpApps.clear();
							if (resultCheck.equals("warning") && !listWarningPerf.contains(app.getIdPerformance()))
							{
								listWarningPerf.add(app.getIdPerformance());
							}
							configOk = false;
						}
					}
					else
					{
						if (resultCheck.equals("true"))
						{
							listPerf.add(app.getIdPerformance());
							listWarningPerf.remove(app.getIdPerformance());
							configOk = true;
							continue;
						}
					}
				}
				appChange = true;
			}
			if (appChange)
			{
				loadPlanApp = true;
			}
			else if (!appChange && (currentConfig != null && !currentConfig.equals(app.getConfig())))
			{
				loadPlanApp = false;
			}

			if (loadPlanApp)
			{
				//build applicability of a plan that match for an applicability of one performance
				if (currentModelPlan != null && !currentModelPlan.equals(app.getModelPlan()))
				{
					currentModelPlan = app.getModelPlan();
					currentTtPlan = app.getTtPlan();
					currentMarketPlan = app.getMarketPlan();
					currentConfigPlan = app.getConfigPlan();
					appDto = new ApplicabilityDto(currentModelPlan, currentTtPlan, currentMarketPlan, currentConfigPlan);
					mpApps.add(appDto);
				}
				else
				{
					if (currentTtPlan != null && !currentTtPlan.equals(app.getTtPlan()))
					{
						currentTtPlan = app.getTtPlan();
						currentMarketPlan = app.getMarketPlan();
						currentConfigPlan = app.getConfigPlan();
						appDto = new ApplicabilityDto(currentModelPlan, currentTtPlan, currentMarketPlan, currentConfigPlan);
						mpApps.add(appDto);
					}
					else
					{
						if (currentMarketPlan != null && !currentMarketPlan.equals(app.getMarket()))
						{
							currentMarketPlan = app.getMarketPlan();
							currentConfigPlan = app.getConfigPlan();
							appDto = new ApplicabilityDto(currentModelPlan, currentTtPlan, currentMarketPlan, currentConfigPlan);
							mpApps.add(appDto);
						}
					}
				}
			}
			//build list of configuration for an applicability (same model,same tt, same model) of a performance
			if (currentModel != null && !currentModel.equals(app.getModel()) || currentTt != null && !currentTt.equals(app.getTt()) || currentMarket != null && !currentMarket.equals(app.getMarket())
					|| currentConfig != null && !currentConfig.equals(app.getConfig()))
			{
				currentModel = app.getModel();
				currentTt = app.getTt();
				currentMarket = app.getMarket();
				currentConfig = app.getConfig();
				if (app.getConfig() != null)
				{
					perfConfigsByApp = app.getConfig();
				}

			}
		}
		//check config at the end of the loop for
		if (!configOk && listPerfApp.size() > 0)
		{
			resultCheck = checkConfig(perfConfigsByApp, mpApps, configList, isIveco);

			if (isIveco)
			{
				if (resultCheck.equals("true"))
				{
					listPerf.add(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance());
					listWarningPerf.remove(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance());
				}
				else if (resultCheck.equals("warning"))
				{
					if (!listWarningPerf.contains(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance()))
					{
						listWarningPerf.add(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance());
					}
				}
			}
			else
			{
				if (resultCheck.equals("true"))
				{
					listPerf.add(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance());
					listWarningPerf.remove(listPerfApp.get(listPerfApp.size() - 1).getIdPerformance());
				}
			}
		}
		return listPerf;
	}

	/**
	 * check if the configToCheck match with at least one list of configuration of list of applicability.
	 * 
	 * @param complexConfigToCheck : configuration of an app of a performance
	 * @param appList : list of configuration to check with the configToCheck
	 * @param configList : list of configuration
	 * @return true if the configuration match, warning if the plan has no a missing configuration category, else false
	 */
	private String checkConfig(String complexConfigToCheck, List<ApplicabilityDto> appList, Map<Long, Long> configList, Boolean isIveco) {

		String result = "false";
		int i = 0;
		if (appList.size() == 0)
		{
			if (complexConfigToCheck == null || complexConfigToCheck.equals(""))
			{
				result = "true";
			}
			else
			{
				result = "warning";
			}
		}
		else
		{
			while (i < appList.size() && !result.equals("true"))
			{
				if ((appList.get(i).getConfig() == null || appList.get(i).getConfig().equals("")))
				{
					if (complexConfigToCheck == null || complexConfigToCheck.equals(""))
					{
						// if no config for the element and the context, then it is applicable
						result = "true";
					}
					else
					{
						// if  config for the element and no config for the context, then warning
						result = "warning";
					}
				}
				else if ((complexConfigToCheck == null || complexConfigToCheck.equals("")))
				{
					// if no config for the element and config for the context, then it is applicable
					result = "true";
				}
				else
				{
					//init elementCheck
					String res = UtilConfiguration.isApplicableForAComplexConfiguration(complexConfigToCheck, appList.get(i).getConfig(), configList, "INTERVALS");
					if (!res.equals("false"))
					{
						result = res;
					}
				}
				i++;
			}
		}
		return result;
	}

	/**
	 * duplicate operations.
	 * 
	 * @param idPlan filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	private void duplicateOperation(String idPlan) throws SystemException, ApplicativeException {
		IntervalAccess access = new IntervalAccess();
		IntervalOperationAccess accessOperation = new IntervalOperationAccess();
		// duplicate operation in next intervals
		// for each interval of a plan which can be duplicated
		List<IntervalDto> listInterval = access.getListForOperationDuplication(idPlan);
		for (IntervalDto interval : listInterval)
		{
			// only operation with a performance with group=null can be duplicated
			if (interval.getGroup() == null)
			{
				// Km and Month and Hour multiple
				if (interval.getAfterValueKm() != null && interval.getAfterValueMonth() != null && interval.getAfterValueHour() != null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() != null && interval2.getAfterValueMonth() != null && interval2.getAfterValueHour() != null)
							{
								Long ratio = interval2.getAfterValueKm() / interval.getAfterValueKm();
								if ((interval2.getAfterValueKm() % interval.getAfterValueKm()) == 0)
								{
									if ((interval2.getAfterValueMonth().equals(ratio * interval.getAfterValueMonth())) &&
											(interval2.getAfterValueHour().equals(ratio * interval.getAfterValueHour())))
									{

										// duplicate operation
										accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());

									}
								}
							}
						}
					}
				}

				// Km and Month  multiple
				if (interval.getAfterValueKm() != null && interval.getAfterValueMonth() != null && interval.getAfterValueHour() == null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() != null && interval2.getAfterValueMonth() != null && interval2.getAfterValueHour() == null)
							{
								Long ratio = interval2.getAfterValueKm() / interval.getAfterValueKm();
								if ((interval2.getAfterValueKm() % interval.getAfterValueKm()) == 0)
								{
									if (interval2.getAfterValueMonth().equals(ratio * interval.getAfterValueMonth()))
									{

										// duplicate operation
										accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());

									}
								}
							}
						}
					}
				}

				// Km  and Hour multiple
				if (interval.getAfterValueKm() != null && interval.getAfterValueMonth() == null && interval.getAfterValueHour() != null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() != null && interval2.getAfterValueMonth() == null && interval2.getAfterValueHour() != null)
							{
								Long ratio = interval2.getAfterValueKm() / interval.getAfterValueKm();
								if ((interval2.getAfterValueKm() % interval.getAfterValueKm()) == 0)
								{
									if (interval2.getAfterValueHour().equals(ratio * interval.getAfterValueHour()))
									{

										// duplicate operation
										accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());

									}
								}
							}
						}
					}
				}

				//  Month and Hour multiple
				if (interval.getAfterValueKm() == null && interval.getAfterValueMonth() != null && interval.getAfterValueHour() != null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() == null && interval2.getAfterValueMonth() != null && interval2.getAfterValueHour() != null)
							{
								Long ratio = interval2.getAfterValueMonth() / interval.getAfterValueMonth();
								if ((interval2.getAfterValueMonth() % interval.getAfterValueMonth()) == 0)
								{
									if (interval2.getAfterValueHour().equals(ratio * interval.getAfterValueHour()))
									{
										// duplicate operation
										accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());
									}
								}
							}
						}
					}
				}

				// Km  multiple
				if (interval.getAfterValueKm() != null && interval.getAfterValueMonth() == null && interval.getAfterValueHour() == null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() != null && interval2.getAfterValueMonth() == null && interval2.getAfterValueHour() == null)
							{
								Long ratio = interval2.getAfterValueKm() / interval.getAfterValueKm();
								if ((interval2.getAfterValueKm() % interval.getAfterValueKm()) == 0)
								{
									// duplicate operation
									accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());
								}
							}
						}
					}
				}

				// Month  multiple
				if (interval.getAfterValueKm() == null && interval.getAfterValueMonth() != null && interval.getAfterValueHour() == null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() == null && interval2.getAfterValueMonth() != null && interval2.getAfterValueHour() == null)
							{
								Long ratio = interval2.getAfterValueMonth() / interval.getAfterValueMonth();
								if ((interval2.getAfterValueMonth() % interval.getAfterValueMonth()) == 0)
								{
									// duplicate operation
									accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());
								}
							}
						}
					}
				}

				// Hour  multiple
				if (interval.getAfterValueKm() == null && interval.getAfterValueMonth() == null && interval.getAfterValueHour() != null)
				{
					for (IntervalDto interval2 : listInterval)
					{
						if (!interval.getId().equals(interval2.getId()) && interval2.getGroup() == null)
						{
							if (interval2.getAfterValueKm() == null && interval2.getAfterValueMonth() == null && interval2.getAfterValueHour() != null)
							{
								Long ratio = interval2.getAfterValueHour() / interval.getAfterValueHour();
								if ((interval2.getAfterValueHour() % interval.getAfterValueHour()) == 0)
								{
									// duplicate operation
									accessOperation.duplicate(interval.getId().toString(), interval2.getId().toString());
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Clone maintenance interval and interval_operation.
	 * 
	 * @param idSourcePlan the id of the source plan
	 * @param idDestPlan the id of the destination plan
	 * @param lang the id of the lang
	 * @param userName userName
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void duplicateMaintenanceInterval(String idSourcePlan, String idDestPlan, String lang, String userName)
			throws SystemException, ApplicativeException {
		List<IntervalDto> listIntervalDto = getList(idSourcePlan, lang);

		/** Manager for the Table Column Title business layout. */

		for (IntervalDto intDto : listIntervalDto)
		{
			Long idInterval = intDto.getId();
			intDto.setId(null);
			intDto.setIdPlan(Long.parseLong(idDestPlan));

			save(intDto);

			List<IntervalOperationDto> listIntOpeDto = new IntervalOperationBusiness().getListOfOperationIntervalByIntAndPlan(idInterval, new Long(idDestPlan));
			for (IntervalOperationDto intOpeDto : listIntOpeDto)
			{
				intOpeDto.setIntervalId(intDto.getId());
				new IntervalOperationAccess().add(intOpeDto.getIntervalId().toString(), intOpeDto.getIdOperationSeries().toString());
			}
		}
	}

	/**
	 * Get the List of comments by plan .
	 * 
	 * @param idPlan filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException an Applicative Exception
	 */
	public List<IntervalDto> getCommentListByPlan(String idPlan) throws SystemException, ApplicativeException {
		return new IntervalAccess().getCommentListByPlan(idPlan);
	}

	/**
	 * check Configuration With Item Logic : with AND between items and OR between values of a same item.
	 * 
	 * @param context list of config selected in the context
	 * @param element list of config for the element t check
	 * @return true if config matches.
	 */
	public boolean checkConfigurationWithItemLogic(List<ConfigurationDto> context, List<ConfigurationDto> element) {
		boolean result = true;
		boolean configItemExist = false;
		HashMap<Integer, Boolean> elementCheck = new HashMap<Integer, Boolean>();

		if ((context.size() == 0) || (element.size() == 0))
		{
			// if no config for the element or the context, then it is applicable
			result = true;
		}
		else
		{
			//init elementCheck
			for (ConfigurationDto configElement : element)
			{
				if (!elementCheck.containsKey(configElement.getConfigItemId()))
				{
					elementCheck.put(configElement.getConfigItemId(), false);
				}
			}

			Iterator<Integer> indexBrowser = elementCheck.keySet().iterator();
			while (indexBrowser.hasNext())
			{
				Integer item = indexBrowser.next();

				// find config value for this item
				for (ConfigurationDto configElement : element)
				{
					if (configElement.getConfigItemId().equals(item))
					{
						configItemExist = false;
						for (ConfigurationDto configContext : context)
						{
							if (configElement.getConfigItemId().equals(configContext.getConfigItemId()))
							{
								if (configElement.getIdConfig().equals(configContext.getIdConfig()))
								{
									// if one value of the given item is selected --> the item is true
									elementCheck.put(item, true);
									break;
								}
								configItemExist = true;
							}
						}
						//if this config item is not specified
						if (!configItemExist)
						{
							elementCheck.put(item, true);
						}
					}
					if (elementCheck.get(item) == true)
					{
						break;
					}
				}
			}

			// if all element of the elementCheck are true, result = true
			indexBrowser = elementCheck.keySet().iterator();
			while (indexBrowser.hasNext() && result)
			{
				Integer item = indexBrowser.next();
				if (elementCheck.get(item) == false)
				{
					result = false;
				}
			}

		}
		return result;
	}

	/**
	 * Get the List of intervals .
	 * 
	 * @param idComment filter
	 * @return the list of intervals
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public List<IntervalDto> getIntervalsListByComment(String idComment) throws SystemException {
		IntervalAccess access = new IntervalAccess();
		List<IntervalDto> result = access.getIntervalsListByComment(idComment);
		return result;
	}

	/**
	 * Get the first interval for a comment.
	 * 
	 * @param commentLbl filter
	 * @return the first interval
	 * @throws SystemException Cannot execute query or access to database.
	 */

	public IntervalDto getFirstIntervalComment(String commentLbl) throws SystemException {
		IntervalAccess access = new IntervalAccess();
		IntervalDto result = access.getFirstIntervalComment(commentLbl);
		return result;
	}

}
