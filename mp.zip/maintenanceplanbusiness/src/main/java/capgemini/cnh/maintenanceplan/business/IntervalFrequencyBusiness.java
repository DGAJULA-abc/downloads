/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.access.IntervalFrequencyAccess;
import capgemini.cnh.maintenanceplan.dto.IntervalDto;
import capgemini.cnh.maintenanceplan.dto.IntervalFrequencyDto;

/**
 * @author mamestoy
 *
 */
public class IntervalFrequencyBusiness extends Business {

	/**
	 * Define a logger.
	 */
	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public IntervalFrequencyBusiness() throws SystemException {
		super();
	}

	/**
	 * find interval code.
	 * 
	 * @param dto to find
	 * @return interval Frequency
	 * @param specificUnitKey Key of the specific unit
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public IntervalFrequencyDto findIntervalCode(IntervalDto dto, String specificUnitKey) throws SystemException, ApplicativeException {
		IntervalFrequencyAccess access = new IntervalFrequencyAccess();
		IntervalFrequencyDto result = access.findIntervalCode(dto, specificUnitKey);
		return result;
	}

}
