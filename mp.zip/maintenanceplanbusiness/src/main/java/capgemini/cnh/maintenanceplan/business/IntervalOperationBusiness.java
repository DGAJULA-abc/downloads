/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.IntervalOperationAccess;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationDto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public IntervalOperationBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of intervals for a given operation on a series.
	 * 
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationDto> getListOfIntervalOperation(String operationSeriesId) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListOfIntervalOperation(operationSeriesId);
	}

	/**
	 * Get the List of operations on a series for a given interval.
	 * 
	 * @param intervalId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationDto> getListOfOperationInterval(String intervalId) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListOfOperationInterval(intervalId);
	}

	/**
	 * Get the List of operations on a series for a given interval.
	 * 
	 * @param intervalId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationDto> getListOfOperationIntervalNotReleased(String intervalId) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListOfOperationIntervalNotReleased(intervalId);
	}

	/**
	 * Get the List of operations/interval by plan.
	 * 
	 * @param planId to filter
	 * @param language for translation
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationDto> getListByPlan(String planId, String language) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListByPlan(planId, language);
	}

	/**
	 * Get the List of operations/interval by plan.
	 * 
	 * @param planId to filter
	 * @param language to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationDto> getListOpIntervalByPlan(String planId, String language) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListOpIntervalByPlan(planId, language);
	}

	/**
	 * update interval of a project released.
	 * 
	 * @param oldOpeSeries : old link.
	 * @param newOpeSeries : new link.
	 * @param projectId : project Id.
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void updateIntervalProjectRelease(Long oldOpeSeries, Long newOpeSeries, Long projectId) throws SystemException, ApplicativeException {
		new IntervalOperationAccess().updateIntervalProjectRelease(oldOpeSeries, newOpeSeries, projectId);
	}

	/**
	 * Get the interval on a series for a given interval and a given operation.
	 * 
	 * @param intervalId to filter
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public IntervalOperationDto getListForOperationInterval(String intervalId, String operationSeriesId) throws SystemException, ApplicativeException {
		return new IntervalOperationAccess().getListForOperationInterval(intervalId, operationSeriesId);
	}

	/**
	 * Get the List of operations on a series for a given interval Id (Source) and a given plan Id (Dest).
	 * 
	 * @param intervalIdSrc id of interval to get the operations from
	 * @param planIdDest the id of the current plan to get the project id
	 * @return the list of intervals
	 * @throws SystemException system exception
	 */
	public List<IntervalOperationDto> getListOfOperationIntervalByIntAndPlan(Long intervalIdSrc, Long planIdDest) throws SystemException {
		return new IntervalOperationAccess().getListOfOperationIntervalByIntAndPlan(intervalIdSrc, planIdDest);
	}

}
