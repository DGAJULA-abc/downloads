/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.IntervalOperationCompareAccess;
import capgemini.cnh.maintenanceplan.dto.IntervalOperationCompareDto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public IntervalOperationCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of intervals for a given operation on a series.
	 * 
	 * @param operationSeriesId to filter
	 * @return the list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<IntervalOperationCompareDto> getListOfIntervalOperation(String operationSeriesId) throws SystemException, ApplicativeException {
		return new IntervalOperationCompareAccess().getListOfIntervalOperation(operationSeriesId);
	}

}
