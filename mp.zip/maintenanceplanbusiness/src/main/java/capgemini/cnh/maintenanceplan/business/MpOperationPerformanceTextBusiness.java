package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.access.MpOperationPerformanceTextAccess;
import capgemini.cnh.maintenanceplan.dto.MpOperationPerformanceTextDto;

/**
 * @author jtolosa
 * 
 *         Business class to manage SRT_SRT_DEFECT data.
 */
public class MpOperationPerformanceTextBusiness extends Business<MpOperationPerformanceTextDto> {

	/** Define a logger for this class. */
	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/**
	 * Constructor.
	 */
	public MpOperationPerformanceTextBusiness() {
		super();
	}

	/**
	 * Constructor.
	 */
	public MpOperationPerformanceTextBusiness(MpOperationPerformanceTextAccess access) {
		super(access);
	}

	/**
	 * Check if the translation exists in TABLE_TITLE oracle Table.
	 * 
	 * @param label label for the Performance
	 * @return the List of records for this translation
	 */
	public List<MpOperationPerformanceTextDto> isTranslationExist(String label) {
		try
		{
			return (new MpOperationPerformanceTextAccess()).isTranslationExist(label);
		}
		catch (SystemException e)
		{
			logger.error("System Exception: " + e.getMessage());
			return null;
		}
	}

	/**
	 * Find the records where the Free Text ID is equals to @param freeTextId.
	 * 
	 * @param freeTextId Free Text ID
	 * @return List of records
	 */
	public List<MpOperationPerformanceTextDto> findByFreeTextId(Long freeTextId) {
		try
		{
			return (new MpOperationPerformanceTextAccess()).findByFreeTextId(freeTextId);
		}
		catch (SystemException e)
		{
			logger.error("System Exception: " + e.getMessage());
			return null;
		}
	}

	/**
	 * Get the list of the performances with label for an operation series.
	 * 
	 * @param opeSerId id of the oepration series
	 * @return the list of the performances with label for an operation series
	 */
	public List<MpOperationPerformanceTextDto> getListByOperationSeriesId(Long opeSerId) {
		try
		{
			return new MpOperationPerformanceTextAccess().getListByOperationSeriesId(opeSerId);
		}
		catch (SystemException e)
		{
			logger.error("System Exception: " + e.getMessage());
			return null;
		}
	}

	/**
	 * Get the list of the performances without label for an operation series.
	 * 
	 * @param opeSerId id of the oepration series
	 * @return the list of the performances without label for an operation series
	 * @throws SystemException System Exception
	 */
	public List<MpOperationPerformanceTextDto> getListByOperationSeriesIdWithoutLabel(Long opeSerId) throws SystemException {
		return new MpOperationPerformanceTextAccess().getListByOperationSeriesIdWithoutLabel(opeSerId);
	}
}
