/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.Constantes;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ResourceLabel;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.access.OperationAccess;
import capgemini.cnh.maintenanceplan.dto.OperationDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesDto;

/**
 * @author sdomecq
 *
 */
public class OperationBusiness extends Business {

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(OperationBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationDto> getList(String language) throws SystemException, ApplicativeException {

		return new OperationAccess().getList(language);
	}

	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @param selectedSeriesIceCode for series actions check
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationDto> getList(String language, String selectedSeriesIceCode) throws SystemException, ApplicativeException {

		return new OperationAccess().getList(language, selectedSeriesIceCode);
	}

	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationDto> getListExport(String language) throws SystemException, ApplicativeException {

		return new OperationAccess().getListExport(language);
	}

	/**
	 * Get the List of Micro operations.
	 * 
	 * @param language for translated texts
	 * @return the list of micro operations
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationDto> getListExportMicro(String language) throws SystemException, ApplicativeException {

		return new OperationAccess().getListExportMicro(language);
	}

	/**
	 * Get one operations.
	 * 
	 * @param idOperation to get
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public OperationDto get(String idOperation, String language) throws SystemException, ApplicativeException {

		return new OperationAccess().get(idOperation, language);
	}

	/**
	 * Get one operation with only micro or srt code.
	 * 
	 * @param idOperation to get
	 * @param language for translated texts
	 * @return the operation
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public OperationDto getWarrantyOperationWithoutLabels(String idOperation) throws SystemException, ApplicativeException {

		return new OperationAccess().getWarrantyOperationWithoutLabels(idOperation);
	}

	/**
	 * Get one association operation/series.
	 * 
	 * @param idSeriesOperation to get
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public OperationDto get(String idSeriesOperation) throws SystemException, ApplicativeException {
		return new OperationAccess().get(idSeriesOperation);
	}

	/**
	 * save one operations.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationDto dto) throws SystemException, ApplicativeException {
		if (dto.getId() == null)
		{
			new OperationAccess().add(dto);
		}
		else
		{
			new OperationAccess().update(dto);
		}
	}

	/**
	 * delete operation in MP_OPERATION table.
	 * 
	 * @param operationId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteSelectedOperation(String operationId) throws SystemException, ApplicativeException {
		new OperationAccess().deleteSelectedOperation(operationId);
	}

	/**
	 * Get an operation .
	 * 
	 * @param id current element
	 * @param code of micro operation or warranty
	 * @param language for translated texts
	 * @param family of location
	 * @param group of location
	 * @param subGroup of location
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public OperationDto getOperationByCodeAndByLocation(String id, String code, String family, String group, String subGroup, String language) throws SystemException, ApplicativeException {
		return new OperationAccess().getOperationByCodeAndByLocation(id, code, family, group, subGroup, language);
	}

	/**
	 * Get an operation based on its code.
	 * 
	 * @param code of micro operation or warranty
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationDto> getOperationByCode(String code) throws SystemException, ApplicativeException {
		return new OperationAccess().getOperationByCode(code);
	}

	public void getOperationTypeLabel(OperationSeriesDto seriesDto, OperationDto dto) {
		switch (seriesDto.getByCustomer().intValue())
		{
		case -1:
			dto.setLabelOpeType("-");
			break;
		case Constantes.OPE_CUSTOMER:
			dto.setLabelOpeType(ResourceLabel.getInstance().getLabel("customer"));
			break;
		case Constantes.OPE_CUSTOMER_CONTRACT:
			dto.setLabelOpeType(ResourceLabel.getInstance().getLabel("customer.with.contract"));
			break;
		case Constantes.OPE_DEALER:
			dto.setLabelOpeType(ResourceLabel.getInstance().getLabel("dealer"));
			break;
		}
	}

	/**
	 * Get an operation based on its code.
	 * 
	 * @param code of micro operation or warranty
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationDto getOperationById(Long id) {
		try
		{
			return new OperationAccess().getOperationById(id);
		}
		catch (SystemException e)
		{
			logger.error("SystemException e: " + e.getMessage());
			return null;
		}
	}
}
