/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationConsumableAccess;
import capgemini.cnh.maintenanceplan.access.OperationConsumableApplicabilityAccess;
import capgemini.cnh.maintenanceplan.dto.ApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableDto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationConsumableBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of consumable for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableDto> getList(String idSeriesOperation, String language) throws SystemException, ApplicativeException {

		return new OperationConsumableAccess().getList(idSeriesOperation, language);
	}

	/**
	 * Get the List of consumable for a given operation on a series without language.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableDto> getList(String idSeriesOperation) throws SystemException, ApplicativeException {

		return new OperationConsumableAccess().getList(idSeriesOperation);
	}

	/**
	 * save a list of consumables for a given operation on a series.
	 * 
	 * @param theConsumable dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationConsumableDto theConsumable) throws SystemException, ApplicativeException {
		if (theConsumable.getId() == null)
		{
			new OperationConsumableAccess().add(theConsumable);
		}
		else
		{
			new OperationConsumableAccess().update(theConsumable);
		}
	}

	/**
	 * add consumable for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void addApplicability(OperationConsumableApplicabilityDto dto) throws SystemException, ApplicativeException {
		new OperationConsumableApplicabilityAccess().add(dto);
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void deleteApplicability(String id) throws SystemException, ApplicativeException {
		new OperationConsumableApplicabilityAccess().delete(id);
	}

	/**
	 * delete record for a given operation on a series.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteBySeries(String operationSeriesId) throws SystemException, ApplicativeException {

		new OperationConsumableApplicabilityAccess().deleteBySeries(operationSeriesId);
		new OperationConsumableAccess().deleteBySeries(operationSeriesId);
	}

	/**
	 * delete consumables for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void delete(String id) throws SystemException, ApplicativeException {
		new OperationConsumableApplicabilityAccess().delete(id);
		new OperationConsumableAccess().delete(id);
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idOpeCons to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableApplicabilityDto> getListApplicabilityByCons(String idOpeCons) throws SystemException, ApplicativeException {
		return new OperationConsumableApplicabilityAccess().getListApplicabilityByCons(idOpeCons);
	}

	/**
	 * Get the List of consumables for a given plan.
	 * 
	 * @param planId plan id
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ApplicabilityDto> getListForPlan(String planId) throws SystemException, ApplicativeException {
		return new OperationConsumableApplicabilityAccess().getListForPlan(planId);
	}

	/**
	 * Get the applicability of the consumables of a project.
	 * 
	 * @param projectId project id
	 * @return a list of consumable applicabilities
	 * @throws SystemException SystemException
	 */
	public List<OperationConsumableApplicabilityDto> getApplicabilityListByProject(String projectId) throws SystemException {
		return new OperationConsumableApplicabilityAccess().getApplicabilityListByProject(projectId);
	}

	/**
	 * Get the applicability of the consumables of a project.
	 * 
	 * @param projectId project id
	 * @param mode RELEASED or DRAFT
	 * @return a list of consumable applicabilities
	 * @throws SystemException SystemException
	 */
	public List<OperationConsumableApplicabilityDto> getApplicabilityListByProject(String projectId, String mode) throws SystemException {
		return new OperationConsumableApplicabilityAccess().getApplicabilityListByProject(projectId, mode);
	}

	/**
	 * Get the List of applicability by project.
	 * 
	 * @param projectId The project Id
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableApplicabilityDto> getListApplicabilityByProject(String projectId) throws SystemException, ApplicativeException {
		return new OperationConsumableApplicabilityAccess().getListApplicabilityByProject(projectId);
	}
}
