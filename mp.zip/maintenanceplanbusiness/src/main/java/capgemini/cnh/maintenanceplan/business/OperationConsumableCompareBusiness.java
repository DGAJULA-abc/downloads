/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationConsumableCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationConsumableCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of consumable for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationConsumableCompareDto> getList(String idSeriesOperation, String language) throws SystemException, ApplicativeException {

		return new OperationConsumableCompareAccess().getList(idSeriesOperation, language);
	}

}
