/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceplan.access.OperationIuLinkAccess;
import capgemini.cnh.maintenanceplan.dto.OperationIuLinkDto;

/**
 * @author mamestoy
 *
 */
public class OperationIuLinkBusiness extends Business {

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(OperationBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationIuLinkBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of IU Links for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of IUs
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationIuLinkDto> getList(String idSeriesOperation) throws SystemException, ApplicativeException {

		return new OperationIuLinkAccess().getList(idSeriesOperation);
	}

	/**
	 * delete ius for a given operation on a series.
	 * 
	 * @param id of the IU to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void delete(String id) throws SystemException, ApplicativeException {
		new OperationIuLinkAccess().delete(id);
	}

	/**
	 * save a list of ius for a given operation on a series.
	 * 
	 * @param theIu dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationIuLinkDto theIu) throws SystemException, ApplicativeException {
		if (theIu.getId() == null)
		{
			new OperationIuLinkAccess().add(theIu);
		}
	}

	/**
	 * Get a link IU/operation series Id.
	 * 
	 * @param opSerId operation series Id
	 * @param iuId IU id
	 * @param location iu location
	 * @param infotype iu infotype
	 * @return the operation
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationIuLinkDto getLinkForIuSeries(String opSerId, String iuId, String location, String infotype) {
		try
		{
			return new OperationIuLinkAccess().getLinkForIuSeries(opSerId, iuId, location, infotype);
		}
		catch (SystemException e)
		{
			logger.error("SystemException e: " + e.getMessage());
			return null;
		}
	}

}
