/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationPartAccess;
import capgemini.cnh.maintenanceplan.access.OperationPartApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.OperationPartCompareAccess;
import capgemini.cnh.maintenanceplan.access.PartAccess;
import capgemini.cnh.maintenanceplan.dto.OperationPartApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationPartCompareDto;
import capgemini.cnh.maintenanceplan.dto.PartDto;

/**
 * @author sdomecq
 *
 */
public class OperationPartCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationPartCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of part for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartCompareDto> getList(String idSeriesOperation) throws SystemException, ApplicativeException {

		return new OperationPartCompareAccess().getList(idSeriesOperation);
	}

	/**
	 * save a part.
	 * 
	 * @param thePart dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	//	public void save(OperationPartDto thePart) throws SystemException, ApplicativeException {
	//		if (thePart.getId() == null)
	//		{
	//			new OperationPartAccess().add(thePart);
	//		}
	//		else
	//		{
	//			new OperationPartAccess().update(thePart);
	//		}
	//		new PartAccess().add(new PartDto(thePart.getCodePart(), thePart.getPartLabel()));
	//
	//	}

	/**
	 * Get the List of parts.
	 * 
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<PartDto> getListParts() throws SystemException, ApplicativeException {

		return new PartAccess().getList();
	}

	/**
	 * add part for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void addApplicability(OperationPartApplicabilityDto dto) throws SystemException, ApplicativeException {
		new OperationPartApplicabilityAccess().add(dto);
	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void deleteApplicability(String id) throws SystemException, ApplicativeException {
		new OperationPartApplicabilityAccess().delete(id);
	}

	/**
	 * delete record for a given operation on a series.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteBySeries(String operationSeriesId) throws SystemException, ApplicativeException {
		new OperationPartApplicabilityAccess().deleteBySeries(operationSeriesId);
		new OperationPartAccess().deleteBySeries(operationSeriesId);

	}

	/**
	 * delete parts for a given operation on a series.
	 * 
	 * @param id to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void delete(String id) throws SystemException, ApplicativeException {
		new OperationPartApplicabilityAccess().delete(id);
		new OperationPartAccess().delete(id);
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idOpePart to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPartApplicabilityDto> getListApplicabilityByPart(String idOpePart) throws SystemException, ApplicativeException {
		return new OperationPartApplicabilityAccess().getListApplicabilityByPart(idOpePart);
	}
}
