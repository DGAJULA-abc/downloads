/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationPerfCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceCompareDto;

/**
 * @author mamestoy
 *
 */
public class OperationPerfCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationPerfCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of perf for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceCompareDto> getList(String idSeriesOperation, String language) throws SystemException, ApplicativeException {
		return new OperationPerfCompareAccess().getList(idSeriesOperation, language);
	}

}
