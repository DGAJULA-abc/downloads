/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.ConditionAccess;
import capgemini.cnh.maintenanceplan.access.OperationPerformanceAccess;
import capgemini.cnh.maintenanceplan.access.OperationPerformanceApplicabilityAccess;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceDto;

/**
 * @author sdomecq
 *
 */
public class OperationPerformanceBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationPerformanceBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of performances .
	 * 
	 * @param operationSeriesId filter
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceDto> getList(String operationSeriesId, String language) throws SystemException, ApplicativeException {

		return new OperationPerformanceAccess().getList(operationSeriesId, language);
	}

	/**
	 * Get the List of performances modified since the last release of a project in the series.
	 * 
	 * @param operationSeriesId filter
	 * @param language for translated texts
	 * @param selectedSeriesIceCode ice code of the series
	 * @return the list of performances
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */

	public List<OperationPerformanceDto> getListModifiedPerf(String operationSeriesId, String language, String selectedSeriesIceCode) throws SystemException, ApplicativeException {

		return new OperationPerformanceAccess().getListModifiedPerf(operationSeriesId, language, selectedSeriesIceCode);
	}

	/**
	 * Get the List of performances without language.
	 * 
	 * @param operationSeriesId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceDto> getList(String operationSeriesId) throws SystemException, ApplicativeException {

		return new OperationPerformanceAccess().getList(operationSeriesId);
	}

	/**
	 * delete record for a given operation on a series.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void deleteBySeries(String operationSeriesId) throws SystemException, ApplicativeException {
		new OperationPerformanceAccess().deleteBySeries(operationSeriesId);
		new ConditionAccess().deleteOperationConditionBySeries(operationSeriesId);
		new OperationPerformanceApplicabilityAccess().deleteBySeries(operationSeriesId);
	}

	/**
	 * delete record for a given id.
	 * 
	 * @param idPerformance to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(String idPerformance) throws SystemException, ApplicativeException {
		new OperationPerformanceAccess().delete(idPerformance);
		new ConditionAccess().deleteOperationConditionByPerf(idPerformance);
		new OperationPerformanceApplicabilityAccess().deleteByPerf(idPerformance);
	}

	/**
	 * save operations/performance.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationPerformanceDto dto) throws SystemException, ApplicativeException {

		if (dto.getIdPerformance() == null)
		{
			dto.setIdPerformance(new OperationPerformanceAccess().add(dto));
		}
		else
		{
			//Check if the performance has changed (the different value of the perf km/hour/month/group
			Long nb = new OperationPerformanceAccess().existPerformance(dto);
			if (nb == null || nb.compareTo(0L) <= 0)
			{
				new OperationPerformanceAccess().update(dto);
			}
			else
			{
				//we don't know if the performance name has changed so it is updated all the time
				new OperationPerformanceAccess().updatePerfName(dto);
			}

		}

	}

	/**
	 * update modification date.
	 * 
	 * @param performanceId to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void updatePerfModificationDate(Long performanceId) throws SystemException, ApplicativeException {

		new OperationPerformanceAccess().updateModificationDate(performanceId);
	}

	/**
	 * save operations/performance.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void saveCondition(ConditionDto dto) throws SystemException, ApplicativeException {

		if (dto.getIdCondition() == null)
		{
			new ConditionAccess().addOperationCondition(dto);
		}
		else
		{
			Long nb = new ConditionAccess().existOperationCondition(dto);
			if (nb == null || nb.compareTo(0L) <= 0)
			{
				new OperationPerformanceAccess().updateModificationDate(dto.getIdPerformance());
				new ConditionAccess().updateOperationCondition(dto);
			}

		}

	}

	/**
	 * save operations/performance.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void saveByCustomer(OperationPerformanceDto dto) throws SystemException, ApplicativeException {

		new OperationPerformanceAccess().updatePerfByCustomer(dto);

	}

	/**
	 * add consumable for a given operation on a series.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void addApplicability(OperationPerformanceApplicabilityDto dto) throws SystemException, ApplicativeException {
		new OperationPerformanceApplicabilityAccess().add(dto);
	}

	/**
	 * check if app exits.
	 * 
	 * @param dto to check
	 * @return true if app exits
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean existPerfApplicability(OperationPerformanceApplicabilityDto dto) throws SystemException, ApplicativeException {
		boolean result = true;
		Long nb = new OperationPerformanceApplicabilityAccess().existPerfApplicability(dto);
		if (nb == null || nb.compareTo(0L) <= 0)
		{
			result = false;
		}
		return result;
	}

	/**
	 * delete appli for a given perf.
	 * 
	 * @param idPerformance to filter
	 * @return true if element deleted
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean deleteApplicabilityByPerf(String idPerformance) throws SystemException, ApplicativeException {
		boolean deleted = false;
		Long nb = new OperationPerformanceApplicabilityAccess().deleteByPerf(idPerformance);
		if (nb != null && nb.compareTo(0L) > 0)
		{
			deleted = true;
		}
		return deleted;
	}

	/**
	 * save operations/performance.
	 * 
	 * @param dto to save
	 * @param idPerf useful to find if there are operation condition to clone
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void clone(OperationPerformanceDto dto, Long idPerf) throws SystemException, ApplicativeException {
		dto.setModifDate(null);
		dto.setIdPerformance(new OperationPerformanceAccess().add(dto));

		List<ConditionDto> listOpeCondDto = new ConditionAccess().getListOperationCondition(idPerf.toString());
		for (ConditionDto condDto : listOpeCondDto)
		{
			condDto.setIdCondition(null);
			condDto.setIdPerformance(dto.getIdPerformance());
			new ConditionAccess().addOperationCondition(condDto);
		}
	}

	/**
	 * Get the List of applicability .
	 * 
	 * @param idPerformance to filter
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListApplicabilityByPerf(String idPerformance) throws SystemException, ApplicativeException {
		return new OperationPerformanceApplicabilityAccess().getListApplicabilityByPerf(idPerformance);
	}

	/**
	 * Get the List of performance applicable (but not at configuration level) .
	 * 
	 * @param idPlan to filter
	 * @param idPerf : max or harm
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListPerformanceApplicableWithoutConfig(String idPlan, String idPerf) throws SystemException, ApplicativeException {
		return new OperationPerformanceApplicabilityAccess().getListPerformanceApplicableWithoutConfig(idPlan, idPerf);
	}

	/**
	 * Get the List of performances applicable (but not at configuration level) .
	 * 
	 * @param idPlan to filter
	 * @param perfsList : List of perfs to check
	 * @param perfType harm or max
	 * @return the list of applicability
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceApplicabilityDto> getListPerformanceApplicableToPlan(String idPlan, String perfsList, String perfType) throws SystemException, ApplicativeException {
		return new OperationPerformanceApplicabilityAccess().getListPerformanceApplicableToPlan(idPlan, perfsList, perfType);
	}

	/**
	 * Get the List of performances with the operation code.
	 * 
	 * @param listPerf list of performance to retrieve the operation code/label
	 * @return the list of performance
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationPerformanceDto> getListPerformance(List<Long> listPerf) throws SystemException, ApplicativeException {
		return new OperationPerformanceAccess().getListPerformance(listPerf);
	}

	/**
	 * Get a performance.
	 * 
	 * @param idPerf id of the performance to get
	 * @return the perf
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public OperationPerformanceDto getPerformance(String idPerf) throws SystemException, ApplicativeException {

		return new OperationPerformanceAccess().getPerformance(idPerf);
	}
}
