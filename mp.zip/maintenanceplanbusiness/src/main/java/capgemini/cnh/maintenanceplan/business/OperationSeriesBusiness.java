/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capgemini.cnh.cnhadmin.business.ManagerConfigurationBusiness;
import capgemini.cnh.cnhadmin.util.UtilConfiguration;
import capgemini.cnh.common.access.AllApplicabilityAccess;
import capgemini.cnh.common.dto.AllApplicabilityDto;
import capgemini.cnh.common.dto.ComplexConfigurationDto;
import capgemini.cnh.common.util.Constants;
import capgemini.cnh.component.dto.ConfigurationDto;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.Constantes;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.icedata.dto.MarketDto;
import capgemini.cnh.maintenanceplan.access.ConditionAccess;
import capgemini.cnh.maintenanceplan.access.MpOperationPerformanceTextAccess;
import capgemini.cnh.maintenanceplan.access.OperationConsumableApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.OperationPartApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.OperationPerformanceApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.OperationSeriesAccess;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.MpOperationPerformanceTextDto;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationConsumableDto;
import capgemini.cnh.maintenanceplan.dto.OperationIuLinkDto;
import capgemini.cnh.maintenanceplan.dto.OperationPartApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationPartDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.OperationPerformanceDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesDto;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;
import capgemini.cnh.mp.business.MpOperationConsumableBusiness;
import capgemini.cnh.mp.business.MpOperationPartBusiness;
import capgemini.cnh.mp.business.MpOperationPerfBusiness;
import capgemini.cnh.mp.dto.MpOperationConsumableDto;
import capgemini.cnh.mp.dto.MpOperationPartDto;
import capgemini.cnh.mp.dto.MpOperationPerfDto;
import capgemini.cnh.product.business.SerieBusiness;
import capgemini.cnh.product.dto.BrandDto;
import capgemini.cnh.product.dto.SerieDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationSeriesBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getList(String language, String brand, String type, String product, String series) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().getList(language, brand, type, product, series);
	}

	//TODO CR103
	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @param projectId : Id of the selected project
	 *
	 * @return the list of operations
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getOpListForProject(String language, String projectId) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().getOpListForProject(language, projectId);
	}

	/**
	 * save one operations.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationSeriesDto dto) throws SystemException, ApplicativeException {
		if (dto.getId() == null)
		{
			new OperationSeriesAccess().add(dto);
		}
		else
		{
			new OperationSeriesAccess().update(dto);
		}
	}

	/**
	 * delete operation.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(String operationSeriesId) throws SystemException, ApplicativeException {
		new OperationSeriesAccess().delete(operationSeriesId);

	}

	/**
	 * Get the List of series associated to a given operation.
	 * 
	 * @param idOperation to filter
	 * @return the list of associated series
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOfSeries(String idOperation) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().getListOfSeries(idOperation);
	}

	/**
	 * Get the List of operations in a series.
	 * 
	 * @param dto OperationSeriesDto
	 * @param idLang id of the language
	 * @return the list of associated series
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOfSeriesForOneOp(OperationSeriesDto dto, String idLang) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOfSeriesForOneOp(dto, idLang);
	}

	/**
	 * Get one association operation/series.
	 * 
	 * @param idSeriesOperation to get
	 * @return association operation/series
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public OperationSeriesDto get(String idSeriesOperation) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().get(idSeriesOperation);
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOperationSeriesByProjectExcelExport(idProject, language);
	}

	/**
	 * Get the list of operations by project.
	 * 
	 * @param idProject : id of the project
	 * @return the list of Operations by Series for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(Long idProject) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOperationSeriesByProject(idProject);
	}

	/**
	 * Get the list of operations for a project linked to perf free text.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProjectLinkedToPerfFreeText(Long idProject) throws SystemException {
		return new OperationSeriesAccess().getListOperationSeriesByProjectLinkedToPerfFreeText(idProject);
	}

	/**
	 * Get the list of operations for a series to perf free text.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<OperationSeriesDto> getListOperationSeriesLinkedToPerfFreeText(Long idProject) throws SystemException {
		return new OperationSeriesAccess().getListOperationSeriesLinkedToPerfFreeText(idProject);
	}

	/**
	 * Get the list of operations by project.
	 * 
	 * @param dto ProjectDto
	 * @return the list of Operations by Series for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(ProjectDto dto) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOperationSeriesByProject(dto);
	}

	/**
	 * Get the list of operations by plan.
	 * 
	 * @param isPlan Plan id
	 * @return the list of Operations by Series for the plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByPlan(Long planId) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOperationSeriesByPlan(planId);
	}

	/**
	 * Duplicate project.
	 * 
	 * @param oldProjectdto ProjectDto
	 * @param newProjectId the new project id
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void duplicateOnRelease(ProjectDto oldProjectdto, String newProjectId) throws SystemException, ApplicativeException {
		Long idProject = oldProjectdto.getId();
		HashMap<Long, Long> linkOpeSeries = new HashMap<Long, Long>();
		MpOperationPerformanceTextBusiness business = new MpOperationPerformanceTextBusiness(new MpOperationPerformanceTextAccess());

		List<OperationSeriesDto> listOpeSeriesDto = new OperationSeriesBusiness().getListOperationSeriesByProject(idProject);

		for (OperationSeriesDto opeDto : listOpeSeriesDto)
		{
			Long opeSerId = opeDto.getId();
			opeDto.setId(null);
			opeDto.setMPId(Long.parseLong(newProjectId));

			//insert in operation and update the project id
			// Before the insert
			new OperationSeriesBusiness().save(opeDto);
			linkOpeSeries.put(opeSerId, opeDto.getId());
			//insertOnRelease(opeDto);

			List<OperationPerformanceDto> listOpePerfDto = new OperationPerformanceBusiness().getList(opeSerId.toString());

			for (OperationPerformanceDto perfDto : listOpePerfDto)
			{
				Long perfId = perfDto.getIdPerformance();
				perfDto.setIdPerformance(null);
				perfDto.setIdOperationSeries(opeDto.getId());
				new OperationPerformanceBusiness().save(perfDto);
				//insertPerfOnRelease(perfDto);

				List<ConditionDto> listCondDto = new ConditionAccess().getListOperationCondition(perfId.toString());

				for (ConditionDto condDto : listCondDto)
				{
					condDto.setIdCondition(null);
					condDto.setIdPerformance(perfDto.getIdPerformance());
					new OperationPerformanceBusiness().saveCondition(condDto);
					//insertCondOnRelease(condDto);
				}

				List<OperationPerformanceApplicabilityDto> listOpePerfAppliDto = new OperationPerformanceApplicabilityAccess().getListApplicabilityByPerf(perfId.toString());

				for (OperationPerformanceApplicabilityDto perfAppliDto : listOpePerfAppliDto)
				{
					perfAppliDto.setId(null);
					perfAppliDto.setIdPerformance(perfDto.getIdPerformance());
					new OperationPerformanceBusiness().addApplicability(perfAppliDto);
					//insertPerfApplicabilityOnRelease(perfAppliDto);
				}
			}
			if (listOpePerfDto.isEmpty())
			{
				//Copy free text
				List<MpOperationPerformanceTextDto> performances = new MpOperationPerformanceTextBusiness().getListByOperationSeriesIdWithoutLabel(opeSerId);

				for (MpOperationPerformanceTextDto performance : performances)
				{
					performance.setPerfOpeSerId(opeDto.getId());
					performance.setPerfId(business.nextId(MpOperationPerformanceTextDto.class, Constantes.SQ_MP_OPERATION_PERFORMANCE_TEXT));
					business.insertDto(performance);
				}
			}

			List<OperationConsumableDto> listConsDto = new OperationConsumableBusiness().getList(opeSerId.toString());

			for (OperationConsumableDto consDto : listConsDto)
			{
				List<OperationConsumableApplicabilityDto> listConsAppliDto = new OperationConsumableApplicabilityAccess().getListApplicabilityByCons(consDto.getId().toString());

				consDto.setId(null);
				consDto.setIdOperationSeries(opeDto.getId());
				new OperationConsumableBusiness().save(consDto);
				//insertOpeConsOnRelease(consDto);

				for (OperationConsumableApplicabilityDto consAppliDto : listConsAppliDto)
				{
					consAppliDto.setId(null);
					consAppliDto.setIdOperationConsumable(consDto.getId());
					new OperationConsumableBusiness().addApplicability(consAppliDto);
					//insertConsAppliOnRelease(consAppliDto);
				}
			}

			List<OperationPartDto> listPartDto = new OperationPartBusiness().getList(opeSerId.toString());

			for (OperationPartDto partDto : listPartDto)
			{
				List<OperationPartApplicabilityDto> listPartAppliDto = new OperationPartApplicabilityAccess().getListApplicabilityByPart(partDto.getId().toString());

				partDto.setId(null);
				partDto.setIdOperationSeries(opeDto.getId());
				new OperationPartBusiness().save(partDto);
				//insertOpePartOnRelease(partDto);

				for (OperationPartApplicabilityDto partAppliDto : listPartAppliDto)
				{
					partAppliDto.setId(null);
					partAppliDto.setIdOperationPart(partDto.getId());
					new OperationPartBusiness().addApplicability(partAppliDto);
					//insertPartAppliOnRelease(partAppliDto);
				}
			}

			// IU Links
			List<OperationIuLinkDto> listIuLinkDto = new OperationIuLinkBusiness().getList(opeSerId.toString());

			for (OperationIuLinkDto iuLinkDto : listIuLinkDto)
			{
				iuLinkDto.setId(null);
				iuLinkDto.setIdOperationSeries(opeDto.getId());
				new OperationIuLinkBusiness().save(iuLinkDto);
			}
		}
		//		 // update the id in mp_interval_operation
		//		Iterator<Long> indexBrowser = linkOpeSeries.keySet().iterator();
		//		while (indexBrowser.hasNext())
		//		{
		//			Long oldOpeSeries = indexBrowser.next();
		//			new IntervalOperationBusiness().updateIntervalProjectRelease(oldOpeSeries, linkOpeSeries.get(oldOpeSeries), idProject);
		//		}
	}

	/**
	 * Clone an operation series.
	 * 
	 * @param isForTheCloning true if cloning of the series/ false for the check
	 * @param codeOp Operation Code
	 * @param idSeriesOperation operation series Id
	 * @param iceCodeDestSerie Ice Code of the dest series
	 * @param idOperationDest operation destination id
	 * @param idLanguage language id
	 * @param lstBrandDto list of brands
	 * @param marketsTargetSeries list of market for the target series
	 * @param projectId the destination project
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */

	public String cloneAnOperation(Boolean isForTheCloning, String codeOp, String idSeriesOperation, String iceCodeDestSerie, String idOperationDest, String idLanguage, List<BrandDto> lstBrandDto,
			boolean isCV, List<Dto> marketsTargetSeries, List<String> configsTargetSeries, Map<String, ConfigurationDto> mapConfigStore, Long projectId)
			throws SystemException, ApplicativeException {
		String applicability = "";

		Boolean cloneInSameSeries = false;
		MpOperationPerformanceTextBusiness business = new MpOperationPerformanceTextBusiness(new MpOperationPerformanceTextAccess());

		if (idSeriesOperation != null && !idSeriesOperation.equals(""))
		{
			// Operation_Series duplication
			OperationSeriesDto opeSeriesDto = new OperationSeriesBusiness().get(idSeriesOperation);
			opeSeriesDto.setId(null);

			// We can duplicate OperationSeries into ANOTHER Series
			if (iceCodeDestSerie != null && !iceCodeDestSerie.equals(""))
			{
				String appli[] = iceCodeDestSerie.split("[.]", 4);
				opeSeriesDto.setApplicabilityBrandIceCode(appli[0]);
				opeSeriesDto.setApplicabilityTypeIceCode(appli[1]);
				opeSeriesDto.setApplicabilityProductIceCode(appli[2]);
				opeSeriesDto.setApplicabilitySeriesIceCode(appli[3]);
			}
			// Or associated to an other Operation in the SAME Series
			else if (idOperationDest != null && !idOperationDest.equals(""))
			{
				cloneInSameSeries = true;
				opeSeriesDto.setIdOperation(Long.parseLong(idOperationDest));
			}

			// The project Id must be updated too
			opeSeriesDto.setMPId(projectId);

			// Save only when cloning. Not for the check
			if (isForTheCloning)
			{
				new OperationSeriesBusiness().save(opeSeriesDto);
			}

			//PERFORMANCE - WITH LABEL
			if (cloneInSameSeries || isForTheCloning)
			{
				List<MpOperationPerformanceTextDto> performances = new MpOperationPerformanceTextBusiness().getListByOperationSeriesIdWithoutLabel(new Long(idSeriesOperation));

				for (MpOperationPerformanceTextDto performance : performances)
				{
					performance.setPerfOpeSerId(opeSeriesDto.getId());
					performance.setPerfId(null);
					performance.setPerfId(business.nextId(MpOperationPerformanceTextDto.class, Constantes.SQ_MP_OPERATION_PERFORMANCE_TEXT));
					business.insertDto(performance);
				}

			}
			//PERFORMANCE - Operation_Performance & Operation_condition duplication
			List<OperationPerformanceDto> listOpePerfDto = new OperationPerformanceBusiness().getList(idSeriesOperation, idLanguage);
			for (OperationPerformanceDto dto : listOpePerfDto)
			{
				Long idPerf = dto.getIdPerformance();

				// Clone in the same series, all the applicability can be cloned
				if (cloneInSameSeries)
				{
					dto.setIdPerformance(null);
					dto.setIdOperationSeries(opeSeriesDto.getId());
					new OperationPerformanceBusiness().clone(dto, idPerf);

					//Operation_Perf_Applicability duplication 
					List<OperationPerformanceApplicabilityDto> listOpePerfAppliDto = new OperationPerformanceBusiness().getListApplicabilityByPerf(idPerf.toString());
					for (OperationPerformanceApplicabilityDto opePerfAppliDto : listOpePerfAppliDto)
					{
						opePerfAppliDto.setId(null);
						opePerfAppliDto.setIdPerformance(dto.getIdPerformance());
						new OperationPerformanceBusiness().addApplicability(opePerfAppliDto);
					}
				}

				// Clone in another series, the applicability must exist in the destination series to be cloned
				else
				{
					dto.setIdPerformance(null);
					dto.setIdOperationSeries(opeSeriesDto.getId());
					// Save only when cloning. Not for the check
					if (isForTheCloning)
					{
						new OperationPerformanceBusiness().clone(dto, idPerf);
					}

					// PERFORMANCES APPLICABILITY !!!!
					List<AllApplicabilityDto> applicabilityPerf = new AllApplicabilityAccess().getMaintenancePlanApplicabilityOperationPerformance(idSeriesOperation, idPerf.toString());
					for (AllApplicabilityDto appliDto : applicabilityPerf)
					{
						String applicabilityToDisplay = new PlanBusiness().displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore);

						// If the applicability is at Series level with configuration, the applicability is partially copied if the configuration values don�t exist for the destination Series.
						if (appliDto.getModelId() == null && appliDto.getConfigId() != null)
						{
							// Label of the config applicability 

							// Check if configuration applicable in the new series
							String[] listLogical = appliDto.getConfigId().split("\\" + UtilConfiguration.LOGICAL_OPERATOR_OR);
							int i = 0;
							String applicable = "";
							String perfAppliToAdd = "";
							String missingApplicability = "";
							while (i < listLogical.length)
							{
								applicable = UtilConfiguration.isPartOfConfigApplicable(listLogical[i], configsTargetSeries);
								if (applicable.equals(""))
								{
									if (!perfAppliToAdd.equals(""))
									{
										perfAppliToAdd = perfAppliToAdd + "+" + listLogical[i];
									}
									else
									{
										perfAppliToAdd = listLogical[i];
									}

								}
								// Missing applicability
								else
								{
									String missingAppli[] = applicable.split(";");
									int j = 0;
									while (j < missingAppli.length)
									{
										ComplexConfigurationDto dtoConfigMissing = new ComplexConfigurationDto();
										dtoConfigMissing = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(missingAppli[j], idLanguage, true, isCV, mapConfigStore);
										if (missingApplicability.equals(""))
										{
											missingApplicability = dtoConfigMissing.getConfigurationLabel();
										}
										else if (!missingApplicability.contains(dtoConfigMissing.getConfigurationLabel()))
										{
											missingApplicability = missingApplicability + "\n" + dtoConfigMissing.getConfigurationLabel();
										}
										j++;
									}
								}
								i++;
							}

							// Save applicability only when cloning. Not for the check
							if (isForTheCloning)
							{
								if (!perfAppliToAdd.equals(""))
								{
									// Check the consumable
									MpOperationPerfDto mpPerfDto = new MpOperationPerfBusiness().checkMpOperationPerf(opeSeriesDto.getId(), dto.getPerformanceLabel(), dto.getMaxStartValueKm(),
											dto.getMaxStartValueMonth(), dto.getMaxStartValueHour(), dto.getMaxAfterValueKm(), dto.getMaxAfterValueMonth(), dto.getMaxAfterValueHour(),
											dto.getHarmStartValueKm(), dto.getHarmStartValueMonth(), dto.getHarmStartValueHour(), dto.getHarmAfterValueKm(), dto.getHarmAfterValueMonth(),
											dto.getHarmAfterValueHour());
									if (mpPerfDto != null)
									{
										OperationPerformanceApplicabilityDto appliPerfDtoToAdd = new OperationPerformanceApplicabilityDto();
										appliPerfDtoToAdd.setId(null);
										appliPerfDtoToAdd.setIdPerformance(dto.getIdPerformance());
										appliPerfDtoToAdd.setConfig(perfAppliToAdd);
										new OperationPerformanceBusiness().addApplicability(appliPerfDtoToAdd);
									}
								}
							}

							// Destination applicability
							String appliDestination[] = iceCodeDestSerie.split("[.]", 4);
							SerieDto destinationSeriesDto = new SerieBusiness().getIdSeries(appliDestination[0], appliDestination[1], appliDestination[2], appliDestination[3]);
							String destSeriesLabel = new SerieBusiness().getSerieById(destinationSeriesDto.getId()).getAName();

							ComplexConfigurationDto dtoConf = new ComplexConfigurationDto();

							String newApp = "";

							if (!perfAppliToAdd.equals(""))
							{
								dtoConf = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(perfAppliToAdd, idLanguage, true, isCV, mapConfigStore);
								newApp = iceCodeDestSerie + " - " + destSeriesLabel + UtilConfiguration.getConfigurationLabelMultiline(dtoConf.getConfigurationLabel());
							}
							else
							{
								newApp = iceCodeDestSerie + " - " + destSeriesLabel;
							}

							// Original App , New App and Missing App
							if (applicability.equals("") && (!missingApplicability.equals("")))
							{
								applicability = codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^" + newApp + "^" + missingApplicability;
							}
							else if (!missingApplicability.equals(""))
							{
								applicability = applicability + "@" + codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^" + newApp + "^"
										+ missingApplicability;
							}

						}
						// If the applicability is at Model or TT/BM level (with or without configuration), the applicability is not copied
						else if (appliDto.getModelId() != null)
						{
							if (appliDto.getConfigId() != null)
							{
								// With config
								if (applicability.equals(""))
								{
									applicability = codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
								}
								else
								{
									applicability = applicability + "@" + codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
								}
							}
							else
							{
								// Without config
								if (applicability.equals(""))
								{
									applicability = codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^" + Constants.APP_WITHOUT_CONF;
								}
								else
								{
									applicability = applicability + "@" + codeOp + "^" + "" + "^" + "" + "^" + dto.getPerformanceLabel() + "^" + applicabilityToDisplay + "^"
											+ Constants.APP_WITHOUT_CONF;
								}
							}
						}
					}
				}
			}

			//CONSUMABLES -  duplication
			String consApp = cloneConsumablesForOperation(isForTheCloning, codeOp, idSeriesOperation, iceCodeDestSerie, idOperationDest, idLanguage, lstBrandDto, isCV, cloneInSameSeries, opeSeriesDto,
					marketsTargetSeries, configsTargetSeries, mapConfigStore);
			if (applicability.equals(""))
			{
				applicability = consApp;
			}
			else if (!consApp.equals(""))
			{
				applicability = applicability + "@" + consApp;
			}

			//PARTS -  duplication
			String partApp = clonePartsForOperation(isForTheCloning, codeOp, idSeriesOperation, iceCodeDestSerie, idOperationDest, idLanguage, lstBrandDto, isCV, cloneInSameSeries, opeSeriesDto,
					marketsTargetSeries, configsTargetSeries, mapConfigStore);
			if (applicability.equals(""))
			{
				applicability = partApp;
			}
			else if (!partApp.equals(""))
			{
				applicability = applicability + "@" + partApp;
			}

			//IULINKS - duplication
			List<OperationIuLinkDto> listIuLinkDto = new OperationIuLinkBusiness().getList(idSeriesOperation);
			for (OperationIuLinkDto iuLinkDto : listIuLinkDto)
			{
				iuLinkDto.setId(null);
				iuLinkDto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationIuLinkBusiness().save(iuLinkDto);
			}

		}

		return applicability;

	}

	/**
	 * Clone the Consumables of an operation from a series.
	 * 
	 * @param isForTheCloning true if cloning of the series/ false for the check
	 * @param codeOp Operation Code
	 * @param idSeriesOperation operation series Id
	 * @param iceCodeDestSerie Ice Code of the dest series
	 * @param idOperationDest operation destination id
	 * @param idLanguage language id
	 * @param lstBrandDto list of brands
	 * @param isCV list of brands
	 * @param cloneInSameSeries true if clone in same series
	 * @param opeSeriesDto operation series dto
	 * @param marketsTargetSeries list of market for the target series
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */

	public String cloneConsumablesForOperation(Boolean isForTheCloning, String codeOp, String idSeriesOperation, String iceCodeDestSerie, String idOperationDest, String idLanguage,
			List<BrandDto> lstBrandDto,
			boolean isCV, Boolean cloneInSameSeries, OperationSeriesDto opeSeriesDto, List<Dto> marketsTargetSeries, List<String> configsTargetSeries, Map<String, ConfigurationDto> mapConfigStore)
			throws SystemException, ApplicativeException {
		String applicability = "";
		List<OperationConsumableDto> listOpeConsDto = new OperationConsumableBusiness().getList(idSeriesOperation, idLanguage);

		for (OperationConsumableDto dto : listOpeConsDto)
		{
			// Clone in the same series, all the applicability can be cloned
			if (cloneInSameSeries)
			{
				Long idCons = dto.getId();
				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationConsumableBusiness().save(dto);

				//Operation_Perf_Applicability duplication 
				List<OperationConsumableApplicabilityDto> listOpeConsAppliDto = new OperationConsumableBusiness().getListApplicabilityByCons(idCons.toString());
				for (OperationConsumableApplicabilityDto opeConsAppliDto : listOpeConsAppliDto)
				{
					opeConsAppliDto.setId(null);
					opeConsAppliDto.setIdOperationConsumable(dto.getId());
					new OperationConsumableBusiness().addApplicability(opeConsAppliDto);
				}
			}

			// Clone in another series, the applicability must exist in the destination series to be cloned
			else
			{

				// CONSUMABLES APPLICABILITY !!!!
				List<AllApplicabilityDto> applicabilityCons = new AllApplicabilityAccess().getMaintenancePlanApplicabilityOperationConsumable(idSeriesOperation, dto.getId().toString());

				// Adding of the consumable
				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				// Save only when cloning. Not for the check
				if (isForTheCloning)
				{
					new OperationConsumableBusiness().save(dto);
				}

				for (AllApplicabilityDto appliDto : applicabilityCons)
				{
					String applicabilityToDisplay = new PlanBusiness().displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore);

					// If the applicability is at Series level with configuration, the applicability is partially copied if the configuration values don�t exist for the destination Series.
					if (appliDto.getModelId() == null && appliDto.getConfigId() != null)
					{
						//Check market exists
						//if no exist, the market applicability is not saved
						boolean marketExist = false;
						if (appliDto.getMarketId() != null)
						{
							//check market 
							for (Dto marketDto : marketsTargetSeries)
							{
								if (((MarketDto) marketDto).getMkId().equals(appliDto.getMarketId()))
								{
									marketExist = true;
									break;
								}
							}
						}
						else
						{
							marketExist = true;
						}
						if (!marketExist)
						{
							// Original App , New App and Missing App
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + "^" + dto.getConsumable() + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + "^" + dto.getConsumable() + "" + "^" + "" + "^" + applicabilityToDisplay + "^"
										+ Constants.APP_MARKET;;
							}
						}
						else
						{
							// Label of the config applicability 

							// Check if configuration applicable in the new series
							String[] listLogical = appliDto.getConfigId().split("\\" + UtilConfiguration.LOGICAL_OPERATOR_OR);
							int i = 0;
							String applicable = "";
							String consAppliToAdd = "";
							String missingApplicability = "";
							while (i < listLogical.length)
							{
								applicable = UtilConfiguration.isPartOfConfigApplicable(listLogical[i], configsTargetSeries);
								if (applicable.equals(""))
								{
									if (!consAppliToAdd.equals(""))
									{
										consAppliToAdd = consAppliToAdd + "+" + listLogical[i];
									}
									else
									{
										consAppliToAdd = listLogical[i];
									}

								}
								// Missing applicability
								else
								{
									String missingAppli[] = applicable.split(";");
									int j = 0;
									while (j < missingAppli.length)
									{
										ComplexConfigurationDto dtoConfigMissing = new ComplexConfigurationDto();
										dtoConfigMissing = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(missingAppli[j], idLanguage, true, isCV, mapConfigStore);
										if (missingApplicability.equals("") && dtoConfigMissing.getConfigurationLabel() != null)
										{
											missingApplicability = dtoConfigMissing.getConfigurationLabel();
										}
										else if (!missingApplicability.contains(dtoConfigMissing.getConfigurationLabel()))
										{
											missingApplicability = missingApplicability + "\n" + dtoConfigMissing.getConfigurationLabel();
										}
										j++;
									}
								}
								i++;
							}

							// Save only when cloning. Not for the check
							if (isForTheCloning)
							{
								if (!consAppliToAdd.equals(""))
								{
									// Check the consumable
									MpOperationConsumableDto mpConsDto = new MpOperationConsumableBusiness().checkMpOperationConsumable(opeSeriesDto.getId(), dto.getIdConsumable(), dto.getQuantity(),
											dto.getUnit());
									if (mpConsDto != null)
									{
										OperationConsumableApplicabilityDto appliConsDtoToAdd = new OperationConsumableApplicabilityDto();
										appliConsDtoToAdd.setId(null);
										appliConsDtoToAdd.setIdOperationConsumable(mpConsDto.getId());
										appliConsDtoToAdd.setConfig(consAppliToAdd);
										new OperationConsumableBusiness().addApplicability(appliConsDtoToAdd);
									}
								}
							}

							// Destination applicability
							String appliDestination[] = iceCodeDestSerie.split("[.]", 4);
							SerieDto destinationSeriesDto = new SerieBusiness().getIdSeries(appliDestination[0], appliDestination[1], appliDestination[2], appliDestination[3]);
							String destSeriesLabel = new SerieBusiness().getSerieById(destinationSeriesDto.getId()).getAName();

							ComplexConfigurationDto dtoConf = new ComplexConfigurationDto();

							String newApp = "";

							if (!consAppliToAdd.equals(""))
							{
								dtoConf = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(consAppliToAdd, idLanguage, true, isCV, mapConfigStore);
								newApp = iceCodeDestSerie + " - " + destSeriesLabel + UtilConfiguration.getConfigurationLabelMultiline(dtoConf.getConfigurationLabel());
							}
							else
							{
								newApp = iceCodeDestSerie + " - " + destSeriesLabel;
							}

							// Original App , New App and Missing App
							if (applicability.equals("") && (!missingApplicability.equals("")))
							{
								applicability = codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + newApp + "^" + missingApplicability;
							}
							else if (!missingApplicability.equals(""))
							{
								applicability = applicability + "@" + codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + newApp + "^"
										+ missingApplicability;
							}
						}

					}
					else if (appliDto.getModelId() == null && appliDto.getMarketId() != null)
					{
						//Check market exists
						//if no exist, the market applicability is not saved
						boolean marketExist = false;
						//check market 
						for (Dto marketDto : marketsTargetSeries)
						{
							if (((MarketDto) marketDto).getMkId().equals(appliDto.getMarketId()))
							{
								marketExist = true;
								break;
							}
						}
						if (!marketExist)
						{
							// Original App , New App and Missing App
							// Without config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + "^" + dto.getConsumable() + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + "^" + dto.getConsumable() + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;
							}
						}
						else
						{
							// Save only when cloning. Not for the check
							if (isForTheCloning)
							{
								// Check the consumable
								MpOperationConsumableDto mpConsDto = new MpOperationConsumableBusiness().checkMpOperationConsumable(opeSeriesDto.getId(), dto.getIdConsumable(), dto.getQuantity(),
										dto.getUnit());
								if (mpConsDto != null)
								{
									OperationConsumableApplicabilityDto appliConsDtoToAdd = new OperationConsumableApplicabilityDto();
									appliConsDtoToAdd.setId(null);
									appliConsDtoToAdd.setIdOperationConsumable(mpConsDto.getId());
									appliConsDtoToAdd.setMarket(appliDto.getMarketId());
									new OperationConsumableBusiness().addApplicability(appliConsDtoToAdd);
								}
							}
						}
					}
					// If the applicability is at Model or TT/BM level (with or without configuration), the applicability is not copied
					else if (appliDto.getModelId() != null)
					{
						if (appliDto.getConfigId() != null)
						{
							// With config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
							}
						}
						else
						{
							// Without config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITHOUT_CONF;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + "" + "^" + dto.getConsumable() + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITHOUT_CONF;
							}
						}
					}
				}

			}
		}
		return applicability;
	}

	/**
	 * Clone the parts of an operation from a series.
	 * 
	 * @param isForTheCloning true if cloning of the series/ false for the check
	 * @param codeOp Operation Code
	 * @param idSeriesOperation operation series Id
	 * @param iceCodeDestSerie Ice Code of the dest series
	 * @param idOperationDest operation destination id
	 * @param idLanguage language id
	 * @param lstBrandDto list of brands
	 * @param isCV list of brands
	 * @param cloneInSameSeries true if clone in same series
	 * @param opeSeriesDto operation series dto
	 * @param marketsTargetSeries list of market for the target series
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */

	public String clonePartsForOperation(Boolean isForTheCloning, String codeOp, String idSeriesOperation, String iceCodeDestSerie, String idOperationDest, String idLanguage,
			List<BrandDto> lstBrandDto,
			boolean isCV, Boolean cloneInSameSeries, OperationSeriesDto opeSeriesDto, List<Dto> marketsTargetSeries, List<String> configsTargetSeries, Map<String, ConfigurationDto> mapConfigStore)
			throws SystemException, ApplicativeException {
		String applicability = "";
		//PARTS -  duplication
		List<OperationPartDto> listOpePartDto = new OperationPartBusiness().getList(idSeriesOperation);
		for (OperationPartDto dto : listOpePartDto)
		{
			Long idPart = dto.getId();

			// Clone in the same series, all the applicability can be cloned
			if (cloneInSameSeries)
			{
				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationPartBusiness().save(dto);

				//Operation_Perf_Applicability duplication 
				List<OperationPartApplicabilityDto> listOpePartAppliDto = new OperationPartBusiness().getListApplicabilityByPart(idPart.toString());
				for (OperationPartApplicabilityDto opePartAppliDto : listOpePartAppliDto)
				{
					opePartAppliDto.setId(null);
					opePartAppliDto.setIdOperationPart(dto.getId());
					new OperationPartBusiness().addApplicability(opePartAppliDto);
				}
			}

			// Clone in another series, the applicability must exist in the destination series to be cloned
			else
			{
				// PARTS APPLICABILITY !!!!
				List<AllApplicabilityDto> applicabilityPart = new AllApplicabilityAccess().getMaintenancePlanApplicabilityOperationPart(idSeriesOperation, dto.getId().toString());

				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				// Save only when cloning. Not for the check
				if (isForTheCloning)
				{
					new OperationPartBusiness().save(dto);
				}

				for (AllApplicabilityDto appliDto : applicabilityPart)
				{
					String applicabilityToDisplay = new PlanBusiness().displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore);

					// If the applicability is at Series level with configuration, the applicability is partially copied if the configuration values don�t exist for the destination Series.
					if (appliDto.getModelId() == null && appliDto.getConfigId() != null)
					{
						//Check market exists
						//if no exist, the market applicability is not saved
						boolean marketExist = false;
						if (appliDto.getMarketId() != null)
						{
							//check market 
							for (Dto marketDto : marketsTargetSeries)
							{
								if (((MarketDto) marketDto).getMkId().equals(appliDto.getMarketId()))
								{
									marketExist = true;
									break;
								}
							}
						}
						else
						{
							marketExist = true;
						}
						if (!marketExist)
						{
							// Original App , New App and Missing App
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;
							}
						}
						else
						{
							// Label of the config applicability 

							// Check if configuration applicable in the new series
							String[] listLogical = appliDto.getConfigId().split("\\" + UtilConfiguration.LOGICAL_OPERATOR_OR);
							int i = 0;
							String applicable = "";
							String partAppliToAdd = "";
							String missingApplicability = "";
							while (i < listLogical.length)
							{
								applicable = UtilConfiguration.isPartOfConfigApplicable(listLogical[i], configsTargetSeries);
								if (applicable.equals(""))
								{
									if (!partAppliToAdd.equals(""))
									{
										partAppliToAdd = partAppliToAdd + "+" + listLogical[i];
									}
									else
									{
										partAppliToAdd = listLogical[i];
									}

								}
								// Missing applicability
								else
								{
									String missingAppli[] = applicable.split(";");
									int j = 0;
									while (j < missingAppli.length)
									{
										ComplexConfigurationDto dtoConfigMissing = new ComplexConfigurationDto();
										dtoConfigMissing = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(missingAppli[j], idLanguage, true, isCV, mapConfigStore);
										if (missingApplicability.equals(""))
										{
											missingApplicability = dtoConfigMissing.getConfigurationLabel();
										}
										else if (!missingApplicability.contains(dtoConfigMissing.getConfigurationLabel()))
										{
											missingApplicability = missingApplicability + "\n" + dtoConfigMissing.getConfigurationLabel();
										}
										j++;
									}
								}
								i++;
							}

							// Save only when cloning. Not for the check
							if (isForTheCloning)
							{
								if (!partAppliToAdd.equals(""))
								{
									// Check the part
									MpOperationPartDto mpPartDto = new MpOperationPartBusiness().checkMpOperationPart(opeSeriesDto.getId(), dto.getCodePart(), dto.getQuantity().longValue());
									if (mpPartDto != null)
									{
										OperationPartApplicabilityDto appliPartDtoToAdd = new OperationPartApplicabilityDto();
										appliPartDtoToAdd.setId(null);
										appliPartDtoToAdd.setIdOperationPart(dto.getId());
										appliPartDtoToAdd.setMarket(appliDto.getMarketId());
										appliPartDtoToAdd.setConfig(partAppliToAdd);
										new OperationPartBusiness().addApplicability(appliPartDtoToAdd);
									}
								}
							}

							// Destination applicability
							String appliDestination[] = iceCodeDestSerie.split("[.]", 4);
							SerieDto destinationSeriesDto = new SerieBusiness().getIdSeries(appliDestination[0], appliDestination[1], appliDestination[2], appliDestination[3]);
							String destSeriesLabel = new SerieBusiness().getSerieById(destinationSeriesDto.getId()).getAName();

							ComplexConfigurationDto dtoConf = new ComplexConfigurationDto();

							String newApp = "";

							if (!partAppliToAdd.equals(""))
							{
								dtoConf = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(partAppliToAdd, idLanguage, true, isCV, mapConfigStore);
								newApp = iceCodeDestSerie + " - " + destSeriesLabel + UtilConfiguration.getConfigurationLabelMultiline(dtoConf.getConfigurationLabel());
							}
							else
							{
								newApp = iceCodeDestSerie + " - " + destSeriesLabel;
							}

							// Original App , New App and Missing App
							if (applicability.equals("") && (!missingApplicability.equals("")))
							{
								applicability = codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + newApp + "^" + missingApplicability;
							}
							else if (!missingApplicability.equals(""))
							{
								applicability = applicability + "@" + codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + newApp + "^"
										+ missingApplicability;
							}
						}

					}
					else if (appliDto.getModelId() == null && appliDto.getMarketId() != null)
					{
						//Check market exists
						//if no exist, the market applicability is not saved
						boolean marketExist = false;
						//check market 
						for (Dto marketDto : marketsTargetSeries)
						{
							if (((MarketDto) marketDto).getMkId().equals(appliDto.getMarketId()))
							{
								marketExist = true;
								break;
							}
						}
						if (!marketExist)
						{
							// Original App , New App and Missing App
							// Without config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_MARKET;
							}
						}
						else
						{
							// Save only when cloning. Not for the check
							if (isForTheCloning)
							{
								// Check the part
								MpOperationPartDto mpPartDto = new MpOperationPartBusiness().checkMpOperationPart(opeSeriesDto.getId(), dto.getCodePart(), dto.getQuantity().longValue());
								if (mpPartDto != null)
								{
									OperationPartApplicabilityDto appliPartDtoToAdd = new OperationPartApplicabilityDto();
									appliPartDtoToAdd.setId(null);
									appliPartDtoToAdd.setIdOperationPart(dto.getId());
									appliPartDtoToAdd.setMarket(appliDto.getMarketId());
									new OperationPartBusiness().addApplicability(appliPartDtoToAdd);
								}
							}
						}
					}
					// If the applicability is at Model or TT/BM level (with or without configuration), the applicability is not copied
					else if (appliDto.getModelId() != null)
					{
						if (appliDto.getConfigId() != null)
						{
							// With config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITH_CONF;
							}
						}
						else
						{
							// Without config
							if (applicability.equals(""))
							{
								applicability = codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITHOUT_CONF;
							}
							else
							{
								applicability = applicability + "@" + codeOp + "^" + dto.getPartLabel() + "^" + "" + "^" + "" + "^" + applicabilityToDisplay + "^" + Constants.APP_WITHOUT_CONF;
							}
						}
					}
				}

			}

		}
		return applicability;
	}
	/*
	public void cloneAnOperation(String idSeriesOperation, String iceCodeDestSerie, String idOperationDest, String idLanguage) throws SystemException, ApplicativeException 
	{
		if (idSeriesOperation != null && !idSeriesOperation.equals(""))
		{
			// Operation_Series duplication
			OperationSeriesDto opeSeriesDto = new OperationSeriesBusiness().get(idSeriesOperation);
			opeSeriesDto.setId(null);
	
			// We can duplicate OperationSeries into an other Series
			if (iceCodeDestSerie != null && !iceCodeDestSerie.equals(""))
			{
				String appli[] = iceCodeDestSerie.split("[.]", 4);
				opeSeriesDto.setApplicabilityBrandIceCode(appli[0]);
				opeSeriesDto.setApplicabilityTypeIceCode(appli[1]);
				opeSeriesDto.setApplicabilityProductIceCode(appli[2]);
				opeSeriesDto.setApplicabilitySeriesIceCode(appli[3]);
			}
			// Or associated to an other Operation
			else if (idOperationDest != null && !idOperationDest.equals(""))
			{
				opeSeriesDto.setIdOperation(Long.parseLong(idOperationDest));
			}
			new OperationSeriesBusiness().save(opeSeriesDto);
	
			//Operation_Performance & Operation_condition duplication
			List<OperationPerformanceDto> listOpePerfDto = new OperationPerformanceBusiness().getList(idSeriesOperation, idLanguage);
			for (OperationPerformanceDto dto : listOpePerfDto)
			{
				Long idPerf = dto.getIdPerformance();
				dto.setIdPerformance(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationPerformanceBusiness().clone(dto, idPerf);
	
				//Operation_Perf_Applicability duplication 
				List<OperationPerformanceApplicabilityDto> listOpePerfAppliDto = new OperationPerformanceBusiness().getListApplicabilityByPerf(idPerf.toString());
				for (OperationPerformanceApplicabilityDto opePerfAppliDto : listOpePerfAppliDto)
				{
					opePerfAppliDto.setId(null);
					opePerfAppliDto.setIdPerformance(dto.getIdPerformance());
					new OperationPerformanceBusiness().addApplicability(opePerfAppliDto);
				}
			}
	
			//Operation_consumable duplication
			List<OperationConsumableDto> listOpeConsDto = new OperationConsumableBusiness().getList(idSeriesOperation, idLanguage);
			for (OperationConsumableDto dto : listOpeConsDto)
			{
				Long idCons = dto.getId();
				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationConsumableBusiness().save(dto);
	
				//Operation_Perf_Applicability duplication 
				List<OperationConsumableApplicabilityDto> listOpeConsAppliDto = new OperationConsumableBusiness().getListApplicabilityByCons(idCons.toString());
				for (OperationConsumableApplicabilityDto opeConsAppliDto : listOpeConsAppliDto)
				{
					opeConsAppliDto.setId(null);
					opeConsAppliDto.setIdOperationConsumable(dto.getId());
					new OperationConsumableBusiness().addApplicability(opeConsAppliDto);
				}
			}
	
			//Operation_part_number & Part_number duplication
			List<OperationPartDto> listOpePartNbDto = new OperationPartBusiness().getList(idSeriesOperation);
			for (OperationPartDto dto : listOpePartNbDto)
			{
				Long idPart = dto.getId();
				dto.setId(null);
				dto.setIdOperationSeries(opeSeriesDto.getId());
				new OperationPartBusiness().save(dto);
	
				//Operation_Perf_Applicability duplication 
				List<OperationPartApplicabilityDto> listOpePartAppliDto = new OperationPartBusiness().getListApplicabilityByPart(idPart.toString());
				for (OperationPartApplicabilityDto opePartAppliDto : listOpePartAppliDto)
				{
					opePartAppliDto.setId(null);
					opePartAppliDto.setIdOperationPart(dto.getId());
					new OperationPartBusiness().addApplicability(opePartAppliDto);
				}
			}
		}
		
	}
	*/

	/**
	 * delete operation.
	 * 
	 * @param projectId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(Long projectId) throws SystemException, ApplicativeException {
		new OperationSeriesAccess().delete(projectId);

	}
}
