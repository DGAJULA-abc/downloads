/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationSeriesAccess;
import capgemini.cnh.maintenanceplan.access.OperationSeriesConsCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesConsCompareDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesConsCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationSeriesConsCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of operations.
	 * 
	 * @param language for translated texts
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getList(String language, String brand, String type, String product, String series) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().getList(language, brand, type, product, series);
	}

	/**
	 * save one operations.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(OperationSeriesDto dto) throws SystemException, ApplicativeException {
		if (dto.getId() == null)
		{
			new OperationSeriesAccess().add(dto);
		}
		else
		{
			new OperationSeriesAccess().update(dto);
		}
	}

	/**
	 * delete operation.
	 * 
	 * @param operationSeriesId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(String operationSeriesId) throws SystemException, ApplicativeException {
		new OperationSeriesAccess().delete(operationSeriesId);

	}

	/**
	 * Get the List of series associated to a given operation.
	 * 
	 * @param idOperation to filter
	 * @return the list of associated series
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOfSeries(String idOperation) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().getListOfSeries(idOperation);
	}

	/**
	 * Get one association operation/series.
	 * 
	 * @param idSeriesOperation to get
	 * @return association operation/series
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public OperationSeriesDto get(String idSeriesOperation) throws SystemException, ApplicativeException {

		return new OperationSeriesAccess().get(idSeriesOperation);
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesConsCompareDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException, ApplicativeException {
		return new OperationSeriesConsCompareAccess().getListOperationSeriesByProject(idProject, language);
	}

	/**
	 * Get the list of operations by project.
	 * 
	 * @param idProject : id of the project
	 * @return the list of Operations by Series for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesDto> getListOperationSeriesByProject(Long idProject) throws SystemException, ApplicativeException {
		return new OperationSeriesAccess().getListOperationSeriesByProject(idProject);
	}

	/**
	 * Get the operations.
	 * 
	 * @param opeSerId : opeSerId
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationSeriesConsCompareDto getOperationSeries(Long opeSerId, String language) throws SystemException {
		return new OperationSeriesConsCompareAccess().getOperationSeries(opeSerId, language);
	}
}
