/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationSeriesIntervalCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesIntervalCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesIntervalCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationSeriesIntervalCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesIntervalCompareDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException, ApplicativeException {
		return new OperationSeriesIntervalCompareAccess().getListOperationSeriesByProject(idProject, language);
	}

}
