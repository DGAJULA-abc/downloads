/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationSeriesPartCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesPartCompareDto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesPartCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationSeriesPartCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesPartCompareDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException, ApplicativeException {
		return new OperationSeriesPartCompareAccess().getListOperationSeriesByProject(idProject, language);
	}

	/**
	 * Get the operations.
	 * 
	 * @param opeSerId : opeSerId
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationSeriesPartCompareDto getOperationSeries(Long opeSerId, String language) throws SystemException {
		return new OperationSeriesPartCompareAccess().getOperationSeries(opeSerId, language);
	}
}
