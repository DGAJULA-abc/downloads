/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.OperationSeriesPerfCompareAccess;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesPerfCompareDto;

/**
 * @author mamestoy
 *
 */
public class OperationSeriesPerfCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public OperationSeriesPerfCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the list of operations.
	 * 
	 * @param idProject : id of the project
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<OperationSeriesPerfCompareDto> getListOperationSeriesByProject(String idProject, String language) throws SystemException, ApplicativeException {
		return new OperationSeriesPerfCompareAccess().getListOperationSeriesByProject(idProject, language);
	}

	/**
	 * Get the operations.
	 * 
	 * @param opeSerId : opeSerId
	 * @param language for translated texts
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public OperationSeriesPerfCompareDto getOperationSeries(Long opeSerId, String language) throws SystemException {
		return new OperationSeriesPerfCompareAccess().getOperationSeries(opeSerId, language);
	}

}
