/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.KitCompositionAccess;
import capgemini.cnh.maintenanceplan.access.PartAccess;
import capgemini.cnh.maintenanceplan.access.PartHistoryAccess;
import capgemini.cnh.maintenanceplan.dto.KitCompositionDto;
import capgemini.cnh.maintenanceplan.dto.PartDto;
import capgemini.cnh.maintenanceplan.dto.PartHistoryDto;

/**
 * @author sdomecq
 *
 */
public class PartBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public PartBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the list of parts.
	 * 
	 * @param currentLang to filter
	 * @param defaultLang to filter
	 * @return the list of parts
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PartDto> getList(String currentLang, String defaultLang) throws SystemException, ApplicativeException {

		return new PartAccess().getList(currentLang, defaultLang);
	}

	/**
	 * Get the substitute if exists for a list of part.
	 * 
	 * @param listPart to search
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PartHistoryDto> getSubstitute(List<String> listPart) throws SystemException, ApplicativeException {

		return new PartHistoryAccess().getSubstitute(listPart);
	}

	/**
	 * Get the composition (list of part number) of a kit.
	 * 
	 * @param selectedKitId to search
	 * @return a list of associated part number
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<KitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException, ApplicativeException {

		return new KitCompositionAccess().getPartsListByKit(selectedKitId);
	}

	/**
	 * Get the original part if exists for a list of part.
	 * 
	 * @param listPart to search
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PartHistoryDto> getOriginal(List<String> listPart) throws SystemException {

		return new PartHistoryAccess().getOriginal(listPart);
	}

	/**
	 * Get the substitute if exists for a list of part after the date.
	 * 
	 * @param part the part to search
	 * @param date the date after
	 * @return if part number code/supersessionCode exists
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PartHistoryDto> getSubstituteAfterDate(String part, String date) throws SystemException, ApplicativeException {

		return new PartHistoryAccess().getSubstituteAfterDate(part, date);
	}

	/**
	 * Get the part.
	 * 
	 * @param pnCode : part number Code
	 * @return the part number
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public PartDto getPartByCode(String pnCode) throws SystemException, ApplicativeException {
		return new PartAccess().getPartByCode(pnCode);
	}

}
