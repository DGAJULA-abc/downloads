/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;
import java.util.Map;

import capgemini.cnh.cnhadmin.business.ManagerConfigurationBusiness;
import capgemini.cnh.cnhadmin.util.UtilConfiguration;
import capgemini.cnh.common.access.AllApplicabilityAccess;
import capgemini.cnh.common.dto.AllApplicabilityDto;
import capgemini.cnh.common.dto.ComplexConfigurationDto;
import capgemini.cnh.common.util.Constants;
import capgemini.cnh.component.dto.ConfigurationDto;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.ConditionAccess;
import capgemini.cnh.maintenanceplan.access.IntervalAccess;
import capgemini.cnh.maintenanceplan.access.IntervalOperationAccess;
import capgemini.cnh.maintenanceplan.access.PlanAccess;
import capgemini.cnh.maintenanceplan.access.PlanApplicabilityAccess;
import capgemini.cnh.maintenanceplan.dto.CloneSeriesDto;
import capgemini.cnh.maintenanceplan.dto.ConditionDto;
import capgemini.cnh.maintenanceplan.dto.OperationSeriesDto;
import capgemini.cnh.maintenanceplan.dto.PlanApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.PlanDto;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;
import capgemini.cnh.product.business.SerieBusiness;
import capgemini.cnh.product.dto.BrandDto;
import capgemini.cnh.product.dto.SerieDto;

/**
 * @author sdomecq
 *
 */
public class PlanBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public PlanBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of plan .
	 * 
	 * @param planProjectId filter
	 * @param language for translated texts
	 * @param mode to find the status of plans
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PlanDto> getList(String planProjectId, String language, String mode) throws SystemException, ApplicativeException {

		return new PlanAccess().getList(planProjectId, language, mode);
	}

	/**
	 * delete record for a given id.
	 * 
	 * @param idPlan to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(String idPlan) throws SystemException, ApplicativeException {
		// MP_MAINTENANCE_PLAN
		new PlanAccess().delete(idPlan);
		// MP_MAINTENANCE_CONDITION
		new ConditionAccess().deletePlanCondition(idPlan);
		// MP_PLAN_APPLICABILITY
		new PlanApplicabilityAccess().deleteByPlanId(idPlan);
		// MP_INTERVAL_OPERATION
		new IntervalOperationAccess().deleteByPlanId(idPlan);
		// MP_INTERVAL
		new IntervalAccess().deleteByPlan(idPlan);
	}

	/**
	 * save plan.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(PlanDto dto) throws SystemException, ApplicativeException {

		if (dto.getId() == null)
		{
			dto.setId(new PlanAccess().add(dto));
		}
		else
		{
			new PlanAccess().update(dto);
		}

	}

	/**
	 * save operations/performance.
	 * 
	 * @param dto to save
	 * @param user : last modifier
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void saveCondition(ConditionDto dto, String user) throws SystemException, ApplicativeException {
		PlanBusiness business = new PlanBusiness();

		if (dto.getIdCondition() == null)
		{
			new ConditionAccess().addPlanCondition(dto);
		}
		else
		{

			new ConditionAccess().updatePlanCondition(dto);

			// When the applicability is added or updated, the last modifier and the last modif date are update in the MP_MAINTENANCE_PLAN table
			business.update(dto.getIdPlan().toString(), user);

		}
	}

	/**
	 * add applicability for given plan.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void addApplicability(PlanApplicabilityDto dto) throws SystemException, ApplicativeException {
		new PlanApplicabilityAccess().add(dto);
	}

	/**
	 * delete appli for a given plan.
	 * 
	 * @param idPlan to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void deleteApplicabilityByPlan(String idPlan) throws SystemException, ApplicativeException {
		new PlanApplicabilityAccess().deleteByPlanId(idPlan);
	}

	/**
	 * Get the List of condition .
	 * 
	 * @param planId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<ConditionDto> getConditionList(String planId) throws SystemException, ApplicativeException {

		return new ConditionAccess().getListMaintenanceCondition(planId);
	}

	/**
	 * Get the List of Applicability .
	 * 
	 * @param planId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PlanApplicabilityDto> getApplicabilityList(String planId) throws SystemException, ApplicativeException {
		return new PlanApplicabilityAccess().getListMaintenanceApplicability(planId);
	}

	/**
	 * Get the List of operation conditions .
	 * 
	 * @param maintenanceAppId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<PlanApplicabilityDto> getApplicabilityListOrdered(String maintenanceAppId) throws SystemException {
		return new PlanApplicabilityAccess().getListMaintenanceApplicabilityOrdered(maintenanceAppId);
	}

	/**
	 * Get the plan .
	 * 
	 * @param planId filter
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public PlanDto getPlanById(String planId) throws SystemException, ApplicativeException {

		return new PlanAccess().getPlanById(planId);
	}

	/**
	 * Clone maintenance plan.
	 * 
	 * @param isForTheCloning true if cloning of the series, false for check
	 * @param prjName the project name
	 * @param idSourceProject the id of the source project
	 * @param idDestProject the id of the destination project
	 * @param language language
	 * @param userName userName
	 * @param isInSameSeries clone in the same series or not ?
	 * @param iceCodeDestSerie ice code of the destination series
	 * @param iceCodeOriginalSeries ice code of the original series
	 * @param operationListInDestSeries operation list in destination series
	 * @return info for the excel report
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public String duplicateMaintenancePlan(Boolean isForTheCloning, String prjName, String idSourceProject, Long idDestProject, String language, String userName,
			String mode, boolean isInSameSeries, String iceCodeDestSerie, String iceCodeOriginalSeries, List<BrandDto> lstBrandDto, boolean isCV, List<String> configsTargetSeries,
			Map<String, ConfigurationDto> mapConfigStore, List<OperationSeriesDto> operationListInDestSeries)
			throws SystemException, ApplicativeException {

		String appliPlan = "";
		String appli = "";

		List<PlanDto> listPlanDto = new PlanBusiness().getList(idSourceProject, language, null);

		for (PlanDto dto : listPlanDto)
		{
			Long idPlan = dto.getId();
			Long prevPlanExtId = dto.getExtId();
			dto.setId(null);
			dto.setIdProject(idDestProject);
			// Save only for cloning. Not for the check
			if (isForTheCloning)
			{
				save(dto);

				//Maintenance_Condition duplication
				duplicateMaintenanceCondition(idPlan.toString(), dto.getId().toString());
			}

			// For the cloning, register in table MP_CLONE_SERIES
			if ("clone".equals(mode))
			{
				if (prevPlanExtId != null)
				{
					CloneSeriesDto cloneSeriesdto = new CloneSeriesDto();
					cloneSeriesdto.setIdProjectSrc(Long.parseLong(idSourceProject));
					cloneSeriesdto.setExtIdSrc(prevPlanExtId);
					if (new CloneSeriesBusiness().getRecordCloneForPrjPlanSrc(cloneSeriesdto) == null)
					{
						new CloneSeriesBusiness().save(cloneSeriesdto);
					}
				}
			}

			if ("versioning".equals(mode) || "clone".equals(mode))
			{
				if (isForTheCloning)
				{
					//Plan_applicability duplication
					appliPlan = duplicatePlanApplicability(isForTheCloning, dto, prjName, language, idSourceProject, idPlan.toString(), dto.getId().toString(), isInSameSeries, iceCodeDestSerie,
							iceCodeOriginalSeries, lstBrandDto, isCV, configsTargetSeries, mapConfigStore);

					if (!appliPlan.equals(""))
					{
						appli = appli + appliPlan + "@";
					}

					//MP_Interval and interval_operation
					//new IntervalBusiness().duplicateMaintenanceInterval(idPlan.toString(), dto.getId().toString(), language, userName, mode, operationListInDestSeries);
					new IntervalBusiness().duplicateMaintenanceInterval(idPlan.toString(), dto.getId().toString(), language, userName);
				}
				else
				{
					//Plan_applicability duplication
					//appli = duplicatePlanApplicability(isForTheCloning, dto, prjName, language, idSourceProject, idPlan.toString(), null, isInSameSeries, iceCodeDestSerie, iceCodeOriginalSeries, lstBrandDto);
					appliPlan = duplicatePlanApplicability(isForTheCloning, dto, prjName, language, idSourceProject, idPlan.toString(), null, isInSameSeries, iceCodeDestSerie, iceCodeOriginalSeries,
							lstBrandDto, isCV, configsTargetSeries, mapConfigStore);

					if (!appliPlan.equals(""))
					{
						appli = appli + appliPlan + "@";
					}
				}
			}

			if (isForTheCloning && "versioning".equals(mode))
			{
				// Update the ext id of the plan: if the previous extId = null take the id of the previous plan, else take the extId.
				Long extId = null;
				if (prevPlanExtId != null)
				{
					extId = prevPlanExtId;
				}
				else
				{
					extId = idPlan;
				}
				updateExtId(dto.getId(), extId);
			}

		}

		return appli;
	}

	/**
	 * Clone maintenance condition.
	 * 
	 * @param idSourcePlan the id of the source plan
	 * @param idDestPlan the id of the destination plan
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void duplicateMaintenanceCondition(String idSourcePlan, String idDestPlan) throws SystemException, ApplicativeException {
		List<ConditionDto> listConditionDto = new PlanBusiness().getConditionList(idSourcePlan);
		for (ConditionDto condDto : listConditionDto)
		{
			condDto.setIdCondition(null);
			condDto.setIdPlan(Long.parseLong(idDestPlan));
			new ConditionAccess().addPlanCondition(condDto);
		}
	}

	/**
	 * Clone plan applicability.
	 * 
	 * @param isForCloning true if clone of the series, false if chjeck
	 * @param dto the plan dto
	 * @param prjName name of the project
	 * @param idLanguage language
	 * @param idSourceProject the id of the source project
	 * @param idSourcePlan the id of the source plan
	 * @param idDestPlan the id of the destination plan
	 * @param isInSameSeries clone in the same series or not ?
	 * @param iceCodeDestSerie ice code of the destination series
	 * @param iceCodeOriginalSeries ice code of the original series
	 * @param lstBrandDto list of brands
	 * @return all the info for the excel file
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */

	public String duplicatePlanApplicability(Boolean isForCloning, PlanDto dto, String prjName, String idLanguage, String idSourceProject, String idSourcePlan, String idDestPlan,
			boolean isInSameSeries, String iceCodeDestSerie, String iceCodeOriginalSeries, List<BrandDto> lstBrandDto, boolean isCV, List<String> configsTargetSeries,
			Map<String, ConfigurationDto> mapConfigStore)
			throws SystemException, ApplicativeException {

		String applicability = "";

		// Clone in the same series
		if (isInSameSeries)
		{
			List<PlanApplicabilityDto> listApplicabilityDto = new PlanBusiness().getApplicabilityList(idSourcePlan);
			for (PlanApplicabilityDto appliDto : listApplicabilityDto)
			{
				appliDto.setId(null);
				appliDto.setIdPlan(Long.parseLong(idDestPlan));
				addApplicability(appliDto);
			}
		}
		// Clone in another series
		else
		{
			String conditionLabel = "";
			String perfType = "";

			// Condition
			ConditionDto condDto = dto.getCondition();

			if (condDto != null && condDto.getUsage() != null)
			{
				conditionLabel = condDto.getUsage().getValueTitle();
			}

			// Performance
			if (dto.getPerformanceType() != null)
			{
				perfType = dto.getPerformanceType();
			}

			ProjectDto projAppDto = new ProjectBusiness().getApp(idSourceProject);

			List<AllApplicabilityDto> applicabilityPlan = new AllApplicabilityAccess().getMaintenancePlanApplicabilityPlan(projAppDto.getApplicabilityId().toString(), idSourcePlan);
			for (AllApplicabilityDto appliDto : applicabilityPlan)
			{
				// If the applicability is at Series level with configuration, the applicability is partially copied if the configuration values don�t exist for the destination Series.
				if (appliDto.getModelId() == null && appliDto.getConfigId() != null)
				{
					// Label of the config applicability 

					// Check if configuration applicable in the new series
					String[] listLogical = appliDto.getConfigId().split("\\" + UtilConfiguration.LOGICAL_OPERATOR_OR);
					int i = 0;
					String applicable = "";
					String planAppliToAdd = "";
					String missingApplicability = "";
					while (i < listLogical.length)
					{
						applicable = UtilConfiguration.isPartOfConfigApplicable(listLogical[i], configsTargetSeries);
						if (applicable.equals(""))
						{
							if (!planAppliToAdd.equals(""))
							{
								planAppliToAdd = planAppliToAdd + "+" + listLogical[i];
							}
							else
							{
								planAppliToAdd = listLogical[i];
							}

						}
						// Missing applicability
						else
						{
							String missingAppli[] = applicable.split(";");
							int j = 0;
							while (j < missingAppli.length)
							{
								ComplexConfigurationDto dtoConfigMissing = new ComplexConfigurationDto();
								dtoConfigMissing = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(missingAppli[j], idLanguage, true, isCV, mapConfigStore);
								if (missingApplicability.equals(""))
								{
									missingApplicability = dtoConfigMissing.getConfigurationLabel();
								}
								else if (!missingApplicability.contains(dtoConfigMissing.getConfigurationLabel()))
								{
									missingApplicability = missingApplicability + "\n" + dtoConfigMissing.getConfigurationLabel();
								}
								j++;
							}
						}
						i++;
					}

					if (isForCloning)
					{
						if (!planAppliToAdd.equals(""))
						{
							PlanApplicabilityDto appliDtoToAdd = new PlanApplicabilityDto();
							appliDtoToAdd.setId(null);
							appliDtoToAdd.setIdPlan(Long.parseLong(idDestPlan));
							appliDtoToAdd.setConfig(planAppliToAdd);
							addApplicability(appliDtoToAdd);
						}
					}

					// Destination applicability
					String appliDestination[] = iceCodeDestSerie.split("[.]", 4);
					SerieDto destinationSeriesDto = new SerieBusiness().getIdSeries(appliDestination[0], appliDestination[1], appliDestination[2], appliDestination[3]);
					String destSeriesLabel = new SerieBusiness().getSerieById(destinationSeriesDto.getId()).getAName();

					ComplexConfigurationDto dtoConf = new ComplexConfigurationDto();

					String newApp = "";

					if (!planAppliToAdd.equals(""))
					{
						dtoConf = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(planAppliToAdd, idLanguage, true, isCV, mapConfigStore);
						newApp = iceCodeDestSerie + " - " + destSeriesLabel + UtilConfiguration.getConfigurationLabelMultiline(dtoConf.getConfigurationLabel());
					}
					else
					{
						newApp = iceCodeDestSerie + " - " + destSeriesLabel;
					}

					// Original App , New App and Missing App
					if (applicability.equals("") && (!missingApplicability.equals("")))
					{
						applicability = prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^" + displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore) + "^"
								+ newApp + "^"
								+ missingApplicability;
					}
					else if (!missingApplicability.equals(""))
					{
						applicability = applicability + "@" + prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^"
								+ displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore) + "^"
								+ newApp + "^" + missingApplicability;
					}
				}
				// If the applicability is at Model or TT/BM level (with or without configuration), the applicability is not copied
				else if (appliDto.getModelId() != null)
				{
					if (appliDto.getConfigId() != null)
					{
						// With config
						if (applicability.equals(""))
						{
							applicability = prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^" + displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore) + "^"
									+ Constants.APP_WITH_CONF;
						}
						else
						{
							applicability = applicability + "@" + prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^"
									+ displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore)
									+ "^"
									+ Constants.APP_WITH_CONF;
						}
					}
					else
					{
						// Without config
						if (applicability.equals(""))
						{
							applicability = prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^" + displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore) + "^"
									+ Constants.APP_WITHOUT_CONF;
						}
						else
						{
							applicability = applicability + "@" + prjName + "^" + dto.getName() + "^" + conditionLabel + "^" + perfType + "^"
									+ displayListApplicability(idLanguage, appliDto, isCV, mapConfigStore)
									+ "^"
									+ Constants.APP_WITHOUT_CONF;
						}
					}
				}
			}

		}
		return applicability;
	}

	/**
	 * update Last Modifier and Modif date of MP_MAINTENANCE_PLAN.
	 * 
	 * @param idPlan id of the plan to update
	 * @param lastModifier modifier for the update
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void update(String idPlan, String lastModifier) throws SystemException, ApplicativeException {
		new PlanAccess().update(idPlan, lastModifier);
	}

	/**
	 * Update the external id of the plan.
	 * 
	 * @param intId the internal id
	 * @param extId the external id to update
	 * @throws ApplicativeException applicativeException
	 * @throws SystemException systemException
	 * @throws ApplicativeException
	 */
	public void updateExtId(Long intId, Long extId) throws SystemException, ApplicativeException {
		new PlanAccess().updateExtId(intId, extId);
	}

	/**
	 * display list of applicability.
	 * 
	 * @param idLanguage : id of the lang
	 * @param app : applicability
	 * @throws ApplicativeException applicativeException
	 * @throws SystemException systemException
	 * @return the string of the applicability list
	 */

	public String displayListApplicability(String idLanguage, AllApplicabilityDto app, boolean isCV, Map<String, ConfigurationDto> mapConfigStore) throws SystemException, ApplicativeException {
		String applicability = "";
		ComplexConfigurationDto dtoConfig = new ComplexConfigurationDto();

		if (app.getConfigId() != null)
		{
			dtoConfig = new ManagerConfigurationBusiness().getComplexConfigurationWithPrpCodes(app.getConfigId(), idLanguage, true, isCV, mapConfigStore);

		}

		if (app.getModelId() != null)
		{
			if (app.getModelIceCode() != null)
			{
				if (app.getTechnicalTypeIceCode() == null)
				{
					applicability += app.getFullIceCode() + " - " + app.getModelName();
					if (app.getMarketName() != null)
					{
						applicability += " - " + app.getMarketName();
					}
					if (dtoConfig.getConfigurationLabel() != null)
					{
						applicability += " - \n" + UtilConfiguration.getConfigurationLabelMultiline(dtoConfig.getConfigurationLabel());
					}
				}
				else
				{
					applicability += app.getFullIceCode() + " - " + app.getTechnicalTypeLabel();
					if (app.getMarketName() != null)
					{
						applicability += " - " + app.getMarketName();
					}
					if (dtoConfig.getConfigurationLabel() != null)
					{
						applicability += " - \n" + UtilConfiguration.getConfigurationLabelMultiline(dtoConfig.getConfigurationLabel());
					}
				}
			}
		}
		else
		{
			applicability += app.getFullIceCode() + " - " + app.getSeriesName();
			if (app.getMarketName() != null)
			{
				applicability += " - " + app.getMarketName();
			}
			if (dtoConfig.getConfigurationLabel() != null)
			{
				applicability += " - \n" + UtilConfiguration.getConfigurationLabelMultiline(dtoConfig.getConfigurationLabel());
			}
		}

		return applicability;
	}

	/**
	 * Get the valid plans from other versions of a project linked by external id.
	 * 
	 * @param id id of the plan
	 * @param extId External id of the plan
	 * @return the list of valid plans
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getValidPlansPreviousVersion(String id, String extId) throws SystemException {
		return new PlanAccess().getValidPlansPreviousVersion(id, extId);
	}

	/**
	 * Get the draft plans linked to thsi plan that have already been exported to SAP.
	 * 
	 * @param id plan id
	 * @return the list of previously exported plans.
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getDraftPlansAlreadyExported(String id, Long extId) throws SystemException {
		return new PlanAccess().getDraftPlansAlreadyExported(id, extId);
	}

	/**
	 * Get the valid plans from the previous released project version.
	 * 
	 * @param projectId project id
	 * @param projectNumber project Number
	 * @return the valid plans from the previous released project version.
	 * @throws SystemException SystemException
	 */
	public List<PlanDto> getValidPlansPreviousProject(String projectId, String projectNumber) throws SystemException {
		return new PlanAccess().getValidPlansPreviousProject(projectId, projectNumber);
	}

	/**
	 * Get the plan applicabilities by project.
	 * 
	 * @param projectId project id
	 * @return the list of plan applicability
	 * @throws SystemException SystemException
	 */
	public List<PlanApplicabilityDto> getApplicabilityListByProject(String projectId) throws SystemException {
		return new PlanApplicabilityAccess().getApplicabilityListByProject(projectId);
	}

	/**
	 * Get the plan applicabilities by project and status.
	 * 
	 * @param projectId project id
	 * @param mode RELEASED or DRAFT
	 * @return the list of plan applicability
	 * @throws SystemException SystemException
	 */
	public List<PlanApplicabilityDto> getApplicabilityListByProject(String projectId, String mode) throws SystemException {
		return new PlanApplicabilityAccess().getApplicabilityListByProject(projectId, mode);
	}

}
