/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.PlanCompareAccess;
import capgemini.cnh.maintenanceplan.dto.PlanCompareDto;

/**
 * @author sdomecq
 *
 */
public class PlanCompareBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public PlanCompareBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of plan .
	 * 
	 * @param planProjectId filter
	 * @param language for translated texts
	 * @return the list of operations
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<PlanCompareDto> getList(String planProjectId, String language) throws SystemException, ApplicativeException {

		return new PlanCompareAccess().getList(planProjectId, language);
	}

}
