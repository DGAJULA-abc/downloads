/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.ConditionAccess;
import capgemini.cnh.maintenanceplan.access.IntervalAccess;
import capgemini.cnh.maintenanceplan.access.IntervalOperationAccess;
import capgemini.cnh.maintenanceplan.access.PlanAccess;
import capgemini.cnh.maintenanceplan.access.PlanApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.ProjectAccess;
import capgemini.cnh.maintenanceplan.access.ProjectApplicabilityAccess;
import capgemini.cnh.maintenanceplan.access.ProjectTimeSheetAccess;
import capgemini.cnh.maintenanceplan.access.StandardOilAccess;
import capgemini.cnh.maintenanceplan.access.StandardOilApplicabilityAccess;
import capgemini.cnh.maintenanceplan.dto.ProjectDto;
import capgemini.cnh.maintenanceplan.dto.ProjectTimeSheetDto;
import capgemini.cnh.maintenanceplan.dto.StandardOilApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.StandardOilDto;

/**
 * @author sdomecq
 *
 */
public class ProjectBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public ProjectBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of project.
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @param statusList Status of prj to be filtered if needed ?
	 * @param isPrjSelected Project displayed in tab or not ?
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getList(String brand, String type, String product, String series, String statusList, Boolean isPrjSelected, String projectId) throws SystemException, ApplicativeException {

		return new ProjectAccess().getList(brand, type, product, series, statusList, isPrjSelected, projectId);
	}

	/**
	 * Get the List of projects for a series (2 last versions of Preliminary and Released projects).
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	//	public List<ProjectDto> getTwoLastVersionsProjectsList(String brand, String type, String product, String series) throws SystemException, ApplicativeException {
	//
	//		return new ProjectAccess().getTwoLastVersionsProjectsList(brand, type, product, series);
	//	}

	/**
	 * Get the List of Released projects. If several records for one project -> max version is taken into account
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getListReleasedForMaxVersion(String brand, String type, String product, String series) throws SystemException, ApplicativeException {

		return new ProjectAccess().getListReleasedForMaxVersion(brand, type, product, series);
	}

	/**
	 * Get the project
	 * 
	 * @param number : project number
	 * @param version : version of the project
	 * @return the project
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getProjectForNumberAndVersion(String number, String version) throws SystemException, ApplicativeException {

		return new ProjectAccess().getProjectForNumberAndVersion(number, version);
	}

	/**
	 * Get the List of Released project.
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getListReleased(String brand, String type, String product, String series) throws SystemException, ApplicativeException {

		return new ProjectAccess().getListReleased(brand, type, product, series);
	}

	/**
	 * Get the List of Preliminary project.
	 * 
	 * @param brand filter
	 * @param type filter
	 * @param product filter
	 * @param series filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getListDraft(String brand, String type, String product, String series) throws SystemException, ApplicativeException {

		return new ProjectAccess().getListDraft(brand, type, product, series);
	}

	/**
	 * save one project.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void save(ProjectDto dto) throws SystemException, ApplicativeException {
		if (dto.getId() == null)
		{
			new ProjectAccess().add(dto);
		}
		else
		{
			new ProjectAccess().update(dto);
		}
	}

	/**
	 * delete project.
	 * 
	 * @param projectId to delete
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void delete(String projectId) throws SystemException, ApplicativeException {
		// MP_Maintenance_project
		new ProjectAccess().delete(projectId);
		// MP_APPLICABILITY_TS
		new ProjectTimeSheetAccess().deleteByProjectId(projectId);
		// MP_PROJECT_APPLICABILITY
		new ProjectApplicabilityAccess().deleteByProjectId(projectId);
		// MP_PLAN_APPLICABILITY
		new PlanApplicabilityAccess().deleteByProjectId(projectId);
		// MP_INTERVAL_OPERATION
		new IntervalOperationAccess().deleteByProjectId(projectId);
		// MP_INTERVAL
		new IntervalAccess().deleteByProjectId(projectId);
		// MP_MAINTENANCE_CONDITION
		new ConditionAccess().deleteByProjectId(projectId);
		// MP_MAINTENANCE_PLAN
		new PlanAccess().deletePlanForProject(projectId);
		// MP_STD_OIL_APPLICABILITY
		new StandardOilApplicabilityAccess().deleteByProjectId(projectId);
		// MP_STD_OIL
		new StandardOilAccess().deleteByProjectId(projectId);
	}

	/**
	 * add project comment.
	 * 
	 * @param projectId to filter
	 * @param comment to set
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void updateComment(String projectId, String comment) throws SystemException, ApplicativeException {
		new ProjectAccess().updateComment(projectId, comment);
	}

	/**
	 * save project applicability.
	 * 
	 * @param dto to save
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void saveApplicability(ProjectDto dto) throws SystemException, ApplicativeException {
		new ProjectApplicabilityAccess().add(dto);
	}

	/**
	 * save project timesheet.
	 * 
	 * @param dtoList to save
	 * @param projectId filter
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void saveTimesheetList(List<ProjectTimeSheetDto> dtoList, String projectId) throws SystemException, ApplicativeException {
		ProjectTimeSheetAccess access = new ProjectTimeSheetAccess();
		access.deleteByProjectId(projectId);
		for (ProjectTimeSheetDto dto : dtoList)
		{
			access.add(dto);
		}
	}

	/**
	 * get project comment.
	 * 
	 * @param projectId to filter
	 * @return comment
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getComment(String projectId) throws SystemException, ApplicativeException {
		return new ProjectAccess().getComment(projectId);
	}

	/**
	 * Get the List of project applicability.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getApp(String idProject) throws SystemException, ApplicativeException {
		return new ProjectApplicabilityAccess().getApp(idProject);
	}

	/**
	 * Get the List of timesheet.
	 * 
	 * @param appliId filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	/*
	public List<ProjectTimeSheetDto> getListTimeSheet(String appliId) throws SystemException, ApplicativeException {
	
		return new ProjectTimeSheetAccess().getList(appliId);
	}
	*/

	/**
	 * Get the maintenance project .
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getMaintenanceProject(String idProject) throws SystemException, ApplicativeException {
		return new ProjectAccess().getMaintenanceProject(idProject);
	}

	/**
	 * Get the maintenance project to export for the WU.
	 * 
	 * @param idProject : id of the project
	 * @param languageId : EN for AG&CE, IT for CV
	 * @return the list of the project/plans
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getMaintenancePlansProjectWithOpforWUToExport(String idProject, String languageId) throws SystemException, ApplicativeException {
		return new ProjectAccess().getMaintenancePlansProjectWithOpforWUToExport(idProject, languageId);
	}

	/**
	 * Get the maintenance project to export for the WU.
	 * 
	 * @param idProject : id of the project
	 * @param languageId : EN for AG&CE, IT for CV
	 * @return the list of the project/plans
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getMaintenancePlansProjectforWUToExport(String idProject, String languageId) throws SystemException, ApplicativeException {
		return new ProjectAccess().getMaintenancePlansProjectforWUToExport(idProject, languageId);
	}

	/**
	 * Get the maintenance project App.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getMaintenanceProjectApp(String idProject) throws SystemException, ApplicativeException {
		return new ProjectAccess().getMaintenanceProjectApp(idProject);
	}

	/**
	 * Get the project without user information.
	 * 
	 * @param idProject : id of the project
	 * @return the list of applicability for the project
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public ProjectDto getMaintenanceProjectWithoutUser(String idProject) throws SystemException {
		return new ProjectAccess().getMaintenanceProjectWithoutUser(idProject);
	}

	/**
	 * Clone project applicability and applicability timesheets.
	 * 
	 * @param idSourceProject the id of the source project
	 * @param idDestProject the id of the destination project
	 * @param fullIceCodeSerie the iceCode of the serie if the new project is in another serie
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void duplicateProjectApplicability(String idSourceProject, String idDestProject, String fullIceCodeSerie) throws SystemException, ApplicativeException {
		ProjectDto projAppDto = getApp(idSourceProject);

		// Project_Applicability duplication
		//Long idProjAppSource = projAppDto.getApplicabilityId();
		projAppDto.setId(Long.parseLong(idDestProject));
		projAppDto.setApplicabilityId(null);

		if (fullIceCodeSerie != null && !fullIceCodeSerie.equals(""))
		{
			String appli[] = fullIceCodeSerie.split("[.]", 4);
			projAppDto.setApplicabilityBrandIceCode(appli[0]);
			projAppDto.setApplicabilityTypeIceCode(appli[1]);
			projAppDto.setApplicabilityProductIceCode(appli[2]);
			projAppDto.setApplicabilitySeriesIceCode(appli[3]);
		}
		saveApplicability(projAppDto);

	}

	/**
	 * Clone project standard oils with their applicabilities.
	 * 
	 * @param idSourceProject the id of the source project
	 * @param idDestProject the id of the destination project
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public void duplicateProjectStandardOilsWithAppicability(String idSourceProject, String idDestProject) throws SystemException, ApplicativeException {
		StandardOilBusiness stdOilBusiness = new StandardOilBusiness();
		List<StandardOilDto> stdOils = stdOilBusiness.getListOilsByProject(idSourceProject);

		// Duplicate each standard oil
		for (StandardOilDto dto : stdOils)
		{
			StandardOilDto stdOilDto = new StandardOilDto();
			stdOilDto.setProjectId(Integer.parseInt(idDestProject));
			stdOilDto.setOilId(dto.getOilId());
			stdOilBusiness.addStandardOil(stdOilDto);

			// For each standard oils, duplicate the applicabilities
			StandardOilDto isStandard = stdOilBusiness.isStandard(idDestProject, stdOilDto.getOilId());
			List<StandardOilApplicabilityDto> apps = stdOilBusiness.getListOilApplicability(dto.getOilStdId().toString());
			for (StandardOilApplicabilityDto app : apps)
			{
				StandardOilApplicabilityDto newApp = new StandardOilApplicabilityDto();
				newApp.setIdStdOil(isStandard.getOilStdId());
				newApp.setModel(app.getModel());
				newApp.setTt(app.getTt());
				newApp.setMarket(app.getMarket());
				newApp.setConfig(app.getConfig());
				stdOilBusiness.addApplicability(newApp);
			}
		}
	}

	/**
	 * Get next id for version.
	 * 
	 * @param mpNumber : MP number
	 * @return the next id
	 * @throws SystemException system exception
	 * @throws ApplicativeException applicative exception
	 */
	public Long getNextId(String mpNumber) throws SystemException, ApplicativeException {
		ProjectAccess access = new ProjectAccess();
		Long nextId = access.getNextId(mpNumber);

		if (null == nextId)
		{
			nextId = new Long(1);
		}
		return nextId;
	}

	/**
	 * Get max MP_NUMERO to calculate the next one.
	 * 
	 * @return the next project number
	 * @throws SystemException system exception
	 * @throws ApplicativeException applicative exception
	 */
	public Long searchExistingMPNumber() throws SystemException, ApplicativeException {
		ProjectAccess access = new ProjectAccess();
		Long nextId = access.searchExistingMPNumber();

		if (null == nextId)
		{
			nextId = new Long(1);
		}
		return nextId;
	}

	/**
	 * Get the List of existing projects with same number and version.
	 * 
	 * @param number filter
	 * @param version filter
	 * @param id filter
	 * @return the list of projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getListForNumberAndVersion(String number, String version, String id) throws SystemException, ApplicativeException {

		return new ProjectAccess().getListForNumberAndVersion(number, version, id);
	}

	/**
	 * Get released project()s with a higher version.
	 * 
	 * @param number : number of the project
	 * @param version : version of the project
	 * @return the released project()s with a higher version.
	 * @throws SystemException System exception
	 */
	public List<ProjectDto> getReleasedProjectsWithHigherVersion(String number, String version) throws SystemException {
		return new ProjectAccess().getReleasedProjectsWithHigherVersion(number, version);
	}

	/**
	 * Get the last version project, Released or Preliminary.
	 * 
	 * @param project the current project
	 * @return the previous project exported
	 * @throws SystemException SystemException
	 */
	public ProjectDto getLastVersion(ProjectDto project) throws SystemException {
		return new ProjectAccess().getLastVersion(project);
	}

	/**
	 * Update release type of all the versions of the project.
	 * 
	 * @param projectNumber the project number
	 * @throws SystemException SystemException
	 */
	public void updateReleaseTypeOfAllVersionsForProject(ProjectDto project) throws SystemException {
		new ProjectAccess().updateReleaseTypeOfAllVersionsForProject(project);
	}

	/**
	 * Set the last report generated for check consistency.
	 * 
	 * @param idProject the project id
	 * @param fileName the report file name
	 * 
	 * @throws SystemException SystemException
	 */
	public void setLastReport(Long idProject, String fileName) throws SystemException {
		new ProjectAccess().setLastReport(idProject, fileName);
	}

	/**
	 * Get the List of projects associated to a given operation.
	 * 
	 * @param idOperation to filter
	 * @return the list of associated projects
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<ProjectDto> getListOfProjectsLinkedToAnOp(String idOperation) throws SystemException, ApplicativeException {

		return new ProjectAccess().getListOfProjectsLinkedToAnOp(idOperation);
	}

	/**
	 * Set the flag to true/false if a project must be displayed or not in tabs (for a selected series).
	 * 
	 * @param flag the flag to put
	 * @param projectId the id of the project
	 * 
	 * @throws SystemException SystemException
	 */
	public void updateLink(Boolean flag, String projectId) throws SystemException {
		new ProjectAccess().updateLink(flag, projectId);
	}

	/**
	 * Get the project associated to a given operation and an project Id.
	 * 
	 * @param idOperation to filter
	 * @param idPrj to filter
	 * @return the associated project
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public ProjectDto getProjectLinkedToAnOpAndPrjId(String idOperation, String idPrj) throws SystemException, ApplicativeException {

		return new ProjectAccess().getProjectLinkedToAnOpAndPrjId(idOperation, idPrj);
	}

	/**
	 * set the project selected in tab.
	 * 
	 * @param projectId to filter
	 * @param isSelected : is_selected to set
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void updatePrjSelected(String projectId, Boolean isSelected) throws SystemException, ApplicativeException {
		new ProjectAccess().updatePrjSelected(projectId, isSelected);
	}
}
