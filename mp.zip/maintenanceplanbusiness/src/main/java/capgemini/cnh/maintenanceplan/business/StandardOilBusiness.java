package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.StandardOilAccess;
import capgemini.cnh.maintenanceplan.access.StandardOilApplicabilityAccess;
import capgemini.cnh.maintenanceplan.dto.StandardOilApplicabilityDto;
import capgemini.cnh.maintenanceplan.dto.StandardOilDto;

/**
 * Business class for the standard oils.
 * 
 * @author mdaudign
 */
public class StandardOilBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public StandardOilBusiness() throws SystemException {
		super();
	}

	/**
	 * Check if an oil is standard for a project.
	 * 
	 * @param oilId the id of the oil
	 * @param projectId the id of the project
	 * @return a StandardOilDto if the oil is standard, null if not
	 * @throws SystemException Cannot execute query or access to database
	 * @throws ApplicativeException application exception
	 */
	public StandardOilDto isStandard(String projectId, Long oilId) throws SystemException, ApplicativeException {
		return new StandardOilAccess().isStandard(projectId, oilId);
	}

	/**
	 * Add a standard oil.
	 * 
	 * @param dto the oil
	 * @throws SystemException Cannot execute query or access to database
	 * @throws ApplicativeException application exception
	 */
	public void addStandardOil(StandardOilDto dto) throws SystemException, ApplicativeException {
		new StandardOilAccess().addStandardOil(dto);
	}

	/**
	 * Delete a standard oil.
	 * 
	 * @param dto the oil
	 * @throws SystemException Cannot execute query or access to database
	 * @throws ApplicativeException application exception
	 */
	public void deleteStandardOil(StandardOilDto dto) throws SystemException, ApplicativeException {
		new StandardOilAccess().deleteStandardOil(dto);
	}

	/**
	 * Get the standard oils for a project.
	 * 
	 * @param projectId the id of the project
	 * @return a list of standard oils
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<StandardOilDto> getListOilsByProject(String projectId) throws SystemException, ApplicativeException {
		return new StandardOilAccess().getListOilsByProject(projectId);
	}

	/**
	 * Delete the standard oils for a project.
	 * 
	 * @param idProject to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void deleteByProjectId(String idProject) throws SystemException, ApplicativeException {
		new StandardOilAccess().deleteByProjectId(idProject);
	}

	/**
	 * Add applicability for a standard oil.
	 * 
	 * @param dto to save
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void addApplicability(StandardOilApplicabilityDto dto) throws SystemException, ApplicativeException {
		new StandardOilApplicabilityAccess().add(dto);
	}

	/**
	 * Delete applicability for a standard oil.
	 * 
	 * @param idOil to filter
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public void deleteApplicabilityByOil(String idOil) throws SystemException, ApplicativeException {
		new StandardOilApplicabilityAccess().deleteByOilId(idOil);
	}

	/**
	 * Get the List of applicability for an oil.
	 * 
	 * @param idStdOil oil id filter
	 * @return the list of applicabilities
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<StandardOilApplicabilityDto> getListOilApplicability(String idStdOil) throws SystemException, ApplicativeException {
		return new StandardOilApplicabilityAccess().getListOilApplicability(idStdOil);
	}
}
