/**
 * 
 */
package capgemini.cnh.maintenanceplan.business;

import java.util.List;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.UnitSeriesAccess;
import capgemini.cnh.maintenanceplan.dto.UnitSeriesDto;

/**
 * @author langlade
 *
 */
public class UnitSeriesBusiness extends Business<UnitSeriesDto> {

//	/**
//	 * Define a logger.
//	 */
//	private TIDBLogger logger = TIDBLogger.getLogger(this.getClass());

	/**
	 * Data source access.
	 */
	private final UnitSeriesAccess access;

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public UnitSeriesBusiness() throws SystemException {
		this(new UnitSeriesAccess());
	}

	/**
	 * Constructor.
	 * 
	 * @param access Data source access
	 * 
	 * @throws SystemException system exception
	 */
	private UnitSeriesBusiness(final UnitSeriesAccess access) throws SystemException {
		super(access);
		this.access = access;
	}

	/**
	 * Get the List of unit series.
	 * 
	 * @return the list of unit series
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<UnitSeriesDto> getList() throws SystemException, ApplicativeException {
		List<UnitSeriesDto> result = access.getList();
		return result;
	}

	/**
	 * Get the special unit for the ice code.
	 * 
	 * @param brandIceCode brand ice code
	 * @param typeIceCode type ice code
	 * @param productIceCode product ice code
	 * @param seriesIceCode series ice code
	 * 
	 * @return The special unit
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public UnitSeriesDto getSpecificUnit(
			String brandIceCode, String typeIceCode,
			String productIceCode, String seriesIceCode) throws SystemException {
		UnitSeriesDto result = access.getFromIceCode(brandIceCode, typeIceCode, productIceCode, seriesIceCode);
		return result;
	}

	/**
	 * Delete a specific unit.
	 * 
	 * @param unitSeries The unit series to delete
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean deleteSpecificUnit(UnitSeriesDto unitSeries) throws SystemException {
		return access.delete(unitSeries);
	}

	/**
	 * Clone an original specific unit to a destination specific unit.
	 * 
	 * @param originalUnitSeries the original specific unit to clone
	 * @param brandIceCodeDestination brand ice code of the series of the destination specific unit
	 * @param typeIceCodeDestination type ice code of the series of the destination specific unit
	 * @param productIceCodeDestination product ice code of the series of the destination specific unit
	 * @param seriesIceCodeDestination series ice code of the series of the destination specific unit
	 * 
	 * @return Success or failure
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean cloneSpecificUnit(
			UnitSeriesDto originalUnitSeries,
			String brandIceCodeDestination, String typeIceCodeDestination,
			String productIceCodeDestination, String seriesIceCodeDestination) throws SystemException {
		return access.clone(originalUnitSeries,
				brandIceCodeDestination, typeIceCodeDestination, productIceCodeDestination, seriesIceCodeDestination);
	}
}
