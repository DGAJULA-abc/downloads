package capgemini.cnh.maintenanceplan.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.access.UsageAccess;
import capgemini.cnh.maintenanceplan.dto.UsageDto;

/**
 * @author sdomecq
 *
 */
public class UsageBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public UsageBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of usage for a given language.
	 * 
	 * @param language for translated texts
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<UsageDto> getList(String language) throws SystemException, ApplicativeException {

		return new UsageAccess().getList(language);
	}

}
