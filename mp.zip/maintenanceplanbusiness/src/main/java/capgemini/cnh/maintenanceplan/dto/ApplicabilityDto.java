/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class ApplicabilityDto extends Dto implements Comparable {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** Id operation series. */
	private Long idOperationSeries = null;

	/** applicability. **/
	private String model = null;

	/** applicability. **/
	private String tt = null;
	/** applicability. **/
	private Long market = null;

	/** applicability. **/
	private String config;

	/**
	 * Constructor.
	 */
	public ApplicabilityDto() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param model the id to set
	 * @param tt the id to set
	 * @param market the id to set
	 * @param config the complex configuration
	 */
	public ApplicabilityDto(String model, String tt, Long market, String config) {
		super();
		this.model = model;
		this.tt = tt;
		this.market = market;
		this.config = config;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the tt
	 */
	public String getTt() {
		return tt;
	}

	/**
	 * @param tt the tt to set
	 */
	public void setTt(String tt) {
		this.tt = tt;
	}

	/**
	 * @return the market
	 */
	public Long getMarket() {
		return market;
	}

	/**
	 * @param market the market to set
	 */
	public void setMarket(Long market) {
		this.market = market;
	}

	/**
	 * @return the config
	 */
	public String getConfig() {
		return config;
	}

	/**
	 * @param config the config to set
	 */
	public void setConfig(String config) {
		this.config = config;
	}

	/**
	 * 
	 * @return the operation series id
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * 
	 * @param idOperationSeries the operation series id
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * Function needed to order applicabilities by Operation series id.
	 */
	@Override
	public int compareTo(Object o) {
		ApplicabilityDto other = (ApplicabilityDto) o;
		int result = 0;

		if (this.idOperationSeries.compareTo(other.idOperationSeries) < 0)
		{
			result = -1;
		}
		else if (this.idOperationSeries.compareTo(other.idOperationSeries) > 0)
		{
			result = 1;
		}

		return result;
	}
}
