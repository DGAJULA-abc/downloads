/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author langlade
 *
 */
public class CheckSeriesDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** brand ice code. **/
	private String brandIceCode = null;
	/** type ice code. **/
	private String typeIceCode = null;
	/** product ice code. **/
	private String productIceCode = null;
	/** series ice code. **/
	private String seriesIceCode = null;
	/** name of the project. **/
	private String projectName = null;
	/** number of the project. **/
	private String projectNumber = null;
	/** version of the project. **/
	private Integer projectVersion = null;
	/** start date. **/
	private Date start = null;
	/** end date. **/
	private Date end = null;
	/** is for release the project. **/
	private boolean isForRelease = false;
	/** status. **/
	private Byte status = null;
	/** report. **/
	private String report = null;

	/** Saved parameters for call to save project after release on warn. */
	private String idProject = null;
	/** Saved parameters for call to save project after release on warn. */
	private String selectedstatus = null;
	/** Saved parameters for call to save project after release on warn. */
	private String appliId = null;
	/** Saved parameters for call to save project after release on warn. */
	private String personalizedProject = null;
	/** Saved parameters for call to save project after release on warn. */
	private String oldstatus = null;
	/** Saved parameters for call to save project after release on warn. */
	private String standardOils = null;
	/** Saved parameters for call to save project after release on warn. */
	private String lastModifier = null;
	/** Saved parameters for call to save project after release on warn. */
	private String hasContract = null;
	/** Saved parameters for call to save project after release on warn. */
	private String releaseType = null;
	/** Saved parameters for call to save project after release on warn. */
	private String isUcr = null;
	/** Saved parameters for call to save project after release on warn. */
	private String customer = null;

	/**
	 * Constructor.
	 */
	public CheckSeriesDto() {
		super();
	}

	/**
	 * @return the brandIceCode
	 */
	public String getBrandIceCode() {
		return brandIceCode;
	}

	/**
	 * @param brandIceCode the brandIceCode to set
	 */
	public void setBrandIceCode(String brandIceCode) {
		this.brandIceCode = brandIceCode;
	}

	/**
	 * @return the typeIceCode
	 */
	public String getTypeIceCode() {
		return typeIceCode;
	}

	/**
	 * @param typeIceCode the typeIceCode to set
	 */
	public void setTypeIceCode(String typeIceCode) {
		this.typeIceCode = typeIceCode;
	}

	/**
	 * @return the productIceCode
	 */
	public String getProductIceCode() {
		return productIceCode;
	}

	/**
	 * @param productIceCode the productIceCode to set
	 */
	public void setProductIceCode(String productIceCode) {
		this.productIceCode = productIceCode;
	}

	/**
	 * @return the seriesIceCode
	 */
	public String getSeriesIceCode() {
		return seriesIceCode;
	}

	/**
	 * @param seriesIceCode the seriesIceCode to set
	 */
	public void setSeriesIceCode(String seriesIceCode) {
		this.seriesIceCode = seriesIceCode;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}


	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}


	/**
	 * @return the projectNumber
	 */
	public String getProjectNumber() {
		return projectNumber;
	}

	/**
	 * @param projectNumber the projectNumber to set
	 */
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	/**
	 * @return the projectVersion
	 */
	public Integer getProjectVersion() {
		return projectVersion;
	}

	/**
	 * @param projectVersion the projectVersion to set
	 */
	public void setProjectVersion(Integer projectVersion) {
		this.projectVersion = projectVersion;
	}

	/**
	 * @return the start
	 */
	public Date getStart() {
		return start;
	}

	/**
	 * @param start the start to set
	 */
	public void setStart(Date start) {
		this.start = start;
	}

	/**
	 * @return the end
	 */
	public Date getEnd() {
		return end;
	}

	/**
	 * @param end the end to set
	 */
	public void setEnd(Date end) {
		this.end = end;
	}

	/**
	 * @return the isForRelease
	 */
	public boolean isForRelease() {
		return isForRelease;
	}


	/**
	 * @param isForRelease the isForRelease to set
	 */
	public void setForRelease(boolean isForRelease) {
		this.isForRelease = isForRelease;
	}

	/**
	 * @return the status
	 */
	public Byte getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Byte status) {
		this.status = status;
	}

	/**
	 * @return the report
	 */
	public String getReport() {
		return report;
	}

	/**
	 * @param report the report to set
	 */
	public void setReport(String report) {
		this.report= report;
	}

	/**
	 * @return the idProject
	 */
	public String getIdProject() {
		return idProject;
	}

	/**
	 * @param idProject the idProject to set
	 */
	public void setIdProject(String idProject) {
		this.idProject = idProject;
	}

	/**
	 * @return the selectedstatus
	 */
	public String getSelectedstatus() {
		return selectedstatus;
	}

	/**
	 * @param selectedstatus the selectedstatus to set
	 */
	public void setSelectedstatus(String selectedstatus) {
		this.selectedstatus = selectedstatus;
	}

	/**
	 * @return the appliId
	 */
	public String getAppliId() {
		return appliId;
	}

	/**
	 * @param appliId the appliId to set
	 */
	public void setAppliId(String appliId) {
		this.appliId = appliId;
	}

	/**
	 * @return the personalizedProject
	 */
	public String getPersonalizedProject() {
		return personalizedProject;
	}

	/**
	 * @param personalizedProject the personalizedProject to set
	 */
	public void setPersonalizedProject(String personalizedProject) {
		this.personalizedProject = personalizedProject;
	}

	/**
	 * @return the oldstatus
	 */
	public String getOldstatus() {
		return oldstatus;
	}

	/**
	 * @param oldstatus the oldstatus to set
	 */
	public void setOldstatus(String oldstatus) {
		this.oldstatus = oldstatus;
	}

	/**
	 * @return the standardOils
	 */
	public String getStandardOils() {
		return standardOils;
	}

	/**
	 * @param standardOils the standardOils to set
	 */
	public void setStandardOils(String standardOils) {
		this.standardOils = standardOils;
	}

	/**
	 * @return the lastModifier
	 */
	public String getLastModifier() {
		return lastModifier;
	}

	/**
	 * @param lastModifier the lastModifier to set
	 */
	public void setLastModifier(String lastModifier) {
		this.lastModifier = lastModifier;
	}

	/**
	 * @return the hasContract
	 */
	public String getHasContract() {
		return hasContract;
	}

	/**
	 * @param hasContract the hasContract to set
	 */
	public void setHasContract(String hasContract) {
		this.hasContract = hasContract;
	}

	/**
	 * @return the releaseType
	 */
	public String getReleaseType() {
		return releaseType;
	}

	/**
	 * @param releaseType the releaseType to set
	 */
	public void setReleaseType(String releaseType) {
		this.releaseType = releaseType;
	}

	/**
	 * @return the isUcr
	 */
	public String getIsUcr() {
		return isUcr;
	}

	/**
	 * @param isUcr the isUcr to set
	 */
	public void setIsUcr(String isUcr) {
		this.isUcr = isUcr;
	}

	/**
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = String.join(".", brandIceCode, typeIceCode, productIceCode, seriesIceCode);

		toReturn += " - projectName : " + projectName + " - isForRelease : " + isForRelease + " - status : " + status + " - report : " + report;

		return toReturn;
	}
}
