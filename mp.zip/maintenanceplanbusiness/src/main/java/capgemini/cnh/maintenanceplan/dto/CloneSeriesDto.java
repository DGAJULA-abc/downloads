/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class CloneSeriesDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** id project source. **/
	private Long idProjectSrc = null;

	/** id project destination. **/
	private Long idProjectDest = null;

	/** External plan id source. */
	private Long extIdSrc = null;

	/** External plan id destination. */
	private Long extIdDest = null;

	/**
	 * Constructor.
	 */
	public CloneSeriesDto() {
		super();
	}

	/**
	 * @return the idProjectSrc
	 */
	public Long getIdProjectSrc() {
		return idProjectSrc;
	}

	/**
	 * @param idProjectSrc the idProjectSrc to set
	 */
	public void setIdProjectSrc(Long idProjectSrc) {
		this.idProjectSrc = idProjectSrc;
	}

	/**
	 * @return the idProjectDest
	 */
	public Long getIdProjectDest() {
		return idProjectDest;
	}

	/**
	 * @param idProjectDest the idProjectDest to set
	 */
	public void setIdProjectDest(Long idProjectDest) {
		this.idProjectDest = idProjectDest;
	}

	/**
	 * @return the extIdSrc
	 */
	public Long getExtIdSrc() {
		return extIdSrc;
	}

	/**
	 * @param extIdSrc the extIdSrc to set
	 */
	public void setExtIdSrc(Long extIdSrc) {
		this.extIdSrc = extIdSrc;
	}

	/**
	 * @return the extIdDest
	 */
	public Long getExtIdDest() {
		return extIdDest;
	}

	/**
	 * @param extIdDest the extIdDest to set
	 */
	public void setExtIdDest(Long extIdDest) {
		this.extIdDest = extIdDest;
	}

}
