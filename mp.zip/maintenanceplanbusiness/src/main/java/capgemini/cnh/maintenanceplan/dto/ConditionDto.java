/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class ConditionDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** id. **/
	private Long idCondition = null;

	/** id. **/
	private Long idPlan = null;

	/** id. **/
	private Long idPerformance = null;

	/** usage. **/
	private UsageDto usage = null;

	/**
	 * Constructor.
	 */
	public ConditionDto() {
		super();
	}

	/**
	 * @return the idCondition
	 */
	public Long getIdCondition() {
		return idCondition;
	}

	/**
	 * @param idCondition the idCondition to set
	 */
	public void setIdCondition(Long idCondition) {
		this.idCondition = idCondition;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the idPerformance
	 */
	public Long getIdPerformance() {
		return idPerformance;
	}

	/**
	 * @param idPerformance the idPerformance to set
	 */
	public void setIdPerformance(Long idPerformance) {
		this.idPerformance = idPerformance;
	}

	/**
	 * @return the usage
	 */
	public UsageDto getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(UsageDto usage) {
		this.usage = usage;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @param alone to det or not [ ] aroud the dto
	 * @return formatted string
	 */
	public String toJavaScript(boolean alone) {
		StringBuffer strForJavaSript = new StringBuffer();
		if (alone)
		{
			strForJavaSript.append("[");
		}

		strForJavaSript.append("'");
		if (idCondition != null)
		{
			strForJavaSript.append(idCondition.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (idPlan != null)
		{
			strForJavaSript.append(idPlan.toString());
		}
		else if (idPerformance != null)
		{
			strForJavaSript.append(idPerformance.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (usage != null)
		{
			strForJavaSript.append(usage.getValueId().toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (usage != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(usage.getItemTitle() + " - " + usage.getValueTitle()));
		}
		strForJavaSript.append("'");

		if (alone)
		{
			strForJavaSript.append("]");
		}

		return strForJavaSript.toString();
	}

}
