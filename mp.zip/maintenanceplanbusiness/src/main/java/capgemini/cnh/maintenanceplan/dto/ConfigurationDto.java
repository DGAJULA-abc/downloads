package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/* Project CNH/TICD Last Change by mmartel */

/**
 * Dto class for configuration. The key is the combination IdConfig / IdLanguage
 */
public class ConfigurationDto extends Dto implements Comparable<ConfigurationDto> {

	/** serial version id. */
	private static final long serialVersionUID = 2L;

	/** idConfig attribute. */
	private Long idConfig = null;

	/** configItemId attribute. */
	private Integer configItemId = null;

	/**
	 * Constructor.
	 */
	public ConfigurationDto(Long idConfig, Integer configItemId) {
		super();
		this.idConfig = idConfig;
		this.configItemId = configItemId;

	}

	/**
	 * Constructor.
	 */
	public ConfigurationDto() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param config configuration to copy.
	 */
	public ConfigurationDto(ConfigurationDto config) {
		super();
		if (null != config)
		{
			this.idConfig = config.getIdConfig();
			this.configItemId = config.getConfigItemId();
		}
	}

	/**
	 * @return the idConfig
	 */
	public Long getIdConfig() {
		return idConfig;
	}

	/**
	 * @param idConfig the idConfig to set
	 */
	public void setIdConfig(Long idConfig) {
		this.idConfig = idConfig;
	}

	/**
	 * @return the configItemId
	 */
	public Integer getConfigItemId() {
		return configItemId;
	}

	/**
	 * @param configItemId the configItemId to set
	 */
	public void setConfigItemId(Integer configItemId) {
		this.configItemId = configItemId;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted DTO.
	 */
	public String toString() {
		String toReturn = "CONFIGURATION";
		toReturn += " ";
		toReturn += getIdConfig();
		toReturn += " ";
		toReturn += getConfigItemId();

		return toReturn;
	}

	/**
	 * Compares this object with the specified object for order. Returns a negative integer, zero,
	 * or a positive integer as this object is less than, equal to, or greater than the specified
	 * object.
	 * 
	 * @param o the object to be compared.
	 * @return a negative integer, zero, or a positive integer as this object is less than, equal
	 *         to, or greater than the specified object.
	 */
	public int compareTo(ConfigurationDto o) {
		int comparedValue = -1;
		if (null != idConfig)
		{
			comparedValue = this.idConfig.compareTo(o.getIdConfig());
		}
		return comparedValue;
	}

	/**
	 * Return true if this and given object are equals. Equality between two LanguageDto object
	 * means equality of attribute idLanguage.
	 * 
	 * @param otherObject Object to test
	 * @return true or false.
	 */
	public boolean equals(Object otherObject) {
		// a quick test to see if the objects are identical
		if (this == otherObject)
		{
			return true;
		}

		// must return false if the explicit parameter is null
		if (otherObject == null)
		{
			return false;
		}

		// if the classes don't match, they can't be equal
		if (getClass() != otherObject.getClass())
		{
			return false;
		}

		// now we know otherObject is a non-null LanguageDto
		ConfigurationDto other = (ConfigurationDto) otherObject;
		return getIdConfig().equals(other.getIdConfig());
	}

}
