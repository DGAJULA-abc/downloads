/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class IntervalDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Maintenance Interval Id. **/
	private Long id = null;

	/** Plan Id. **/
	private Long idPlan = null;

	/** Type. **/
	private String typeLabel = null;

	/** Type. **/
	private String type = null;

	/** Code. **/
	private String code = null;

	/** Start Value Km. **/
	private Long startValueKm = null;

	/** Start Value Month. **/
	private Long startValueMonth = null;

	/** Start Value Hour. **/
	private Long startValueHour = null;

	/** After Value Km. **/
	private Long afterValueKm = null;

	/** After Value Month. **/
	private Long afterValueMonth = null;

	/** After Value Hour. **/
	private Long afterValueHour = null;

	/** Repair Time. **/
	private Long repairTime = null;

	/** operation by series. **/
	private Long operationBySeriesId = null;

	/** comment. **/
	private String comment = null;

	/** comment Id. **/
	private Long commentId = null;

	/** group. **/
	private Long group = null;

	/** Is customer. **/
	private Boolean isCustomer = null;

	/** flag. **/
	private boolean flag = false;

	/**
	 * Constructor.
	 */
	public IntervalDto() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the commentId
	 */
	public Long getCommentId() {
		return commentId;
	}

	/**
	 * @param commentId the commentId to set
	 */
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	/**
	 * @return the group
	 */
	public Long getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(Long group) {
		this.group = group;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the startValueKm
	 */
	public Long getStartValueKm() {
		return startValueKm;
	}

	/**
	 * @param startValueKm the startValueKm to set
	 */
	public void setStartValueKm(Long startValueKm) {
		this.startValueKm = startValueKm;
	}

	/**
	 * @return the startValueMonth
	 */
	public Long getStartValueMonth() {
		return startValueMonth;
	}

	/**
	 * @param startValueMonth the startValueMonth to set
	 */
	public void setStartValueMonth(Long startValueMonth) {
		this.startValueMonth = startValueMonth;
	}

	/**
	 * @return the startValueHour
	 */
	public Long getStartValueHour() {
		return startValueHour;
	}

	/**
	 * @param startValueHour the startValueHour to set
	 */
	public void setStartValueHour(Long startValueHour) {
		this.startValueHour = startValueHour;
	}

	/**
	 * @return the afterValueKm
	 */
	public Long getAfterValueKm() {
		return afterValueKm;
	}

	/**
	 * @param afterValueKm the afterValueKm to set
	 */
	public void setAfterValueKm(Long afterValueKm) {
		this.afterValueKm = afterValueKm;
	}

	/**
	 * @return the afterValueMonth
	 */
	public Long getAfterValueMonth() {
		return afterValueMonth;
	}

	/**
	 * @param afterValueMonth the afterValueMonth to set
	 */
	public void setAfterValueMonth(Long afterValueMonth) {
		this.afterValueMonth = afterValueMonth;
	}

	/**
	 * @return the afterValueHour
	 */
	public Long getAfterValueHour() {
		return afterValueHour;
	}

	/**
	 * @param afterValueHour the afterValueHour to set
	 */
	public void setAfterValueHour(Long afterValueHour) {
		this.afterValueHour = afterValueHour;
	}

	/**
	 * @return the repairTime
	 */
	public Long getRepairTime() {
		return repairTime;
	}

	/**
	 * @param repairTime the repairTime to set
	 */
	public void setRepairTime(Long repairTime) {
		this.repairTime = repairTime;
	}

	/**
	 * @return the typeLabel
	 */
	public String getTypeLabel() {
		return typeLabel;
	}

	/**
	 * @param typeLabel the typeLabel to set
	 */
	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	/**
	 * @return the operationBySeriesId
	 */
	public Long getOperationBySeriesId() {
		return operationBySeriesId;
	}

	/**
	 * @param operationBySeriesId the operationBySeriesId to set
	 */
	public void setOperationBySeriesId(Long operationBySeriesId) {
		this.operationBySeriesId = operationBySeriesId;
	}

	/**
	 * 
	 * @return true if the interval is made of customer operations, false otherwise.
	 */
	public Boolean isCustomer() {
		return isCustomer;
	}

	/**
	 * 
	 * @param isCustomer true if the interval is made of customer operations, false otherwise.
	 */
	public void setCustomer(Boolean isCustomer) {
		this.isCustomer = isCustomer;
	}

	/**
	 * @return the flag
	 */
	public boolean isFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		if (id != null)
		{
			toReturn += "id Maintenance Interval " + id.toString();
		}
		toReturn += " - ";
		if (idPlan != null)
		{
			toReturn += "id Plan " + idPlan.toString();
		}
		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		if (idPlan != null)
		{
			strForJavaSript.append(idPlan.toString());
		}

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (type != null)
		{
			strForJavaSript.append(type.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (typeLabel != null)
		{
			strForJavaSript.append(typeLabel.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (code != null)
		{
			strForJavaSript.append(code.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueKm != null)
		{
			strForJavaSript.append(startValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueMonth != null)
		{
			strForJavaSript.append(startValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueHour != null)
		{
			strForJavaSript.append(startValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueKm != null)
		{
			strForJavaSript.append(afterValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueMonth != null)
		{
			strForJavaSript.append(afterValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueHour != null)
		{
			strForJavaSript.append(afterValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (group != null)
		{
			strForJavaSript.append(group.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (repairTime != null)
		{
			strForJavaSript.append(repairTime.toString());
		}

		strForJavaSript.append("'");

		// comment is set twice for old comment value
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (comment != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(comment));
			strForJavaSript.append("'");
			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(comment));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (commentId != null)
		{
			strForJavaSript.append(commentId.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJSon() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("{");
		strForJavaSript.append("\"id\":");
		strForJavaSript.append("\"");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"idPlan\":");
		if (idPlan != null)
		{
			strForJavaSript.append(idPlan.toString());
		}

		strForJavaSript.append(",");
		strForJavaSript.append("\"typeId\":");
		strForJavaSript.append("\"");
		if (type != null)
		{
			strForJavaSript.append(type.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"type\":");
		strForJavaSript.append("\"");
		if (typeLabel != null)
		{
			strForJavaSript.append(typeLabel.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"code\":");
		strForJavaSript.append("\"");
		if (code != null)
		{
			strForJavaSript.append(code.toString());
		}

		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuekm\":");
		strForJavaSript.append("\"");
		if (startValueKm != null)
		{
			strForJavaSript.append(startValueKm.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuemonth\":");
		strForJavaSript.append("\"");
		if (startValueMonth != null)
		{
			strForJavaSript.append(startValueMonth.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuehour\":");
		strForJavaSript.append("\"");
		if (startValueHour != null)
		{
			strForJavaSript.append(startValueHour.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuekm\":");
		strForJavaSript.append("\"");
		if (afterValueKm != null)
		{
			strForJavaSript.append(afterValueKm.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuemonth\":");
		strForJavaSript.append("\"");
		if (afterValueMonth != null)
		{
			strForJavaSript.append(afterValueMonth.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuehour\":");
		strForJavaSript.append("\"");
		if (afterValueHour != null)
		{
			strForJavaSript.append(afterValueHour.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"group\":");
		strForJavaSript.append("\"");
		if (group != null)
		{
			strForJavaSript.append(group.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"repairtime\":");
		strForJavaSript.append("\"");
		if (repairTime != null)
		{
			strForJavaSript.append(repairTime.toString());
		}

		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		strForJavaSript.append("\"comment\":");
		strForJavaSript.append("\"");
		if (comment != null)
		{
			//strForJavaSript.append(StringEscapeUtils.escapeJavaScript(comment));
			strForJavaSript.append(comment);
			strForJavaSript.append("\"");
			strForJavaSript.append(",");
			strForJavaSript.append("\"commentOld\":");
			strForJavaSript.append("\"");
			//strForJavaSript.append(StringEscapeUtils.escapeJavaScript(comment));
			strForJavaSript.append(comment);
		}
		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		strForJavaSript.append("\"commentId\":");
		strForJavaSript.append("\"");
		if (commentId != null)
		{
			strForJavaSript.append(commentId.toString());
		}
		strForJavaSript.append("\"");

		strForJavaSript.append("}");

		return strForJavaSript.toString();
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * IntervalDto object means equality of Code, all Values and repair time
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		IntervalDto other = (IntervalDto) obj;
		if (((this.getCode() == null && other.getCode() == null) || (this.getCode() != null && this.getCode().equals(other.getCode())))
				&& ((this.getAfterValueKm() == null && other.getAfterValueKm() == null)
						|| (this.getAfterValueKm() != null && other.getAfterValueKm() != null && this.getAfterValueKm().compareTo(other.getAfterValueKm()) == 0))
				&& ((this.getAfterValueHour() == null && other.getAfterValueHour() == null)
						|| (this.getAfterValueHour() != null && other.getAfterValueHour() != null && this.getAfterValueHour().compareTo(other.getAfterValueHour()) == 0))
				&& ((this.getAfterValueMonth() == null && other.getAfterValueMonth() == null)
						|| (this.getAfterValueMonth() != null && other.getAfterValueMonth() != null && this.getAfterValueMonth().compareTo(other.getAfterValueMonth()) == 0))
				&& ((this.getStartValueKm() == null && other.getStartValueKm() == null)
						|| (this.getStartValueKm() != null && other.getStartValueKm() != null && this.getStartValueKm().compareTo(other.getStartValueKm()) == 0))
				&& ((this.getStartValueHour() == null && other.getStartValueHour() == null)
						|| (this.getStartValueHour() != null && other.getStartValueHour() != null && this.getStartValueHour().compareTo(other.getStartValueHour()) == 0))
				&& ((this.getStartValueMonth() == null && other.getStartValueMonth() == null)
						|| (this.getStartValueMonth() != null && other.getStartValueMonth() != null && this.getStartValueMonth().compareTo(other.getStartValueMonth()) == 0))
				&& ((this.getRepairTime() == null && other.getRepairTime() == null)
						|| (this.getRepairTime() != null && other.getRepairTime() != null && this.getRepairTime().compareTo(other.getRepairTime()) == 0)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
