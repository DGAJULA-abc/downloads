/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class IntervalFrequencyDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Code. **/
	private String code = null;

	/** Start Value of the specific unit. **/
	private Long startValueSpecificUnit = null;

	/** Start Value Month. **/
	private Long startValueMonth = null;

	/** Start Value Hour. **/
	private Long startValueHour = null;

	/** After Value of the specific unit. **/
	private Long afterValueSpecificUnit = null;

	/** After Value Month. **/
	private Long afterValueMonth = null;

	/** After Value Hour. **/
	private Long afterValueHour = null;

	/** Specific unit key. **/
	private String specificUnitKey = null;

	/**
	 * Constructor.
	 */
	public IntervalFrequencyDto() {
		super();
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the startValueSpecificUnit
	 */
	public Long getStartValueSpecificUnit() {
		return startValueSpecificUnit;
	}

	/**
	 * @param startValueSpecificUnit the startValueSpecificUnit to set
	 */
	public void setStartValueSpecificUnit(Long startValueSpecificUnit) {
		this.startValueSpecificUnit = startValueSpecificUnit;
	}

	/**
	 * @return the startValueMonth
	 */
	public Long getStartValueMonth() {
		return startValueMonth;
	}

	/**
	 * @param startValueMonth the startValueMonth to set
	 */
	public void setStartValueMonth(Long startValueMonth) {
		this.startValueMonth = startValueMonth;
	}

	/**
	 * @return the startValueHour
	 */
	public Long getStartValueHour() {
		return startValueHour;
	}

	/**
	 * @param startValueHour the startValueHour to set
	 */
	public void setStartValueHour(Long startValueHour) {
		this.startValueHour = startValueHour;
	}

	/**
	 * @return the afterValueSpecificUnit
	 */
	public Long getAfterValueSpecificUnit() {
		return afterValueSpecificUnit;
	}

	/**
	 * @param afterValueSpecificUnit the afterValueSpecificUnit to set
	 */
	public void setAfterValueSpecificUnit(Long afterValueSpecificUnit) {
		this.afterValueSpecificUnit = afterValueSpecificUnit;
	}

	/**
	 * @return the afterValueMonth
	 */
	public Long getAfterValueMonth() {
		return afterValueMonth;
	}

	/**
	 * @param afterValueMonth the afterValueMonth to set
	 */
	public void setAfterValueMonth(Long afterValueMonth) {
		this.afterValueMonth = afterValueMonth;
	}

	/**
	 * @return the afterValueHour
	 */
	public Long getAfterValueHour() {
		return afterValueHour;
	}

	/**
	 * @param afterValueHour the afterValueHour to set
	 */
	public void setAfterValueHour(Long afterValueHour) {
		this.afterValueHour = afterValueHour;
	}

	/**
	 * @return the specificUnitKey
	 */
	public String getSpecificUnitKey() {
		return specificUnitKey;
	}

	/**
	 * @param specificUnitKey the specificUnitKey to set
	 */
	public void setSpecificUnitKey(String specificUnitKey) {
		this.specificUnitKey = specificUnitKey;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (code != null)
		{
			strForJavaSript.append(code.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueMonth != null)
		{
			strForJavaSript.append(startValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueHour != null)
		{
			strForJavaSript.append(startValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueMonth != null)
		{
			strForJavaSript.append(afterValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueHour != null)
		{
			strForJavaSript.append(afterValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (startValueSpecificUnit != null)
		{
			strForJavaSript.append(startValueSpecificUnit.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (afterValueSpecificUnit != null)
		{
			strForJavaSript.append(afterValueSpecificUnit.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (specificUnitKey != null)
		{
			strForJavaSript.append(specificUnitKey.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJSon() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("{");
		strForJavaSript.append("\"code\":");
		strForJavaSript.append("\"");
		if (code != null)
		{
			strForJavaSript.append(code.toString());
		}

		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuespecificunit\":");
		strForJavaSript.append("\"");
		if (startValueSpecificUnit != null)
		{
			strForJavaSript.append(startValueSpecificUnit.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuemonth\":");
		strForJavaSript.append("\"");
		if (startValueMonth != null)
		{
			strForJavaSript.append(startValueMonth.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"firstValuehour\":");
		strForJavaSript.append("\"");
		if (startValueHour != null)
		{
			strForJavaSript.append(startValueHour.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuespecificunit\":");
		strForJavaSript.append("\"");
		if (afterValueSpecificUnit != null)
		{
			strForJavaSript.append(afterValueSpecificUnit.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuemonth\":");
		strForJavaSript.append("\"");
		if (afterValueMonth != null)
		{
			strForJavaSript.append(afterValueMonth.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"afterValuehour\":");
		strForJavaSript.append("\"");
		if (afterValueHour != null)
		{
			strForJavaSript.append(afterValueHour.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"specificUnitKey\":");
		strForJavaSript.append("\"");
		if (specificUnitKey != null)
		{
			strForJavaSript.append(specificUnitKey.toString());
		}
		strForJavaSript.append("\"");

		strForJavaSript.append("}");

		return strForJavaSript.toString();
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * IntervalDto object means equality of Code, all Values and repair time
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		IntervalFrequencyDto other = (IntervalFrequencyDto) obj;
		if (((this.getCode() == null && other.getCode() == null) || (this.getCode() != null && this.getCode().equals(other.getCode())))
				&& ((this.getAfterValueSpecificUnit() == null && other.getAfterValueSpecificUnit() == null)
						|| (this.getAfterValueSpecificUnit() != null && other.getAfterValueSpecificUnit() != null && this.getAfterValueSpecificUnit().compareTo(other.getAfterValueSpecificUnit()) == 0))
				&& ((this.getAfterValueHour() == null && other.getAfterValueHour() == null)
						|| (this.getAfterValueHour() != null && other.getAfterValueHour() != null && this.getAfterValueHour().compareTo(other.getAfterValueHour()) == 0))
				&& ((this.getAfterValueMonth() == null && other.getAfterValueMonth() == null)
						|| (this.getAfterValueMonth() != null && other.getAfterValueMonth() != null && this.getAfterValueMonth().compareTo(other.getAfterValueMonth()) == 0))
				&& ((this.getStartValueSpecificUnit() == null && other.getStartValueSpecificUnit() == null)
						|| (this.getStartValueSpecificUnit() != null && other.getStartValueSpecificUnit() != null && this.getStartValueSpecificUnit().compareTo(other.getStartValueSpecificUnit()) == 0))
				&& ((this.getStartValueHour() == null && other.getStartValueHour() == null)
						|| (this.getStartValueHour() != null && other.getStartValueHour() != null && this.getStartValueHour().compareTo(other.getStartValueHour()) == 0))
				&& ((this.getStartValueMonth() == null && other.getStartValueMonth() == null)
						|| (this.getStartValueMonth() != null && other.getStartValueMonth() != null && this.getStartValueMonth().compareTo(other.getStartValueMonth()) == 0))
				&& ((this.getSpecificUnitKey() == null && other.getSpecificUnitKey() == null) || (this.getSpecificUnitKey() != null && this.getSpecificUnitKey().equals(other.getSpecificUnitKey()))))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
