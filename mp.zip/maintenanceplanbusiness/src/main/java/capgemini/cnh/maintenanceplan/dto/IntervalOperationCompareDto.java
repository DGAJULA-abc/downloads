/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** interval Id. **/
	private Long intervalId = null;

	/** interval code. **/
	private String intervalCode = null;

	/** operation label. **/
	private String operationLabel = null;

	/** operation Id. **/
	private Long idOperation = null;

	/** operation micro. **/
	private String microOperation = null;

	/** operation srt. **/
	private String srtOperation = null;

	/** with data. **/
	private String withConsumable;

	/** with data. **/
	private String withParts;

	/** with data. **/
	private String withPerf;

	/** Start Value Km. **/
	private Long startValueKm = null;

	/** Start Value Month. **/
	private Long startValueMonth = null;

	/** Start Value Hour. **/
	private Long startValueHour = null;

	/** After Value Km. **/
	private Long afterValueKm = null;

	/** After Value Month. **/
	private Long afterValueMonth = null;

	/** After Value Hour. **/
	private Long afterValueHour = null;

	/** Repair Time. **/
	private Long repairTime = null;

	/**
	 * Constructor.
	 */
	public IntervalOperationCompareDto() {
		super();
	}

	/**
	 * @return the idOperation
	 */
	public Long getIdOperation() {
		return idOperation;
	}

	/**
	 * @param idOperation the idOperation to set
	 */
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the intervalId
	 */
	public Long getIntervalId() {
		return intervalId;
	}

	/**
	 * @param intervalId the intervalId to set
	 */
	public void setIntervalId(Long intervalId) {
		this.intervalId = intervalId;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the operationLabel
	 */
	public String getOperationLabel() {
		return operationLabel;
	}

	/**
	 * @param operationLabel the operationLabel to set
	 */
	public void setOperationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
	}

	/**
	 * @return the microOperation
	 */
	public String getMicroOperation() {
		return microOperation;
	}

	/**
	 * @param microOperation the microOperation to set
	 */
	public void setMicroOperation(String microOperation) {
		this.microOperation = microOperation;
	}

	/**
	 * @return the srtOperation
	 */
	public String getSrtOperation() {
		return srtOperation;
	}

	/**
	 * @param srtOperation the srtOperation to set
	 */
	public void setSrtOperation(String srtOperation) {
		this.srtOperation = srtOperation;
	}

	/**
	 * @return the withConsumable
	 */
	public String getWithConsumable() {
		return withConsumable;
	}

	/**
	 * @param withConsumable the withConsumable to set
	 */
	public void setWithConsumable(String withConsumable) {
		this.withConsumable = withConsumable;
	}

	/**
	 * @return the withParts
	 */
	public String getWithParts() {
		return withParts;
	}

	/**
	 * @param withParts the withParts to set
	 */
	public void setWithParts(String withParts) {
		this.withParts = withParts;
	}

	/**
	 * @return the withPerf
	 */
	public String getWithPerf() {
		return withPerf;
	}

	/**
	 * @param withPerf the withPerf to set
	 */
	public void setWithPerf(String withPerf) {
		this.withPerf = withPerf;
	}

	/**
	 * 
	 * @return the start value km
	 */
	public Long getStartValueKm() {
		return startValueKm;
	}

	/**
	 * 
	 * @param startValueKm the startValueKm to set
	 */
	public void setStartValueKm(Long startValueKm) {
		this.startValueKm = startValueKm;
	}

	/**
	 * 
	 * @return startValueMonth
	 */
	public Long getStartValueMonth() {
		return startValueMonth;
	}

	/**
	 * 
	 * @param startValueMonth startValueMonth to set
	 */
	public void setStartValueMonth(Long startValueMonth) {
		this.startValueMonth = startValueMonth;
	}

	/**
	 * 
	 * @return startValueHour
	 */
	public Long getStartValueHour() {
		return startValueHour;
	}

	/**
	 * 
	 * @param startValueHour the startValueHour to set
	 */
	public void setStartValueHour(Long startValueHour) {
		this.startValueHour = startValueHour;
	}

	/**
	 * 
	 * @return afterValueKm
	 */
	public Long getAfterValueKm() {
		return afterValueKm;
	}

	/**
	 * 
	 * @param afterValueKm the afterValueKm to set
	 */
	public void setAfterValueKm(Long afterValueKm) {
		this.afterValueKm = afterValueKm;
	}

	/**
	 * 
	 * @return afterValueMonth
	 */
	public Long getAfterValueMonth() {
		return afterValueMonth;
	}

	/**
	 * 
	 * @param afterValueMonth the afterValueMonth to set
	 */
	public void setAfterValueMonth(Long afterValueMonth) {
		this.afterValueMonth = afterValueMonth;
	}

	/**
	 * 
	 * @return afterValueHour
	 */
	public Long getAfterValueHour() {
		return afterValueHour;
	}

	/**
	 * 
	 * @param afterValueHour the afterValueHour to set
	 */
	public void setAfterValueHour(Long afterValueHour) {
		this.afterValueHour = afterValueHour;
	}

	/**
	 * 
	 * @return repairTime
	 */
	public Long getRepairTime() {
		return repairTime;
	}

	/**
	 * 
	 * @param repairTime
	 */
	public void setRepairTime(Long repairTime) {
		this.repairTime = repairTime;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "interval Id " + intervalId;

		return toReturn;
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * IntervalDto object means equality of Code, all Values and repair time
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		IntervalOperationCompareDto other = (IntervalOperationCompareDto) obj;
		if (areEqual(this.getIntervalCode(), other.getIntervalCode())
				&& areEqual(this.getAfterValueKm(), other.getAfterValueKm())
				&& areEqual(this.getAfterValueHour(), other.getAfterValueHour())
				&& areEqual(this.getAfterValueMonth(), other.getAfterValueMonth())
				&& areEqual(this.getStartValueKm(), other.getStartValueKm())
				&& areEqual(this.getStartValueHour(), other.getStartValueHour())
				&& areEqual(this.getStartValueMonth(), other.getStartValueMonth())
				&& areEqual(this.getRepairTime(), other.getRepairTime()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
