/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class IntervalOperationDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** interval Id. **/
	private Long intervalId = null;

	/** interval code. **/
	private String intervalCode = null;

	/** operation label. **/
	private String operationLabel = null;

	/** operation Id. **/
	private Long idOperation = null;

	/** operation micro. **/
	private String microOperation = null;

	/** operation srt. **/
	private String srtOperation = null;

	/** with data. **/
	private String withConsumable;

	/** with data. **/
	private String withParts;

	/** with data. **/
	private String withPerf;

	/**
	 * Constructor.
	 */
	public IntervalOperationDto() {
		super();
	}

	/**
	 * @return the idOperation
	 */
	public Long getIdOperation() {
		return idOperation;
	}

	/**
	 * @param idOperation the idOperation to set
	 */
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the intervalId
	 */
	public Long getIntervalId() {
		return intervalId;
	}

	/**
	 * @param intervalId the intervalId to set
	 */
	public void setIntervalId(Long intervalId) {
		this.intervalId = intervalId;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the operationLabel
	 */
	public String getOperationLabel() {
		return operationLabel;
	}

	/**
	 * @param operationLabel the operationLabel to set
	 */
	public void setOperationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
	}

	/**
	 * @return the microOperation
	 */
	public String getMicroOperation() {
		return microOperation;
	}

	/**
	 * @param microOperation the microOperation to set
	 */
	public void setMicroOperation(String microOperation) {
		this.microOperation = microOperation;
	}

	/**
	 * @return the srtOperation
	 */
	public String getSrtOperation() {
		return srtOperation;
	}

	/**
	 * @param srtOperation the srtOperation to set
	 */
	public void setSrtOperation(String srtOperation) {
		this.srtOperation = srtOperation;
	}

	/**
	 * @return the withConsumable
	 */
	public String getWithConsumable() {
		return withConsumable;
	}

	/**
	 * @param withConsumable the withConsumable to set
	 */
	public void setWithConsumable(String withConsumable) {
		this.withConsumable = withConsumable;
	}

	/**
	 * @return the withParts
	 */
	public String getWithParts() {
		return withParts;
	}

	/**
	 * @param withParts the withParts to set
	 */
	public void setWithParts(String withParts) {
		this.withParts = withParts;
	}

	/**
	 * @return the withPerf
	 */
	public String getWithPerf() {
		return withPerf;
	}

	/**
	 * @param withPerf the withPerf to set
	 */
	public void setWithPerf(String withPerf) {
		this.withPerf = withPerf;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "interval Id " + intervalId;

		return toReturn;
	}
}
