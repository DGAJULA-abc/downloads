/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author MAY
 *
 */
public class KitCompositionDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public KitCompositionDto() {
		super();
	}

	/** COMP_KIT_CODE. **/
	private String compKitCode = null;

	/** COMP_PN_CODE. **/
	private String compPnCode = null;

	/** COMP_PN_LABEL. **/
	private String compPnLabel = null;

	/** COMP_PN_QTY. **/
	private Long compPnQty = null;

	/** COMP_DATE. **/
	private String compDate = null;

	/**
	 * @return the compKitCode
	 */
	public String getCompKitCode() {
		return compKitCode;
	}

	/**
	 * @param compKitCode the compKitCode to set
	 */
	public void setCompKitCode(String compKitCode) {
		this.compKitCode = compKitCode;
	}

	/**
	 * @return the compPnCode
	 */
	public String getCompPnCode() {
		return compPnCode;
	}

	/**
	 * @param compPnCode the compPnCode to set
	 */
	public void setCompPnCode(String compPnCode) {
		this.compPnCode = compPnCode;
	}

	/**
	 * @return the compPnLabel
	 */
	public String getCompPnLabel() {
		return compPnLabel;
	}

	/**
	 * @param compPnLabel the compPnLabel to set
	 */
	public void setCompPnLabel(String compPnLabel) {
		this.compPnLabel = compPnLabel;
	}

	/**
	 * @return the compPnQty
	 */
	public Long getCompPnQty() {
		return compPnQty;
	}

	/**
	 * @param compPnQty the compPnQty to set
	 */
	public void setCompPnQty(Long compPnQty) {
		this.compPnQty = compPnQty;
	}

	/**
	 * @return the compDate
	 */
	public String getCompDate() {
		return compDate;
	}

	/**
	 * @param compDate the compDate to set
	 */
	public void setCompDate(String compDate) {
		this.compDate = compDate;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		toReturn += getCompKitCode();
		toReturn += " ";
		toReturn += getCompPnCode();
		toReturn += " ";
		toReturn += getCompPnQty();
		toReturn += " ";
		toReturn += getCompDate();
		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");

		strForJavaSript.append(compPnCode);
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(compPnLabel));
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(compPnQty);
		strForJavaSript.append("'");
		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
