/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import javax.annotation.Resource;

import capgemini.cnh.framework.dto.Dto;

/**
 *
 * @author jtolosa
 * 
 *         This class is used to manage data from MP_OPERATION_PERFORMANCE_TEXT table.
 */
public class MpOperationPerformanceTextDto extends Dto {

	/**  */
	private static final long serialVersionUID = -2737259069046665072L;

	/** PERF ID. */
	@Resource(name = "PERF_ID")
	private Long perfId;

	/** PERF OPERATION SERIES ID. */
	@Resource(name = "PERF_OPE_SER_ID")
	private Long perfOpeSerId;

	/** PERF NAME. */
	@Resource(name = "PERF_NAME")
	private String perfName;

	/** FREE TEXT ID. */
	@Resource(name = "FREE_TEXT")
	private Long freeTextId;

	/** FREE TEXT. */
	@Resource(name = "MESSAGE", shareable = false)
	private String freeText;

	/**
	 * Constructor.
	 */
	public MpOperationPerformanceTextDto() {
		// Empty Construtor.
		super();
	}

	/**
	 * Getter perfId.
	 *
	 * @return perfId
	 */
	public Long getPerfId() {
		return perfId;
	}

	/**
	 * Getter perfOpeSerId.
	 *
	 * @return perfOpeSerId
	 */
	public Long getPerfOpeSerId() {
		return perfOpeSerId;
	}

	/**
	 * Getter perfName.
	 *
	 * @return perfName
	 */
	public String getPerfName() {
		return perfName;
	}

	/**
	 * Getter freeTextId.
	 *
	 * @return freeTextId
	 */
	public Long getFreeTextId() {
		return freeTextId;
	}

	/**
	 * Setter perfId.
	 *
	 * @param perfId perfId to set.
	 */
	public void setPerfId(Long perfId) {
		this.perfId = perfId;
	}

	/**
	 * Setter perfOpeSerId.
	 *
	 * @param perfOpeSerId perfOpeSerId to set.
	 */
	public void setPerfOpeSerId(Long perfOpeSerId) {
		this.perfOpeSerId = perfOpeSerId;
	}

	/**
	 * Setter perfName.
	 *
	 * @param perfName perfName to set.
	 */
	public void setPerfName(String perfName) {
		this.perfName = perfName;
	}

	/**
	 * Setter freeTextId.
	 *
	 * @param freeTextId freeTextId to set.
	 */
	public void setFreeTextId(Long freeTextId) {
		this.freeTextId = freeTextId;
	}

	/**
	 * Getter pour freeText.
	 *
	 * @return freeText
	 */
	public String getFreeText() {
		return freeText;
	}

	/**
	 * Setter pour freeText.
	 *
	 * @param freeText freeText à positionner.
	 */
	public void setFreeText(String freeText) {
		this.freeText = freeText;
	}

	/**
	 * Getter pour tableName.
	 *
	 * @return tableName
	 */
	public String getDbTable() {
		return "MP_OPERATION_PERFORMANCE_TEXT";
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MpOperationPerformanceTextDto other = (MpOperationPerformanceTextDto) obj;
		if (areEqual(this.getFreeTextId(), other.getFreeTextId())
				&& areEqual(this.getPerfName(), other.getPerfName()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
