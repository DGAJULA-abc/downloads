/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableApplicabilityDto extends ApplicabilityDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long idOperationConsumable = null;

	/**
	 * Constructor.
	 */
	public OperationConsumableApplicabilityDto() {
		super();
	}

	/**
	 * @return the idOperationConsumable
	 */
	public Long getIdOperationConsumable() {
		return idOperationConsumable;
	}

	/**
	 * @param idOperationConsumable the idOperationConsumable to set
	 */
	public void setIdOperationConsumable(Long idOperationConsumable) {
		this.idOperationConsumable = idOperationConsumable;
	}
}
