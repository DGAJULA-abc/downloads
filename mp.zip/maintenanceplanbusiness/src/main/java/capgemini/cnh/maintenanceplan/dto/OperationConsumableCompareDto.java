/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** Id consumable. **/
	private Long idConsumable = null;
	/** Label consumable. **/
	private String consumable = null;

	/** quanity. **/
	private Double quantity = null;
	/** unit. **/
	private String unit = null;

	/** with data. **/
	private String withAppli = null;

	/** Model applicability. */
	private String modelAppli = null;

	/** TT applicability. */
	private String ttAppli = null;

	/** Market applicability. */
	private Long marketAppli = null;

	/** Configuration of the consumable. */
	private String configAppli = null;

	/**
	 * Constructor.
	 */
	public OperationConsumableCompareDto() {
		super();
	}

	/**
	 * 
	 * @return The model applicability
	 */
	public String getModelAppli() {
		return modelAppli;
	}

	/**
	 * 
	 * @param modelAppli The model applicability to set
	 */
	public void setModelAppli(String modelAppli) {
		this.modelAppli = modelAppli;
	}

	/**
	 * 
	 * @return The TT applicability
	 */
	public String getTtAppli() {
		return ttAppli;
	}

	/**
	 * 
	 * @param ttAppli The TT applicability to set
	 */
	public void setTtAppli(String ttAppli) {
		this.ttAppli = ttAppli;
	}

	/**
	 * 
	 * @return The market applicability
	 */
	public Long getMarketAppli() {
		return marketAppli;
	}

	/**
	 * 
	 * @param marketAppli The market applicability to set
	 */
	public void setMarketAppli(Long marketAppli) {
		this.marketAppli = marketAppli;
	}

	/**
	 * 
	 * @return The Configuration applicability
	 */
	public String getConfigAppli() {
		return configAppli;
	}

	/**
	 * 
	 * @param configAppli The Configuration applicability to set
	 */
	public void setConfigAppli(String configAppli) {
		this.configAppli = configAppli;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the idConsumable
	 */
	public Long getIdConsumable() {
		return idConsumable;
	}

	/**
	 * @param idConsumable the idConsumable to set
	 */
	public void setIdConsumable(Long idConsumable) {
		this.idConsumable = idConsumable;
	}

	/**
	 * @return the consumable
	 */
	public String getConsumable() {
		return consumable;
	}

	/**
	 * @param consumable the consumable to set
	 */
	public void setConsumable(String consumable) {
		this.consumable = consumable;
	}

	/**
	 * @return the quantity
	 */
	public Double getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		if (idConsumable != null)
		{
			toReturn += "id consumable " + idConsumable.toString();
		}

		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (idConsumable != null)
		{
			strForJavaSript.append(idConsumable.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(consumable));
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (quantity != null)
		{
			strForJavaSript.append(quantity.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (unit != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(unit));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Double a, Double b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		OperationConsumableCompareDto other = (OperationConsumableCompareDto) obj;
		if (areEqual(this.getIdConsumable(), other.getIdConsumable())
				&& areEqual(this.getQuantity(), other.getQuantity())
				&& areEqual(this.getUnit(), other.getUnit())
				&& areEqual(this.getModelAppli(), other.getModelAppli())
				&& areEqual(this.getTtAppli(), other.getTtAppli())
				&& areEqual(this.getMarketAppli(), other.getMarketAppli())
				&& areEqual(this.getConfigAppli(), other.getConfigAppli()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
