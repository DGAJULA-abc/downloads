/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationConsumableDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** Id consumable. **/
	private Long idConsumable = null;
	/** Label consumable. **/
	private String consumable = null;

	/** Description of the consumable. */
	private String consumableDescription = null;

	/** quanity. **/
	private Double quantity = null;
	/** unit. **/
	private String unit = null;

	/** with data. **/
	private String withAppli = null;

	/**
	 * Constructor.
	 */
	public OperationConsumableDto() {
		super();
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the idConsumable
	 */
	public Long getIdConsumable() {
		return idConsumable;
	}

	/**
	 * @param idConsumable the idConsumable to set
	 */
	public void setIdConsumable(Long idConsumable) {
		this.idConsumable = idConsumable;
	}

	/**
	 * @return the consumable
	 */
	public String getConsumable() {
		return consumable;
	}

	/**
	 * @param consumable the consumable to set
	 */
	public void setConsumable(String consumable) {
		this.consumable = consumable;
	}

	/**
	 * 
	 * @return the consumable description
	 */
	public String getConsumableDescription() {
		return consumableDescription;
	}

	/**
	 * 
	 * @param consumableDescription the consumable description to set
	 */
	public void setConsumableDescription(String consumableDescription) {
		this.consumableDescription = consumableDescription;
	}

	/**
	 * @return the quantity
	 */
	public Double getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		if (idConsumable != null)
		{
			toReturn += "id consumable " + idConsumable.toString();
		}

		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (idConsumable != null)
		{
			strForJavaSript.append(idConsumable.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(consumable));
		strForJavaSript.append("'");

		// Consumable description to be displayed as tooltip
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(consumableDescription));
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (quantity != null)
		{
			strForJavaSript.append(quantity.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (unit != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(unit));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		OperationConsumableDto other = (OperationConsumableDto) obj;
		if (this.getIdConsumable().compareTo(other.getIdConsumable()) == 0 && this.getQuantity().compareTo(other.getQuantity()) == 0
				&& this.getUnit().equals(other.getUnit()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
