/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public OperationDto() {
		super();
	}

	/**
	 * Constructor.
	 */
	public OperationDto(OperationDto dto) {
		super();
		id = dto.getId();
		codeMicroOperation = dto.getCodeMicroOperation();
		codeSrt = dto.getCodeSrt();
		title = dto.getTitle();
		titleId = dto.getTitleId();
		description = dto.getDescription();
		descriptionId = dto.getDescriptionId();
		status = dto.getStatus();
		statusLabel = dto.getStatusLabel();
		modifDate = dto.getModifDate();
		lastModifier = dto.getLastModifier();
		locationFamilyIceCode = dto.getLocationFamilyIceCode();
		locationGroupIceCode = dto.getLocationGroupIceCode();
		locationSubGroupIceCode = dto.getLocationSubGroupIceCode();
		locationLabel = dto.getLocationLabel();
		infotypeTopicIceCode = dto.getInfotypeTopicIceCode();
		infotypeSubTopicIceCode = dto.getInfotypeSubTopicIceCode();
		infotypeCategoryIceCode = dto.getInfotypeCategoryIceCode();
		infotypeInfotypeIceCode = dto.getInfotypeInfotypeIceCode();
		infotypeLabel = dto.getInfotypeLabel();
		labelSeries = dto.getLabelSeries();
		labelOpeType = dto.getLabelOpeType();
		isOperationCurrentSerie = dto.isOperationCurrentSerie();
		byCustomer = dto.getByCustomer();
	}

	/** Id. **/
	private Long id = null;

	/** code micro operation. **/
	private String codeMicroOperation = null;
	/** code srt. **/
	private String codeSrt = null;

	/** title. **/
	private String title = null;
	/** title Id. **/
	private Long titleId = null;

	/** description. **/
	private String description = null;
	/** description Id. **/
	private Long descriptionId = null;

	/** status. **/
	private Integer status = null;
	/** status. **/
	private String statusLabel = null;

	/** change date. **/
	private String modifDate = null;

	/** last modifier. **/
	private String lastModifier = null;

	/** family ice code. **/
	private String locationFamilyIceCode = null;
	/** group ice code. **/
	private String locationGroupIceCode = null;
	/** subgroup ice code. **/
	private String locationSubGroupIceCode = null;
	/** location label. **/
	private String locationLabel = null;

	/** topic ice code. **/
	private String infotypeTopicIceCode = null;
	/** subtopic ice code. **/
	private String infotypeSubTopicIceCode = null;
	/** category ice code. **/
	private String infotypeCategoryIceCode = null;
	/** infotype ice code. **/
	private String infotypeInfotypeIceCode = null;
	/** infotype label. **/
	private String infotypeLabel = null;
	/** Label for series. **/
	private String labelSeries = "";
	/** Label for Operation Type. **/
	private String labelOpeType = "";
	/** Label for series. **/
	private Long labelSeriesId = null;
	/** Check if the operation linked to current serie. **/
	private boolean isOperationCurrentSerie = false;

	private Long byCustomer = null;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the codeMicroOperation
	 */
	public String getCodeMicroOperation() {
		return codeMicroOperation;
	}

	/**
	 * @param codeMicroOperation the codeMicroOperation to set
	 */
	public void setCodeMicroOperation(String codeMicroOperation) {
		this.codeMicroOperation = codeMicroOperation;
	}

	/**
	 * @return the codeSrt
	 */
	public String getCodeSrt() {
		return codeSrt;
	}

	/**
	 * @param codeSrt the codeSrt to set
	 */
	public void setCodeSrt(String codeSrt) {
		this.codeSrt = codeSrt;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the titleId
	 */
	public Long getTitleId() {
		return titleId;
	}

	/**
	 * @param titleId the titleId to set
	 */
	public void setTitleId(Long titleId) {
		this.titleId = titleId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the descriptionId
	 */
	public Long getDescriptionId() {
		return descriptionId;
	}

	/**
	 * @param descriptionId the descriptionId to set
	 */
	public void setDescriptionId(Long descriptionId) {
		this.descriptionId = descriptionId;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the locationFamilyIceCode
	 */
	public String getLocationFamilyIceCode() {
		return locationFamilyIceCode;
	}

	/**
	 * @param locationFamilyIceCode the locationFamilyIceCode to set
	 */
	public void setLocationFamilyIceCode(String locationFamilyIceCode) {
		this.locationFamilyIceCode = locationFamilyIceCode;
	}

	/**
	 * @return the locationGroupIceCode
	 */
	public String getLocationGroupIceCode() {
		return locationGroupIceCode;
	}

	/**
	 * @param locationGroupIceCode the locationGroupIceCode to set
	 */
	public void setLocationGroupIceCode(String locationGroupIceCode) {
		this.locationGroupIceCode = locationGroupIceCode;
	}

	/**
	 * @return the locationSubGroupIceCode
	 */
	public String getLocationSubGroupIceCode() {
		return locationSubGroupIceCode;
	}

	/**
	 * @param locationSubGroupIceCode the locationSubGroupIceCode to set
	 */
	public void setLocationSubGroupIceCode(String locationSubGroupIceCode) {
		this.locationSubGroupIceCode = locationSubGroupIceCode;
	}

	/**
	 * @return the locationLabel
	 */
	public String getLocationLabel() {
		return locationLabel;
	}

	/**
	 * @param locationLabel the locationLabel to set
	 */
	public void setLocationLabel(String locationLabel) {
		this.locationLabel = locationLabel;
	}

	/**
	 * @return the infotypeTopicIceCode
	 */
	public String getInfotypeTopicIceCode() {
		return infotypeTopicIceCode;
	}

	/**
	 * @param infotypeTopicIceCode the infotypeTopicIceCode to set
	 */
	public void setInfotypeTopicIceCode(String infotypeTopicIceCode) {
		this.infotypeTopicIceCode = infotypeTopicIceCode;
	}

	/**
	 * @return the infotypeSubTopicIceCode
	 */
	public String getInfotypeSubTopicIceCode() {
		return infotypeSubTopicIceCode;
	}

	/**
	 * @param infotypeSubTopicIceCode the infotypeSubTopicIceCode to set
	 */
	public void setInfotypeSubTopicIceCode(String infotypeSubTopicIceCode) {
		this.infotypeSubTopicIceCode = infotypeSubTopicIceCode;
	}

	/**
	 * @return the infotypeCategoryIceCode
	 */
	public String getInfotypeCategoryIceCode() {
		return infotypeCategoryIceCode;
	}

	/**
	 * @param infotypeCategoryIceCode the infotypeCategoryIceCode to set
	 */
	public void setInfotypeCategoryIceCode(String infotypeCategoryIceCode) {
		this.infotypeCategoryIceCode = infotypeCategoryIceCode;
	}

	/**
	 * @return the infotypeInfotypeIceCode
	 */
	public String getInfotypeInfotypeIceCode() {
		return infotypeInfotypeIceCode;
	}

	/**
	 * @param infotypeInfotypeIceCode the infotypeInfotypeIceCode to set
	 */
	public void setInfotypeInfotypeIceCode(String infotypeInfotypeIceCode) {
		this.infotypeInfotypeIceCode = infotypeInfotypeIceCode;
	}

	/**
	 * @return the infotypeLabel
	 */
	public String getInfotypeLabel() {
		return infotypeLabel;
	}

	/**
	 * @param infotypeLabel the infotype to set
	 */
	public void setInfotypeLabel(String infotypeLabel) {
		this.infotypeLabel = infotypeLabel;
	}

	/**
	 * @return the isOperationCurrentSerie
	 */
	public boolean isOperationCurrentSerie() {
		return isOperationCurrentSerie;
	}

	/**
	 * @param isOperationCurrentSerie the isOperationCurrentSerie to set
	 */
	public void setOperationCurrentSerie(boolean isOperationCurrentSerie) {
		this.isOperationCurrentSerie = isOperationCurrentSerie;
	}

	/**
	 * @return the infotype full ice code
	 */
	public String getInfotypeFullIceCode() {
		String toReturn = getInfotypeTopicIceCode();

		if (getInfotypeSubTopicIceCode() != null)
		{
			toReturn += ".";
			toReturn += getInfotypeSubTopicIceCode();

			if (getInfotypeCategoryIceCode() != null)
			{
				toReturn += ".";
				toReturn += getInfotypeCategoryIceCode();

				if (getInfotypeInfotypeIceCode() != null)
				{
					toReturn += ".";
					toReturn += getInfotypeInfotypeIceCode();
				}
			}
		}

		return toReturn;
	}

	/**
	 * @return the location full ice code
	 */
	public String getLocationFullIceCode() {

		String toReturn = getLocationFamilyIceCode();

		if (getLocationGroupIceCode() != null)
		{
			toReturn += ".";
			toReturn += getLocationGroupIceCode();

			if (getLocationSubGroupIceCode() != null)
			{
				toReturn += ".";
				toReturn += getLocationSubGroupIceCode();
			}
		}

		return toReturn;
	}

	/**
	 * @return the statusLabel
	 */
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @param statusLabel the statusLabel to set
	 */
	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * @return the lastModifier
	 */
	public String getLastModifier() {
		return lastModifier;
	}

	/**
	 * @param lastModifier the lastModifier to set
	 */
	public void setLastModifier(String lastModifier) {
		this.lastModifier = lastModifier;
	}

	/**
	 * Getter pour labelSeries.
	 *
	 * @return labelSeries
	 */
	public String getLabelSeries() {
		return labelSeries;
	}

	/**
	 * Setter pour labelSeries.
	 *
	 * @param labelSeries labelSeries à positionner.
	 */
	public void setLabelSeries(String labelSeries) {
		this.labelSeries = labelSeries;
	}

	/**
	 * Getter pour labelSeriesId.
	 *
	 * @return labelSeriesId
	 */
	public Long getLabelSeriesId() {
		return labelSeriesId;
	}

	/**
	 * Setter pour labelSeriesId.
	 *
	 * @param labelSeriesId labelSeriesId à positionner.
	 */
	public void setLabelSeriesId(Long labelSeriesId) {
		this.labelSeriesId = labelSeriesId;
	}

	/**
	 * Getter pour labelOpeType.
	 *
	 * @return labelOpeType
	 */
	public String getLabelOpeType() {
		return labelOpeType;
	}

	/**
	 * Setter pour labelOpeType.
	 *
	 * @param labelOpeType labelOpeType à positionner.
	 */
	public void setLabelOpeType(String labelOpeType) {
		this.labelOpeType = labelOpeType;
	}

	public Long getByCustomer() {
		return byCustomer;
	}

	public void setByCustomer(Long byCustomer) {
		this.byCustomer = byCustomer;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		if (id != null)
		{
			toReturn += "id " + id.toString();
		}
		toReturn += " - ";
		toReturn += "micro ope " + codeMicroOperation;
		toReturn += " - ";
		toReturn += "srt " + codeSrt;
		toReturn += " - ";
		toReturn += "title " + title;
		toReturn += " - ";
		if (titleId != null)
		{
			toReturn += "titleId " + titleId.toString();
			toReturn += " - ";
		}

		toReturn += "description " + description;
		toReturn += " - ";
		if (descriptionId != null)
		{
			toReturn += "descriptionId " + descriptionId.toString();
			toReturn += " - ";
		}
		toReturn += " - ";
		toReturn += "status " + status.toString();
		toReturn += " - ";
		if (modifDate != null)
		{
			toReturn += "status date " + modifDate.toString();
			toReturn += " - ";
		}
		toReturn += "location " + getLocationFamilyIceCode();
		toReturn += " - ";
		toReturn += "infotype " + getInfotypeFullIceCode();
		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	private String toJavaScriptCommon() {
		StringBuffer strForJavaSript = new StringBuffer();

		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (codeMicroOperation != null && !codeMicroOperation.equals(""))
		{
			strForJavaSript.append(codeMicroOperation);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (codeSrt != null && !codeSrt.equals(""))
		{
			strForJavaSript.append(codeSrt);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (title != null && !title.equals(""))
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(title));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (description != null && !description.equals(""))
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(description));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (status != null)
		{
			strForJavaSript.append(status.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (statusLabel != null)
		{
			strForJavaSript.append(statusLabel.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (getLocationFullIceCode() != null)
		{
			strForJavaSript.append(getLocationFullIceCode());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (locationLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(locationLabel));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (getInfotypeFullIceCode() != null)
		{
			strForJavaSript.append(getInfotypeFullIceCode());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (infotypeLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(infotypeLabel));
		}
		strForJavaSript.append("'");

		return strForJavaSript.toString();
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");

		strForJavaSript.append(toJavaScriptCommon());

		strForJavaSript.append(",").append(false);
		strForJavaSript.append(",''");
		strForJavaSript.append(",").append(new Long(0));
		strForJavaSript.append(",''");
		strForJavaSript.append(",''");
		strForJavaSript.append(",''");
		strForJavaSript.append(",''");
		strForJavaSript.append(",''");
		strForJavaSript.append(",").append(isOperationCurrentSerie);
		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @param selected for check box
	 * @param repairTime value
	 * @param byCustomer value
	 * @param operationSeriesId value
	 * @return formatted string
	 */
	public String toJavaScript(boolean selected, String repairTime, Long byCustomer, String operationSeriesId) {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");

		strForJavaSript.append(toJavaScriptCommon());
		strForJavaSript.append(",");
		strForJavaSript.append(selected);
		strForJavaSript.append(",'");
		strForJavaSript.append(repairTime);
		strForJavaSript.append("',");
		strForJavaSript.append(byCustomer);
		strForJavaSript.append(",'");
		strForJavaSript.append(operationSeriesId);
		strForJavaSript.append("','");
		strForJavaSript.append(labelSeries);
		strForJavaSript.append("','");
		strForJavaSript.append(labelSeries);
		strForJavaSript.append("','");
		strForJavaSript.append(labelSeriesId);
		strForJavaSript.append("','");
		strForJavaSript.append(labelOpeType);
		strForJavaSript.append("',");
		strForJavaSript.append(isOperationCurrentSerie);
		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}
}
