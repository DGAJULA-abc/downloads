/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.common.dto.AllApplicabilityDto;
import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public class OperationIuLinkDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** IU Id. **/
	private String iuId = null;

	/** IU Title. **/
	private String iuTitle = null;

	/** IU Location. **/
	private String iuLocation = null;

	/** IU Infotype. **/
	private String iuInfotype = null;

	/** IU Status. **/
	private String iuStatus = null;

	/** IU Applicability. */
	private List<AllApplicabilityDto> applicabilityList = null;

	/**
	 * Constructor.
	 */
	public OperationIuLinkDto() {
		super();
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the iuId
	 */
	public String getIuId() {
		return iuId;
	}

	/**
	 * @param iuId the iuId to set
	 */
	public void setIuId(String iuId) {
		this.iuId = iuId;
	}

	/**
	 * @return the iuTitle
	 */
	public String getIuTitle() {
		return iuTitle;
	}

	/**
	 * @param iuTitle the iuTitle to set
	 */
	public void setIuTitle(String iuTitle) {
		this.iuTitle = iuTitle;
	}

	/**
	 * @return the iuLocation
	 */
	public String getIuLocation() {
		return iuLocation;
	}

	/**
	 * @param iuLocation the iuLocation to set
	 */
	public void setIuLocation(String iuLocation) {
		this.iuLocation = iuLocation;
	}

	/**
	 * @return the iuInfotype
	 */
	public String getIuInfotype() {
		return iuInfotype;
	}

	/**
	 * @param iuInfotype the iuInfotype to set
	 */
	public void setIuInfotype(String iuInfotype) {
		this.iuInfotype = iuInfotype;
	}

	/**
	 * 
	 * @return the IU status
	 */
	public String getIuStatus() {
		return iuStatus;
	}

	/**
	 * 
	 * @param iuStatus the IU status to set
	 */
	public void setIuStatus(String iuStatus) {
		this.iuStatus = iuStatus;
	}

	/**
	 * 
	 * @return the applicability of the IU
	 */
	public List<AllApplicabilityDto> getApplicabilityList() {
		return applicabilityList;
	}

	/**
	 * 
	 * @param applicability the applicability of the IU
	 */
	public void setApplicabilityList(List<AllApplicabilityDto> applicabilityList) {
		this.applicabilityList = applicabilityList;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(idOperationSeries);
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(iuId);
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(iuTitle));
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (iuLocation != null)
		{
			strForJavaSript.append(iuLocation.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (iuInfotype != null)
		{
			strForJavaSript.append(iuInfotype.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
