/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

/**
 * @author sdomecq
 *
 */
public class OperationPartApplicabilityDto extends ApplicabilityDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long idOperationPart = null;

	/**
	 * Constructor.
	 */
	public OperationPartApplicabilityDto() {
		super();
	}

	/**
	 * @return the idOperationPart
	 */
	public Long getIdOperationPart() {
		return idOperationPart;
	}

	/**
	 * @param idOperationPart the idOperationPart to set
	 */
	public void setIdOperationPart(Long idOperationPart) {
		this.idOperationPart = idOperationPart;
	}

}
