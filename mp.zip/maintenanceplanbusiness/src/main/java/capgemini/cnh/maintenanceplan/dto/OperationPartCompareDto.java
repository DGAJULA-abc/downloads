/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationPartCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** code part. **/
	private String codePart = null;
	/** Label part. **/
	private String partLabel = null;

	/** quantity. **/
	private Double quantity = null;

	/** in kit. **/
	private boolean inKit = false;

	/** with data. **/
	private String withAppli = null;

	/** Model applicability. */
	private String modelAppli = null;

	/** TT applicability. */
	private String ttAppli = null;

	/** Market applicability. */
	private Long marketAppli = null;

	/** Configuration of the consumable. */
	private String configAppli = null;

	/**
	 * Constructor.
	 */
	public OperationPartCompareDto() {
		super();
	}

	/**
	 * @return
	 */
	public String getModelAppli() {
		return modelAppli;
	}

	/**
	 * @param modelAppli
	 */
	public void setModelAppli(String modelAppli) {
		this.modelAppli = modelAppli;
	}

	/**
	 * @return
	 */
	public String getTtAppli() {
		return ttAppli;
	}

	/**
	 * @param ttAppli
	 */
	public void setTtAppli(String ttAppli) {
		this.ttAppli = ttAppli;
	}

	/**
	 * @return
	 */
	public Long getMarketAppli() {
		return marketAppli;
	}

	/**
	 * @param marketAppli
	 */
	public void setMarketAppli(Long marketAppli) {
		this.marketAppli = marketAppli;
	}

	/**
	 * @return
	 */
	public String getConfigAppli() {
		return configAppli;
	}

	/**
	 * @param configAppli
	 */
	public void setConfigAppli(String configAppli) {
		this.configAppli = configAppli;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the codePart
	 */
	public String getCodePart() {
		return codePart;
	}

	/**
	 * @param codePart the codePart to set
	 */
	public void setCodePart(String codePart) {
		this.codePart = codePart;
	}

	/**
	 * @return the partLabel
	 */
	public String getPartLabel() {
		return partLabel;
	}

	/**
	 * @param partLabel the partLabel to set
	 */
	public void setPartLabel(String partLabel) {
		this.partLabel = partLabel;
	}

	/**
	 * @return the quantity
	 */
	public Double getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the inKit
	 */
	public boolean getInKit() {
		return inKit;
	}

	/**
	 * @param inKit the inKit to set
	 */
	public void setInKit(boolean inKit) {
		this.inKit = inKit;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "code part " + codePart;
		toReturn += " - ";
		toReturn += "part " + partLabel;

		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(codePart));
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(partLabel));
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (quantity != null)
		{
			strForJavaSript.append(quantity.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		if (inKit)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");
		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Double a, Double b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		OperationPartCompareDto other = (OperationPartCompareDto) obj;
		if (areEqual(this.getCodePart(), other.getCodePart())
				&& areEqual(this.getQuantity(), other.getQuantity())
				&& (this.getInKit() == other.getInKit())
				&& areEqual(this.getModelAppli(), other.getModelAppli())
				&& areEqual(this.getTtAppli(), other.getTtAppli())
				&& areEqual(this.getMarketAppli(), other.getMarketAppli())
				&& areEqual(this.getConfigAppli(), other.getConfigAppli()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
