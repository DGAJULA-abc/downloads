/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationPartDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** code part. **/
	private String codePart = null;
	/** Label part. **/
	private String partLabel = null;

	/** quantity. **/
	private Double quantity = null;

	/** Group. **/
	private Integer group = null;

	/** in kit. **/
	private boolean inKit = false;

	/** with data. **/
	private String withAppli = null;

	/** label origin. **/
	private String partLabelOrigin = null;

	private String note = null;

	/**
	 * Constructor.
	 */
	public OperationPartDto() {
		super();
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the codePart
	 */
	public String getCodePart() {
		return codePart;
	}

	/**
	 * @param codePart the codePart to set
	 */
	public void setCodePart(String codePart) {
		this.codePart = codePart;
	}

	/**
	 * @return the partLabel
	 */
	public String getPartLabel() {
		return partLabel;
	}

	/**
	 * @param partLabel the partLabel to set
	 */
	public void setPartLabel(String partLabel) {
		this.partLabel = partLabel;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the quantity
	 */
	public Double getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the inKit
	 */
	public boolean getInKit() {
		return inKit;
	}

	/**
	 * @param inKit the inKit to set
	 */
	public void setInKit(boolean inKit) {
		this.inKit = inKit;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * @return the partLabelOrigin
	 */
	public String getPartLabelOrigin() {
		return partLabelOrigin;
	}

	/**
	 * @param partLabelOrigin the partLabelOrigin to set
	 */
	public void setPartLabelOrigin(String partLabelOrigin) {
		this.partLabelOrigin = partLabelOrigin;
	}

	public Integer getGroup() {
		return group;
	}

	public void setGroup(Integer group) {
		this.group = group;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "code part " + codePart;
		toReturn += " - ";
		toReturn += "part " + partLabel;

		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("\"");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(codePart));
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(StringEscapeUtils.escapeJava(partLabel));
		strForJavaSript.append("\"");

		strForJavaSript.append(",");

		strForJavaSript.append("\"");
		if (note != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJava(note));
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");

		strForJavaSript.append("\"");
		if (quantity != null)
		{
			strForJavaSript.append(quantity.toString());
		}
		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		if (group != null)
		{
			strForJavaSript.append(group);
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");

		if (inKit)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}

		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		//		if (partLabelOrigin != null && partLabelOrigin.equals(Constants.PN_LBL_ORI_AUTHOR))
		//		{
		//			strForJavaSript.append("true");
		//		}
		//		else
		//		{
		//			strForJavaSript.append("false");
		//		}

		strForJavaSript.append("\"");
		if (partLabelOrigin != null)
		{
			strForJavaSript.append(partLabelOrigin);
		}
		strForJavaSript.append("\"");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScriptBis() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("\"");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(codePart));
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(StringEscapeUtils.escapeJava(partLabel));
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(StringEscapeUtils.escapeJava(note));
		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		if (group != null)
		{
			strForJavaSript.append(group);
		}
		strForJavaSript.append("\"");

		strForJavaSript.append(",");

		strForJavaSript.append("\"");
		if (quantity != null)
		{
			strForJavaSript.append(quantity.toString());
		}
		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		if (inKit)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}

		strForJavaSript.append("\"");

		strForJavaSript.append(",");
		//		if (partLabelOrigin != null && partLabelOrigin.equals(Constants.PN_LBL_ORI_AUTHOR))
		//		{
		//			strForJavaSript.append("true");
		//		}
		//		else
		//		{
		//			strForJavaSript.append("false");
		//		}
		strForJavaSript.append("\"");
		if (partLabelOrigin != null)
		{
			strForJavaSript.append(partLabelOrigin);
		}
		strForJavaSript.append("\"");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
