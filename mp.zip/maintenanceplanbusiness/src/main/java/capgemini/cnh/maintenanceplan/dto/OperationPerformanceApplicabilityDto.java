/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

/**
 * @author sdomecq
 *
 */
public class OperationPerformanceApplicabilityDto extends ApplicabilityDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** perf Id. **/
	private Long idPerformance = null;

	/** config item. **/
	private Integer configItem = null;

	/** applicability of plan. **/

	/** applicability. **/
	private String modelPlan = null;

	/** applicability. **/
	private String ttPlan = null;
	/** applicability. **/
	private Long marketPlan = null;
	/** applicability. **/
	private String configPlan = null;
	/** config item. **/
	private Integer configItemPlan = null;

	/**
	 * Constructor.
	 */
	public OperationPerformanceApplicabilityDto() {
		super();
	}

	/**
	 * @return the idPerformance
	 */
	public Long getIdPerformance() {
		return idPerformance;
	}

	/**
	 * @param idPerformance the idPerformance to set
	 */
	public void setIdPerformance(Long idPerformance) {
		this.idPerformance = idPerformance;
	}

	/**
	 * @return the configItem
	 */
	public Integer getConfigItem() {
		return configItem;
	}

	/**
	 * @param configItem the configItem to set
	 */
	public void setConfigItem(Integer configItem) {
		this.configItem = configItem;
	}

	/**
	 * @return the modelPlan
	 */
	public String getModelPlan() {
		return modelPlan;
	}

	/**
	 * @param modelPlan the modelPlan to set
	 */
	public void setModelPlan(String modelPlan) {
		this.modelPlan = modelPlan;
	}

	/**
	 * @return the ttPlan
	 */
	public String getTtPlan() {
		return ttPlan;
	}

	/**
	 * @param ttPlan the ttPlan to set
	 */
	public void setTtPlan(String ttPlan) {
		this.ttPlan = ttPlan;
	}

	/**
	 * @return the marketPlan
	 */
	public Long getMarketPlan() {
		return marketPlan;
	}

	/**
	 * @param marketPlan the marketPlan to set
	 */
	public void setMarketPlan(Long marketPlan) {
		this.marketPlan = marketPlan;
	}

	/**
	 * @return the configPlan
	 */
	public String getConfigPlan() {
		return configPlan;
	}

	/**
	 * @param configPlan the configPlan to set
	 */
	public void setConfigPlan(String configPlan) {
		this.configPlan = configPlan;
	}

	/**
	 * @return the configItemPlan
	 */
	public Integer getConfigItemPlan() {
		return configItemPlan;
	}

	/**
	 * @param configItemPlan the configItemPlan to set
	 */
	public void setConfigItemPlan(Integer configItemPlan) {
		this.configItemPlan = configItemPlan;
	}

}
