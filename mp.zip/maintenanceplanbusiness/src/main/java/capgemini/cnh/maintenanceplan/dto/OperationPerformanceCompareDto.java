/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationPerformanceCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** id performance. **/
	private Long idPerformance = null;

	/** Label performance. **/
	private String performanceLabel = null;

	/** Max start Value KM. **/
	private Long maxStartValueKm = null;

	/** Max start Value Month. **/
	private Long maxStartValueMonth = null;

	/** Max start Value Hour. **/
	private Long maxStartValueHour = null;

	/** Max after Value Km. **/
	private Long maxAfterValueKm = null;

	/** Max after Value Month. **/
	private Long maxAfterValueMonth = null;

	/** Max after Value Hour. **/
	private Long maxAfterValueHour = null;

	/** Harm start Value Km. **/
	private Long harmStartValueKm = null;

	/** Max start Value Month. **/
	private Long harmStartValueMonth = null;

	/** Max Start Value Hour. **/
	private Long harmStartValueHour = null;

	/** Harm after Value Km. **/
	private Long harmAfterValueKm = null;

	/** Harm after Value Month. **/
	private Long harmAfterValueMonth = null;

	/** Harm Start Value Hour. **/
	private Long harmAfterValueHour = null;

	/** condition. **/
	private ConditionDto condition = null;

	/** Max group. **/
	private Long maxGroup = null;

	/** Harm group. **/
	private Long harmGroup = null;

	/** with data. **/
	private String withAppli = null;

	/** Model applicability. */
	private String modelAppli = null;

	/** TT applicability. */
	private String ttAppli = null;

	/** Market applicability. */
	private Long marketAppli = null;

	/** Configuration of the consumable. */
	private String configAppli = null;

	/**
	 * Constructor.
	 */
	public OperationPerformanceCompareDto() {
		super();
	}

	/**
	 * @return the idPerformance
	 */
	public Long getIdPerformance() {
		return idPerformance;
	}

	/**
	 * @param idPerformance the idPerformance to set
	 */
	public void setIdPerformance(Long idPerformance) {
		this.idPerformance = idPerformance;
	}

	/**
	 * @return the performanceLabel
	 */
	public String getPerformanceLabel() {
		return performanceLabel;
	}

	/**
	 * @param performanceLabel the performanceLabel to set
	 */
	public void setPerformanceLabel(String performanceLabel) {
		this.performanceLabel = performanceLabel;
	}

	/**
	 * @return the maxStartValueKm
	 */
	public Long getMaxStartValueKm() {
		return maxStartValueKm;
	}

	/**
	 * @param maxStartValueKm the maxStartValueKm to set
	 */
	public void setMaxStartValueKm(Long maxStartValueKm) {
		this.maxStartValueKm = maxStartValueKm;
	}

	/**
	 * @return the maxStartValueMonth
	 */
	public Long getMaxStartValueMonth() {
		return maxStartValueMonth;
	}

	/**
	 * @param maxStartValueMonth the maxStartValueMonth to set
	 */
	public void setMaxStartValueMonth(Long maxStartValueMonth) {
		this.maxStartValueMonth = maxStartValueMonth;
	}

	/**
	 * @return the maxStartValueHour
	 */
	public Long getMaxStartValueHour() {
		return maxStartValueHour;
	}

	/**
	 * @param maxStartValueHour the maxStartValueHour to set
	 */
	public void setMaxStartValueHour(Long maxStartValueHour) {
		this.maxStartValueHour = maxStartValueHour;
	}

	/**
	 * @return the maxAfterValueKm
	 */
	public Long getMaxAfterValueKm() {
		return maxAfterValueKm;
	}

	/**
	 * @param maxAfterValueKm the maxAfterValueKm to set
	 */
	public void setMaxAfterValueKm(Long maxAfterValueKm) {
		this.maxAfterValueKm = maxAfterValueKm;
	}

	/**
	 * @return the maxAfterValueMonth
	 */
	public Long getMaxAfterValueMonth() {
		return maxAfterValueMonth;
	}

	/**
	 * @param maxAfterValueMonth the maxAfterValueMonth to set
	 */
	public void setMaxAfterValueMonth(Long maxAfterValueMonth) {
		this.maxAfterValueMonth = maxAfterValueMonth;
	}

	/**
	 * @return the maxAfterValueHour
	 */
	public Long getMaxAfterValueHour() {
		return maxAfterValueHour;
	}

	/**
	 * @param maxAfterValueHour the maxAfterValueHour to set
	 */
	public void setMaxAfterValueHour(Long maxAfterValueHour) {
		this.maxAfterValueHour = maxAfterValueHour;
	}

	/**
	 * @return the harmStartValueKm
	 */
	public Long getHarmStartValueKm() {
		return harmStartValueKm;
	}

	/**
	 * @param harmStartValueKm the harmStartValueKm to set
	 */
	public void setHarmStartValueKm(Long harmStartValueKm) {
		this.harmStartValueKm = harmStartValueKm;
	}

	/**
	 * @return the harmStartValueMonth
	 */
	public Long getHarmStartValueMonth() {
		return harmStartValueMonth;
	}

	/**
	 * @param harmStartValueMonth the harmStartValueMonth to set
	 */
	public void setHarmStartValueMonth(Long harmStartValueMonth) {
		this.harmStartValueMonth = harmStartValueMonth;
	}

	/**
	 * @return the harmStartValueHour
	 */
	public Long getHarmStartValueHour() {
		return harmStartValueHour;
	}

	/**
	 * @param harmStartValueHour the harmStartValueHour to set
	 */
	public void setHarmStartValueHour(Long harmStartValueHour) {
		this.harmStartValueHour = harmStartValueHour;
	}

	/**
	 * @return the harmAfterValueKm
	 */
	public Long getHarmAfterValueKm() {
		return harmAfterValueKm;
	}

	/**
	 * @param harmAfterValueKm the harmAfterValueKm to set
	 */
	public void setHarmAfterValueKm(Long harmAfterValueKm) {
		this.harmAfterValueKm = harmAfterValueKm;
	}

	/**
	 * @return the harmAfterValueMonth
	 */
	public Long getHarmAfterValueMonth() {
		return harmAfterValueMonth;
	}

	/**
	 * @param harmAfterValueMonth the harmAfterValueMonth to set
	 */
	public void setHarmAfterValueMonth(Long harmAfterValueMonth) {
		this.harmAfterValueMonth = harmAfterValueMonth;
	}

	/**
	 * @return the harmAfterValueHour
	 */
	public Long getHarmAfterValueHour() {
		return harmAfterValueHour;
	}

	/**
	 * @param harmAfterValueHour the harmAfterValueHour to set
	 */
	public void setHarmAfterValueHour(Long harmAfterValueHour) {
		this.harmAfterValueHour = harmAfterValueHour;
	}

	/**
	 * @return the condition
	 */
	public ConditionDto getCondition() {
		return condition;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(ConditionDto condition) {
		this.condition = condition;
	}

	/**
	 * @return the maxGroup
	 */
	public Long getMaxGroup() {
		return maxGroup;
	}

	/**
	 * @param maxGroup the maxGroup to set
	 */
	public void setMaxGroup(Long maxGroup) {
		this.maxGroup = maxGroup;
	}

	/**
	 * @return the harmGroup
	 */
	public Long getHarmGroup() {
		return harmGroup;
	}

	/**
	 * @param harmGroup the harmGroup to set
	 */
	public void setHarmGroup(Long harmGroup) {
		this.harmGroup = harmGroup;
	}

	/**
	 * 
	 * @return The model applicability
	 */
	public String getModelAppli() {
		return modelAppli;
	}

	/**
	 * 
	 * @param modelAppli The model applicability to set
	 */
	public void setModelAppli(String modelAppli) {
		this.modelAppli = modelAppli;
	}

	/**
	 * 
	 * @return The TT applicability
	 */
	public String getTtAppli() {
		return ttAppli;
	}

	/**
	 * 
	 * @param ttAppli The TT applicability to set
	 */
	public void setTtAppli(String ttAppli) {
		this.ttAppli = ttAppli;
	}

	/**
	 * 
	 * @return The market applicability
	 */
	public Long getMarketAppli() {
		return marketAppli;
	}

	/**
	 * 
	 * @param marketAppli The market applicability to set
	 */
	public void setMarketAppli(Long marketAppli) {
		this.marketAppli = marketAppli;
	}

	/**
	 * 
	 * @return The Configuration applicability
	 */
	public String getConfigAppli() {
		return configAppli;
	}

	/**
	 * 
	 * @param configAppli The Configuration applicability to set
	 */
	public void setConfigAppli(String configAppli) {
		this.configAppli = configAppli;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		if (idPerformance != null)
		{
			toReturn += "id performance " + idPerformance.toString();
		}

		return toReturn;
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Double a, Double b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(ConditionDto a, ConditionDto b) {
		boolean result = false;
		if (a == null && b == null)
		{
			result = true;
		}
		else if (a == null || b == null)
		{
			result = false;
		}
		else
		{
			UsageDto aDto = ((ConditionDto) a).getUsage();
			UsageDto bDto = ((ConditionDto) b).getUsage();
			if (aDto == null && bDto == null)
			{
				result = true;
			}
			else if (aDto != null && bDto != null)
			{
				result = areEqual(aDto.getValueId(), bDto.getValueId());
			}
			else
			{
				result = false;
			}
		}
		return result;
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		OperationPerformanceCompareDto other = (OperationPerformanceCompareDto) obj;
		if (areEqual(this.getPerformanceLabel(), other.getPerformanceLabel())
				&& areEqual(this.getMaxStartValueKm(), other.getMaxStartValueKm())
				&& areEqual(this.getMaxStartValueMonth(), other.getMaxStartValueMonth())
				&& areEqual(this.getMaxStartValueHour(), other.getMaxStartValueHour())
				&& areEqual(this.getMaxAfterValueKm(), other.getMaxAfterValueKm())
				&& areEqual(this.getMaxAfterValueMonth(), other.getMaxAfterValueMonth())
				&& areEqual(this.getMaxAfterValueHour(), other.getMaxAfterValueHour())
				&& areEqual(this.getHarmStartValueKm(), other.getHarmStartValueKm())
				&& areEqual(this.getHarmStartValueMonth(), other.getHarmStartValueMonth())
				&& areEqual(this.getHarmStartValueHour(), other.getHarmStartValueHour())
				&& areEqual(this.getHarmAfterValueKm(), other.getHarmAfterValueKm())
				&& areEqual(this.getHarmAfterValueMonth(), other.getHarmAfterValueMonth())
				&& areEqual(this.getHarmAfterValueHour(), other.getHarmAfterValueHour())
				&& areEqual(this.getCondition(), other.getCondition())
				&& areEqual(this.getModelAppli(), other.getModelAppli())
				&& areEqual(this.getTtAppli(), other.getTtAppli())
				&& areEqual(this.getMarketAppli(), other.getMarketAppli())
				&& areEqual(this.getConfigAppli(), other.getConfigAppli()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
