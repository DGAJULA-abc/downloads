/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.common.Constantes;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.util.ResourceLabel;

/**
 * @author mamestoy
 *
 */
public class OperationPerformanceDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** operation code. **/
	private String operationCode = null;

	/** id performance. **/
	private Long idPerformance = null;

	/** Label performance. **/
	private String performanceLabel = null;

	/** Max start Value KM. **/
	private Long maxStartValueKm = null;

	/** Max start Value Month. **/
	private Long maxStartValueMonth = null;

	/** Max start Value Hour. **/
	private Long maxStartValueHour = null;

	/** Max after Value Km. **/
	private Long maxAfterValueKm = null;

	/** Max after Value Month. **/
	private Long maxAfterValueMonth = null;

	/** Max after Value Hour. **/
	private Long maxAfterValueHour = null;

	/** Harm start Value Km. **/
	private Long harmStartValueKm = null;

	/** Max start Value Month. **/
	private Long harmStartValueMonth = null;

	/** Max Start Value Hour. **/
	private Long harmStartValueHour = null;

	/** Harm after Value Km. **/
	private Long harmAfterValueKm = null;

	/** Harm after Value Month. **/
	private Long harmAfterValueMonth = null;

	/** Harm Start Value Hour. **/
	private Long harmAfterValueHour = null;

	/** condition. **/
	private ConditionDto condition = null;

	/** with data. **/
	private String withAppli = null;

	/** Max group. **/
	private Long maxGroup = null;

	/** Harm group. **/
	private Long harmGroup = null;

	/** Modif date **/
	private String modifDate = null;

	private Long byCustomer = null;

	/**
	 * Constructor.
	 */
	public OperationPerformanceDto() {
		super();
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the idPerformance
	 */
	public Long getIdPerformance() {
		return idPerformance;
	}

	/**
	 * @param idPerformance the idPerformance to set
	 */
	public void setIdPerformance(Long idPerformance) {
		this.idPerformance = idPerformance;
	}

	/**
	 * @return the performanceLabel
	 */
	public String getPerformanceLabel() {
		return performanceLabel;
	}

	/**
	 * @param performanceLabel the performanceLabel to set
	 */
	public void setPerformanceLabel(String performanceLabel) {
		this.performanceLabel = performanceLabel;
	}

	/**
	 * @return the maxStartValueKm
	 */
	public Long getMaxStartValueKm() {
		return maxStartValueKm;
	}

	/**
	 * @param maxStartValueKm the maxStartValueKm to set
	 */
	public void setMaxStartValueKm(Long maxStartValueKm) {
		this.maxStartValueKm = maxStartValueKm;
	}

	/**
	 * @return the maxStartValueMonth
	 */
	public Long getMaxStartValueMonth() {
		return maxStartValueMonth;
	}

	/**
	 * @param maxStartValueMonth the maxStartValueMonth to set
	 */
	public void setMaxStartValueMonth(Long maxStartValueMonth) {
		this.maxStartValueMonth = maxStartValueMonth;
	}

	/**
	 * @return the maxStartValueHour
	 */
	public Long getMaxStartValueHour() {
		return maxStartValueHour;
	}

	/**
	 * @param maxStartValueHour the maxStartValueHour to set
	 */
	public void setMaxStartValueHour(Long maxStartValueHour) {
		this.maxStartValueHour = maxStartValueHour;
	}

	/**
	 * @return the maxAfterValueKm
	 */
	public Long getMaxAfterValueKm() {
		return maxAfterValueKm;
	}

	/**
	 * @param maxAfterValueKm the maxAfterValueKm to set
	 */
	public void setMaxAfterValueKm(Long maxAfterValueKm) {
		this.maxAfterValueKm = maxAfterValueKm;
	}

	/**
	 * @return the maxAfterValueMonth
	 */
	public Long getMaxAfterValueMonth() {
		return maxAfterValueMonth;
	}

	/**
	 * @param maxAfterValueMonth the maxAfterValueMonth to set
	 */
	public void setMaxAfterValueMonth(Long maxAfterValueMonth) {
		this.maxAfterValueMonth = maxAfterValueMonth;
	}

	/**
	 * @return the maxAfterValueHour
	 */
	public Long getMaxAfterValueHour() {
		return maxAfterValueHour;
	}

	/**
	 * @param maxAfterValueHour the maxAfterValueHour to set
	 */
	public void setMaxAfterValueHour(Long maxAfterValueHour) {
		this.maxAfterValueHour = maxAfterValueHour;
	}

	/**
	 * @return the harmStartValueKm
	 */
	public Long getHarmStartValueKm() {
		return harmStartValueKm;
	}

	/**
	 * @param harmStartValueKm the harmStartValueKm to set
	 */
	public void setHarmStartValueKm(Long harmStartValueKm) {
		this.harmStartValueKm = harmStartValueKm;
	}

	/**
	 * @return the harmStartValueMonth
	 */
	public Long getHarmStartValueMonth() {
		return harmStartValueMonth;
	}

	/**
	 * @param harmStartValueMonth the harmStartValueMonth to set
	 */
	public void setHarmStartValueMonth(Long harmStartValueMonth) {
		this.harmStartValueMonth = harmStartValueMonth;
	}

	/**
	 * @return the harmStartValueHour
	 */
	public Long getHarmStartValueHour() {
		return harmStartValueHour;
	}

	/**
	 * @param harmStartValueHour the harmStartValueHour to set
	 */
	public void setHarmStartValueHour(Long harmStartValueHour) {
		this.harmStartValueHour = harmStartValueHour;
	}

	/**
	 * @return the harmAfterValueKm
	 */
	public Long getHarmAfterValueKm() {
		return harmAfterValueKm;
	}

	/**
	 * @param harmAfterValueKm the harmAfterValueKm to set
	 */
	public void setHarmAfterValueKm(Long harmAfterValueKm) {
		this.harmAfterValueKm = harmAfterValueKm;
	}

	/**
	 * @return the harmAfterValueMonth
	 */
	public Long getHarmAfterValueMonth() {
		return harmAfterValueMonth;
	}

	/**
	 * @param harmAfterValueMonth the harmAfterValueMonth to set
	 */
	public void setHarmAfterValueMonth(Long harmAfterValueMonth) {
		this.harmAfterValueMonth = harmAfterValueMonth;
	}

	/**
	 * @return the harmAfterValueHour
	 */
	public Long getHarmAfterValueHour() {
		return harmAfterValueHour;
	}

	/**
	 * @param harmAfterValueHour the harmAfterValueHour to set
	 */
	public void setHarmAfterValueHour(Long harmAfterValueHour) {
		this.harmAfterValueHour = harmAfterValueHour;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		if (idPerformance != null)
		{
			toReturn += "id performance " + idPerformance.toString();
		}
		return toReturn;
	}

	/**
	 * @return the condition
	 */
	public ConditionDto getCondition() {
		return condition;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(ConditionDto condition) {
		this.condition = condition;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * @return the maxGroup
	 */
	public Long getMaxGroup() {
		return maxGroup;
	}

	/**
	 * @param maxGroup the maxGroup to set
	 */
	public void setMaxGroup(Long maxGroup) {
		this.maxGroup = maxGroup;
	}

	/**
	 * @return the harmGroup
	 */
	public Long getHarmGroup() {
		return harmGroup;
	}

	/**
	 * @param harmGroup the harmGroup to set
	 */
	public void setHarmGroup(Long harmGroup) {
		this.harmGroup = harmGroup;
	}

	/**
	 * @return the operationCode
	 */
	public String getOperationCode() {
		return operationCode;
	}

	/**
	 * @param operationCode the operationCode to set
	 */
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	public Long getByCustomer() {
		return byCustomer;
	}

	public void setByCustomer(Long byCustomer) {
		this.byCustomer = byCustomer;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (idPerformance != null)
		{
			strForJavaSript.append(idPerformance.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(performanceLabel));
		strForJavaSript.append("'");

		if (condition != null)
		{
			strForJavaSript.append(",");
			strForJavaSript.append(condition.toJavaScript(false));
		}
		else
		{

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");
		}
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (maxStartValueKm != null)
		{
			strForJavaSript.append(maxStartValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxStartValueMonth != null)
		{
			strForJavaSript.append(maxStartValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxStartValueHour != null)
		{
			strForJavaSript.append(maxStartValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxAfterValueKm != null)
		{
			strForJavaSript.append(maxAfterValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxAfterValueMonth != null)
		{
			strForJavaSript.append(maxAfterValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxAfterValueHour != null)
		{
			strForJavaSript.append(maxAfterValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (maxGroup != null)
		{
			strForJavaSript.append(maxGroup);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmStartValueKm != null)
		{
			strForJavaSript.append(harmStartValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmStartValueMonth != null)
		{
			strForJavaSript.append(harmStartValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmStartValueHour != null)
		{
			strForJavaSript.append(harmStartValueHour.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmAfterValueKm != null)
		{
			strForJavaSript.append(harmAfterValueKm.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmAfterValueMonth != null)
		{
			strForJavaSript.append(harmAfterValueMonth.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmAfterValueHour != null)
		{
			strForJavaSript.append(harmAfterValueHour);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (harmGroup != null)
		{
			strForJavaSript.append(harmGroup);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (byCustomer != null)
		{
			strForJavaSript.append(byCustomer);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");

		if (byCustomer != null)
		{
			switch (byCustomer.intValue())
			{
			case Constantes.OPE_CUSTOMER:
				strForJavaSript.append(ResourceLabel.getInstance().getLabel("customer"));
				break;
			case Constantes.OPE_CUSTOMER_CONTRACT:
				strForJavaSript.append(ResourceLabel.getInstance().getLabel("customer.with.contract"));
				break;
			case Constantes.OPE_DEALER:
				strForJavaSript.append(ResourceLabel.getInstance().getLabel("dealer"));
				break;
			}
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
