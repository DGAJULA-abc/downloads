/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class OperationSeriesConsCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public OperationSeriesConsCompareDto() {
		super();
	}

	/** Id. **/
	private Long id = null;

	/** MP ID. **/
	private Long mpId = null;

	/** operation series Id old link to mp_interval_operation. **/
	private Long idOperationLinkInt = null;

	/** operation ID. **/
	private Long idOperation = null;

	/** operation detail. **/
	private OperationDto operation = null;

	/** brand ice code. **/
	private String applicabilityBrandIceCode = null;
	/** type ice code. **/
	private String applicabilityTypeIceCode = null;
	/** product ice code. **/
	private String applicabilityProductIceCode = null;
	/** series ice code. **/
	private String applicabilitySeriesIceCode = null;
	/** series ice code. **/
	private String applicabilitySeriesId = null;
	/** applicability label. **/
	private String applicabilityLabel = null;

	/** repair time . **/
	private Integer repairTime = null;

	/** can be made by customer . **/
	private boolean byCustomer = false;

	/** with data. **/
	private String withConsumable = "";

	/** with data. **/
	private String withParts = "";

	/** with data. **/
	private String withPerf = "";

	/** List of consumables for the operation. */
	private List<OperationConsumableCompareDto> consList = null;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * 
	 * @return The consumable list
	 */
	public List<OperationConsumableCompareDto> getConsList() {
		return consList;
	}

	/**
	 * 
	 * @param consList The consumable list to set
	 */
	public void setConsList(List<OperationConsumableCompareDto> consList) {
		this.consList = consList;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the applicabilityBrandIceCode
	 */
	public String getApplicabilityBrandIceCode() {
		return applicabilityBrandIceCode;
	}

	/**
	 * @param applicabilityBrandIceCode the applicabilityBrandIceCode to set
	 */
	public void setApplicabilityBrandIceCode(String applicabilityBrandIceCode) {
		this.applicabilityBrandIceCode = applicabilityBrandIceCode;
	}

	/**
	 * @return the applicabilityTypeIceCode
	 */
	public String getApplicabilityTypeIceCode() {
		return applicabilityTypeIceCode;
	}

	/**
	 * @param applicabilityTypeIceCode the applicabilityTypeIceCode to set
	 */
	public void setApplicabilityTypeIceCode(String applicabilityTypeIceCode) {
		this.applicabilityTypeIceCode = applicabilityTypeIceCode;
	}

	/**
	 * @return the applicabilityProductIceCode
	 */
	public String getApplicabilityProductIceCode() {
		return applicabilityProductIceCode;
	}

	/**
	 * @param applicabilityProductIceCode the applicabilityProductIceCode to set
	 */
	public void setApplicabilityProductIceCode(String applicabilityProductIceCode) {
		this.applicabilityProductIceCode = applicabilityProductIceCode;
	}

	/**
	 * @return the applicabilitySeriesIceCode
	 */
	public String getApplicabilitySeriesIceCode() {
		return applicabilitySeriesIceCode;
	}

	/**
	 * @param applicabilitySeriesIceCode the applicabilitySeriesIceCode to set
	 */
	public void setApplicabilitySeriesIceCode(String applicabilitySeriesIceCode) {
		this.applicabilitySeriesIceCode = applicabilitySeriesIceCode;
	}

	/**
	 * @return the applicabilityLabel
	 */
	public String getApplicabilityLabel() {
		return applicabilityLabel;
	}

	/**
	 * @param applicabilityLabel the applicabilityLabel to set
	 */
	public void setApplicabilityLabel(String applicabilityLabel) {
		this.applicabilityLabel = applicabilityLabel;
	}

	/**
	 * @return the repairTime
	 */
	public Integer getRepairTime() {
		return repairTime;
	}

	/**
	 * @param repairTime the repairTime to set
	 */
	public void setRepairTime(Integer repairTime) {
		this.repairTime = repairTime;
	}

	/**
	 * @return the applicability full ice code
	 */
	public String getSeriesFullIceCode() {
		String toReturn = getApplicabilityBrandIceCode();
		toReturn += ".";
		toReturn += getApplicabilityTypeIceCode();
		toReturn += ".";
		toReturn += getApplicabilityProductIceCode();
		toReturn += ".";
		toReturn += getApplicabilitySeriesIceCode();

		return toReturn;
	}

	/**
	 * @return the operation
	 */
	public OperationDto getOperation() {
		return operation;
	}

	/**
	 * @param operation the operation to set
	 */
	public void setOperation(OperationDto operation) {
		this.operation = operation;
	}

	/**
	 * @return the applicabilitySeriesId
	 */
	public String getApplicabilitySeriesId() {
		return applicabilitySeriesId;
	}

	/**
	 * @param applicabilitySeriesId the applicabilitySeriesId to set
	 */
	public void setApplicabilitySeriesId(String applicabilitySeriesId) {
		this.applicabilitySeriesId = applicabilitySeriesId;
	}

	/**
	 * @return the MP id
	 */
	public Long getMPId() {
		return mpId;
	}

	/**
	 * @param mpId the MP id to set
	 */
	public void setMPId(Long mpId) {
		this.mpId = mpId;
	}

	/**
	 * @return the idOperation
	 */
	public Long getIdOperation() {
		return idOperation;
	}

	/**
	 * @param idOperation the idOperation to set
	 */
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	/**
	 * @return the byCustomer
	 */
	public boolean getByCustomer() {
		return byCustomer;
	}

	/**
	 * @param byCustomer the byCustomer to set
	 */
	public void setByCustomer(boolean byCustomer) {
		this.byCustomer = byCustomer;
	}

	/**
	 * @return the withConsumable
	 */
	public String getWithConsumable() {
		return withConsumable;
	}

	/**
	 * @param withConsumable the withConsumable to set
	 */
	public void setWithConsumable(String withConsumable) {
		this.withConsumable = withConsumable;
	}

	/**
	 * @return the withParts
	 */
	public String getWithParts() {
		return withParts;
	}

	/**
	 * @param withParts the withParts to set
	 */
	public void setWithParts(String withParts) {
		this.withParts = withParts;
	}

	/**
	 * @return the withPerf
	 */
	public String getWithPerf() {
		return withPerf;
	}

	/**
	 * @param withPerf the withPerf to set
	 */
	public void setWithPerf(String withPerf) {
		this.withPerf = withPerf;
	}

	/**
	 * @return the idOperationLinkInt
	 */
	public Long getIdOperationLinkInt() {
		return idOperationLinkInt;
	}

	/**
	 * @param idOperationLinkInt the idOperationLinkInt to set
	 */
	public void setIdOperationLinkInt(Long idOperationLinkInt) {
		this.idOperationLinkInt = idOperationLinkInt;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		if (id != null)
		{
			toReturn += "id " + id.toString();
		}
		toReturn += " - ";
		if (operation != null)
		{
			toReturn += "id operation" + operation.getId().toString();
		}
		toReturn += " - ";
		toReturn += "series " + getSeriesFullIceCode();
		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (applicabilityLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(applicabilityLabel));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(getSeriesFullIceCode());
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (applicabilitySeriesId != null)
		{
			strForJavaSript.append(applicabilitySeriesId);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getId() != null)
		{
			strForJavaSript.append(operation.getId().toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getCodeMicroOperation() != null)
		{
			strForJavaSript.append(operation.getCodeMicroOperation());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getCodeSrt() != null)
		{
			strForJavaSript.append(operation.getCodeSrt());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getTitle() != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(operation.getTitle()));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getDescription() != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(operation.getDescription()));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getLocationFullIceCode() != null)
		{
			strForJavaSript.append(operation.getLocationFullIceCode());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getLocationLabel() != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(operation.getLocationLabel()));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getInfotypeFullIceCode() != null)
		{
			strForJavaSript.append(operation.getInfotypeFullIceCode());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if ((operation != null) && operation.getInfotypeLabel() != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(operation.getInfotypeLabel()));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (repairTime != null)
		{
			strForJavaSript.append(repairTime.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (byCustomer)
		{
			strForJavaSript.append("X");
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withConsumable != null)
		{
			strForJavaSript.append(withConsumable);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withParts != null)
		{
			strForJavaSript.append(withParts);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withPerf != null)
		{
			strForJavaSript.append(withPerf);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Integer a, Integer b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		OperationSeriesConsCompareDto other = (OperationSeriesConsCompareDto) obj;
		if (areEqual(this.getIdOperation(), other.getIdOperation())
				&& areEqual(this.getRepairTime(), other.getRepairTime())
				&& this.getByCustomer() == other.getByCustomer()
				&& areEqual(this.getWithParts(), other.getWithParts())
				&& areEqual(this.getWithConsumable(), other.getWithConsumable()))
		{
			int diff = 0;
			List<OperationConsumableCompareDto> lstOpeCons = new ArrayList<OperationConsumableCompareDto>(this.getConsList().size());
			List<OperationConsumableCompareDto> lstOpeCons2 = new ArrayList<OperationConsumableCompareDto>(other.getConsList().size());

			lstOpeCons.addAll(this.getConsList());
			lstOpeCons2.addAll(other.getConsList());

			if (lstOpeCons.size() >= lstOpeCons2.size())
			{
				lstOpeCons.removeAll(lstOpeCons2);
				diff = lstOpeCons.size();
			}
			else
			{
				lstOpeCons2.removeAll(lstOpeCons);
				diff = lstOpeCons2.size();
			}

			if (diff == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}

}
