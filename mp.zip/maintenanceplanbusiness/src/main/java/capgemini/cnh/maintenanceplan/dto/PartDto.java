/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class PartDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** code part. **/
	private String codePart = null;
	/** Label part. **/
	private String partLabel = null;

	/** family ice code. **/
	private String locationFamilyIceCode = null;
	/** group ice code. **/
	private String locationGroupIceCode = null;
	/** subgroup ice code. **/
	private String locationSubGroupIceCode = null;
	/** location label. **/
	private String locationLabel = null;
	/** language */
	private String language = null;
	/** label origin. **/
	private String partLabelOrigin = null;

	/**
	 * Constructor.
	 */
	public PartDto() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param code for init
	 * @param label for init
	 */
	public PartDto(String code, String label, String labelOrigin) {

		super();
		codePart = code;
		partLabel = label;
		partLabelOrigin = labelOrigin;
	}

	/**
	 * @return the codePart
	 */
	public String getCodePart() {
		return codePart;
	}

	/**
	 * @param codePart the codePart to set
	 */
	public void setCodePart(String codePart) {
		this.codePart = codePart;
	}

	/**
	 * @return the partLabel
	 */
	public String getPartLabel() {
		return partLabel;
	}

	/**
	 * @param partLabel the partLabel to set
	 */
	public void setPartLabel(String partLabel) {
		this.partLabel = partLabel;
	}

	/**
	 * @return the locationFamilyIceCode
	 */
	public String getLocationFamilyIceCode() {
		return locationFamilyIceCode;
	}

	/**
	 * @param locationFamilyIceCode the locationFamilyIceCode to set
	 */
	public void setLocationFamilyIceCode(String locationFamilyIceCode) {
		this.locationFamilyIceCode = locationFamilyIceCode;
	}

	/**
	 * @return the locationGroupIceCode
	 */
	public String getLocationGroupIceCode() {
		return locationGroupIceCode;
	}

	/**
	 * @param locationGroupIceCode the locationGroupIceCode to set
	 */
	public void setLocationGroupIceCode(String locationGroupIceCode) {
		this.locationGroupIceCode = locationGroupIceCode;
	}

	/**
	 * @return the locationSubGroupIceCode
	 */
	public String getLocationSubGroupIceCode() {
		return locationSubGroupIceCode;
	}

	/**
	 * @param locationSubGroupIceCode the locationSubGroupIceCode to set
	 */
	public void setLocationSubGroupIceCode(String locationSubGroupIceCode) {
		this.locationSubGroupIceCode = locationSubGroupIceCode;
	}

	/**
	 * @return the locationLabel
	 */
	public String getLocationLabel() {
		return locationLabel;
	}

	/**
	 * @param locationLabel the locationLabel to set
	 */
	public void setLocationLabel(String locationLabel) {
		this.locationLabel = locationLabel;
	}

	/**
	 * 
	 * @return
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * 
	 * @param language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the partLabelOrigin
	 */
	public String getPartLabelOrigin() {
		return partLabelOrigin;
	}

	/**
	 * @param partLabelOrigin the partLabelOrigin to set
	 */
	public void setPartLabelOrigin(String partLabelOrigin) {
		this.partLabelOrigin = partLabelOrigin;
	}

	/**
	 * @return the location full ice code
	 */
	public String getLocationFullIceCode() {
		String toReturn = getLocationFamilyIceCode();

		if (getLocationGroupIceCode() != null)
		{
			toReturn += ".";
			toReturn += getLocationGroupIceCode();

			if (getLocationSubGroupIceCode() != null)
			{
				toReturn += ".";
				toReturn += getLocationSubGroupIceCode();
			}
		}

		return toReturn;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		toReturn += "code part " + codePart;
		toReturn += " - ";
		toReturn += "part " + partLabel;
		toReturn += " - ";
		toReturn += "location " + getLocationFamilyIceCode();
		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(codePart));
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (partLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(partLabel));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (partLabelOrigin != null)
		{
			strForJavaSript.append(partLabelOrigin);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
