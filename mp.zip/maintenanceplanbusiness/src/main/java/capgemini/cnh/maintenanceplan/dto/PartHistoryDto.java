/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.Iterator;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mmartel
 *
 */
public class PartHistoryDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public PartHistoryDto() {
		super();
	}

	/** HIST_PN_CODE. **/
	private String histPnCode = null;
	/** HIST_SUBSTITUTE_PN_CODE. **/
	private String histSubstitutePnCode = null;
	/** HIST_SUPERSESSION_DATE. **/
	private String histSupersessionDate = null;
	/** HIST_SUPERSESSION_QTY. **/
	private Long histSupersessionQty = null;
	/** HIST_SUPERSESSION_TYPE. **/
	private String histSupersessionType = null;

	/**
	 * @return the histPnCode
	 */
	public String getHistPnCode() {
		return histPnCode;
	}

	/**
	 * @param histPnCode the histPnCode to set
	 */
	public void setHistPnCode(String histPnCode) {
		this.histPnCode = histPnCode;
	}

	/**
	 * @return the histSubstitutePnCode
	 */
	public String getHistSubstitutePnCode() {
		return histSubstitutePnCode;
	}

	/**
	 * @param histSubstitutePnCode the histSubstitutePnCode to set
	 */
	public void setHistSubstitutePnCode(String histSubstitutePnCode) {
		this.histSubstitutePnCode = histSubstitutePnCode;
	}

	/**
	 * @return the histSupersessionDate
	 */
	public String getHistSupersessionDate() {
		return histSupersessionDate;
	}

	/**
	 * @param histSupersessionDate the histSupersessionDate to set
	 */
	public void setHistSupersessionDate(String histSupersessionDate) {
		this.histSupersessionDate = histSupersessionDate;
	}

	/**
	 * @return the histSupersessionQty
	 */
	public Long getHistSupersessionQty() {
		return histSupersessionQty;
	}

	/**
	 * @param histSupersessionQty the histSupersessionQty to set
	 */
	public void setHistSupersessionQty(Long histSupersessionQty) {
		this.histSupersessionQty = histSupersessionQty;
	}

	/**
	 * @return the histSupersessionType
	 */
	public String getHistSupersessionType() {
		return histSupersessionType;
	}

	/**
	 * @param histSupersessionType the histSupersessionType to set
	 */
	public void setHistSupersessionType(String histSupersessionType) {
		this.histSupersessionType = histSupersessionType;
	}

	/**
	 * Return true if the PN is contained in the List as a substitute PN.
	 * 
	 * @param partList List of the part supersessions
	 * @return return true if pn contained as subtitute
	 */
	public boolean isAsSubstitute(List<PartHistoryDto> partList) {

		boolean isInList = false;
		Iterator<PartHistoryDto> iterator = partList.iterator();
		while (!isInList && iterator.hasNext())
		{
			PartHistoryDto part = iterator.next();
			if (this.histPnCode.equals(part.getHistSubstitutePnCode()))
			{
				isInList = true;
			}
		}

		return isInList;
	}

	/**
	 * Return true if the PN is contained in the List as a substitute PN.
	 * 
	 * @param partList List of the part supersessions
	 * @return return true if pn contained as subtitute
	 */
	public boolean isAsReplaced(List<PartHistoryDto> partList) {

		boolean isInList = false;
		Iterator<PartHistoryDto> iterator = partList.iterator();
		while (!isInList && iterator.hasNext())
		{
			PartHistoryDto part = iterator.next();
			if (this.histSubstitutePnCode.equals(part.getHistPnCode()))
			{
				isInList = true;
			}
		}

		return isInList;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("\"");
		strForJavaSript.append(histPnCode);
		strForJavaSript.append("\"");
		strForJavaSript.append(",");
		strForJavaSript.append("\"");
		strForJavaSript.append(histSubstitutePnCode);
		strForJavaSript.append("\"");

		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}

}
