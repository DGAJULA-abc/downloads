/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

/**
 * @author sdomecq
 *
 */
public class PlanApplicabilityDto extends ApplicabilityDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** plan Id. **/
	private Long idPlan = null;

	/**
	 * Constructor.
	 */
	public PlanApplicabilityDto() {
		super();
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}
}
