/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
/**
 * @author iazkonob
 *
 */
public class PlanCompareDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** id project. **/
	private Long idProject = null;

	/** standard. **/
	private boolean standard = false;

	/** name. **/
	private String name = null;

	/** status. **/
	private Integer status = null;
	/** status. **/
	private String statusLabel = null;

	/** status change date. **/
	private String modifDate = null;

	/** last modifier. **/
	private String lastModifier = null;

	/** condition. **/
	private ConditionDto condition = null;

	/** performance. **/
	private String performance = null;

	/** performance. **/
	private String performanceType = "harm";

	/** with data. **/
	private String withAppli = null;

	/** Interval List of the plan. **/
	private List<IntervalDto> intList = null;

	/** Model applicability. **/
	private String modelApp = null;

	/** TT applicability. **/
	private String ttApp = null;

	/** Market applicability. **/
	private Long marketApp = null;

	/** Configuration applicability. **/
	private String configApp = null;

	/**
	 * Constructor.
	 */
	public PlanCompareDto() {
		super();
	}

	/**
	 * @return
	 */
	public String getModelApp() {
		return modelApp;
	}

	/**
	 * @param modelApp
	 */
	public void setModelApp(String modelApp) {
		this.modelApp = modelApp;
	}

	/**
	 * @return
	 */
	public String getTtApp() {
		return ttApp;
	}

	/**
	 * @param ttApp
	 */
	public void setTtApp(String ttApp) {
		this.ttApp = ttApp;
	}

	/**
	 * @return
	 */
	public Long getMarketApp() {
		return marketApp;
	}

	/**
	 * @param marketApp
	 */
	public void setMarketApp(Long marketApp) {
		this.marketApp = marketApp;
	}

	/**
	 * @return
	 */
	public String getConfigApp() {
		return configApp;
	}

	/**
	 * @param configApp
	 */
	public void setConfigApp(String configApp) {
		this.configApp = configApp;
	}

	/**
	 * @return the interval list
	 */
	public List<IntervalDto> getIntList() {
		return intList;
	}

	/**
	 * @param intList the interval list to set
	 */
	public void setIntList(List<IntervalDto> intList) {
		this.intList = intList;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idProject
	 */
	public Long getIdProject() {
		return idProject;
	}

	/**
	 * @param idProject the idProject to set
	 */
	public void setIdProject(Long idProject) {
		this.idProject = idProject;
	}

	/**
	 * @return the standard
	 */
	public boolean getStandard() {
		return standard;
	}

	/**
	 * @param standard the standard to set
	 */
	public void setStandard(boolean standard) {
		this.standard = standard;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the statusLabel
	 */
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @param statusLabel the statusLabel to set
	 */
	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the lastModifier
	 */
	public String getLastModifier() {
		return lastModifier;
	}

	/**
	 * @param lastModifier the lastModifier to set
	 */
	public void setLastModifier(String lastModifier) {
		this.lastModifier = lastModifier;
	}

	/**
	 * @return the condition
	 */
	public ConditionDto getCondition() {
		return condition;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(ConditionDto condition) {
		this.condition = condition;
	}

	/**
	 * @return the performance
	 */
	public String getPerformance() {
		return performance;
	}

	/**
	 * @param performance the performance to set
	 */
	public void setPerformance(String performance) {
		this.performance = performance;
	}

	/**
	 * @return the performanceId
	 */
	public String getPerformanceType() {
		return performanceType;
	}

	/**
	 * @param performanceId the performanceId to set
	 */
	public void setPerformanceType(String performanceType) {
		this.performanceType = performanceType;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (idProject != null)
		{
			strForJavaSript.append(idProject.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		if (standard)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(name);
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (status != null)
		{
			strForJavaSript.append(status.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (statusLabel != null)
		{
			strForJavaSript.append(statusLabel);
		}
		strForJavaSript.append("'");

		if (condition != null)
		{
			strForJavaSript.append(",");
			strForJavaSript.append(condition.toJavaScript(false));
		}
		else
		{

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");
		}

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (performanceType != null)
		{
			strForJavaSript.append(performanceType);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (performance != null)
		{
			strForJavaSript.append(performance);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Long a, Long b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First String value to compare
	 * @param b Second String value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(String a, String b) {
		if ((a == null && b == null) || (a != null && b != null && a.equals(b)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(Integer a, Integer b) {
		if ((a == null && b == null) || (a != null && b != null && a.compareTo(b) == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(UsageDto a, UsageDto b) {
		if ((a == null && b == null) || (a != null && b != null && areEqual(a.getValueId(), b.getValueId())))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Returns true if both values are equal, even if both are null.
	 * 
	 * @param a First Long value to compare
	 * @param b Second Long value to compare
	 * @return true is both are equal
	 */
	private boolean areEqual(ConditionDto a, ConditionDto b) {
		if ((a == null && b == null) || (a != null && b != null && areEqual(a.getUsage(), b.getUsage())))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		PlanCompareDto other = (PlanCompareDto) obj;
		if (this.getStandard() == other.getStandard()
				&& this.getPerformanceType().equals(other.getPerformanceType())
				&& areEqual(this.getModelApp(), other.getModelApp())
				&& areEqual(this.getTtApp(), other.getTtApp())
				&& areEqual(this.getMarketApp(), other.getMarketApp())
				&& areEqual(this.getConfigApp(), other.getConfigApp())
				&& areEqual(this.getCondition(), other.getCondition()))
		{
			int diff = 0;
			List<IntervalDto> lstInter = new ArrayList<IntervalDto>(this.getIntList().size());
			List<IntervalDto> lstInter2 = new ArrayList<IntervalDto>(other.getIntList().size());

			lstInter.addAll(this.getIntList());
			lstInter2.addAll(other.getIntList());

			if (lstInter.size() >= lstInter2.size())
			{
				lstInter.removeAll(lstInter2);
				diff = lstInter.size();
			}
			else
			{
				lstInter2.removeAll(lstInter);
				diff = lstInter2.size();
			}

			if (diff == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
}
