/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.maintenanceplan.business.PlanBusiness;

/**
 * @author sdomecq
 *
 */
public class PlanDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** id project. **/
	private Long idProject = null;

	/** standard. **/
	private boolean standard = false;

	/** name. **/
	private String name = null;

	/** status. **/
	private Integer status = null;
	/** status. **/
	private String statusLabel = null;

	/** status change date. **/
	private String modifDate = null;

	/** last modifier. **/
	private String lastModifier = null;

	/** condition. **/
	private ConditionDto condition = null;

	/** performance. **/
	private String performance = null;

	/** performance. **/
	private String performanceType = "harm";

	/** with data. **/
	private String withAppli = null;

	/** External id. */
	private Long extId = null;

	/** Old External id (if any change of mission or performance has happened). */
	private Long oldExtId = null;

	/**
	 * Constructor.
	 */
	public PlanDto() {
		super();
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idProject
	 */
	public Long getIdProject() {
		return idProject;
	}

	/**
	 * @param idProject the idProject to set
	 */
	public void setIdProject(Long idProject) {
		this.idProject = idProject;
	}

	/**
	 * @return the standard
	 */
	public boolean getStandard() {
		return standard;
	}

	/**
	 * @param standard the standard to set
	 */
	public void setStandard(boolean standard) {
		this.standard = standard;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the statusLabel
	 */
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @param statusLabel the statusLabel to set
	 */
	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the lastModifier
	 */
	public String getLastModifier() {
		return lastModifier;
	}

	/**
	 * @param lastModifier the lastModifier to set
	 */
	public void setLastModifier(String lastModifier) {
		this.lastModifier = lastModifier;
	}

	/**
	 * @return the condition
	 */
	public ConditionDto getCondition() {
		return condition;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(ConditionDto condition) {
		this.condition = condition;
	}

	/**
	 * @return the performance
	 */
	public String getPerformance() {
		return performance;
	}

	/**
	 * @param performance the performance to set
	 */
	public void setPerformance(String performance) {
		this.performance = performance;
	}

	/**
	 * @return the performanceId
	 */
	public String getPerformanceType() {
		return performanceType;
	}

	/**
	 * @param performanceId the performanceId to set
	 */
	public void setPerformanceType(String performanceType) {
		this.performanceType = performanceType;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @param isCNHCustomer : true if the customer is AG&CE, false if it is CV.
	 * @return formatted string
	 */
	public String toJavaScript(boolean isCNHCustomer) {
		StringBuffer strForJavaSript = new StringBuffer();

		// Check if the plan has already been validated in a previous version of the project.
		// If it has, it cannot be put to "Deleted" status.
		List<PlanDto> validPlansPreviousVersion = new ArrayList<PlanDto>();
		List<PlanDto> draftPlansAlreadyExported = new ArrayList<PlanDto>();
		List<PlanDto> draftPlansWasValid = new ArrayList<PlanDto>();
		boolean canBeDeleted = true;
		boolean perfCanChange = true;

		if (!isCNHCustomer)
		{
			try
			{
				if (status == 1)
				{
					if (extId != null)
					{
						validPlansPreviousVersion = new PlanBusiness().getValidPlansPreviousVersion(id.toString(), extId.toString());
					}
					else if (extId == null && oldExtId != null)
					{
						validPlansPreviousVersion = new PlanBusiness().getValidPlansPreviousVersion(id.toString(), oldExtId.toString());
					}
				}
				else if (status == 0)
				{
					draftPlansAlreadyExported = new PlanBusiness().getDraftPlansAlreadyExported(id.toString(), extId);

					if (extId != null)
					{
						draftPlansWasValid = new PlanBusiness().getValidPlansPreviousVersion(id.toString(), extId.toString());
					}
				}

			}
			catch (SystemException e)
			{

			}

			if (status == 1 && !validPlansPreviousVersion.isEmpty())
			{
				canBeDeleted = false;
				perfCanChange = false;
			}

			if (status == 0 && !draftPlansWasValid.isEmpty())
			{
				canBeDeleted = false;
			}

			if (status == 0 && !draftPlansAlreadyExported.isEmpty())
			{
				perfCanChange = false;
			}
		}

		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (idProject != null)
		{
			strForJavaSript.append(idProject.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		if (standard)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(name);
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (status != null)
		{
			strForJavaSript.append(status.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (statusLabel != null)
		{
			strForJavaSript.append(statusLabel);
		}
		strForJavaSript.append("'");

		if (condition != null)
		{
			strForJavaSript.append(",");
			strForJavaSript.append(condition.toJavaScript(false));
		}
		else
		{

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");

			strForJavaSript.append(",");
			strForJavaSript.append("'");
			strForJavaSript.append("'");
		}

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (performanceType != null)
		{
			strForJavaSript.append(performanceType);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (performance != null)
		{
			strForJavaSript.append(performance);
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (withAppli != null)
		{
			strForJavaSript.append(withAppli);
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (canBeDeleted)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (perfCanChange)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append("'");
		strForJavaSript.append("]");

		return strForJavaSript.toString();

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId.
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		PlanDto other = (PlanDto) obj;
		if (id == null)
		{
			if (other.id != null)
			{
				return false;
			}
		}
		else if (!name.equals(other.name) ||
				!status.equals(other.status) ||
				standard != other.standard ||
				(performance != null ? !performance.equals(other.performance) : other.performance != null))
		{
			return false;
		}
		return true;
	}

	/**
	 * Return the ext id.
	 * 
	 * @return the external id
	 */
	public Long getExtId() {
		return extId;
	}

	/**
	 * Sets the external id.
	 * 
	 * @param extId the external id to set
	 */
	public void setExtId(Long extId) {
		this.extId = extId;
	}

	/**
	 * Return the old external id.
	 * 
	 * @return the old external id
	 */
	public Long getOldExtId() {
		return oldExtId;
	}

	/**
	 * Get the old external id.
	 * 
	 * @param oldExtId
	 */
	public void setOldExtId(Long oldExtId) {
		this.oldExtId = oldExtId;
	}
}
