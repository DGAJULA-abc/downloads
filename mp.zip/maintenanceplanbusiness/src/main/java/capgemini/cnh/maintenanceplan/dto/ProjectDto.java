/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class ProjectDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public ProjectDto() {
		super();
	}

	/** Id. **/
	private Long id = null;

	/** title. **/
	private String name = null;

	/** status. **/
	private Integer status = null;
	/** status. **/
	private String statusLabel = null;

	/** status change date. **/
	private String modifDate = null;

	/** status change date. **/
	private String modifDateWithHour = null;

	/** status creation date. **/
	private String creationDate = null;

	/** last modifier. **/
	private String lastModifierId = null;

	/** last modifier. **/
	private String lastModifierName = null;

	/** version. **/
	private Integer version = null;

	/** comment. **/
	private String comment = null;

	/** number. **/
	private String number = null;

	/** appli id. **/
	private Long applicabilityId = null;
	/** brand ice code. **/
	private String applicabilityBrandIceCode = null;
	/** type ice code. **/
	private String applicabilityTypeIceCode = null;
	/** product ice code. **/
	private String applicabilityProductIceCode = null;
	/** series ice code. **/
	private String applicabilitySeriesIceCode = null;
	/** series id. **/
	private Long applicabilitySeriesId = null;
	/** applicability label. **/
	private String applicabilityLabel = null;

	/** Timesheet. **/
	private Long timesheet = null;

	/** Timesheet column. **/
	private String timesheetColumn = null;

	/** personalized. **/
	private boolean personalized = false;

	/** Has Contract. **/
	private boolean hasContract = false;

	/**
	 * Release type:
	 * 0 --> Select a release type
	 * 1 --> Full export
	 * 2 --> Send only standard oils
	 */
	private Long releaseType = null;

	/**
	 * true if the project is for UCR. false otherwise.
	 */
	private boolean isUcr = false;

	/**
	 * Last report generated for check consistency.
	 */
	private String lastReport = null;

	/** Repair Time. **/
	private Long repairTime = null;

	/** PlanDto. **/
	private PlanDto plan = null;

	/** OperationDto. **/
	private IntervalOperationDto operation = null;

	/** Is Selected. **/
	private boolean selected = false;

	/**
	 * @return the timesheet
	 */
	public Long getTimesheet() {
		return timesheet;
	}

	/**
	 * @param timesheet the timesheet to set
	 */
	public void setTimesheet(Long timesheet) {
		this.timesheet = timesheet;
	}

	/**
	 * @return the timesheetColumn
	 */
	public String getTimesheetColumn() {
		return timesheetColumn;
	}

	/**
	 * @param timesheetColumn the timesheetColumn to set
	 */
	public void setTimesheetColumn(String timesheetColumn) {
		this.timesheetColumn = timesheetColumn;
	}

	/**
	 * @return the applicabilityBrandIceCode
	 */
	public String getApplicabilityBrandIceCode() {
		return applicabilityBrandIceCode;
	}

	/**
	 * @param applicabilityBrandIceCode the applicabilityBrandIceCode to set
	 */
	public void setApplicabilityBrandIceCode(String applicabilityBrandIceCode) {
		this.applicabilityBrandIceCode = applicabilityBrandIceCode;
	}

	/**
	 * @return the applicabilityTypeIceCode
	 */
	public String getApplicabilityTypeIceCode() {
		return applicabilityTypeIceCode;
	}

	/**
	 * @param applicabilityTypeIceCode the applicabilityTypeIceCode to set
	 */
	public void setApplicabilityTypeIceCode(String applicabilityTypeIceCode) {
		this.applicabilityTypeIceCode = applicabilityTypeIceCode;
	}

	/**
	 * @return the applicabilityProductIceCode
	 */
	public String getApplicabilityProductIceCode() {
		return applicabilityProductIceCode;
	}

	/**
	 * @param applicabilityProductIceCode the applicabilityProductIceCode to set
	 */
	public void setApplicabilityProductIceCode(String applicabilityProductIceCode) {
		this.applicabilityProductIceCode = applicabilityProductIceCode;
	}

	/**
	 * @return the applicabilitySeriesIceCode
	 */
	public String getApplicabilitySeriesIceCode() {
		return applicabilitySeriesIceCode;
	}

	/**
	 * @param applicabilitySeriesIceCode the applicabilitySeriesIceCode to set
	 */
	public void setApplicabilitySeriesIceCode(String applicabilitySeriesIceCode) {
		this.applicabilitySeriesIceCode = applicabilitySeriesIceCode;
	}

	/**
	 * @return the applicabilitySeriesId
	 */
	public Long getApplicabilitySeriesId() {
		return applicabilitySeriesId;
	}

	/**
	 * @param applicabilitySeriesId the applicabilitySeriesId to set
	 */
	public void setApplicabilitySeriesId(Long applicabilitySeriesId) {
		this.applicabilitySeriesId = applicabilitySeriesId;
	}

	/**
	 * @return the applicabilityLabel
	 */
	public String getApplicabilityLabel() {
		return applicabilityLabel;
	}

	/**
	 * @param applicabilityLabel the applicabilityLabel to set
	 */
	public void setApplicabilityLabel(String applicabilityLabel) {
		this.applicabilityLabel = applicabilityLabel;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the modifDateWithHour
	 */
	public String getModifDateWithHour() {
		return modifDateWithHour;
	}

	/**
	 * @param modifDateWithHour the modifDateWithHour to set.
	 */
	public void setModifDateWithHour(String modifDateWithHour) {
		this.modifDateWithHour = modifDateWithHour;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the creationDate
	 */
	public String getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the statusLabel
	 */
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @param statusLabel the statusLabel to set
	 */
	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * @return the lastModifierId
	 */
	public String getLastModifierId() {
		return lastModifierId;
	}

	/**
	 * @param lastModifierId the lastModifierId to set
	 */
	public void setLastModifierId(String lastModifierId) {
		this.lastModifierId = lastModifierId;
	}

	/**
	 * @return the lastModifierName
	 */
	public String getLastModifierName() {
		return lastModifierName;
	}

	/**
	 * @param lastModifierName the lastModifierName to set
	 */
	public void setLastModifierName(String lastModifierName) {
		this.lastModifierName = lastModifierName;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the applicabilityId
	 */
	public Long getApplicabilityId() {
		return applicabilityId;
	}

	/**
	 * @param applicabilityId the applicabilityId to set
	 */
	public void setApplicabilityId(Long applicabilityId) {
		this.applicabilityId = applicabilityId;
	}

	/**
	 * @return the personalized
	 */
	public boolean getPersonalized() {
		return personalized;
	}

	/**
	 * @param personalized the personalized to set
	 */
	public void setPersonalized(boolean personalized) {
		this.personalized = personalized;
	}

	/**
	 * 
	 * @return true if the project has or can have a contract
	 */
	public boolean hasContract() {
		return hasContract;
	}

	/**
	 * 
	 * @param hasContract
	 */
	public void setHasContract(boolean hasContract) {
		this.hasContract = hasContract;
	}

	/**
	 * 
	 * @return Release type:
	 *         0 --> Select a release type
	 *         1 --> Full export
	 *         2 --> Send only standard oils
	 */
	public Long getReleaseType() {
		return releaseType;
	}

	/**
	 * 
	 * @param releaseType
	 *            0 --> Select a release type
	 *            1 --> Full export
	 *            2 --> Send only standard oils
	 */
	public void setReleaseType(Long releaseType) {
		this.releaseType = releaseType;
	}

	/**
	 * 
	 * @return true if the project is for UCR.
	 */
	public boolean isUcr() {
		return isUcr;
	}

	/**
	 * 
	 * @param isUcr
	 */
	public void setUcr(boolean isUcr) {
		this.isUcr = isUcr;
	}

	/**
	 * @return the lastReport
	 */
	public String getLastReport() {
		return lastReport;
	}

	/**
	 * @param lastReport the lastReport to set
	 */
	public void setLastReport(String lastReport) {
		this.lastReport = lastReport;
	}

	public Long getRepairTime() {
		return repairTime;
	}

	public void setRepairTime(Long repairTime) {
		this.repairTime = repairTime;
	}

	/**
	 * @return the plan
	 */
	public PlanDto getPlan() {
		return plan;
	}

	/**
	 * @param plan the plan to set
	 */
	public void setPlan(PlanDto plan) {
		this.plan = plan;
	}

	/**
	 * @return the operation
	 */
	public IntervalOperationDto getOperation() {
		return operation;
	}

	/**
	 * @param operation the operation to set
	 */
	public void setOperation(IntervalOperationDto operation) {
		this.operation = operation;
	}

	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}

	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	/**
	 * @return the applicability full ice code
	 */
	public String getSeriesFullIceCode() {
		String toReturn = getApplicabilityBrandIceCode();
		toReturn += ".";
		toReturn += getApplicabilityTypeIceCode();
		toReturn += ".";
		toReturn += getApplicabilityProductIceCode();
		toReturn += ".";
		toReturn += getApplicabilitySeriesIceCode();

		return toReturn;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		if (id != null)
		{
			strForJavaSript.append(id.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (number != null)
		{
			strForJavaSript.append(number.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(name));
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (version != null)
		{
			strForJavaSript.append(version.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (lastModifierName != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(lastModifierName.toString()));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (modifDate != null)
		{
			strForJavaSript.append(modifDate.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (status != null)
		{
			strForJavaSript.append(status.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (statusLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(statusLabel.toString()));
		}
		strForJavaSript.append("'");

		strForJavaSript.append(",");

		if (selected)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}

		strForJavaSript.append(",");

		if (personalized)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}

		strForJavaSript.append(",");

		if (isUcr)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}

		strForJavaSript.append(",");

		if (hasContract)
		{
			strForJavaSript.append("true");
		}
		else
		{
			strForJavaSript.append("false");
		}
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (releaseType != null)
		{
			strForJavaSript.append(releaseType.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");

		strForJavaSript.append(lastReport == null ? false : true);
		strForJavaSript.append(",");

		strForJavaSript.append("'");
		if (applicabilityId != null)
		{
			strForJavaSript.append(applicabilityId.toString());
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (applicabilityLabel != null)
		{
			strForJavaSript.append(StringEscapeUtils.escapeJavaScript(applicabilityLabel));
		}
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(getSeriesFullIceCode());
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (applicabilitySeriesId != null)
		{
			strForJavaSript.append(applicabilitySeriesId);
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();

	}
}