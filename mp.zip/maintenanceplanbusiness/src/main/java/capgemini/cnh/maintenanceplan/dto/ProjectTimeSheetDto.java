/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class ProjectTimeSheetDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public ProjectTimeSheetDto() {
		super();
	}

	/** id Applicability. **/
	private Long idApplicability = null;
	/** timesheet. **/
	private String timesheet = null;
	/** column. **/
	private Long column = null;

	/**
	 * @return the idApplicability
	 */
	public Long getIdApplicability() {
		return idApplicability;
	}

	/**
	 * @param idApplicability the idApplicability to set
	 */
	public void setIdApplicability(Long idApplicability) {
		this.idApplicability = idApplicability;
	}

	/**
	 * @return the timesheet
	 */
	public String getTimesheet() {
		return timesheet;
	}

	/**
	 * @param timesheet the timesheet to set
	 */
	public void setTimesheet(String timesheet) {
		this.timesheet = timesheet;
	}

	/**
	 * @return the column
	 */
	public Long getColumn() {
		return column;
	}

	/**
	 * @param column the column to set
	 */
	public void setColumn(Long column) {
		this.column = column;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		strForJavaSript.append(timesheet);
		strForJavaSript.append("'");

		strForJavaSript.append(",");
		strForJavaSript.append("'");
		if (column != null)
		{
			strForJavaSript.append(column.toString());
		}
		strForJavaSript.append("'");

		strForJavaSript.append("]");

		return strForJavaSript.toString();

	}

}
