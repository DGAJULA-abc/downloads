package capgemini.cnh.maintenanceplan.dto;

/**
 * Dto class for the standard oil applicability.
 * 
 * @author mdaudign
 */
public class StandardOilApplicabilityDto extends ApplicabilityDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** plan Id. **/
	private Long idStdOil = null;

	/**
	 * Constructor.
	 */
	public StandardOilApplicabilityDto() {
		super();
	}

	/**
	 * Constructor by copy.
	 * 
	 * @param oldDto the object to copy
	 */
	public StandardOilApplicabilityDto(StandardOilApplicabilityDto oldDto) {
		super();
		this.setId(oldDto.getId());
		idStdOil = oldDto.getIdStdOil();
		this.setModel(oldDto.getModel());
		this.setTt(oldDto.getTt());
		this.setMarket(oldDto.getMarket());
		this.setConfig(oldDto.getConfig());
	}

	/**
	 * Get the standard oil id.
	 * 
	 * @return the standard oil id
	 */
	public Long getIdStdOil() {
		return idStdOil;
	}

	/**
	 * Set the standard oil id.
	 * 
	 * @param idStdOil the standard oil id to set
	 */
	public void setIdStdOil(Long idStdOil) {
		this.idStdOil = idStdOil;
	}
}
