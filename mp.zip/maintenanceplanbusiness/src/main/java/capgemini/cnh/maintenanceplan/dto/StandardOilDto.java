package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for the standard oils.
 * 
 * @author mdaudign
 */
public class StandardOilDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Standard Oil id.
	 */
	private Long oilStdId = null;

	/**
	 * Project id.
	 */
	private Integer projectId = null;

	/**
	 * Oil id.
	 */
	private Long oilId = null;

	/**
	 * Constructor.
	 */
	public StandardOilDto() {
		super();
	}

	/**
	 * Constructor by copy.
	 * 
	 * @param oldDto the object to copy
	 */
	public StandardOilDto(StandardOilDto oldDto) {
		super();
		oilStdId = oldDto.getOilStdId();
		projectId = oldDto.getProjectId();
		oilId = oldDto.getOilId();
	}

	/**
	 * Get the standard oil id.
	 * 
	 * @return the standard oil id
	 */
	public Long getOilStdId() {
		return oilStdId;
	}

	/**
	 * Set the standard oil id.
	 * 
	 * @param oilStdId the standard oil id to set
	 */
	public void setOilStdId(Long oilStdId) {
		this.oilStdId = oilStdId;
	}

	/**
	 * Get the project id.
	 * 
	 * @return the project id
	 */
	public Integer getProjectId() {
		return projectId;
	}

	/**
	 * Set the project id.
	 * 
	 * @param projectId the project id to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	/**
	 * Get the oil id.
	 * 
	 * @return the oil id
	 */
	public Long getOilId() {
		return oilId;
	}

	/**
	 * Set the oil id.
	 * 
	 * @param oilId the oil id to set
	 */
	public void setOilId(Long oilId) {
		this.oilId = oilId;
	}
}
