/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author langlade
 *
 */
public class UnitSeriesDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** brand ice code. **/
	private String brandIceCode = null;
	/** type ice code. **/
	private String typeIceCode = null;
	/** product ice code. **/
	private String productIceCode = null;
	/** series ice code. **/
	private String seriesIceCode = null;
	/** unit. **/
	private String unit = null;
	/** unit key. **/
	private String unitKey = null;

	/**
	 * Constructor.
	 */
	public UnitSeriesDto() {
		super();
	}

	/**
	 * @return the brandIceCode
	 */
	public String getBrandIceCode() {
		return brandIceCode;
	}

	/**
	 * @param brandIceCode the brandIceCode to set
	 */
	public void setBrandIceCode(String brandIceCode) {
		this.brandIceCode = brandIceCode;
	}

	/**
	 * @return the typeIceCode
	 */
	public String getTypeIceCode() {
		return typeIceCode;
	}

	/**
	 * @param typeIceCode the typeIceCode to set
	 */
	public void setTypeIceCode(String typeIceCode) {
		this.typeIceCode = typeIceCode;
	}

	/**
	 * @return the productIceCode
	 */
	public String getProductIceCode() {
		return productIceCode;
	}

	/**
	 * @param productIceCode the productIceCode to set
	 */
	public void setProductIceCode(String productIceCode) {
		this.productIceCode = productIceCode;
	}

	/**
	 * @return the seriesIceCode
	 */
	public String getSeriesIceCode() {
		return seriesIceCode;
	}

	/**
	 * @param seriesIceCode the seriesIceCode to set
	 */
	public void setSeriesIceCode(String seriesIceCode) {
		this.seriesIceCode = seriesIceCode;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * @return the unitKey
	 */
	public String getUnitKey() {
		return unitKey;
	}

	/**
	 * @param unitKey the unitKey to set
	 */
	public void setUnitKey(String unitKey) {
		this.unitKey = unitKey;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = String.join(".", brandIceCode, typeIceCode, productIceCode, seriesIceCode);

		toReturn += " - specific unit : " + unit;

		return toReturn;
	}
}
