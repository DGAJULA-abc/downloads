/**
 * 
 */
package capgemini.cnh.maintenanceplan.dto;

import org.apache.commons.lang.StringEscapeUtils;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class UsageDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public UsageDto() {
		super();
	}

	/** Id. **/
	private Long valueId = null;
	/** title. **/
	private String valueTitle = null;
	/** title Id. **/
	private Long valueTitleId = null;

	/** Id. **/
	private Long itemId = null;
	/** title. **/
	private String itemTitle = null;
	/** title Id. **/
	private Long itemTitleId = null;

	/**
	 * @return the valueId
	 */
	public Long getValueId() {
		return valueId;
	}

	/**
	 * @param valueId the valueId to set
	 */
	public void setValueId(Long valueId) {
		this.valueId = valueId;
	}

	/**
	 * @return the valueTitle
	 */
	public String getValueTitle() {
		return valueTitle;
	}

	/**
	 * @param valueTitle the valueTitle to set
	 */
	public void setValueTitle(String valueTitle) {
		this.valueTitle = valueTitle;
	}

	/**
	 * @return the valueTitleId
	 */
	public Long getValueTitleId() {
		return valueTitleId;
	}

	/**
	 * @param valueTitleId the valueTitleId to set
	 */
	public void setValueTitleId(Long valueTitleId) {
		this.valueTitleId = valueTitleId;
	}

	/**
	 * @return the itemId
	 */
	public Long getItemId() {
		return itemId;
	}

	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	/**
	 * @return the itemTitle
	 */
	public String getItemTitle() {
		return itemTitle;
	}

	/**
	 * @param itemTitle the itemTitle to set
	 */
	public void setItemTitle(String itemTitle) {
		this.itemTitle = itemTitle;
	}

	/**
	 * @return the itemTitleId
	 */
	public Long getItemTitleId() {
		return itemTitleId;
	}

	/**
	 * @param itemTitleId the itemTitleId to set
	 */
	public void setItemTitleId(Long itemTitleId) {
		this.itemTitleId = itemTitleId;
	}

	/**
	 * Get dto formatted for java script.
	 * 
	 * @return formatted string
	 */
	public String toJavaScript() {
		StringBuffer strForJavaSript = new StringBuffer();
		strForJavaSript.append("[");
		strForJavaSript.append("'");
		strForJavaSript.append(valueId);
		strForJavaSript.append("'");
		strForJavaSript.append(",");
		strForJavaSript.append("'");
		strForJavaSript.append(StringEscapeUtils.escapeJavaScript(itemTitle + " - " + valueTitle));
		strForJavaSript.append("'");
		strForJavaSript.append("]");

		return strForJavaSript.toString();
	}
}
