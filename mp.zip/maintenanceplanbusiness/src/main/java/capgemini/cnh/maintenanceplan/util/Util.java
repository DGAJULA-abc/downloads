package capgemini.cnh.maintenanceplan.util;

import java.sql.Date;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;

/**
 * Utilitary class.
 * 
 */
public class Util {

	/**
	 * Constructor.
	 */
	private Util() {
	}

	/**
	 * Getting in a format used with Oracle database.
	 * 
	 * @return date string
	 */
	public static String getDate() {
		// format the system date for the update
		Calendar l_currentDate = Calendar.getInstance();
		l_currentDate.setTimeInMillis(System.currentTimeMillis());
		String closeDate = l_currentDate.get(Calendar.DAY_OF_MONTH) + "/" + (l_currentDate.get(Calendar.MONTH) + 1) + "/"
				+ l_currentDate.get(Calendar.YEAR);
		return closeDate;
	}

	/**
	 * Build the date as dd mm yy [hh:mm:ss].
	 * 
	 * @param withHour : add the hous to the date
	 * @return the date formatted as dd mm yy [hh:mm:ss]
	 */
	public static String getNowDate(boolean withHour) {
		NumberFormat formatter = new DecimalFormat("00");
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());
		String day = String.valueOf(formatter.format(currentDate.get(Calendar.DAY_OF_MONTH)));
		String month = String.valueOf(formatter.format(currentDate.get(Calendar.MONTH) + 1));
		String year = String.valueOf(currentDate.get(Calendar.YEAR));
		String hour = String.valueOf(formatter.format(currentDate.get(Calendar.HOUR_OF_DAY)));
		String minute = String.valueOf(formatter.format(currentDate.get(Calendar.MINUTE)));
		String second = String.valueOf(formatter.format(currentDate.get(Calendar.SECOND)));
		String now = day + "/" + month + "/" + year;
		if (withHour)
		{
			now = now + " " + hour + ":" + minute + ":" + second;
		}
		return now;
	}

	/**
	 * Build the year as yy .
	 * 
	 * @return the year formatted as yy
	 */
	public static String getNowYearYY() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		return String.valueOf(currentDate.get(Calendar.YEAR)).substring(2, 4);
	}

	/**
	 * Build the year as yyyy .
	 * 
	 * @return the year formatted as yyyy
	 */
	public static String getNowYearYYYY() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		return String.valueOf(currentDate.get(Calendar.YEAR));
	}

	/**
	 * Get current date.
	 * 
	 * @param myDate to format
	 * @return format dd/mm/yyyy
	 */
	public static String dateToString(Date myDate) {
		String result = null;
		if (myDate != null)
		{
			Calendar currentDate = Calendar.getInstance();
			currentDate.setTimeInMillis(myDate.getTime());

			NumberFormat formatter2 = new DecimalFormat("00");
			NumberFormat formatter4 = new DecimalFormat("0000");
			result = formatter2.format(currentDate.get(Calendar.DAY_OF_MONTH)) + "/" + formatter2.format((currentDate.get(Calendar.MONTH) + 1)) + "/"
					+ formatter4.format(currentDate.get(Calendar.YEAR));
		}

		return result;
	}

}
