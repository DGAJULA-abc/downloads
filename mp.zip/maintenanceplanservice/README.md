
# maintenanceplanservice

## 🔹 About The Project

Describe in a few lines what this software package cert does. If it is an application, add a screenshot and a description of users and use cases. If it's a library or other, the screenshot is not mandatory but an explanation of what is offered and which projects use it.

**Repository type:** 📟 Application or ⚙️ Library or 📂 Other

**Entity:** 📕 CNHI or 📘 Iveco

<div style="text-align:center">
    <img src="screenshot.png"/>
</div>

**Contact points**

- **Techlead:** someone@capgemini.com
- **Testing lead**: someone-else@capgemini.com

## 🔹 Built With

This section should list any major frameworks/libraries used to bootstrap your project. Leave any add-ons/plugins for the acknowledgements section. Here are a few examples.

![Angular](https://img.shields.io/static/v1?label=Angular&message=8&color=greeen&logo=angular)
![Java](https://img.shields.io/static/v1?label=Java&message=11&color=greeen&logo=openjdk)
![Spring Boot](https://img.shields.io/static/v1?label=SpringBoot&message=2.4&color=greeen&logo=spring)
![Maven](https://img.shields.io/static/v1?label=Maven&message=3&color=greeen&logo=apachemaven)
![Git](https://img.shields.io/static/v1?label=Git&message=SCM&color=greeen&logo=git)

## 🔹 Getting Started

This is an example of how you may give instructions on setting up your project locally. To get a local copy up and running follow these simple example steps.

### Prerequisites

This is an example of how to list things you need to use the software and how to install them.

- NPM

  `npm install npm@latest -g`

### Installation
Below is an example of how you can instruct your audience on installing and setting up your app. This template doesn't rely on any external dependencies or services.

1. Get a free API Key at https://example.com
2. Clone the repo

    `git clone https://github.com/your_username/Project-Name.git`

3. Install NPM packages

    `npm install`

4. Enter your API in `config.js`

```js
const API_KEY = 'ENTER YOUR API';
```

## 🔹 Branch Management

The project is oriented towards a **branch-based** approach: *before developing a feature, the developer checks out a “feature” branch and makes all the code changes there. The developer creates a merge request with the main branch when the development on the feature is complete. There might be a code review before merging the feature branch into the main branch. Most importantly, developers never push code changes directly to the main branch in the feature-based workflow.*

or

The project is oriented towards a **trunk-based** approach: *developer can directly push changes to the main branch, but if a coding activity requires more extensive time — perhaps a few days — they can check out a branch from main, move the changes into it, then merge it back in when development is complete.*

This is how branches are used on the project:

| Branch     | Usage |
|------------|-------|
| main       | This is a highly stable branch that is always production-ready and contains the last release version of source code in production. |
| release    | Used to integrate features for a release. This branch is typically deployed in staging environnement for validation. |
| develop    | Serves as a branch for integrating different features planned for an upcoming release. |
| feature/*  | Short-lived branch used to develop a feature. |

## 🔹 Continuous Integration & Delivery

This project is under CI/CD using Jenkins for the Production Line.

+ [TODO Link to Jenkins](https://cnhi-tidb-pl.pl.s2-eu.capgemini.com/?permlink=https://cnhi-tidb-pl.pl.s2-eu.capgemini.com/jenkins/)

## 🔹 Task management

+ TODO Link to JIRA / Azure Devops

## 🔹 Licence

Copyright Capgemini - All rights reserved
