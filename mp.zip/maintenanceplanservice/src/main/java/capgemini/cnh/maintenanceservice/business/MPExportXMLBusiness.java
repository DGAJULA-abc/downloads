package capgemini.cnh.maintenanceservice.business;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.jdom.Element;

import com.fasterxml.jackson.core.JsonProcessingException;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceservice.dto.MPExportXMLDto;
import capgemini.cnh.maintenanceservice.dto.MpFrequencyDto;
import capgemini.cnh.maintenanceservice.service.MaintenanceService;
import capgemini.cnh.maintenanceservice.util.Constantes;
import capgemini.cnh.maintenanceservice.util.MaintenanceUtil;
import capgemini.cnh.maintenanceservice.util.UnitsUtil;
import capgemini.cnh.maintenanceservice.util.UtilDate;
import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.business.MpKitCompositionBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationConsumableBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationPartBusiness;
import capgemini.cnh.mpbusiness.business.MpSapSerialNumber17Business;
import capgemini.cnh.mpbusiness.business.MpSupersessionBusiness;
import capgemini.cnh.mpbusiness.business.MpUsageBusiness;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpKitCompositionDto;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;
import capgemini.cnh.mpbusiness.dto.MpOperationDto;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;
import capgemini.cnh.mpbusiness.dto.MpPartNodeDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpSapSerialNumber17Dto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.MpIntervalStatusEnum;
import capgemini.cnh.ticd.component.business.ConsumableBusiness;
import capgemini.cnh.ticd.component.business.TableTitleBusiness;
import capgemini.cnh.ticd.component.dto.ConsumableDto;
import capgemini.cnh.ticd.component.dto.TableTitleDto;

/**
 * @author thlarzab
 *
 */
public class MPExportXMLBusiness {

	/**
	 * 
	 */
	private static final String QUOTATION = "Quotation";

	/** The logger. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MPExportXMLBusiness.class);

	private static final String DMS_EXPORT = "DMSExport";

	private static final String HEADER = "Header";

	private static final String CONTEXT = "Context";

	private static final String SOURCE = "Source";

	private static final String CREATION_TIME = "Creation_time";

	private static final String ENGINE_VERSION = "Engine_version";

	private static final String USER_ID = "User_id";

	private static final String ACTIVITY = "Activity";

	private static final String VEHICLE_DETAILS = "Vehicle_details";

	private static final String VIN = "VIN";

	private static final String SERIES = "Series";

	private static final String MODEL = "Model";

	private static final String MILEAGE = "Mileage";

	private static final String HOURS = "Hours";

	private static final String USAGE = "Usage";

	private static final String USAGE_ID = "Usage_id";

	private static final String CONFIGURATION = "Configuration";

	private static final String START_WARRANTY_DATE = "Start_Warranty_date";

	private static final String CLAIMS = "Claims";

	public static final String CLAIM = "Claim";

	private static final String CODE = "code";

	private static final String TYPE = "type";

	private static final String FREQUENCY_LOWER = "frequency";

	private static final String FREQUENCY_UPPER = "Frequency";

	private static final String REPAIR_TIME = "Repair_Time";

	private static final String FAILURE_CODE = "Failure_code";

	private static final String MPOPERATION = "MPOperation";

	private static final String MICRO = "Micro";

	private static final String SRT = "SRT";

	private static final String PART = "Part";

	private static final String PART_FATHER = "PartFather";

	private static final String PART_CHILD = "PartChild";

	private static final String PN = "PN";

	private static final String QUANTITY = "quantity";

	private static final String PREFERRED = "preferred";

	private static final String CONSUMABLE = "Consumable";

	private static final String ID = "id";

	private static final String UNIT = "unit";

	private static final String ADDITIONAL_INFOS = "Additional_infos";

	private static final String OPERATION_LIST = "Operation_list";

	private static final String OPERATION = "Operation";

	private static final String LABEL = "Label";

	private static final String LANGUAGE = "language";

	private static final String VALUE = "value";

	private static final String DESCRIPTION = "Description";

	private static final String PART_LIST = "Part_list";

	private static final String CONSUMABLE_LIST = "Consumable_list";

	private static final String FREQUENCY_LIST = "Frequency_list";

	private static final String ID_FREQUENCY = "Id";

	private static final String COMMENT = "Comment";

	private static final String KIT_LIST = "Kit_list";

	private static final String KIT = "Kit";

	private static final String KITPN = "KitPN";

	private static final String SESSION = "Session";

	private static final String DATE_FORMAT = "dd-MM-yyyy";

	private static final String BM_ICE_CODE = "BM_Icecode";

	private static final String PLAN = "Plan";

	private static final String EXTERNAL_PLAN_ID = "external_plan_id";

	private static final String PROJECT_NUMBER = "project_number";

	private static final String VERSION = "version";

	private static final String GROUP_NUMBER = "group_number";

	private static final String CONTRACT_NUMBER = "contract_number";

	private static final String WARRANTY_TYPE = "warranty_type";

	private static final String HISTORY = "History";

	private static final String COUPON_HISTORY = "Coupon_History";

	private static final String SAP_CLAIM = "sap_claim";

	private static final String DATE = "date";

	private static final String EXACT_MILEAGE = "exact_mileage";

	private static final String EXACT_HOURS = "exact_hours";

	private static final String EXACT_DATE = "exact_date";

	private static final String FAILURE_DATE = "failure_date";

	private static final String COUPON = "coupon";

	private static final String SELECTION = "selection";

	private static final String SUPERSESSION = "supersession";

	private static final String STATUS = "status";

	private static final String AT_MONTH = "at_month";

	private static final String AT_HOURS = "at_hours";

	private static final String AT_KM = "at_km";

	private static final String EVERY_MONTH = "every_month";

	private static final String EVERY_HOURS = "every_hours";

	private static final String EVERY_KM = "every_km";

	private static final String MP = "MP";

	private static final String EN = "EN";

	private static final String IT = "IT";

	private static final String ES = "ES";

	private static final String FR = "FR";

	private static final String DE = "DE";

	private static final String DELTA_KM = "delta_km";

	private static final String DELTA_HOURS = "delta_hours";

	private static final String DELTA_MONTH = "delta_month";

	private static final String USAGE_LIST = "Usage_list";

	private static final String ORIGIN = "origin";

	private static final String EMPTY_STRING = "";

	private static final String OPER_CODE = "Oper_code";

	private static final String STRONG_ID = "Strong_id";

	private static final String EXPORT = "Export";

	private static final String XML_HEADER = "<(.+?)>";

	private static final String GROUP = "group";

	private static final String IS_HIDDEN = "is_hidden";

	/** Creates. */
	public MPExportXMLBusiness() {
	}

	/**
	 * @param writer : writer
	 * @param mpExportDto : mpExport Dto
	 * @throws XMLStreamException
	 */
	private void generateSapHeader(XMLStreamWriter writer, MPExportXMLDto mpExportDto, boolean isIveco) throws XMLStreamException {

		MpPlanDto planSelected = mpExportDto.getPlan();
		writer.writeStartElement(HEADER);
		/**
		 * <Context> SAP
		 */
		writer.writeStartElement(CONTEXT);
		writer.writeAttribute(SOURCE, MP);
		writer.writeAttribute(CREATION_TIME, UtilDate.getGMTDate("yyyyMMddHHmmss"));
		writer.writeAttribute(ENGINE_VERSION, mpExportDto.getSoftwareVersion());
		writer.writeAttribute(USER_ID, mpExportDto.getUserID());
		writer.writeAttribute(ACTIVITY, EXPORT);
		writer.writeEndElement();
		/**
		 * <Vehicle_details> SAP
		 */
		writer.writeStartElement(VEHICLE_DETAILS);
		writer.writeAttribute(BM_ICE_CODE,
				mpExportDto.getBmIceCode() != null ? mpExportDto.getBmIceCode() : EMPTY_STRING);
		writer.writeAttribute(MILEAGE,
				mpExportDto.getActualMileage() != null ? mpExportDto.getActualMileage() : EMPTY_STRING);
		if (mpExportDto.getActualHour() != null)
		{
			writer.writeAttribute(HOURS, mpExportDto.getActualHour());
		}
		if (planSelected != null && planSelected.getCondition() != null && planSelected.getCondition().getUsage() != null && planSelected.getCondition().getUsage() != null
				&& (MpUsageDto.DEFAULT_VALUE_ID != planSelected.getCondition().getUsage().getValueId()))
		{
			writer.writeAttribute(USAGE_ID, String.valueOf(planSelected.getCondition().getUsage().getValueId()));
		}
		writer.writeAttribute(START_WARRANTY_DATE, mpExportDto.getWarrantyDate() != null
				? (new SimpleDateFormat(DATE_FORMAT).format(new Date(Long.parseLong(mpExportDto.getWarrantyDate()))))
				: EMPTY_STRING);
		writer.writeEndElement();
		writer.flush();
		/**
		 * <Plan> SAP
		 */

		writer.writeStartElement(PLAN);
		writer.writeAttribute(EXTERNAL_PLAN_ID, mpExportDto.getExtPlanId() != null ? mpExportDto.getExtPlanId().toString() : EMPTY_STRING);
		if (planSelected != null && planSelected.getProjectNumber() != null)
		{
			writer.writeAttribute(PROJECT_NUMBER, planSelected.getProjectNumber());
		}
		else
		{
			writer.writeAttribute(PROJECT_NUMBER, EMPTY_STRING);
		}
		if (planSelected != null && planSelected.getProjectVersion() != null)
		{
			writer.writeAttribute(VERSION, planSelected.getProjectVersion().toString());
		}
		else
		{
			writer.writeAttribute(VERSION, EMPTY_STRING);
		}
		if (mpExportDto.getContractGroup() != null && !mpExportDto.getContractGroup().equals(""))
		{
			writer.writeAttribute(GROUP_NUMBER, mpExportDto.getContractGroup());
		}

		if (isIveco && mpExportDto.getContractNb() != null && !mpExportDto.getContractNb().equals("")
				|| (!isIveco && mpExportDto.getWarrantyType() != null && !mpExportDto.getWarrantyType().equals(Constants.STANDARD_CONTRACT)))
		{

			writer.writeAttribute(CONTRACT_NUMBER, mpExportDto.getContractNb());
		}

		if (!isIveco && mpExportDto.getWarrantyType() != null && !mpExportDto.getWarrantyType().equals(""))
		{
			writer.writeAttribute(WARRANTY_TYPE, mpExportDto.getWarrantyType());
		}
		writer.writeEndElement();

		writer.writeEndElement();

	}

	/**
	 * @param writer
	 * @param mpExportDto
	 * @throws XMLStreamException
	 */
	private void generateSapHistory(XMLStreamWriter writer, MPExportXMLDto mpExportDto) throws XMLStreamException {
		writer.writeStartElement(HISTORY);
		for (MpHistoryIntervalDto couponHistoryDto : mpExportDto.getHistoryList())
		{
			writer.writeStartElement(COUPON_HISTORY);
			writer.writeAttribute(SAP_CLAIM, couponHistoryDto.getIsSapOrigin().toString());
			writer.writeAttribute(COUPON, couponHistoryDto.getIntervalCode());
			writer.writeAttribute(MILEAGE, couponHistoryDto.getIntValue(MpType.MP_KM) != null ? couponHistoryDto.getIntValue(MpType.MP_KM).toString() : "0");
			writer.writeAttribute(EXACT_MILEAGE,
					couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_KM) != null ? couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_KM).toString() : "0");
			writer.writeAttribute(HOURS, couponHistoryDto.getIntValue(MpType.MP_HOUR) != null ? couponHistoryDto.getIntValue(MpType.MP_HOUR).toString() : "0");
			writer.writeAttribute(EXACT_HOURS,
					couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_HOUR) != null ? couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_HOUR).toString() : "0");
			Date date = null;
			if (mpExportDto.getWarrantyDate() != null && couponHistoryDto.getIntValue(MpType.MP_MONTH) != null
					&& !couponHistoryDto.getIntValue(MpType.MP_MONTH).equals(new Long(0)))
			{
				date = new Date(Long.parseLong(mpExportDto.getWarrantyDate()));
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.MONTH, couponHistoryDto.getIntValue(MpType.MP_MONTH).intValue());
				date = cal.getTime();
			}
			writer.writeAttribute(DATE,
					date != null ? (new SimpleDateFormat(DATE_FORMAT).format(date)) : EMPTY_STRING);
			writer.writeAttribute(EXACT_DATE,
					couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_MONTH) != null
							&& !couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_MONTH).equals(new Long(0))
									? (new SimpleDateFormat(DATE_FORMAT)
											.format(new Date(couponHistoryDto.retreiveFromExactValueByMpType(MpType.MP_MONTH))))
									: EMPTY_STRING);
			writer.writeEndElement();
			writer.flush();
		}
		writer.writeEndElement();
	}

	/**
	 * @param mpExportDto
	 * @param writer
	 * @param mergedPartsList
	 * @param mergedConsList
	 * @param mergedOperations
	 * @param frequencyList
	 * @param isIveco
	 * @param isOriginal
	 * @param isConnected
	 * @param historyList
	 * @param isOptimized 
	 * @throws XMLStreamException
	 * @throws ApplicativeException
	 * @throws SystemException
	 */
	private void generateSapClaims(MPExportXMLDto mpExportDto, XMLStreamWriter writer, List<MpOperationPartDto> mergedPartsList, List<MpOperationConsumableDto> mergedConsList,
			List<MpOperationDto> mergedOperations, List<MpFrequencyDto> frequencyList, boolean isIveco, boolean isOriginal, boolean isConnected, List<MpHistoryIntervalDto> historyList, boolean isOptimized)
			throws XMLStreamException, ApplicativeException, SystemException {

		boolean heavyFlexContract = mpExportDto.isHeavyFlexContract();
		List<MpIntervalOperationDto> intervalsList = mpExportDto.getMpIntervalOperations();
		List<MpIntervalOperationDto> intervalsListRecommended = mpExportDto.getIntervalsListRecommended();
		String country = mpExportDto.getIceContextDto().getCountry().toUpperCase();
		boolean isSapXmlForAgCe = !isIveco && !isOriginal;
		
		//Here to no impact the export xml too much
		// prepar part to set preferred or not 
		/**
		 * <Claims>
		 */
		writer.writeStartElement(CLAIMS);
		writer.writeAttribute(FAILURE_DATE, UtilDate.dateToString(mpExportDto.getFailureDate(), "dd-MM-yyyy"));

		// For all claims
		StringBuilder failureCode = null;

		// When we create 2 XML (ORIGINAL_SAP_XML and SAP_XML), we call 2 times this method
		// Add intervalsList to intervalsListRecommended only the first time : 
		//  - For IVECO, only 1 XML (SAP_XML)
		//  - For AG&CE, only for first XML (ORIGINAL_SAP_XML)
		if (isIveco || (!isIveco && isOriginal))
		{
			intervalsListRecommended.addAll(0, intervalsList);
		}

		for (MpIntervalOperationDto interval : intervalsListRecommended)
		{
			failureCode = new StringBuilder();
			if (null != interval.getFailureCode())
			{
				if (!isIveco)
				{
					failureCode.append("000");
					failureCode.append(interval.getDefect()); // 00500EV
				}
				failureCode.append(interval.getFailureCode());
			}
			else
			{
				failureCode.append(EMPTY_STRING);
			}
			// COMMON
			writer.writeStartElement(CLAIM);
			writer.writeAttribute(COUPON, interval.getCode());
			if (isIveco)
			{
				writer.writeAttribute(TYPE, interval.getType() != null ? interval.getType() : EMPTY_STRING);
			}

			// Origin E stand for Etim, T stand for Telematics , "N" if not applicable
			String origin = "E";
			if (interval.getSelectionType().equals(Constants.A_ACTUAL))
			{
				origin = "N";
			}
			else if (heavyFlexContract && interval.getExternal() != null && interval.getExternal().equals(new Integer(1)))
			{
				origin = "T";
			}
			writer.writeAttribute(ORIGIN, origin);
			// Selection A stand for Actual, R for recommended and  B stand for Recommended and proposed by algo
			writer.writeAttribute(SELECTION, interval.getSelectionType());
			writer.writeAttribute(REPAIR_TIME, interval.getRepairTime() != null ? interval.getRepairTime().toString() : EMPTY_STRING);
			writer.writeAttribute(FAILURE_CODE, failureCode.toString());
			StringBuilder sb = new StringBuilder("-");
			sb.append(interval.getCoupon());
			// Status T stand for On Time, S stand for ComingSoon and O stand for Overdue
			writer.writeAttribute(STATUS, interval.getStatus().getValue());

			// If status is different from On Time
			if (!interval.getStatus().equals(MpIntervalStatusEnum.ON_TIME))
			{
				if (interval.getDeltaValue().get(MpType.MP_KM) != null && interval.getDeltaValue().get(MpType.MP_KM).compareTo(new Long(0)) != 0)
				{
					writer.writeAttribute(DELTA_KM, String.valueOf(java.lang.Math.abs(interval.getDeltaValue().get(MpType.MP_KM))));
				}
				if (interval.getDeltaValue().get(MpType.MP_HOUR) != null && interval.getDeltaValue().get(MpType.MP_HOUR).compareTo(new Long(0)) != 0)
				{
					writer.writeAttribute(DELTA_HOURS, String.valueOf(java.lang.Math.abs(interval.getDeltaValue().get(MpType.MP_HOUR))));
				}
				if (interval.getDeltaValue().get(MpType.MP_MONTH) != null && interval.getDeltaValue().get(MpType.MP_MONTH).compareTo(new Long(0)) != 0)
				{

					if (isConnected)
					{
						// For connected vehicle, there are hours in MP_MONTH unit, so change it in Month
						// If 0 < nbJours < 44 : nbMois = 1
						// If 45 < nbJours < 74 : nbMois = 2...
						long nbDays = java.lang.Math.abs(interval.getDeltaValue().get(MpType.MP_MONTH));
						int nbMonth = MaintenanceUtil.convertDaysToMonthsForConnectedVehicles(nbDays, 0, 15, 0);
						writer.writeAttribute(DELTA_MONTH, String.valueOf(nbMonth));
					}
					else
					{
						writer.writeAttribute(DELTA_MONTH, String.valueOf(java.lang.Math.abs(interval.getDeltaValue().get(MpType.MP_MONTH))));
					}

				}
			}
			writer.writeAttribute(OPER_CODE, sb.toString());

			if (!isIveco)
			{
				writer.writeAttribute(STRONG_ID, getStrongIdFomHistory(historyList, interval.getCode()));
				//TODO Put the isHidden in comment in the release 8.19 waiting for SAP to finish this PBI
				//adding the is_hidden attribute.
//				Boolean isSelectedButNotRecommended = interval.getSelectionType().equals(Constants.A_ACTUAL);
//				String isHidden = (isOptimized && (interval.isHidden() ||  isSelectedButNotRecommended)) ? "Y" : "N";
//				writer.writeAttribute(IS_HIDDEN, isHidden);
			}
			generateSapMPOperation(writer, interval, frequencyList, mergedConsList, mergedPartsList, mergedOperations, intervalsList, country, isSapXmlForAgCe, isIveco);
			writer.writeEndElement();
			writer.flush();
		}
		writer.writeEndElement();
	}

	private String getStrongIdFomHistory(List<MpHistoryIntervalDto> historyList, String intervalCode) throws SystemException {
		Optional<MpHistoryIntervalDto> history = historyList.stream().filter(h -> h.getIntervalCode().equals(intervalCode)).findFirst();
		if (history.isPresent())
		{
			return history.get().getStrongId();
		}

		return EMPTY_STRING;
	}

	/**
	 * @param writer
	 * @param interval
	 * @param frequencyList
	 * @param mergedConsList
	 * @param mergedPartsList
	 * @param mergedOperations
	 * @param intervalsList
	 * @param country
	 * @param isSapXmlForAgCe
	 * @param isIveco
	 * @throws XMLStreamException
	 * @throws ApplicativeException
	 * @throws SystemException
	 */
	private void generateSapMPOperation(XMLStreamWriter writer, MpIntervalOperationDto interval, List<MpFrequencyDto> frequencyList, List<MpOperationConsumableDto> mergedConsList,
			List<MpOperationPartDto> mergedPartsList, List<MpOperationDto> mergedOperations, List<MpIntervalOperationDto> intervalsList,
			String country, boolean isSapXmlForAgCe, boolean isIveco)
			throws XMLStreamException, ApplicativeException, SystemException {

		MpFrequencyDto mpFrequencyDto = null;
		mpFrequencyDto = new MpFrequencyDto(interval.getCode(), interval.getFrequency());
		mpFrequencyDto.setMpInterval(interval);
		frequencyList.add(mpFrequencyDto);

		//group the parts and consumables inside the same operation code
		//can happen to have 2 operation with the same operation code but with different location (ice code)
		List<MpOperationDto> mergedOpList = createOperationListMerged(interval.getOperations());

		if (isSapXmlForAgCe)
		{
			// For SAP XML AG&CE, merge duplicated Parts and consumables
			mergeDuplicatedPartsAndConsumables(mergedOpList);
		}

		for (MpOperationDto op : mergedOpList)
		{
			writer.writeStartElement(MPOPERATION);

			String operationType = null;
			if (null != op.getMicroOperation())
			{
				operationType = MICRO;
				writer.writeAttribute(CODE, op.getMicroOperation());
			}
			else
			{
				operationType = SRT;
				writer.writeAttribute(CODE, op.getSrtOperation());
			}
			writer.writeAttribute(TYPE, operationType);
			mergedConsList = op.getMergedConsumables();
			generateSapConsumables(writer, mergedConsList, country, isSapXmlForAgCe);
			// COMMON
			mergedPartsList = op.getMergedParts();
			generateSapParts(writer, mergedPartsList, intervalsList, isSapXmlForAgCe, isIveco);
			if (!existsOperationInList(mergedOperations, op))
			{
				mergedOperations.add(op);
			}
			writer.writeEndElement();
			writer.flush();
		}

	}

	private List<MpOperationPartDto> getPartsReplacedBy(MpOperationPartDto part) {
		List<MpOperationPartDto> parts = new ArrayList<MpOperationPartDto>();

		try
		{
			MpSupersessionBusiness superSessionBusiness = new MpSupersessionBusiness();
			MpPartNodeDto sons = superSessionBusiness.getSupersessions(part.getCodePart(), part.getPartLabel(), null, true);
			if (sons != null && sons.getChildren() != null && !sons.getChildren().isEmpty())
			{
				parts = superSessionBusiness.transformNodeToList(sons.getChildren());
			}
		}
		catch (JsonProcessingException | SystemException | ApplicativeException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return parts;
	}

	/**
	 * group the parts and consumables inside the same operation code
	 * can happen to have 2 operation with the same operation code but with different location (ice code)
	 * 
	 * @param operationsList
	 * @return merged list of operation + merged list of consumables and parts
	 */
	private List<MpOperationDto> createOperationListMerged(List<MpOperationDto> operationsList) {
		int i = 0;
		List<String> opAlreadyManaged = new ArrayList<>();
		List<MpOperationDto> operationListMerged = new ArrayList<>();
		for (MpOperationDto op : operationsList)
		{
			if (!opAlreadyManaged.contains(op.getCode() + op.getIceCode()))
			{
				op.setMergedConsumables(op.getConsumables());
				op.setMergedParts(op.getParts());

				String codeOp = op.getMicroOperation();
				if (codeOp == null)
				{
					codeOp = op.getSrtOperation();
				}
				for (int j = i; j < operationsList.size() - 1; j++)
				{
					MpOperationDto op2 = operationsList.get(j);
					String codeOp2 = op2.getMicroOperation();
					if (codeOp2 == null)
					{
						codeOp2 = op2.getSrtOperation();
					}
					if (codeOp.equals(codeOp2) && !op.getIceCode().equals(op2.getIceCode()))
					{
						opAlreadyManaged.add(op2.getCode() + op2.getIceCode());
						op.getMergedConsumables().addAll(op2.getConsumables());
						op.getMergedParts().addAll(op2.getParts());
					}
				}
				operationListMerged.add(op);
			}
			i++;
		}
		return operationListMerged;
	}

	/**
	 * For SAP XML AG&CE, merge duplicated Parts and Consumables
	 * 
	 * @param operationListMerged the list to merge
	 */
	private void mergeDuplicatedPartsAndConsumables(List<MpOperationDto> operationListMerged) {

		Map<String, String> treatedPartsMap = new HashMap<String, String>();
		Map<String, String> treatedConsumablesMap = new HashMap<String, String>();

		for (MpOperationDto operation : operationListMerged)
		{

			String operationCode;
			if (null != operation.getMicroOperation()) operationCode = operation.getMicroOperation();
			else operationCode = operation.getSrtOperation();

			// 1 - Iterate on Parts list
			for (MpOperationPartDto part : operation.getMergedParts())
			{
				//				if (part.getReplacedByList() != null && !part.getReplacedByList().isEmpty() && part.isSelected())
				//				{
				//					for (MpOperationPartDto partReplace : part.getReplacedByList())
				//					{
				//
				//					}
				//				}
				//				// Find the part to modify
				//				else if (part.isSelected())
				//				{
				String currentPN = part.getCodePart();
				if (StringUtils.isNotEmpty(currentPN))
				{
					// Check for part duplication
					if (treatedPartsMap.containsKey(currentPN))
					{
						// Duplicated part case, aggregate current with treated part
						for (MpOperationDto op : operationListMerged)
						{

							String opCode;
							if (null != op.getMicroOperation()) opCode = op.getMicroOperation();
							else opCode = op.getSrtOperation();

							if (treatedPartsMap.get(currentPN).equals(opCode))
							{
								// Find the operation to modify

								for (MpOperationPartDto p : op.getMergedParts())
								{

									if (currentPN.equals(p.getCodePart()))
									{
										// Find the part to modify
										if (part.isSelected())
										{
											// Update Quantity in first part
											p.setQuantity(Double.sum(p.getQuantity(), part.getQuantity()));

											// If duplicated part is selected, update first part selection
											p.setSelected(part.isSelected());
										}

										// This part duplicated must be deleted, add flag to delete during XML creation
										part.setDuplicated(true);

										break;
									}

									//									if (p.isSelected() && currentPN.equals(p.getCodePart()))
									//									{
									//										// Update Quantity in first part
									//										p.setQuantity(Double.sum(p.getQuantity(), part.getQuantity()));
									//
									//										// If duplicated part is selected, update first part selection
									//										//p.setSelected(part.isSelected());
									//
									//										// This part duplicated must be deleted, add flag to delete during XML creation
									//										part.setDuplicated(true);
									//
									//										break;
									//									}
								}

								break;
							}
						}

					}
					else
					{
						// Add part in all treated parts (with associated MpOperation code)
						treatedPartsMap.put(currentPN, operationCode);
					}
				}
				//				}
			}

			// 2 - Iterate on Consumables list
			for (MpOperationConsumableDto consumable : operation.getMergedConsumables())
			{
				//				if (consumable.isSelected())
				//				{
				String currentPN = consumable.getPartnumber();
				if (StringUtils.isNotEmpty(currentPN))
				{
					if (treatedConsumablesMap.containsKey(currentPN))
					{
						// Duplicated consumable case, aggregate current with treated consumable
						for (MpOperationDto op : operationListMerged)
						{

							String opCode;
							if (null != op.getMicroOperation()) opCode = op.getMicroOperation();
							else opCode = op.getSrtOperation();

							if (treatedConsumablesMap.get(currentPN).equals(opCode))
							{
								// Find the operation to modify
								for (MpOperationConsumableDto c : op.getMergedConsumables())
								{
									if (currentPN.equals(c.getPartnumber()))
									{
										// Find the consumable to modify
										if (consumable.isSelected())
										{
											// Update Quantity in first Consumable
											c.setQty(Float.sum(c.getQty(), consumable.getQty()));

											// If duplicated Consumable is selected, update first consumable selection
											c.setSelected(consumable.isSelected());
										}

										// This part duplicated must be deleted, add flag to delete during XML creation
										consumable.setDuplicated(true);

										break;
									}

									//									if (currentPN.equals(c.getPartnumber()))
									//									{
									//										// Find the consumable to modify
									//										if (consumable.isSelected() && c.isSelected())
									//										{
									//											// Update Quantity in first Consumable
									//											c.setQty(Float.sum(c.getQty(), consumable.getQty()));
									//
									//											// If duplicated Consumable is selected, update first consumable selection
									//											//											c.setSelected(consumable.isSelected());
									//										}
									//
									//										// This part duplicated must be deleted, add flag to delete during XML creation
									//										consumable.setDuplicated(true);
									//
									//										break;
									//									}
								}

								break;
							}
						}

					}
					else
					{
						// Add part in all treated parts (with associated MpOperation code)
						treatedConsumablesMap.put(currentPN, operationCode);
						//						mergedConsumablesOut.add(consumable);
					}
				}
				//				}
			}

			// Add parts in operation
			//			operationOut.getMergedConsumables().clear();
			//			operationOut.setMergedConsumables(mergedConsumablesOut);
			//
			//			// Add Operation merged in operation list
			//			operationListMergedOut.add(operationOut);
		}

		//		operationListMerged.clear();
		//		operationListMerged.addAll(operationListMergedOut);

	}

	/**
	 * @param write
	 * @param mergedConsList
	 * @throws XMLStreamException
	 */
	private void generateSapConsumables(XMLStreamWriter writer, List<MpOperationConsumableDto> mergedConsList, String country, boolean isSapXmlForAgCe) throws XMLStreamException {

		for (MpOperationConsumableDto cons : mergedConsList)
		{
			// For SAP XML AG&CE (not original SAP XML) : 
			// - consumables with empty PN not added in the XML
			// - duplicated consumables not added in the XML
			if ((!isSapXmlForAgCe || (isSapXmlForAgCe && StringUtils.isNotEmpty(cons.getPartnumber()))) && !cons.isDuplicated())
			{
				writer.writeStartElement(CONSUMABLE);
				writer.writeAttribute(ID,
						cons.getIdConsumable() != null ? cons.getIdConsumable().toString() : EMPTY_STRING);
				writer.writeAttribute(PN, cons.getPartnumber() != null ? cons.getPartnumber() : EMPTY_STRING);

				if (Constantes.UNITED_KINGDOM.equalsIgnoreCase(country))
				{
					double rtn = UnitsUtil.getConvertedNumInStringUK(cons.getUnit(), cons.getQty());

					writer.writeAttribute(QUANTITY, String.valueOf(rtn != 0.00 ? rtn : UnitsUtil.roundAvoid(cons.getQty(), 2)));
					writer.writeAttribute(UNIT, "L");
				}
				else
				{
					writer.writeAttribute(QUANTITY, String.valueOf(UnitsUtil.roundAvoid(cons.getQty(), 2)));
					writer.writeAttribute(UNIT, (cons.getUnit() != null ? cons.getUnit() : EMPTY_STRING));
				}

				// TODO: Consumable cannot be selected in eTIM default Y
				writer.writeAttribute(SELECTION, cons.isSelected() ? "Y" : "N");
				writer.writeEndElement();
				writer.flush();
			}

		}

	}

	/**
	 * @param writer
	 * @param mergedPartsList
	 * @param intervalsList
	 * @throws ApplicativeException
	 * @throws SystemException
	 * @throws XMLStreamException
	 */
	private void generateSapParts(XMLStreamWriter writer, List<MpOperationPartDto> mergedPartsList, List<MpIntervalOperationDto> intervalsList, boolean isSapXmlForAgCe, boolean isIveco)
			throws ApplicativeException, SystemException, XMLStreamException {

		List<Integer> groupList = new ArrayList<Integer>();

		for (MpOperationPartDto part : mergedPartsList)
		{
			//TODO if the part is selected and a list of replace exists set the list of part replaced instead of the original part
			if (part.getReplacedByList() != null && !part.getReplacedByList().isEmpty() && part.isSelected())
			{
				for (MpOperationPartDto partReplace : part.getReplacedByList())
				{
					writer.writeStartElement(PART);
					writer.writeAttribute(PN, partReplace.getCodePart() != null ? partReplace.getCodePart() : EMPTY_STRING);
					String partQty = EMPTY_STRING;
					if (partReplace.getQuantity() != null)
					{
						partQty = String.valueOf(partReplace.getQuantity());
					}
					writer.writeAttribute(QUANTITY, partQty);

					Integer partGroup = part.getPartGroup();
					if (partGroup != null && partGroup.compareTo(new Integer(0)) != 0)
					{
						writer.writeAttribute(GROUP, String.valueOf(partGroup));
					}

					if (isIveco)
					{
						writer.writeAttribute(SUPERSESSION, "Y");
					}
					writer.writeAttribute(SELECTION, "Y");

					writer.writeEndElement();
					writer.flush();
				}

				// Load all the superSession chain
				if (isIveco)
				{
					List<MpOperationPartDto> partsReplacement = getPartsReplacedBy(part);
					part.setReplacedByList(partsReplacement);
				}
			}
			else
			{

				// For SAP XML AG&CE (not original SAP XML) : 
				// - parts with empty PN not added in the XML
				// - duplicated parts not added in the XML
				if ((!isSapXmlForAgCe || (isSapXmlForAgCe && StringUtils.isNotEmpty(part.getCodePart()))) && !part.isDuplicated())
				{
					writer.writeStartElement(PART);
					writer.writeAttribute(PN, part.getCodePart() != null ? part.getCodePart() : EMPTY_STRING);
					writer.writeAttribute(QUANTITY, part.getQuantity() != null ? part.getQuantity().toString() : EMPTY_STRING);

					Integer partGroup = part.getPartGroup();
					if (partGroup != null && partGroup.compareTo(new Integer(0)) != 0)
					{
						writer.writeAttribute(GROUP, String.valueOf(partGroup));
						groupList.add(partGroup);
					}
					else if (part.isNewPart())
					{
						//We have to add a new partGroup for the new part.  
						if (!groupList.isEmpty())
						{
							Integer newPartGroup = null;
							Collections.sort(groupList);
							newPartGroup = groupList.get(groupList.size() - 1) + 1;
							writer.writeAttribute(GROUP, String.valueOf(newPartGroup));
							groupList.add(newPartGroup);
						}

					}

					if (part.isKitPreferred())
					{
						//part.setKitPreferred(true);
						writer.writeAttribute(PREFERRED, "Yes");
					}

					if (isIveco)
					{
						List<MpOperationPartDto> partsReplacement = getPartsReplacedBy(part);
						part.setReplacedByList(partsReplacement);
						writer.writeAttribute(SUPERSESSION, partsReplacement.isEmpty() ? "N" : "Y");
					}

					if (part.isNewPart())
					{
						writer.writeAttribute(SELECTION, "M");
					}
					else
					{
						writer.writeAttribute(SELECTION, part.isSelected() ? "Y" : "N");
					}

					writer.writeEndElement();
					writer.flush();
				}

			}
		}
	}

	/**
	 * @param writer
	 * @param mergedOperations
	 * @param frequencyList
	 * @param business
	 * @param partBusiness
	 * @param consBusiness
	 * @param kitCompositionBusiness
	 * @param mpExportDto
	 * @throws XMLStreamException
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	private void generateSapAdditionalInfos(XMLStreamWriter writer, List<MpOperationDto> mergedOperations, List<MpFrequencyDto> frequencyList,
			TableTitleBusiness business, MpOperationPartBusiness partBusiness, ConsumableBusiness consBusiness, Map<String, String> kitCodeByPartNumber, MPExportXMLDto mpExportDto,
			boolean isSapXmlForAgCe, boolean isIveco)
			throws XMLStreamException, SystemException, ApplicativeException {
		writer.writeStartElement(ADDITIONAL_INFOS);
		List<MpOperationPartDto> partsList = new ArrayList<>();
		HashMap<String, MpOperationPartDto> partsHmap = new HashMap<>();
		List<MpOperationConsumableDto> consumablesList = new ArrayList<>();
		HashMap<Long, MpOperationConsumableDto> consumablesHmap = new HashMap<>();
		List<TableTitleDto> opDescriptionList = null;
		List<ConsumableDto> consDescriptionList = null;

		generateSapAddInfoOperations(writer, mergedOperations, opDescriptionList, business, partsList, consumablesList, isIveco);
		writer.flush();
		generateSapAddInfoConsumables(writer, consumablesList, consumablesHmap, consDescriptionList, consBusiness, mpExportDto, isSapXmlForAgCe);
		writer.flush();
		generateSapAddInfoParts(writer, partsList, partsHmap, partBusiness, isSapXmlForAgCe, isIveco);
		writer.flush();
		generateSapAddInfoFrequency(writer, frequencyList, business);
		writer.flush();

		List<MpOperationPartDto> mpOperationParts = getPartsFromOperationsList(mergedOperations);

		Map<String, List<MpKitCompositionDto>> mapMpKitCompoByKitCode = getMapKitCompoByKitCode(mpOperationParts, kitCodeByPartNumber);

		if (!mapMpKitCompoByKitCode.keySet().isEmpty())
		{
			generateSapAddInfoKitsNew(writer, mapMpKitCompoByKitCode);
		}

		writer.flush();
		generateSapAddInfoUsages(writer, mpExportDto);
		writer.flush();
		writer.writeEndElement();
	}

	/**
	 * @param writer
	 * @param partsList
	 * @param partsHmap
	 * @param partBusiness
	 * @throws XMLStreamException
	 * @throws SystemException
	 */
	private List<MpOperationPartDto> getPartsFromOperationsList(List<MpOperationDto> mergedOperations) {
		List<MpOperationPartDto> mpOperationPartList = new ArrayList<>();
		for (MpOperationDto mpOperation : mergedOperations)
		{
			List<MpOperationPartDto> mpOperationPartDtoLst = mpOperation.getParts();
			for (MpOperationPartDto mpOperationPart : mpOperationPartDtoLst)
			{

				mpOperationPartList.add(mpOperationPart);

			}

		}
		return mpOperationPartList;
	}

	/**
	 * @param writer
	 * @param partsList
	 * @param partsHmap
	 * @param partBusiness
	 * @throws ApplicativeException
	 * @throws XMLStreamException
	 * @throws SystemException
	 */
	private Map<String, List<MpKitCompositionDto>> getMapKitCompoByKitCode(List<MpOperationPartDto> mpOperationParts, Map<String, String> kitCodeByPartNumber)
			throws SystemException, ApplicativeException {
		MpKitCompositionBusiness kitCompositionBusiness = new MpKitCompositionBusiness();
		Map<String, List<MpKitCompositionDto>> mapMpKitCompoByKitCode = new HashMap<>();
		for (MpOperationPartDto mpPart : mpOperationParts)
		{

			if (mpPart.isInKit())
			{
				// Composition of the kit
				if (!mapMpKitCompoByKitCode.containsKey(mpPart.getCodePart()))
				{
					List<MpKitCompositionDto> kitCompositionListByCodePart = kitCompositionBusiness.getPartsListByKit(mpPart.getCodePart());
					if (!kitCompositionListByCodePart.isEmpty())
					{
						mapMpKitCompoByKitCode.put(mpPart.getCodePart(), kitCompositionListByCodePart);
					}
				}
			}
			else if (!mpPart.isInKit())
			{
				if (kitCodeByPartNumber.containsKey(mpPart.getCodePart()))
				{
					String codeKit = kitCodeByPartNumber.get(mpPart.getCodePart());
					if (!mapMpKitCompoByKitCode.containsKey(codeKit))
					{
						List<MpKitCompositionDto> kitCompositionListByCodePart = kitCompositionBusiness.getPartsListByKit(codeKit);
						if (!kitCompositionListByCodePart.isEmpty())
						{
							mapMpKitCompoByKitCode.put(codeKit, kitCompositionListByCodePart);
						}
					}
				}

			}

		}
		return mapMpKitCompoByKitCode;

	}

	/**
	 * @param writer
	 * @param mergedOperations
	 * @param opDescriptionList
	 * @param business
	 * @param partsList
	 * @param consumablesList
	 * @throws XMLStreamException
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	private void generateSapAddInfoOperations(XMLStreamWriter writer, List<MpOperationDto> mergedOperations, List<TableTitleDto> opDescriptionList, TableTitleBusiness business,
			List<MpOperationPartDto> partsList, List<MpOperationConsumableDto> consumablesList, Boolean isIveco) throws XMLStreamException, SystemException, ApplicativeException {
		writer.writeStartElement(OPERATION_LIST);
		String descriptionId = null;
		List<String> existingPartsList = new ArrayList<>();
		for (MpOperationDto operation : mergedOperations)
		{
			writer.writeStartElement(OPERATION);
			if (null != operation.getMicroOperation())
			{
				// "Micro";
				writer.writeAttribute(CODE, operation.getMicroOperation());
			}
			else
			{
				// "SRT";
				writer.writeAttribute(CODE, operation.getSrtOperation());
			}

			// For all descriptions
			descriptionId = operation.getOperationLabelId();
			if (null != descriptionId)
			{
				opDescriptionList = business.getListTableTitle(descriptionId);
			}
			if (null != opDescriptionList && !opDescriptionList.isEmpty())
			{

				for (TableTitleDto opDescr : opDescriptionList)
				{
					if (opDescr.getIdLanguage().equals(EN))
					{
						writer.writeStartElement(LABEL);
						writer.writeAttribute(LANGUAGE, EN);
						writer.writeAttribute(VALUE, StringEscapeUtils.unescapeHtml(opDescr.getMessage()));
						writer.writeEndElement();
					}
				}
			}

			// Combine parts
			for (MpOperationPartDto part : operation.getParts())
			{
				if (isIveco)
				{
					// Check for part duplication
					if (existingPartsList.contains(part.getCodePart()))
					{
						// update quantity
						int partIndex = -1;
						for (int i = 0; i < partsList.size(); i++)
						{
							if (partsList.get(i).getCodePart().equals(part.getCodePart()))
							{
								partIndex = i;
							}
						}

						MpOperationPartDto existingPart = partsList.get(partIndex);
						existingPart.setQuantity(Double.sum(existingPart.getQuantity(), part.getQuantity()));
					}
					else
					{
						partsList.add(part);
						existingPartsList.add(part.getCodePart());
					}
				}
				else
				{
					if (part.getReplacedByList() != null && !part.getReplacedByList().isEmpty() && part.isSelected())
					{
						//get the part replace if part selected
						for (MpOperationPartDto partReplace : part.getReplacedByList())
						{
							if (!existingPartsList.contains(partReplace.getCodePart()))
							{
								existingPartsList.add(partReplace.getCodePart());
								partsList.add(partReplace);
								partReplace.setAReplacement(true);
							}
						}
					}
					else if (!existingPartsList.contains(part.getCodePart()))
					{
						existingPartsList.add(part.getCodePart());
						partsList.add(part);
					}
				}

			}

			consumablesList.addAll(operation.getConsumables());
			writer.writeEndElement();
			writer.flush();
		}
		writer.writeEndElement();
	}

	/**
	 * @param writer
	 * @param partsList
	 * @param partsHmap
	 * @param partBusiness
	 * @throws XMLStreamException
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	private void generateSapAddInfoParts(XMLStreamWriter writer, List<MpOperationPartDto> partsList, HashMap<String, MpOperationPartDto> partsHmap, MpOperationPartBusiness partBusiness,
			boolean isSapXmlForAgCe, boolean isIveco)
			throws XMLStreamException, SystemException, ApplicativeException {
		MpOperationPartDto mpPartDto = null;
		String label = null;
		MpPartDetailDto partDetailRoot;
		writer.writeStartElement(PART_LIST);

		for (MpOperationPartDto part : partsList)
		{
			// Check for part duplication
			if (!partsHmap.containsKey(part.getCodePart()))
			{
				partsHmap.put(part.getCodePart(), part);

				// For SAP XML AG&CE (not original SAP XML), consumables with empty PN not added in the XML
				if (!isSapXmlForAgCe || (isSapXmlForAgCe && StringUtils.isNotEmpty(part.getCodePart())))
				{
					if (isIveco && part.getReplacedByList() != null && !part.getReplacedByList().isEmpty())
					{
						writer.writeStartElement(PART);
						writer.writeAttribute(PN, part.getCodePart());
						writer.writeAttribute(QUANTITY, part.getQuantity() != null ? part.getQuantity().toString() : EMPTY_STRING);

						mpPartDto = partBusiness.getPart(part.getCodePart());
						label = null;
						if (null != mpPartDto && mpPartDto.getPartLabel() != null && !mpPartDto.getPartLabel().equals(""))
						{
							label = mpPartDto.getPartLabel();
						}
						// improve if part supersession to get the part description already retrieve for the tooltip in MP_PART_NUMBER_DETAIL
						if (label == null && part.isAReplacement())
						{
							partDetailRoot = partBusiness.getPartDetail(part.getCodePart());
							if (partDetailRoot != null && partDetailRoot.getPndLabelEn() != null)
							{
								label = partDetailRoot.getPndLabelEn();
							}
						}
						if (null != label)
						{
							writer.writeStartElement(DESCRIPTION);
							writer.writeAttribute(LANGUAGE, EN);
							writer.writeAttribute(VALUE, StringEscapeUtils.unescapeHtml(label));
							writer.writeEndElement();
						}

						if (part.getReplacedByList() != null && !part.getReplacedByList().isEmpty())
						{
							for (MpOperationPartDto child : part.getReplacedByList())
							{
								generatePartChild(writer, child);
							}

						}

						writer.writeEndElement();
						writer.flush();

					}
					else
					{
						writer.writeStartElement(PART);
						writer.writeAttribute(PN, part.getCodePart());

						mpPartDto = partBusiness.getPart(part.getCodePart());
						label = null;
						if (null != mpPartDto && mpPartDto.getPartLabel() != null && !mpPartDto.getPartLabel().equals(""))
						{
							label = mpPartDto.getPartLabel();
						}
						// improve if part supersession to get the part description already retrieve for the tooltip in MP_PART_NUMBER_DETAIL
						if (label == null && part.isAReplacement())
						{
							partDetailRoot = partBusiness.getPartDetail(part.getCodePart());
							if (partDetailRoot != null && partDetailRoot.getPndLabelEn() != null)
							{
								label = partDetailRoot.getPndLabelEn();
							}
						}
						if (null != label)
						{
							writer.writeStartElement(DESCRIPTION);
							writer.writeAttribute(LANGUAGE, EN);
							writer.writeAttribute(VALUE, StringEscapeUtils.unescapeHtml(label));
							writer.writeEndElement();
						}

						writer.writeEndElement();
						writer.flush();
					}

				}

			}
		}

		writer.writeEndElement();
	}

	/**
	 * @param writer
	 * @param child
	 */
	void generatePartChild(XMLStreamWriter writer, MpOperationPartDto child) throws XMLStreamException {
		writer.writeStartElement(PART_CHILD);
		writer.writeAttribute(PN, child.getCodePart());
		writer.writeAttribute(QUANTITY, child.getQuantity() != null ? child.getQuantity().toString() : EMPTY_STRING);
		writer.writeAttribute(TYPE, child.getType() != null ? child.getType().toString() : EMPTY_STRING);

		if (child.getReplacedByList() != null && !child.getReplacedByList().isEmpty())
		{
			List<MpOperationPartDto> sons = child.getReplacedByList();
			for (MpOperationPartDto son : sons)
			{
				generatePartChild(writer, son);
			}
		}

		writer.writeEndElement();
	}

	/**
	 * @param writer
	 * @param consumablesList
	 * @param consumablesHmap
	 * @param consDescriptionList
	 * @param consBusiness
	 * @throws XMLStreamException
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	private void generateSapAddInfoConsumables(XMLStreamWriter writer, List<MpOperationConsumableDto> consumablesList, HashMap<Long, MpOperationConsumableDto> consumablesHmap,
			List<ConsumableDto> consDescriptionList, ConsumableBusiness consBusiness, MPExportXMLDto mpExportDto, boolean isSapXmlForAgCe)
			throws XMLStreamException, SystemException, ApplicativeException {

		// COMMON
		writer.writeStartElement(CONSUMABLE_LIST);
		MpOperationConsumableBusiness mpOperationConsumableBusiness = new MpOperationConsumableBusiness();
		for (MpOperationConsumableDto cons : consumablesList)
		{
			if (!consumablesHmap.containsKey(cons.getIdConsumable()))
			{
				// MSH - Consumable changes.
				MpOperationConsumableDto newDto = mpOperationConsumableBusiness.getConsumablesOccByConsId(cons.getIdConsumable(), false, mpExportDto.getIceContextDto());

				if (newDto == null)
				{
					newDto = mpOperationConsumableBusiness.getConsumablesOccByConsId(cons.getIdConsumable(), true, mpExportDto.getIceContextDto());
				}

				consumablesHmap.put(cons.getIdConsumable(), cons);

				// For SAP XML AG&CE (not original SAP XML), consumables with empty PN not added in the XML
				if (!isSapXmlForAgCe || (isSapXmlForAgCe && ((newDto != null && StringUtils.isNotEmpty(newDto.getPartnumber())) || StringUtils.isNotEmpty(cons.getPartnumber()))))
				{
					writer.writeStartElement(CONSUMABLE);
					// MSH Changes for COnsumable.
					if (newDto != null && newDto.getPartnumber() != null)
					{
						writer.writeAttribute(PN, newDto.getPartnumber());
					}
					else
					{
						writer.writeAttribute(PN, cons.getPartnumber() != null ? cons.getPartnumber() : EMPTY_STRING);
					}

					writer.writeAttribute(ID,
							cons.getIdConsumable() != null ? cons.getIdConsumable().toString() : EMPTY_STRING);

					// For all descriptions
					consDescriptionList = consBusiness.getConsumableById(cons.getIdConsumable().toString());
					if (null != consDescriptionList && !consDescriptionList.isEmpty())
					{
						for (ConsumableDto consDescr : consDescriptionList)
						{
							if (consDescr.getIdLanguage().equals(EN))
							{
								writer.writeStartElement(LABEL);
								writer.writeAttribute(LANGUAGE, EN);
								if (newDto != null && newDto.getDescription() != null)
								{
									writer.writeAttribute(VALUE, new StringBuilder().append(consDescr.getGroup()).append(" - ")
											.append(newDto.getDescription()).toString());
								}
								else
								{
									writer.writeAttribute(VALUE, new StringBuilder().append(consDescr.getGroup()).append(" - ")
											.append(consDescr.getName()).toString());
								}
								writer.writeEndElement();
							}

						}
						for (ConsumableDto consDescr : consDescriptionList)
						{
							if (consDescr.getIdLanguage().equals(EN) && consDescr.getDescription() != null)
							{
								writer.writeStartElement(DESCRIPTION);
								writer.writeAttribute(LANGUAGE, EN);
								writer.writeAttribute(VALUE, StringEscapeUtils.unescapeHtml(consDescr.getDescription()).replaceAll("\n", " "));
								writer.writeEndElement();
							}
						}
					}
					writer.writeEndElement();
					writer.flush();
				}

			}
		}
		writer.writeEndElement();

	}

	/**
	 * @param writer
	 * @param frequencyList
	 * @param business
	 * @throws XMLStreamException
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	private void generateSapAddInfoFrequency(XMLStreamWriter writer, List<MpFrequencyDto> frequencyList, TableTitleBusiness business) throws XMLStreamException, SystemException, ApplicativeException {
		writer.writeStartElement(FREQUENCY_LIST);

		// For all freq
		MpIntervalDto mpInterval = null;
		List<TableTitleDto> commentsList = null;
		for (MpFrequencyDto freq : frequencyList)
		{
			mpInterval = freq.getMpInterval();
			// SAP Frequency
			writer.writeStartElement(FREQUENCY_UPPER);
			writer.writeAttribute(COUPON, freq.getId() != null ? freq.getId() : EMPTY_STRING);
			if (freq.getMpInterval() != null)
			{

				writer.writeAttribute(CODE,
						freq.getMpInterval().getCoupon() != null ? freq.getMpInterval().getCoupon() : EMPTY_STRING);

				writer.writeAttribute(TYPE,
						freq.getMpInterval().getType() != null ? freq.getMpInterval().getType() : EMPTY_STRING);
				if (freq.getMpInterval().getStartValue(MpType.MP_KM) != null && freq.getMpInterval().getStartValue(MpType.MP_KM) != 0)
					writer.writeAttribute(AT_KM, freq.getMpInterval().getStartValue(MpType.MP_KM).toString());
				if (freq.getMpInterval().getStartValue(MpType.MP_HOUR) != null && freq.getMpInterval().getStartValue(MpType.MP_HOUR) != 0)
					writer.writeAttribute(AT_HOURS, freq.getMpInterval().getStartValue(MpType.MP_HOUR).toString());
				if (freq.getMpInterval().getStartValue(MpType.MP_MONTH) != null && freq.getMpInterval().getStartValue(MpType.MP_MONTH) != 0)
					writer.writeAttribute(AT_MONTH, freq.getMpInterval().getStartValue(MpType.MP_MONTH).toString());
				if (freq.getMpInterval().getAfterValue(MpType.MP_KM) != null && freq.getMpInterval().getAfterValue(MpType.MP_KM) != 0)
					writer.writeAttribute(EVERY_KM, freq.getMpInterval().getAfterValue(MpType.MP_KM).toString());
				if (freq.getMpInterval().getAfterValue(MpType.MP_HOUR) != null && freq.getMpInterval().getAfterValue(MpType.MP_HOUR) != 0)
					writer.writeAttribute(EVERY_HOURS, freq.getMpInterval().getAfterValue(MpType.MP_HOUR).toString());
				if (freq.getMpInterval().getAfterValue(MpType.MP_MONTH) != null && freq.getMpInterval().getAfterValue(MpType.MP_MONTH) != 0)
					writer.writeAttribute(EVERY_MONTH, freq.getMpInterval().getAfterValue(MpType.MP_MONTH).toString());
			}
			commentsList = null;
			if (null != mpInterval.getCommentId())
			{
				commentsList = business.getListTableTitle(mpInterval.getCommentId().toString());
			}
			if (null != commentsList && !commentsList.isEmpty())
			{
				for (TableTitleDto comment : commentsList)
				{
					if (comment.getIdLanguage().equals(EN))
					{
						writer.writeStartElement(COMMENT);
						writer.writeAttribute(LANGUAGE, EN);
						writer.writeAttribute(VALUE, comment.getMessage());
						writer.writeEndElement();
					}

				}

			}
			writer.writeEndElement();
			writer.flush();
		}
		writer.writeEndElement();
	}

	/**
	 * @param writer : writer
	 * @param mapMpKitCompoByKitCode : all kit to be created
	 * @throws XMLStreamException : XMLStreamException
	 * @throws SystemException : SystemException
	 * @throws ApplicativeException : ApplicativeException
	 */
	private void generateSapAddInfoKitsNew(XMLStreamWriter writer, Map<String, List<MpKitCompositionDto>> mapMpKitCompoByKitCode)
			throws XMLStreamException, SystemException, ApplicativeException {
		// DMS
		// MAY Kit Composition
		// For each kit characterized as "Preferred, its composition (part number list)
		// is described

		// For all Parts
		boolean kitListTagToBeCreated = true;

		for (Map.Entry<String, List<MpKitCompositionDto>> entry : mapMpKitCompoByKitCode.entrySet())
		{
			// Composition of the kit
			List<MpKitCompositionDto> kitCompositionList = entry.getValue();
			String kitCode = entry.getKey();
			if (!kitCompositionList.isEmpty())
			{
				if (kitListTagToBeCreated)
				{
					writer.writeStartElement(KIT_LIST);
					kitListTagToBeCreated = false;
				}
				writer.writeStartElement(KIT);
				writer.writeAttribute(KITPN, kitCode);
				// For all the parts which compose the kit
				for (MpKitCompositionDto partKit : kitCompositionList)
				{
					writer.writeStartElement(PART);
					writer.writeAttribute(PN, partKit.getCompPnCode());
					writer.writeAttribute(QUANTITY,
							partKit.getCompPnQty() != null ? partKit.getCompPnQty().toString() : EMPTY_STRING);
					writer.writeEndElement();
				}
				writer.writeEndElement();
				writer.flush();
			}
		}

		writer.writeEndElement();
	}

	/**
	 * @param writer
	 * @param mpExportDto
	 * @throws XMLStreamException
	 * @throws SystemException
	 */
	private void generateSapAddInfoUsages(XMLStreamWriter writer, MPExportXMLDto mpExportDto) throws XMLStreamException, SystemException {

		MpUsageBusiness mpUsageBusiness = new MpUsageBusiness();
		MpPlanDto planSelected = mpExportDto.getPlan();
		if (planSelected != null && planSelected.getCondition() != null && planSelected.getCondition().getUsage() != null && planSelected.getCondition().getUsage() != null)
		{
			MpUsageDto mpUsageDto = planSelected.getCondition().getUsage();
			if (MpUsageDto.DEFAULT_VALUE_ID != mpUsageDto.getValueId())
			{
				writer.writeStartElement(USAGE_LIST);

				String valueTitle = mpUsageBusiness.getMpUsageDtoValueTitleByIdAndLanguage(mpUsageDto.getValueId(), EN);

				if (valueTitle != null)
				{
					//used for Job card for the DMS export to set the usage label (in this case only English))
					if (mpExportDto.getUsage() == null || mpExportDto.getUsage().equals(""))
					{
						mpExportDto.setUsage(valueTitle);
					}
					writer.writeStartElement(USAGE);
					writer.writeAttribute(USAGE_ID, String.valueOf(mpUsageDto.getValueId()));
					writer.writeStartElement(DESCRIPTION);
					writer.writeAttribute(LANGUAGE, EN);
					writer.writeAttribute(VALUE, valueTitle);
					writer.writeEndElement();
					writer.flush();
				}

				writer.writeEndElement();
			}
		}
	}

	/**
	 * Generates XML file content according data.
	 * 
	 * @param mpExportDto
	 * @param kitCodeByPartNumber
	 * @param isIveco
	 * @param isOptimized 
	 * @param isOriginal, if true OLD SAP XML (for backup), else new one formatted for SAP
	 * @return
	 * @throws SystemException : the system exception to be thrown
	 * @throws ApplicativeException
	 */
	public String generateSAPXML(MPExportXMLDto mpExportDto, Map<String, String> kitCodeByPartNumber, boolean isIveco, boolean isOriginal, boolean isConnected,
			List<MpHistoryIntervalDto> historyList, boolean isOptimized)
			throws SystemException, ApplicativeException {

		try
		{
			System.setProperty("javax.xml.stream.XMLOutputFactory", "com.sun.xml.internal.stream.XMLOutputFactoryImpl");
			System.setProperty("javax.xml.stream.XMLStreamWriter", "com.sun.xml.internal.stream.writers.XMLStreamWriterImpl");

			StringWriter stringOut = new StringWriter();
			XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();
			XMLStreamWriter writer = outputFactory.createXMLStreamWriter(stringOut);
			writer.writeStartDocument("UTF-8", "1.0");

			// Quotation or Claim
			String type = mpExportDto.getType();
			if (type == null)
			{
				type = EXPORT;
			}

			// Business to get description and label
			TableTitleBusiness business = new TableTitleBusiness();
			ConsumableBusiness consBusiness = new ConsumableBusiness();
			MpOperationPartBusiness partBusiness = new MpOperationPartBusiness();

			/**
			 * XML document creation
			 * 
			 * <Session>
			 */
			boolean isSapXmlForAgCe = !isIveco && !isOriginal;
			writer.writeStartElement(SESSION);
			logger.error("MML - generateSAPXML:" + mpExportDto);
			if (mpExportDto != null)
			{
				logger.error("MML - generateSAPXML:" + mpExportDto.getVin());
			}

			String vin = mpExportDto.getVin();
			if (isSapXmlForAgCe && vin != null && vin.length() == 9)
			{
				MpSapSerialNumber17Dto mpSapSerialNumber17Dto = (new MpSapSerialNumber17Business()).getSapSerialNumber17FromSapVin(vin);
				if (mpSapSerialNumber17Dto != null)
				{
					vin = mpSapSerialNumber17Dto.getSapVin17();
				}
				else
				{
					logger.error("Sap Serial Number 17 not found for VIN 9:" + vin);
				}

			}
			writer.writeAttribute(VIN, vin);
			writer.flush();
			stringOut.flush();

			/**
			 * <Header> SAP
			 */
			generateSapHeader(writer, mpExportDto, isIveco);
			writer.flush();
			/**
			 * <History> SAP
			 */
			generateSapHistory(writer, mpExportDto);
			writer.flush();

			/**
			 * <Claims> SAP
			 */
			List<MpOperationPartDto> mergedPartsList = null;
			List<MpOperationConsumableDto> mergedConsList = null;
			List<MpOperationDto> mergedOperations = new ArrayList<>();
			List<MpFrequencyDto> frequencyList = new ArrayList<>();

			generateSapClaims(mpExportDto, writer, mergedPartsList,
					mergedConsList, mergedOperations,
					frequencyList, isIveco, isOriginal, isConnected, historyList, isOptimized);
			writer.flush();
			/**
			 * <Additional_infos>
			 */
			generateSapAdditionalInfos(writer, mergedOperations, frequencyList, business, partBusiness, consBusiness, kitCodeByPartNumber, mpExportDto, isSapXmlForAgCe, isIveco);
			writer.writeEndElement();
			writer.writeEndDocument();
			writer.flush();
			String out = stringOut.toString().replaceFirst(XML_HEADER, "");
			return out;
		}
		catch (XMLStreamException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Generates XML file content according data.
	 * 
	 * @param session the session to have the data
	 * @return content of XML
	 * @throws ApplicativeException : the applicative exception to be thrown
	 * @throws SystemException : the system exception to be thrown
	 */
	public org.jdom.Document generateDMSXML(MPExportXMLDto mpExportXmlDto, Map<String, String> kitCodeByPartNumber, boolean isIveco)
			throws SystemException, ApplicativeException {
		// MaintenancePlanDto mpDto = session.getMpInteractive();
		// Quotation or Claim
		String type = mpExportXmlDto.getType();
		if (type == null)
		{
			type = CLAIM;
		}
		String currentLang = mpExportXmlDto.getIdLangue();
		// Business to get description and label
		TableTitleBusiness business = new TableTitleBusiness();
		ConsumableBusiness consBusiness = new ConsumableBusiness();
		MpOperationPartBusiness partBusiness = new MpOperationPartBusiness();

		String mpConfiguration = mpExportXmlDto.getConfiguration();

		// dealer language, EN, IT, FR, ES, DE
		List<String> languages = new ArrayList<>();
		languages.add(EN);
		languages.add(IT);
		languages.add(FR);
		languages.add(ES);
		languages.add(DE);
		if (!languages.contains(currentLang))
		{
			languages.add(currentLang);
		}

		/**
		 * XML document creation
		 * 
		 * <DMSExport>
		 */
		Element plan = new Element(DMS_EXPORT);

		// New JDOM Document based on root
		org.jdom.Document document = new org.jdom.Document(plan);

		/**
		 * <Header>
		 */
		Element header = new Element(HEADER);
		plan.addContent(header);
		Element context = new Element(CONTEXT);
		context.setAttribute(SOURCE, MP);
		if (type.equals(CLAIM))
		{
			context.setAttribute(CREATION_TIME, UtilDate.dateToString(mpExportXmlDto.getFailureDate(), "dd-MM-yyyy"));
		}
		else
		{
			context.setAttribute(CREATION_TIME, UtilDate.getDateDDMMYYYY_DASH());
		}
		context.setAttribute(ENGINE_VERSION, mpExportXmlDto.getSoftwareVersion());
		context.setAttribute(USER_ID, mpExportXmlDto.getUserID());
		context.setAttribute(ACTIVITY, type);
		header.addContent(context);
		Element vehicule = new Element(VEHICLE_DETAILS);
		vehicule.setAttribute(VIN, mpExportXmlDto.getVin());

		vehicule.setAttribute(SERIES, mpExportXmlDto.getSeries() != null ? mpExportXmlDto.getSeries() : EMPTY_STRING);
		vehicule.setAttribute(MODEL, mpExportXmlDto.getModel() != null ? mpExportXmlDto.getModel() : EMPTY_STRING);
		vehicule.setAttribute(MILEAGE,
				mpExportXmlDto.getActualMileage() != null ? mpExportXmlDto.getActualMileage() : "");
		vehicule.setAttribute(HOURS, mpExportXmlDto.getActualHour() != null ? mpExportXmlDto.getActualHour() : "");
		vehicule.setAttribute(USAGE, mpExportXmlDto.getUsage() != null ? mpExportXmlDto.getUsage() : "");
		vehicule.setAttribute(CONFIGURATION, mpConfiguration != null ? mpConfiguration : "");
		vehicule.setAttribute(START_WARRANTY_DATE, mpExportXmlDto.getWarrantyDate() != null
				? (new SimpleDateFormat(DATE_FORMAT).format(new Date(Long.parseLong(mpExportXmlDto.getWarrantyDate()))))
				: "");
		header.addContent(vehicule);
		/**
		 * <Claims>
		 */
		Element claims = new Element(CLAIMS);
		plan.addContent(claims);
		Element claim = null;
		Element mpOp = null;
		Element partElement = null;
		Element consum = null;
		String operationType = "";
		// For all claims
		List<MpIntervalOperationDto> intervalsList = mpExportXmlDto.getMpIntervalOperations();
		List<MpOperationDto> operations = null;
		List<MpOperationPartDto> mergedPartsList = null;
		List<MpOperationConsumableDto> mergedConsList = null;
		List<MpOperationDto> mergedOperations = new ArrayList<>();
		List<MpFrequencyDto> frequencyList = new ArrayList<>();
		MpFrequencyDto mpFrequencyDto = null;
		StringBuilder failureCode = null;
		String code = EMPTY_STRING;
		for (MpIntervalOperationDto interval : intervalsList)
		{
			failureCode = new StringBuilder();
			if (null != interval.getCoupon())
			{
				code = interval.getCoupon();
				failureCode.append("000");
				failureCode.append(interval.getCoupon().substring(0, (interval.getCoupon().length() - 3)));
				failureCode.append(" ");
				failureCode.append("0MM1");

			}
			else
			{
				failureCode.append(EMPTY_STRING);
			}
			claim = new Element(CLAIM);
			claim.setAttribute(CODE, code);
			claim.setAttribute(TYPE, interval.getType() != null ? interval.getType() : EMPTY_STRING);
			claim.setAttribute(FREQUENCY_LOWER, interval.getCode() != null ? interval.getCode() : EMPTY_STRING);
			claim.setAttribute(REPAIR_TIME,
					interval.getRepairTime() != null ? interval.getRepairTime().toString() : EMPTY_STRING);
			claim.setAttribute(FAILURE_CODE, failureCode.toString());
			claims.addContent(claim);
			mpFrequencyDto = new MpFrequencyDto(interval.getCode(), interval.getFrequency());
			mpFrequencyDto.setMpInterval(interval);
			frequencyList.add(mpFrequencyDto);

			// For all MP operations
			operations = interval.getOperations();

			//group the parts and consumables inside the same operation code
			//can happen to have 2 operation with the same operation code but with different location (ice code)
			List<MpOperationDto> operationListMerged = createOperationListMerged(operations);

			for (MpOperationDto op : operationListMerged)
			{
				mpOp = new Element(MPOPERATION);
				if (null != op.getMicroOperation())
				{
					operationType = MICRO;
					mpOp.setAttribute(CODE, op.getMicroOperation());
				}
				else
				{
					operationType = SRT;
					mpOp.setAttribute(CODE, op.getSrtOperation());
				}
				mpOp.setAttribute("type", operationType);
				claim.addContent(mpOp);

				mergedPartsList = op.getMergedParts();
				// For all Parts
				for (MpOperationPartDto part : mergedPartsList)
				{
					// add part in xml only if it is selected
					if (part.isSelected() || type.equals(QUOTATION))
					{
						if (part.getReplacedByList() != null && !part.getReplacedByList().isEmpty() && part.isSelected())
						{
							for (MpOperationPartDto partReplace : part.getReplacedByList())
							{
								partElement = new Element(PART);
								partElement.setAttribute(PN, partReplace.getCodePart() != null ? partReplace.getCodePart() : EMPTY_STRING);
								String partQty = EMPTY_STRING;
								if (partReplace.getQuantity() != null)
								{
									partQty = String.valueOf(partReplace.getQuantity());
								}
								partElement.setAttribute(QUANTITY, partQty);
								mpOp.addContent(partElement);
							}
						}
						else
						{
							partElement = new Element(PART);
							partElement.setAttribute(PN, part.getCodePart() != null ? part.getCodePart() : EMPTY_STRING);
							partElement.setAttribute(QUANTITY,
									part.getQuantity() != null ? part.getQuantity().toString() : EMPTY_STRING);
							// If the kit is preferred, adding of the "Preferred" attribute
							if (part.isKitPreferred())
							{
								partElement.setAttribute(PREFERRED, "Yes");
							}
							mpOp.addContent(partElement);
						}
					}
				}

				mergedConsList = op.getMergedConsumables();
				// For all Consumables
				for (MpOperationConsumableDto cons : mergedConsList)
				{
					if (cons.isSelected() || type.equals(QUOTATION))
					{
						consum = new Element(CONSUMABLE);
						consum.setAttribute(ID,
								cons.getIdConsumable() != null ? cons.getIdConsumable().toString() : EMPTY_STRING);
						consum.setAttribute(PN, cons.getPartnumber() != null ? cons.getPartnumber() : EMPTY_STRING);
						consum.setAttribute(QUANTITY, String.valueOf(cons.getQty()));
						consum.setAttribute(UNIT, (cons.getUnit() != null ? cons.getUnit() : EMPTY_STRING));

						mpOp.addContent(consum);
					}
				}

				if (!existsOperationInList(mergedOperations, op))
				{
					mergedOperations.add(op);
				}
			}

		}

		/**
		 * <Additional_infos>
		 */
		Element addInfo = new Element(ADDITIONAL_INFOS);
		plan.addContent(addInfo);
		Element opList = null;
		Element partList = null;
		Element consList = null;
		Element freqList = null;
		Element freqElement = null;
		Element kitList = null;
		Element kitElement = null;
		Element op = null;
		Element consElement = null;
		Element descr = null;
		String descriptionId = null;
		List<MpOperationPartDto> partsList = new ArrayList<>();
		HashMap<String, MpOperationPartDto> partsHmap = new HashMap<>();
		List<MpOperationConsumableDto> consumablesList = new ArrayList<>();
		HashMap<Long, MpOperationConsumableDto> consumablesHmap = new HashMap<>();
		List<TableTitleDto> opDescriptionList = null;
		List<ConsumableDto> consDescriptionList = null;
		List<MpPartDescriptionDto> partDescriptionList = null;
		opList = new Element(OPERATION_LIST);
		addInfo.addContent(opList);
		// For all operations
		for (MpOperationDto operation : mergedOperations)
		{
			op = new Element(OPERATION);
			if (null != operation.getMicroOperation())
			{
				// "Micro";
				op.setAttribute(CODE, operation.getMicroOperation());
			}
			else
			{
				// "SRT";
				op.setAttribute(CODE, operation.getSrtOperation());
			}
			opList.addContent(op);
			// For all descriptions
			descriptionId = operation.getOperationLabelId();
			if (null != descriptionId)
			{
				opDescriptionList = business.getListTableTitle(descriptionId);
			}
			if (null != opDescriptionList && !opDescriptionList.isEmpty())
			{
				for (String lang : languages)
				{
					for (TableTitleDto opDescr : opDescriptionList)
					{
						if (opDescr.getIdLanguage().equals(lang))
						{
							descr = new Element(LABEL);
							descr.setAttribute(LANGUAGE, lang);
							descr.setAttribute(VALUE, StringEscapeUtils.unescapeHtml(opDescr.getMessage()));
							op.addContent(descr);
						}
					}
				}
			}
			descriptionId = operation.getOperationDescriptionId();
			opDescriptionList = null;
			if (null != descriptionId)
			{
				opDescriptionList = business.getListTableTitle(descriptionId);
			}
			if (null != opDescriptionList && !opDescriptionList.isEmpty())
			{
				for (String lang : languages)
				{
					for (TableTitleDto opDescr : opDescriptionList)
					{
						if (opDescr.getIdLanguage().equals(lang))
						{
							descr = new Element(DESCRIPTION);
							descr.setAttribute(LANGUAGE, lang);
							descr.setAttribute(VALUE, StringEscapeUtils.unescapeHtml(opDescr.getMessage()));
							op.addContent(descr);
						}
					}
				}
			}
			List<String> parts = new ArrayList<>();
			for (MpOperationPartDto mpOpDto : operation.getParts())
			{
				if (mpOpDto.getReplacedByList() != null && !mpOpDto.getReplacedByList().isEmpty() && mpOpDto.isSelected())
				{
					//get the part replace if part selected
					for (MpOperationPartDto partReplace : mpOpDto.getReplacedByList())
					{
						if (!parts.contains(partReplace.getCodePart()))
						{
							parts.add(partReplace.getCodePart());
							partsList.add(partReplace);
						}
					}
				}
				else if (!parts.contains(mpOpDto.getCodePart()) && (mpOpDto.isSelected() || type.equals(QUOTATION)))
				{
					parts.add(mpOpDto.getCodePart());
					partsList.add(mpOpDto);
				}
			}
			consumablesList.addAll(operation.getConsumables());
		}

		partList = new Element(PART_LIST);
		addInfo.addContent(partList);
		// For all Parts
		for (MpOperationPartDto part : partsList)
		{

			// add part in xml only if it is selected
			if (!partsHmap.containsKey(part.getCodePart()))
			{
				partsHmap.put(part.getCodePart(), part);
				partElement = new Element(PART);
				partElement.setAttribute(PN, part.getCodePart());
				partList.addContent(partElement);
				// For all descriptions
				partDescriptionList = partBusiness.getPartsByCode(part.getCodePart());
				if (null != partDescriptionList && !partDescriptionList.isEmpty())
				{
					for (String lang : languages)
					{
						for (MpPartDescriptionDto partDescr : partDescriptionList)
						{
							if (partDescr.getDescLanguage().equals(lang))
							{
								descr = new Element(DESCRIPTION);
								descr.setAttribute(LANGUAGE, lang);
								descr.setAttribute(VALUE, StringEscapeUtils.unescapeHtml(partDescr.getDescription()));
								partElement.addContent(descr);
							}
						}
					}
				}
				else if (part.getPartLabel() != null && !part.getPartLabel().equals(""))
				{
					// exists only in EN (for supersession the label has been already taken from MP_PART_NUMBER_DETAIL)
					descr = new Element(DESCRIPTION);
					descr.setAttribute(LANGUAGE, EN);
					descr.setAttribute(VALUE, StringEscapeUtils.unescapeHtml(part.getPartLabel()));
					partElement.addContent(descr);
				}
			}

		}

		consList = new Element(CONSUMABLE_LIST);
		addInfo.addContent(consList);
		// For all cons
		MpOperationConsumableBusiness mpOperationConsumableBusiness = new MpOperationConsumableBusiness();
		//MSH
		for (MpOperationConsumableDto cons : consumablesList)
		{
			if (cons.isSelected() || type.equals(QUOTATION))
			{
				// add part in xml only if it is selected
				if (!consumablesHmap.containsKey(cons.getIdConsumable()))
				{
					// MSH - Consumable changes.
					MpOperationConsumableDto newDto = mpOperationConsumableBusiness.getConsumablesOccByConsId(cons.getIdConsumable(), false, mpExportXmlDto.getIceContextDto());

					if (newDto == null)
					{
						newDto = mpOperationConsumableBusiness.getConsumablesOccByConsId(cons.getIdConsumable(), true, mpExportXmlDto.getIceContextDto());
					}

					consumablesHmap.put(cons.getIdConsumable(), cons);
					consElement = new Element(CONSUMABLE);
					// MSH Changes for Consumable.
					if (newDto != null && newDto.getPartnumber() != null)
					{
						consElement.setAttribute(PN, newDto.getPartnumber());
					}
					else
					{
						consElement.setAttribute(PN, cons.getPartnumber() != null ? cons.getPartnumber() : EMPTY_STRING);
					}

					consElement.setAttribute(ID,
							cons.getIdConsumable() != null ? cons.getIdConsumable().toString() : EMPTY_STRING);
					consList.addContent(consElement);
					// For all descriptions
					consDescriptionList = consBusiness.getConsumableById(cons.getIdConsumable().toString());
					if (null != consDescriptionList && !consDescriptionList.isEmpty())
					{
						for (String lang : languages)
						{
							for (ConsumableDto consDescr : consDescriptionList)
							{
								if (consDescr.getIdLanguage().equals(lang))
								{
									descr = new Element(LABEL);
									descr.setAttribute(LANGUAGE, lang);
									// MSH
									if (newDto != null && newDto.getDescription() != null)
									{
										descr.setAttribute(VALUE, new StringBuilder().append(consDescr.getGroup()).append(" - ")
												.append(newDto.getDescription()).toString());
									}
									else
									{
										descr.setAttribute(VALUE, new StringBuilder().append(consDescr.getGroup()).append(" - ")
												.append(consDescr.getName()).toString());
									}

									consElement.addContent(descr);
								}
							}
						}
						for (String lang : languages)
						{
							for (ConsumableDto consDescr : consDescriptionList)
							{
								if (consDescr.getIdLanguage().equals(lang) && consDescr.getDescription() != null)
								{
									descr = new Element(DESCRIPTION);
									descr.setAttribute(LANGUAGE, lang);
									descr.setAttribute(VALUE, StringEscapeUtils.unescapeHtml(consDescr.getDescription()));;
									consElement.addContent(descr);
								}
							}
						}
					}
				}
			}
		}

		freqList = new Element(FREQUENCY_LIST);
		addInfo.addContent(freqList);
		// For all freq
		HashMap<String, String> intervalsId = null;
		String freqDescription = null;
		MpIntervalDto mpInterval = null;
		List<TableTitleDto> commentsList = null;

		String unitKey = new String();
		if (!isIveco)
		{
			unitKey = MaintenanceService.getUnitKeyBySerie(mpExportXmlDto.getIceContextDto().getBrand().getIceCode(), mpExportXmlDto.getIceContextDto().getType().getIceCode(),
					mpExportXmlDto.getIceContextDto().getProduct().getIceCode(), mpExportXmlDto.getIceContextDto().getSeries().getIceCode());
		}

		for (MpFrequencyDto freq : frequencyList)
		{
			mpInterval = freq.getMpInterval();
			freqElement = new Element(FREQUENCY_UPPER);
			freqElement.setAttribute(ID_FREQUENCY, freq.getId() != null ? freq.getId() : EMPTY_STRING);
			freqDescription = freq.getDescription();
			freqList.addContent(freqElement);
			// For all descriptions
			for (String lang : languages)
			{
				intervalsId = MaintenancePlanBusiness.setIntervalElementList(mpExportXmlDto.getIntervalElementList(),
						mpExportXmlDto.getDefaultLanguage(), lang, unitKey);
				freqDescription = MaintenanceUtil.getTitle(mpInterval, intervalsId, isIveco, unitKey);
				descr = new Element(DESCRIPTION);
				descr.setAttribute(LANGUAGE, lang);
				descr.setAttribute(VALUE, freqDescription != null ? freqDescription : freq.getDescription());
				freqElement.addContent(descr);
			}
			// For all comments
			commentsList = null;
			if (null != mpInterval.getCommentId())
			{
				commentsList = business.getListTableTitle(mpInterval.getCommentId().toString());
			}
			if (null != commentsList && !commentsList.isEmpty())
			{
				for (String lang : languages)
				{
					for (TableTitleDto comment : commentsList)
					{
						if (comment.getIdLanguage().equals(lang))
						{
							descr = new Element(COMMENT);
							descr.setAttribute(LANGUAGE, lang);
							descr.setAttribute(VALUE, comment.getMessage());
							freqElement.addContent(descr);
						}
					}
				}
			}
		}

		//  Kit Composition

		List<MpOperationPartDto> mpOperationParts = getPartsFromOperationsList(mergedOperations);

		Map<String, List<MpKitCompositionDto>> mapMpKitCompoByKitCode = getMapKitCompoByKitCode(mpOperationParts, kitCodeByPartNumber);

		if (!mapMpKitCompoByKitCode.keySet().isEmpty())
		{

			// DMS
			// MAY Kit Composition
			// For each kit characterized as "Preferred, its composition (part number list)
			// is described
			kitList = new Element(KIT_LIST);
			addInfo.addContent(kitList);
			// For all Parts
			for (Map.Entry<String, List<MpKitCompositionDto>> entry : mapMpKitCompoByKitCode.entrySet())
			{
				String kitCode = entry.getKey();
				// Composition of the kit
				List<MpKitCompositionDto> kitCompositionList = entry.getValue();

				// If the kit is "preferred", its composition is added
				kitElement = new Element(KIT);
				kitElement.setAttribute(KITPN, kitCode);
				kitList.addContent(kitElement);

				// For all the parts which compose the kit
				for (MpKitCompositionDto partKit : kitCompositionList)
				{
					descr = new Element(PART);
					descr.setAttribute(PN, partKit.getCompPnCode());
					descr.setAttribute(QUANTITY,
							partKit.getCompPnQty() != null ? partKit.getCompPnQty().toString() : EMPTY_STRING);
					kitElement.addContent(descr);
				}

			}

		}

		// END MAY Kit Composition

		return document;
	}

	/**
	 * Test if the op is in the list.
	 * 
	 * @param mergedOperations the list of op
	 * @param operation the op to test
	 * @return true if the op is in the list
	 */
	private boolean existsOperationInList(List<MpOperationDto> mergedOperations, MpOperationDto operation) {
		boolean exists = false;
		for (MpOperationDto op : mergedOperations)
		{
			if (null != op.getMicroOperation() && null != operation.getMicroOperation()
					&& op.getMicroOperation().equals(operation.getMicroOperation()))
			{
				exists = true;
				break;
			}
			if (null != op.getSrtOperation() && null != operation.getSrtOperation()
					&& op.getSrtOperation().equals(operation.getSrtOperation()))
			{
				exists = true;
				break;
			}

		}

		return exists;
	}
}