package capgemini.cnh.maintenanceservice.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.util.ConnectedTypeEnum;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * @author thlarzab
 *
 */

public class MPExportXMLDto {

	private String idLangue;

	private String softwareVersion;

	private String userID;

	private String vin;

	private String defaultLanguage;

	private String configuration;

	private String series;

	private String model;

	private String actualMileage;

	private String actualHour;

	private String usage;

	private String warrantyDate;

	private String warrantyType;

	private String type;

	private String bmIceCode;

	private String contractNb;

	private MpPlanDto plan;

	private ArrayList<MpIntervalOperationDto> intervalsList;

	private ArrayList<MpIntervalOperationDto> intervalsListRecommended;

	private HashMap<String, HashMap<String, String>> intervalElementList;

	private ArrayList<MpHistoryIntervalDto> historyList;

	private String contractGroup;

	private Long extPlanId;

	private String planId;

	private boolean heavyFlexContract;

	private Date failureDate;

	private IceContextDto iceContextDto = null;

	public MPExportXMLDto(MaintenancePlanDto mpDto, MyVehicleContextDto myVehicleContextDto, String type, String softVersion, String userId) {
		iceContextDto = myVehicleContextDto.getContextDto();

		softwareVersion = softVersion;
		userID = userId;
		bmIceCode = null;
		if (iceContextDto != null && iceContextDto.getModel() != null)
		{
			if (iceContextDto.getSeries() != null && iceContextDto.getProduct() != null && iceContextDto.getType() != null && iceContextDto.getBrand() != null)
			{
				bmIceCode = iceContextDto.getBrand().getIceCode() + "." +
						iceContextDto.getType().getIceCode() + "." +
						iceContextDto.getProduct().getIceCode() + "." +
						iceContextDto.getSeries().getIceCode();
				if (iceContextDto.getModel() != null)
				{
					bmIceCode += "." + iceContextDto.getModel().getIceCode();
				}
			}
			idLangue = iceContextDto.getLanguage().getIdlanguage();
			defaultLanguage = iceContextDto.getDefaultLanguage();
			if (iceContextDto.getLanguage() != null)
			{
				if (mpDto.getMpPlanList() == null || mpDto.getMpPlanList().isEmpty())
				{
					List<MpPlanDto> mpPlanList = new ArrayList<>();
					mpPlanList.add(mpDto.getMpPlanSelected());
					mpDto.setMpPlanList(mpPlanList);
				}
				configuration = mpDto.getConfiguration(myVehicleContextDto.getProductConfiguration(), iceContextDto.getLanguage());
			}
		}
		else
		{
			idLangue = Constants.ENGLISH;
			defaultLanguage = Constants.ENGLISH;
		}
		vin = myVehicleContextDto.getPinVin();

		series = mpDto.getSeries();
		model = mpDto.getModel();
		actualMileage = mpDto.getActualMileage();
		actualHour = mpDto.getActualHour();
		usage = mpDto.getUsageLabel();
		warrantyDate = mpDto.getWarrantyDate();

		this.heavyFlexContract = false;
		if (myVehicleContextDto.getMpContract() != null && myVehicleContextDto.getMpContract().getActiveMpContract() != null)
		{
			this.warrantyType = myVehicleContextDto.getMpContract().getActiveMpContract().getTypeContract();
			this.contractNb = myVehicleContextDto.getMpContract().getActiveMpContract().getContractNumber();
			this.contractGroup = myVehicleContextDto.getMpContract().getActiveMpContract().getMpGroupConf();
			if (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(myVehicleContextDto.getMpContract().getActiveMpContract().getTypeContract()))
			{
				this.heavyFlexContract = true;
			}
		}
		plan = mpDto.getMpPlanSelected();
		historyList = (ArrayList<MpHistoryIntervalDto>) ((ArrayList<MpHistoryIntervalDto>) mpDto.getListHistory()).clone();
		intervalsList = (ArrayList<MpIntervalOperationDto>) ((ArrayList<MpIntervalOperationDto>) mpDto.getMpIntervalOperations()).clone();
		intervalsListRecommended = (ArrayList<MpIntervalOperationDto>) ((ArrayList<MpIntervalOperationDto>) mpDto.getMpIntervalOperationsRecommended()).clone();
		intervalElementList = (HashMap<String, HashMap<String, String>>) mpDto.getIntervalElementList().clone();
		this.type = type;
		this.extPlanId = mpDto.getPlanExternalId();
		this.planId = mpDto.getPlanId();

	}

	public String getDefaultLanguage() {
		return defaultLanguage;
	}

	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}

	public String getIdLangue() {
		return idLangue;
	}

	public void setIdLangue(String idLangue) {
		this.idLangue = idLangue;
	}

	public String getSoftwareVersion() {
		return softwareVersion;
	}

	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getConfiguration() {
		return configuration;
	}

	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getActualMileage() {
		return actualMileage;
	}

	public void setActualMileage(String actualMileage) {
		this.actualMileage = actualMileage;
	}

	public String getActualHour() {
		return actualHour;
	}

	public void setActualHour(String actualHour) {
		this.actualHour = actualHour;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	public String getWarrantyDate() {
		return warrantyDate;
	}

	public void setWarrantyDate(String warrantyDate) {
		this.warrantyDate = warrantyDate;
	}

	/**
	 * @return the warrantyType
	 */
	public String getWarrantyType() {
		return warrantyType;
	}

	/**
	 * @param warrantyType the warrantyType to set
	 */
	public void setWarrantyType(String warrantyType) {
		this.warrantyType = warrantyType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<MpIntervalOperationDto> getMpIntervalOperations() {
		return intervalsList;
	}

	public void setIntervalsList(ArrayList<MpIntervalOperationDto> intervalsList) {
		this.intervalsList = intervalsList;
	}

	/**
	 * @return the intervalsListRecommended
	 */
	public ArrayList<MpIntervalOperationDto> getIntervalsListRecommended() {
		return intervalsListRecommended;
	}

	/**
	 * @param intervalsListRecommended the intervalsListRecommended to set
	 */
	public void setIntervalsListRecommended(ArrayList<MpIntervalOperationDto> intervalsListRecommended) {
		this.intervalsListRecommended = intervalsListRecommended;
	}

	public HashMap<String, HashMap<String, String>> getIntervalElementList() {
		return intervalElementList;
	}

	public void setIntervalElementList(HashMap<String, HashMap<String, String>> intervalElementList) {
		this.intervalElementList = intervalElementList;
	}

	public String getBmIceCode() {
		return bmIceCode;
	}

	public void setBmIceCode(String bmIceCode) {
		this.bmIceCode = bmIceCode;
	}

	public String getContractNb() {
		return contractNb;
	}

	public void setContractNb(String contractNb) {
		this.contractNb = contractNb;
	}

	public MpPlanDto getPlan() {
		return plan;
	}

	public void setPlan(MpPlanDto plan) {
		this.plan = plan;
	}

	public ArrayList<MpHistoryIntervalDto> getHistoryList() {
		return historyList;
	}

	public void setHistoryList(ArrayList<MpHistoryIntervalDto> listHistory) {
		this.historyList = listHistory;
	}

	public String getContractGroup() {
		return contractGroup;
	}

	/**
	 * @param contractGroup
	 */
	public void setContractGroup(String contractGroup) {
		this.contractGroup = contractGroup;
	}

	public Long getExtPlanId() {
		return extPlanId;
	}

	public void setExtPlanId(Long extPlanId) {
		this.extPlanId = extPlanId;
	}

	public boolean isHeavyFlexContract() {
		return heavyFlexContract;
	}

	public void setHeavyFlexContract(boolean heavyFlexContract) {
		this.heavyFlexContract = heavyFlexContract;
	}

	/**
	 * @return the planId
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * Getter pour failureDate.
	 *
	 * @return failureDate
	 */
	public Date getFailureDate() {
		return failureDate;
	}

	/**
	 * Setter pour failureDate.
	 *
	 * @param failureDate failureDate à positionner.
	 */
	public void setFailureDate(Date failureDate) {
		this.failureDate = failureDate;
	}

	/**
	 * Getter pour iceContextDto.
	 *
	 * @return iceContextDto
	 */
	public IceContextDto getIceContextDto() {
		return iceContextDto;
	}

	/**
	 * Setter pour iceContextDto.
	 *
	 * @param iceContextDto iceContextDto à positionner.
	 */
	public void setIceContextDto(IceContextDto iceContextDto) {
		this.iceContextDto = iceContextDto;
	}

}