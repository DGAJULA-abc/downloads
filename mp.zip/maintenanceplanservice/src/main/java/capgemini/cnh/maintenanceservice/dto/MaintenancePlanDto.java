package capgemini.cnh.maintenanceservice.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.common.IceConstantes;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.LanguageDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpStdOilDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * Maintenance plan DTO for session persistent data storage.
 * 
 * @author dbabillo
 */
public class MaintenancePlanDto extends Dto {

	/**
	 * Default serial identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Token used to build an interval token.
	 */
	private HashMap<String, HashMap<String, String>> intervalElementList = new HashMap<String, HashMap<String, String>>();

	/**
	 * Maintenance plan identifier.
	 */
	private String planId = null;

	/**
	 * Actual mileage.
	 */
	private String actualMileage = null;

	/**
	 * Actual hour.
	 */
	private String actualHour = null;

	/**
	 * Warranty date for a V.I.N.
	 */
	private MpHistoryWarrantyDto warranty = null;

	/**
	 * Interval list.
	 */
	private List<MpIntervalDto> listIntervals = null;

	/**
	 * History list once fully completed and valid.
	 */
	private List<MpHistoryIntervalDto> listHistory = null;

	/**
	 * HTML of operation for PDF generation.
	 */
	private String html = null;

	/**
	 * plan selected by the dealer (if contract defined in the contract).
	 */
	private MpPlanDto mpPlanSelected = null;

	/**
	 * list of plan applicable for the current selected configuration.
	 */
	private List<MpPlanDto> mpPlanList = null;

	/**
	 * list of plan applicable for the current selected configuration before modifying configuration.
	 */
	private List<MpPlanDto> mpPreviousPlanList = new ArrayList<MpPlanDto>();

	/**
	 * previous configs Selection.
	 */
	private Map<String, ConfigurationDto> previousConfigsSelection = new HashMap<String, ConfigurationDto>();

	/**
	 * usage label .
	 */
	private String usageLabel = null;

	/**
	 * Warranty start date.
	 */
	private String warrantyDate = null;

	/**
	 * mpIntervalOperations.
	 */
	List<MpIntervalOperationDto> mpIntervalOperations = null;

	/**
	 * mpIntervalOperationsRecommended.
	 */
	List<MpIntervalOperationDto> mpIntervalOperationsRecommended = null;

	/**
	 * Predefined Mission Id.
	 */
	private Long predefinedMissionId = null;

	/**
	 * Configuration.
	 */
	private String configuration = null;

	/**
	 * Series.
	 */
	private String series = null;

	/**
	 * hasContract.
	 */
	private boolean hasContract = false;

	/**
	 * Maintenance external plan identifier.
	 */
	private Long planExternalId = null;

	/**
	 * Warranty start date.
	 */
	private Date warrantyStartDate = null;

	/**
	 * List of vins.
	 */
	private List<String> listVin = null;

	/**
	 * current date from the front.
	 */
	String nowDate = null;

	/**
	 * list of flexible coupons.
	 */
	Map<String, MpFlexCouponDto> flexibleCoupons = new HashMap<String, MpFlexCouponDto>();

	/**
	 * Store list of standard oil by project whatever the configuration selection.
	 */
	private Map<Integer, List<MpStdOilDto>> mapStdOilByProject = new HashMap<Integer, List<MpStdOilDto>>();

	private HashMap<MpType, Long> delta = new HashMap<MpType, Long>();

	/**
	 * Model.
	 */
	private String model = null;

	/**
	 * Model.
	 */
	boolean historyIsModified = false;

	/**
	 * has Valid History.
	 */
	boolean hasValidHistory = false;

	/**
	 * The next stop coming from the UCR webservice.
	 */
	private List<MpNextStopDto> ucrNextStopList = new ArrayList<>();

	/**
	 * Information about the minimum next stop from UCR.
	 */
	private MpNextStopMinDto ucrNextStopMin = new MpNextStopMinDto();

	/**
	 * True if the workshop has a DJC subscription.
	 */
	private boolean djc = false;

	/**
	 * Default constructor.
	 */
	public MaintenancePlanDto() {
		super();
	}

	/**
	 * @return the intervalElementList
	 */
	public HashMap<String, HashMap<String, String>> getIntervalElementList() {
		return intervalElementList;
	}

	/**
	 * @param intervalElementList the intervalElementList to set
	 */
	public void setIntervalElementList(HashMap<String, HashMap<String, String>> intervalElementList) {
		this.intervalElementList = intervalElementList;
	}

	/**
	 * @return the planId
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * @return the actualMileage
	 */
	public String getActualMileage() {
		return actualMileage;
	}

	/**
	 * @param actualMileage the actualMileage to set
	 */
	public void setActualMileage(String actualMileage) {
		this.actualMileage = actualMileage;
	}

	/**
	 * @return the actualHour
	 */
	public String getActualHour() {
		return actualHour;
	}

	/**
	 * @param actualHour the actualHour to set
	 */
	public void setActualHour(String actualHour) {
		this.actualHour = actualHour;
	}

	/**
	 * @return the warranty
	 */
	public MpHistoryWarrantyDto getWarranty() {
		return warranty;
	}

	/**
	 * @return true if a V.I.N. is set, false otherwise
	 */
	public boolean hasVin() {
		return (warranty != null && warranty.getVin() != null && this.warranty.getVin().equals("") == false);
	}

	/**
	 * @param warranty the warranty to set
	 */
	public void setWarranty(MpHistoryWarrantyDto warranty) {
		this.warranty = warranty;
	}

	/**
	 * @return the listIntervals
	 */
	public List<MpIntervalDto> getListIntervals() {
		return listIntervals;
	}

	/**
	 * @param listIntervals the listIntervals to set
	 */
	public void setListIntervals(List<MpIntervalDto> listIntervals) {
		this.listIntervals = listIntervals;
	}

	/**
	 * @return the html
	 */
	public String getHtml() {
		return html;
	}

	/**
	 * @param html the html to set
	 */
	public void setHtml(String html) {
		this.html = html;
	}

	/**
	 * @return the mpPlanList
	 */
	public List<MpPlanDto> getMpPlanList() {
		return mpPlanList;
	}

	/**
	 * @param mpPlanList the mpPlanList to set
	 */
	public void setMpPlanList(List<MpPlanDto> mpPlanList) {
		this.mpPlanList = mpPlanList;
	}

	/**
	 * Getter pour mpPlanSelected.
	 *
	 * @return mpPlanSelected
	 */
	public MpPlanDto getMpPlanSelected() {
		return mpPlanSelected;
	}

	/**
	 * Setter pour mpPlanSelected.
	 *
	 * @param mpPlanSelected mpPlanSelected à positionner.
	 */
	public void setMpPlanSelected(MpPlanDto mpPlanSelected) {
		this.mpPlanSelected = mpPlanSelected;
	}

	/**
	 * @param context current application context from UserSession
	 * @return true if the user can save history interval, false otherwise
	 */
	public boolean hasRightToSave(IceContextDto context) {
		return (this.hasVin() && (context.isInternalUser() == false || (context.isInternalUser() == true && context.getAccessMode() == IceConstantes.ACCESS_MODE_DRAFT)));
//				&& !this.djc);  // let the is DJC dealer save in the IMP
	}

	/**
	 * @return the mpPreviousPlanList
	 */
	public List<MpPlanDto> getMpPreviousPlanList() {
		return mpPreviousPlanList;
	}

	/**
	 * @param mpPreviousPlanList the mpPreviousPlanList to set
	 */
	public void setMpPreviousPlanList(List<MpPlanDto> mpPreviousPlanList) {
		this.mpPreviousPlanList = mpPreviousPlanList;
	}

	/**
	 * @return the previousConfigsSelection
	 */
	public Map<String, ConfigurationDto> getPreviousConfigsSelection() {
		return previousConfigsSelection;
	}

	/**
	 * @param previousConfigsSelection the previousConfigsSelection to set
	 */
	public void setPreviousConfigsSelection(Map<String, ConfigurationDto> previousConfigsSelection) {
		this.previousConfigsSelection = previousConfigsSelection;
	}

	/**
	 * @return the listHistory
	 */
	public List<MpHistoryIntervalDto> getListHistory() {
		return listHistory;
	}

	/**
	 * @param listHistory the listHistory to set
	 */
	public void setListHistory(List<MpHistoryIntervalDto> listHistory) {
		this.listHistory = listHistory;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder()
				.append("intervals: ").append(this.listIntervals).append("\n")
				.append("plan: ").append(this.planId).append("\n")
				.append("plans: ").append(this.mpPlanList).append("\n")
				.append("hour: ").append(this.actualHour).append("\n")
				.append("mileage: ").append(this.actualMileage).append("\n")
				.append("warranty: ").append(this.warranty).append("\n");
		return (result.toString());
	}

	/**
	 * @return the usageLabel
	 */
	public String getUsageLabel() {
		return usageLabel;
	}

	/**
	 * @param usageLabel the usageLabel to set
	 */
	public void setUsageLabel(String usageLabel) {
		this.usageLabel = usageLabel;
	}

	/**
	 * @return the warrantyDate
	 */
	public String getWarrantyDate() {
		return warrantyDate;
	}

	/**
	 * @param warrantyDate the warrantyDate to set
	 */
	public void setWarrantyDate(String warrantyDate) {
		this.warrantyDate = warrantyDate;
	}

	/**
	 * @return the mpIntervalOperations
	 */
	public List<MpIntervalOperationDto> getMpIntervalOperations() {
		return mpIntervalOperations;
	}

	/**
	 * @param mpIntervalOperations the mpIntervalOperations to set
	 */
	public void setMpIntervalOperations(List<MpIntervalOperationDto> mpIntervalOperations) {
		this.mpIntervalOperations = mpIntervalOperations;
	}

	/**
	 * @return the mpIntervalOperations
	 */
	public List<MpIntervalOperationDto> getMpIntervalOperationsRecommended() {
		return mpIntervalOperationsRecommended;
	}

	/**
	 * @param mpIntervalOperations the mpIntervalOperations to set
	 */
	public void setMpIntervalOperationsRecommended(List<MpIntervalOperationDto> mpIntervalOperationsRecommended) {
		this.mpIntervalOperationsRecommended = mpIntervalOperationsRecommended;
	}

	/**
	 * @return the predefinedMissionId
	 */
	public Long getPredefinedMissionId() {
		return predefinedMissionId;
	}

	/**
	 * @param predefinedMissionId the predefinedMissionId to set
	 */
	public void setPredefinedMissionId(Long predefinedMissionId) {
		this.predefinedMissionId = predefinedMissionId;
	}

	/**
	 * @return the configuration
	 */
	public String getConfiguration(ProductConfiguration productConfiguration, LanguageDto language) {
		int i = 0;
		MpPlanDto plan = null;
		while (i < this.mpPlanList.size())
		{
			plan = this.mpPlanList.get(i);
			if (plan.getId().toString().equals(this.planId) && plan.hasConfiguration())
			{
				this.configuration = plan.toConfigurationTitle(productConfiguration, language);
			}
			i++;
		}
		return this.configuration;
	}

	/**
	 * @return the series
	 */
	public String getSeries() {
		return series;
	}

	/**
	 * @param series the series to set
	 */
	public void setSeries(String series) {
		this.series = series;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the planExternalId
	 */
	public Long getPlanExternalId() {
		return planExternalId;
	}

	/**
	 * @param planExternalId the planExternalId to set
	 */
	public void setPlanExternalId(Long planExternalId) {
		this.planExternalId = planExternalId;
	}

	/**
	 * @return the mapStdOilByProject
	 */
	public Map<Integer, List<MpStdOilDto>> getMapStdOilByProject() {
		return mapStdOilByProject;
	}

	/**
	 * @param mapStdOilByProject the mapStdOilByProject to set
	 */
	public void setMapStdOilByProject(HashMap<Integer, List<MpStdOilDto>> mapStdOilByProject) {
		this.mapStdOilByProject = mapStdOilByProject;
	}

	/**
	 * @return the warrantyStartDate
	 */
	public Date getWarrantyStartDate() {
		return warrantyStartDate;
	}

	/**
	 * @param warrantyStartDate the warrantyStartDate to set
	 */
	public void setWarrantyStartDate(Date warrantyStartDate) {
		this.warrantyStartDate = warrantyStartDate;
	}

	public HashMap<MpType, Long> getDelta() {
		return delta;
	}

	/**
	 * @return the hasContract
	 */
	public boolean isHasContract() {
		return hasContract;
	}

	/**
	 * @param hasContract the hasContract to set
	 */
	public void setHasContract(boolean hasContract) {
		this.hasContract = hasContract;
	}

	/**
	 * Getter pour listVin.
	 *
	 * @return listVin
	 */
	public List<String> getListVin() {
		return listVin;
	}

	/**
	 * Setter pour listVin.
	 *
	 * @param listVin listVin à positionner.
	 */
	public void setListVin(List<String> listVin) {
		this.listVin = listVin;
	}

	/**
	 * Getter pour nowDate.
	 *
	 * @return nowDate
	 */
	public String getNowDate() {
		return nowDate;
	}

	/**
	 * Setter pour nowDate.
	 *
	 * @param nowDate nowDate à positionner.
	 */
	public void setNowDate(String nowDate) {
		this.nowDate = nowDate;
	}

	/**
	 * Getter pour flexibleCoupons.
	 *
	 * @return flexibleCoupons
	 */
	public Map<String, MpFlexCouponDto> getFlexibleCoupons() {
		return flexibleCoupons;
	}

	/**
	 * Setter pour flexibleCoupons.
	 *
	 * @param flexibleCoupons flexibleCoupons à positionner.
	 */
	public void setFlexibleCoupons(Map<String, MpFlexCouponDto> flexibleCoupons) {
		this.flexibleCoupons = flexibleCoupons;
	}

	/**
	 * Getter pour historyIsModified.
	 *
	 * @return historyIsModified
	 */
	public boolean isHistoryIsModified() {
		return historyIsModified;
	}

	/**
	 * Setter pour historyIsModified.
	 *
	 * @param historyIsModified historyIsModified à positionner.
	 */
	public void setHistoryIsModified(boolean historyIsModified) {
		this.historyIsModified = historyIsModified;
	}

	/**
	 * Getter pour hasValidHistory.
	 *
	 * @return hasValidHistory
	 */
	public boolean isHasValidHistory() {
		return hasValidHistory;
	}

	/**
	 * Setter pour hasValidHistory.
	 *
	 * @param hasValidHistory hasValidHistory à positionner.
	 */
	public void setHasValidHistory(boolean hasValidHistory) {
		this.hasValidHistory = hasValidHistory;
	}

	/**
	 * 
	 * @return ucrNextStopList
	 */
	public List<MpNextStopDto> getUcrNextStopList() {
		return ucrNextStopList;
	}

	/**
	 * 
	 * @param ucrNextStopList ucrNextStopList
	 */
	public void setUcrNextStopList(List<MpNextStopDto> ucrNextStopList) {
		this.ucrNextStopList = ucrNextStopList;
	}

	/**
	 * 
	 * @return ucrNextStopList
	 */
	public MpNextStopMinDto getUcrNextStopMin() {
		return ucrNextStopMin;
	}

	/**
	 * 
	 * @param ucrNextStopMin ucrNextStopList
	 */
	public void setUcrNextStopMin(MpNextStopMinDto ucrNextStopMin) {
		this.ucrNextStopMin = ucrNextStopMin;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isDjc() {
		return djc;
	}

	/**
	 * 
	 * @param isDJc
	 */
	public void setDjc(boolean djc) {
		this.djc = djc;
	}
}
