package capgemini.cnh.maintenanceservice.dto;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;

/**
 * Maintenance plan frequency DTO for session persistent data storage.
 * 
 * @author cblois
 */
public class MpFrequencyDto extends Dto {

	/**
	 * Default serial identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Maintenance plan frequency identifier.
	 */
	private String id = null;

	/**
	 * Maintenance plan frequency description.
	 */
	private String description = null;

	/**
	 * Maintenance plan interval.
	 */
	private MpIntervalOperationDto mpInterval = null;

	/**
	 * Default constructor.
	 */
	public MpFrequencyDto(String id, String description) {
		super();
		this.id = id;
		this.description = description;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the mpInterval
	 */
	public MpIntervalOperationDto getMpInterval() {
		return mpInterval;
	}

	/**
	 * @param mpInterval the mpInterval to set
	 */
	public void setMpInterval(MpIntervalOperationDto mpInterval) {
		this.mpInterval = mpInterval;
	}

}
