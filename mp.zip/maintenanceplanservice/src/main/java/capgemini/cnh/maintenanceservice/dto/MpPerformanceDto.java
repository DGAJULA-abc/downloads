package capgemini.cnh.maintenanceservice.dto;

import capgemini.cnh.framework.dto.Dto;

public class MpPerformanceDto extends Dto {

	/**
	 * TODO Supprimer le mpSearchDecorator de etimredesign
	 * 
	 */

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public MpPerformanceDto() {
		super();
	}

	/** Id. **/
	private String id = null;
	/** title. **/
	private String title = null;

	/**
	 * Constructor.
	 * 
	 * @param id perf
	 * @param title perf
	 */
	public MpPerformanceDto(String id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

}
