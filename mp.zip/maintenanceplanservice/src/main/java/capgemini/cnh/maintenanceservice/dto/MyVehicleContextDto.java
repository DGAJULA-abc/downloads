package capgemini.cnh.maintenanceservice.dto;

import java.io.Serializable;
import java.util.List;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.IwdSubscription;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.ice.dto.product.ModelDto;
import capgemini.cnh.mpbusiness.dto.MpContractDto;

/**
 * Manage context for My Maintenance.
 * Project TIDB WEB
 * 
 * @author cblois
 */
public class MyVehicleContextDto implements Serializable {

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The context.
	 */
	private IceContextDto contextDto = null;

	/**
	 * IWD Subscription.
	 */
	private IwdSubscription iwdSubscription = null;

	/**
	 * The pin or the vin.
	 */
	private String pinVin = null;

	/**
	 * The VCB.
	 */
	private String vcb = null;

	/**
	 * The full ice code, model ice code or technical type code.
	 */
	private String fullIceCode = null;

	/**
	 * The full ice code of the engine if any.
	 */
	private String engineFullIceCode = null;

	/**
	 * The warranty date.
	 */
	private String warrantyDate = null;

	/**
	 * Product configuration.
	 */
	private ProductConfiguration productConfiguration = null;

	/**
	 * The contract.
	 */
	private MpContractDto mpContract = null;

	/**
	 * The plan.
	 */
	private MaintenancePlanDto mpInteractive = null;

	/**
	 * The currentVehicleData .
	 */
	private CurrentVehicleDataDto currentVehicleData = null;

	/**
	 * The sap vehicle information.
	 */
	private ResponseData sapVehicleInformation = null;

	/**
	 * The message as a json string
	 */
	String messageJson = null;

	/**
	 * The 9 and 17 digit VIN.
	 */
	private List<String> vinList = null;

	/** List of models matching the PIN for the current brand. */
	private List<ModelDto> modelsListForPin = null;

	/**
	 * Creates a new instance of MyMaintenanceContextDto.
	 **/
	public MyVehicleContextDto() {
		this.iwdSubscription = new IwdSubscription();
	}

	/**
	 * @return the contextDto
	 */
	public IceContextDto getContextDto() {
		return contextDto;
	}

	/**
	 * @param contextDto the contextDto to set
	 */
	public void setContextDto(IceContextDto contextDto) {
		this.contextDto = contextDto;
	}

	/**
	 * @return the messageJson
	 */
	public String getMessageJson() {
		return messageJson;
	}

	/**
	 * @param message the messageJson to set
	 */
	public void setMessageJson(String messageJson) {
		this.messageJson = messageJson;
	}

	/**
	 * @return the vcb
	 */
	public String getVcb() {
		return vcb;
	}

	/**
	 * @param vcb the vcb to set
	 */
	public void setVcb(String vcb) {
		this.vcb = vcb;
	}

	/**
	 * @return the iwdSubscription
	 */
	public IwdSubscription getIwdSubscription() {
		return iwdSubscription;
	}

	/**
	 * @param iwdSubscription the iwdSubscription to set
	 */
	public void setIwdSubscription(IwdSubscription iwdSubscription) {
		this.iwdSubscription = iwdSubscription;
	}

	/**
	 * @return the pinVin
	 */
	public String getPinVin() {
		return pinVin;
	}

	/**
	 * @param pinVin the pinVin to set
	 */
	public void setPinVin(String pinVin) {
		this.pinVin = pinVin;
	}

	/**
	 * @return the fullIceCode
	 */
	public String getFullIceCode() {
		return fullIceCode;
	}

	/**
	 * @param fullIceCode the fullIceCode to set
	 */
	public void setFullIceCode(String fullIceCode) {
		this.fullIceCode = fullIceCode;
	}

	/**
	 * @return the productConfiguration
	 */
	public ProductConfiguration getProductConfiguration() {
		if (this.productConfiguration == null)
		{
			this.productConfiguration = new ProductConfiguration();
		}
		return this.productConfiguration;
	}

	/**
	 * @param productConfiguration the productConfiguration to set
	 */
	public void setProductConfiguration(ProductConfiguration productConfiguration) {
		this.productConfiguration = productConfiguration;
	}

	/**
	 * @return the mpContract
	 */
	public MpContractDto getMpContract() {
		return mpContract;
	}

	/**
	 * @param mpContract the mpContract to set
	 */
	public void setMpContract(MpContractDto mpContract) {
		this.mpContract = mpContract;
	}

	/**
	 * @return the mpInteractive
	 */
	public MaintenancePlanDto getMpInteractive() {
		return mpInteractive;
	}

	/**
	 * @param mpInteractive the mpInteractive to set
	 */
	public void setMpInteractive(MaintenancePlanDto mpInteractive) {
		this.mpInteractive = mpInteractive;
	}

	/**
	 * @return the sapVehicleInformation
	 */
	public ResponseData getSapVehicleInformation() {
		return sapVehicleInformation;
	}

	/**
	 * @param sapVehicleInformation the sapVehicleInformation to set
	 */
	public void setSapVehicleInformation(ResponseData sapVehicleInformation) {
		this.sapVehicleInformation = sapVehicleInformation;
	}

	/**
	 * @return the isConnectSOAPForRepHistory
	 */
	public boolean isConnectSOAPForRepHistory() {
		//return this.getSapVehicleInformation() != null && this.getSapVehicleInformation().getGeneral() != null && !this.getSapVehicleInformation().getGeneral().isEmpty();
		return this.getSapVehicleInformation() != null && this.getSapVehicleInformation().isMpRepairHistoFromSapOk();
	}

	/**
	 * @return the currentVehicleData
	 */
	public CurrentVehicleDataDto getCurrentVehicleData() {
		return currentVehicleData;
	}

	/**
	 * @param currentVehicleData the currentVehicleData to set
	 */
	public void setCurrentVehicleData(CurrentVehicleDataDto currentVehicleData) {
		this.currentVehicleData = currentVehicleData;
	}

	/**
	 * @return the engineFullIceCode
	 */
	public String getEngineFullIceCode() {
		return engineFullIceCode;
	}

	/**
	 * @param engineFullIceCode the engineFullIceCode to set
	 */
	public void setEngineFullIceCode(String engineFullIceCode) {
		this.engineFullIceCode = engineFullIceCode;
	}

	/**
	 * @return the warrantyDate
	 */
	public String getWarrantyDate() {
		return warrantyDate;
	}

	/**
	 * @param warrantyDate the warrantyDate to set
	 */
	public void setWarrantyDate(String warrantyDate) {
		this.warrantyDate = warrantyDate;
	}

	/**
	 * 
	 * @return the VIN list
	 */
	public List<String> getVinList() {
		return vinList;
	}

	/**
	 * 
	 * @param vinList The VIN list to set
	 */
	public void setVinList(List<String> vinList) {
		this.vinList = vinList;
	}

	/**
	 * @return the modelsListForPin
	 */
	public List<ModelDto> getModelsListForPin() {
		return modelsListForPin;
	}

	/**
	 * @param modelsListForPin the modelsListForPin to set
	 */
	public void setModelsListForPin(List<ModelDto> modelsListForPin) {
		this.modelsListForPin = modelsListForPin;
	}

}
