package capgemini.cnh.maintenanceservice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.axis2.transport.http.HTTPConstants;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.IceConstantes;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ApplicationProperties;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.ConnectedTypeEnum;
import capgemini.cnh.tiam.ws.ice.TiamServicesCallback;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.AlertInstanceArray_WS;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CouponInstanceArray_WS;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CouponInstance_WS;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CreateMPNotifications;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.DealerShort_WS;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.ResultStatus_WS;

/**
 * Maintenance.
 * 
 * @author mmartel
 */
public class MaintenanceAlertService extends Business implements Runnable {

	/** The user . */
	String user;
	/** The mp contract . */
	MpContractDto contractDto;
	/** The mp contract detail for flexible contract. */
	MpContractVehicleDto mpContractVehicleDto;
	/** The current mileage. */
	CurrentVehicleDataDto currentVehicleDataDto;
	/** The list of next stop. */
	List<MpNextStopDto> mpdtoList;
	/** The customer : CNH or IVECO. */
	String customer;
	/** flexibleCoupons. */
	Map<String, MpFlexCouponDto> flexibleCoupons;

	IceContextDto context;

	/** The logger. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenanceAlertService.class);

	/** Creates. */
	public MaintenanceAlertService(String user, MpContractDto contractDto, MpContractVehicleDto mpContractVehicleDto, CurrentVehicleDataDto currentVehicleDataDto,
			List<MpNextStopDto> mpdtoList, String customer, Map<String, MpFlexCouponDto> flexibleCoupons, IceContextDto context) {
		this.user = user;
		this.user = user;
		this.contractDto = contractDto;
		this.mpContractVehicleDto = mpContractVehicleDto;
		this.currentVehicleDataDto = currentVehicleDataDto;
		this.mpdtoList = mpdtoList;
		this.customer = customer;
		this.flexibleCoupons = flexibleCoupons;
		this.context = context;
	}

	/**
	 * (non-Javadoc).
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		logger.warn(String.format("Start MaintenanceAlertService"));
		long begin = System.currentTimeMillis();

		createMpAlertForConnectedContract(user, contractDto, mpContractVehicleDto, currentVehicleDataDto, mpdtoList, customer, context);

		long end = System.currentTimeMillis();
		long delta = end - begin;
		logger.warn(String.format("TIME EXECUTION MaintenanceAlertService : %d ", delta));
	}

	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/************************************************* Alert MP Creation ***************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/

	/**
	 * Create an alert for connected contracts, Flexible and Targa
	 * 
	 * @param userSession
	 * @param mpNextStopAlertDtoList
	 */
	public void createMpAlertForConnectedContract(String user, MpContractDto contractDto, MpContractVehicleDto mpContractVehicleDto, CurrentVehicleDataDto currentVehicleDataDto,
			List<MpNextStopDto> mpdtoList, String customer, IceContextDto context) {

		try
		{
			MaintenancePlanBusiness mpBusiness = MaintenanceService.getMaintenancePlanBusiness(null, customer, null, context);

			mpBusiness.setFlexibleCoupons(flexibleCoupons);
			MpIntervalDto tolInt = (new MpIntervalBusiness()).getCouponTolerance(contractDto.getActiveMpContract().getPlanId());
			if (tolInt != null)
			{
				mpBusiness.updateDelta(tolInt.getAfterValue(MpType.MP_KM), tolInt.getAfterValue(MpType.MP_HOUR));
			}

			if (contractDto != null
					&& contractDto.getActiveMpContract() != null
					&& (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contractDto.getActiveMpContract().getTypeContract())
							|| ConnectedTypeEnum.LIGHT_TARGA_CONNECTED.getValue().equals(contractDto.getActiveMpContract().getConnectedType())))
			{

				List<MpNextStopDto> mpNextStopDtoListWithoutexternal = new ArrayList<>();

				for (MpNextStopDto mpNextStopDto : mpdtoList)
				{
					if (!Integer.valueOf(1).equals(mpNextStopDto.getExternal()))
					{
						mpNextStopDtoListWithoutexternal.add(mpNextStopDto);
					}
				}

				if (currentVehicleDataDto != null && (currentVehicleDataDto.getCurrentMileage() != null || currentVehicleDataDto.getCurrentHours() != null))
				{
					List<MpNextStopAlertDto> mpNextStopAlertDtoList = mpBusiness.getCouponInAlert("", mpNextStopDtoListWithoutexternal, mpContractVehicleDto, currentVehicleDataDto);

					createAlertsOfCouponsInAlert(user, mpNextStopAlertDtoList);
				}

			}
		}
		catch (SystemException e)
		{
			logger.error("createMpAlertForConnectedContract error", e);
		}
	}

	/**
	 * @param userSession
	 * @param mpNextStopAlertDtoList
	 */
	private void createAlertsOfCouponsInAlert(String user, List<MpNextStopAlertDto> mpNextStopAlertDtoList) {
		if (!mpNextStopAlertDtoList.isEmpty())
		{
			CouponInstance_WS[] couponInstanceWsArray = new CouponInstance_WS[mpNextStopAlertDtoList.size()];
			for (int i = 0; i < mpNextStopAlertDtoList.size(); i++)
			{

				MpNextStopAlertDto mpNextStopAlertDto = mpNextStopAlertDtoList.get(i);
				CouponInstance_WS couponInstanceWs = mapMpNextStopAlertDtoToCouponInstanceWsStub(mpNextStopAlertDto);
				couponInstanceWsArray[i] = couponInstanceWs;
			}
			callWSCreateMpNotifications(user, couponInstanceWsArray);
		}
	}

	/**
	 * @param user
	 * @param couponInstanceWsArray
	 */
	private void callWSCreateMpNotifications(String user, CouponInstance_WS[] couponInstanceWsArray) {
		AlertInstanceArray_WS alertInstanceArray = new AlertInstanceArray_WS();
		ResultStatus_WS resultStatus = new ResultStatus_WS();
		try
		{
			CouponInstanceArray_WS couponInstanceArrayWS = new CouponInstanceArray_WS();
			couponInstanceArrayWS.setCouponInstance_WSs(couponInstanceWsArray);

			Properties properties = ApplicationProperties.getProperties();
			String tiamServiceStub = properties.getProperty("tiam.soap.url");
			TiamServicesStub icestub = new TiamServicesStub(tiamServiceStub);

			icestub._getServiceClient().getOptions().setTimeOutInMilliSeconds(100 * 10000);
			// Parameter to avoid a socket timeout
			icestub._getServiceClient().getOptions().setProperty(HTTPConstants.SO_TIMEOUT, new Integer(0));
			icestub._getServiceClient().getOptions().setProperty(HTTPConstants.CHUNKED, false);

			// Call eTim SOAP web service manage
			CreateMPNotifications request = new CreateMPNotifications();
			request.setCouponInstances(couponInstanceArrayWS);
			request.setOriginatingSystem(IceConstantes.TIDB_SOURCE);
			request.setApplicativeUserId(IceConstantes.TIDB_SOURCE);
			request.setApplicativePassword(IceConstantes.TIDB_SOURCE);
			request.setExternalUserId(user);

			TiamServicesCallback callback = new TiamServicesCallback();

			//Asynchronous call to TiamServices
			logger.info("startcreateMPNotifications");
			icestub.startcreateMPNotifications(request, callback);
			//icestub.createMPNotifications(request);

			logger.info("callback");

			//true if the web service called is successfully done
			boolean isComplete = false;
			//true if an error occurred
			boolean isError = false;

			//Check the web service call status every 10 sec (check done if the call is not completed and without error)
			while (!isComplete && !isError)
			{
				Thread.sleep(10000);
				isComplete = callback.isComplete();
				isError = callback.isInError();
				logger.info("Alert creation completed: " + isComplete);
				logger.info("Alert creation in error: " + callback.isInError());
			}

			if (isComplete)
			{
				alertInstanceArray = callback.getAlertInstanceArray_WS();
			}
			else
			{
				logger.error("callMpCreateAlertsICEService logFailureMP Exception: ");

			}

		}
		catch (IOException e)
		{
			logger.error(String.format("RemoteException IceServices %s", e.getMessage()));
			alertInstanceArray = new AlertInstanceArray_WS();
			resultStatus.setCode(capgemini.cnh.framework.common.Constantes.RESULT_CODE_ALERT_ERROR);
			resultStatus.setMessage(String.format("RemoteException IceServices %s", e.getMessage()));
			alertInstanceArray.setResultStatus(resultStatus);
		}
		catch (InterruptedException e)
		{
			logger.error(String.format("InterruptedException IceServices %s", e.getMessage()));
			alertInstanceArray = new AlertInstanceArray_WS();
			resultStatus.setCode(capgemini.cnh.framework.common.Constantes.RESULT_CODE_ALERT_ERROR);
			resultStatus.setMessage(String.format("InterruptedException IceServices %s", e.getMessage()));
			alertInstanceArray.setResultStatus(resultStatus);
			Thread.currentThread().interrupt();
		}
	}

	/**
	 * @param mpNextStopAlertDto
	 * @return
	 */
	private CouponInstance_WS mapMpNextStopAlertDtoToCouponInstanceWsStub(MpNextStopAlertDto mpNextStopAlertDto) {
		CouponInstance_WS couponInstanceWs = new CouponInstance_WS();
		couponInstanceWs.setPinVin(mpNextStopAlertDto.getVin());
		couponInstanceWs.setCouponCode(mpNextStopAlertDto.getIntervalCode());

		// Coupon data

		Map<MpType, Long> nextValueMap = mpNextStopAlertDto.getNextValueMap();

		Map<MpType, Date> proposalDateMap = mpNextStopAlertDto.getProposalDateMap();

		if (nextValueMap.get(MpType.MP_KM) != null)
		{
			couponInstanceWs.setNextKm(nextValueMap.get(MpType.MP_KM));
		}
		if (nextValueMap.get(MpType.MP_HOUR) != null)
		{
			couponInstanceWs.setNextHour(nextValueMap.get(MpType.MP_HOUR));
		}
		if (proposalDateMap.get(MpType.MP_MONTH) != null)
		{
			couponInstanceWs.setNextDate(proposalDateMap.get(MpType.MP_MONTH));
		}
		if (nextValueMap.get(MpType.MP_MONTH) != null)
		{
			couponInstanceWs.setNextMonth(nextValueMap.get(MpType.MP_MONTH));
		}
		couponInstanceWs.setBrandIceCode(mpNextStopAlertDto.getBrandIceCode());

		// se Mp Services ligne 928
		couponInstanceWs.setOriginatingSystem(IceConstantes.TIDB_SOURCE);
		String dealerCode = mpNextStopAlertDto.getDealerCode();
		DealerShort_WS[] dealerShortWSs = null;
		if (dealerCode != null)
		{
			dealerShortWSs = new DealerShort_WS[1];
			dealerShortWSs[0] = new DealerShort_WS();
			dealerShortWSs[0].setCode(mpNextStopAlertDto.getDealerCode());

		}
		couponInstanceWs.setDealers(dealerShortWSs);
		return couponInstanceWs;
	}

}
