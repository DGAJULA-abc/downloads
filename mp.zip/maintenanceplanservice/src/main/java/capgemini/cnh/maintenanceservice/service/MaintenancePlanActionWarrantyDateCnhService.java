package capgemini.cnh.maintenanceservice.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.WarrantyServicesDto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceservice.util.UtilDate;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;

public class MaintenancePlanActionWarrantyDateCnhService {

	/**
	 * Logger for the class.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenancePlanActionWarrantyDateCnhService.class);

	/**
	 * JSON KEY response.
	 */
	private static final String KEY_RESPONSE = "response";

	/**
	 * JSON KEY number.
	 */
	private static final String KEY_NUMBER = "number";

	/**
	 * Execute formSearch action.
	 * 
	 * @param request the request
	 * @param session the user session
	 * 
	 * @return JSON result
	 * 
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public static MpHistoryWarrantyDto getWarrantyStartDate(ResponseData vehicleDto, CurrentVehicleDataDto currentVehicleDataDto, MpContractDto contract, List<String> lstPinVin)
			throws ApplicativeException, SystemException {

		boolean isWsdModifiable = true;
		String warrantyDate = null;
		String minDate = null;
		String maxDate = LocalDate.now().toString();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(UtilDate.FORMAT_DATE_YYYYMMDD);

		MpHistoryWarrantyDto warrantyStartDate = new MpHistoryWarrantyDto();

		if (null != currentVehicleDataDto && null != currentVehicleDataDto.getWtyStartDate())
		{
			// set the WSD in the result JSON. 2021-01-19T00:00:00+00:00
			warrantyDate = currentVehicleDataDto.getWtyStartDate();
		}
		else if (vehicleDto != null && vehicleDto.getWarrantyServices().stream().anyMatch(c -> "V".equals(c.getWarrantyType()) || "J".equals(c.getWarrantyType()) || "A".equals(c.getWarrantyType())))
		{

			List<LocalDate> warrantyDateListe = vehicleDto.getWarrantyServices().stream()
					.filter(c -> "V".equals(c.getWarrantyType()) || "J".equals(c.getWarrantyType()) || "A".equals(c.getWarrantyType()))
					.map(WarrantyServicesDto::getServStartdate)
					.filter(Objects::nonNull)
					.map(d -> LocalDate.parse(d, formatter))
					.collect(Collectors.toList());

			if (!warrantyDateListe.isEmpty())
			{
				warrantyDate = warrantyDateListe.stream()
						.sorted()
						.collect(Collectors.toList())
						.get(0).toString();
			}

			//getServStartdate() 
		}

		// is WSD modifiable
		List<MpHistoryIntervalDto> intervalList = MpIntervalBusiness.readListHistoryInterval(lstPinVin, null, null);

		if (warrantyDate != null && !intervalList.isEmpty())
		{
			isWsdModifiable = false;
		}

		// If contract max date = contract start date
		if (contract != null && contract.getActiveMpContract() != null && contract.getActiveMpContract().getContractStartDate() != null)
		{
			if (contract.getActiveMpContract().getContractStartDate() instanceof java.sql.Date)
			{
				LocalDate contractStartDate = ((java.sql.Date) contract.getActiveMpContract().getContractStartDate()).toLocalDate();
				maxDate = contractStartDate.toString();
				if (warrantyDate == null) {
					warrantyDate = contract.getWarrantyStartDate();
				}
			}
			else
			{
				LocalDate contractStartDate = contract.getActiveMpContract().getContractStartDate().toInstant()
						.atZone(ZoneId.systemDefault())
						.toLocalDate();
				maxDate = contractStartDate.toString();
			}
		}

		// If WSD, min date = WSD
		if (warrantyDate != null)
		{
			minDate = warrantyDate;

			// FSA Temporally fix for min max range bug  
			LocalDate mindate = LocalDate.parse(minDate, formatter);
			LocalDate maxdate = LocalDate.parse(maxDate, formatter);

			if (mindate.isAfter(maxdate))
			{
				minDate = null;
				maxDate = null;
			}
		}

		warrantyStartDate.setWarrantyDate(warrantyDate);
		warrantyStartDate.setModifiable(isWsdModifiable);
		warrantyStartDate.setMinDate(minDate);
		warrantyStartDate.setMaxDate(maxDate);

		return warrantyStartDate;

	}

}
