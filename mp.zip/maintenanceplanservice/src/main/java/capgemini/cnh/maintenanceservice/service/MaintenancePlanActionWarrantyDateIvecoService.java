package capgemini.cnh.maintenanceservice.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.VehicleDataDto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.maintenanceservice.util.UtilDate;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;

public class MaintenancePlanActionWarrantyDateIvecoService {

	/**
	 * Logger for the class.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenancePlanActionWarrantyDateIvecoService.class);

	/**
	 * JSON KEY response.
	 */
	private static final String KEY_RESPONSE = "response";

	/**
	 * JSON KEY number.
	 */
	private static final String KEY_NUMBER = "number";

	/**
	 * Execute formSearch action.
	 * 
	 * @param request the request
	 * @param session the user session
	 * 
	 * @return JSON result
	 * 
	 * @throws SystemException a System Exception
	 * @throws ApplicativeException an Applicative Exception
	 */
	public static MpHistoryWarrantyDto getWarrantyStartDate(ResponseData vehicleDto, MpContractDto contract, String pinVin)
			throws ApplicativeException {

		MpHistoryWarrantyDto warrantyStartDate = new MpHistoryWarrantyDto();
		String warrantyDate = null;

		try
		{
			if (contract != null && contract.getWarrantyStartDate() != null)
			{
				warrantyDate = contract.getWarrantyStartDate();
			}
			else if (vehicleDto != null && !vehicleDto.getVehicleData().isEmpty() && vehicleDto.getVehicleData().get(0).getWtyStart() != null)
			{
				List<VehicleDataDto> listVehicle = vehicleDto.getVehicleData();
				warrantyDate = listVehicle.get(0).getWtyStart();

			}
			else if (contract == null)
			{
				MpHistoryWarrantyDto history = (new MpIntervalBusiness()).readHistoryWarranty(pinVin);
				if (history != null)
				{
					warrantyDate = history.getWarrantyDate();
					// Put the wsd in the good format 
					if (warrantyDate != null)
					{
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern(UtilDate.FORMAT_DATE_DDMMYYYY_SLASH);
						LocalDate wsd = LocalDate.parse(warrantyDate, formatter);

						formatter = DateTimeFormatter.ofPattern(UtilDate.FORMAT_DATE_YYYYMMDD);
						warrantyDate = wsd.format(formatter);
					}
				}
			}
		}
		catch (SystemException e)
		{
			throw new ApplicativeException(e);
		}

		warrantyStartDate.setWarrantyDate(warrantyDate);
		return warrantyStartDate;

	}

}
