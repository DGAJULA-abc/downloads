/**
 *
 */
package capgemini.cnh.maintenanceservice.service;

import java.io.IOException;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jdom.JDOMException;
import org.jdom.output.DOMOutputter;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.jobcard.model.JobcardParameters;
import capgemini.cnh.externals.jobcard.ws.JobcardWebService;
import capgemini.cnh.externals.jobcard.ws.JobcardWebService.JobcardWebServiceEnum;
import capgemini.cnh.externals.openapi.model.OpenApiParameters;
import capgemini.cnh.externals.openapi.ws.OpenApiWebService;
import capgemini.cnh.externals.openapi.ws.OpenApiWebService.OpenApiWebServiceEnum;
import capgemini.cnh.externals.sap.SAPBroker;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.WarrantyServicesDto;
import capgemini.cnh.externals.sap.model.SAPParameters;
import capgemini.cnh.externals.util.NextCouponsConstants;
import capgemini.cnh.externals.util.VehicleTelematicsConstants;
import capgemini.cnh.externals.util.WorkshopEnabledConstants;
import capgemini.cnh.framework.access.TransactionAccess;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.common.IceConstantes;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ApplicationProperties;
import capgemini.cnh.framework.util.ResourceLabel;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.DMCBusiness;
import capgemini.cnh.ice.business.MonSearchBySnBusiness;
import capgemini.cnh.ice.business.ProductBusiness;
import capgemini.cnh.ice.business.WebParamBusiness;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.MonSearchBySnDto;
import capgemini.cnh.ice.dto.WebParamDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.ice.dto.product.SeriesDto;
import capgemini.cnh.maintenanceservice.business.MPExportXMLBusiness;
import capgemini.cnh.maintenanceservice.dto.MPExportXMLDto;
import capgemini.cnh.maintenanceservice.dto.MaintenancePlanDto;
import capgemini.cnh.maintenanceservice.dto.MyVehicleContextDto;
import capgemini.cnh.maintenanceservice.util.Constantes;
import capgemini.cnh.maintenanceservice.util.MaintenanceEdsUtil;
import capgemini.cnh.maintenanceservice.util.MaintenanceUcrUtil;
import capgemini.cnh.maintenanceservice.util.MaintenanceUtil;
import capgemini.cnh.maintenanceservice.util.UtilDate;
import capgemini.cnh.mpbusiness.business.MPSapHistoryService;
import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.business.MaintenancePlanFixedSchedulingBusiness;
import capgemini.cnh.mpbusiness.business.MaintenancePlanVariableSchedulingBusiness;
import capgemini.cnh.mpbusiness.business.MpAppointmentBusiness;
import capgemini.cnh.mpbusiness.business.MpClaimBusiness;
import capgemini.cnh.mpbusiness.business.MpFlexMaintenanceBusiness;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.business.MpLockBusiness;
import capgemini.cnh.mpbusiness.business.MpNextStopBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationConsumableBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationIuLinkBusiness;
import capgemini.cnh.mpbusiness.business.MpOperationPartBusiness;
import capgemini.cnh.mpbusiness.business.MpPlanBusiness;
import capgemini.cnh.mpbusiness.business.MpToleranceBusiness;
import capgemini.cnh.mpbusiness.business.MpUnitSeriesBusiness;
import capgemini.cnh.mpbusiness.dto.MpCallStatus;
import capgemini.cnh.mpbusiness.dto.MpClaimDto;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractTypeMessageDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryOrigin;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto.NextMaintenance;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopViewDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopViewDtoMapper;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;
import capgemini.cnh.mpbusiness.dto.MpOperationDto;
import capgemini.cnh.mpbusiness.dto.MpOperationIuLinkDto;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;
import capgemini.cnh.mpbusiness.dto.SmartViewMaintenanceViewDto;
import capgemini.cnh.mpbusiness.util.ConnectedTypeEnum;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.ContractVisibility;
import capgemini.cnh.mpbusiness.util.MpIntervalByCodeComparator;
import capgemini.cnh.mpbusiness.util.MpIntervalHistoryEnum;
import capgemini.cnh.mpbusiness.util.MpIntervalStatusEnum;
import capgemini.cnh.tiam.business.EtimAlertBusiness;
import capgemini.cnh.tiam.dto.EtimAlertDto;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.AlertInstance_WS;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CloseAlertInstancesByPinVins;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CloseAlertInstancesByPinVinsResponse;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CloseMpAlerts;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.CloseMpAlertsResponse;
import capgemini.cnh.tiam.ws.ice.TiamServicesStub.ResultStatus_WS;
import capgemini.cnh.ticd.document.business.ConsumableListBusiness;
import capgemini.cnh.ticd.document.business.IuBusiness;
import capgemini.cnh.ticd.document.domain.ConsumableListDomain;
import capgemini.cnh.ticd.document.dto.ConsumableListDto;
import capgemini.cnh.ticd.document.dto.IUDocDto;

/**
 *
 * @author mmartel
 */
public class MaintenanceService {

	/** logger variable. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenanceService.class);

	/**
	 * JSON KEY intervals.
	 */
	public static final String KEY_INTERVAL = "intervals";

	/**
	 * JSON KEY reloadMaintBox.
	 */
	public static final String KEY_RELOAD_MAINTENANCE_BOX = "reloadMaintBox";

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT_yyyy_MM_dd = "yyyy-MM-dd";
	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT_yyyy_MM_dd_HH_mm_ss = "yyyy-MM-dd HH:mm:ss";

	/**
	 * Applicable Mission List
	 */
	public static final String APPLICABLE_MISSION_LIST = "applicable_mission_list";

	public static MpContractDto getAllMpContracts(List<String> lstPinVin, boolean isIveco) throws SystemException, ApplicativeException {
		return new MpPlanBusiness().getAllMpContracts(lstPinVin, true, isIveco);
	}

	/**
	 * set the context to retrieve the maintenance data for a specific vin .
	 *
	 * @param vin : vehicle identifier number
	 * @param actualMileage : actual Mileage
	 * @param actualHour : actual hour (from JobCard)
	 * @param iceContextDto : brand/type/product/series/model/tt - Country - Market- languageDto - IwdSubscription - AccessMode=VALID
	 * @param mpContractDto : mp ContractDto
	 * @param productConfiguration : product Configuration
	 * @param nowDate : current date (from JobCard java script nowdate=(new Date()).getTime())
	 * @param customer : IVECO or not
	 * @param userId : connected user
	 * @return the object MyVehicleContextDto
	 * @throws ApplicativeException : Applicative Exception
	 * @throws SystemException : System Exception
	 * @throws KeyStoreException : KeyStoreException
	 * @throws NoSuchAlgorithmException : NoSuch Algorithm Exception
	 * @throws CertificateException : Certificate Exception
	 * @throws IOException : IO Exception
	 * @throws UnrecoverableKeyException : Unrecoverable KeyException
	 * @throws KeyManagementException : KeyManagement Exception
	 * @throws ParseException : ParseException
	 * @throws NumberFormatException : NumberFormatException
	 */
	public static MyVehicleContextDto intializeMaintenancePlanContext(String vin, String actualMileage, String actualHour,
			IceContextDto iceContextDto, ProductConfiguration productConfiguration, MpContractDto mpContractDto, String nowDate, String customer, String userId, boolean isConnected,
			boolean ucrManageMP)
			throws SystemException, ApplicativeException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException, KeyManagementException,
			NumberFormatException, ParseException {
		MaintenancePlanDto mpDto = new MaintenancePlanDto();
		MyVehicleContextDto myVehicleContextDto = new MyVehicleContextDto();
		myVehicleContextDto.setContextDto(iceContextDto);
		CurrentVehicleDataDto currentVehicleDataDto = new CurrentVehicleDataDto();
		List<String> vinList = new ArrayList<>();
		boolean isIveco = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));
		List<MpUsageDto> applicableMissionList = new ArrayList<>();

		currentVehicleDataDto.setConnected(isConnected);
		currentVehicleDataDto.setUcrManageMP(ucrManageMP);
		vinList.add(vin);

		//For AG&CE, the pin (9 or 17 digit) needs to be retreived
		// the current vehicle info should be retrieved from UCR
		vinList = new VehicleService().getVins(vin, isIveco);

		myVehicleContextDto.setVinList(vinList);

		Map<String, MpFlexCouponDto> flexibleCoupons = MaintenanceUtil.initFlexibleCoupon();

		mpDto.setFlexibleCoupons(flexibleCoupons);
		mpDto.setActualMileage(actualMileage);
		mpDto.setActualHour(actualHour);
		mpDto.setNowDate(nowDate);
		mpDto.setModel(iceContextDto.getModel() != null ? iceContextDto.getModel().getAName() : "");
		//set language
		WebParamBusiness webParamBusiness = new WebParamBusiness();
		String defaultLanguage = webParamBusiness.getTidbConfVariable(IceConstantes.TIDB_CONF_DEFAULT_WEB_LANGUAGE).getWeb_value();
		if (defaultLanguage == null)
		{
			defaultLanguage = Constantes.ENGLISH;
		}
		iceContextDto.setDefaultLanguage(defaultLanguage);

		//Get Contract
		myVehicleContextDto.setMpContract(mpContractDto);
		//Call SapBroker + update mp history from sap broker
		// Get SAP Information for the given VIN
		//get also the warranty start date, so call for contract and other
		boolean isSoapCallOk = false;
		SAPParameters params = new SAPParameters(vin, iceContextDto.getLanguage().getIdlanguage(), isIveco, iceContextDto.getMarketId().intValue());
		params.setUsingCache(true);
		ResponseData responseData = SAPBroker.call(params);
		if (mpContractDto != null)
		{
			callMpHistoryUpdatedBySAP(vin, vinList, mpContractDto, responseData, Constants.CUSTOMER_IVECO, flexibleCoupons, false, iceContextDto);
			isSoapCallOk = responseData != null && responseData.isMpRepairHistoFromSapOk();
		}
		else
		{
			isSoapCallOk = true;
		}

		MpPlanDto planDto = new MpPlanDto(null);
		List<MpNextStopDto> mpdtoList = new ArrayList<>();
		MpNextStopMinDto mpNextStopMin = new MpNextStopMinDto();

		String unitKey = null;
		if (!isIveco)
		{
			unitKey = MaintenanceService.getUnitKeyBySerie(iceContextDto.getBrand().getIceCode(), iceContextDto.getType().getIceCode(), iceContextDto.getProduct().getIceCode(),
					iceContextDto.getSeries().getIceCode());
		}
		//For AG&CE continue only vehicle is not connected (for the moment)
		if (isIveco || !ucrManageMP || (unitKey != null && !unitKey.isEmpty())) // -- if (isIveco or balers)
		{
			// TODO IAZ --> For AG&CE connected vehicles, call next coupons from UCR
			//retrieve the plan id
			planDto = retrievePlanApplicable(vin, mpContractDto, iceContextDto, productConfiguration);
		}
		else // AG&CE Connected vehicles
		{
			planDto = fillMpNextStopListFromUCR(mpdtoList, mpNextStopMin, iceContextDto.getLanguage().getIdlanguage(), vin, actualHour, userId, null, isConnected, applicableMissionList);
		}

		MpHistoryWarrantyDto warrantyStartDateDto = new MpHistoryWarrantyDto();
		String warrantyStartDate = null;

		if (isIveco)
		{
			warrantyStartDateDto = MaintenancePlanActionWarrantyDateIvecoService.getWarrantyStartDate(responseData, mpContractDto, vin);
		}
		else
		{
			warrantyStartDateDto = MaintenancePlanActionWarrantyDateCnhService.getWarrantyStartDate(responseData, myVehicleContextDto.getCurrentVehicleData(), mpContractDto, vinList);
		}

		// convert warrantyStartDate to millisecond string
		if (null != warrantyStartDateDto.getWarrantyDate())
		{
			warrantyStartDate = parseWarrantyDate(warrantyStartDateDto.getWarrantyDate(), DATE_FORMAT_yyyy_MM_dd, "dd/MM/yyyy");
		}

		warrantyStartDateDto.setVin(vin);
		myVehicleContextDto.setPinVin(vin);
		warrantyStartDateDto.setWarrantyDate(warrantyStartDate);
		mpDto.setWarranty(warrantyStartDateDto);
		mpDto.setWarrantyDate(warrantyStartDate);
		myVehicleContextDto.setWarrantyDate(warrantyStartDate);

		if (planDto != null && planDto.getId() != null && isSoapCallOk && warrantyStartDate != null)
		{
			mpDto.setPlanId(planDto.getId().toString());
			mpDto.setMpPlanSelected(planDto);
			mpDto.setUcrNextStopList(mpdtoList);
			mpDto.setUcrNextStopMin(mpNextStopMin);

			// get the current vehicle data : for IVECO retrieved from EDS
			if (isIveco)
			{
				currentVehicleDataDto = MaintenanceEdsUtil.getCurrentVehicleDataFromEDS(vin);
			}

			myVehicleContextDto.setCurrentVehicleData(currentVehicleDataDto);

			//-- getIntervalElementList : This list can be empty, it used in eTIM as a cache, if empty it is automatically rebuild each time
			//-- get the list of interval (For AG&CE, retrieve only non-customer intervals)
			String mpFamily = Context.getStringProperty("mp.family.code");
			List<MpIntervalDto> listIntervals = MpIntervalBusiness.getMaintenanceIntervals(planDto.getId(), iceContextDto.getLanguage().getIdlanguage(), defaultLanguage, mpFamily, isIveco);
			Collections.sort(listIntervals, new MpIntervalByCodeComparator(flexibleCoupons));
			mpDto.setListIntervals(listIntervals);
			//-- getListHistory
			mpDto.setListHistory(new ArrayList<MpHistoryIntervalDto>()); // -- reset/init history list
			mpDto.getListHistory().addAll(getMpHistory(mpDto, mpContractDto, Arrays.asList(vin), iceContextDto.getLanguage().getIdlanguage(), defaultLanguage,
					flexibleCoupons, customer, nowDate, String.valueOf(isConnected), false, new ArrayList<MpHistoryIntervalDto>(), new ArrayList<MpHistoryIntervalDto>(), iceContextDto));
			myVehicleContextDto.setMpInteractive(mpDto);
			myVehicleContextDto.setPinVin(vin);
			myVehicleContextDto.setProductConfiguration(productConfiguration);
			myVehicleContextDto.setSapVehicleInformation(responseData);

			myVehicleContextDto.setContextDto(iceContextDto);
			myVehicleContextDto.setProductConfiguration(productConfiguration);

			return myVehicleContextDto;
		}
		else
		{
			String error = "intializeMaintenancePlanContext Error";

			if (planDto == null || planDto.getId() == null)
			{
				error = error.concat("==> PLAN or PLAN ID is null \n");
			}
			if (!isSoapCallOk)
			{
				error = error.concat("==> SAP Broker issue \n");
			}
			if (warrantyStartDate == null)
			{
				error = error.concat("==> Warranty start date is null \n");
			}
			logger.error(error);
			// plan not applicable
			// warranty start date null
			// sap broker ko
			return null;
		}
	}

	/**
	 * retrieve the applicable plan.
	 *
	 * @param vin vehicle number
	 * @param contract list of contracts
	 * @param iceContextDto ice context dto
	 * @param productConfiguration product configuration
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	public static MpPlanDto retrievePlanApplicable(String vin, MpContractDto contract, IceContextDto iceContextDto, ProductConfiguration productConfiguration)
			throws ApplicativeException, SystemException {

		MpPlanDto planDto = null;
		MpPlanBusiness planBusiness = new MpPlanBusiness();
		if (contract != null)
		{
			MpContractVehicleDto activeContract = contract.getActiveMpContract();
			if (activeContract != null)
			{
				//check plan applicable
				planDto = new MpPlanBusiness().checkPlanApplicable(activeContract.getPlanId(), iceContextDto, productConfiguration);
			}
		}
		else
		{
			List<MpHistoryIntervalDto> listAllHistory = MpIntervalBusiness.readListHistoryInterval(Arrays.asList(vin), null, null);
			if (!listAllHistory.isEmpty())
			{
				Long planExtId = listAllHistory.get(0).getPlanExternalId();
				if (planExtId != null)
				{
					planDto = planBusiness.checkLastVersionPlanApplicable(planExtId, iceContextDto, productConfiguration);
				}
			}
		}
		return planDto;
	}

	/**
	 * Get the proposed coupons .
	 *
	 * @param myVehicleContextDto : vehicle data information and mp context
	 * @param customer : customer (to be checked with Julien and check how to get from setMaintenancePlanContext)
	 * @param userId : user id retrieved from UCR (check how to get from setMaintenancePlanContext)
	 * @param dealerCode : dealer code retrieved from UCR (check how to get from setMaintenancePlanContext)
	 * @param dealerName : dealer name retrieved from UCR (check how to get from setMaintenancePlanContext)
	 */
	public static List<MpIntervalDto> retrieveProposedCoupons(MyVehicleContextDto myVehicleContextDto, String customer, String userId, String dealerCode, String dealerName)
			throws SystemException, ApplicativeException {
		List<MpIntervalDto> result = null;
		IceContextDto dtoIceContext = null;
		Locale locale = null;
		MpContractDto contract = null;
		CurrentVehicleDataDto currentVehicleData = null;
		MaintenancePlanDto mpDto = null;
		String nowDate = null;
		if (myVehicleContextDto != null)
		{
			contract = myVehicleContextDto.getMpContract();
			dtoIceContext = myVehicleContextDto.getContextDto();
			locale = new Locale(dtoIceContext.getLanguage().getIdlanguage());
			currentVehicleData = myVehicleContextDto.getCurrentVehicleData();
			mpDto = myVehicleContextDto.getMpInteractive();

			String unitKey = "";
			if (mpDto != null)
			{
				nowDate = mpDto.getNowDate();
				List<MpNextStopDto> nextCouponFromUcr = mpDto.getUcrNextStopList();
				//for the moment it has been desactivated (we assume that 2 vin can not be called at the same time)
				boolean isMpLockEnabled = false;
				Map<String, MpFlexCouponDto> flexibleCoupons = mpDto.getFlexibleCoupons();

				boolean isIveco = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));
				if (!isIveco)
				{
					unitKey = MaintenanceService.getUnitKeyBySerie(dtoIceContext.getBrand().getIceCode(), dtoIceContext.getType().getIceCode(), dtoIceContext.getProduct().getIceCode(),
							dtoIceContext.getSeries().getIceCode());
				}

				result = retrieveProposedCoupons(nowDate, currentVehicleData != null ? currentVehicleData.isUcrManageMP() : false, locale, customer, flexibleCoupons, true,
						dtoIceContext, contract, currentVehicleData, isMpLockEnabled, mpDto, nextCouponFromUcr, userId, dealerCode, dealerName, false, mpDto.getListHistory(),
						myVehicleContextDto.getVinList(),
						null, "", unitKey, currentVehicleData.isConnected(), myVehicleContextDto.getEngineFullIceCode(), myVehicleContextDto.getProductConfiguration());
				if (result != null && !result.isEmpty())
				{
					final Long planId = Long.valueOf(mpDto.getPlanId());
					for (MpIntervalDto interval : result)
					{
						interval.setIdPlan(planId);
					}
				}
			}
		}
		return result;
	}

	/**
	 * Get the proposed coupons .
	 *
	 * @param nowDate : current date (from JobCard java script nowdate=(new Date()).getTime())
	 * @param isDataFromUcr : is coupon selected received from UCR (false from JobCard because AG&CE not yet implemented)
	 * @param locale : locale (to be checked with Julien)
	 * @param customer : customer
	 * @param flexibleCoupons : list of flexible coupon
	 * @param hasRightToSave : MML to review
	 * @param dtoIceContext : used to get current language and default language
	 * @param contract : all contract data
	 * @param currentVehicleDate : current vehicle data
	 * @param isMpLockEnabled : set false (or get from database check how to get from setMaintenancePlanContext)
	 * @param mpDto : data relative the mp (initialize in the function setMaintenancePlanContext)
	 * @param nextCouponFromUcr : next coupon retrieved from UCR (null for the moment for JobCard)
	 * @param userId : user id only used for UCR for log
	 * @param dealerCode : dealer code only used in web service to UCR
	 * @param dealerName : dealer name only used in web service UCR
	 * @param mpPlanUcr : the MP plan provide by UCR
	 */
	public static List<MpIntervalDto> retrieveProposedCoupons(String nowDate, boolean ucrManageMp, Locale locale, String customer, Map<String, MpFlexCouponDto> flexibleCoupons,
			boolean hasRightToSave, IceContextDto dtoIceContext, MpContractDto contract, CurrentVehicleDataDto currentVehicleDate, boolean isMpLockEnabled, MaintenancePlanDto mpDto,
			List<MpNextStopDto> nextCouponFromUcr, String userId, String dealerCode, String dealerName, boolean historyChanged, List<MpHistoryIntervalDto> listQuestionHistory, List<String> lstPinVin,
			MpPlanDto mpPlanUcr, String unit, String unitKey, boolean isConnectedUcr, String engineFullIceCode, ProductConfiguration productConfiguration)
			throws SystemException, ApplicativeException {

		//MML to be passed
		//Locale locale = context.getLanguage().getLocale();
		String vin = mpDto.getWarranty().getVin();

		// list that will contain the history for vin with active contract
		List<MpHistoryIntervalDto> listHistoryContract = new ArrayList<>();

		// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
		MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(mpDto, nowDate, locale, customer, null, dtoIceContext);
		mpBusiness.setFlexibleCoupons(flexibleCoupons);

		//MML Context to be passed
		//MpContractDto contract = userSession.getMpContract();  IAZ
		ContractVisibility contractVisibility = new ContractVisibility(contract, ucrManageMp);

		// -- this is voodoo MML
		//MML Context to be passed
		Map<String, String> voodoo = MaintenancePlanBusiness.setIntervalElementList(mpDto.getIntervalElementList(), dtoIceContext, unitKey);

		// Prepare operations for UCR
		Map<String, JsonArrayBuilder> couponOperationJsonForUCR = new HashMap<>();

		// -- for all questions
		// -- compute interval value from exact value
		// -- update/insert question to the database
		// -- Keep only the modified questions
		boolean historyModified = false;
		List<MpHistoryIntervalDto> listQuestionsToKeep = new ArrayList<>();
		boolean isIveco = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));
		if (historyChanged)
		{
			//for UCR it is the current history
			List<MpHistoryIntervalDto> previousHistory = mpDto.getListHistory();
			mpDto.setListHistory(new ArrayList<MpHistoryIntervalDto>()); // -- reset/init history list
			MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness();

			boolean hasContractAg = !isIveco && contract != null;
			// case contract Ag
			if (hasContractAg)
			{
				long fistContractTime = 0;
				if (!contract.getContracts().isEmpty())
				{
					fistContractTime = contract.getContracts().get(contract.getContracts().size() - 1).getContractStartDate().getTime();
				}
				// get the last eTIM or the last sap
				// if eTIM is get we cannot save history and set message to user
				int toleranceToMatch = Integer.valueOf(Context.getStringProperty("mp.tolerance.tomatch"));
				int toleranceToWait = Integer.valueOf(Context.getStringProperty("mp.tolerance.towait"));
				listHistoryContract = new MpIntervalBusiness().readListHistoryIntervalWithContract(lstPinVin, toleranceToMatch, toleranceToWait, fistContractTime, flexibleCoupons, false);
			}

			for (MpHistoryIntervalDto question : listQuestionHistory)
			{
				boolean update = false;
				question.setVin(mpDto.getWarranty().getVin());
				question.setLstPinVin(lstPinVin);

				if (ucrManageMp)
				{
					question.setIsSapOrigin(MpHistoryOrigin.UCR.getValue());
				}

				//  IAZ Save failure date equal to Exact Month
				question.setFailureDate(question.retreiveFromExactValueByMpType(MpType.MP_MONTH));

				// Set operation Json
				MpIntervalOperationDto operation = getOperation(mpDto.getListIntervals().stream().filter(coupon -> coupon.getCode().equals(question.getIntervalCode())).findFirst().get(),
						dtoIceContext, Constantes.ENGLISH, productConfiguration, engineFullIceCode);

				JsonArrayBuilder operationJson = createOperationJsonForUCR(operation);
				// Build Operation JSON
				// create the Operations JSON here
				couponOperationJsonForUCR.put(question.getIntervalCode(), operationJson);

				question.setOperationJsonForUcr(operationJson.build().toString());

				for (MpType type : MpType.values())
				{
					if (question.retreiveFromExactValueByMpType(type).compareTo(0L) > 0)
					{
						update = true;
						// MML , the interval id must be updated to get the interval id of the project
						// of the new version
						mpBusiness.setInterval(question, mpDto.getListIntervals(), previousHistory, contractVisibility.hasComponentFlexible());
						// update interval value.
						//MML to be passed
						//if (mpDto.hasRightToSave(context))
						if (hasRightToSave)
						{
							historyModified = mpIntervalBusiness.updateOrInsertHistoryInterval(question, listQuestionsToKeep, isIveco, listHistoryContract, hasContractAg) || historyModified;
						}
						mpDto.getListHistory().add(question); // -- add to history list
						break; // -- update only once.
					}
					else
					{
						question.setIntValue(type, 0L); // -- reset interval value
					}
				}
				//MML to be passed
				//if (update == false && mpDto.hasRightToSave(context))
				if (update == false && hasRightToSave)
				{
					// -- all value to 0 delete the interval.
					historyModified = MpIntervalBusiness.deleteHistoryInterval(question) || historyModified;
				}
			}

			for (MpHistoryIntervalDto question : listQuestionsToKeep)
			{
				MpIntervalOperationDto operation = getOperation(mpDto.getListIntervals().stream().filter(coupon -> coupon.getCode().equals(question.getIntervalCode())).findFirst().get(),
						dtoIceContext, Constantes.ENGLISH, productConfiguration, engineFullIceCode);
				// Build Operation JSON
				// create the Operations JSON here
				couponOperationJsonForUCR.put(question.getIntervalCode(), createOperationJsonForUCR(operation));
			}
		}

		mpBusiness.updateDelta(mpDto.getListIntervals());
		// -- no questions: we have all the information to select the correct intervals.
		// then using the criteria mileage/hour/date, retrieved the selected intervals
		List<MpNextStopDto> listNextStopFlexible = new ArrayList<>();
		List<MpNextStopDto> listFlexNextStopCalculated = new ArrayList<>();
		if (contractVisibility.hasComponentFlexible())
		{
			listNextStopFlexible = new MpNextStopBusiness().getAllNextStopFlexibles(mpDto.getWarranty().getVin());
			//TODO add the flew coupons not alerted by EDS as empty
			List<MpHistoryIntervalDto> listFlexNextStopMissing = mpBusiness.getMissingFlexibleNextStop(listNextStopFlexible, mpDto.getWarranty().getVin());
			listFlexNextStopCalculated = mpBusiness.calculateNextFlexibleStop(listFlexNextStopMissing, new ArrayList<MpNextStopDto>(), listQuestionHistory, mpDto.getListIntervals(),
					mpDto.getWarranty().getVin());
			listNextStopFlexible.addAll(listFlexNextStopCalculated);

		}

		// If the interval modal is opened from an alert, jumpFromAlertUCR = true
		if (!ucrManageMp || (unitKey != null && !unitKey.isEmpty())) //Nominal case
		{
			// TODO MML consider the external alert
			mpBusiness.selectRecommandedIntervals(mpDto.getListIntervals(), listQuestionHistory, listNextStopFlexible, voodoo, isIveco, unitKey);

			//Recalculate the MP next stop in case the dealer modify the history and quit the IMP without saving a maintenance

			//MML to be passed
			//if (mpDto.hasRightToSave(context) && (historyModified || !listFlexNextStopCalculated.isEmpty()))
			if (hasRightToSave && (historyModified || !listFlexNextStopCalculated.isEmpty()))
			{
				updateNextStopHistoryChanged(mpBusiness, mpDto, currentVehicleDate, contractVisibility, contract, flexibleCoupons, listNextStopFlexible, listQuestionHistory, userId, customer,
						isMpLockEnabled, dtoIceContext, lstPinVin);
				if (!isIveco)
				{

					// Send feedback to UCR
					if (listQuestionsToKeep != null && !listQuestionsToKeep.isEmpty())
					{
						Long warrantyDate = mpDto.getWarrantyDate() != null ? new Long(mpDto.getWarrantyDate()) : 0L;
						Boolean isDealer = true;//For save history record(save in Initialization window of the IMP), isDealer is true
						String saveComments = "";
						String projectNumber = "";
						Integer projectVersion = 0;
						Long planExtId = mpDto.getPlanExternalId();
						String planId = mpDto.getPlanId();
						Optional<MpPlanDto> optMpPlan = mpDto.getMpPlanList().stream()
								.filter(x -> (planExtId != null && planExtId.equals(x.getExtId()))
										|| (planId != null && planId.equals(x.getId().toString())))
								.findFirst();

						if (optMpPlan.isPresent())
						{
							MpPlanDto mpPlan = optMpPlan.get();
							projectNumber = mpPlan.getProjectNumber();
							projectVersion = mpPlan.getProjectVersion();
						}

						JsonObjectBuilder body = null;
						if (dealerCode == null || dealerCode.isEmpty())
						{
							body = new MaintenanceUcrUtil().prepareJsonOpenApiFeedback(new ArrayList<>(), listQuestionsToKeep, mpDto.getWarranty().getVin(),
									mpDto.getPlanExternalId(), null, dealerName, userId, null, warrantyDate, isDealer, couponOperationJsonForUCR, saveComments, projectNumber, projectVersion);
						}
						else
						{
							body = new MaintenanceUcrUtil().prepareJsonOpenApiFeedback(new ArrayList<>(), listQuestionsToKeep, mpDto.getWarranty().getVin(),
									mpDto.getPlanExternalId(), dealerCode, dealerName, null, null, warrantyDate, isDealer, couponOperationJsonForUCR, saveComments, projectNumber, projectVersion);
						}

						OpenApiParameters args = new OpenApiParameters(mpDto.getWarranty().getVin(), OpenApiWebServiceEnum.FEEDBACK, userId, body.build().toString());

						OpenApiWebService.call(args);
					}
				}
			}
		}
		else if ((ucrManageMp || historyModified) && mpPlanUcr != null && mpPlanUcr.getId() != null)	// Jump from UCR
		{
			selectProposedCouponFromUCR(vin, new Double(mpDto.getActualHour()), mpDto.getListIntervals(), listQuestionsToKeep, userId, dealerCode, dealerName, nextCouponFromUcr, locale, mpPlanUcr,
					mpBusiness, dtoIceContext, listQuestionHistory, isConnectedUcr, historyModified, couponOperationJsonForUCR, mpDto);

			logger.error("error interval list: " + mpDto.getListIntervals());
			logger.error("error question list: " + listQuestionHistory);
			logger.error("error flex list: " + listNextStopFlexible);
			logger.error("error  warranty: " + mpDto.getWarranty());
			logger.error("error warranty vin : " + mpDto.getWarranty().getVin());
			logger.error("error plan ucr: " + mpPlanUcr);
			logger.error("error plan ucr id: " + mpPlanUcr.getId());
			logger.error("error contract visibility: " + contractVisibility);
			logger.error("error warranty start date: " + mpDto.getWarrantyDate());
			logger.error("error mileage: " + mpDto.getActualMileage());
			logger.error("error interval list: " + mpDto.getActualHour());

			List<MpNextStopDto> nextStops = mpBusiness.calculateNextStop(mpDto.getListIntervals(), listQuestionHistory, listNextStopFlexible, mpDto.getWarranty().getVin(),
					mpPlanUcr.getId(), contractVisibility, new Long(mpDto.getWarrantyDate()), new Long(mpDto.getActualMileage()), new Long(mpDto.getActualHour()));

			new MpNextStopBusiness().addNextStop(nextStops, listNextStopFlexible, contractVisibility, currentVehicleDate, new Long(mpDto.getWarrantyDate()), null, null,
					mpBusiness, lstPinVin);
		}
		else // Get the coupons saved in session when loading the Maintenance box from the Smart View
		{
			selectProposedCouponFromUCRFromSession(nextCouponFromUcr, mpDto.getListIntervals(), locale, mpBusiness, listQuestionHistory);
		}
		//Add the performanceLabel (no more done in the decorator because used by JobCard)
		setPerformanceLabel(mpDto.getListIntervals(), voodoo, customer, unitKey);
		//put in the object in order to be used in the json : used to reload the smart view for connected
		mpDto.setHistoryIsModified(historyModified);
		return mpDto.getListIntervals();

	}

	/**
	 * Re calculate the next stop if the history changed.
	 * for contract with alect (for CV) - re-create alert if alerts still exists
	 *
	 * @param customer : customer
	 * @param flexibleCoupons : list of flexible coupon
	 * @param contract : all contract data
	 * @param contractVisibility : contract Visibility
	 * @param currentVehicleDate : current vehicle data
	 * @param isMpLockEnabled : set false (or get from database check how to get from setMaintenancePlanContext)
	 * @param mpDto : data relative the mp (initialize in the function setMaintenancePlanContext)
	 * @param userId : user id only used for UCR for log
	 * @param mpBusiness : mp Business
	 * @param mpPlanUcr : the MP plan provide by UCR
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	protected static void updateNextStopHistoryChanged(MaintenancePlanBusiness mpBusiness, MaintenancePlanDto mpDto, CurrentVehicleDataDto currentVehicleDate,
			ContractVisibility contractVisibility, MpContractDto contract, Map<String, MpFlexCouponDto> flexibleCoupons,
			List<MpNextStopDto> listNextStopFlexible, List<MpHistoryIntervalDto> listQuestionHistory,
			String userId, String customer, boolean isMpLockEnabled, IceContextDto context, List<String> lstPinVin) throws SystemException, ApplicativeException {
		MpLockBusiness mpLockBusiness = new MpLockBusiness();
		// Lock MP
		boolean proceed = false;

		if (mpLockBusiness.addMpLock(mpDto.getWarranty().getVin(), isMpLockEnabled))
		{
			proceed = true;
			/** Create transaction. */
			TransactionAccess transaction;
			transaction = new TransactionAccess();
			try
			{
				/** Begin transaction. */
				transaction.beginTransaction();
				MpNextStopMinDto minNextStop = null;
				MpNextStopMinDto oldMinNextStop = null;
				//update next stop if history change
				if (contractVisibility.hasProposalDateAndAlert())
				{
					//get the old min stop in order to check if the status should be set to TO_RECALL
					oldMinNextStop = new MpNextStopBusiness().getMpNextStopMin(lstPinVin);
					// get the external alert to set the flag
					minNextStop = new MpNextStopMinDto(mpDto.getWarranty().getVin(), new Long(mpDto.getPlanId()), contract.getActiveMpContract().getContractNumber());
					minNextStop.setCurrentMileage(new Long(mpDto.getActualMileage()));
					minNextStop.setCurrentHour(new Long(mpDto.getActualHour()));
					if (oldMinNextStop != null)
					{
						minNextStop.setMpCallStatus(oldMinNextStop.getMpCallStatus());
					}
				}
				else
				{
					currentVehicleDate = null;
				}
				//TODO MML set the status on the coupons with external alert
				List<MpNextStopDto> nextStops = mpBusiness.calculateNextStop(mpDto.getListIntervals(), listQuestionHistory, listNextStopFlexible, mpDto.getWarranty().getVin(),
						new Long(mpDto.getPlanId()),
						contractVisibility, new Long(mpDto.getWarrantyDate()), new Long(mpDto.getActualMileage()), new Long(mpDto.getActualHour()));
				new MpNextStopBusiness().addNextStop(nextStops, listNextStopFlexible, contractVisibility, currentVehicleDate, new Long(mpDto.getWarrantyDate()),
						minNextStop, oldMinNextStop, mpBusiness, lstPinVin);
				//MML - Re-call the creation of alert if needed : it will update the previous alert id in MP_NEXT_STOP_MIN if needed
				if (contractVisibility.hasProposalDateAndAlert())
				{
					MpContractVehicleDto mpContractVehicleDto = new MpFlexMaintenanceBusiness().getMpActiveFlexContract(mpDto.getWarranty().getVin());
					if (IceConstantes.PROFILE_IVECO.equals(customer) && mpContractVehicleDto != null)
					{
						// not recalling ws because it has been current mileage has been updated in content action and set in session
						MaintenanceAlertService service = new MaintenanceAlertService(userId, contract, mpContractVehicleDto, currentVehicleDate,
								nextStops, customer, flexibleCoupons, context);
						service.run();
					}
				}
				/** Commit transaction. */
				transaction.commitTransaction();

			}
			catch (SystemException e)
			{
				// RollBack transaction
				transaction.rollbackTransaction();
				throw new ApplicativeException(e);
			}
			finally
			{
				transaction.endTransaction();
				// unlock MP
				if (proceed)
				{
					mpLockBusiness.removeMpLock(mpDto.getWarranty().getVin(), isMpLockEnabled);
				}
			}
		}

	}

	/**
	 * Select the proposed coupon from next coupon calling UCR.
	 *
	 * @param pinVin : pinVin
	 * @param currentVehicleDate : current Vehicle Date
	 * @param intervalList : list of interval for the plan
	 * @param listQuestionsToKeep : list of history entered by the dealer and to be transfered to UCR
	 * @param userId : user Id (used only for log)
	 * @param dealerCode : dealer Code
	 * @param dealerName : dealer name
	 * @param couponsInSessionList : coupon previously retrieved from UCR
	 * @param locale : locale
	 * @param mpPlanUcr : the MP plan provide by UCR
	 * @param ucrMpNextStopDtoList : the UCR mp next stop dto list
	 */
	protected static void selectProposedCouponFromUCR(String pinVin, Double actualHours, List<MpIntervalDto> intervalList, List<MpHistoryIntervalDto> listQuestionsToKeep,
			String userId, String dealerCode, String dealerName, List<MpNextStopDto> couponsInSessionList, Locale locale, MpPlanDto mpPlanUcr,
			MaintenancePlanBusiness mpBusiness, IceContextDto currentContext, List<MpHistoryIntervalDto> listQuestionHistory, Boolean isConnectedUcr, boolean historyModified,
			Map<String, JsonArrayBuilder> couponOperationJsonForUCR, MaintenancePlanDto mpDto)
			throws SystemException, ApplicativeException {

		JsonObjectBuilder body = Json.createObjectBuilder();
		List<MpUsageDto> applicableMissionList = new ArrayList<MpUsageDto>();

		if (historyModified)
		{
			Long planId = mpPlanUcr.getExtId() != null ? mpPlanUcr.getExtId() : mpPlanUcr.getId();
			String projectNumber = "";
			Integer projectVersion = 0;
			Long planExtId = mpDto.getPlanExternalId();
			Optional<MpPlanDto> optMpPlan = mpDto.getMpPlanList().stream()
					.filter(x -> (planExtId != null && planExtId.equals(x.getExtId()))
							|| (planId != null && planId.equals(x.getId())))
					.findFirst();

			if (optMpPlan.isPresent())
			{
				MpPlanDto mpPlan = optMpPlan.get();
				projectNumber = mpPlan.getProjectNumber();
				projectVersion = mpPlan.getProjectVersion();
			}

			Boolean isDealer = true;//For save history record(save in Initialization window of the IMP), isDealer is 0
			String saveComments = "";

			//MML TODO REVIEW THE VIN 9 or 17
			if (dealerCode == null || dealerCode.isEmpty())
			{
				body = new MaintenanceUcrUtil().prepareJsonOpenApiFeedback(new ArrayList<>(), listQuestionsToKeep, pinVin, planId, null, dealerName, userId, actualHours,
						mpBusiness.getWarranty(), isDealer, couponOperationJsonForUCR, saveComments, projectNumber, projectVersion);
			}
			else
			{
				body = new MaintenanceUcrUtil().prepareJsonOpenApiFeedback(new ArrayList<>(), listQuestionsToKeep, pinVin, planId, dealerCode, dealerName, null, actualHours,
						mpBusiness.getWarranty(), isDealer, couponOperationJsonForUCR, saveComments, projectNumber, projectVersion);
			}

			OpenApiParameters args = new OpenApiParameters(pinVin, OpenApiWebServiceEnum.FEEDBACK, userId, body.build().toString());

			OpenApiWebService.call(args);
		}

		// ############# CALL GET NEXT MAINTENANCE COUPONS ONLY IF HISTORY HAS BEEN MANUALLY INPUT ################

		body = new MaintenanceUcrUtil().prepareJsonOpenApiNextCoupons(pinVin, isConnectedUcr, actualHours, currentContext.getLanguage().getIdlanguage());

		OpenApiParameters argsCoupons = new OpenApiParameters(pinVin, OpenApiWebServiceEnum.NEXT_COUPONS, userId, body.build().toString());

		JsonObject resultCoupons = OpenApiWebService.call(argsCoupons);

		JsonObject dataObject = resultCoupons.getJsonObject(VehicleTelematicsConstants.PARAM_DATA);

		MpNextStopMinDto mpNextStopMin = new MpNextStopMinDto();

		try
		{
			// Prepare all the Dtos from the JSON
			couponsInSessionList.clear();
			getMpNextStopListFromUCR(dataObject, couponsInSessionList, mpNextStopMin, mpPlanUcr, applicableMissionList);
		}
		catch (ParseException e)
		{
			throw new SystemException(e.getMessage());
		}

		// Create a new method using couponsInSessionList instead of dataObject
		//			JsonArray nextCouponsArray = dataObject.getJsonArray(NextCouponsConstants.MP_NEXT_COUPON_COUPONS);

		for (MpIntervalDto interval : intervalList)
		{
			interval.setSelected(false);
			interval.setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
			interval.setDeltaComment("");
		}

		// TODO IAZ Manage comments from Overdue and Coming soon.
		selectProposedCouponFromUCRFromSession(couponsInSessionList, intervalList, locale, mpBusiness, listQuestionHistory);

	}

	/**
	 * Select the proposed coupon from session loaded from UCR.
	 *
	 * @param intervalList : list of interval for the plan
	 * @param couponsInSessionList : coupon previously retrieved from UCR
	 * @param locale : locale
	 */
	protected static void selectProposedCouponFromUCRFromSession(List<MpNextStopDto> couponsInSessionList, List<MpIntervalDto> intervalList, Locale locale, MaintenancePlanBusiness mpBusiness,
			List<MpHistoryIntervalDto> listQuestionHistory) {

		MutableBoolean messageWritten = new MutableBoolean();

		if (couponsInSessionList != null)
		{
			for (MpNextStopDto nextStop : couponsInSessionList)
			{
				for (MpIntervalDto interval : intervalList)
				{
					// Setting the is_hidden object into interval from nextStop
					if (interval.getCode().equals(nextStop.getIntervalCode()))
					{
						interval.setHidden(nextStop.isHidden());

						/* SelectionType and selectionTypeDescription can be either:
						 * 	5 --> Heavy Overdue = Selected Heavy overdue
						 * 	4 --> Overdue = Selected Overdue
						 * 	3 --> On time = Selected
						 *  2 --> Suggested = Selected
						 *  0 --> Anticipated = Not selected
						 */
						// Only Overdue, Alert and Coming soon
						// Not Coupon history nor Coming next
						if (!NextMaintenance.ANTICIPATED.equals(nextStop.getUcrNextMaintenance()))
						{
							StringBuilder message = new StringBuilder();
							messageWritten.setFalse();

							if (NextMaintenance.OVERDUE.equals(nextStop.getUcrNextMaintenance()))
							{
								interval.setSelected(true);
								interval.setStatus(MpIntervalStatusEnum.OVERDUE);

								// Overdue message
								String messageProperties = Constants.MESSAGE_OVERDUE_OF;

								if (nextStop.isHighOverdue() || nextStop.isHighOverdueDays())
								{
									// High Overdue message
									interval.setStatus(MpIntervalStatusEnum.HIGH_OVERDUE);
									messageProperties = Constants.MESSAGE_HIGH_OVERDUE_OF;
								}

								// Hours
								if (nextStop.getOverdueValue(MpType.MP_HOUR) != null && nextStop.getOverdueValue(MpType.MP_HOUR).compareTo(new Long(0)) != 0)
								{
									message.append(mpBusiness.generateComment(messageWritten, messageProperties, MpType.MP_HOUR, nextStop.getOverdueValue(MpType.MP_HOUR), false, new String(),
											interval, true));
								}

								// Months
								if (nextStop.getOverdueValue(MpType.MP_MONTH) != null && nextStop.getOverdueValue(MpType.MP_MONTH).compareTo(new Long(0)) != 0)
								{
									message.append(mpBusiness.generateComment(messageWritten, messageProperties, MpType.MP_MONTH, nextStop.getOverdueValue(MpType.MP_MONTH), false, new String(),
											interval, true));
								}

								// If no hours nor days have been sent
								if (message.toString().isEmpty())
								{
									if (null != ResourceLabel.getInstance())
									{
										message.append(ResourceLabel.getInstance().getLabel(Constants.MESSAGE_OVERDUE, locale));
									}
									else
									{
										message.append(Constants.MESSAGE_OVERDUE);
									}

								}
							}
							// Only Coming Soon
							else if (NextMaintenance.ON_TIME.equals(nextStop.getUcrNextMaintenance()))
							{
								interval.setSelected(true);
								interval.setStatus(MpIntervalStatusEnum.ON_TIME);

								DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
								String strDate = dateFormat.format(nextStop.getProposalDate(MpType.MP_HOUR));

								interval.setForecastDate(strDate);

								//							// Hours
								//							if (null != ResourceLabel.getInstance() && nextStop.isComingSoonHours() && nextStop.getForecastValue(MpType.MP_HOUR) != null
								//									&& nextStop.getForecastValue(MpType.MP_HOUR).compareTo(new Long(0)) != 0)
								//							{
								//								message.append(mpBusiness.generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, MpType.MP_HOUR, nextStop.getForecastValue(MpType.MP_HOUR), false,
								//										new String(), interval, true));
								//							}
								//
								//							// Months
								//							if (null != ResourceLabel.getInstance() && nextStop.isComingSoonDays() && nextStop.getForecastValue(MpType.MP_MONTH) != null
								//									&& nextStop.getForecastValue(MpType.MP_MONTH).compareTo(new Long(0)) != 0)
								//							{
								//								message.append(mpBusiness.generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, MpType.MP_MONTH, nextStop.getForecastValue(MpType.MP_MONTH), false,
								//										new String(), interval, true));
								//							}
							}
							// Only Coming Soon
							else if (NextMaintenance.SUGGESTED.equals(nextStop.getUcrNextMaintenance()))
							{
								interval.setSelected(true);
								interval.setStatus(MpIntervalStatusEnum.COMING_SOON);

								DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
								String strDate = dateFormat.format(nextStop.getProposalDate(MpType.MP_HOUR));

								interval.setForecastDate(strDate);

								// Hours
								if (nextStop.getForecastValue(MpType.MP_HOUR) != null
										&& nextStop.getForecastValue(MpType.MP_HOUR).compareTo(new Long(0)) != 0)
								{
									message.append(mpBusiness.generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, MpType.MP_HOUR, nextStop.getForecastValue(MpType.MP_HOUR), false,
											new String(), interval, true));
								}

								// Months
								if (nextStop.isComingSoonDays() && nextStop.getForecastValue(MpType.MP_MONTH) != null
										&& nextStop.getForecastValue(MpType.MP_MONTH).compareTo(new Long(0)) != 0)
								{
									message.append(mpBusiness.generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, MpType.MP_MONTH, nextStop.getForecastValue(MpType.MP_MONTH), false,
											new String(), interval, true));
								}
							}

							interval.setDeltaComment(message.toString());
						}
					}
				}
			}

			// Manage the frozen period for connected vehicles
			for (MpIntervalDto interval : intervalList)
			{
				for (MpHistoryIntervalDto questionDto : listQuestionHistory)
				{
					if (questionDto.getIntervalCode().equals(interval.getCode()))
					{
						interval.setModifiable(questionDto.isCanBeModified());
						interval.setSavable(questionDto.isCanBeSaved());
					}
				}
			}
		}
	}

	/**
	 * Select the proposed coupon from session loaded from UCR.
	 *
	 * @param intervalList : list of interval for the plan
	 * @param couponsInSessionList : coupon previously retrieved from UCR
	 * @param locale : locale
	 */
	protected static void setPerformanceLabel(List<MpIntervalDto> intervalList, Map<String, String> intervalIds, String customer, String unit) {
		boolean isIveco = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));

		for (MpIntervalDto dto : intervalList)
		{
			dto.setPerformanceLabel(MaintenanceUtil.getTitle(dto, intervalIds, isIveco, unit));
		}
	}

	/**
	 * retrieve mp history.
	 * for the eTIM need it also retrieve the coupon without history and overdue (in this case the history is requested to the dealer)
	 * it also return if the history is valid : if the current mileage/hour is not inferior to the existing history
	 *
	 * @param mpDto : data relative the mp
	 * @param contract : all contract data
	 * @param vin : vehicle number
	 * @param nowDate : current date (from JobCard java script nowdate=(new Date()).getTime())
	 * @param jumpFromAlertUCR : is coupon selected received from UCR (false from JobCard because AG&CE not yet implemented)
	 * @param languageId : language Id
	 * @param defaultLanguage : default Language
	 * @param customer : customer
	 * @param flexibleCoupons : list of flexible coupon (to be checked with Julien and check how to get from setMaintenancePlanContext)
	 * @param dealerCode : dealer code retrieved from UCR (check how to get from setMaintenancePlanContext)
	 * @param listHistoryQuestion : result param set the value for the json
	 * @param listNewQuestion : result param set the value for the json
	 *
	 * @return result history list
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static List<MpHistoryIntervalDto> getMpHistory(MaintenancePlanDto mpDto, MpContractDto contract, List<String> lstPinVin, String languageId, String defaultLanguage,
			Map<String, MpFlexCouponDto> flexibleCoupons,
			String customer, String nowDate, String jumpFromAlertUCR, boolean callFromETIM, List<MpHistoryIntervalDto> listHistoryQuestion, List<MpHistoryIntervalDto> listNewQuestion,
			IceContextDto context)
			throws SystemException, ApplicativeException {
		List<MpHistoryIntervalDto> listHistory = new ArrayList<>();
		List<MpHistoryIntervalDto> listHistoryResult = new ArrayList<>();

		// -- Get the external plan Id linked to plan Id
		mpDto.setPlanExternalId((new MpPlanBusiness()).getExternalPlanId(new Long(mpDto.getPlanId())).getExtId());

		boolean isIveco = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));
		boolean isFlexHeavy = false;
		if (contract != null && ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract()))
		{
			isFlexHeavy = true;
		}

		// -- get the list of interval (For AG&CE, retrieve only non-customer intervals)
		List<MpIntervalDto> listIntervals = MpIntervalBusiness.getMaintenanceIntervals(new Long(mpDto.getPlanId()), languageId, defaultLanguage, Context.getStringProperty("mp.family.code"), isIveco);
		Collections.sort(listIntervals, new MpIntervalByCodeComparator(flexibleCoupons));
		mpDto.setListIntervals(listIntervals);

		// -- read history of intervals for the VIN
		listHistory = getMpHistoryFromDB(lstPinVin, contract, flexibleCoupons, mpDto.getPlanExternalId());
		// -- from history and intervals ask questions if needed
		Locale locale = new Locale(languageId);

		// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
		MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(mpDto, nowDate, locale, customer, null, context);
		mpBusiness.setFlexibleCoupons(flexibleCoupons);
		if (callFromETIM)
		{
			List<MpHistoryIntervalDto> listNewQuestionTmp = mpBusiness.getNewQuestionList(lstPinVin, listHistory, listIntervals, mpDto.getPlanExternalId(), isFlexHeavy);
			listNewQuestion.addAll(listNewQuestionTmp);
		}

		boolean valid = true; // -- history is coherent
		if (!lstPinVin.isEmpty())
		{

			List<MpHistoryIntervalDto> listHistoryQuestionTmp = mpBusiness.getHistoryQuestionList(listHistory, listIntervals);
			listHistoryQuestion.addAll(listHistoryQuestionTmp);
			valid = mpBusiness.getValidActual(listHistoryQuestion, listNewQuestion, listIntervals);
		}

		if (listNewQuestion != null)
		{
			listHistoryResult.addAll(listNewQuestion);
		}
		if (listHistoryQuestion != null)
		{
			listHistoryResult.addAll(listHistoryQuestion);
		}
		if (callFromETIM)
		{
			if (Boolean.parseBoolean(jumpFromAlertUCR))
			{
				boolean canBeModified = true;
				for (MpHistoryIntervalDto question : listHistoryResult)
				{
					canBeModified = true;
					for (MpType type : MpType.values())
					{
						if (question.retreiveFromExactValueByMpType(type) != null && question.retreiveFromExactValueByMpType(type) != 0)
						{
							canBeModified = false;
							break;
						}
					}
					question.setCanBeModified(canBeModified);
				}
			}
			// -- build JSON.
			if (contract != null)
			{
				mpDto.setHasContract(true);

			}
		}
		//valid status for the json in eTIM
		mpDto.setHasValidHistory(valid);
		return listHistoryResult;
	}

	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/************************************************* Update SAP History ***************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/

	/**
	 * Call ExectuorService to update in background the MP history from SAP broker MP repair.
	 *
	 * @param vin vehicle number
	 * @param contract list of contracts
	 * @param sapVehicleInformation sap vehicle info
	 * @param tidbCustomer customer
	 * @param flexCoupons list of flex coupon
	 * @param isDvd id launch from eTIM GO
	 */
	public static void callMpHistoryUpdatedBySAP(String vin, List<String> vinList, MpContractDto contract, ResponseData sapVehicleInformation, String tidbCustomer,
			Map<String, MpFlexCouponDto> flexCoupons, boolean isDvd,
			IceContextDto context) {
		// Call service executor

		if (!isDvd)
		{
			int toleranceToMatch = new Integer(Context.getStringProperty("mp.tolerance.tomatch"));
			int toleranceToWait = new Integer(Context.getStringProperty("mp.tolerance.towait"));

			MPSapHistoryService service = new MPSapHistoryService(vin, vinList, Constants.ENGLISH, sapVehicleInformation,
					contract, toleranceToMatch, toleranceToWait, context);
			service.setCouponFlexibles(flexCoupons);
			service.setCustomer(tidbCustomer);
			service.runWithoutThread();
		}
	}

	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/************************************************* Calculate Next stop ***************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/

	public static SmartViewMaintenanceViewDto getSmartViewMaintenanceViewDtoByVin(MyVehicleContextDto myVehicleContextDto, String customer, String user) {
		SmartViewMaintenanceViewDto smartViewMaintenanceViewDto = null;
		IceContextDto dtoIceContext = null;
		MpContractDto contract = null;
		CurrentVehicleDataDto currentVehicleData = null;
		MaintenancePlanDto mpDto = null;
		if (myVehicleContextDto != null)
		{
			contract = myVehicleContextDto.getMpContract();
			dtoIceContext = myVehicleContextDto.getContextDto();
			currentVehicleData = myVehicleContextDto.getCurrentVehicleData();
			ResponseData sapVechicleInfo = myVehicleContextDto.getSapVehicleInformation();
			ProductConfiguration productConfiguration = myVehicleContextDto.getProductConfiguration();
			mpDto = myVehicleContextDto.getMpInteractive();

			if (mpDto != null)
			{
				Map<String, MpFlexCouponDto> flexibleCoupons = mpDto.getFlexibleCoupons();
				smartViewMaintenanceViewDto = getSmartViewMaintenanceViewDtoByVin(myVehicleContextDto.getPinVin(), myVehicleContextDto.getVinList(), currentVehicleData, dtoIceContext,
						productConfiguration, flexibleCoupons,
						customer,
						sapVechicleInfo, contract, user, mpDto.getUcrNextStopList(), mpDto.getUcrNextStopMin(), mpDto.getMpPlanSelected());
			}
		}
		return smartViewMaintenanceViewDto;
	}

	/**
	 *
	 * @param vin
	 * @param currentVehicleDataDto
	 * @param contextDto
	 * @param productConfiguration
	 * @param flexibleCoupons
	 * @param customer
	 * @param sapVechicleInfo
	 * @param mpContractDto
	 * @param user
	 * @param listNextStop
	 * @param mpNextStopMin
	 * @return
	 */
	public static SmartViewMaintenanceViewDto getSmartViewMaintenanceViewDtoByVin(String vin, List<String> lstPinVin, CurrentVehicleDataDto currentVehicleDataDto, IceContextDto contextDto,
			ProductConfiguration productConfiguration, Map<String, MpFlexCouponDto> flexibleCoupons, String customer, ResponseData sapVechicleInfo, MpContractDto mpContractDto, String user,
			List<MpNextStopDto> listNextStop, MpNextStopMinDto mpNextStopMin, MpPlanDto planDto) {

		boolean isIveco = IceConstantes.PROFILE_IVECO.equals(customer);
		List<MpUsageDto> applicableMissionList = new ArrayList<MpUsageDto>();

		//Get EDS informtion
		// TODO IAZ Manage connectivity
		// --> Contract CV / Contract AG Not Connected
		if (mpContractDto != null && currentVehicleDataDto != null && !currentVehicleDataDto.isUcrManageMP())
		{
			try
			{
				//MML TO DO  improve replace sapVechicleInfo by warranty start date
				//MML TO DO  improve replace contextDto and productConfiguration by passing
				String errorCase = retrieveNextStopWithContract(listNextStop, vin, mpContractDto, sapVechicleInfo, currentVehicleDataDto, mpNextStopMin, customer, false, productConfiguration,
						contextDto, flexibleCoupons, Arrays.asList(vin));

				// create only for flexible contract
				MpFlexMaintenanceBusiness mpFlexMaintenanceBusiness = new MpFlexMaintenanceBusiness();
				MpContractVehicleDto mpContractVehicleDto = mpFlexMaintenanceBusiness.getMpActiveFlexContract(vin);
				if (errorCase.equals("0") && isIveco && mpContractVehicleDto != null)
				{
					// not recalling ws because it has been current mileage has been updated in content action and set in session
					// vehicule date to recover in session
					//for JOB card this method is not called as a thread
					MaintenanceAlertService service = new MaintenanceAlertService(user, mpContractDto, mpContractVehicleDto, currentVehicleDataDto,
							listNextStop, customer, flexibleCoupons, contextDto);
					service.run();
				}
			}
			catch (SystemException | ApplicativeException e)
			{
				logger.error("Error retrieveNextStopWithContract for vin : " + vin, e);
			}
		}
		// --> Contract AG Connected / No Contract AG Connected
		else if ((mpContractDto != null || mpContractDto == null) && !isIveco && currentVehicleDataDto != null && currentVehicleDataDto.isUcrManageMP() && planDto != null)
		{
			// Do nothing --> Everything calculated in intializeMaintenancePlanContext
		}
		// --> No Contract CV / No Contract AG Not Connected
		else
		{
			try
			{
				//MML TO DO  improve replace sapVechicleInfo by warranty start date
				retrieveNextStopWithoutContract(listNextStop, vin, productConfiguration, sapVechicleInfo, customer, false, contextDto, flexibleCoupons, Arrays.asList(vin), currentVehicleDataDto);
			}
			catch (ApplicativeException e)
			{
				logger.error("Error retrieveNextStopWithoutContract for vin : " + vin, e);

			}
		}

		SmartViewMaintenanceViewDto smartViewMaintenanceViewDto = new SmartViewMaintenanceViewDto();

		try
		{
			smartViewMaintenanceViewDto = getSmartViewMaintenanceDto(lstPinVin, listNextStop, mpNextStopMin, currentVehicleDataDto,
					currentVehicleDataDto != null ? currentVehicleDataDto.isUcrManageMP() : false, flexibleCoupons,
					contextDto.getBrand().getIceCode(), contextDto.getType().getIceCode(), contextDto.getProduct().getIceCode(), contextDto.getSeries().getIceCode(), sapVechicleInfo, customer,
					applicableMissionList);

		}
		catch (SystemException | ApplicativeException e)
		{
			logger.error("Error getSmartViewMaintenanceDto for vin : " + vin, e);

		}

		return smartViewMaintenanceViewDto;
	}

	/**
	 * Retrieve next maintenance stop for a VIN without contract.
	 *
	 * @param listNextStopResult : listNextStopResult (out parameter)
	 * @param vin : vin
	 * @param contract : contract
	 * @param sapVechicleInfo : sapVechicleInfo
	 * @param currentVehicleData : currentVehicleData
	 * @param minNextStopResult the minNextStopResult
	 * @param customer iveco or agce
	 * @param mpLockEnabled if true try to add a lock
	 * @param productConfiguration product Configuration
	 * @param iceContextDto ice Context Dto
	 * @return return error code
	 * @throws ApplicativeException an applicative exception CurrentVehicleDataDto currentVehicleData
	 * @throws SystemException
	 */
	public static String retrieveNextStopWithContract(List<MpNextStopDto> listNextStopResult, String vin, MpContractDto contract, ResponseData sapVechicleInfo,
			CurrentVehicleDataDto currentVehicleData, MpNextStopMinDto minNextStopResult, String customer, boolean mpLockEnabled, ProductConfiguration productConfiguration,
			IceContextDto iceContextDto, Map<String, MpFlexCouponDto> flexibleCoupons, List<String> lstPinVin)
			throws ApplicativeException, SystemException {

		MpContractVehicleDto activeContract = null;
		String warrantyDate = null;
		boolean toBeRecalculated = false;
		boolean proceed = false;
		String errorCase = "0";
		List<MpNextStopDto> listNextStop = new ArrayList<>();
		MpNextStopMinDto minNextStop = null;
		MpLockBusiness mpLockBusiness = new MpLockBusiness();
		CurrentVehicleDataDto currentVehicleDataLocal = null;
		boolean isIVECO = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));

		ContractVisibility contractVisibility = new ContractVisibility(contract);
		if (contract != null && contract.getActiveMpContract() != null)
		{

			if (!isIVECO || ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract())
					|| ConnectedTypeEnum.LIGHT_TARGA_CONNECTED.getValue().equals(contract.getActiveMpContract().getConnectedType()))
			{
				currentVehicleDataLocal = currentVehicleData;
			}

			activeContract = contract.getActiveMpContract();

			MpHistoryWarrantyDto warrantyStartDateDto = new MpHistoryWarrantyDto();

			if (isIVECO)
			{
				warrantyStartDateDto = MaintenancePlanActionWarrantyDateIvecoService.getWarrantyStartDate(sapVechicleInfo, contract, vin);
			}
			else
			{
				warrantyStartDateDto = MaintenancePlanActionWarrantyDateCnhService.getWarrantyStartDate(sapVechicleInfo, currentVehicleDataLocal, contract, lstPinVin);
			}

			warrantyDate = warrantyStartDateDto.getWarrantyDate();
		}
		if (activeContract != null)
		{
			// Lock MP
			if (mpLockBusiness.addMpLock(vin, mpLockEnabled))
			{
				proceed = true;
			}
			/** Create transaction. */
			TransactionAccess transaction;
			try
			{
				transaction = new TransactionAccess();
				try
				{
					/** Begin transaction. */
					transaction.beginTransaction();

					// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
					MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(null, customer, transaction, iceContextDto);
					mpBusiness.setFlexibleCoupons(flexibleCoupons);

					//Check if next stop needs to be recalculated
					MpNextStopBusiness nextStopBussiness = new MpNextStopBusiness(transaction);

					//check plan applicable
					MpPlanDto planDto = new MpPlanBusiness().checkPlanApplicable(activeContract.getPlanId(), iceContextDto, productConfiguration);
					if (planDto == null)
					{
						errorCase = "2";// plan not applicable
						new DMCBusiness().logFailureMP("ALL", Constants.LOG_TYPE_NO_PLAN_APP, "VIN: " + vin + " - retrieveNextStopWithContract - plan not applicable for this VIN",
								Context.getSoftwareVersion(), "ALL");
					}
					else
					{
						minNextStop = nextStopBussiness.getMpNextStopMin(lstPinVin);
						if (contractVisibility.hasProposalDateAndAlert())
						{
							//Check new plan (compare between plan id from contract and MP_NEXT_STOP_MIN ) or contract change
							//TODO MML don't update  MP_NEXT_STOP_VIN if performance doesn't change
							toBeRecalculated = true;
							if (minNextStop != null)
							{
								toBeRecalculated = !minNextStop.getIdPlan().equals(activeContract.getPlanId()) || !minNextStop.getContractNb().equals(activeContract.getContractNumber());
							}
							//or Check minimum stop is not overdue (MP_NEXT_STOP_MIN ) : only for flex contract
							if (currentVehicleDataLocal != null && minNextStop != null)
							{
								if (currentVehicleDataLocal.getCurrentMileage() != null && minNextStop.getNextValue(MpType.MP_KM) != null
										&& currentVehicleDataLocal.getCurrentMileage().compareTo(minNextStop.getNextValue(MpType.MP_KM)) > 0)
								{
									//if min = -1 set the currentMileage to the alert in MP_NEXT_FLEX_STOP for external=1
									if (proceed)
									{
										nextStopBussiness.updateNextStopFlexAlertNoValue(vin, currentVehicleDataLocal.getCurrentMileage());
									}
									toBeRecalculated = true;
								}
								else if (currentVehicleDataLocal.getCurrentHours() != null && minNextStop.getNextValue(MpType.MP_HOUR) != null
										&& currentVehicleDataLocal.getCurrentHours().compareTo(minNextStop.getNextValue(MpType.MP_HOUR)) > 0)
								{
									toBeRecalculated = true;
								}
								else if (minNextStop.getMinProposalDate(MpType.MP_MONTH) != null && (new Date()).after(minNextStop.getMinProposalDate(MpType.MP_MONTH)) ||
										(warrantyDate != null && minNextStop.getMinProposalDate(MpType.MP_MONTH) == null && minNextStop.getNextValue(MpType.MP_MONTH) != null))
								{
									//case of overdue and case of the warrranty start date was previously null and then it is reset to a new value
									toBeRecalculated = true;
								}
							}

							if (minNextStop == null)
							{
								minNextStop = new MpNextStopMinDto();
							}
						}
						else
						{
							//Check new plan (compare between plan id from contract and MP_NEXT_STOP) or contract change from flex-> not flex (delete min table)
							//if no plan found to be calculated
							toBeRecalculated = nextStopBussiness.checkPlanChange(lstPinVin, activeContract.getPlanId()) || minNextStop != null;
							if (minNextStop != null && proceed)
							{
								nextStopBussiness.deleteNextStopMin(vin);
								nextStopBussiness.deleteNextFlexStop(vin);
								minNextStop = null;
							}
						}

						//or Retrieve info from update SAP history (set a value in usersession and then delete it for another seach by VIN)
						//historyUpdateOk = waitSapHistoryUpdated(contract, feedbackDto, userId, remoteAddr, vin);
						toBeRecalculated = contract.isHistoryModified() || toBeRecalculated;
						if (toBeRecalculated)
						{
							if (warrantyDate == null)
							{
								//errorCase = "3";// warranty start date not available
								new DMCBusiness().logFailureMP("ALL", Constants.LOG_TYPE_WAR_DATE_MISSING, "VIN: " + vin + " - retrieveNextStopWithContract - missing warranty start date",
										Context.getSoftwareVersion(), "ALL");
							}
							if (proceed)
							{
								listNextStop = mpBusiness.calculateNextStopAndSave(contract, vin, contractVisibility, currentVehicleDataLocal, warrantyDate, minNextStop, lstPinVin);
								// call alert web service only if the flag_alert=1
							}
						}
					}
					//otherwise
					//MML TO REVIEW for the test errorCase.equals("0")
					if (listNextStop.isEmpty() && errorCase.equals("0"))
					{
						//otherwise get next stop
						listNextStop = nextStopBussiness.getNextStops(lstPinVin);

						//distinct by IntervalCode
						HashSet<Object> seen = new HashSet<>();
						listNextStop.removeIf(e -> !seen.add(e.getIntervalCode()));

						if (contractVisibility.hasProposalDateAndAlert())
						{
							if (contractVisibility.hasComponentFlexible())
							{
								MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness(transaction);
								MpIntervalDto tolInt = mpIntervalBusiness.getCouponTolerance(activeContract.getPlanId());
								if (tolInt != null)
								{
									mpBusiness.updateDelta(tolInt.getAfterValue(MpType.MP_KM), tolInt.getAfterValue(MpType.MP_HOUR));
								}
								//Get flex coupon if in tolerance compared to the maximum between next stop min and current value
								List<MpNextStopDto> listNextFlexibleStop = nextStopBussiness.getNextStopFlexiblesInTol(vin, minNextStop, mpBusiness.getTolKm());
								for (MpNextStopDto nextFlexStop : listNextFlexibleStop)
								{
									boolean isFound = false;
									for (MpNextStopDto nextStop : listNextStop)
									{
										if (nextFlexStop.getIntervalCode().equals(nextStop.getIntervalCode()) && null != nextFlexStop.getExternal() && nextFlexStop.getExternal().intValue() != 1)
										{
											nextStop.setNextValue(MpType.MP_KM, nextFlexStop.getNextValue(MpType.MP_KM));
											isFound = true;
											break;
										}
									}
									if (!isFound)
									{
										listNextStop.add(nextFlexStop);
									}
								}
							}

							if (proceed)
							{
								//Recalculate the proposal date using the data from EDS web service for the minimum proposal date and update it
								//reevaluate alert : update flag in MP_NEXT_STOP_MIN
								nextStopBussiness.updateMinProposalDateAndAlert(minNextStop, currentVehicleDataLocal, mpBusiness.getWarrantyDateInTime(warrantyDate), mpBusiness);
							}
							//TODO MML call alert web service only if the flag_alert goes from 0->1
							//Check if urgent alert must be triggered, if yes call the web service : to be called in a thread : not wait update
							// maintenance are urgent if the min_next_stop < current_value - tolerance (and not already present : to do in web service or here)
						}

					}
					/** Commit transaction. */
					transaction.commitTransaction();
				}
				catch (SystemException | ApplicativeException e)
				{
					// RollBack transaction
					transaction.rollbackTransaction();
					throw new ApplicativeException(e);
				}
				finally
				{
					transaction.endTransaction();
					if (proceed)
					{
						// unlock MP
						mpLockBusiness.removeMpLock(vin, mpLockEnabled);
						proceed = false;
					}
				}

			}
			catch (SystemException e1)
			{
				if (proceed)
				{
					// unlock MP
					mpLockBusiness.removeMpLock(vin, mpLockEnabled);
				}
				throw new ApplicativeException(e1);
			}
		}
		if (minNextStop != null)
		{
			minNextStopResult.copy(minNextStop);
		}
		listNextStopResult.addAll(listNextStop);

		return errorCase;
	}

	/**
	 * retrieve next maintenance stop for a VIN without contract.
	 *
	 * @param listNextStopResult : listNextStopResult (out parameter)
	 * @param vin : vin
	 * @param productConfiguration : productConfiguration of the vehicle
	 * @param sapVechicleInfo : sapVechicleInfo
	 * @param customer : cv or agce
	 * @param mpLockEnabled if true try to add a lock
	 * @return return error code
	 * @throws ApplicativeException an applicative exception
	 */
	public static String retrieveNextStopWithoutContract(List<MpNextStopDto> listNextStopResult, String vin, ProductConfiguration productConfiguration, ResponseData sapVechicleInfo, String customer,
			boolean mpLockEnabled,
			IceContextDto contextDto, Map<String, MpFlexCouponDto> flexibleCoupons, List<String> lstPinVin, CurrentVehicleDataDto currentVehicleDataDto)
			throws ApplicativeException {
		String errorCase = "0";

		boolean toBeRecalculated = false;

		MpLockBusiness mpLockBusiness = new MpLockBusiness();
		List<MpNextStopDto> listNextStop = new ArrayList<>();
		boolean proceed = false;
		// Lock MP if mpLockEnabled
		if (mpLockBusiness.addMpLock(vin, mpLockEnabled))
		{
			proceed = true;
		}
		/** Create transaction. */
		TransactionAccess transaction;
		try
		{
			transaction = new TransactionAccess();
			try
			{
				/** Begin transaction. */
				transaction.beginTransaction();

				// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
				MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(null, customer, transaction, contextDto);
				mpBusiness.setFlexibleCoupons(flexibleCoupons);

				MpNextStopBusiness nextStopBussiness = new MpNextStopBusiness(transaction);

				//Retrieve plan from next stop or from history and see if the version of plan changed
				Long planId = null;
				MpPlanBusiness planBusiness = new MpPlanBusiness();

				listNextStop = nextStopBussiness.getNextStops(lstPinVin);

				//distinct by IntervalCode
				HashSet<Object> seen = new HashSet<>();
				listNextStop.removeIf(e -> !seen.add(e.getIntervalCode()));

				Long planExtId = null;

				List<MpHistoryIntervalDto> listAllHistory = MpIntervalBusiness.readListHistoryInterval(lstPinVin, null, null);

				if (!listAllHistory.isEmpty())
				{
					planExtId = listAllHistory.get(0).getPlanExternalId();
					if (planExtId != null)
					{
						MpPlanDto planDto = planBusiness.checkLastVersionPlanApplicable(planExtId, contextDto, productConfiguration);
						//case of previously a MP flexible was applicable
						MpNextStopMinDto minNextStop = nextStopBussiness.getMpNextStopMin(lstPinVin);
						if (minNextStop != null && proceed)
						{
							nextStopBussiness.deleteNextStopMin(vin);
							nextStopBussiness.deleteNextFlexStop(vin);
						}
						if (planDto != null)
						{
							planId = planDto.getId();
							if (listNextStop.isEmpty())
							{
								toBeRecalculated = true;
							}
							else
							{
								Long oldPlanId = listNextStop.get(0).getIdPlan();
								toBeRecalculated = !oldPlanId.equals(planDto.getId()) || minNextStop != null;
							}
						}
						else
						{
							errorCase = "2";// no more plan applicable for this VIN
							new DMCBusiness().logFailureMP("ALL", Constants.LOG_TYPE_NO_PLAN_APP, "VIN: " + vin + " - retrieveNextStopWithoutContract - no more plan applicable for this VIN",
									Context.getSoftwareVersion(), "ALL");
							if (!listNextStop.isEmpty() && proceed)
							{
								nextStopBussiness.deleteNextStop(lstPinVin);
							}
							listNextStop = new ArrayList<>();
						}
					}
				}
				else
				{
					errorCase = "1";// none plan defined for this VIN
					if (!listNextStop.isEmpty() && proceed)
					{
						nextStopBussiness.deleteNextStop(lstPinVin);
					}
					listNextStop = new ArrayList<>();
				}
				//for no contract, get the plan id of the last version and compare to the plan id in the next stop table
				if (toBeRecalculated)
				{
					//Get warranty start date
					Long warrantyStartDate = null;
					boolean isIVECO = (null != customer && customer.equals(IceConstantes.PROFILE_IVECO));
					MpHistoryWarrantyDto warrantyStartDateDto = new MpHistoryWarrantyDto();

					if (isIVECO)
					{
						warrantyStartDateDto = MaintenancePlanActionWarrantyDateIvecoService.getWarrantyStartDate(sapVechicleInfo, null, vin);
					}
					else
					{
						warrantyStartDateDto = MaintenancePlanActionWarrantyDateCnhService.getWarrantyStartDate(sapVechicleInfo, currentVehicleDataDto, null, lstPinVin);
					}

					String warrantyDate = warrantyStartDateDto.getWarrantyDate();
					if (warrantyDate != null)
					{
						warrantyStartDate = mpBusiness.getWarrantyDateInTime(warrantyDate);
					}
					else
					{
						errorCase = "3";// warranty start date not available
						new DMCBusiness().logFailureMP("ALL", Constants.LOG_TYPE_WAR_DATE_MISSING, "VIN: " + vin + "retrieveNextStopWithoutContract - missing warranty start date",
								Context.getSoftwareVersion(), "ALL");
					}

					MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness();
					List<MpIntervalDto> listInterval = mpIntervalBusiness.getMaintenanceIntervalsWithoutOperation(planId, Constants.ENGLISH, Context.getStringProperty("mp.family.code"));
					List<MpHistoryIntervalDto> listHistory = MpIntervalBusiness.readListHistoryInterval(lstPinVin, null, planExtId);
					if (proceed)
					{
						ContractVisibility contractVisibility = new ContractVisibility(false, false);
						listNextStop = mpBusiness.calculateNextStop(listInterval, listHistory, new ArrayList<MpNextStopDto>(), vin, planId, contractVisibility, warrantyStartDate, null, null);
						nextStopBussiness.addNextStop(listNextStop, null, contractVisibility, null, warrantyStartDate, null, null, null, lstPinVin);
					}

				}

				/** Commit transaction. */
				transaction.commitTransaction();
			}
			catch (SystemException | ApplicativeException e)
			{

				// RollBack transaction
				transaction.rollbackTransaction();
				throw new ApplicativeException(e);
			}
			finally
			{
				transaction.endTransaction();
				if (proceed)
				{
					// unlock MP
					mpLockBusiness.removeMpLock(vin, mpLockEnabled);
					proceed = false;
				}
			}
		}
		catch (SystemException e1)
		{
			if (proceed)
			{
				// unlock MP
				mpLockBusiness.removeMpLock(vin, mpLockEnabled);
			}
			throw new ApplicativeException(e1);
		}
		listNextStopResult.addAll(listNextStop);
		listNextStopResult.stream().distinct().collect(Collectors.toList());
		return errorCase;

	}

	/**
	 * @param listNextStop
	 * @param mpNextStopMin
	 * @param currentVehicleDataDto
	 * @param flexCoupons
	 * @param customer
	 * @return
	 * @throws ApplicativeException
	 * @throws SystemException
	 */
	public static SmartViewMaintenanceViewDto getSmartViewMaintenanceDto(List<String> lstPinVin, List<MpNextStopDto> listNextStop, MpNextStopMinDto mpNextStopMin,
			CurrentVehicleDataDto currentVehicleDataDto,
			boolean mpAvailableFromUcr, Map<String, MpFlexCouponDto> flexCoupons, String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode,
			ResponseData sapVehicleInformation, String customer, List<MpUsageDto> applicableMissionList) throws SystemException, ApplicativeException {
		SmartViewMaintenanceViewDto smartViewMaintenanceViewDto = new SmartViewMaintenanceViewDto();

		if (!listNextStop.isEmpty())
		{
			// For UCR The Next stop value in hours, the overdue in hours will be managed here. The proposal date and overdue in days is set in the lines below.
			List<MpNextStopViewDto> nextMaintenanceList = new MpNextStopViewDtoMapper().mapDtoToListView(listNextStop, mpNextStopMin, mpAvailableFromUcr, flexCoupons);
			smartViewMaintenanceViewDto.setNextMaintenanceList(nextMaintenanceList);
		}

		if (currentVehicleDataDto != null)
		{
			smartViewMaintenanceViewDto.setCurrentMileage(currentVehicleDataDto.getCurrentMileage());
			smartViewMaintenanceViewDto.setCurrentHour(currentVehicleDataDto.getCurrentHours());
			smartViewMaintenanceViewDto.setUcrStatusMsg(currentVehicleDataDto.findCoveredByUcrStatusMessage());
			smartViewMaintenanceViewDto.setUcrStatus(currentVehicleDataDto.getConnectivityStatus());
			smartViewMaintenanceViewDto.setLastCommunicationDate(currentVehicleDataDto.getLastCommunicationDate());
			smartViewMaintenanceViewDto.setMpAlertActive(currentVehicleDataDto.isMpAlertActive());
		}

		Date minProposalDate = null;

		if (!listNextStop.isEmpty())
		{
			for (MpType mpType : MpType.values())
			{
				if (mpNextStopMin != null && mpNextStopMin.getMinProposalDate(mpType) != null && (minProposalDate == null || mpNextStopMin.getMinProposalDate(mpType).before(minProposalDate)))
				{
					minProposalDate = mpNextStopMin.getMinProposalDate(mpType);
				}
				if (mpNextStopMin != null && mpNextStopMin.getMinProposalDate(mpType) == null && mpNextStopMin.getNextValue(mpType) != null && !mpType.equals(MpType.MP_MONTH))
				{
					minProposalDate = null;
					break;
				}
				else if (mpNextStopMin != null && mpNextStopMin.getMinProposalDate(mpType) == null && mpType.equals(MpType.MP_MONTH))
				{
					for (MpNextStopViewDto dto : smartViewMaintenanceViewDto.getNextMaintenanceList())
					{
						if (MpType.MP_MONTH.toString().equals(dto.getMpType()) && dto.getCoupons() != null && !dto.getCoupons().isEmpty())
						{
							minProposalDate = null;
							break;
						}
					}
				}
			}
		}

		if (minProposalDate != null)
		{
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			smartViewMaintenanceViewDto.setProposalDateMilliSec(minProposalDate.getTime());
			smartViewMaintenanceViewDto.setProposalDate(df.format(minProposalDate));
			smartViewMaintenanceViewDto.setDaysInOverdue(mpNextStopMin.getDaysInOverdue());
		}

		if (mpNextStopMin.getIdPlan() != null)
		{
			smartViewMaintenanceViewDto.setPlanId(mpNextStopMin.getIdPlan());
		}
		// Get the unit key for the current serie
		String unitKey = MaintenanceService.getUnitKeyBySerie(brandIcecode, typeIcecode, productIcecode, seriesIcecode);

		smartViewMaintenanceViewDto.setUnitKey(unitKey);

		// Message Type of Contract
		MpContractTypeMessageDto mpContractTypeMessageDto = MaintenanceService.getTypeOfContractMessage(lstPinVin, sapVehicleInformation, customer);
		smartViewMaintenanceViewDto.setContractTypeMessage(mpContractTypeMessageDto);

		// Applicable mission list
		smartViewMaintenanceViewDto.setApplicableMissionList(applicableMissionList);
		return smartViewMaintenanceViewDto;
	}

	private static String parseWarrantyDate(String warrantyStartDate, String format, String altFormat) {
		String parsedDate = null;
		try
		{
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			Date date = formatter.parse(warrantyStartDate);
			parsedDate = String.valueOf(date.getTime());
		}
		catch (ParseException pe)
		{
			if (null != altFormat)
			{
				parsedDate = parseWarrantyDate(warrantyStartDate, altFormat, null);
			}
			else
			{
				logger.error(pe.getMessage());
			}
		}
		return parsedDate;
	}

	/**
	 * Close MP alert for coupon saved.
	 *
	 * @param userId interval history
	 * @param vin list of all the intervals of the plan
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static List<EtimAlertDto> closeMPAlerts(boolean isCV, String userId, List<String> lstPinVin, List<MpHistoryIntervalDto> historyList)
			throws SystemException, ApplicativeException {
		List<String> couponList = new ArrayList<>();
		List<EtimAlertDto> mpAlertClosed = null;
		for (MpHistoryIntervalDto history : historyList)
		{
			couponList.add(history.getIntervalCode());
		}

		if (isCV)
		{
			if (null != couponList && !couponList.isEmpty())
			{
				closeMPAlerts(lstPinVin.get(0), couponList.toArray(new String[couponList.size()]), userId);
			}
		}
		else
		{
			// get alert to be closed for the vin
			List<EtimAlertDto> alertsRules = (new EtimAlertBusiness()).getAlertInstanceOpenedForVinAndCoupons(lstPinVin,
					couponList);
			mpAlertClosed = closeMPAlerts(alertsRules, userId);
		}
		return mpAlertClosed;
	}

	/**
	 * Close MP alert for coupon saved.
	 *
	 * @param userId interval history
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static List<EtimAlertDto> closeMPAlerts(List<EtimAlertDto> alertsRules, String userId)
			throws SystemException, ApplicativeException {
		TiamServicesStub tiamStub;

		if (null != alertsRules && !alertsRules.isEmpty())
		{

			for (EtimAlertDto alertRule : alertsRules)
			{
				try
				{
					// Call TIAM SOAP web service closeAlertInstancesByPinVins
					CloseAlertInstancesByPinVins request = new CloseAlertInstancesByPinVins();
					request.setAlertRuleId(alertRule.getAlertId());
					request.setPinVins(new String[] { alertRule.getPinVin() });
					request.setApplicativeUserId(IceConstantes.TIAM_SOURCE);
					request.setApplicativePassword(IceConstantes.TIAM_SOURCE);
					request.setOriginatingSystem(IceConstantes.TIAM_SOURCE);
					request.setExternalUserId(userId);
					Properties properties = ApplicationProperties.getProperties();
					String tiamServiceStub = properties.getProperty("tiam.soap.url");
					/** Stub axis2. */
					tiamStub = new TiamServicesStub(tiamServiceStub);
					CloseAlertInstancesByPinVinsResponse response = tiamStub.closeAlertInstancesByPinVins(request);
					TiamServicesStub.AlertInstanceArray_WS alertInstanceArrayWS = response.get_return();

					// Deal with result status
					ResultStatus_WS resultStatus = alertInstanceArrayWS.getResultStatus();
					if (null == resultStatus)
					{
						logger.error("MP alert - closeAlertInstancesByPinVins resultStatus==null");
						StringBuilder message = new StringBuilder();
						message.append("TIAM SOAP web service closeAlertInstancesByPinVins resultStatus=null");
						throw new ApplicativeException(message.toString());
					}
					else if (-1 == resultStatus.getCode())
					{
						logger.error(
								"MP alert - closeAlertInstancesByPinVins resultStatus==-1" + resultStatus.getMessage());
						throw new ApplicativeException(resultStatus.getMessage());
					}
				}
				catch (IOException e)
				{
					logger.error("MP alert - TIAM SOAP web service closeAlertInstancesByPinVins exception");
					throw new ApplicativeException(e.getMessage());
				}
			}

			return alertsRules;
		}
		else
		{
			return null;
		}
	}

	/**
	 * Close MP alert for all coupons.
	 *
	 * @param userId interval history
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static void closeMPAlerts(String vin, String[] coupons, String userId)
			throws SystemException, ApplicativeException {
		TiamServicesStub tiamStub;

		if (null != coupons && coupons.length > 0)
		{
			try
			{
				// Call TIAM SOAP web service CloseMpAlerts
				CloseMpAlerts request = new CloseMpAlerts();
				request.setVin(vin);
				request.setCoupons(coupons);
				request.setApplicativeUserId(IceConstantes.TIAM_SOURCE);
				request.setApplicativePassword(IceConstantes.TIAM_SOURCE);
				request.setOriginatingSystem(IceConstantes.ETIM_SOURCE);
				request.setExternalUserId(userId);
				Properties properties = ApplicationProperties.getProperties();
				String tiamServiceStub = properties.getProperty("tiam.soap.url");
				/** Stub axis2. */
				tiamStub = new TiamServicesStub(tiamServiceStub);
				CloseMpAlertsResponse response = tiamStub.closeMpAlerts(request);
				TiamServicesStub.AlertInstanceArray_WS alertInstanceArrayWS = response.get_return();
				// Deal with result status
				ResultStatus_WS resultStatus = alertInstanceArrayWS.getResultStatus();
				if (null == resultStatus)
				{
					logger.error("MP alert - CloseMpAlerts resultStatus==null");
					StringBuilder message = new StringBuilder();
					message.append("TIAM SOAP web service CloseMpAlerts resultStatus=null");
					throw new ApplicativeException(message.toString());
				}
				else if (-1 == resultStatus.getCode())
				{
					logger.error(
							"MP alert - CloseMpAlerts resultStatus==-1" + resultStatus.getMessage());
					throw new ApplicativeException(resultStatus.getMessage());
				}
				AlertInstance_WS[] alerts = alertInstanceArrayWS.getAlertInstance_WSs();
				if (null != alerts && alerts.length > 0)
				{
					for (int i = 0; i < alerts.length; i++)
					{
						logger.debug(String.valueOf(alerts[i].getAlertId()));
					}
				}
				else
				{
					logger.debug("No MP alert closed for the vin " + vin);
				}
			}
			catch (RemoteException e)
			{
				logger.error("MP alert - TIAM SOAP web service CloseMpAlerts exception");
				throw new ApplicativeException(e.getMessage());
			}
		}
	}

	/**
	 * Fill the minimum next stop information for the smartview.
	 *
	 * @param jsonData Data retrieved from the next coupons WS.
	 * @param mpNextStopMin Dto to fill.
	 * @param inputFormat Date format.
	 * @throws ParseException ParseException
	 */
	private static void fillMinNextStop(JsonObject jsonData, MpNextStopMinDto mpNextStopMin, SimpleDateFormat inputFormat) throws ParseException {
		// Proposal Date
		JsonValue jsonValueProposalDate = jsonData.get(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_STOP_DATE);
		if (jsonValueProposalDate != null && !jsonValueProposalDate.toString().equals("null") && !jsonValueProposalDate.toString().equals(""))
		{
			mpNextStopMin.setMinProposalDate(MpType.MP_HOUR, inputFormat.parse(jsonData.getString(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_STOP_DATE)));
		}

		// Next stop value
		JsonValue jsonValueNextStop = jsonData.get(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_NEXT_STOP);
		if (jsonValueNextStop != null && !jsonValueNextStop.toString().equals("null") && !jsonValueNextStop.toString().equals(""))
		{
			mpNextStopMin.setNextValue(MpType.MP_HOUR, Long.valueOf(jsonData.getInt(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_NEXT_STOP)));
		}

		// Delta overdue
		JsonValue jsonValueOverdueHours = jsonData.get(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_DELTA_OVERDUE_HOURS);
		if (jsonValueOverdueHours != null && !jsonValueOverdueHours.toString().equals("null") && !jsonValueOverdueHours.toString().equals(""))
		{
			mpNextStopMin.setHoursInOverdue(Long.valueOf(jsonData.getInt(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_DELTA_OVERDUE_HOURS)));
		}

		// Delta overdue days
		JsonValue jsonValueOverdueDays = jsonData.get(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_DELTA_OVERDUE_DAYS);
		if (jsonValueOverdueDays != null && !jsonValueOverdueDays.toString().equals("null") && !jsonValueOverdueDays.toString().equals(""))
		{
			mpNextStopMin.setDaysInOverdue(Long.valueOf(jsonData.getInt(NextCouponsConstants.MP_NEXT_COUPON_VEHICLE_DELTA_OVERDUE_DAYS)));
		}
	}

	/**
	 * Get the MpNextStop list from UCR data
	 *
	 * @param userSession the user session
	 * @param jsonData json response from UCR web service
	 * @param mpdtoList mpdto list to fill
	 * @param mpNextStopMin the mp next stop min
	 * @throws SystemException ParseException
	 * @throws ParseException
	 * @throws ApplicativeException
	 */
	public static void getMpNextStopListFromUCR(JsonObject jsonData, List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, MpPlanDto mpPlanUcr, List<MpUsageDto> applicableMissionList)
			throws SystemException, ParseException {
		//TODO
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
		List<MpNextStopDto> mpdtoOverdueList = new ArrayList<>();
		List<MpNextStopDto> mpdtoAlertList = new ArrayList<>();
		List<MpNextStopDto> mpdtoComingSoonList = new ArrayList<>();
		List<MpNextStopDto> mpdtoComingNextList = new ArrayList<>();
		List<MpType> mpTypeList = new ArrayList<>();

		//MP INC5 : Only manage hour type  IAZ null management
		mpTypeList.add(MpType.MP_HOUR);

		// Set the plan id in the min Next stop
		long planId = Long.valueOf(jsonData.getInt(NextCouponsConstants.MP_NEXT_COUPON_PLAN_ID));
		mpNextStopMin.setIdPlan(planId);

		// Step 1 - Manage Next stop display
		fillMinNextStop(jsonData, mpNextStopMin, inputFormat);
		JsonObject missionData;
		JsonArray jsonArrayMissionList = jsonData.getJsonArray(MaintenanceService.APPLICABLE_MISSION_LIST);
		for (int i = 0; i < jsonArrayMissionList.size(); i++)
		{
			missionData = jsonArrayMissionList.getJsonObject(i);
			long missionPlanId = Long.valueOf(missionData.getInt("plan_id"));
			applicableMissionList.add(new MpUsageDto(missionData.getInt("id"), missionData.getString("description"), missionPlanId));
			if (mpPlanUcr != null && mpPlanUcr.getCondition() != null && mpPlanUcr.getCondition().getUsage() != null && planId == missionPlanId)
			{
				mpPlanUcr.getCondition().getUsage().setValueId(missionData.getInt("id"));
			}
		}

		// Step 2 - Manage Overdues, Alerts, Coming Soons, etc...
		JsonArray jsonCoupons = jsonData.getJsonArray(NextCouponsConstants.MP_NEXT_COUPON_COUPONS);

		// Get the interval list of the plan.
		List<MpIntervalDto> listInterval = new ArrayList<>();
		if (mpPlanUcr != null && mpPlanUcr.getId() != null)
		{
			listInterval = new MpIntervalBusiness().getMaintenanceIntervalsWithoutOperation(mpPlanUcr.getId(), Constants.ENGLISH, Context.getStringProperty("mp.family.code"));
		}

		for (int i = 0; i < jsonCoupons.size(); i++)
		{
			JsonObject jsonCoupon = jsonCoupons.getJsonObject(i);
			MpNextStopDto mpNextStopDto = new MpNextStopDto();

			JsonValue jsonValueMaintenanceType = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_MAINTENANCE_TYPE);

			if (jsonValueMaintenanceType != null && !jsonValueMaintenanceType.toString().equals("null") && !jsonValueMaintenanceType.toString().equals(""))
			{

				mpNextStopDto.setIntervalCode(jsonCoupon.getString(NextCouponsConstants.MP_NEXT_COUPON_MAINTENANCE_TYPE));
				mpNextStopDto.setIdPlan(mpNextStopMin.getIdPlan());

				Optional.ofNullable(jsonCoupon.get("is_hidden"))
						.map(JsonValue::toString)
						.map(Boolean::parseBoolean)
						.ifPresent(mpNextStopDto::setHidden);

				JsonValue jsonValueDescription = jsonCoupon.get("description");
				if (jsonValueDescription != null && !jsonValueDescription.toString().equals("null") && !jsonValueDescription.equals(""))
				{
					mpNextStopDto.setDescription(jsonCoupon.getString("description"));
				}
				else
				{
					mpNextStopDto.setDescription("");
				}

				JsonValue jsonValueNextMaintenance = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_NEXT_MAINTENANCE);

				if (jsonValueNextMaintenance != null && !jsonValueNextMaintenance.toString().equals("null") && !jsonValueNextMaintenance.toString().equals(""))
				{
					mpNextStopDto.setUcrNextMaintenance(MpNextStopDto.NextMaintenance.valueOf(jsonCoupon.getInt(NextCouponsConstants.MP_NEXT_COUPON_NEXT_MAINTENANCE)));
					boolean isPlanApplicable = false;
					for (MpIntervalDto mpIntervalDto : listInterval)
					{
						if (mpIntervalDto.getCode().equals(mpNextStopDto.getIntervalCode()) && !mpIntervalDto.isCustomer())
						{
							isPlanApplicable = true;
							break;
						}
					}
					if (isPlanApplicable && mpTypeList != null && !mpTypeList.isEmpty())
					{
						for (MpType mpType : mpTypeList)
						{
							Date couponDate = null;
							JsonValue jsonValue = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_DAY);
							if (mpNextStopDto.getUcrNextMaintenance() == MpNextStopDto.NextMaintenance.OVERDUE)
							{
								couponDate = Calendar.getInstance().getTime();
							}
							else if (jsonValue.toString() != null && !jsonValue.toString().equals("null") && !jsonValue.toString().equals(""))
							{
								String dateString = jsonCoupon.getString(NextCouponsConstants.MP_NEXT_COUPON_DAY);
								couponDate = inputFormat.parse(dateString);
							}
							mpNextStopDto.setProposalDate(mpType, couponDate);

							JsonValue jsonNextValue = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_NEXT_MAINTENANCE_STEP);
							if (jsonNextValue.toString() != null && !jsonNextValue.toString().equals("null"))
							{
								mpNextStopDto.setNextValue(mpType, Long.valueOf(jsonCoupon.getInt(NextCouponsConstants.MP_NEXT_COUPON_NEXT_MAINTENANCE_STEP)));
							}
							else
							{
								mpNextStopDto.setNextValue(mpType, null);
							}

							if (mpNextStopDto.getUcrNextMaintenance() != MpNextStopDto.NextMaintenance.ANTICIPATED)
							{
								JsonValue jsonIsNextStop = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_IS_COUPON_NEXT_STOP);

								if (jsonIsNextStop != null && !jsonIsNextStop.toString().equals("null") && !jsonIsNextStop.toString().equals(""))
								{
									mpNextStopDto.setNextStop(jsonCoupon.getBoolean(NextCouponsConstants.MP_NEXT_COUPON_IS_COUPON_NEXT_STOP));
								}

								if (mpNextStopDto.getUcrNextMaintenance() == MpNextStopDto.NextMaintenance.HIGH_OVERDUE)
								{
									// Manage Overdue data
									manageOverdueData(jsonCoupon, mpNextStopDto, mpType);

									// Add the coupon to the overdue list
									if (!mpdtoOverdueList.contains(mpNextStopDto))
									{
										mpdtoOverdueList.add(mpNextStopDto);
									}
								}
								else if (mpNextStopDto.getUcrNextMaintenance() == MpNextStopDto.NextMaintenance.OVERDUE)
								{
									// Manage Overdue data
									manageOverdueData(jsonCoupon, mpNextStopDto, mpType);

									// Add the coupon to the overdue list
									if (!mpdtoOverdueList.contains(mpNextStopDto))
									{
										mpdtoOverdueList.add(mpNextStopDto);
									}
								}
								else if (mpNextStopDto.getUcrNextMaintenance() == MpNextStopDto.NextMaintenance.ON_TIME)
								{
									// Manage COming soon data (for future purposes)
									manageComingSoonData(jsonCoupon, mpNextStopDto, mpType);

									// Add the coupon to the alert list
									if (!mpdtoAlertList.contains(mpNextStopDto))
									{
										mpdtoAlertList.add(mpNextStopDto);
									}
								}
								else if (mpNextStopDto.getUcrNextMaintenance() == MpNextStopDto.NextMaintenance.SUGGESTED)
								{
									// Manage COming soon data
									manageComingSoonData(jsonCoupon, mpNextStopDto, mpType);

									// Add the coupon to the coming soon list
									if (!mpdtoComingSoonList.contains(mpNextStopDto))
									{
										mpdtoComingSoonList.add(mpNextStopDto);
									}
								}
							}
						}
					}
				}
			}
		}

		mpdtoList.addAll(mpdtoOverdueList);
		mpdtoList.addAll(mpdtoAlertList);
		mpdtoList.addAll(mpdtoComingSoonList);
		mpdtoList.addAll(mpdtoComingNextList);
	}

	/**
	 * Manage all the data for Overdue coupons.
	 *
	 * @param jsonCoupon Json from UCR.
	 * @param mpNextStopDto Next stop object
	 * @param mpType type (hours)
	 */
	private static void manageOverdueData(JsonObject jsonCoupon, MpNextStopDto mpNextStopDto, MpType mpType) {

		// Check if the coupon is high overdue for hours
		JsonValue jsonValueIsHighOverdue = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_IS_HIGH_OVERDUE);
		if (jsonValueIsHighOverdue != null && !jsonValueIsHighOverdue.toString().equals("null"))
		{
			mpNextStopDto.setHighOverdue(jsonCoupon.getBoolean(NextCouponsConstants.MP_NEXT_COUPON_IS_HIGH_OVERDUE));
		}
		else
		{
			mpNextStopDto.setHighOverdue(false);
		}

		// Check if the coupon is high overdue for days
		JsonValue jsonValueIsHighOverdueDays = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_IS_HIGH_OVERDUE_DAYS);
		if (jsonValueIsHighOverdueDays != null && !jsonValueIsHighOverdueDays.toString().equals("null"))
		{
			mpNextStopDto.setHighOverdueDays(jsonCoupon.getBoolean(NextCouponsConstants.MP_NEXT_COUPON_IS_HIGH_OVERDUE_DAYS));
		}
		else
		{
			mpNextStopDto.setHighOverdueDays(false);
		}

		// Set High Overdue in hours
		if (mpNextStopDto.isHighOverdue())
		{
			// Set value of the overdue
			JsonValue jsonValueHours = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_HOURS_IN_OVERDUE);
			if (jsonValueHours != null && !jsonValueHours.toString().equals("null"))
			{
				mpNextStopDto.setOverdueValue(mpType, Long.valueOf(jsonValueHours.toString()));
			}
		}

		// Set High overdue in days
		if (mpNextStopDto.isHighOverdueDays())
		{
			// Set value of the overdue for days
			JsonValue jsonValueDays = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_DAYS_OVERDUE);
			if (jsonValueDays != null && !jsonValueDays.toString().equals("null"))
			{
				mpNextStopDto.setOverdueValue(MpType.MP_MONTH, Long.valueOf(jsonValueDays.toString()));
			}
		}

		// Set normal Overdue in hours and days
		if (!mpNextStopDto.isHighOverdue() && !mpNextStopDto.isHighOverdueDays())
		{
			// Set value of the overdue
			JsonValue jsonValueHours = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_HOURS_IN_OVERDUE);
			if (jsonValueHours != null && !jsonValueHours.toString().equals("null"))
			{
				mpNextStopDto.setOverdueValue(mpType, Long.valueOf(jsonValueHours.toString()));
			}

			// Set value of the overdue for days
			JsonValue jsonValueDays = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_DAYS_OVERDUE);
			if (jsonValueDays != null && !jsonValueDays.toString().equals("null"))
			{
				mpNextStopDto.setOverdueValue(MpType.MP_MONTH, Long.valueOf(jsonValueDays.toString()));
			}
		}
	}

	/**
	 * Manage all the data for Coming soon and alert coupons.
	 *
	 * @param jsonCoupon Json from UCR.
	 * @param mpNextStopDto Next stop object
	 * @param mpType type (hours)
	 */
	private static void manageComingSoonData(JsonObject jsonCoupon, MpNextStopDto mpNextStopDto, MpType mpType) {
		// Set value of the forecast for hours
		JsonValue jsonValueHours = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_FORECAST_IN_HOURS);
		if (jsonValueHours != null && !jsonValueHours.toString().equals("null"))
		{
			mpNextStopDto.setForecastValue(mpType, jsonCoupon.getJsonNumber(NextCouponsConstants.MP_NEXT_COUPON_FORECAST_IN_HOURS).longValue());
		}

		// Check if the coupon is in coming soon for hours
		JsonValue jsonValueIsHighOverdue = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_IS_FORECAST_IN_TOLERANCE_HOURS);
		if (jsonValueIsHighOverdue != null && !jsonValueIsHighOverdue.toString().equals("null"))
		{
			mpNextStopDto.setComingSoonHours(jsonCoupon.getBoolean(NextCouponsConstants.MP_NEXT_COUPON_IS_FORECAST_IN_TOLERANCE_HOURS));
		}
		else
		{
			mpNextStopDto.setComingSoonHours(false);
		}

		// Set value of the forecast for days
		JsonValue jsonValueDays = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_FORECAST_IN_DAYS);
		if (jsonValueDays != null && !jsonValueDays.toString().equals("null"))
		{
			mpNextStopDto.setForecastValue(MpType.MP_MONTH, Long.valueOf(jsonValueDays.toString()));
		}

		// Check if the coupon is in coming soon for days
		JsonValue jsonValueIsHighOverdueDays = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_IS_FORECAST_IN_TOLERANCE_MONTHS);
		if (jsonValueIsHighOverdueDays != null && !jsonValueIsHighOverdueDays.toString().equals("null"))
		{
			mpNextStopDto.setComingSoonDays(jsonCoupon.getBoolean(NextCouponsConstants.MP_NEXT_COUPON_IS_FORECAST_IN_TOLERANCE_MONTHS));
		}
		else
		{
			mpNextStopDto.setComingSoonDays(false);
		}
	}

	/**
	 * Save the performed maintenance in history.
	 *
	 * @param myVehicleContextDto the request
	 * @param failureDate format : yyyy-MM-dd
	 * @param repairDate format : number of milisecond (last clocking date) = nowDate
	 * @param customer IVECO or not
	 * @param userId the user Id
	 * @param dealerCode the dealer Code
	 * @param dealerName the dealer Name
	 * @param fullIntervalList : full list of interval
	 * @param selectedIntervalList list of interval selected (in order to save in histo)
	 * @param intervalOperationList list of interval selected (with status with status O,A,... + delta) + operation + part + consumable => for claim
	 * @param recommended interval list of interval proposed but not selected (A) + delta (operation are empty) => for claim
	 * @param kitCodeByPartNumber for each part, the kit it belongs to => for claim
	 * @param isExternalUser : Checking if its external or internal user connected to the application
	 * @param isOptimized : for isOptimized plans
	 * @return result JSON
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public static boolean saveMaintenance(MyVehicleContextDto myVehicleContextDto, String failureDate, String repairDate, String customer, String userId, String dealerCode, String dealerName,
			String softwareVersion,
			List<MpIntervalDto> fullIntervalList, List<MpIntervalDto> listIntervals, List<MpIntervalOperationDto> listIntervalsOperationSelected,
			List<MpIntervalOperationDto> listIntervalsOperationRecommended, Map<String, String> kitCodeByPartNumber, boolean isDealer, boolean isExternalUser, boolean isOptimized)
			throws ApplicativeException, SystemException {
		boolean isOk = false;
		boolean isIveco = ("IVECO").equals(customer);
		if (failureDate != null && !failureDate.isEmpty() && repairDate != null && !repairDate.isEmpty())
		{
			// mpDto ( should contain : actual mileage, actual hour, warranty start date,
			// mpDto.getListIntervals() (only interval selected) (with selection of part/cons + interval with overdue, delta)
			// mpDto.getPlanExternalId(),mpDto.getPlanId(),mpDto.getSelectedPLan() //get the plan for claim
			MaintenancePlanDto mpDto = myVehicleContextDto.getMpInteractive() != null ? 
					myVehicleContextDto.getMpInteractive(): new MaintenancePlanDto();
			
			if (mpDto.getActualHour() == null || mpDto.getActualHour().isEmpty())
			{
				mpDto.setActualHour("0");
			}
			if (mpDto.getActualMileage() == null || mpDto.getActualMileage().isEmpty())
			{
				mpDto.setActualMileage("0");
			}
			if (mpDto.getWarranty() != null)
			{
				mpDto.setWarrantyDate(mpDto.getWarranty().getWarrantyDate());
			}

			// myVehicleContextDto : myVehicleContextDto (vin, icecontextdto ((series+model name, ice code), productconfiguration, contract)
			//contract info store in the snapshot
			MpContractDto contract = myVehicleContextDto.getMpContract();

			// flexibleCoupons : list of flexible coupons
			Map<String, MpFlexCouponDto> flexibleCoupons = MaintenanceUtil.initFlexibleCoupon();

			//Set the list of interval selected using JOB CARD selection
			mpDto.setListIntervals(listIntervals);

			//mpDto.getMpIntervalOperations() (with selection of part/cons + interval with overdue, delta) :
			mpDto.setMpIntervalOperations(listIntervalsOperationSelected);

			//Set the list of interval not recommended using JOB CARD snapshot
			mpDto.setMpIntervalOperationsRecommended(listIntervalsOperationRecommended);

			//Retrieve the history
			List<MpHistoryIntervalDto> listHistory = getMpHistoryFromDB(Arrays.asList(myVehicleContextDto.getPinVin()), contract, flexibleCoupons, mpDto.getPlanExternalId());
			mpDto.setListHistory(listHistory);

			//#########################################################################################################################################################
			//								MANAGE CURRENT VEHICLE DATA HERE FOR AG AND CV
			//#########################################################################################################################################################

			// @param kitCodeByPartNumber : to be checked
			//TODO IAZ - Get the information of connectivity
			boolean ucrManageMp = isIveco ? false : myVehicleContextDto.getCurrentVehicleData().isUcrManageMP();

			CurrentVehicleDataDto currentVehicleData = myVehicleContextDto.getCurrentVehicleData();
			// lstPinVin : lstPinVin // TODO inaki get list of PIN VIN (only for AG)
			List<String> lstPinVin = new ArrayList<>();
			lstPinVin.add(myVehicleContextDto.getPinVin());
			//Recalculate for CV to get the current km/average for the calculation of proposal date(should call the ws)
			if (isIveco)
			{
				currentVehicleData = MaintenanceEdsUtil.getCurrentVehicleDataFromEDS(myVehicleContextDto.getPinVin());
			}

			// azurePath : azurePath (empty for DJC)
			String claimPdfUrl = ""; //TODO IAZ : check if PDF empty no possibility to see it and if xml dms empty either
			String partAttachmentUrl = "";
			String serviceAttachmentUrl = "";

			//locale use only to set the interval comment (overdue, ....) not useful
			Locale locale = new Locale("EN");
			IceContextDto iceContextDto = myVehicleContextDto.getContextDto();

			//additional info for claim
			boolean generateDms = true;
			if (iceContextDto.getSeries() != null && iceContextDto.getProduct() != null && iceContextDto.getType() != null && iceContextDto.getBrand() != null)
			{
				SeriesDto seriesDto = new ProductBusiness().getSeriesByIceCode(iceContextDto.getSeries().getIceCode(),
						iceContextDto.getProduct().getIceCode(),
						iceContextDto.getType().getIceCode(),
						iceContextDto.getBrand().getIceCode());
				if (seriesDto != null)
				{
					mpDto.setSeries(seriesDto.getAName());
				}
			}

			boolean isMpLockEnabled = false;
			String saveComment = "";

			isOk = saveMaintenance(lstPinVin, myVehicleContextDto, contract, mpDto, fullIntervalList,
					flexibleCoupons, repairDate, failureDate, kitCodeByPartNumber, claimPdfUrl, ucrManageMp, locale, isMpLockEnabled,
					currentVehicleData, myVehicleContextDto.getContextDto(), customer, userId, dealerCode, dealerName, softwareVersion,
					generateDms, isDealer, isExternalUser, saveComment, partAttachmentUrl, serviceAttachmentUrl, isOptimized, null);
		}

		return isOk;
	}

	/**
	 * Retrieve the current history depending if contract or not.
	 *
	 * @param vin the vin
	 * @param contract the contract
	 * @param flexibleCoupons : flexibleCoupons
	 * @param planExtId : planExtId
	 * @return return the history
	 * @throws SystemException a system exception
	 */
	public static List<MpHistoryIntervalDto> getMpHistoryFromDB(List<String> lstPinVin, MpContractDto contract, Map<String, MpFlexCouponDto> flexibleCoupons, Long planExtId) throws SystemException {
		List<MpHistoryIntervalDto> listHistory = null;
		boolean isFlexHeavy = false;
		if (contract != null)
		{
			long fistContractTime = 0;
			if (!contract.getContracts().isEmpty())
			{
				fistContractTime = contract.getContracts().get(contract.getContracts().size() - 1).getContractStartDate().getTime();
			}
			if (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract()))
			{
				isFlexHeavy = true;
			}
			// get the last eTIM or the last sap
			// if eTIM is get we cannot save history and set message to user
			int toleranceToMatch = Integer.valueOf(Context.getStringProperty("mp.tolerance.tomatch"));
			int toleranceToWait = Integer.valueOf(Context.getStringProperty("mp.tolerance.towait"));
			listHistory = new MpIntervalBusiness().readListHistoryIntervalWithContract(lstPinVin, toleranceToMatch, toleranceToWait, fistContractTime, flexibleCoupons, isFlexHeavy);
		}
		else if (!lstPinVin.isEmpty())
		{
			listHistory = MpIntervalBusiness.readListHistoryInterval(lstPinVin, null, planExtId);
		}
		else
		{
			listHistory = new ArrayList<>();
		}
		return listHistory;
	}

	/**
	 * Save the performed maintenance in history.
	 *
	 * @param lstPinVin : list the pin vin (9/17 digits)
	 * @param myVehicleContextDto : used for getting the VIN, iceContext for draft claim,
	 * @param contract : the active contract
	 * @param mpDto ( should contain : actual mileage (mileage for saving), actual hour (hour for saving), warranty start date,
	 *            mpDto.getListIntervals() (only interval selected)
	 *            mpDto.getListHistory() (history in DB or in session), mpDto.getPlanExternalId(),mpDto.getPlanId(),
	 *            mpDto.getMpIntervalOperations() (with selection of part/cons + interval with overdue, delta)
	 *            mpDto.getMpIntervalOperations() (with selection of part/cons + interval with overdue, delta)
	 * @param fullIntervalList : full interval list from the plan
	 * @param flexibleCoupons : list of flexible coupons
	 * @param nowDate : date of the repair
	 * @param dataParamStr : failure date (format : yyyy-MM-dd)
	 * @param kitCodeByPartNumber : to be checked
	 * @param claimPdfPath : azurePath (empty for DJC)
	 * @param jumpFromAlertUcr : jumpFromAlertUcr
	 * @param locale : locale (only for the display of the comment: overdue,... to be done in the front later)
	 * @param isMpLockEnabled : isMpLockEnabled : (false from DJC, info stored in DB)
	 * @param currentVehicleData : use to calculate a proposal date for CV
	 * @param context : ice context dto => only for AG&CE to get the extra unit (example bales and initialize tolerance)
	 * @param customer : IVECO or not
	 * @param userId : user id
	 * @param dealerCode : dealerCode
	 * @param dealerName : dealerName
	 * @param generateDms : generateDms true/false
	 * @param saveComments
	 * @param isExternalUser : this is to check if its an external or internal user that is connected to the application
	 * @param partAttachmentPath : this is the pdf part attachment url to be saved in the db
	 * @param serviceAttachmentPath : this is the pdf service attachment url to be saved in the db
	 * @param isOptimized : this is for optimized plans
	 * @param certifiedParts
	 * @return true if the save is ok
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */

	public static boolean saveMaintenance(List<String> lstPinVin, MyVehicleContextDto myVehicleContextDto, MpContractDto contract, MaintenancePlanDto mpDto, List<MpIntervalDto> fullIntervalList,
			Map<String, MpFlexCouponDto> flexibleCoupons, String nowDate, String dataParamStr, Map<String, String> kitCodeByPartNumber, String claimPdfPath, boolean ucrManageMp, Locale locale,
			boolean isMpLockEnabled, CurrentVehicleDataDto currentVehicleData, IceContextDto context, String customer, String userId, String dealerCode, String dealerName, String softwareVersion,
			boolean generateDms, boolean isDealer, boolean isExternalUser, String saveComments, String partAttachmentPath, String serviceAttachmentPath, boolean isOptimized, Integer certifiedParts)
			throws ApplicativeException, SystemException {

		boolean proceed = false;
		boolean saveIsOk = false;
		String contractNb = "";
		boolean isIvecoCustomer = ("IVECO").equals(customer);
		List<MpNextStopDto> nextStops = new ArrayList<>();

		List<MpHistoryIntervalDto> historyList = new ArrayList<>();

		ContractVisibility contractVisibility = new ContractVisibility(contract);
		if (contract != null && contract.getActiveMpContract() != null && (ConnectedTypeEnum.LIGHT_TARGA_CONNECTED.getValue().equals(contract.getActiveMpContract().getConnectedType())
				|| ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract())))
		{
			contractNb = contract.getActiveMpContract().getContractNumber();
		}

		String vin = myVehicleContextDto.getPinVin();
		MpLockBusiness mpLockBusiness = new MpLockBusiness();
		MpNextStopMinDto oldMinNextStop = null;

		// Map used to store the operations selected by the dealer --> Store in DB + send to UCR
		Map<String, JsonArrayBuilder> couponOperationJsonForUCR = new HashMap<>();
		try
		{
			// Lock MP
			if (mpLockBusiness.addMpLock(vin, isMpLockEnabled))
			{
				proceed = true;

				/** Create transaction. */
				TransactionAccess transaction;
				transaction = new TransactionAccess();
				try
				{
					/** Begin transaction. */
					transaction.beginTransaction();

					/************ Initialize business with current transaction. **********/
					MpNextStopBusiness nextStopBusiness = new MpNextStopBusiness(transaction);
					MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness(transaction);

					// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
					MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(mpDto, nowDate, locale, customer, transaction, context);
					mpBusiness.setFlexibleCoupons(flexibleCoupons);

					Date failureDate = null;

					/************ retrieve the list of interval to save in db (calculate int value). **********/
					//interval list : result
					historyList = mpBusiness.getIntervalHistory(vin, mpDto.getListIntervals(), nowDate, mpDto.getListHistory(), mpDto.getPlanExternalId(), contractVisibility.hasComponentFlexible());

					/************ Generate the operation JSON for UCR. **********/
					for (MpHistoryIntervalDto history : historyList)
					{
						// create the Operations JSON here
						JsonArrayBuilder operationJson = createOperationJsonForUCR(
								mpDto.getMpIntervalOperations().stream().filter(coupon -> coupon.getCode().equals(history.getIntervalCode())).findFirst().get());

						couponOperationJsonForUCR.put(history.getIntervalCode(), operationJson);
					}

					/************ Save flexible coupon in the table coupon done to export to EDS + delete external alert. **********/
					if (contractVisibility.hasComponentFlexible())
					{
						for (MpHistoryIntervalDto history : historyList)
						{
							// Save coupon flexible in MP_NEXT_STOP_DONE_WK if vehicle has flexible contract
							//delete external alert
							nextStopBusiness.addFlexStopDone(history, flexibleCoupons, Long.valueOf(nowDate));
							nextStopBusiness.deleteFlexExternalAlert(history, flexibleCoupons);
						}
					}
					/************ Calculate next stop **********/
					List<MpNextStopDto> listNextFlexCoupon = new ArrayList<>();
					if (contractVisibility.hasComponentFlexible())
					{
						listNextFlexCoupon = nextStopBusiness.getAllNextStopFlexibles(vin);
					}
					// Recalculate next stop flexible if done
					// For flexible and targa contracts
					MpNextStopMinDto minNextStop = null;
					if (contractVisibility.hasProposalDateAndAlert())
					{
						// listNextFlexCoupon is updated with coupon recalculated
						if (contractVisibility.hasComponentFlexible())
						{
							// Only for flexible contracts
							mpBusiness.calculateNextFlexibleStop(historyList, listNextFlexCoupon, mpDto.getListHistory(), fullIntervalList, vin);
						}

						minNextStop = new MpNextStopMinDto(vin, Long.valueOf(mpDto.getPlanId()), contractNb);
						minNextStop.setCurrentMileage(Long.valueOf(mpDto.getActualMileage()));
						minNextStop.setCurrentHour(Long.valueOf(mpDto.getActualHour()));
						minNextStop.setMpCallStatus(MpCallStatus.NOT_CALLED);
					}

					// first need to fusion the new history (for coupon saved) + history for coupon
					// not saved

					List<MpHistoryIntervalDto> mergedHistoryList = mpBusiness.mergedHistoryList(historyList, mpDto.getListHistory());
					mpBusiness.setFlexibleCoupons(flexibleCoupons);

					nextStops = mpBusiness.calculateNextStop(fullIntervalList,
							mergedHistoryList, listNextFlexCoupon, vin,
							Long.valueOf(mpDto.getPlanId()), contractVisibility, Long.valueOf(mpDto.getWarrantyDate()),
							Long.valueOf(mpDto.getActualMileage()), Long.valueOf(mpDto.getActualHour()));
					//keep old to get the alert id to close the appointment
					oldMinNextStop = new MpNextStopBusiness().getMpNextStopMin(Arrays.asList(mpDto.getWarranty().getVin()));
					nextStopBusiness.addNextStop(nextStops, listNextFlexCoupon, contractVisibility, currentVehicleData, Long.valueOf(mpDto.getWarrantyDate()), minNextStop, null,
							mpBusiness, lstPinVin);

					/************ get failure date **********/
					long timestampFailure = 0;
					if (dataParamStr != null)
					{
						//[SSE] INC6996826 : IVECO LITHUANIA - ETIM - MAINTENANCE INQUIRY
						failureDate = new SimpleDateFormat(DATE_FORMAT_yyyy_MM_dd).parse(dataParamStr);
						//TODO IAZ Set failure date in milliseconds
						Calendar timeFailure = Calendar.getInstance();
						timeFailure.setTime(failureDate);
						timestampFailure = failureDate.getTime() + timeFailure.getTimeZone().getOffset(timeFailure.getTime().getTime());

					}
					/************ save XML + save PDF path for both Claim , PART, and Service if exists + save in MP_HISTORY **********/

					String maxId = saveXml(transaction, failureDate, Long.valueOf(nowDate), kitCodeByPartNumber, claimPdfPath, partAttachmentPath, serviceAttachmentPath, isIvecoCustomer,
							userId, softwareVersion, mpDto, myVehicleContextDto, contract, generateDms, currentVehicleData != null ? currentVehicleData.isUcrManageMP() : false, historyList,
							isOptimized, certifiedParts);

					for (MpHistoryIntervalDto history : historyList)
					{

						// Update the field MPH_CLAIM_ID of the MP_HISTORY_INTERVAL table with the id of the claim inserted in the MP_CAIM table
						history.setIdClaim(maxId);
						history.setFailureDate(timestampFailure);
						history.setOperationJsonForUcr(couponOperationJsonForUCR.get(history.getIntervalCode()).build().toString());

						// set CUSTOMER or DEALER for mp history interval
						int operatorType = isDealer ? MpIntervalHistoryEnum.DEALER.getValue() : MpIntervalHistoryEnum.CUSTOMER.getValue();
						history.setOperatorType(operatorType);

						// Update the Origin of the interval if a jump form a UCR alert has been performed
						if (ucrManageMp)
						{
							history.setIsSapOrigin(MpHistoryOrigin.UCR.getValue());
						}
						history.setSaveComments(saveComments);
						// Save HistoryInterval
						mpIntervalBusiness.createHistoryInterval(history);
					}

					/** Commit transaction. */
					transaction.commitTransaction();
					saveIsOk = true;
				}

				catch (NumberFormatException | JsonException | SystemException | ApplicativeException | ParseException e)
				{
					// RollBack transaction
					transaction.rollbackTransaction();
					throw new ApplicativeException(e);
				}
				finally
				{
					transaction.endTransaction();
					// unlock MP
					if (proceed)
					{
						mpLockBusiness.removeMpLock(vin, isMpLockEnabled);
					}
				}
			}
		}
		catch (SystemException e1)
		{
			// unlock MP
			if (proceed)
			{
				mpLockBusiness.removeMpLock(vin, isMpLockEnabled);
			}
			throw new ApplicativeException(e1);
		}

		try
		{
			// Close alert
			if (contractVisibility.hasProposalDateAndAlert() && proceed)
			{
				if (null != oldMinNextStop && isIvecoCustomer)
				{
					// close appointment linked to the urgent alerts
					(new MpAppointmentBusiness()).closeAppointment(oldMinNextStop.getAlertGroupId());
				}
				//MML TODO REVIEW THE VIN 9 or 17
				MaintenanceService.closeMPAlerts(isIvecoCustomer, userId, lstPinVin, historyList);
			}
			if (contractVisibility.hasProposalDateAndAlert())
			{
				//MML - Re-call the creation of alert if needed (if not all coupons in alert are not closed) : it will update the previous alert id in MP_NEXT_STOP_MIN if needed
				MpContractVehicleDto mpContractVehicleDto = new MpFlexMaintenanceBusiness().getMpActiveFlexContract(vin);
				if (IceConstantes.PROFILE_IVECO.equals(customer) && mpContractVehicleDto != null)
				{
					// not recalling ws because it has been current mileage has been updated in content action and set in session
					MaintenanceAlertService service = new MaintenanceAlertService(userId, contract, mpContractVehicleDto, currentVehicleData,
							nextStops, customer, flexibleCoupons, context);
					service.run();
				}
			}
			// MML TODO Recalculate possible alert
		}
		catch (SystemException | ApplicativeException e)
		{
			logger.error("ERROR MP ALERT FAILED", e);
		}

		// FEEDBACK FOR UCR - Call UCR WebService
		if (!isIvecoCustomer)
		{
			String projectNumber = null;
			Integer projectVersion = null;
			JsonObjectBuilder body = Json.createObjectBuilder();
			Long planExtId = mpDto.getPlanExternalId();
			String planId = mpDto.getPlanId();
			Optional<MpPlanDto> optMpPlan = mpDto.getMpPlanList().stream()
					.filter(x -> (planExtId != null && planExtId.equals(x.getExtId()))
							|| (planId != null && planId.equals(x.getId().toString())))
					.findFirst();
			if (optMpPlan.isPresent())
			{
				MpPlanDto mpPlan = optMpPlan.get();
				projectNumber = mpPlan.getProjectNumber();
				projectVersion = mpPlan.getProjectVersion();
			}

			Double engineHours = Double.parseDouble(mpDto.getActualHour());
			Long warrantyDate = mpDto.getWarrantyDate() != null ? new Long(mpDto.getWarrantyDate()) : 0L;

			// Set the plan id and current Engine Hours from UCR if received.
			//TODO MML check with inaki if necessary + check if mpdto.getActualHour is ok
			/*	if (Boolean.parseBoolean(jumpFromAlertUcr))
				{
					engineHours = Double.valueOf(currentVehicleData.getCurrentHours());
				}*/

			logger.warn("#############    FEEDBACK FOR UCR - Dealer code   #############\nDealer Code: " + dealerCode);

			//MML TODO REVIEW THE VIN 9 or 17
			if (dealerCode == null || dealerCode.isEmpty())
			{
				dealerCode = userId;
			}
			// maintenance activity is saved by an internal user
			if (!isExternalUser)
			{
				dealerCode = "";
				dealerName = "";
			}
			body = new MaintenanceUcrUtil().prepareJsonOpenApiFeedback(new ArrayList<>(), historyList, vin, planExtId, dealerCode, dealerName, userId, engineHours, warrantyDate, isDealer,
					couponOperationJsonForUCR, saveComments, partAttachmentPath, serviceAttachmentPath, projectNumber, projectVersion, certifiedParts);

			OpenApiParameters args = new OpenApiParameters(vin, OpenApiWebServiceEnum.FEEDBACK, userId, body.build().toString());

			logger.warn("#############    FEEDBACK FOR UCR - Call UCR WebService JSON    #############\n" + body.build().toString());

			OpenApiWebService.call(args);

		}

		return saveIsOk;
	}

	private static JsonArrayBuilder createOperationJsonForUCR(MpIntervalOperationDto coupon) {
		JsonArrayBuilder operationArray = Json.createArrayBuilder();

		coupon.getOperations().parallelStream().forEach(operation -> {
			JsonObjectBuilder operationJson = Json.createObjectBuilder();

			operationJson.add("code", operation.getMicroOperation() != null ? operation.getMicroOperation() : operation.getSrtOperation());
			operationJson.add("description", operation.getOperationLabel() != null ? operation.getOperationLabel() : "");
			operationJson.add("descriptionSeries", operation.getOperationLabelForSeries() != null ? operation.getOperationLabelForSeries() : "");
			operationJson.add("location", operation.getIceCode() != null ? operation.getIceCode().substring(0, 2) : "");
			operationJson.add("selected", operation.isSelected());

			JsonArrayBuilder partArray = Json.createArrayBuilder();
			operation.getParts().stream().forEach(part -> {

				if (part.getReplacedByList() == null || part.getReplacedByList().isEmpty())
				{
					JsonObjectBuilder partJson = Json.createObjectBuilder();

					partJson.add("partNumber", part.getCodePart());
					partJson.add("description", part.getPartLabel() != null ? part.getPartLabel() : "");
					partJson.add("secondDescripion", part.getNote() != null ? part.getNote() : "");
					partJson.add("quantity", part.getQuantity());
					partJson.add("selected", part.isSelected());
					partJson.add("original", part.isOriginal());
					partJson.add("manuallyAdded", part.isNewPart());
					partJson.add("isKit", part.isInKit());
					if (part.getPartGroup() != null)
					{
						partJson.add("group", part.getPartGroup());
					}
					else
					{
						partJson.addNull("group");
					}
					partJson.add("isSupersession", part.isAReplacement());

					partArray.add(partJson);
				}
				else
				{
					part.getReplacedByList().stream().forEach(partSupersession -> {
						JsonObjectBuilder partJson = Json.createObjectBuilder();

						partJson.add("partNumber", partSupersession.getCodePart());
						partJson.add("description", partSupersession.getPartLabel() != null ? part.getPartLabel() : "");
						partJson.add("secondDescripion", part.getNote() != null ? part.getNote() : "");
						partJson.add("quantity", partSupersession.getQuantity());
						partJson.add("selected", part.isSelected());
						partJson.add("original", part.isOriginal());
						partJson.add("manuallyAdded", part.isNewPart());
						partJson.add("isKit", part.isInKit());
						if (part.getPartGroup() != null)
						{
							partJson.add("group", part.getPartGroup());
						}
						else
						{
							partJson.addNull("group");
						}
						partJson.add("isSupersession", true);

						partArray.add(partJson);
					});
				}

			});
			operationJson.add("parts", partArray);

			JsonArrayBuilder consArray = Json.createArrayBuilder();
			operation.getConsumables().stream().forEach(consumable -> {
				JsonObjectBuilder consumableJson = Json.createObjectBuilder();

				consumableJson.add("consId", consumable.getIdConsumable());
				consumableJson.add("occurrenceId", consumable.getOccurrenceId() != null ? consumable.getOccurrenceId() : 0L);
				consumableJson.add("description", consumable.getConsumable());
				consumableJson.add("partNumber", consumable.getPartnumber() != null ? consumable.getPartnumber() : "");
				consumableJson.add("quantity", consumable.getUnitLiter() != null ? consumable.getQtyLiter() : consumable.getQty());
				consumableJson.add("unit", consumable.getUnitLiter() != null && consumable.getUnit() != null ? consumable.getUnitLiter() : consumable.getUnit());
				consumableJson.add("quantityUk", consumable.getUnitLiter() != null ? consumable.getQty() : consumable.getQtyLiter());
				consumableJson.add("unitUk", consumable.getUnitLiter() != null && consumable.getUnit() != null ? consumable.getUnit() : "");
				consumableJson.add("selected", consumable.isSelected());

				consArray.add(consumableJson);
			});
			operationJson.add("consumables", consArray);

			operationArray.add(operationJson);
		});

		return operationArray;
	}

	/**
	 * Execute SaveXml action.
	 *
	 * @param transaction transaction or null if no in a transaction
	 * @param heavyFlexContract if contract flex
	 * @param failureDate failure Date
	 * @param repairDate date of the repair
	 * @param kitCodeByPartNumber kit part number
	 * @param azureUrl the azure URL
	 * @param isIveco if iveco customer
	 * @param userID the user ID
	 * @param softwareVersion the software application
	 * @param mpDto the mpdto
	 * @param myVehicleContextDto the vehicle dto
	 * @param partAttachmentPath : this is the pdf part attachment url to be saved in the db
	 * @param serviceAttachmentUrl : this is the pdf service attachment url to be saved in the db
	 * @param isOptimized : this is for the isOptimized plan
	 * @param certifiedParts
	 * @return the claim id
	 *
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */

	private static String saveXml(
			TransactionAccess transaction, Date failureDate, Long repairDate,
			Map<String, String> kitCodeByPartNumber, String claimPdfPath, String partAttachmentPath, String serviceAttachmentPath, boolean isIveco,
			String userID, String softwareVersion, MaintenancePlanDto mpDto, MyVehicleContextDto myVehicleContextDto,
			MpContractDto contractDto, boolean generateDms, boolean isConnected, List<MpHistoryIntervalDto> historyList, boolean isOptimized, Integer certifiedParts)
			throws SystemException, ApplicativeException {

		MpClaimDto dto = new MpClaimDto();
		MpClaimBusiness claimBusiness = new MpClaimBusiness(transaction);

		// Generate content of XML file
		MPExportXMLDto mpExportXmlDto = new MPExportXMLDto(mpDto, myVehicleContextDto, MPExportXMLBusiness.CLAIM, softwareVersion, userID);
		MPExportXMLBusiness mpExportXmlBusiness = new MPExportXMLBusiness();
		mpExportXmlDto.setFailureDate(failureDate);

		// For AG&CE, Original SAP XML (old), for backup
		CompletableFuture<List<String>> futureXmlSapStringList = CompletableFuture
				.supplyAsync(() -> {

					String originalXmlSapString = null;
					String xmlSapString = null;
					List<String> res = Arrays.asList(new String[2]);

					try
					{
						// For AG&CE, Original SAP XML (old), for backup
						if (!isIveco)
						{
							originalXmlSapString = mpExportXmlBusiness.generateSAPXML(mpExportXmlDto, kitCodeByPartNumber, isIveco, true, isConnected, historyList, isOptimized);
						}
						// New SAP XML, formatted
						xmlSapString = mpExportXmlBusiness.generateSAPXML(mpExportXmlDto, kitCodeByPartNumber, isIveco, false, isConnected, historyList, isOptimized);
						res.set(0, originalXmlSapString);
						res.set(1, xmlSapString);
					}
					catch (SystemException | ApplicativeException e)
					{
						logger.error(e);
					}

					return res;
				});

		CompletableFuture<String> futureXmlDmsString = CompletableFuture
				.supplyAsync(() -> {
					org.jdom.Document temp = null;
					String res = null;

					if (generateDms)
					{
						try
						{
							//TODO inaki : not use a file
							temp = mpExportXmlBusiness.generateDMSXML(mpExportXmlDto, kitCodeByPartNumber, isIveco);
							DOMOutputter outputter = new DOMOutputter();
							res = documentToString(outputter.output(temp));
						}
						catch (SystemException | ApplicativeException | JDOMException e)
						{
							logger.error(e);
						}
					}
					return res;
				});

		CompletableFuture.allOf(futureXmlSapStringList, futureXmlDmsString).join();

		String originalXmlSapString = futureXmlSapStringList.join().get(0);
		String xmlSapString = futureXmlSapStringList.join().get(1);
		String xmlDmsString = futureXmlDmsString.join();

		dto.setVinCode(mpExportXmlDto.getVin());

		//Contract is valid if there is a contract number
		// and if failure date is between older start date and end date
		dto.setHasContract(new MpPlanBusiness().hasContractValid(contractDto, failureDate));
		dto.setHour(Long.parseLong(mpExportXmlDto.getActualHour()));
		dto.setKm(Long.parseLong(mpExportXmlDto.getActualMileage()));
		dto.setFilterXML(xmlDmsString);
		dto.setFilterOriginalSAPXML(originalXmlSapString);
		dto.setFilterSAPXML(xmlSapString);

		if (!claimPdfPath.isEmpty())
		{
			dto.setPdfPath(claimPdfPath);
		}
		dto.setPdfParts(partAttachmentPath);
		dto.setPdfService(serviceAttachmentPath);
		dto.setCertifiedParts(certifiedParts);

		//[SSE] INC6996826 : IVECO LITHUANIA - ETIM - MAINTENANCE INQUIRY
		dto.setFailureDate(UtilDate.dateToString(failureDate, DATE_FORMAT_yyyy_MM_dd));

		dto.setCreationDate(UtilDate.dateToString(new Date(repairDate), DATE_FORMAT_yyyy_MM_dd_HH_mm_ss));
		claimBusiness.addClaim(dto);
		return claimBusiness.getMaxClaimId();
	}

	/**
	 * Converts a XML DOM tree to a XML string.
	 *
	 * @param aXML Document to convert
	 * @return the xml formatted into a string
	 */
	private static String documentToString(org.w3c.dom.Document aXML) {
		DOMSource domSource = new DOMSource(aXML);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		Transformer transformer;
		try
		{
			transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(domSource, sr);
		}
		catch (TransformerFactoryConfigurationError | TransformerException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sw.toString();
	}

	/**
	 * Display in eTIM the type of contract to the dealer in order he understands if a claim can be done and if digital claim
	 *
	 * @see MpPlanBusiness#getAllMpContracts(String)
	 *
	 * @param vin
	 * @return the message to display
	 * @throws ApplicativeException
	 * @throws SystemException
	 */
	public static MpContractTypeMessageDto getTypeOfContractMessage(List<String> lstPinVin, ResponseData sapVehicleInformation, String customer)
			throws ApplicativeException, SystemException {

		MpContractTypeMessageDto mpContractTypeMessageDto = new MpContractTypeMessageDto();

		MpPlanBusiness mpPlanBusiness = new MpPlanBusiness();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdfWarranty = new SimpleDateFormat("yyyy-MM-dd");

		String[] warrantyTypes = customer.equals(Constants.CUSTOMER_CNH) ? Constants.WARRANTY_TYPES_CNH : Constants.WARRANTY_TYPES_IVECO;

		// On ne prend pas le mpContractDto de la session car in contient des contrats avec la tolerance +2 mois
		MpContractDto mpContractDto = mpPlanBusiness.getAllMpContracts(lstPinVin, false, customer.equals(Constants.CUSTOMER_IVECO));
		if (mpContractDto != null && mpContractDto.getActiveMpContract() != null)
		{
			// There is INTERACTIVE contract for this VIN (1, 2, or 3)
			MpContractVehicleDto activeMpContract = mpContractDto.getActiveMpContract();
			String typeContract = activeMpContract.getTypeContract();
			String contractNumber = activeMpContract.getContractNumber();
			// Start date of the first contract (last contract in list mpContractDto.getContracts())
			Date contractStartDate = mpContractDto.getContracts().get(mpContractDto.getContracts().size() - 1).getContractStartDate();
			Date contractEndDate = activeMpContract.getContractEndDate();

			if (Constants.CUSTOMER_CNH.equals(customer))
			{
				if (Constants.WARRANTY_TYPE_CNH_PROCARE.equals(typeContract))
				{
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_CNH_PROCARE);
				}
				else if (Constants.WARRANTY_TYPE_CNH_STANDARD.equals(typeContract))
				{
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_CNH_STANDARD);
				}
				mpContractTypeMessageDto.setContractType(typeContract);
			}
			else
			{
				if (Constants.INTERACTIVE_CONTRACT.equals(typeContract))
				{
					// CASE 1 : In the contract imported from SAP, the contract type is « 1 » and start date <= Today <=end date
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_INTERACTIVE);
					mpContractTypeMessageDto.setContractType(Constants.INTERACTIVE_CONTRACT);
				}
				else if (Constants.PAY_PER_USE_CONTRACT.equals(typeContract))
				{
					// CASE 2 : In the contract imported from SAP, the contract type is « 2 » and start date <= Today <=end date
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_PAY_PER_USE);
					mpContractTypeMessageDto.setContractType(Constants.PAY_PER_USE_CONTRACT);
				}
				else if (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(typeContract))
				{
					// CASE 3 : In the contract imported from SAP, the contract type is « 3 » and start date <= Today <=end date
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_FLEXIBLE);
					mpContractTypeMessageDto.setContractType(ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue());
				}
			}

			mpContractTypeMessageDto.setContractNumber(contractNumber);
			mpContractTypeMessageDto.setContractStartDate(sdf.format(contractStartDate));
			mpContractTypeMessageDto.setContractEndDate(sdf.format(contractEndDate));

		}
		else if (sapVehicleInformation != null
				&& isContractTypeMWarrantyServices(sapVehicleInformation.getWarrantyServices(), warrantyTypes)
				&& getActiveContractTypeMWarrantyServices(sapVehicleInformation.getWarrantyServices(), warrantyTypes) != null)
		{

			// CASE 4 : In the SAP broker if there is a contract type "M" (IVECO) / "0" or "M" (CNH) in the warranty service and start date <= Today <=end date
			WarrantyServicesDto warranty = getActiveContractTypeMWarrantyServices(sapVehicleInformation.getWarrantyServices(), warrantyTypes);

			if (Constants.CUSTOMER_IVECO.equals(customer))
			{
				mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_STANDARD);
			}
			else
			{
				if (Constants.WARRANTY_TYPE_CNH_PROCARE.equals(warranty.getWarrantyType()))
				{
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_WARRANTY_CNH_PROCARE);
				}
				else
				{
					mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_WARRANTY_CNH_STANDARD);
				}
			}

			mpContractTypeMessageDto.setContractType(warranty.getWarrantyType());
			mpContractTypeMessageDto.setContractNumber(warranty.getContract());

			// Message part StartDate/EndDate
			try
			{
				mpContractTypeMessageDto.setContractStartDate(sdf.format(sdfWarranty.parse(warranty.getServStartdate())));
				mpContractTypeMessageDto.setContractEndDate(sdf.format(sdfWarranty.parse(warranty.getServEnddate())));
			}
			catch (ParseException e)
			{
				throw new ApplicativeException(e);
			}

		}
		else if ((mpContractDto != null && mpContractDto.getActiveMpContract() == null && !mpContractDto.getContracts().isEmpty()))
		{
			MpContractVehicleDto expiredContract = mpContractDto.getContracts().get(0);

			if (expiredContract.getContractEndDate().before(new Date()))
			{
				// CASE 5 : There were contracts (standard, interactive,…) and End date < Today
				mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_EXPIRED);

				mpContractTypeMessageDto.setContractType(expiredContract.getTypeContract());
				mpContractTypeMessageDto.setContractNumber(expiredContract.getContractNumber());
				mpContractTypeMessageDto.setContractStartDate(sdf.format(expiredContract.getContractStartDate()));
				mpContractTypeMessageDto.setContractEndDate(sdf.format(expiredContract.getContractEndDate()));
			}
			else
			{
				// CASE 6 : A maintenance contract has never been defined for the VIN
				mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_NO_CONTRACT);
			}

		}
		else if (sapVehicleInformation != null && isExpiredContractTypeMWarrantyServices(sapVehicleInformation.getWarrantyServices(), warrantyTypes))
		{
			// TODO LAE IAZ which contract type (last expired ?)
			mpContractTypeMessageDto.setContractType(Constants.STANDARD_CONTRACT);
			WarrantyServicesDto warranty = getExpiredContractTypeMWarrantyServices(sapVehicleInformation.getWarrantyServices());
			mpContractTypeMessageDto.setContractNumber(warranty != null ? warranty.getContract() : "");
			mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_EXPIRED);

			// Message part StartDate/EndDate
			try
			{
				mpContractTypeMessageDto.setContractStartDate(sdf.format(sdfWarranty.parse(warranty.getServStartdate())));
				mpContractTypeMessageDto.setContractEndDate(sdf.format(sdfWarranty.parse(warranty.getServEnddate())));
			}
			catch (ParseException e)
			{
				throw new ApplicativeException(e);
			}
		}
		else
		{

			// CASE 6 : A maintenance contract has never been defined for the VIN
			mpContractTypeMessageDto.setContractTypeMessageKey(Constants.MESSAGE_KEY_NO_CONTRACT);

		}

		return mpContractTypeMessageDto;

	}

	/**
	 * Calculate the Active Contract type 'M' in Warranty Services provided by SAP.
	 *
	 * @param dto DTO containing the context (VIN, SUBFLOW and LANGUAGE)
	 * @param warrantyTypes customer warranty types
	 *
	 * @throws ApplicativeException
	 */
	private static WarrantyServicesDto getActiveContractTypeMWarrantyServices(List<WarrantyServicesDto> warrantyServices, String[] warrantyTypes) throws ApplicativeException {

		// Check if Warranty Services are currently active (NOW between begin and end date)
		if (warrantyServices != null && !warrantyServices.isEmpty())
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			for (WarrantyServicesDto warranty : warrantyServices)
			{
				if (warranty.getServStartdate() != null && warranty.getServEnddate() != null && Arrays.asList(warrantyTypes).contains(warranty.getWarrantyType()))
				{
					Date beginDate;
					Date endDate;
					try
					{
						beginDate = sdf.parse(warranty.getServStartdate());
						endDate = sdf.parse(warranty.getServEnddate());
					}
					catch (ParseException e)
					{
						throw new ApplicativeException(e);
					}
					Date currentDate = new Date();

					if (currentDate.compareTo(beginDate) > 0 && currentDate.compareTo(endDate) < 0)
					{
						return warranty;
					}
				}
			}

		}

		return null;

	}

	/**
	 * Calculate the Active Contract type 'M' in Warranty Services provided by SAP.
	 *
	 * @param dto DTO containing the context (VIN, SUBFLOW and LANGUAGE)
	 * @param warrantyTypes customer warranty types
	 *
	 * @throws ApplicativeException
	 */
	private static boolean isContractTypeMWarrantyServices(List<WarrantyServicesDto> warrantyServices, String[] warrantyTypes) throws ApplicativeException {

		if (warrantyServices != null && !warrantyServices.isEmpty())
		{

			for (WarrantyServicesDto warranty : warrantyServices)
			{
				if (Arrays.asList(warrantyTypes).contains(warranty.getWarrantyType()))
				{
					return true;
				}
			}

		}

		return false;

	}

	/**
	 * Calculate the Active Contract type 'M' in Warranty Services provided by SAP.
	 *
	 * @param dto DTO containing the context (VIN, SUBFLOW and LANGUAGE)
	 * @param warrantyTypes customer warranty types
	 *
	 * @throws ApplicativeException
	 */
	private static boolean isExpiredContractTypeMWarrantyServices(List<WarrantyServicesDto> warrantyServices, String[] warrantyTypes) throws ApplicativeException {

		// Check if Warranty Services are currently active (NOW between begin and end date)
		if (warrantyServices != null && !warrantyServices.isEmpty())
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			for (WarrantyServicesDto warranty : warrantyServices)
			{
				if (warranty.getServEnddate() != null && Arrays.asList(warrantyTypes).contains(warranty.getWarrantyType()))
				{

					Date endDate;
					try
					{
						endDate = sdf.parse(warranty.getServEnddate());
					}
					catch (ParseException e)
					{
						throw new ApplicativeException(e);
					}
					Date currentDate = new Date();

					if (currentDate.after(endDate))
					{
						return true;
					}
				}
			}

		}

		return false;

	}

	/*
	 * Calculate the Active Contract type 'M' in Warranty Services provided by SAP.
	 *
	 * @param dto DTO containing the context (VIN, SUBFLOW and LANGUAGE)
	 * @throws ApplicativeException
	 */
	private static WarrantyServicesDto getExpiredContractTypeMWarrantyServices(List<WarrantyServicesDto> warrantyServices) throws ApplicativeException {

		// Check if Warranty Services are currently active (NOW between begin and end date)
		if (warrantyServices != null && !warrantyServices.isEmpty())
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			for (WarrantyServicesDto warranty : warrantyServices)
			{
				if (warranty.getServEnddate() != null && Constants.STANDARD_CONTRACT.equals(warranty.getWarrantyType()))
				{

					Date endDate;
					try
					{
						endDate = sdf.parse(warranty.getServEnddate());
					}
					catch (ParseException e)
					{
						throw new ApplicativeException(e);
					}
					Date currentDate = new Date();

					if (currentDate.after(endDate))
					{
						return warranty;
					}
				}
			}

		}

		return null;

	}

	/**
	 * Get the unit key of the current series.
	 *
	 * @param brandIcecode Brand ICE code
	 * @param typeIcecode Type ICE code
	 * @param productIcecode Product ICE code
	 * @param seriesIcecode Series ICE code
	 * @return the key of the unit to display correctly the labels
	 * @throws SystemException SystemException
	 * @throws ApplicativeException ApplicativeException
	 */
	public static String getUnitKeyBySerie(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException, ApplicativeException {
		String result = "";
		// Get the unit key for the current serie
		MpUnitSeriesDto mpUnitSeriesDto = new MpUnitSeriesBusiness().getUnitKeyBySerie(brandIcecode, typeIcecode, productIcecode, seriesIcecode);
		if (mpUnitSeriesDto != null && mpUnitSeriesDto.getUnitKey() != null)
		{
			result = mpUnitSeriesDto.getUnitKey();
		}

		return result;
	}

	/**
	 * Fill the mpNextStopmin and the MpNextStop list from UCR data
	 *
	 * @param userSession
	 * @param mpdtoList mpdto list to fill
	 * @param mpNextStopMin to fill
	 * @return an error code
	 * @throws SystemException ParseException
	 * @throws ApplicativeException
	 */
	public static MpPlanDto fillMpNextStopListFromUCR(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, String languageId, String vin, String currentHours, String userId,
			MonSearchBySnDto monSearchBySnDto, boolean isConnected, List<MpUsageDto> applicableMissionList)
			throws SystemException, ParseException, ApplicativeException {

		MpPlanDto planDto = new MpPlanDto(null);
		//Call to UCR Webservice
		JsonObjectBuilder body = Json.createObjectBuilder();
		if (languageId != null)
		{
			// Check that the engine hour String is not empty (potentially coming from DJC)
			body = new MaintenanceUcrUtil().prepareJsonOpenApiNextCoupons(vin, isConnected, currentHours != "" ? Long.valueOf(currentHours).doubleValue() : Long.valueOf(0L).doubleValue(), languageId);
		}

		OpenApiParameters args = new OpenApiParameters(vin, OpenApiWebServiceEnum.NEXT_COUPONS, userId, body.build().toString());
		JsonObject jsonResponse = OpenApiWebService.call(args);
		//If Response fail, return error case
		if (jsonResponse == null)
		{
			planDto.setErrorCase("7");
			new DMCBusiness().logFailureMP("ALL", Constants.UCR_GET_NEXT_COUPONS_ERROR, "VIN: " + vin + " - Error retrieving Next Stop Coupon from UCR",
					Context.getSoftwareVersion(), "ALL");
			return planDto;
		}
		else
		{
			JsonObject jsonData = jsonResponse.getJsonObject(VehicleTelematicsConstants.PARAM_DATA);

			if (!jsonData.isNull(NextCouponsConstants.MP_NEXT_COUPON_COUPONS) && !jsonData.getJsonArray(NextCouponsConstants.MP_NEXT_COUPON_COUPONS).isEmpty()
					&& !jsonData.isNull(NextCouponsConstants.MP_NEXT_COUPON_PLAN_ID))
			{
				//Get Last Engine Hour to compare with the current engine hour (Run Like a Rolex)
				JsonArray jsonCoupons = jsonData.getJsonArray(NextCouponsConstants.MP_NEXT_COUPON_COUPONS);
				if (jsonCoupons.size() > 0)
				{
					JsonObject jsonCoupon = jsonCoupons.getJsonObject(0);
					JsonValue jsonValue = jsonCoupon.get(NextCouponsConstants.MP_NEXT_COUPON_LAST_ENGINE_HOURS);
					if (!JsonValue.NULL.equals(jsonValue) && jsonValue.toString() != null && !jsonValue.toString().equals("null"))
					{
						jsonCoupon.getJsonNumber(NextCouponsConstants.MP_NEXT_COUPON_LAST_ENGINE_HOURS).longValue();
						Long engineHour = Long.valueOf(jsonCoupon.getInt(NextCouponsConstants.MP_NEXT_COUPON_LAST_ENGINE_HOURS));

						if (monSearchBySnDto != null)
						{
							//monSearchBySnDto.setEngineHoursUcrCoupons(engineHour);
						//	monSearchBySnDto.setEngineHoursUcrTelematics(currentHours != "" ? Long.valueOf(currentHours) : null);
							//Insert engine hours data in database
							//new MonSearchBySnBusiness().updateEngineHoursData(monSearchBySnDto);
						}
					}
				}

				Long planExtId = Long.valueOf(jsonData.getInt(NextCouponsConstants.MP_NEXT_COUPON_PLAN_ID));
				// Set the plan in the session
				planDto = new MpPlanBusiness().getPlanByExtId(planExtId);

				if (planDto != null)
				{
					Optional.ofNullable(jsonData.get("is_optimized"))
							.map(JsonValue::toString)
							.map(Boolean::parseBoolean)
							.ifPresent(planDto::setOptimized);
				}

				MaintenanceService.getMpNextStopListFromUCR(jsonData, mpdtoList, mpNextStopMin, planDto, applicableMissionList);
			}
			else if (jsonData.isNull(NextCouponsConstants.MP_NEXT_COUPON_PLAN_ID))
			{
				planDto.setErrorCase("7");

				new DMCBusiness().logFailureMP("ALL", Constants.UCR_GET_NEXT_COUPONS_ERROR, "VIN: " + vin + " - Plan id is null",
						Context.getSoftwareVersion(), "ALL");
			}
			else
			{
				planDto.setErrorCase("8");

				new DMCBusiness().logFailureMP("ALL", Constants.UCR_GET_NEXT_COUPONS_ERROR, "VIN: " + vin + " - Next Coupons are empty or null",
						Context.getSoftwareVersion(), "ALL");
			}
		}
		return planDto;
	}

	/**
	 * Return true if the workshop uses DJC.
	 *
	 * @param workshopSapCode workshopSapCode from DEALER_PORTAL_USERS
	 * @return true if the workshop uses DJC.
	 * @throws SystemException SystemException
	 * @throws ApplicativeException ApplicativeException
	 */
	public static boolean isWorkshopEnabled(String workshopSapCode) throws SystemException, ApplicativeException {

		boolean result = false;
		JobcardParameters args = new JobcardParameters(workshopSapCode, JobcardWebServiceEnum.WORKSHOP_ENABLED);

		JsonObject resultWs = JobcardWebService.call(args);

		//If Response fail, return error case
		if (resultWs != null && !resultWs.isEmpty() && resultWs.containsKey(WorkshopEnabledConstants.PARAM_WORKSHOP_ENABLED))
		{
			result = resultWs.getBoolean(WorkshopEnabledConstants.PARAM_WORKSHOP_ENABLED);
		}
		else
		{
			new DMCBusiness().logFailureMP("ALL", Constants.JOBCARD_GET_WORKSHOP_ENABLED, "WORKSHOP_SAP_CODE: " + workshopSapCode + " - Error retrieving Workshop from UCR",
					Context.getSoftwareVersion(), "ALL");
		}

		return result;
	}

	/**
	 * MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
	 *
	 * @param mpDto
	 * @param nowDate
	 * @param locale
	 * @param customer
	 * @param dtoIceContext
	 * @return
	 */
	public static MaintenancePlanBusiness getMaintenancePlanBusiness(MaintenancePlanDto mpDto, String nowDate, Locale locale, String customer, TransactionAccess transaction,
			IceContextDto dtoIceContext) {

		// MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
		MpToleranceDto mpToleranceDto = new MpToleranceBusiness().getToleranceByBrandAndMarket(dtoIceContext);
		MaintenancePlanBusiness mpBusiness = null;
		switch (mpToleranceDto.getSchedulingType())
		{
		case Constants.VARIABLE_SCHEDULING:
			mpBusiness = new MaintenancePlanVariableSchedulingBusiness(mpDto.getActualMileage(), mpDto.getActualHour(), mpDto.getWarranty().getWarrantyDate(), nowDate, locale,
					customer, transaction, dtoIceContext);
			break;
		case Constants.FIXED_SCHEDULING:
			mpBusiness = new MaintenancePlanFixedSchedulingBusiness(mpDto.getActualMileage(), mpDto.getActualHour(), mpDto.getWarranty().getWarrantyDate(), nowDate, locale,
					customer, transaction, dtoIceContext);
			break;
		default:
			mpBusiness = new MaintenancePlanVariableSchedulingBusiness(mpDto.getActualMileage(), mpDto.getActualHour(), mpDto.getWarranty().getWarrantyDate(), nowDate, locale,
					customer, transaction, dtoIceContext);
			break;
		}

		return mpBusiness;

	}

	/**
	 * MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
	 *
	 * @param customer
	 * @param transaction
	 * @param iceContextDto
	 * @return
	 */
	public static MaintenancePlanBusiness getMaintenancePlanBusiness(Long warrantyDate, String customer, TransactionAccess transaction, IceContextDto iceContextDto) {
		MpToleranceDto mpToleranceDto = new MpToleranceBusiness().getToleranceByBrandAndMarket(iceContextDto);
		MaintenancePlanBusiness mpBusiness = null;
		switch (mpToleranceDto.getSchedulingType())
		{
		case Constants.VARIABLE_SCHEDULING:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(warrantyDate, customer, transaction, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(customer, transaction, iceContextDto);
			}
			break;
		case Constants.FIXED_SCHEDULING:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanFixedSchedulingBusiness(warrantyDate, customer, transaction, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanFixedSchedulingBusiness(customer, transaction, iceContextDto);
			}
			break;
		default:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(warrantyDate, customer, transaction, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(customer, transaction, iceContextDto);
			}
			break;
		}
		return mpBusiness;
	}

	public static List<MpOperationDto> extendOperations(List<MpIntervalOperationDto> mpIntOperationList, IceContextDto context, ProductConfiguration productConfiguration, String engineFullIceCode)
			throws SystemException, ApplicativeException {

		List<MpOperationDto> operationList = mpIntOperationList.parallelStream().map(dto -> {
			MpOperationDto mpOperationDto = new MpOperationDto();

			// Operations
			if (dto.getSrtOperation() != null)
			{
				mpOperationDto.setSrtOperation(dto.getSrtOperation());
			}
			else if (dto.getMicroOperation() != null)
			{
				mpOperationDto.setMicroOperation(dto.getMicroOperation());
			}
			mpOperationDto.setOperationLabelId(dto.getOperationLabelId());
			mpOperationDto.setOperationDescriptionId(dto.getOperationDescriptionId());
			mpOperationDto.setOperationDescription(dto.getOperationDescription());
			mpOperationDto.setOperationLabel(dto.getOperationLabel());
			mpOperationDto.setOperationLabelForSeriesId(dto.getOperationLabelForSeriesId());
			mpOperationDto.setOperationLabelForSeries(dto.getOperationLabelForSeries());
			mpOperationDto.setLocation(dto.getLocation());

			try
			{
				///////////// CONSUMABLES
				List<MpOperationConsumableDto> listOpCons;
				List<MpOperationIuLinkDto> listOpIus = new ArrayList<>();
				listOpCons = getConsumables(dto.getIdOperationSeries(), context, productConfiguration);

				///////////// PARTS
				List<MpOperationPartDto> listOpParts;
				listOpParts = MpOperationPartBusiness.getListPartsByOp(dto.getIdOperationSeries().toString(), context, productConfiguration);

				///////////// IUS LINKS (Get the IU links, only for AG&CE)
				String customer = context.getCustomer();
				if (null != customer && customer.equals(IceConstantes.PROFILE_CNH))
				{
					listOpIus = MpOperationIuLinkBusiness.getListIusByOp(dto.getIdOperationSeries().toString());
				}

				// Consumables attached to the operation
				mpOperationDto.setConsumables(listOpCons);

				// Parts attached to the operation
				mpOperationDto.setParts(listOpParts);
				// Check if the IU is applicable or not. We keep only the first IU applicable
				String iuId = "";
				if (listOpIus != null && listOpIus.size() > 0)
				{
					IuBusiness iuBusiness = new IuBusiness();
					LinkedList<String> lstIuRef = new LinkedList<>();

					for (MpOperationIuLinkDto dtoIuLink : listOpIus)
					{
						// List of Ius linked to the operation
						lstIuRef.add(dtoIuLink.getIuId());
					}

					List<IUDocDto> lstIus = iuBusiness.getListIUinContext(context, lstIuRef, null, true, null, engineFullIceCode, true, productConfiguration);

					// try to find IU with version
					if (null == lstIus || lstIus.isEmpty())
					{
						lstIus = iuBusiness.getListIUinContext(context, lstIuRef, null, true, null, engineFullIceCode, true, true, productConfiguration);
					}

					logger.error("#########################");
					logger.error("Operation:" + dto.getOperationLabel() + "\n");
					String iuString = "";
					for (IUDocDto iu : lstIus)
					{
						iuString += iu.getIfsId() + ",";
					}
					logger.error("Ius:" + iuString + "\n");

					logger.error("#########################");

					// Get the first IU of the list and if the IUId contains a "_", delete the "_"
					// and keep the IU ID
					if (lstIus != null && !lstIus.isEmpty())
					{
						int pos = lstIus.get(0).getIfsId().indexOf("_");
						if (pos != -1)
						{
							iuId = lstIus.get(0).getIfsId().substring(0, pos);
						}
					}
				}
				mpOperationDto.setIuLink(iuId);

				mpOperationDto.setIceCode(dto.getIceCode());
			}
			catch (SystemException | ApplicativeException e)
			{
				logger.error(e.getMessage());
				e.printStackTrace();
				throw new IllegalArgumentException(e);
			}

			return mpOperationDto;

		}).collect(Collectors.toList());

		return operationList;
	}

	/**
	 * copy interval dto to interval operation dto
	 *
	 * @param interval to clone
	 * @return interval operation dto
	 */
	public static MpIntervalOperationDto copyInterval(MpIntervalDto interval) {

		MpIntervalOperationDto intervalOperationDto = new MpIntervalOperationDto();

		intervalOperationDto.setCode(interval.getCode());
		intervalOperationDto.setCoupon(interval.getCoupon());
		intervalOperationDto.setFrequency(interval.getFrequency());
		intervalOperationDto.setType(interval.getType());
		intervalOperationDto.setCommentId(interval.getCommentId());
		intervalOperationDto.setRepairTime(interval.getRepairTime());
		for (MpType type : MpType.values())
		{
			intervalOperationDto.setAfterValue(type, interval.getAfterValue(type));
			intervalOperationDto.setStartValue(type, interval.getStartValue(type));
		}
		intervalOperationDto.setId(interval.getId());
		intervalOperationDto.setCommentLabel(interval.getCommentLabel());
		intervalOperationDto.setSelected(interval.isSelected());
		intervalOperationDto.setCustomer(interval.isCustomer());
		intervalOperationDto.setModifiable(interval.isModifiable());
		intervalOperationDto.setFailureCode(interval.getFailureCode());
		intervalOperationDto.setDefect(interval.getDefect());
		intervalOperationDto.setStatus(interval.getStatus());
		intervalOperationDto.setHidden(interval.isHidden());

		return intervalOperationDto;
	}

	/**
	 * Get the operations for an interval of a maintenance plan.
	 *
	 * @param intervalDto the interval
	 * @param context the user Ice context
	 * @param defaultLanguage the default language
	 * @param productConfiguration the product configuration
	 * @param planId the maintenance plan id
	 * @param jsonCoupons
	 * @param userSession userSession
	 *
	 * @return the operations
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static MpIntervalOperationDto getOperation(MpIntervalDto intervalDto, IceContextDto context, String defaultLanguage,
			ProductConfiguration productConfiguration, String engineFullIceCode)
			throws SystemException, ApplicativeException {
		return getOperation(intervalDto, context, defaultLanguage, productConfiguration, null, engineFullIceCode);
	}

	/**
	 * Get the operations for an interval of a maintenance plan.
	 *
	 * @param intervalDto the interval
	 * @param context the user Ice context
	 * @param defaultLanguage the default language
	 * @param productConfiguration the product configuration
	 * @param planId the maintenance plan id
	 * @param jsonCoupons
	 * @param userSession userSession
	 *
	 * @return the operations
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static MpIntervalOperationDto getOperation(MpIntervalDto intervalDto, IceContextDto context, String defaultLanguage,
			ProductConfiguration productConfiguration, List<MpHistoryIntervalDto> historyIntervals, String engineFullIceCode)
			throws SystemException, ApplicativeException {
		MpIntervalOperationDto mpIntervalDto = null;
		List<MpIntervalOperationDto> listOp = (new MpOperationBusiness()).getListOperations(intervalDto.getId().toString(), context.getLanguage().getIdlanguage(), defaultLanguage);

		if (listOp != null && !listOp.isEmpty())
		{

			// -- copy interval dto to interval operation dto
			mpIntervalDto = copyInterval(intervalDto);
			mpIntervalDto.setOperations(extendOperations(listOp, context, productConfiguration, engineFullIceCode));
			mpIntervalDto.setStatus(intervalDto.getStatus());

			// Add last maintenance details
			if (historyIntervals != null && !historyIntervals.isEmpty())
			{
				for (MpHistoryIntervalDto history : historyIntervals)
				{
					if (history.getIntervalCode().equals(intervalDto.getCode()))
					{
						mpIntervalDto.setLastMaintenanceDate(history.retreiveFromExactValueByMpType(MpType.MP_MONTH));
						mpIntervalDto.setLastMaintenanceEH(history.retreiveFromExactValueByMpType(MpType.MP_HOUR).toString());
						mpIntervalDto.setLastMaintenanceBales(history.retreiveFromExactValueByMpType(MpType.MP_KM).toString());
					}
				}
			}
		}
		return (mpIntervalDto);
	}

	/**
	 * Get all the consumables with correct description and Part number.
	 *
	 * @param idSeriesOperation the id of the operation series
	 * @param context ice context
	 * @param productConfiguration the product configuration
	 * @return the list of operations
	 * @throws SystemException SystemException
	 * @throws ApplicativeException ApplicativeException
	 */
	private static List<MpOperationConsumableDto> getConsumables(Long idSeriesOperation, IceContextDto context, ProductConfiguration productConfiguration)
			throws SystemException, ApplicativeException {

		List<MpOperationConsumableDto> listCons = MpOperationConsumableBusiness.getListConsumablesByOp(idSeriesOperation, context, productConfiguration);

		// MSH -- Get Parts Number and Occurrences based on Market/Region, Current Date and Country.

		listCons.parallelStream().forEach(consumable -> {
			ConsumableListDto consListDto=new ConsumableListDto();
			try
			{
				//consListDto = new ConsumableListBusiness().getConsByIdAndContext(new ConsumableListDto(consumable.getIdConsumable()), context, new ConsumableListDomain());

				if (consListDto != null)
				{
					// set occurrence id
					consumable.setOccurrenceId(consListDto.getCnOccId());

					// Update description of consumable
					if (consumable.getConsumable().indexOf("-") > -1)
					{
						consumable
								.setConsumable(consumable.getConsumable()
										.substring(0, consumable.getConsumable().indexOf("-")) + " - " + consListDto.getCnOccName());
					}

					MpOperationConsumableDto newDto = MpOperationConsumableBusiness.getConsPnByConsId(consumable.getIdConsumable(), consListDto.getCnOccId(), context.getCountry(),
							context.getMarketId().toString());

					// Update Part Number of consumable
					if (newDto != null)
					{
						consumable.setPartnumber(newDto.getPartnumber());
					}
				}
			}
			catch (SystemException e)
			{
				e.printStackTrace();
			}

		});

		return listCons;
	}

	/**
	 * Fill the MP next stop list.
	 * 
	 * @param listNextStop
	 * @param customer
	 * @param sapVehicleInformation
	 * @param currentVehicleData
	 * @param context
	 * @param mpNextStopMin
	 * @param vin
	 * @param lstPinVin
	 * @param mpContractDto
	 * @param productConfiguration
	 * @param flexibleCoupons
	 * @param isMpLockEnabled
	 * @return message error if exists
	 */
	public static String fillMpNextStopList(List<MpNextStopDto> listNextStop, String customer, ResponseData sapVehicleInformation, CurrentVehicleDataDto currentVehicleData, IceContextDto context,
			MpNextStopMinDto mpNextStopMin, String vin, List<String> lstPinVin, MpContractDto mpContractDto, ProductConfiguration productConfiguration,
			Map<String, MpFlexCouponDto> flexibleCoupons, boolean isMpLockEnabled) throws SystemException, ApplicativeException {

		String errorCase = "0";

		if (mpContractDto != null)
		{
			WebParamDto webParam = new WebParamBusiness().getWebParamsForId(Constantes.WEB_PARAM_MP_LOCKER);
			if (!Constantes.MP_LOCK.equals(webParam.getWeb_value()))
			{
				errorCase = retrieveNextStopWithContract(
						listNextStop, vin, mpContractDto, sapVehicleInformation, currentVehicleData, mpNextStopMin,
						customer, isMpLockEnabled, productConfiguration, context, flexibleCoupons, lstPinVin);
			}
			else
			{
				errorCase = "6";
			}
		}
		else
		{
			errorCase = retrieveNextStopWithoutContract(
					listNextStop, vin, productConfiguration, sapVehicleInformation, customer,
					isMpLockEnabled, context, flexibleCoupons, lstPinVin, currentVehicleData);
		}

		if (listNextStop.isEmpty() && !errorCase.equals("0"))
		{
			// error cases : today only log on MP_ETIM_LOGS
		}

		return errorCase;
	}
}
