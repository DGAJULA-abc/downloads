package capgemini.cnh.maintenanceservice.service;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.openapi.model.OpenApiParameters;
import capgemini.cnh.externals.openapi.ws.OpenApiWebService;
import capgemini.cnh.externals.openapi.ws.OpenApiWebService.OpenApiWebServiceEnum;
import capgemini.cnh.externals.util.NextCouponsConstants;
import capgemini.cnh.externals.util.VehicleTelematicsConstants;
import capgemini.cnh.framework.common.Constantes;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.DMCBusiness;
//import capgemini.cnh.ice.business.MonTelematicsBusiness;
//import capgemini.cnh.ice.dto.MonTelematicsDto;
import capgemini.cnh.maintenanceservice.util.MaintenanceUcrUtil;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * Maintenance.
 * 
 * @author mmartel
 */
public class UcrService {

	/** The logger. */
	private static TIDBLogger logger = TIDBLogger.getLogger(UcrService.class);

	/** Creates. */
	public UcrService() {
	}

	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/************************************************* Call Vehicle telematis from UCR ***************************************************************************************/
	/***********************************************************************************************************************************************************************/
	/***********************************************************************************************************************************************************************/

	/**
	 * Call OpenAPI web service to retrieve if the PIN is visible in UCR.
	 * 
	 * @param vin : VIN to search
	 * @param userId : session user Id
	 * @param configList
	 * 
	 * @return true if the PIN is visible in UCR, false otherwise.
	 * @throws SystemException SystemException
	 * @throws KeyStoreException KeyStoreException
	 * @throws IOException IOException
	 * @throws CertificateException CertificateException
	 * @throws NoSuchAlgorithmException NoSuchAlgorithmException
	 * @throws UnrecoverableKeyException UnrecoverableKeyException
	 * @throws KeyManagementException KeyManagementException
	 * @throws ApplicativeException ApplicativeException
	 */

	public static CurrentVehicleDataDto getVehicleTelematics(String vin, String userId, Boolean hasConfigList)
			throws SystemException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException, KeyManagementException, ApplicativeException {

		OpenApiParameters args = new OpenApiParameters(vin, OpenApiWebServiceEnum.VEHICLE_TELEMATICS, userId, null);

		JsonObject jsonResponse = OpenApiWebService.call(args);
		CurrentVehicleDataDto currentVehicleDataDto = new CurrentVehicleDataDto();
		if (jsonResponse != null)
		{
			JsonObject dataObject = jsonResponse.getJsonObject(VehicleTelematicsConstants.PARAM_DATA);
			JsonValue jsonDataflowStatusValue = jsonResponse.get(VehicleTelematicsConstants.PARAM_DATAFLOW_STATUS);

			//CurrentVehicleDataDto currentVehicleDataDto = new CurrentVehicleDataDto();
			//Get visibility of PIN in UCR
			if (dataObject != null)
			{
				if (dataObject.containsKey(VehicleTelematicsConstants.CONNECTIVITY_STATUS) && dataObject.get(VehicleTelematicsConstants.CONNECTIVITY_STATUS).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.CONNECTIVITY_STATUS).toString().equals("null"))
				{
					currentVehicleDataDto.setConnectivityStatus(dataObject.getJsonNumber(VehicleTelematicsConstants.CONNECTIVITY_STATUS).longValue());
				}

				if (dataObject.containsKey(VehicleTelematicsConstants.MAINTENANCE_STATUS) && dataObject.get(VehicleTelematicsConstants.MAINTENANCE_STATUS).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.MAINTENANCE_STATUS).toString().equals("null"))
				{
					currentVehicleDataDto.setMaintenanceStatus(dataObject.getJsonNumber(VehicleTelematicsConstants.MAINTENANCE_STATUS).longValue());
				}

				if (dataObject.containsKey(VehicleTelematicsConstants.WARRANTY_STATUS) && dataObject.get(VehicleTelematicsConstants.WARRANTY_STATUS).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.WARRANTY_STATUS).toString().equals("null"))
				{
					currentVehicleDataDto.setWarrantyStatus(dataObject.getJsonNumber(VehicleTelematicsConstants.WARRANTY_STATUS).longValue());
				}

				//Separate Maintenance and Connectivity
				currentVehicleDataDto.setUcrManageMP(whoManagesMp(currentVehicleDataDto.getConnectivityStatus(), currentVehicleDataDto.getMaintenanceStatus()));

				if (Constantes.UCR_CONNECTIVITY_STATUS_CONNECTED.compareTo(currentVehicleDataDto.getConnectivityStatus()) == 0)
				{
					currentVehicleDataDto.setConnected(true);
				}

				// Start getting LAST_COMMUNICATION_DATE
				if (dataObject.containsKey(VehicleTelematicsConstants.LAST_COMMUNICATION_DATE))
				{
					JsonValue jsonValue = dataObject.get(VehicleTelematicsConstants.LAST_COMMUNICATION_DATE);
					if (jsonValue.toString() != null && !jsonValue.toString().equals("null"))
					{
						currentVehicleDataDto.setLastCommunicationDate(dataObject.getJsonString(VehicleTelematicsConstants.LAST_COMMUNICATION_DATE).toString());
					}
					else
					{
						currentVehicleDataDto.setLastCommunicationDate("");
					}
				}

				// End getting LAST_COMMUNICATION_DATE
				if (dataObject.containsKey(VehicleTelematicsConstants.PARAM_ENGINE_HOURS))
				{
					JsonValue jsonValue = dataObject.get(VehicleTelematicsConstants.PARAM_ENGINE_HOURS);
					if (jsonValue.toString() != null && !jsonValue.toString().equals("null"))
					{
						currentVehicleDataDto.setCurrentHours(dataObject.getJsonNumber(VehicleTelematicsConstants.PARAM_ENGINE_HOURS).longValue());
					}
					else
					{
						currentVehicleDataDto.setCurrentHours(new Long(0));
					}
				}

				// Get the warranty start date from UCR 
				if (dataObject.containsKey(VehicleTelematicsConstants.WTY_START_DATE) && dataObject.get(VehicleTelematicsConstants.WTY_START_DATE).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.WTY_START_DATE).toString().equals("null"))
				{
					currentVehicleDataDto
							.setWtyStartDate(LocalDate.parse(dataObject.getJsonString(VehicleTelematicsConstants.WTY_START_DATE).toString(), DateTimeFormatter.ISO_ZONED_DATE_TIME).toString());
				}

				// Get the annual average usage from UCR
				if (dataObject.containsKey(VehicleTelematicsConstants.AVERAGE_ANNUAL_USAGE) && dataObject.get(VehicleTelematicsConstants.AVERAGE_ANNUAL_USAGE).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.AVERAGE_ANNUAL_USAGE).toString().equals("null"))
				{
					currentVehicleDataDto.setAverageAnnualUsage(dataObject.getJsonNumber(VehicleTelematicsConstants.AVERAGE_ANNUAL_USAGE).longValue());
				}

				// Get the alert on/off parameter
				if (dataObject.containsKey(VehicleTelematicsConstants.MP_ALERT_IS_ACTIVE) && dataObject.get(VehicleTelematicsConstants.MP_ALERT_IS_ACTIVE).toString() != null
						&& !dataObject.get(VehicleTelematicsConstants.MP_ALERT_IS_ACTIVE).toString().equals("null"))
				{
					currentVehicleDataDto.setMpAlertActive(dataObject.getBoolean(VehicleTelematicsConstants.MP_ALERT_IS_ACTIVE));
				}

				// PBI 193884 - Monitoring Telematics
				// hasConfigList is null when the webservice is call from Jobcard (through etim-api)
				if (hasConfigList != null)
				{
//					MonTelematicsDto monTelematicsDto = new MonTelematicsDto();
//					monTelematicsDto.setConnectivityStatus(currentVehicleDataDto.getConnectivityStatus());
//					monTelematicsDto.setMaintenanceStatus(currentVehicleDataDto.getMaintenanceStatus());
//					monTelematicsDto.setWarrantyStatus(currentVehicleDataDto.getWarrantyStatus());
//					monTelematicsDto.setVin(vin);
//					if (hasConfigList)
//					{
//						monTelematicsDto.setSapConfigOk(true);
//					}
//					else
//					{
//						monTelematicsDto.setSapConfigOk(false);
//					}
//
//					new MonTelematicsBusiness().insert(monTelematicsDto);
				}
			}

			//Run Like A Rolex - Display alert message if UCR dataflow is in error (error during algorithm)
			if (jsonDataflowStatusValue != null && jsonDataflowStatusValue.toString().equals("2"))
			{
				currentVehicleDataDto.setCoveredByUcrStatus(capgemini.cnh.framework.common.Constantes.UCRSTATUS_DATAFLOW_ERROR);
			}
		}

		return currentVehicleDataDto;
	}

	/**
	 * Return true if connectivityStatus = 0,1,2,3,4,5 and maintenanceStatus = 0.
	 * 
	 * @param connectivityStatus -1 to 5
	 * @param maintenanceStatus -1 to 3
	 * @return true if connectivityStatus = 0,1,2,3,4,5 and maintenanceStatus = 0.
	 */
	private static boolean whoManagesMp(Long connectivityStatus, Long maintenanceStatus) {
		return (Constantes.UCR_CONNECTIVITY_STATUS_CONNECTED.compareTo(connectivityStatus) == 0
				|| Constantes.UCR_CONNECTIVITY_STATUS_EXPIRED.compareTo(connectivityStatus) == 0
				|| Constantes.UCR_CONNECTIVITY_STATUS_NOT_ACTIVE.compareTo(connectivityStatus) == 0
				|| Constantes.UCR_CONNECTIVITY_STATUS_NOT_CONNECTED.compareTo(connectivityStatus) == 0
				|| Constantes.UCR_CONNECTIVITY_STATUS_TRANSMISSION_ISSUE.compareTo(connectivityStatus) == 0
				|| Constantes.UCR_CONNECTIVITY_STATUS_NO_ENGINE_HOURS.compareTo(connectivityStatus) == 0) && Constantes.UCR_MAINTENANCE_STATUS_MP_FOUND.compareTo(maintenanceStatus) == 0;
	}
	
	/**
	 * @return isOptimized : boolean gotten from ucr side
	 *
	 * @param languageId : the language id that is been used
	 * @param vin : the vine of the current VehicleData Dto
	 * @param userId : user id
	 */
	public static boolean isOptimized(String languageId, String vin, String userId)
			throws SystemException, ApplicativeException{
		
		MpPlanDto planDto = new MpPlanDto(null);
		//Call to UCR Webservice
		JsonObjectBuilder body = Json.createObjectBuilder();
		if (languageId != null)
		{
			// Check that the engine hour String is not empty (potentially coming from DJC)
			body = new MaintenanceUcrUtil().prepareJsonOpenApiNextCoupons(vin, false, Long.valueOf(0L).doubleValue(), languageId);
		}
		
		// calling UCR 
		OpenApiParameters args = new OpenApiParameters(vin, OpenApiWebServiceEnum.NEXT_COUPONS, userId, body.build().toString());
		JsonObject jsonResponse = OpenApiWebService.call(args);
		
		//If Response fail, return error case
		if (jsonResponse == null)
		{
			planDto.setErrorCase("7");
			new DMCBusiness().logFailureMP("ALL", Constants.UCR_GET_NEXT_COUPONS_ERROR, "VIN: " + vin + " - Error retrieving Next Stop Coupon from UCR",
					Context.getSoftwareVersion(), "ALL");
			return planDto.isOptimized();
		}
		else
		{
			JsonObject jsonData = jsonResponse.getJsonObject(VehicleTelematicsConstants.PARAM_DATA);
			if (!jsonData.isNull(NextCouponsConstants.MP_NEXT_COUPON_COUPONS) && !jsonData.getJsonArray(NextCouponsConstants.MP_NEXT_COUPON_COUPONS).isEmpty()
					&& !jsonData.isNull(NextCouponsConstants.MP_NEXT_COUPON_PLAN_ID))
			{
				Optional.ofNullable(jsonData.get("is_optimized"))
						.map(JsonValue::toString)
						.map(Boolean::parseBoolean)
						.ifPresent(planDto::setOptimized);
			}
		}
		return planDto.isOptimized();
	}
}
