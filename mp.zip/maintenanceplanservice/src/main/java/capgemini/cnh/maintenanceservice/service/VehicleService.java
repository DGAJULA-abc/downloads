package capgemini.cnh.maintenanceservice.service;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.common.SearchBySerialNumberConstants;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.SapSerialNumberMappingBusiness;
import capgemini.cnh.ice.dto.SapSerialNumberMappingDto;

/**
 * Maintenance.
 * 
 * @author mmartel
 */
public class VehicleService {

	/** The logger. */
	private static TIDBLogger logger = TIDBLogger.getLogger(VehicleService.class);

	/** Creates. */
	public VehicleService() {
	}

	/**
	 * 
	 * @param pinVin the current pin
	 * 
	 * @return a list with the vin 9/17 if exists
	 * @throws SystemException an exception
	 * @throws ApplicativeException an exception
	 */
	public List<String> getVins(String pinVin, boolean isIveco) throws SystemException, ApplicativeException {
		List<String> lstPinVin = new ArrayList<>();
		lstPinVin.add(pinVin);

		// For CV, there is not the VIN mapping, so check the alerts on the current VIN.
		// For AG&CE, there are several use cases:
		if (!isIveco)
		{
			SapSerialNumberMappingDto sapSerialNumberMappingDto = null;

			if (pinVin.length() == SearchBySerialNumberConstants.SERIAL_NUMBER_NINE_DIGIT)
			{
				sapSerialNumberMappingDto = (new SapSerialNumberMappingBusiness()).getMappedPin17Digit(pinVin);
			}
			else if (pinVin.length() == SearchBySerialNumberConstants.SERIAL_NUMBER_MAX_LENGTH)
			{
				sapSerialNumberMappingDto = (new SapSerialNumberMappingBusiness()).getMappedPin9Digit(pinVin);
			}

			if (sapSerialNumberMappingDto != null && sapSerialNumberMappingDto.getSapVin17() != null && !"".equals(sapSerialNumberMappingDto.getSapVin17()))
			{
				if (pinVin.length() == SearchBySerialNumberConstants.SERIAL_NUMBER_NINE_DIGIT)
				{
					lstPinVin.add(sapSerialNumberMappingDto.getSapVin17());
				}
				else
				{
					lstPinVin.add(sapSerialNumberMappingDto.getSapVin());
				}
			}
		}

		return lstPinVin;
	}
}
