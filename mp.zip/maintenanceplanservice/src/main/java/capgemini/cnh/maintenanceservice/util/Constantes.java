package capgemini.cnh.maintenanceservice.util;

/**
 * class for all WCM constantes. 28/02/2011 - CR 379474, eTIM/SRT Languages
 */
public class Constantes {

	/** International English language variable. */
	public static final String ENGLISH = "EN";

	/** table title key : or. */
	public static final String MP_ID_OR = "MP_ID_OR";
	/** table title key : months. */
	public static final String MP_ID_MONTHS = "MP_ID_MONTHS";
	/** table title key : hours. */
	public static final String MP_ID_HOURS = "MP_ID_HOURS";
	/** table title key : at. */
	public static final String MP_ID_AT = "MP_ID_AT";
	/** table title key : and then. */
	public static final String MP_ID_AND_THEN = "MP_ID_AND_THEN";
	/** table title key : every. */
	public static final String MP_ID_EVERY = "MP_ID_EVERY";
	/** UK constant. */
	public static final String UNITED_KINGDOM = "UNITED KINGDOM";

	/** MP_LOCKER web param value */
	public static final String WEB_PARAM_MP_LOCKER = "MP_LOCKER";

	/** MP_LOCKER enable */
	public static final String MP_LOCK = "1";

	/** performance harmonized. */
	public static final String MP_PERFORMANCE_HARMONIZED = "harm";

	/** PDF FULL for dqr_checklist_table. */
	public static final String FULL = "FULL";

	/** PDF FULL for dqr_checklist_table. */
	public static final String FAULT = "FAULT";

	/** MP_LOCK_VIN web param value: to enable or not the lock. */
	public static final String WEB_PARAM_MP_LOCK_VIN = "MP_LOCK_VIN";

	/**
	 * Constructor.
	 */
	public Constantes() {
	}

}
