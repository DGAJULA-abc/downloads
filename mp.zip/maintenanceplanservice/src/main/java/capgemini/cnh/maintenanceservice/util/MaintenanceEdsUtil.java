/**
 * 
 */
package capgemini.cnh.maintenanceservice.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import capgemini.cnh.externals.business.ServiceRequestParamsBusiness;
import capgemini.cnh.externals.dto.ServiceRequestParamsDto;
import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.eds.model.EDSParameters;
import capgemini.cnh.externals.eds.ws.EdsWebService;
import capgemini.cnh.externals.util.ServiceRequestConstants;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ApplicationProperties;
import capgemini.cnh.framework.util.TIDBLogger;

/**
 *
 * @author mmartel
 */
public class MaintenanceEdsUtil {

	/** logger variable. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenanceEdsUtil.class);

	/**
	 * @param vin
	 * @return
	 * @throws SystemException
	 * @throws ApplicativeException
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	public static CurrentVehicleDataDto getCurrentVehicleDataFromEDS(String vin) {
		Properties properties = ApplicationProperties.getProperties();
		String urlEDS = properties.getProperty("eds.service.url");
		String timeOutEDSStr = properties.getProperty("eds.service.time.out");

		// Manage error
		if (urlEDS == null || urlEDS.isEmpty() || vin.isEmpty())
		{
			logger.error("Params to call EDS WS are empty!");
		}

		int timeOutEDS;
		if (timeOutEDSStr != null && !timeOutEDSStr.isEmpty())
		{
			timeOutEDS = Integer.parseInt(timeOutEDSStr);
		}
		else
		{
			timeOutEDS = 5000;
		}

		String header = getHeaderFromServiceRequestParam();

		EDSParameters edsParams = new EDSParameters(vin, urlEDS, timeOutEDS, header);

		// Call the WEBservice
		String sapResponse = null;
		try
		{
			sapResponse = EdsWebService.call(edsParams);
		}
		catch (SystemException | ApplicativeException e)
		{
			logger.error("Error in error in  EdsWebService.call for vin : " + vin, e);

		}
		CurrentVehicleDataDto currentVehicleDataDto = null;
		if (sapResponse != null)
		{
			ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
					false);

			try
			{
				currentVehicleDataDto = objectMapper.readValue(sapResponse, CurrentVehicleDataDto.class);
			}
			catch (IOException e)
			{
				logger.error("Error JsonParseException to read value sapReponse froM EDS ", e);

			}
		}
		return currentVehicleDataDto;
	}

	/**
	 * @return
	 */
	private static String getHeaderFromServiceRequestParam() {
		String header = "";
		List<ServiceRequestParamsDto> lstServiceRequestParamsDto = new ArrayList<>();

		try
		{
			lstServiceRequestParamsDto = (new ServiceRequestParamsBusiness()).getParamsForType(ServiceRequestConstants.MILEAGE_HOUR);
		}
		catch (SystemException e)
		{
			logger.error("System Exception error in getParamsForType :", e);

		}

		if (!lstServiceRequestParamsDto.isEmpty())
		{
			for (ServiceRequestParamsDto serviceRequestParamsDto : lstServiceRequestParamsDto)
			{
				if (ServiceRequestConstants.PARAM_NAME_HEADER_KEY.equals(serviceRequestParamsDto.getParamName()))
				{
					header = String.valueOf(serviceRequestParamsDto.getParamValue());
				}
			}
		}
		return header;
	}

}
