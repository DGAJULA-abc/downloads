/**
 *
 */
package capgemini.cnh.maintenanceservice.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;

import capgemini.cnh.externals.util.NextCouponsConstants;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.tiam.business.EtimAlertBusiness;
import capgemini.cnh.tiam.dto.EtimAlertDto;
import capgemini.cnh.tiam.dto.PriorityEnum;

/**
 *
 * @author mmartel
 */
public class MaintenanceUcrUtil {

	/** dealerCode. */
	public static final String MP_FEEDBACK_DEALER_CODE = "dealerCode";

	/** dealerName. */
	public static final String MP_FEEDBACK_DEALER_NAME = "dealerName";

	/** userID. */
	public static final String MP_FEEDBACK_DEALER_USER_ID = "userID";

	/** notifications. */
	public static final String MP_FEEDBACK_NOTIFICATIONS = "notifications";

	/** couponCode. */
	public static final String MP_FEEDBACK_COUPON_CODE = "couponCode";

	/** timestamp. */
	public static final String MP_FEEDBACK_TIMESTAMP = "timestamp";

	/** dateCreation. */
	public static final String MP_FEEDBACK_CREATION_DATE = "dateCreation";

	/** dateClosure. */
	public static final String MP_FEEDBACK_CLOSURE_DATE = "dateClosure";

	/** priority. */
	public static final String MP_FEEDBACK_PRIORITY = "priority";

	/** planID. */
	public static final String MP_FEEDBACK_PLAN_ID = "planID";

	/** Engine hours. */
	public static final String MP_FEEDBACK_ENGINE_HOURS = "engineHours";

	/** Theoretical engine hours. */
	private static final String MP_FEEDBACK_THEORETICAL_ENGINE_HOURS = "theoreticalEngineHours";

	/** Theoretical date. */
	private static final String MP_FEEDBACK_THEORETICAL_DATE = "theoreticalDate";

	/** planID. */
	public static final String MP_FEEDBACK_STRONG_ID = "strongID";

	/** planID. */
	public static final String MP_FEEDBACK_IS_DEALER = "isDealer";

	/** operations arrays. */
	public static final String MP_FEEDBACK_OPERATIONS = "operations";

	/** comment. */
	private static final String MP_FEEDBACK_COMMENT = "comment";

	/** Attachments. */
	private static final String MP_FEEDBACK_ATTACHMENTS = "attachments";

	/** Attachments service . */
	private static final Long MP_FEEDBACK_SERVICE_TYPE = 1L;

	/** Attachments part type. */
	private static final Long MP_FEEDBACK_PART_TYPE = 2L;

	/** url */
	private static final String MP_FEEDBACK_URL = "url";

	/** type */
	private static final String MP_FEEDBACK_TYPE = "type";

	private static final String MP_PROJECT_NUMBER = "projectNumber";

	private static final String MP_PROJECT_VERSION = "projectVersion";

	private static final String MP_PARTS_CERTIFIED = "partsCertified";

	/**
	 * Prepare the JSON that will be sent to OpenApi as feedback of the saving of the operations performed.
	 *
	 * @param alertsClosed the alerts that have just been closed.
	 * @param historyList all the coupons that have been performed (alerts + manually selected).
	 * @param vin the vin
	 * @param planId the planId
	 * @param dealerCode the dealer code
	 * @param dealerName the dealer name
	 * @param userId the user id
	 * @param engineHours the engine hours
	 * @param saveComments
	 * @return the Json builder
	 * @throws SystemException SystemException
	 */
	public JsonObjectBuilder prepareJsonOpenApiFeedback(List<EtimAlertDto> alertsClosed, List<MpHistoryIntervalDto> historyList, String vin, Long planId, String dealerCode,
			String dealerName, String userId, Double engineHours,
			Long warrantyDate, Boolean isDealer, Map<String, JsonArrayBuilder> couponOperationJsonForUCR, String saveComments, String projectNumber, Integer projectVersion)
			throws SystemException {

		return prepareJsonOpenApiFeedback(alertsClosed, historyList, vin, planId, dealerCode, dealerName, userId, engineHours, warrantyDate, isDealer, couponOperationJsonForUCR, saveComments, null,
				null, projectNumber, projectVersion, null);
	}

	/**
	 * Prepare the JSON that will be sent to OpenApi as feedback of the saving of the operations performed.
	 *
	 * @param alertsClosed the alerts that have just been closed.
	 * @param historyList all the coupons that have been performed (alerts + manually selected).
	 * @param vin the vin
	 * @param planId the planId
	 * @param dealerCode the dealer code
	 * @param dealerName the dealer name
	 * @param userId the user id
	 * @param engineHours the engine hours
	 * @param saveComments
	 * @return the Json builder
	 * @throws SystemException SystemException
	 */
	public JsonObjectBuilder prepareJsonOpenApiFeedback(List<EtimAlertDto> alertsClosed, List<MpHistoryIntervalDto> historyList, String vin, Long planId, String dealerCode, String dealerName,
			String userId, Double engineHours, Long warrantyDate, boolean isDealer, Map<String, JsonArrayBuilder> couponOperationJsonForUCR, String saveComments, String partAttachmentPath,
			String serviceAttachmentPath, String projectNumber, Integer projectVersion, Integer certifiedParts) throws SystemException {

		JsonObjectBuilder resultJson = Json.createObjectBuilder();
		JsonArrayBuilder alertListJson = Json.createArrayBuilder();
		JsonObjectBuilder alertJson = Json.createObjectBuilder();

		if (dealerCode == null)
		{
			dealerCode = "";
		}

		if (dealerName == null)
		{
			dealerName = "";
		}

		if (userId == null)
		{
			userId = "";
		}
		resultJson.add(MP_FEEDBACK_DEALER_CODE, dealerCode);
		resultJson.add(MP_FEEDBACK_DEALER_NAME, dealerName);
		resultJson.add(MP_FEEDBACK_DEALER_USER_ID, userId);

		// date format & current date
		SimpleDateFormat format = new SimpleDateFormat(UtilDate.FORMAT_DATE_YYYYMMDDTHHMMSSSSSZ);
		String currentDate = UtilDate.getDateYYYYMMDDTHHMMSSSSSZ();

		// List to keep the already checked coupons
		List<String> couponCodeList = new ArrayList<>();

		// When alerts not applicable to the vehicle are closed, the historyList is empty, but we still need to send the feedback to UCR.
		if (historyList.isEmpty())
		{
			for (EtimAlertDto alert : alertsClosed)
			{
				Date closureDate = new EtimAlertBusiness().getClosureDateOfCouponAlert(alert.getAlertId(), alert.getPinVin());
				String creationDate = format.format(alert.getDateCreation());
				if (closureDate != null && closureDate.before(alert.getDateCreation()))
				{
					creationDate = format.format(closureDate);
				}
				// In this case theoreticalEngineHours and theoreticalDate can't be calculated, so we use engineHours and closureDate
				alertJson = addFeedbackObject(engineHours.longValue(), alert.getItemCode(), currentDate, creationDate, format.format(closureDate), alert.getPriority(), planId, engineHours.longValue(),
						format.format(closureDate), null, isDealer,
						couponOperationJsonForUCR.get(alert.getItemCode()) != null ? couponOperationJsonForUCR.get(alert.getItemCode()) : Json.createArrayBuilder(),
						saveComments, partAttachmentPath, serviceAttachmentPath, projectNumber, projectVersion, certifiedParts);

				alertListJson.add(alertJson);
			}
		}
		else
		{
			// Loop over the coupons selected by the user and set the creationDate = timestamp and priority to LOW
			for (MpHistoryIntervalDto coupon : historyList)
			{
				// Get the hours to insert for each coupon
				Long hours = (coupon.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(new Long(0)) == 0 && engineHours != null) ? engineHours.longValue()
						: coupon.retreiveFromExactValueByMpType(MpType.MP_HOUR);

				Long theoreticalEngineHours = coupon.getIntValue(MpType.MP_HOUR);

				// Date = date nombre de mois a partir de la warranty start date => calculer
				Long nbMonth = coupon.getIntValue(MpType.MP_MONTH);

				Date theoreticalDate = null;
				if (warrantyDate != null && nbMonth != null)
				{
					theoreticalDate = new Date(warrantyDate);

					if (!nbMonth.equals(new Long(0)))
					{
						Calendar cal = Calendar.getInstance();
						cal.setTime(theoreticalDate);
						cal.add(Calendar.MONTH, nbMonth.intValue());
						theoreticalDate = cal.getTime();
					}

				}

				// Loop over the alerts closed
				if (alertsClosed != null)
				{
					for (EtimAlertDto alert : alertsClosed)
					{
						if (alert.getItemCode().equals(coupon.getIntervalCode()))
						{
							Date closureDate = new Date(coupon.retreiveFromExactValueByMpType(MpType.MP_MONTH));
							String creationDate = format.format(alert.getDateCreation());
							if (closureDate != null && closureDate.before(alert.getDateCreation()))
							{
								creationDate = format.format(closureDate);
							}

							alertJson = addFeedbackObject(hours, alert.getItemCode(), currentDate, creationDate, format.format(closureDate), alert.getPriority(), planId,
									theoreticalEngineHours,
									theoreticalDate != null ? format.format(theoreticalDate) : null, coupon.getStrongId(), isDealer,
									couponOperationJsonForUCR.get(alert.getItemCode()) != null ? couponOperationJsonForUCR.get(alert.getItemCode()) : Json.createArrayBuilder(),
									saveComments, partAttachmentPath, serviceAttachmentPath, projectNumber, projectVersion, certifiedParts);

							alertListJson.add(alertJson);
							couponCodeList.add(alert.getItemCode());
						}
					}
				}

				if (!couponCodeList.contains(coupon.getIntervalCode()))
				{
					Date closureDate = new Date(coupon.retreiveFromExactValueByMpType(MpType.MP_MONTH));
					String closureDateString = UtilDate.dateToString(closureDate, UtilDate.FORMAT_DATE_YYYYMMDDTHHMMSSSSSZ);

					alertJson = addFeedbackObject(hours, coupon.getIntervalCode(), currentDate, closureDateString, closureDateString, PriorityEnum.LOW.getValue(), planId, theoreticalEngineHours,
							theoreticalDate != null ? format.format(theoreticalDate) : null, coupon.getStrongId(), isDealer,
							couponOperationJsonForUCR.get(coupon.getIntervalCode()) != null ? couponOperationJsonForUCR.get(coupon.getIntervalCode()) : Json.createArrayBuilder(),
							saveComments, partAttachmentPath, serviceAttachmentPath, projectNumber, projectVersion, certifiedParts);

					alertListJson.add(alertJson);
					couponCodeList.add(coupon.getIntervalCode());
				}
			}
		}

		resultJson.add(MP_FEEDBACK_NOTIFICATIONS, alertListJson);

		return resultJson;
	}

	/**
	 * Create the feedback object.
	 *
	 * @param engineHours the engine hours of the vehicle
	 * @param couponCode the coupon code
	 * @param currentDate the current date string
	 * @param creationDate the creation date string
	 * @param closureDate the closure date string
	 * @param priority the priority of the alert closed
	 * @param planId the plan id linked to the alert
	 * @param saveComments
	 * @param certifiedParts
	 * @return the feedback object created
	 */
	private static JsonObjectBuilder addFeedbackObject(Long engineHours, String couponCode, String currentDate, String creationDate, String closureDate, Integer priority, Long planId,
			Long theoreticalEngineHours, String theoreticalDate, String strongId, Boolean isDealer, JsonArrayBuilder operationJson, String saveComments, String partAttachmentPath,
			String serviceAttachmentPath, String projectNumber, Integer projectVersion, Integer certifiedParts) {

		JsonObjectBuilder alertJson = Json.createObjectBuilder();

		alertJson.add(MP_FEEDBACK_ENGINE_HOURS, engineHours);
		alertJson.add(MP_FEEDBACK_COUPON_CODE, couponCode);
		alertJson.add(MP_FEEDBACK_TIMESTAMP, currentDate);
		alertJson.add(MP_FEEDBACK_CREATION_DATE, creationDate);
		alertJson.add(MP_FEEDBACK_CLOSURE_DATE, closureDate);
		alertJson.add(MP_FEEDBACK_PRIORITY, priority);
		alertJson.add(MP_FEEDBACK_PLAN_ID, planId);
		alertJson.add(MP_PROJECT_NUMBER, projectNumber != null ? projectNumber : "");
		alertJson.add(MP_PROJECT_VERSION, projectVersion != null ? projectVersion : 0);
		alertJson.add(MP_FEEDBACK_THEORETICAL_ENGINE_HOURS, theoreticalEngineHours != null ? theoreticalEngineHours : 0L);
		alertJson.add(MP_FEEDBACK_THEORETICAL_DATE, theoreticalDate);
		alertJson.add(MP_FEEDBACK_STRONG_ID, strongId);
		alertJson.add(MP_FEEDBACK_IS_DEALER, isDealer);
		alertJson.add(MP_FEEDBACK_COMMENT, saveComments != null ? saveComments : "");
		alertJson.add(MP_PARTS_CERTIFIED, certifiedParts != null ? certifiedParts : 2);

		JsonArrayBuilder attachmentArray = Json.createArrayBuilder();

		if (serviceAttachmentPath != null)
		{
			attachmentArray.add(prepareAttachmentJson(MP_FEEDBACK_SERVICE_TYPE, serviceAttachmentPath));
		}

		if (partAttachmentPath != null)
		{
			attachmentArray.add(prepareAttachmentJson(MP_FEEDBACK_PART_TYPE, partAttachmentPath));
		}

		alertJson.add(MP_FEEDBACK_ATTACHMENTS, attachmentArray.build());

		alertJson.add(MP_FEEDBACK_OPERATIONS, operationJson.build());

		return alertJson;
	}

	private static JsonObjectBuilder prepareAttachmentJson(Long type, String url) {
		JsonObjectBuilder attachmentJson = Json.createObjectBuilder();

		attachmentJson.add(MP_FEEDBACK_URL, url);
		attachmentJson.add(MP_FEEDBACK_TYPE, type);
		return attachmentJson;
	}

	/**
	 * Prepare the JSON that will be sent to OpenApi as feedback of the saving of the operations performed.
	 *
	 * @param vin the vin
	 * @param engineHours the engine hours
	 * @return the Json builder
	 */
	public JsonObjectBuilder prepareJsonOpenApiNextCoupons(String vin, Boolean isConnected, Double engineHours, String lang) {

		JsonObjectBuilder resultJson = Json.createObjectBuilder();

		resultJson.add(NextCouponsConstants.MP_NEXT_COUPON_VIN, vin);
		resultJson.add(NextCouponsConstants.MP_NEXT_COUPON_IS_CONNECTED, isConnected);
		resultJson.add(NextCouponsConstants.MP_NEXT_COUPON_ENGINE_HOURS, engineHours);
		resultJson.add(NextCouponsConstants.MP_NEXT_COUPON_LANGUAGE, lang);

		return resultJson;
	}

}