/**
 * 
 */
package capgemini.cnh.maintenanceservice.util;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.Range;

import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.VehicleDataDto;
import capgemini.cnh.externals.sap.model.ResponseData.WarrantyServicesDto;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.business.MpNextStopBusiness;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;

/**
 *
 * @author mmartel
 */
public class MaintenanceUtil {

	/** logger variable. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MaintenanceUtil.class);

	/**
	 * 
	 */
	private static final int ORDER_BY_HRS_MON_KM = 3;

	/**
	 * 
	 */
	private static final int ORDER_BY_MON_HRS_KM = 2;

	/**
	 * 
	 */
	private static final int ORDER_BY_KM_MON_HRS = 1;

	/**
	 * 
	 */
	private static final String KM = "km";

	/**
	 * 
	 */
	private static final String SPACE = " ";

	/**
	 * Initialization of list of flexible coupons.
	 */
	public static Map<String, MpFlexCouponDto> initFlexibleCoupon() {

		Map<String, MpFlexCouponDto> flexibleCoupons = new HashMap<>();
		try
		{
			List<MpFlexCouponDto> list = (new MpNextStopBusiness()).getFlexibleCoupons();

			if (list != null)
			{
				for (MpFlexCouponDto couponDto : list)
				{
					flexibleCoupons.put(couponDto.getIntervalCode(), couponDto);
				}
			}
		}
		catch (SystemException e)
		{
			logger.error("Cannot read web parameters.", e);
		}
		return flexibleCoupons;

	}

	/**
	 * Retrieve the warranty start date (first in contract, if not in SAP broker.
	 * 
	 * @param vehicleDto : retrieved from SAP broker
	 * @param contract : object contract
	 * @return the warranty start date
	 * @throws ApplicativeException
	 */
	public static String getWarrantyStartDate(ResponseData vehicleDto, MpContractDto contract, String pinVin, boolean isIveco) throws ApplicativeException {
		String warrantyDate = null;

		if (!isIveco)
		{
			warrantyDate = getWarrantyStartDateIsNotIveco(vehicleDto, contract, pinVin);
		}
		else
		{
			warrantyDate = getWarrantyStartDateIsIveco(vehicleDto, contract, pinVin);
		}
		return warrantyDate;
	}

	/**
	 * _
	 * 
	 * @param vehicleDto
	 * @param contract
	 * @param pinVin
	 * @return
	 * @throws ApplicativeException
	 */
	private static String getWarrantyStartDateIsNotIveco(ResponseData vehicleDto, MpContractDto contract, String pinVin) throws ApplicativeException {
		String warrantyDate = null;

		try
		{
			//Vehicle in demo and CNHi property: warranty type "V" or "J" or "A"
			if (vehicleDto != null && vehicleDto.getWarrantyServices().stream().anyMatch(c -> c.getWarrantyType().equals("V") || c.getWarrantyType().equals("J") || c.getWarrantyType().equals("A")))
			{
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(UtilDate.FORMAT_DATE_YYYYMMDD);

				List<LocalDate> warrantyDateListe = vehicleDto.getWarrantyServices().stream()
						.filter(c -> c.getWarrantyType().equals("V") || c.getWarrantyType().equals("J") || c.getWarrantyType().equals("A"))
						.map(WarrantyServicesDto::getServStartdate)
						.filter(Objects::nonNull)
						.map(d -> LocalDate.parse(d, formatter))
						.collect(Collectors.toList());

				if (!warrantyDateListe.isEmpty())
				{
					warrantyDate = warrantyDateListe.stream()
							.sorted()
							.collect(Collectors.toList())
							.get(0).toString();
				}

				//getServStartdate() 
			}
			else
			{
				if (contract != null && contract.getWarrantyStartDate() != null)
				{
					warrantyDate = contract.getWarrantyStartDate();
				}

				else if (contract == null)
				{
					MpHistoryWarrantyDto history = (new MpIntervalBusiness()).readHistoryWarranty(pinVin);
					if (history != null)
					{
						warrantyDate = history.getWarrantyDate();
					}
				}
			}
		}
		catch (SystemException e)
		{
			throw new ApplicativeException(e);
		}

		return warrantyDate;
	}

	/**
	 * @param vehicleDto
	 * @param contract
	 * @param pinVin
	 * @return
	 * @throws ApplicativeException
	 */
	private static String getWarrantyStartDateIsIveco(ResponseData vehicleDto, MpContractDto contract, String pinVin) throws ApplicativeException {
		String warrantyDate = null;

		try
		{
			if (contract != null && contract.getWarrantyStartDate() != null)
			{
				warrantyDate = contract.getWarrantyStartDate();
			}
			else if (vehicleDto != null && !vehicleDto.getVehicleData().isEmpty() && vehicleDto.getVehicleData().get(0).getWtyStart() != null)
			{
				List<VehicleDataDto> listVehicle = vehicleDto.getVehicleData();
				warrantyDate = listVehicle.get(0).getWtyStart();

			}
			else if (contract == null)
			{
				MpHistoryWarrantyDto history = (new MpIntervalBusiness()).readHistoryWarranty(pinVin);
				if (history != null)
				{
					warrantyDate = history.getWarrantyDate();
				}
			}
		}
		catch (SystemException e)
		{
			throw new ApplicativeException(e);
		}
		return warrantyDate;
	}

	/**
	 * Calculate the performance label: example: Every 100 000km or Every 1000h.
	 */
	/**
	 * 
	 * Method for AGCE to get Title as per the configuration.
	 * New Overload method for getting the Title.
	 * 
	 * @author mshaikh4
	 * @param intervalDto intervalDto
	 * @param intervalIds2 intervalIds2
	 * @return String
	 */
	public static String getTitle(MpIntervalDto intervalDto, Map<String, String> intervalIds2, boolean isIveco, String unit) {
		StringBuilder result = new StringBuilder();

		// Setting Order based on Customer
		int order = isIveco ? ORDER_BY_KM_MON_HRS : ORDER_BY_HRS_MON_KM;

		// ORDERING OF THE LABEL CAN BE CONFIURED AS PER NEED.
		String startResult = getFrequencyLabel(intervalDto.getStartValueKm(), intervalDto.getStartValueMonth(), intervalDto.getStartValueHour(), intervalIds2, order, isIveco, unit);
		String frequencyResult = getFrequencyLabel(intervalDto.getAfterValueKm(), intervalDto.getAfterValueMonth(), intervalDto.getAfterValueHour(), intervalIds2, order, isIveco, unit);

		if (!startResult.isEmpty())
		{
			result.append(intervalIds2.get(Constantes.MP_ID_AT));
			result.append(SPACE);
			result.append(startResult);
			if (!frequencyResult.isEmpty())
			{
				result.append(SPACE);
				result.append(intervalIds2.get(Constantes.MP_ID_AND_THEN));
				result.append(SPACE);
				result.append(intervalIds2.get(Constantes.MP_ID_EVERY));
				result.append(SPACE);
				result.append(frequencyResult);
			}
		}
		else if (!frequencyResult.isEmpty())
		{
			result.append(intervalIds2.get(Constantes.MP_ID_EVERY));
			result.append(SPACE);
			result.append(frequencyResult);
		}
		return result.toString();
	}

	/**
	 * 
	 * Generic method to create the title with value along with Postfix and Prefix expressions.
	 * 
	 * @author mshaikh4
	 * @param prefix String
	 * @param postfix String
	 * @param val Long
	 * @param unit String
	 * @param str StringBuilder
	 * @return StringBuilder
	 */
	public static StringBuilder getValueWithPreAndPostfix(String prefix, String postfix, Long val, String unit, StringBuilder str) {

		if (str == null)
		{
			str = new StringBuilder();
		}

		if (val != null && val > 0)
		{
			if (prefix != null && !prefix.isEmpty() && !str.toString().trim().isEmpty())
			{
				str.append(prefix).append(SPACE);
			}

			str.append(val).append(SPACE).append(unit).append(SPACE);

			if (postfix != null && !postfix.isEmpty())
			{
				str.append(postfix).append(SPACE);
			}
		}

		return str;
	}

	/**
	 * Method to create frequency label with the ordering we need.
	 * 
	 * @author mshaikh4
	 * @param valueKm valueKm
	 * @param valueMonth valueMonth
	 * @param valueHour valueHour
	 * @param intervalIds intervalIds
	 * @param order order
	 * @return String
	 */
	public static String getFrequencyLabel(Long valueKm, Long valueMonth, Long valueHour, Map<String, String> intervalIds, int order, boolean isIveco, String unitKey) {

		StringBuilder str = new StringBuilder();

		// ORDER 1 => KM => MONTHS => HOURS
		if (order == ORDER_BY_KM_MON_HRS)
		{
			getValueWithPreAndPostfix(null, null, valueKm, KM, str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueMonth, intervalIds.get(Constantes.MP_ID_MONTHS), str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueHour, intervalIds.get(Constantes.MP_ID_HOURS), str);
		}
		// ORDER 2 => MONTHS => HOURS => KM
		else if (order == ORDER_BY_MON_HRS_KM)
		{
			getValueWithPreAndPostfix(null, null, valueMonth, intervalIds.get(Constantes.MP_ID_MONTHS), str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueHour, intervalIds.get(Constantes.MP_ID_HOURS), str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueKm, KM, str);

		}
		// ORDER 3 => HOURS => MONTHS => KM
		else if (order == ORDER_BY_HRS_MON_KM)
		{
			String unit = "";
			if (!isIveco)
			{
				// Cas de l'utilisation de UNIT

				unit = intervalIds.get(unitKey);

			}
			else
			{
				unit = KM;
			}

			getValueWithPreAndPostfix(null, null, valueHour, intervalIds.get(Constantes.MP_ID_HOURS), str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueMonth, intervalIds.get(Constantes.MP_ID_MONTHS), str);
			getValueWithPreAndPostfix(intervalIds.get(Constantes.MP_ID_OR), null, valueKm, unit, str);

		}
		// Can create more ordering types and use above logic to create frequency string on the fly with less code.

		return str.toString().trim();

	}

	/**
	 * Convert days to months for connected vehicles
	 * Recursive method to calculate number of months
	 * 
	 * @param days number of days to convert
	 * @param rangeMin first range min (0)
	 * @param rangeMax first range max (44)
	 * @param iter number of iteration (0 for the first call)
	 * @return number of month
	 */
	public static int convertDaysToMonthsForConnectedVehicles(long days, int rangeMin, int rangeMax, int iter) {

		// For connected vehicule, there are hours in MP_MONTH unit, so change it in Month
		// If 0 < nbJours < 44 : nbMois = 1
		// If 45 < nbJours < 74 : nbMois = 2..
		Range<Integer> myRange = Range.between(rangeMin, rangeMax);
		if (myRange.contains((int) days))
		{
			return iter;
		}
		else
		{
			int newRangeMin = Integer.sum(rangeMax, 1);
			// Adds 29 days for next range max
			int newRangeMax = Integer.sum(newRangeMin, 29);
			int newIter = Integer.sum(iter, 1);
			return convertDaysToMonthsForConnectedVehicles(days, newRangeMin, newRangeMax, newIter);
		}

	}

	/**
	 * Get the start date and end date from each contract.
	 * 
	 * @param contractDto the contract object.
	 * @return The couples ends date/start date
	 */
	public static Map<LocalDate, LocalDate> getListStartAndEndDateAllContracts(MpContractDto contractDto) {

		Map<LocalDate, LocalDate> result = new HashMap<>();
		Set<String> contractNbList = new HashSet<>();

		contractDto.getAllContracts().stream().forEach(c -> {
			contractNbList.add(c.getContractNumber());
		});

		contractNbList.stream().forEach(c -> {
			List<MpContractVehicleDto> filteredContractList = contractDto.getAllContracts().stream().filter(contract -> contract.getContractNumber().equals(c)).collect(Collectors.toList());

			// get the maximum End Date and min Start Date of each contract and transform to LocalDate
			LocalDate maxEndDate;
			LocalDate minStartDate;

			Date maxEndDateTemp = filteredContractList.stream().map(MpContractVehicleDto::getContractEndDate).max(Date::compareTo).get();
			Date minStartDateTemp = filteredContractList.stream().map(MpContractVehicleDto::getContractStartDate).min(Date::compareTo).get();

			// Issue with tranforming Date into LocalDate
			if (maxEndDateTemp instanceof java.sql.Date)
			{
				maxEndDate = ((java.sql.Date) maxEndDateTemp).toLocalDate();
			}
			else
			{
				maxEndDate = maxEndDateTemp.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			}

			if (minStartDateTemp instanceof java.sql.Date)
			{
				minStartDate = ((java.sql.Date) minStartDateTemp).toLocalDate();
			}
			else
			{
				minStartDate = minStartDateTemp.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			}

			result.put(minStartDate, maxEndDate);
		});

		return result;
	}

}
