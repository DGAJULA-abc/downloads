/**
 * 
 */
package capgemini.cnh.maintenanceservice.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.UnitsBusiness;
import capgemini.cnh.ice.business.UnitsMapByCountryBusiness;
import capgemini.cnh.ice.dto.UnitsDto;
import capgemini.cnh.ice.dto.UnitsMapByCountryDto;

/**
 * @author mshaikh4
 *
 */
public class UnitsUtil {

	private static final String KEY_CONSLIT = "L";

	/** Logger element. */
	private static TIDBLogger logger = TIDBLogger.getLogger(UnitsUtil.class);

	/**
	 * 
	 */
	UnitsUtil() {
		super();
	}

	/**
	 * 
	 */
	private static Date initDate;

	/**
	 * 
	 */
	private static boolean isInitialized = false;

	/**
	 * 
	 */
	private static Map<String, Map<String, UnitsDto>> unitsMap = new HashMap<>();

	/**
	 * 
	 */
	private static Set<String> siunitSet = new HashSet<>();

	/**
	 * 
	 */
	private static Set<String> usUnitSet = new HashSet<>();

	/**
	 * 
	 */
	private static Map<String, UnitsMapByCountryDto> unitsByCountry = new HashMap<>();

	/**
	 * Decimal Formatter.
	 */
	private static DecimalFormat df = new DecimalFormat("0.00", DecimalFormatSymbols.getInstance());

	/**
	 * Get the converted Num value
	 * 
	 * @param unit
	 * @param num
	 * @param countryName
	 * @return
	 */
	public static double getConvertedNumInString(String unit, double num, String countryName) {
		double rtn = 0.00;
		try
		{
			if (!isInitialized || !isSameDay(initDate, new Date()))
			{
				getAllData();
				setInitialized(true);
				setInitDate(new Date());
				rtn = getConvertedNumData(unit, num, countryName);
			}
			else
			{
				/** getAllData(); **/ // Uncomment only for testing 
				rtn = getConvertedNumData(unit, num, countryName);
			}
		}
		catch (SystemException e)
		{
			setInitialized(false);
			logger.error(e);
		}

		return rtn;
	}

	/**
	 * 
	 * Get the converted unit value
	 * 
	 * @param unit
	 * @param countryName
	 * @return
	 */
	public static String getConvertedUnitInString(String unit, String countryName) {
		String rtn = "";
		try
		{
			if (!isInitialized || !isSameDay(initDate, new Date()))
			{
				getAllData();
				setInitialized(true);
				setInitDate(new Date());
				rtn = getConvertedUnitData(unit, countryName);
			}
			else
			{
				/** getAllData(); **/ // Uncomment only for testing 
				rtn = getConvertedUnitData(unit, countryName);
			}
		}
		catch (SystemException e)
		{
			setInitialized(false);
			logger.error(e);
		}

		return rtn;
	}

	/**
	 * @param unit
	 * @param num
	 * @param countryName
	 * @param rtn
	 */
	private static double getConvertedNumData(String unit, double num, String countryName) {

		if (!unitsMap.isEmpty() && !unitsByCountry.isEmpty() && unit != null && countryName != null && num > 0 && unitsByCountry.containsKey(countryName.toUpperCase())
				&& (isSiUnit(unit) || isUsUnit(unit)))
		{

			//When both the Units are same.
			if (unit.equalsIgnoreCase(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				return roundAvoid(num, 2);
			}
			// The Passed unit is SIUNIT and the country mapped unit is USUNIT
			else if (isSiUnit(unit) && isUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				double aFactor = unitsMap.get(unit).get(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()).getAfactor();
				return roundAvoid(aFactor * num, 2);
			}
			// The Passed unit is USUNIT and the country mapped unit is SIUNIT
			else if (isSiUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()) && isUsUnit(unit))
			{
				double aFactor = unitsMap.get(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()).get(unit).getAfactor();
				return roundAvoid(num / aFactor, 2);

			}
			// Both the Passed and Country Mapping is USUNIT.
			else if (isUsUnit(unit) && isUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				UnitsDto fromConvUnit = getUnitDtoFromMapForUsUnit(unit);
				UnitsDto toConvUnit = getUnitDtoFromMapForUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit());
				if (fromConvUnit != null && toConvUnit != null && fromConvUnit.getSiSign().equalsIgnoreCase(toConvUnit.getSiSign()))
				{
					return roundAvoid((toConvUnit.getAfactor() / fromConvUnit.getAfactor()) * num, 2);
				}
			}

		}
		return 0.00;
	}

	/**
	 * Get the converted unit value
	 * 
	 * @param unit
	 * @param countryName
	 * @param rtn
	 */
	private static String getConvertedUnitData(String unit, String countryName) {

		if (!unitsMap.isEmpty() && !unitsByCountry.isEmpty() && unit != null && countryName != null && unitsByCountry.containsKey(countryName.toUpperCase())
				&& (isSiUnit(unit) || isUsUnit(unit)))
		{

			//When both the Units are same.
			if (unit.equalsIgnoreCase(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				return unit;
			}
			// The Passed unit is SIUNIT and the country mapped unit is USUNIT
			else if (isSiUnit(unit) && isUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				String unitAfterConv = unitsMap.get(unit).get(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()).getUsSign();
				return unitAfterConv;
			}
			// The Passed unit is USUNIT and the country mapped unit is SIUNIT
			else if (isSiUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()) && isUsUnit(unit))
			{
				String unitAfterConv = unitsMap.get(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()).get(unit).getSiSign();
				return unitAfterConv;

			}
			// Both the Passed and Country Mapping is USUNIT.
			else if (isUsUnit(unit) && isUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit()))
			{
				UnitsDto fromConvUnit = getUnitDtoFromMapForUsUnit(unit);
				UnitsDto toConvUnit = getUnitDtoFromMapForUsUnit(unitsByCountry.get(countryName.toUpperCase()).getConvUnit());
				if (fromConvUnit != null && toConvUnit != null && fromConvUnit.getSiSign().equalsIgnoreCase(toConvUnit.getSiSign()))
				{
					return toConvUnit.getUsSign();
				}
			}

		}
		return "";
	}

	/**
	 * 
	 * @param unit
	 * @return
	 */
	public static UnitsDto getUnitDtoFromMapForUsUnit(String unit) {

		for (Entry<String, Map<String, UnitsDto>> entrySi : unitsMap.entrySet())
		{
			if (entrySi.getValue().keySet().contains(unit))
			{
				return entrySi.getValue().get(unit);
			}
		}

		return null;

	}

	/**
	 * 
	 * @param unit
	 * @return boolean
	 */
	private static boolean isSiUnit(String unit) {
		return siunitSet.contains(unit);
	}

	/**
	 * 
	 * @param unit
	 * @return boolean
	 */
	private static boolean isUsUnit(String unit) {
		return usUnitSet.contains(unit);
	}

	/**
	 * 
	 * @return
	 * @throws SystemException
	 */
	private static void getAllData() throws SystemException {

		UnitsBusiness unitsBusiness = new UnitsBusiness();
		UnitsMapByCountryBusiness unitsByCountryBusiness = new UnitsMapByCountryBusiness();

		List<UnitsDto> unitsList = unitsBusiness.getAllUnits();
		unitsMap.clear();
		siunitSet.clear();
		usUnitSet.clear();
		if (unitsList != null && !unitsList.isEmpty())
		{
			for (UnitsDto unitsDto : unitsList)
			{
				if (unitsDto.getSiSign() != null && unitsMap.containsKey(unitsDto.getSiSign()))
				{
					unitsMap.get(unitsDto.getSiSign()).put(unitsDto.getUsSign(), unitsDto);
					setUnitsSets(unitsDto);
				}
				else
				{
					Map<String, UnitsDto> internalMap = new HashMap<>();
					internalMap.put(unitsDto.getUsSign(), unitsDto);
					unitsMap.put(unitsDto.getSiSign(), internalMap);
					setUnitsSets(unitsDto);
				}
			}
		}

		List<UnitsMapByCountryDto> unitsListByCountry = unitsByCountryBusiness.getAllUnitsMappingByCountry();
		unitsByCountry.clear();

		if (unitsListByCountry != null && !unitsListByCountry.isEmpty())
		{
			for (UnitsMapByCountryDto unitsMapByCountryDto : unitsListByCountry)
			{
				unitsByCountry.put(unitsMapByCountryDto.getCountryCode().toUpperCase(), unitsMapByCountryDto);
			}
		}
	}

	/**
	 * @param unitsDto
	 */
	private static void setUnitsSets(UnitsDto unitsDto) {

		if (unitsDto != null)
		{
			if (unitsDto.getSiSign() != null && !unitsDto.getSiSign().isEmpty())
			{
				siunitSet.add(unitsDto.getSiSign());
			}

			if (unitsDto.getUsSign() != null && !unitsDto.getUsSign().isEmpty())
			{
				usUnitSet.add(unitsDto.getUsSign());
			}

		}

	}

	/**
	 * 
	 * @param date1
	 * @param date2
	 * @return boolean
	 */
	public static boolean isSameDay(Date date1, Date date2) {
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		return fmt.format(date1).equals(fmt.format(date2));
	}

	/**
	 * @return the initDate
	 */
	public static Date getInitDate() {
		return initDate;
	}

	/**
	 * @param initDate the initDate to set
	 */
	private static void setInitDate(Date initDate) {
		UnitsUtil.initDate = initDate;
	}

	/**
	 * @return the isInitialized
	 */
	public static boolean isInitialized() {
		return isInitialized;
	}

	/**
	 * @param isInitialized the isInitialized to set
	 */
	private static void setInitialized(boolean isInitialized) {
		UnitsUtil.isInitialized = isInitialized;
	}

	/**
	 * @return the unitsMap
	 */
	public static Map<String, Map<String, UnitsDto>> getUnitsMap() {
		return unitsMap;
	}

	/**
	 * @return the unitsByCountry
	 */
	public static Map<String, UnitsMapByCountryDto> getUnitsByCountry() {
		return unitsByCountry;
	}

	public static double roundAvoid(double value, int places) {
		double scale = Math.pow(10, places);
		return Math.round(value * scale) / scale;
	}

	/**
	 * Get the converted Num value
	 * 
	 * @param unit
	 * @param num
	 * @return
	 */
	public static double getConvertedNumInStringUK(String unit, double num) {
		double rtn = 0.00;
		try
		{
			if (!isInitialized || !isSameDay(initDate, new Date()))
			{
				getAllData();
				setInitialized(true);
				setInitDate(new Date());
				rtn = getConvertedNumDataUK(unit, num);
			}
			else
			{
				/** getAllData(); **/ // Uncomment only for testing 
				rtn = getConvertedNumDataUK(unit, num);
			}
		}
		catch (SystemException e)
		{
			setInitialized(false);
			logger.error(e);
		}

		return rtn;
	}

	/**
	 * @param unit
	 * @param num
	 * @param rtn
	 */
	private static double getConvertedNumDataUK(String unit, double num) {

		if (!unitsMap.isEmpty() && unit != null && num > 0 && (isSiUnit(unit) || isUsUnit(unit)))
		{

			//When both the Units are same.
			if (unit.equalsIgnoreCase(KEY_CONSLIT))
			{
				return roundAvoid(num, 2);
			}
			// The Passed unit is SIUNIT and the country mapped unit is USUNIT
			else if (isSiUnit(unit) && isUsUnit(KEY_CONSLIT))
			{
				double aFactor = unitsMap.get(unit).get(KEY_CONSLIT).getAfactor();
				return roundAvoid(aFactor * num, 2);
			}
			// The Passed unit is USUNIT and the country mapped unit is SIUNIT
			else if (isSiUnit(KEY_CONSLIT) && isUsUnit(unit))
			{
				double aFactor = unitsMap.get(KEY_CONSLIT).get(unit).getAfactor();
				return roundAvoid(num / aFactor, 2);

			}
			// Both the Passed and Country Mapping is USUNIT.
			else if (isUsUnit(unit) && isUsUnit(KEY_CONSLIT))
			{
				UnitsDto fromConvUnit = getUnitDtoFromMapForUsUnit(unit);
				UnitsDto toConvUnit = getUnitDtoFromMapForUsUnit(KEY_CONSLIT);
				if (fromConvUnit != null && toConvUnit != null && fromConvUnit.getSiSign().equalsIgnoreCase(toConvUnit.getSiSign()))
				{
					return roundAvoid((toConvUnit.getAfactor() / fromConvUnit.getAfactor()) * num, 2);
				}
			}

		}
		return 0.00;
	}

}
