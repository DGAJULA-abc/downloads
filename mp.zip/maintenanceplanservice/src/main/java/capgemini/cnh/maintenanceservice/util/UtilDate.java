package capgemini.cnh.maintenanceservice.util;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import capgemini.cnh.framework.util.TIDBLogger;

/**
 * Date utility class.
 */

public class UtilDate {

	/** Display date format. */
	public static String DISPLAY_FORMAT_DATE = "dd/MM/yyyy HH:mm:ss";

	/** Database date format. */
	public static final String DB_FORMAT_DATE = "yyyy-MM-dd HH:mm:ss";

	/** CV KA import date format. */
	public static String FORMAT_DATE_YYYYMMDD = "yyyy-MM-dd";

	/** Database date format. */
	public static String FORMAT_DATE_DDMMYYYY_DASH = "dd-MM-yyyy";

	/** Display date format. */
	public static String FORMAT_DATE_DDMMYYYY_SLASH = "dd/MM/yyyy";

	/** Database date format. */
	public static String FORMAT_DATE_DDMMYYHHMISS_DASH = "dd-MM-yy-HH-mm-ss";

	/** Database date format. */
	public static String FORMAT_DATE_DDMMHHMISS = "ddMMHHmmss";

	/** Database date format. */
	public static String FORMAT_DATE_YYYYMMDDHHMISS = "yyyyMMddHHmmss";

	/** Database date format. */
	public static String FORMAT_DATE_ACLTIMEDATE = "EEE MMM dd HH:mm:ss yyyy";

	/** Database date format. */
	public static String FORMAT_DATE_DDMMYYYY = "ddMMyyyy";

	/** yyyy-MM-dd'T'HH:mm:ss.SSSZ date format. */
	public static final String FORMAT_DATE_YYYYMMDDTHHMMSSSSSZ = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	/**
	 * Constructor.
	 */
	private UtilDate() {
		// Constructor
	}

	/** Define a logger for this class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(UtilDate.class);

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */

	public static String getDate() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), DISPLAY_FORMAT_DATE);

		return formattedDate;
	}

	/**
	 * Get year.
	 * 
	 * @return current year
	 */
	public static String getYear() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), "yyyy");
		return formattedDate;
	}

	/**
	 * Get a formatted date.
	 * 
	 * @param format to apply
	 * @return date
	 */

	public static String getFormatDate(String format) {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), format);
		return formattedDate;
	}

	/**
	 * Format Date yyyy-MM-dd HH:mm:ss to dd/MM/yyyy HH:mm:ss.
	 * 
	 * @param date to convert
	 * @return - a date DD/MMM/YYYY
	 */
	public static String getDisplayDateFormat(String date) {
		String returnDate = null;
		if (date != null)
		{
			try
			{
				SimpleDateFormat sdf = new SimpleDateFormat(DB_FORMAT_DATE);
				returnDate = dateToString(sdf.parse(date), DISPLAY_FORMAT_DATE);
				if (returnDate != null)
				{
					return returnDate;
				}
			}
			catch (ParseException e)
			{
				logger.error(e.getMessage());
			}
		}
		return returnDate;
	}

	/**
	 * Convert Date to String depending on format.
	 * 
	 * @param date to convert
	 * @param format date format
	 * @return - a date
	 */
	public static String dateToString(Date date, String format) {
		if (date != null)
		{
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			dateFormat.setLenient(false);
			return dateFormat.format(date);
		}
		else
		{
			return null;
		}
	}

	/**
	 * Get the elapsed time between start time and actual time.
	 * 
	 * @param text a text to display before the elapsed time
	 * @param start the start time
	 * @return the elapsed time
	 */
	public static String getElapsedTime(String text, long start) {
		String elapsedString = "******" + text;
		long elapsed = System.currentTimeMillis() - start;
		DateFormat df = new SimpleDateFormat("HH 'hours', mm 'mins,' ss 'seconds'");
		df.setTimeZone(TimeZone.getTimeZone("GMT+0"));
		elapsedString = elapsedString + df.format(new Date(elapsed));
		//System.out.println(elapsedString);

		return elapsedString;
	}

	/**
	 * Get current date.
	 * 
	 * @return format dd/mm/yyyy
	 */
	public static String getCurrentDate() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());
		NumberFormat formatter2 = new DecimalFormat("00");
		NumberFormat formatter4 = new DecimalFormat("0000");
		return formatter2.format(currentDate.get(Calendar.DAY_OF_MONTH)) + "/" + formatter2.format((currentDate.get(Calendar.MONTH) + 1)) + "/" + formatter4.format(currentDate.get(Calendar.YEAR));
	}

	/**
	 * Get current date.
	 * 
	 * @return format "DD/MM/YYYY HH:MM:SS"
	 */
	public static String getCurrentDateTime() {
		DateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return myFormat.format(new Date());
	}

	/**
	 * Get current date.
	 * 
	 * @param format : format
	 * @return format
	 */
	public static String getCurrentDateTime(String format) {
		DateFormat myFormat = new SimpleDateFormat(format);
		return myFormat.format(new Date());
	}

	/**
	 * Convert a String date (dd/mm/yyyy) into Date.
	 * 
	 * @param myDate date to convert
	 * @return Date
	 */
	public static Date stringToDate(String myDate) {
		Date result = null;

		if (myDate != null)
		{
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yy");

			try
			{
				result = df.parse(myDate);
			}
			catch (ParseException e)
			{
				e.printStackTrace();
			}
		}

		return result;
	}

	/**
	 * Convert a String date into Date according to the given format.
	 * 
	 * @param myDate date to convert
	 * @param format format used
	 * @return Date
	 */
	public static Date stringToDate(String myDate, String format) {
		Date result = null;

		if (myDate != null)
		{
			SimpleDateFormat df = new SimpleDateFormat(format);

			try
			{
				result = df.parse(myDate);
			}
			catch (ParseException e)
			{
				e.printStackTrace();
			}
		}

		return result;
	}

	/**
	 * Compare a date to the current date.
	 * 
	 * @param date : the given date
	 * @return True the given date is later than the current date, false otherwise
	 */
	public static boolean compareDateToNow(String date) {
		boolean isDateOk = false;

		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat(capgemini.cnh.common.util.Constants.DB_FORMAT_DATE);

			// Current Date
			Calendar currentDate = Calendar.getInstance();
			Date curDate = sdf.parse(dateToString(currentDate.getTime(), capgemini.cnh.common.util.Constants.DB_FORMAT_DATE));
			//Selected date
			Calendar dateCal = Calendar.getInstance();
			dateCal.setTime(sdf.parse(date));
			Date selectedDate = dateCal.getTime();

			if (selectedDate.equals(curDate) || selectedDate.after(curDate))
			{
				isDateOk = true;
			}
		}
		catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return isDateOk;
	}

	/**
	 * Get yesterday date format YYYY-MM-DD.
	 * 
	 * @return the date of yesterday
	 */
	public static String getYesterdayDateYYYYMMDD() {

		Calendar calLastDate = Calendar.getInstance();
		calLastDate.add(Calendar.DATE, -1);
		Date lastDate = calLastDate.getTime();

		return dateToString(lastDate, FORMAT_DATE_YYYYMMDD);
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateDDMMYYYY_DASH() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_DDMMYYYY_DASH);

		return formattedDate;
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateDDMMYYHHMISS_DASH() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_DDMMYYHHMISS_DASH);

		return formattedDate;
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateDDMMHHMISS() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_DDMMHHMISS);

		return formattedDate;
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateYYYYMMDDHHMISS() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_YYYYMMDDHHMISS);

		return formattedDate;
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateAclTimeDate() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_ACLTIMEDATE);

		return formattedDate;
	}

	/**
	 * Get GMT date in a specific format.
	 * 
	 * @param format : date format
	 * @return the GMT date
	 */
	public static String getGMTDate(String format) {
		long elapsed = System.currentTimeMillis();
		DateFormat df = new SimpleDateFormat(format);
		df.setTimeZone(TimeZone.getTimeZone("GMT+0"));
		return df.format(new Date(elapsed));
	}

	/**
	 * Get a formatted date.
	 * 
	 * @return date
	 */
	public static String getDateDDMMYYYY() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_DDMMYYYY);

		return formattedDate;
	}

	/**
	 * Get a formatted date such as yyyy-MM-dd'T'HH:mm:ss.SSSZ .
	 * 
	 * @return date the formatted date string
	 */
	public static String getDateYYYYMMDDTHHMMSSSSSZ() {
		Calendar currentDate = Calendar.getInstance();
		currentDate.setTimeInMillis(System.currentTimeMillis());

		// Format current date
		String formattedDate = dateToString(new Date(currentDate.getTimeInMillis()), FORMAT_DATE_YYYYMMDDTHHMMSSSSSZ);

		return formattedDate;
	}

	/**
	 * Convert a number of milliseconds into the equivalent amount of minutes.
	 * 
	 * @param timing time in milliseconds to convert.
	 * @return number of minutes in the given timing.
	 */
	public static long minutes(long timing) {
		return TimeUnit.MILLISECONDS.toMinutes(timing);
	}

	/**
	 * Convert a number of milliseconds into the equivalent amount of remaining seconds, after minutes calculation.
	 * 
	 * @param timing time in milliseconds to convert.
	 * @return number of seconds remaining (after minutes calculation) in the given timing.
	 */
	public static long seconds(long timing) {
		return TimeUnit.MILLISECONDS.toSeconds(timing) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(timing));
	}

	/**
	 * Get a formatted date.
	 * 
	 * @param time in miliseconds
	 * @return date
	 */
	public static Date getDateDDMMYYYYFromTime(long time) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date(time));
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
}
