package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MonMaintenancePlanDto;

public interface IMonMaintenancePlanAccess {

	public static final String MON_MAINTENANCE_PLAN = "MON_MAINTENANCE_PLAN";
	public static final String MON_VIN = "MON_VIN";
	public static final String MON_DATE = "MON_DATE";
	public static final String MON_UCR_EXT_PLAN_ID = "MON_UCR_EXT_PLAN_ID";
	public static final String MON_UCR_PLAN_ID = "MON_UCR_PLAN_ID";
	public static final String MON_ETIM_EXT_PLAN_ID = "MON_ETIM_EXT_PLAN_ID";
	public static final String MON_ETIM_PLAN_ID = "MON_ETIM_PLAN_ID";

	boolean saveMonMaintenancePlan(MonMaintenancePlanDto mmpDto) throws SystemException;
}
