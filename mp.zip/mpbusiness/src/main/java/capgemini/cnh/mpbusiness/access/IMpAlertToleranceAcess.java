package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpAlertToleranceDto;

/**
 * 
 * @author lestrabo
 *
 */
public interface IMpAlertToleranceAcess {

	/**
	 * Get tolerance km by plan id
	 * 
	 * @param mpAlertToleranceDto : MpAlertToleranceDto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	MpAlertToleranceDto getToleranceByPlanId(Long planId) throws SystemException;

}
