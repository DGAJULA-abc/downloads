package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpAppointmentDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpAppointmentAccess {

	/**
	 * Close the appointment.
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract Long closeAppointment(Long alertGroupId) throws SystemException;

	/**
	 * Create/Move/Cancel the appointment.
	 * 
	 * @param mpAppointment the appointment
	 * @return the updated appointment (date, status ...)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract MpAppointmentDto manageAppointment(MpAppointmentDto mpAppointment) throws SystemException;

	/**
	 * Get the appointment by id.
	 * 
	 * @param id the id of the appointment
	 * @return the appointment
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract MpAppointmentDto getAppointmentById(Long id) throws SystemException;

	/**
	 * Get the appointment by vin,alertGroupId and dealerCde.
	 * 
	 * @param vin the vin of the appointment
	 * @param alertGroupId the alertGroupId of the appointment
	 * @param dealerCde the dealerCde of the appointment
	 * @return the appointment
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract MpAppointmentDto getAppointmentByVinAndAlertGroupIdAndDealerCode(String vin, Long alertGroupId, String dealerCode) throws SystemException;

	/**
	 * Close the appointment.
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract Long updateAppointementToRecall(Long alertGroupId) throws SystemException;

}
