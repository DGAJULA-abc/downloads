package capgemini.cnh.mpbusiness.access;

import java.util.Date;
import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpClaimDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpClaimAccess {

	/**
	 * Name of the table in the database.
	 */
	public static final String TABLE_NAME = "MP_CLAIM";

	/**
	 * Column MPCL_VIN.
	 */
	public static final String COL_VIN = "MPCL_VIN";

	/**
	 * Column MPCL_DATE_MODIF.
	 */
	public static final String COL_DATE_MODIF = "MPCL_DATE_MODIF";

	/**
	 * Column MPCL_DATE_MODIF.
	 */
	public static final String COL_FAILURE_DATE = "MPCL_FAILURE_DATE";

	/**
	 * Column MPCL_DATE.
	 */
	public static final String COL_DATE = "MPCL_DATE";

	/**
	 * Column MPCL_ID.
	 */
	public static final String COL_ID = "MPCL_ID";

	/**
	 * Column MPCL_XML.
	 */
	public static final String COL_XML = "MPCL_XML";

	/**
	 * Column MPCL_SAP_XML.
	 */
	public static final String COL_SAP_XML = "MPCL_SAP_XML";

	/**
	 * Column MPCL_ORIGINAL_SAP_XML.
	 */
	public static final String COL_ORIGINAL_SAP_XML = "MPCL_ORIGINAL_SAP_XML";

	/**
	 * Column MPCL_KM.
	 */
	public static final String COL_KM = "MPCL_KM";

	/**
	 * Column MPCL_HOUR.
	 */
	public static final String COL_HOUR = "MPCL_HOUR";

	/**
	 * Column MPCL_HAS_CONTRACT.
	 */
	public static final String COL_HAS_CONTRACT = "MPCL_HAS_CONTRACT";

	/**
	 * Column MPCL_PDF_PATH.
	 */
	public static final String COL_PDF_PATH = "MPCL_PDF_PATH";

	/**
	 * Column MPCL_PDF_PARTS.
	 */
	public static final String COL_PDF_PARTS = "MPCL_PDF_PARTS";

	/**
	 * Column MPCL_PDF_SERVICE.
	 */
	public static final String COL_PDF_SERVICE = "MPCL_PDF_SERVICE";

	/**
	 * Column MPCL_CERTIFIED_PARTS.
	 */
	public static final String COL_CERTIFIED_PARTS = "MPCL_CERTIFIED_PARTS";

	/**
	 * Insert a claim in the database.
	 * 
	 * @param pClaim
	 *            the claim to insert for a selected VIN
	 * 
	 * @return the request result (true on success, false on error)
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean create(MpClaimDto pClaim) throws SystemException;

	/**
	 * Get list of claims in database for a VIN.
	 * 
	 * @param vinList : selected VIN
	 * @return a list of claims
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpClaimDto> getClaimForVin(List<String> vinList) throws SystemException;

	/**
	 * Get a claim in database for an Id.
	 * 
	 * @param id : selected id
	 * @return a claim
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public abstract MpClaimDto getClaimForId(String id) throws SystemException;

	/**
	 * Update the creation time date in a new field.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public abstract boolean updateDateClaim(String id, String dateEdit) throws SystemException;

	/**
	 * update the XML content in database.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @param XMLFile the content of the XML
	 * @param XMLSapFile the content of the XML sap
	 * @param originalXMLSapFile the content of the original XML sap
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public abstract boolean updateXMLClaim(String id, String dateEdit, String XMLFile, String XMLSapFile, String originalXMLSapFile) throws SystemException;

	/**
	 * Get the max of Id in the MP_CLAIM table.
	 * 
	 * @return the max Id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract String getMaxClaimId() throws SystemException;

	public abstract List<MpClaimDto> getClaimToExport() throws SystemException;

	/**
	 * update PDF_PATH content in database.
	 * 
	 * @param id to update
	 */
	boolean updatePDFPath(String id, String PdfPath) throws SystemException;

	/**
	 * Retrieves the claims for the CSV export which is part of the maintenance export.
	 * 
	 * @param lastExportDate: Date of the last export from which to retrieve the claims.
	 * @return The list of the claims to write in a CSV file
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract List<MpClaimDto> getClaimsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException;

}
