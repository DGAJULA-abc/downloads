package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractConfigurationDto;

/**
 * Access to the table MP_CONTRACT_CONFIGURATION.
 * 
 * @author mmartel
 */
public interface IMpContractConfigurationAccess {

	/**
	 * Get the list of configuration linked to a group.
	 * 
	 * @param group of configuration
	 * @return a list of configuration
	 * @throws SystemException system exception
	 */
	public List<MpContractConfigurationDto> getMpContractConfiguration(String group) throws SystemException;
}
