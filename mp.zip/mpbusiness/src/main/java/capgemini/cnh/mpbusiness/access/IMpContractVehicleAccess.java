package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;

/**
 * Access to the table MP_CONTRACT_VEHICLE.
 * 
 * @author mmartel
 */
public interface IMpContractVehicleAccess {

	/**
	 * Get all the Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the list of plan
	 * @throws SystemException system exception
	 */
	public abstract List<MpContractVehicleDto> getAllMpContracts(List<String> lstPinVin) throws SystemException;

	/**
	 * Get the the applicable Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public abstract MpContractVehicleDto getMpActiveContract(String vin) throws SystemException;

	/**
	 * Get the expired Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public abstract MpContractVehicleDto getExpiredMpContract(String vin) throws SystemException;
}
