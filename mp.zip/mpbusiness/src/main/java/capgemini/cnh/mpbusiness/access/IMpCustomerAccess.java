package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpCustomerAccess {

	/**
	 * get list of urgent maintenances.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpCustomerDto> getCustomersFromMpCustomers(String dealerCode, String brand) throws SystemException;

}
