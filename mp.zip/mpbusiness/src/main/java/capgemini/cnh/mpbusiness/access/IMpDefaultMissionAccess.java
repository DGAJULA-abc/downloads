package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpDefaultMissionDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpDefaultMissionAccess {

	/**
	 * Get the mission for an applicability.
	 * 
	 * @param dtoIceContext : context (series, model, tt)
	 * @param level : series, model or tt level
	 * @return a mission dto
	 * @throws SystemException system exception
	 */

	public abstract MpDefaultMissionDto getMpMissionForApp(IceContextDto dtoIceContext, String level) throws SystemException;

}
