package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;

/**
 * Access to the view MP_FLEX_CONTRACT_WK.
 * 
 * @author cblois
 */
public interface IMpFlexContractAccess {

	/**
	 * Get the the applicable Mp flexible contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public abstract MpContractVehicleDto getMpActiveFlexContract(String vin) throws SystemException;

	/**
	 * Return true if dealer has contract valid false if doesn't have.
	 * 
	 * @param dealerCode : dealer code
	 * @param brandIceCode : brand Ice Code
	 * @return true or false
	 * @throws SystemException system exception
	 */
	public abstract boolean hasDealerActiveContract(String dealerCode, String brandIceCode) throws SystemException;
}
