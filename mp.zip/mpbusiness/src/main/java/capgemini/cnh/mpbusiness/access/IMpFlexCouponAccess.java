package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpFlexCouponAccess {

	/**
	 * get list of potential flexible coupons.
	 * 
	 * @return get list of potential flexible coupons.
	 * @throws SystemException system exception
	 */
	public abstract List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException;

	/**
	 * Get the flexible coupon.
	 * 
	 * @param coupon the coupon
	 * @return the coupon or null
	 * @throws SystemException system exception
	 */
	public abstract MpFlexCouponDto getFlexibleCoupon(String coupon) throws SystemException;
}
