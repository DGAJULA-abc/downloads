/**
 * 2:37:52 PM
 * IMpFlexCustomerSapAccess.java
 * 
 */
package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexCustomerSapDto;

/**
 * @author mshaikh4
 *
 */
public interface IMpFlexCustomerSapAccess {

	/**
	 * Get Customer Details from MP FLEX based on VIN.
	 * 
	 * @param vin vin
	 * @return MpFlexCustomerSapDto
	 * @throws SystemException SystemException
	 */
	public abstract MpFlexCustomerSapDto selectCustomerFromVinDetail(String vin) throws SystemException;

}
