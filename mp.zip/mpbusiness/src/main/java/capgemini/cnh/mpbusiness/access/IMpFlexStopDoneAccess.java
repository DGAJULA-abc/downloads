package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexStopDoneDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpFlexStopDoneAccess {

	/**
	 * add Mp next stop in database.
	 * 
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addFlexStopDone(MpFlexStopDoneDto nextStops) throws SystemException;

	/**
	 * delete Mp next stop in database.
	 * 
	 * @param nextStops : to be deleted
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteFlexStopDone(MpFlexStopDoneDto nextStops) throws SystemException;

}
