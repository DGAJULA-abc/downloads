package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpHistoryConfigDto;

/**
 * Access to the table MP_HISTORY_CONFIG.
 * 
 * @author dbabillo
 */
public interface IMpHistoryConfigAccess {

	/**
	 * Column MPHC_VIN.
	 */
	public static final String COL_VIN = "MPHC_VIN";

	/**
	 * Column MPHC_VALUE_ID.
	 */
	public static final String COL_VALUE = "MPHC_VALUE_ID";

	/**
	 * Column MPHC_ITEM_ID.
	 */
	public static final String COL_ITEM = "MPHC_ITEM_ID";

	/**
	 * Insert an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean create(MpHistoryConfigDto pDto) throws SystemException;

	/**
	 * Select an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to select
	 * @param pLanguageId the language identifier of request information
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract MpHistoryConfigDto read(MpHistoryConfigDto pDto, String pLanguageId) throws SystemException;

	/**
	 * Select a list of interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to select
	 * @param pLanguageId the language identifier of request information
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract List<MpHistoryConfigDto> readList(MpHistoryConfigDto pDto, String pLanguageId, List<String> lstPinVin) throws SystemException;

	/**
	 * Update an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean update(MpHistoryConfigDto pDto) throws SystemException;

	/**
	 * Delete an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean delete(MpHistoryConfigDto pDto) throws SystemException;
}
