package capgemini.cnh.mpbusiness.access;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;

/**
 * Access to the table MP_HISTORY_INTERVAL.
 * 
 * @author dbabillo
 */
public interface IMpHistoryIntervalAccess {

	/**
	 * Name of the table in the database.
	 */
	public static final String TABLE_NAME = "MP_HISTORY_INTERVAL";

	/**
	 * Column MPH_ID.
	 */
	public static final String COL_ID = "MPH_ID";

	/**
	 * Column MPH_VIN.
	 */
	public static final String COL_VIN = "MPH_VIN";

	/**
	 * Column MPH_INT_CODE.
	 */
	public static final String COL_INTERVAL_CODE = "MPH_INTERVAL_CODE";

	/**
	 * Column MPH_INT_ID.
	 */
	public static final String COL_INTERVAL_ID = "MPH_INT_ID";

	/**
	 * Column MPH_UPDATE_DATE.
	 */
	public static final String COL_UPDATE = "MPH_UPDATE_DATE";

	/**
	 * Column MPH_EXACT_VALUE_KM.
	 */
	public static final String COL_KM = "MPH_EXACT_VALUE_KM";

	/**
	 * Column MPH_EXACT_VALUE_MONTH.
	 */
	public static final String COL_MONTH = "MPH_EXACT_VALUE_MONTH";

	/**
	 * Column MPH_EXACT_VALUE_HOUR.
	 */
	public static final String COL_HOUR = "MPH_EXACT_VALUE_HOUR";

	/**
	 * Column MPH_VALUE_KM.
	 */
	public static final String COL_INT_KM = "MPH_INT_VALUE_KM";

	/**
	 * Column MPH_VALUE_MONTH.
	 */
	public static final String COL_INT_MONTH = "MPH_INT_VALUE_MONTH";

	/**
	 * Column MPH_VALUE_HOUR.
	 */
	public static final String COL_INT_HOUR = "MPH_INT_VALUE_HOUR";

	/**
	 * Column MPH_PLAN_EXT_ID.
	 */
	public static final String COL_PLAN_EXT_ID = "MPH_PLAN_EXT_ID";

	/**
	 * Column MPH_ORIGIN.
	 */
	public static final String COL_ORIGIN = "MPH_ORIGIN";
	/**
	 * Column MPH_OLD_PLAN.
	 */
	public static final String COL_OLD_PLAN = "MPH_OLD_PLAN";

	/**
	 * Column MPH_CLAIM_ID.
	 */
	public static final String COL_CLAIM_ID = "MPH_CLAIM_ID";

	/**
	 * Column MPH_VIN.
	 */
	public static final String COL_DELETED = "MPH_DELETED";

	/**
	 * Column MP_FAILURE_DATE.
	 */
	public static final String COL_FAILURE_DATE = "MP_FAILURE_DATE";

	/**
	 * Column MPH_STRONG_ID.
	 */
	public static final String COL_STRONG_ID = "MPH_STRONG_ID";

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	/**
	 * Hsql Date format.
	 */
	public static final String HSQL_DATE_FORMAT = "%d/%m/%Y";

	/**
	 * Operator Code.
	 */
	public static final String COL_OPERATOR_TYPE = "MPH_OPERATOR_TYPE";

	/**
	 * Operation JSON.
	 */
	public static final String COL_OPERATION_JSON = "MPH_OPERATION_JSON";

	/**
	 * MPH_COMMENT.
	 */
	public static final String COL_COMMENT = "MPH_COMMENT";

	/**
	 * Insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto the interval history to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract boolean create(MpHistoryIntervalDto pDto) throws SystemException;

	/**
	 * Select an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto the interval history to select
	 * @param filterOrigin : filter origin
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract MpHistoryIntervalDto read(MpHistoryIntervalDto pDto, Integer filterOrigin) throws SystemException;

	/**
	 * Select a list of interactive maintenance plan interval history in the
	 * database.
	 * 
	 * @param pDto the interval history to select
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract List<MpHistoryIntervalDto> readList(MpHistoryIntervalDto pDto) throws SystemException;

	/**
	 * Select a list of interactive maintenance plan interval history in the
	 * database for a plan and an an origin SAP/eTIM.
	 * 
	 * @param vin the vin
	 * @param filterOrigin the filterOrigin
	 * @param dateFrom the date of history beginning
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> readListFromDateByOrigin(List<String> lstPinVin, Integer filterOrigin, long dateFrom)
			throws SystemException;

	/**
	 * Update an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto the interval history to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract boolean update(MpHistoryIntervalDto pDto) throws SystemException;

	/**
	 * Delete an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto the interval history to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract boolean delete(MpHistoryIntervalDto pDto) throws SystemException;

	/**
	 * Delete an record id in the maintenance plan interval history in the database.
	 * 
	 * @param id the record id to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public boolean delete(String id) throws SystemException;

	/**
	 * Set the status deleted for a record id in the maintenance plan interval
	 * history in the database.
	 * 
	 * @param id the record id to delete
	 * @param deleted 1 to delete otherwise to not delete
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public boolean updateDeleted(String id, int deleted) throws SystemException;

	/**
	 * Select a list of interactive maintenance plan interval history without claim
	 * in the database for a vin.
	 * 
	 * @param vin the vin
	 * @param currentExtPlan the currentExtPlan
	 * @param previousExtPlan the previousExtPlan
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract List<MpHistoryIntervalDto> readListWithoutClaim(String vin) throws SystemException;

	/**
	 * Select the VIN without sap claim.
	 * 
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract List<MpHistoryIntervalDto> getVinWithoutSapClaim() throws SystemException;

	/**
	 * udpate the hour for SAP history using eTim hour.
	 * 
	 * @param sapDto the SAP interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract boolean updateHourHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch)
			throws SystemException;

	/**
	 * udpate the km for SAP history using eTim hour.
	 * 
	 * @param sapDto the SAP interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException cannot execute query or access to database
	 */
	public abstract boolean updateKmHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch)
			throws SystemException;

	/**
	 * Return the complete list of history for a VIN and origin.
	 * 
	 * @param pinVin The PIN or VIN
	 * @param origin the origin of the history: - 0 --> TIDB - 1 --> SAP - 2 --> UCR
	 * 
	 * @return the complete list of UCR history for a VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpHistoryIntervalDto> getHistoryByVinAndOrigin(String pinVin, Integer origin)
			throws SystemException;

	/**
	 * Update the failure date of a claim.
	 * 
	 * @param idToUpdate claim id
	 * @param timestampFailure failure date in milliseconds
	 * @param vin VIN
	 */
	public abstract void updateFailureDateForClaim(String idToUpdate, long timestampFailure, String vin)
			throws SystemException;

	/**
	 * Get the maxEngineHour from a list of intervals for the last month of each interval
	 * 
	 * @param pDto
	 * @return
	 * @throws SystemException
	 */
	public abstract MpHistoryIntervalDto getMaxEngineHour(MpHistoryIntervalDto pDto) throws SystemException;

	Optional<Long> fetchLatestHoursValue(MpHistoryIntervalDto sapDto) throws SystemException;

	Optional<Long> fetchLastRecordHoursValue(MpHistoryIntervalDto sapDto) throws SystemException;

	boolean executeUpdateHoursHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException;

	/**
	 * Retrieves the coupons for the CSV export which is part of the maintenance export.
	 * 
	 * @param lastExportDate: Date of the last export from which to retrieve the coupons.
	 * @return The list of the coupons to write in a CSV file
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract List<MpHistoryIntervalDto> getCouponsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException;
}
