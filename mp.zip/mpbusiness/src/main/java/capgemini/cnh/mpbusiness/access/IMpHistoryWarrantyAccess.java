package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;

/**
 * Access to the table MP_HISTORY_WARRANTY.
 * 
 * @author dbabillo
 */
public interface IMpHistoryWarrantyAccess {

	/**
	 * Name of the table in the database.
	 */
	public static final String TABLE_NAME = "MP_HISTORY_WARRANTY";

	/**
	 * Column MPHW_VIN.
	 */
	public static final String COL_VIN = "MPHW_VIN";

	/**
	 * Column MPHW_WARRANTY_DATE.
	 */
	public static final String COL_WARRANTY_DATE = "MPHW_WARRANTY_DATE";

	/**
	 * Column MPHW_MILEAGE.
	 */
	public static final String COL_MILEAGE = "MPHW_MILEAGE";

	/**
	 * Column MPHW_HOUR.
	 */
	public static final String COL_HOUR = "MPHW_HOUR";

	/**
	 * Column MPHW_MILEAGE.
	 */
	public static final String COL_DATE = "MPHW_DATE";

	/**
	 * Column MPHW_USAGE.
	 */
	public static final String COL_USAGE = "MPHW_USAGE";

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	/**
	 * Hsql Date format.
	 */
	public static final String HSQL_DATE_FORMAT = "%d/%m/%Y";

	/**
	 * Insert an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean create(MpHistoryWarrantyDto pDto) throws SystemException;

	/**
	 * Select an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to select
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract MpHistoryWarrantyDto read(MpHistoryWarrantyDto pDto) throws SystemException;

	/**
	 * Update an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean update(MpHistoryWarrantyDto pDto) throws SystemException;

	/**
	 * Delete an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public abstract boolean delete(MpHistoryWarrantyDto pDto) throws SystemException;
}
