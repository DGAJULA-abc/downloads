package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpIntervalAccess {

	/**
	 * Get the intervals list by plan.
	 * 
	 * @param planId for filter
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance * @return a list of intervals
	 * @param isIveco : true if is IVECO customer
	 * @return list of interval
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpIntervalDto> getMaintenanceIntervals(Long planId, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException;

	/**
	 * Get the list of intervals for a maintenance plan and a list of coupons.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param couponsList : a list of coupons
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public abstract List<MpIntervalDto> getMaintenanceIntervalsByCoupons(Long planId, String[] couponsList, String defaultLanguage, String famIceCode) throws SystemException;

	/**
	 * Get the intervals list by plan.
	 * 
	 * @param planId for filter
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance * @return a list of intervals
	 * @return list of interval
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpIntervalDto> getMaintenanceIntervalsWithoutOperation(Long planId, String defaultLanguage, String famIceCode) throws SystemException;

	/**
	 * Get a coupon name giving the sub group name.
	 * 
	 * @param intervalCode : interval code name
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the coupon
	 * @throws SystemException system exception
	 */
	public abstract MpIntervalDto getCouponName(String intervalCode, String defaultLanguage, String famIceCode) throws SystemException;

	/**
	 * Get the list of intervals for a maintenance plan from interval id.
	 * 
	 * @param intervalId :interval id.
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsFromIntervalId(Long intervalId, String defaultLanguage, String famIceCode) throws SystemException;

	/**
	 * Get the interval for a maintenance plan and an interval.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param intervalId : interval identifier
	 * @return interval for a maintenance plan and interval identifier
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract MpIntervalDto getMaintenanceInterval(String planId, String intervalId) throws SystemException;

	/**
	 * Get value of coupon code for tolerance for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @return value of coupon code for tolerance
	 * @throws SystemException system exception
	 */
	public abstract MpIntervalDto getCouponTolerance(String planId) throws SystemException;

	/**
	 * Get all the coupons with the description of the coupons by language.
	 * 
	 * @param lang the language
	 * @param famGroupIceCode family and group icecode concatenated.
	 * @return the list of coupons.
	 */
	public List<MpIntervalDto> getAllCouponsByLang(String lang, String famGroupIceCode) throws SystemException;
}
