package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpKitCompositionDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpKitCompositionAccess {

	/**
	 * Get the List of operations by plan and intervals.
	 * 
	 * @param selectedKitId to filter
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public abstract List<MpKitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException;

}
