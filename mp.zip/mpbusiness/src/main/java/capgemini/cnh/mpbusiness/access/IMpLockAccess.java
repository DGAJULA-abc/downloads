package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpLockDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpLockAccess {
	/**
	 * Name of the table in the database.
	 */
	public static final String TABLE_NAME = "MP_LOCK";
	
	/**
	 * Column VIN.
	 */
	public static final String COL_VIN = "VIN";

	/**
	 * Column CREATION_DATE.
	 */
	public static final String COL_DATE = "CREATION_DATE";
	
	/**
	 * Add MP lock in database.
	 * 
	 * @param vin : a vin and a the current date to be inserted
	 * @return true if row inserted
	 * @throws SystemException system exception
	 */
	public abstract boolean addMpLock(String vin) throws SystemException;

	/**
	 * Remove MP lock in database.
	 * 
	 * @param vin : a vin and a the current date to be removed
	 * @return true if row removed
	 * @throws SystemException system exception
	 */
	public abstract boolean removeMpLock(String vin) throws SystemException;

}
