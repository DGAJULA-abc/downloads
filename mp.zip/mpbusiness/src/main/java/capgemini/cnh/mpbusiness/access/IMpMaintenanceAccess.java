package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpMaintenanceDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpMaintenanceAccess {

	/**
	 * get list of next maintenances with filters
	 * 
	 * @param dealerCode
	 * @param brandIceCode
	 * @param date
	 * @param customerCode
	 * @param mpCallStatusValue
	 * @param connectedType
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getUrgentMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue, String connectedType)
			throws SystemException;

	/**
	 * get list of urgent maintenances for a customer.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCode(String dealerCode, String brandIceCode, String date, String customerCode) throws SystemException;

	/**
	 * get list of urgent maintenances for all customers.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomers(String dealerCode, String brandIceCode, String date) throws SystemException;

	/**
	 * get list of next maintenances.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getNextMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String connectedType) throws SystemException;

	/**
	 * get list of next maintenances by customer and/or call status.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCodeAndCallStatus(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue)
			throws SystemException;

	/**
	 * get list of next maintenances for all customer and call status.
	 * 
	 * @return get list of urgent maintenances.
	 * @throws SystemException system exception
	 */
	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomersAndCallStatus(String dealerCode, String brandIceCode, String date, String mpCallStatusValue)
			throws SystemException;

	/**
	 * .
	 * 
	 * @return boolean .
	 * @throws SystemException system exception
	 */
	public boolean isExistingPlanId(Long planId) throws SystemException;

}
