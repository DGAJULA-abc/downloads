package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;

/**
 * @author bmilcend
 */
public interface IMpNextStopAccess {

	/**
	 * add Mp next stop flexible in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStopFlex(MpNextStopDto nextStops) throws SystemException;

	/**
	 * update Mp next stop flexible in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopFlex(MpNextStopDto nextStops) throws SystemException;

	/**
	 * update Mp next stop flexible in database for alert without mileage.
	 *
	 * @param vin       : vin
	 * @param currentKm : currentKm
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopFlexAlertNoValue(String vin, Long currentKm) throws SystemException;

	/**
	 * add Mp next stop in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public abstract Long addNextStop(MpNextStopDto nextStops) throws SystemException;

	/**
	 * delete Mp next stop flexible in database for one vin.
	 *
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public abstract Long deleteNextStopFlexible(String vin) throws SystemException;

	/**
	 * delete Mp next stop in database for one vin.
	 *
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public abstract Long deleteNextStop(List<String> vin) throws SystemException;

	/**
	 * Get next flexible stop not done.
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopDto> getNextFlexibleStopNotDone(String vin) throws SystemException;

	/**
	 * Get next stop .
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopDto> getNextStops(List<String> lstPinVin) throws SystemException;

	/**
	 * Get next stop .
	 *
	 * @param vin    : vin to find
	 * @param coupon : coupon code to find
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public abstract MpNextStopDto getNextStop(String vin, String coupon) throws SystemException;

	/**
	 * Get flexible next stop.
	 *
	 * @param vin       : vin to find
	 * @param coupon    : coupon code to find
	 * @param fromCroom : 1 external 0 internal
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public abstract MpNextStopDto getNextStopFlexible(String vin, String coupon, Integer fromCroom) throws SystemException;

	/**
	 * Get all next flexible stop .
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopDto> getAllNextStopFlexibles(String vin) throws SystemException;

	/**
	 * Check if plan changed .
	 *
	 * @param vin    : vin to find
	 * @param planId : planId to find
	 * @return true if plan change
	 * @throws SystemException SystemException
	 */
	public abstract boolean checkPlanChange(List<String> vin, Long planId) throws SystemException;

	/**
	 * Delete flex coupon in from external alert .
	 *
	 * @param dto : dto to delete
	 * @return value different from 0 if deleted
	 * @throws SystemException SystemException
	 */
	public Long deleteCouponExternalAlert(MpNextStopDto dto) throws SystemException;

	public abstract void setNextStopComparison(String vin, Integer comparisonResult, String edsNextStopJson, String etimNextStopJson) throws SystemException;
}
