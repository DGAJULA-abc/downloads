package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * 
 * @author bmilcend
 *
 */
public interface IMpNextStopAlertAccess {

	/**
	 * 
	 * Get the list of VIN-COUPON in alerts.
	 * 
	 * @param alertType: the alertType
	 * @param isFlexibleCoupons: true if we want to get flexible coupons (MP_NEXT_FLEX_STOP_WK table)
	 * @return the list of VIN-COUPON in alerts.
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopAlertDto> getCouponInAlert(MpType alertType, boolean isFlexibleCoupons) throws SystemException;

}
