package capgemini.cnh.mpbusiness.access;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;

/**
 * @author bmilcend
 */
public interface IMpNextStopMinAccess {

	/**
	 * Add minimum next stop .
	 *
	 * @param dto : dto to add
	 * @return value > 0 id add OK
	 * @throws SystemException SystemException
	 */
	public abstract Long addMpNextStopMin(MpNextStopMinDto dto) throws SystemException;

	/**
	 * Update Mp next stop min proposal date.
	 *
	 * @param minNextStop : to be updated
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopMinProposalDate(MpNextStopMinDto minNextStop) throws SystemException;

	/**
	 * Delete min next stop.
	 *
	 * @param vin : vin to find
	 * @return number of deleted row
	 * @throws SystemException SystemException
	 */
	public abstract Long deleteMpNextStopMin(String vin) throws SystemException;

	/**
	 * Get min next stop.
	 *
	 * @param vin : vin to find
	 * @return min next stop
	 * @throws SystemException SystemException
	 */
	public abstract MpNextStopMinDto getMpNextStopMin(List<String> lstPinVin) throws SystemException;

	/**
	 * Get VIN list with updated plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopMinDto> getVinWithUpdatedPlan() throws SystemException;

	/**
	 * Get VIN list with new plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopMinDto> getVinWithNewPlan() throws SystemException;

	/**
	 * Get VIN list with updated performance EDS.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopMinDto> getVinWithUpdatedPerformanceEDS() throws SystemException;

	/**
	 * Get VIN list with coupon in overdue.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public abstract List<MpNextStopMinDto> getVinWithCouponOverdue() throws SystemException;

	/**
	 * Update the proposal date into the table .
	 *
	 * @return
	 * @throws SystemException SystemException
	 */
	public abstract Long updateNextStopProposalDate() throws SystemException;

	/**
	 * Set the flag to 1 for new KM alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public abstract Long setFlagForNewKmAlerts() throws SystemException;

	/**
	 * Set the flag to 1 for new Hour alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public abstract Long setFlagForNewHourAlerts() throws SystemException;

	/**
	 * Set the flag to 1 for new Month alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public abstract Long setFlagForNewMonthAlerts() throws SystemException;

	/**
	 * Get NEXT STOP MIN by vin joined with MP_VEHICLE_KM_HOUR_AV to get the last current mileage.
	 *
	 * @throws SystemException SystemException
	 */
	public abstract MpNextStopMinDto getMpNextStopMinWithLastMileage(String vin) throws SystemException;

	/**
	 * Update call state of MpNextStopMin .
	 *
	 * @throws SystemException SystemException
	 */
	public abstract boolean updateCallStatus(String vin, Integer mpCallStatusValue) throws SystemException;

	/**
	 * Get the min proposal date by vin (called by TiamServices).
	 *
	 * @param vins the vins
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract Map<String, Date> getProposalDateByVin(Set<String> vins) throws SystemException;

	/**
	 * Get the min proposal date by vin. (called by MpServices) Vins not identified for the recreation of alert but in alert.
	 *
	 * @param vins the vins already recreated
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract Map<String, Date> getProposalDateByVinInAlertNotInVins(Set<String> vins) throws SystemException;
}
