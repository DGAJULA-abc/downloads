package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpOilTypeDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpOilTypeAccess {

	/**
	 * Get the oil type list by plan list.
	 * 
	 * @param planList for filter
	 * @param language for display
	 * @param defaultLanguage : default Language
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpOilTypeDto> getListByPlanList(String planList, String language, String defaultLanguage) throws SystemException;

}
