package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpOperationAccess {

	/**
	 * Get the List of operations by plan and intervals.
	 * 
	 * @param planId to filter
	 * @param intervalId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public abstract List<MpIntervalOperationDto> getListOperations(String intervalId, String language, String defaultLanguage) throws SystemException;

	/**
	 * Get the operation by operation series id.
	 * 
	 * @param planId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getOperation(Long opeSerId, String language, String defaultLanguage) throws SystemException;

	/**
	 * Get the operation with the label of the series using its id.
	 * 
	 * @param operation to filter
	 * 
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public abstract List<MpIntervalOperationDto> getOperationWithSeriesLabel(MpIntervalOperationDto operation, String language, String defaultLanguage) throws SystemException;

}
