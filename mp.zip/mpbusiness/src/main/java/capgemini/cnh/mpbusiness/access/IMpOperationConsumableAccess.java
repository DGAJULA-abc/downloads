package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpOperationConsumableAccess {

	/**
	 * Get the List of consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @param defaultLanguage : default Language
	 * @param brandId : brand Id
	 * @param dtoIceContext context
	 * 
	 * @return the list of consumables
	 * @throws SystemException system exception
	 */
	public abstract List<MpOperationConsumableDto> getListConsumablesByOp(Long idSeriesOperation, String language, String defaultLanguage, Long brandId, IceContextDto dtoIceContext)
			throws SystemException;

	/**
	 * Get the consumables context and occurances and part number for consumable id.
	 * 
	 * @param consId consumable Id
	 * @param language dealer lang
	 * @param defaultLanguage : default Language
	 * @param dtoIceContext context
	 * 
	 * @return the object of consumables
	 * @throws SystemException system exception
	 */

	public abstract MpOperationConsumableDto getConsumablesPnByConsIdAndCountryAndMarket(Long consId, Long consOccId, String country, String marketId)
			throws SystemException;

	/**
	 * Get the consumables context and occurances and part number for consumable id.
	 * 
	 * @param consId consumable Id
	 * @param language dealer lang
	 * @param defaultLanguage : default Language
	 * @param dtoIceContext context
	 * 
	 * @return the object of consumables
	 * @throws SystemException system exception
	 */
	public abstract MpOperationConsumableDto getConsumablesOccByConsId(Long consId, boolean defaultLanguage, IceContextDto dtoIceContext)
			throws SystemException;

}
