package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpOperationIuLinkDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpOperationIuLinkAccess {

	/**
	 * Get the List of Iu Links for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 *
	 * @return the list of Ius links
	 * @throws SystemException system exception
	 */
	public abstract List<MpOperationIuLinkDto> getListIusByOp(Long idSeriesOperation) throws SystemException;

}
