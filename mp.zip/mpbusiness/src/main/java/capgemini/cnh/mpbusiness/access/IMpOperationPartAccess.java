package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpOperationPartAccess {

	/**
	 * Get the List of parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param context filter on context
	 * 
	 * @return the list of parts
	 * @throws SystemException system exception
	 */
	public abstract List<MpOperationPartDto> getListPartsByOp(String idSeriesOperation, IceContextDto context) throws SystemException;

	/**
	 * @param partList
	 * @return
	 * @throws SystemException
	 */
	List<MpOperationPartDto> getParts(List<String> partList) throws SystemException;

	/**
	 * Get the pars label .
	 * 
	 * @param part the part
	 * @return the parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpOperationPartDto getPart(String part) throws SystemException;

}
