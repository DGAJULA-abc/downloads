package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpPartDescriptionAccess {

	/**
	 * Get the List of parts for a given part for all the languages.
	 * 
	 * @param code the part code
	 * @return the list of parts
	 * @throws SystemException system exception
	 */
	public abstract List<MpPartDescriptionDto> getPartsByCode(String code) throws SystemException;

	/**
	 * Get the part for a given part and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public abstract MpPartDescriptionDto getPartsByCodeAndLanguage(String code, String language) throws SystemException;

	/**
	 * Get the part for a given part list and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public abstract List<MpPartDescriptionDto> getPartsDescriptionByLanguage(List<String> partList, String language) throws SystemException;

}
