package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpPartDetailAccess {

	/**
	 * Get a part detail.
	 * 
	 * @param partNumber to find
	 * @return the part
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract MpPartDetailDto getPartDetail(String partNumber) throws SystemException, ApplicativeException;

}
