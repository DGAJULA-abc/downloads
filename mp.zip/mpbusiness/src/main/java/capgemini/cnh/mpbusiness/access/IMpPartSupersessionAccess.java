package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPartSupersessionDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpPartSupersessionAccess {

	/**
	 * Get a list part supersession.
	 * 
	 * @param partNumber to find the supersession chain
	 * @return a list part supersession
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpPartSupersessionDto> getSupersessionList(String partNumber) throws SystemException, ApplicativeException;

}
