package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPerfFreeTextDto;

/**
 * 
 * @author mmartel
 *
 */
public interface IMpPerfFreeTextAccess {

	/**
	 * Get the free text performances for a series.
	 * 
	 * @param planId the plan id
	 * @return the list of all the free text performances for a series.
	 */
	public abstract List<MpPerfFreeTextDto> getPerformancesForSeries(String planId, String language) throws SystemException;
}
