package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.product.SeriesDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpPlanAccess {

	/**
	 * Get the plan list by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * 
	 * @return a list of applicable plan
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpPlanDto> getListByProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException;

	/**
	 * Get the plan by id.
	 * 
	 * @param planId filter on plan id
	 * 
	 * @return the plan
	 * @throws SystemException system exception
	 */
	public abstract MpPlanDto getPlan(Long planId) throws SystemException;

	/**
	 * Get the performance list by plan list.
	 * 
	 * @param planList for filter
	 * @return a list of oilType
	 * @throws SystemException system exception
	 */
	public abstract List<MpPlanDto> getPerformanceListByPlanList(String planList) throws SystemException;

	/**
	 * Get the number of plans with hour in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 */
	public abstract Long getNbPlanWithHour(String planList) throws SystemException;

	/**
	 * Get the number of plans with mileage in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 */
	public abstract Long getNbPlanWithMileage(String planList) throws SystemException;

	/**
	 * Get the plan applicable to the criteria.
	 * 
	 * @param planIdList list of plan
	 * @param usageId usage Id
	 * @param performance performance
	 * 
	 * @return list of plans
	 * 
	 * @throws SystemException system exception
	 */
	public List<MpPlanDto> getPlanWithCriteria(List<Long> planIdList, int usageId, String performance) throws SystemException;

	/**
	 * <b>Publication Etim-Offline</b> <br>
	 * Get the plan applicable by Serie.
	 * 
	 * @param serie serie
	 * @return list of plans
	 * @throws SystemException System Exception
	 */
	public List<MpPlanDto> getMaintenancePlanBySerie(SeriesDto serie) throws SystemException;

	/**
	 * Get the external plan id.
	 * 
	 * @param planId for filter
	 * @return external plan id
	 * @throws SystemException system exception
	 */
	public MpPlanDto getExternalPlanId(Long planId) throws SystemException;

	/**
	 * Get the publication date of the IU.
	 * 
	 * @param planId the id of the plan
	 * @param projectVersion the version of the project
	 * @return the IU information
	 * @throws SystemException a system exception
	 */
	public abstract MpPlanDto getMpIuPublicationDate(Long planId, Integer projectVersion) throws SystemException;

	/**
	 * Get the last version of the plan applicable.
	 * 
	 * @param planExtId the id of the plan
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public abstract MpPlanDto getMpCurrentPlanApplicable(Long planExtId) throws SystemException;

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkPlanApplicable(Long planId, IceContextDto context, List<Integer> projectList) throws SystemException;

	/**
	 * Return plan id if applicable to the context.
	 * 
	 * @param planExtId the external id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkLastVersionPlanApplicable(Long planExtId, IceContextDto context, List<Integer> projectList) throws SystemException;

	/**
	 * Get the plan by external plan id.
	 * 
	 * @param planExtId the external plan id
	 * @return the plan
	 * @throws SystemException SystemException
	 */
	public MpPlanDto getPlanByExtId(Long planExtId) throws SystemException;

	public abstract List<MpPlanDto> getPlanAndApplicabilityBySeries(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException;

	public abstract MpPlanDto getPerformanceForPlanId(String PlanExtId, String projectNumber, String version) throws SystemException;
}