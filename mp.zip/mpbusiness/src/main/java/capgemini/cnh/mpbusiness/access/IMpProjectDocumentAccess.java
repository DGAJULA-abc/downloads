/**
* 
*/
package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpProjectDocumentDto;

/**
 * @author sdomecq
 *
 */
public interface IMpProjectDocumentAccess {

	/**
	 * Get the List of project .
	 * 
	 * @param context for applicability
	 * 
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract List<MpProjectDocumentDto> getList(IceContextDto context) throws SystemException;
}
