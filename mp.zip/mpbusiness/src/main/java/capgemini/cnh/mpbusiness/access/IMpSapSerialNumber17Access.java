package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpSapSerialNumber17Dto;

/**
 * 
 * @author jdespeau
 *
 */
public interface IMpSapSerialNumber17Access {

	/**
	 * Name of the table in the database.
	 */
	public static final String TABLE_NAME = "SAP_SERIAL_NUMBER_17";

	/**
	 * Column SAP_VIN.
	 */
	public static final String COL_SAP_VIN = "SAP_VIN";

	/**
	 * Column SAP_VIN_17.
	 */
	public static final String COL_SAP_VIN_17 = "SAP_VIN_17";

	/**
	 * Get Sap Vin 17 From Sap Vin.
	 * 
	 * @param sapVin
	 * @return MpSapSerialNumber17Dto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public abstract MpSapSerialNumber17Dto getSapSerialNumber17FromSapVin(String sapVin) throws SystemException;

}
