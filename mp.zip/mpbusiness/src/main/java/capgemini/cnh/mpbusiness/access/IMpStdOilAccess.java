package capgemini.cnh.mpbusiness.access;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpStdOilDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpStdOilAccess {

	/**
	 * Get the list of standard oil by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * 
	 * @return a list of applicable standard oil
	 * 
	 * @throws SystemException system exception
	 */
	public abstract List<MpStdOilDto> getStdOilsyProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException;

}
