package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;

/**
 * 
 * @author jdespeau
 *
 */
public interface IMpToleranceAcess {

	/**
	 * Table MP_TOLERANCE
	 */
	static final String TABLE = "MP_TOLERANCE";

	/**
	 * Column A_ICE_CODE
	 */
	static final String BRAND_ICE_CODE = "A_ICE_CODE";

	/**
	 * Column MK_ID
	 */
	static final String MARKET_ID = "MK_ID";

	/**
	 * Column SCHEDULING_TYPE :
	 * - VARIABLE_SCHEDULING = 0
	 * - FIXED_SCHEDULING = 1
	 */
	static final String SCHEDULING_TYPE = "SCHEDULING_TYPE";

	/**
	 * Column TECHNICAL_KM.
	 */
	static final String TECHNICAL_KM_MIN = "TECHNICAL_KM_MIN";

	/**
	 * Column TECHNICAL_KM.
	 */
	static final String TECHNICAL_KM_MAX = "TECHNICAL_KM_MAX";

	/**
	 * Tolerated delta for Hours.
	 */
	static final String TECHNICAL_HOUR_MIN = "TECHNICAL_HOUR_MIN";

	/**
	 * Tolerated delta for Hours.
	 */
	static final String TECHNICAL_HOUR_MAX = "TECHNICAL_HOUR_MAX";

	/**
	 * Tolerated delta for months.
	 */
	static final String TECHNICAL_MONTH_MIN = "TECHNICAL_MONTH_MIN";

	/**
	 * Tolerated delta for months.
	 */
	static final String TECHNICAL_MONTH_MAX = "TECHNICAL_MONTH_MAX";

	/**
	 * Tolerated far for Km.
	 */
	static final String COMMERCIAL_KM_MIN = "COMMERCIAL_KM_MIN";

	/**
	 * Tolerated far for Km.
	 */
	static final String COMMERCIAL_KM_MAX = "COMMERCIAL_KM_MAX";

	/**
	 * Tolerated far for Hours.
	 */
	static final String COMMERCIAL_HOUR_MIN = "COMMERCIAL_HOUR_MIN";

	/**
	 * Tolerated far for Hours.
	 */
	static final String COMMERCIAL_HOUR_MAX = "COMMERCIAL_HOUR_MAX";

	/**
	 * Tolerated far for months.
	 */
	static final String COMMERCIAL_MONTH_MIN = "COMMERCIAL_MONTH_MIN";

	/**
	 * Tolerated far for months.
	 */
	static final String COMMERCIAL_MONTH_MAX = "COMMERCIAL_MONTH_MAX";

	/**
	 * Get tolerance by brand and market
	 * 
	 * @param brand
	 * @param market
	 * @return
	 * @throws SystemException
	 */
	MpToleranceDto getToleranceByBrandAndMarket(String brandIceCode, Long marketId) throws SystemException;

}
