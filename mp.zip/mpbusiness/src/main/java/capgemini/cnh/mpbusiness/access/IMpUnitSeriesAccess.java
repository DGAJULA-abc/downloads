package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;

/**
 * 
 * @author jdespeau
 *
 */
public interface IMpUnitSeriesAccess {

	/**
	 * Get unit by serie.
	 * 
	 * @param context
	 * @return the MpUnitSeriesDto
	 * @throws SystemException
	 */
	public abstract MpUnitSeriesDto getUnitBySerie(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException;

}