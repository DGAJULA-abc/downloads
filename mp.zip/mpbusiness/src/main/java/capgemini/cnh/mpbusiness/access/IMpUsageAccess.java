package capgemini.cnh.mpbusiness.access;

import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * 
 * @author cblois
 *
 */
public interface IMpUsageAccess {

	/**
	 * Get the oil type list by plan list.
	 * 
	 * @param planList for filter
	 * @param language for display
	 * @param defaultLanguage : default Language
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public abstract List<MpUsageDto> getListByPlanList(String planList, String language, String defaultLanguage) throws SystemException;

	/**
	 * Get mp usage item translation for the given language.
	 * 
	 * @param itemId the mp usage item id
	 * @param language the language for translation
	 * @return the mp usage item translated
	 * @throws SystemException system exception
	 */
	public abstract MpUsageDto getMpUsageItemTranslation(Long itemId, String language) throws SystemException;

	/**
	 * Get mp usage value translation for the given language.
	 * 
	 * @param valueId the mp usage value id
	 * @param language the language for translation
	 * @return the mp usage value translated
	 * @throws SystemException system exception
	 */
	public abstract MpUsageDto getMpUsageValueTranslation(int valueId, String language) throws SystemException;

	/**
	 * Get translations for every mp usage item. Used for cache.
	 * 
	 * @param language the language for translation
	 * @return a map of mp usage item translation
	 * @throws SystemException system exception
	 */
	public abstract Map<Long, MpUsageDto> getMpUsageItemTranslationsByLang(String language) throws SystemException;

	/**
	 * Get translations for every mp usage value. Used for cache.
	 * 
	 * @param language the language for translation
	 * @return a map of mp usage value translation
	 * @throws SystemException system exception
	 */
	public abstract Map<Integer, MpUsageDto> getMpUsageValueTranslationsByLang(String language) throws SystemException;

	/**
	 * Get all the avalable missions.
	 * 
	 * @return all the mission ids.
	 * @throws SystemException SystemException
	 */
	public abstract List<MpUsageDto> getAllAvailableMissionsIds() throws SystemException;
}
