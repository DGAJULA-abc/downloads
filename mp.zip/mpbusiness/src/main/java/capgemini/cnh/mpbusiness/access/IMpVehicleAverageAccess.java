package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpVehicleAverageDto;

/**
 * 
 * @author bmilcend
 *
 */
public interface IMpVehicleAverageAccess {

	/**
	 * Get the vehicle values for a vin.
	 * 
	 * @param vin : vin
	 * @return a vehicleAverage dto
	 * @throws SystemException system exception
	 */
	public abstract MpVehicleAverageDto getVehicleAverageForVin(String vin) throws SystemException;

}
