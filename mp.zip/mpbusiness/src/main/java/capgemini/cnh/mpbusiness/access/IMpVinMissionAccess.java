package capgemini.cnh.mpbusiness.access;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpVinMissionDto;

/**
 * 
 * @author mamestoy
 *
 */
public interface IMpVinMissionAccess {

	/**
	 * Get the mission for a vin.
	 * 
	 * @param vinCode : vin
	 * @return a mission dto
	 * @throws SystemException system exception
	 */

	public abstract MpVinMissionDto getMpMissionForVin(String vinCode) throws SystemException;

}
