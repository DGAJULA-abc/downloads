package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMonMaintenancePlanAccess;
import capgemini.cnh.mpbusiness.dto.MonMaintenancePlanDto;

public class HsqlMonMaintenancePlan extends HsqlAccess implements IMonMaintenancePlanAccess {

	public HsqlMonMaintenancePlan() throws SystemException {
		super();
	}

	@Override
	protected Dto rs2Dto(ResultSet rs) throws SQLException {
		MonMaintenancePlanDto mmpDto = new MonMaintenancePlanDto();

		mmpDto.setMonVin(getStringIfExists(MON_VIN));
		mmpDto.setMonDate(getDateIfExists(MON_DATE));
		mmpDto.setMonUcrExtPlanId(getLongIfExists(MON_UCR_EXT_PLAN_ID));
		mmpDto.setMonUcrPlanId(getLongIfExists(MON_UCR_PLAN_ID));
		mmpDto.setMonEtimExtPlanId(getLongIfExists(MON_ETIM_EXT_PLAN_ID));
		mmpDto.setMonEtimPlanId(getLongIfExists(MON_ETIM_PLAN_ID));

		return mmpDto;
	}

	@Override
	public boolean saveMonMaintenancePlan(MonMaintenancePlanDto mmpDto) throws SystemException {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(MON_MAINTENANCE_PLAN);
		queryBuilder.append(" (");

		queryBuilder.append(MON_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(MON_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(MON_UCR_EXT_PLAN_ID);
		queryBuilder.append(", ");
		queryBuilder.append(MON_UCR_PLAN_ID);
		queryBuilder.append(", ");
		queryBuilder.append(MON_ETIM_EXT_PLAN_ID);
		queryBuilder.append(", ");
		queryBuilder.append(MON_ETIM_PLAN_ID);

		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(mmpDto.getMonVin()));
		queryBuilder.append(", ");
		queryBuilder.append("SYSDATE");
		queryBuilder.append(", ");
		queryBuilder.append(mmpDto.getMonUcrExtPlanId());
		queryBuilder.append(", ");
		queryBuilder.append(mmpDto.getMonUcrPlanId());
		queryBuilder.append(", ");
		queryBuilder.append(mmpDto.getMonEtimExtPlanId());
		queryBuilder.append(", ");
		queryBuilder.append(mmpDto.getMonEtimPlanId());
		queryBuilder.append(")");

		return executeQuery0(queryBuilder.toString());

	}
}
