package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.DateUtil;
import capgemini.cnh.mpbusiness.access.IMpAppointmentAccess;
import capgemini.cnh.mpbusiness.dto.MpAppointmentActionEnum;
import capgemini.cnh.mpbusiness.dto.MpAppointmentDto;
import capgemini.cnh.mpbusiness.dto.MpAppointmentStatusEnum;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpAppointmentAccess extends HsqlAccess<MpAppointmentDto> implements IMpAppointmentAccess {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public HsqlMpAppointmentAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpAppointmentAccess() throws SystemException {
		super();
	}

	@Override
	public Long closeAppointment(Long alertGroupId) throws SystemException {
		StringBuilder queryBuilder = new StringBuilder();
		SimpleDateFormat sdfUTC = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		sdfUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date dateCurrent = DateUtil.getCurrentUtilDate();
		queryBuilder.append("UPDATE MP_APPOINTMENT ");
		queryBuilder.append("SET MP_APPOINTMENT_CLOSE_DATE = ");
		queryBuilder.append(" TO_DATE (");
		queryBuilder.append(formatString(sdfUTC.format(dateCurrent)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(DateUtil.getDatabaseFormat()));
		queryBuilder.append(")");
		queryBuilder.append(" , MP_APPOINTMENT_SYNCHRO_DATE = ");
		queryBuilder.append(" TO_DATE (");
		queryBuilder.append(formatString(sdfUTC.format(dateCurrent)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(DateUtil.getDatabaseFormat()));
		queryBuilder.append(")");
		queryBuilder.append(" , MP_APPOINTMENT_ACTION = ");
		queryBuilder.append(formatString(MpAppointmentActionEnum.CLOSED.toString()));
		queryBuilder.append(" , MP_APPOINTMENT_STATUS = ");
		queryBuilder.append(formatString(MpAppointmentStatusEnum.NOTCALLED.toString()));
		queryBuilder.append(" WHERE ALERT_GROUP_ID = ").append(alertGroupId);

		return executeQueryI(queryBuilder.toString());
	}

	@Override
	protected MpAppointmentDto rs2Dto(ResultSet rs) throws SQLException {
		MpAppointmentDto dto = new MpAppointmentDto();
		dto.setAppointmentId(getLongIfExists("APPOINTMENT_ID"));
		dto.setAlertGroupId(getLongIfExists("ALERT_GROUP_ID"));
		dto.setVin(getStringIfExists("VIN"));
		dto.setDealerCode(getStringIfExists("DEALER_CODE"));
		dto.setCustomerName(getStringIfExists("CUSTOMER_NAME"));
		dto.setMileage(getLongIfExists("MILEAGE"));
		dto.setEngineHours(getLongIfExists("ENGINE_HOURS"));
		dto.setPlate(getStringIfExists("PLATE"));
		dto.setFreeNote(getStringIfExists("FREE_NOTE"));
		dto.setAction(getStringIfExists("MP_APPOINTMENT_ACTION"));
		dto.setStatus(getStringIfExists("MP_APPOINTMENT_STATUS"));
		dto.setRecallDate(getDateIfExists("MP_APPOINTMENT_RECALL_DATE"));
		dto.setOpenDate(getDateIfExists("MP_APPOINTMENT_OPEN_DATE", Calendar.getInstance(TimeZone.getTimeZone("GMT"))));
		dto.setUpdateDate(getDateIfExists("MP_APPOINTMENT_UPDATE_DATE", Calendar.getInstance(TimeZone.getTimeZone("GMT"))));
		dto.setCloseDate(getDateIfExists("MP_APPOINTMENT_CLOSE_DATE", Calendar.getInstance(TimeZone.getTimeZone("GMT"))));
		dto.setSynchroDate(getDateIfExists("MP_APPOINTMENT_SYNCHRO_DATE", Calendar.getInstance(TimeZone.getTimeZone("GMT"))));
		dto.setCancelDate(getDateIfExists("MP_APPOINTMENT_CANCEL_DATE", Calendar.getInstance(TimeZone.getTimeZone("GMT"))));

		return dto;
	}

	@Override
	public MpAppointmentDto manageAppointment(MpAppointmentDto mpAppointment) throws SystemException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MpAppointmentDto getAppointmentById(Long id) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append("APPOINTMENT_ID, ");
		query.append("ALERT_GROUP_ID, ");
		query.append("DEALER_CODE, ");
		query.append("VIN, ");
		query.append("FREE_NOTE, ");
		query.append("MP_APPOINTMENT_OPEN_DATE,	MP_APPOINTMENT_UPDATE_DATE,	MP_APPOINTMENT_CLOSE_DATE, 	MP_APPOINTMENT_SYNCHRO_DATE, MP_APPOINTMENT_CANCEL_DATE");
		query.append(",MP_APPOINTMENT_ACTION, MP_APPOINTMENT_STATUS, ");
		query.append("MP_APPOINTMENT_RECALL_DATE, CUSTOMER_NAME, MILEAGE, ENGINE_HOURS, PLATE");
		query.append(" FROM MP_APPOINTMENT ");
		query.append(" WHERE ");
		query.append("APPOINTMENT_ID = ");
		query.append(id);

		return executeQuery1(query.toString());
	}

	@Override
	public MpAppointmentDto getAppointmentByVinAndAlertGroupIdAndDealerCode(String vin, Long alertGroupId, String dealerCode) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append("APPOINTMENT_ID, ");
		query.append("ALERT_GROUP_ID, ");
		query.append("DEALER_CODE, ");
		query.append("VIN, ");
		query.append("FREE_NOTE, ");
		query.append("MP_APPOINTMENT_OPEN_DATE,	MP_APPOINTMENT_UPDATE_DATE,	MP_APPOINTMENT_CLOSE_DATE, 	MP_APPOINTMENT_SYNCHRO_DATE, MP_APPOINTMENT_CANCEL_DATE");
		query.append(",MP_APPOINTMENT_ACTION, MP_APPOINTMENT_STATUS, ");
		query.append("MP_APPOINTMENT_RECALL_DATE, CUSTOMER_NAME, MILEAGE, ENGINE_HOURS, PLATE");
		query.append(" FROM MP_APPOINTMENT ");
		query.append(" WHERE ");
		query.append("VIN = ");
		query.append(formatString(vin));
		query.append(" AND ALERT_GROUP_ID = ");
		query.append(alertGroupId);
		query.append(" AND DEALER_CODE = ");
		query.append(formatString(dealerCode));
		query.append(" AND MP_APPOINTMENT_CLOSE_DATE is NULL ");
		query.append(" AND MP_APPOINTMENT_CANCEL_DATE is NULL ");

		return executeQuery1(query.toString());
	}

	@Override
	public Long updateAppointementToRecall(Long alertGroupId) throws SystemException {

		StringBuilder queryBuilder = new StringBuilder();
		SimpleDateFormat sdfUTC = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		sdfUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date dateCurrent = DateUtil.getCurrentUtilDate();
		queryBuilder.append("UPDATE MP_APPOINTMENT ");
		queryBuilder.append("SET MP_APPOINTMENT_SYNCHRO_DATE = ");
		queryBuilder.append(" TO_DATE (");
		queryBuilder.append(formatString(sdfUTC.format(dateCurrent)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(DateUtil.getDatabaseFormat()));
		queryBuilder.append(")");
		queryBuilder.append(" , MP_APPOINTMENT_STATUS = ");
		queryBuilder.append(formatString(MpAppointmentStatusEnum.RECALL.name()));
		queryBuilder.append(" WHERE ALERT_GROUP_ID = ").append(alertGroupId);
		queryBuilder.append(" AND MP_APPOINTMENT_ACTION IN (").append(formatString(MpAppointmentActionEnum.CREATED.toString()));
		queryBuilder.append(",");
		queryBuilder.append(formatString(MpAppointmentActionEnum.UPDATED.toString()));
		queryBuilder.append(")");
		return executeQueryI(queryBuilder.toString());
	}

}
