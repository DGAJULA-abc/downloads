package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.dto.MpContractConfigurationDto;

/**
 * 
 * @author mmartel
 *
 */
public class HsqlMpContractConfigurationAccess extends HsqlAccess<MpContractConfigurationDto> implements IMpContractConfigurationAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpContractConfigurationAccess() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpContractConfigurationDto rs2Dto(ResultSet rs) throws SQLException {
		MpContractConfigurationDto dto = new MpContractConfigurationDto();

		dto.setMpGroupConf(getStringIfExists("MP_GROUP_CONF"));
		dto.setItemId(getLongIfExists("CONFIG_ITEM_ID"));
		dto.setValueId(getLongIfExists("CONFIG_VALUE_ID"));

		return dto;
	}

	/**
	 * Get the list of configuration linked to a group.
	 * 
	 * @param group of configuration
	 * @return a list of configuration
	 * @throws SystemException system exception
	 */
	public List<MpContractConfigurationDto> getMpContractConfiguration(String group) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT MP_GROUP_CONF, CONFIG_ITEM_ID, CONFIG_VALUE_ID FROM MP_CONTRACT_CONFIGURATION");
		query.append(" WHERE MP_GROUP_CONF  = ");
		query.append(formatString(group));

		return executeQueryN(query.toString());

	}

}
