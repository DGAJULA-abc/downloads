package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.common.IceConstantes;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.access.IMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.dto.MpDefaultMissionDto;

/**
 * 
 * @author mamestoy
 *
 */
public class HsqlMpDefaultMissionAccess extends HsqlAccess<MpDefaultMissionDto> implements IMpDefaultMissionAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpDefaultMissionAccess() throws SystemException {
		super();
	}

	/**
	 * Get the mission for an applicability.
	 * 
	 * @param dtoIceContext : context (series, model, tt)
	 * @param level : series, model or tt level
	 * @return a list of table title
	 * @throws SystemException system exception
	 */
	public MpDefaultMissionDto getMpMissionForApp(IceContextDto dtoIceContext, String level) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT MISSION_SER, MISSION_MOD, MISSION_TT, MISSION_ID ");
		query.append(" FROM MP_DEFAULT_MISSION ");
		query.append(" WHERE ");
		query.append(" MISSION_BRA = ");
		query.append(formatString(dtoIceContext.getBrand().getIceCode()));
		query.append(" AND MISSION_TYP = ");
		query.append(formatString(dtoIceContext.getType().getIceCode()));
		query.append(" AND MISSION_PRO = ");
		query.append(formatString(dtoIceContext.getProduct().getIceCode()));
		if (level.equals(Integer.toString(IceConstantes.LEVEL_TECHNICALTYPE)))
		{
			// TT level
			query.append(" AND MISSION_SER = ");
			query.append(formatString(dtoIceContext.getSeries().getIceCode()));
			query.append(" AND MISSION_MOD = ");
			query.append(formatString(dtoIceContext.getModel().getIceCode()));
			query.append(" AND MISSION_TT = ");
			query.append(formatString(dtoIceContext.getTechnicalType().getIceCode()));
		}
		else if (level.equals(Integer.toString(IceConstantes.LEVEL_MODEL)))
		{
			// Model level
			query.append(" AND MISSION_SER = ");
			query.append(formatString(dtoIceContext.getSeries().getIceCode()));
			query.append(" AND MISSION_MOD = ");
			query.append(formatString(dtoIceContext.getModel().getIceCode()));
			query.append(" AND MISSION_TT is null ");
		}
		else
		{
			// Series level
			query.append(" AND MISSION_SER = ");
			query.append(formatString(dtoIceContext.getSeries().getIceCode()));
			query.append(" AND MISSION_MOD is null ");
			query.append(" AND MISSION_TT is null ");
		}

		return executeQuery1(query.toString());
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpDefaultMissionDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpDefaultMissionDto mpMpDefaultMissionDto = new MpDefaultMissionDto();

		// Set Dto
		mpMpDefaultMissionDto.setValueMissionId(getLongIfExists("MISSION_ID"));
		mpMpDefaultMissionDto.setSeriesIceCode(getStringIfExists("MISSION_SER"));
		mpMpDefaultMissionDto.setModelIceCode(getStringIfExists("MISSION_MOD"));
		mpMpDefaultMissionDto.setTtIceCode(getStringIfExists("MISSION_TT"));

		return mpMpDefaultMissionDto;
	}
}
