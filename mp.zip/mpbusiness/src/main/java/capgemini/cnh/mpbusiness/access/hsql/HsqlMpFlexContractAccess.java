package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpFlexContractAccess;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpFlexContractAccess extends HsqlAccess<MpContractVehicleDto> implements IMpFlexContractAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpFlexContractAccess() throws SystemException {
		super();
	}

	/** date format. **/
	private static SimpleDateFormat simpDate = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpContractVehicleDto rs2Dto(ResultSet rs) throws SQLException {
		MpContractVehicleDto dto = new MpContractVehicleDto();

		dto.setSapVin(getStringIfExists("VIN"));
		dto.setPlanId(getLongIfExists("PLAN_ID"));
		dto.setContractStartDate(getDateIfExists("CONTRACT_DATE_START"));
		dto.setContractEndDate(getDateIfExists("CONTRACT_DATE_EXP"));
		dto.setDealerCode(getStringIfExists("DEALER_CODE"));
		dto.setCustomerCode(getStringIfExists("CUSTOMER_CODE"));
		dto.setContractNumber(getStringIfExists("CONTRACT_NB"));
		dto.setBrandIceCode(getStringIfExists("BRAND_ICECODE"));
		return dto;
	}

	@Override
	public MpContractVehicleDto getMpActiveFlexContract(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String todayDate = df.format(new Date());

		query.append(
				"SELECT VIN, BRAND_ICECODE, PLAN_ID, CONTRACT_DATE_START, CONTRACT_DATE_EXP, DEALER_CODE, CUSTOMER_CODE FROM MP_FLEX_CONTRACT_WK ");
		query.append(" WHERE VIN = ");
		query.append(formatString(vin));
		query.append(" and CONTRACT_DATE_START <= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");
		query.append(" and CONTRACT_DATE_EXP >= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");

		return executeQuery1(query.toString());
	}

	@Override
	public boolean hasDealerActiveContract(String dealerCode, String brandIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String todayDate = df.format(new Date());

		query.append(
				"SELECT VIN FROM MP_FLEX_CONTRACT_WK ");
		query.append(" WHERE ");
		query.append(" DEALER_CODE = ").append(formatString(dealerCode));
		query.append(" and CONTRACT_DATE_START <= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");
		query.append(" and CONTRACT_DATE_EXP >= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");
		query.append(" and BRAND_ICECODE = ");
		query.append(formatString(brandIceCode));
		return executeQuery0(query.toString());

	}

}
