package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author bmilcend
 *
 */
public class HsqlMpFlexCouponAccess extends HsqlAccess<MpFlexCouponDto> implements IMpFlexCouponAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpFlexCouponAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT COUPON_CODE FROM MP_COUPON_FLEX");
		return executeQueryN(query.toString());
	}

	@Override
	protected MpFlexCouponDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpFlexCouponDto dto = new MpFlexCouponDto();

		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		return dto;
	}

	@Override
	public MpFlexCouponDto getFlexibleCoupon(String coupon) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT COUPON_CODE FROM MP_COUPON_FLEX WHERE COUPON_CODE=");
		query.append(formatString(coupon));
		return executeQuery1(query.toString());
	}

}
