/**
 * 2:53:19 PM
 * HsqlMpFlexCustomerSapAccess.java
 * 
 */
package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.dto.MpFlexCustomerSapDto;

/**
 * @author mshaikh4
 *
 */
public class HsqlMpFlexCustomerSapAccess extends HsqlAccess<MpFlexCustomerSapDto> implements IMpFlexCustomerSapAccess {

	/**
	 * @param dbAccess
	 * @throws SystemException
	 */
	public HsqlMpFlexCustomerSapAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * 
	 * @throws SystemException
	 */
	public HsqlMpFlexCustomerSapAccess() throws SystemException {
		super();
	}

	/* (non-Javadoc)
	 * @see capgemini.cnh.mp.access.IMpFlexCustomerSapAccess#selectCustomerFromVinDetail(java.lang.String)
	 */
	@Override
	public MpFlexCustomerSapDto selectCustomerFromVinDetail(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT CUSTOMER_CODE, CUSTOMER_NAME1, CUSTOMER_NAME2, E_MAIL, PHONE_NUMBER, CUSTOMER_COUNTRY ");
		query.append(" FROM MP_FLEX_CUSTOMER_SAP ");
		query.append(" WHERE CUSTOMER_CODE =  ");
		query.append(" ( ");
		query.append(" SELECT t1.CUSTOMER_CODE FROM MP_FLEX_CONTRACT_INFO_SAP t1 WHERE t1.CONTRACT = ");
		query.append(" (SELECT t0.SAP_CONTRACT_NB FROM MP_CONTRACT_VEHICLE t0 WHERE t0.SAP_VIN = ");
		query.append(formatString(vin));
		query.append("  AND START_DATE <= SYSDATE AND END_DATE >= SYSDATE) ");
		query.append(" ) ");

		return executeQuery1(query.toString());
	}

	/* (non-Javadoc)
	 * @see capgemini.cnh.framework.access.Access#rs2Dto(java.sql.ResultSet)
	 */
	@Override
	protected MpFlexCustomerSapDto rs2Dto(ResultSet rs) throws SQLException {
		MpFlexCustomerSapDto dto = new MpFlexCustomerSapDto();
		dto.setCustomerCode(getStringIfExists("CUSTOMER_CODE"));
		dto.setCustomeName1(getStringIfExists("CUSTOMER_NAME1"));
		dto.setCustomerName2(getStringIfExists("CUSTOMER_NAME2"));
		dto.seteMail(getStringIfExists("E_MAIL"));
		dto.setPhoneNumber(getStringIfExists("PHONE_NUMBER"));
		dto.setCustomerCountry(getStringIfExists("CUSTOMER_COUNTRY"));
		return dto;
	}

}
