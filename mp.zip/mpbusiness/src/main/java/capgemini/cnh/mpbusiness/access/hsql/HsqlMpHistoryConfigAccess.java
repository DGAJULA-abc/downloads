package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.access.QueryBuilderAccess;
import capgemini.cnh.framework.access.table.statik.CONFIG_ITEM;
import capgemini.cnh.framework.access.table.statik.CONFIG_VALUE;
import capgemini.cnh.framework.access.table.statik.MP_HISTORY_CONFIG;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.access.IConfigurationAccess;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.ConfigurationDto.ConfigurationDtoBuilder;
import capgemini.cnh.mpbusiness.access.IMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.dto.MpHistoryConfigDto;

/**
 * Access to the table MP_HISTORY_CONFIG.
 * 
 * @author dbabillo
 */
public class HsqlMpHistoryConfigAccess extends HsqlAccess<MpHistoryConfigDto> implements IMpHistoryConfigAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException Cannot get data source.
	 */
	public HsqlMpHistoryConfigAccess() throws SystemException {
		super();
	}

	@Override
	public boolean create(MpHistoryConfigDto pDto) throws SystemException {
		Long ret = null;
		boolean created = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(MP_HISTORY_CONFIG.table().getName());
		queryBuilder.append(" (");

		queryBuilder.append(COL_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_VALUE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_ITEM);

		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(pDto.getVin().toString()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIdConfig().toString()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getConfigItemId().toString()));
		queryBuilder.append(")");

		ret = executeQueryI(MP_HISTORY_CONFIG.table().getName(), queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			created = true;
		}
		return created;
	}

	/**
	 * Internal query builder.
	 * 
	 * @param pQueryBuilder the query
	 */
	private void selectColumn(StringBuilder pQueryBuilder) {
		pQueryBuilder.append(COL_VIN);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_VALUE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_ITEM);
		pQueryBuilder.append(", ");
		QueryBuilderAccess.selectColumn(pQueryBuilder, CONFIG_VALUE.table().getName(), IConfigurationAccess.CFG_LG);
		pQueryBuilder.append(", ");
		QueryBuilderAccess.selectColumn(pQueryBuilder, CONFIG_VALUE.table().getName(), IConfigurationAccess.CFG_VALUE);
		pQueryBuilder.append(", ");
		QueryBuilderAccess.selectColumn(pQueryBuilder, CONFIG_VALUE.table().getName(), IConfigurationAccess.CFG_DESCRIPTION);
		pQueryBuilder.append(", ");
		QueryBuilderAccess.selectColumn(pQueryBuilder, CONFIG_ITEM.table().getName(), IConfigurationAccess.CFG_NAME);
		pQueryBuilder.append(", ");
		QueryBuilderAccess.selectColumn(pQueryBuilder, CONFIG_ITEM.table().getName(), IConfigurationAccess.CFG_PRIMARY);
	}

	@Override
	public MpHistoryConfigDto read(MpHistoryConfigDto pDto, String pLanguageId) throws SystemException {
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);

		queryBuilder.append(" FROM ");
		queryBuilder.append(MP_HISTORY_CONFIG.table().getName());

		queryBuilder.append(" LEFT JOIN ");
		queryBuilder.append(CONFIG_VALUE.table().getName());
		queryBuilder.append(" ON ");
		queryBuilder.append(CONFIG_VALUE.table().getName());
		queryBuilder.append(".");
		queryBuilder.append(IConfigurationAccess.CFG_VALUE_ID);
		queryBuilder.append(" = ");
		queryBuilder.append(COL_VALUE);

		queryBuilder.append(" LEFT JOIN ");
		queryBuilder.append(CONFIG_ITEM.table().getName());
		queryBuilder.append(" ON ");
		queryBuilder.append(CONFIG_ITEM.table().getName());
		queryBuilder.append(".");
		queryBuilder.append(IConfigurationAccess.CFG_ITEM_ID);
		queryBuilder.append(" = ");
		queryBuilder.append(COL_ITEM);

		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ITEM, pDto.getConfigItemId());
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VALUE, pDto.getIdConfig());
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VIN, pDto.getVin());
		if (pLanguageId != null)
		{
			and = QueryBuilderAccess.whereColumn(queryBuilder, and, CONFIG_ITEM.table().getName() + '.' + IConfigurationAccess.CFG_LG, pLanguageId);
			and = QueryBuilderAccess.whereColumn(queryBuilder, and, CONFIG_VALUE.table().getName() + '.' + IConfigurationAccess.CFG_LG, pLanguageId);
		}
		if (!and)
		{
			throw new IllegalArgumentException("cannot build where clause with " + pDto.toString());
		}

		pDto = (MpHistoryConfigDto) executeQuery1(queryBuilder.toString());
		return pDto;
	}

	@Override
	public List<MpHistoryConfigDto> readList(MpHistoryConfigDto pDto, String pLanguageId, List<String> lstPinVin) throws SystemException {
		List<MpHistoryConfigDto> read = new ArrayList<MpHistoryConfigDto>();
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(lstPinVin.toArray(), "','");

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);

		queryBuilder.append(" FROM ");
		queryBuilder.append(MP_HISTORY_CONFIG.table().getName());

		queryBuilder.append(" LEFT JOIN ");
		queryBuilder.append(CONFIG_VALUE.table().getName());
		queryBuilder.append(" ON ");
		queryBuilder.append(CONFIG_VALUE.table().getName());
		queryBuilder.append(".");
		queryBuilder.append(IConfigurationAccess.CFG_VALUE_ID);
		queryBuilder.append(" = ");
		queryBuilder.append(COL_VALUE);

		queryBuilder.append(" LEFT JOIN ");
		queryBuilder.append(CONFIG_ITEM.table().getName());
		queryBuilder.append(" ON ");
		queryBuilder.append(CONFIG_ITEM.table().getName());
		queryBuilder.append(".");
		queryBuilder.append(IConfigurationAccess.CFG_ITEM_ID);
		queryBuilder.append(" = ");
		queryBuilder.append(COL_ITEM);

		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ITEM, pDto.getConfigItemId());
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VALUE, pDto.getIdConfig());
		if (and)
		{
			queryBuilder.append(" AND ");
		}
		queryBuilder.append(COL_VIN);
		queryBuilder.append(" in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");

		if (pLanguageId != null)
		{
			QueryBuilderAccess.whereColumn(queryBuilder, true, CONFIG_ITEM.table().getName() + '.' + IConfigurationAccess.CFG_LG, pLanguageId);
			QueryBuilderAccess.whereColumn(queryBuilder, true, CONFIG_VALUE.table().getName() + '.' + IConfigurationAccess.CFG_LG, pLanguageId);
		}

		read = executeQueryN(queryBuilder.toString());
		return read;
	}

	@Override
	public boolean update(MpHistoryConfigDto pDto) throws SystemException {
		Long ret = null;
		boolean updated = false;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("UPDATE ");
		queryBuilder.append(MP_HISTORY_CONFIG.table().getName());
		queryBuilder.append(" SET ");

		QueryBuilderAccess.equalColumn(queryBuilder, COL_VALUE, pDto.getIdConfig());

		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ITEM, pDto.getConfigItemId());
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VIN, pDto.getVin());
		if (and == false)
		{
			throw new IllegalArgumentException("cannot build where clause with " + pDto.toString());
		}

		ret = executeQueryI(MP_HISTORY_CONFIG.table().getName(), queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	@Override
	public boolean delete(MpHistoryConfigDto pDto) throws SystemException {
		Long ret = null;
		boolean deleted = false;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(pDto.getLstPinVin().toArray(), "','");

		queryBuilder.append("DELETE FROM ");
		queryBuilder.append(MP_HISTORY_CONFIG.table().getName());
		queryBuilder.append(" WHERE ");
		queryBuilder.append(COL_VIN);
		queryBuilder.append(" in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");

		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ITEM, pDto.getConfigItemId());
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VALUE, pDto.getIdConfig());
		if (and == false)
		{
			throw new IllegalArgumentException("cannot build where clause with " + pDto.toString());
		}

		ret = executeQueryI(MP_HISTORY_CONFIG.table().getName(), queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			deleted = true;
		}
		return deleted;
	}

	@Override
	protected MpHistoryConfigDto rs2Dto(ResultSet rs) throws SQLException {
		ConfigurationDtoBuilder builder = new ConfigurationDtoBuilder();

		builder.setIdConfig(super.getColumnIfExist(MP_HISTORY_CONFIG.MPHC_VALUE_ID))
				.setIdLanguage(super.getColumnIfExist(CONFIG_VALUE.CFG_LG))
				.setName(super.getColumnIfExist(CONFIG_VALUE.CFG_VALUE))
				.setDescription(super.getColumnIfExist(CONFIG_VALUE.CFG_DESCRIPTION))
				.setConfigItemId(super.getColumnIfExist(MP_HISTORY_CONFIG.MPHC_ITEM_ID))
				.setConfigItemName(super.getColumnIfExist(CONFIG_ITEM.CFG_NAME));

		Integer primary = getColumnIfExist(CONFIG_ITEM.CFG_PRIMARY);
		builder.setPrimaryConfig((null == primary) ? false : (1 == primary));

		ConfigurationDto dto = builder.build();

		MpHistoryConfigDto mpdto = new MpHistoryConfigDto(super.getString(COL_VIN), dto);

		return (mpdto);
	}
}
