package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.access.QueryBuilderAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * Access to the table MP_HISTORY_INTERVAL.
 * 
 * @author dbabillo
 */
public class HsqlMpHistoryIntervalAccess extends HsqlAccess implements IMpHistoryIntervalAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException Cannot get data source.
	 */
	public HsqlMpHistoryIntervalAccess() throws SystemException {
		super();
	}

	/**
	 * Internal query builder.
	 * 
	 * @param pQueryBuilder the query
	 */
	private void selectColumn(StringBuilder pQueryBuilder) {
		pQueryBuilder.append(COL_ID);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INTERVAL_CODE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_VIN);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INTERVAL_CODE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INTERVAL_ID);
		pQueryBuilder.append(", DATE_FORMAT(");
		pQueryBuilder.append(COL_UPDATE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(formatString(HSQL_DATE_FORMAT));
		pQueryBuilder.append(") AS ");
		pQueryBuilder.append(COL_UPDATE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_KM);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_MONTH);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_HOUR);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INT_KM);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INT_MONTH);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_INT_HOUR);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_PLAN_EXT_ID);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_ORIGIN);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_CLAIM_ID);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_FAILURE_DATE);
		pQueryBuilder.append(", ");
		pQueryBuilder.append(COL_STRONG_ID);
		//		pQueryBuilder.append(", ");
		//		pQueryBuilder.append(COL_OPERATOR_TYPE);
	}

	@Override
	public boolean create(MpHistoryIntervalDto pDto) throws SystemException {
		Long ret = null;
		boolean created = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" (");

		queryBuilder.append(COL_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_INTERVAL_CODE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_INTERVAL_ID);
		queryBuilder.append(", ");
		queryBuilder.append(COL_KM);
		queryBuilder.append(", ");
		queryBuilder.append(COL_MONTH);
		queryBuilder.append(", ");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(", ");
		queryBuilder.append(COL_INT_KM);
		queryBuilder.append(", ");
		queryBuilder.append(COL_INT_MONTH);
		queryBuilder.append(", ");
		queryBuilder.append(COL_INT_HOUR);
		queryBuilder.append(", ");
		queryBuilder.append(COL_PLAN_EXT_ID);
		queryBuilder.append(", ");
		queryBuilder.append(COL_ORIGIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_CLAIM_ID);
		queryBuilder.append(", ");
		queryBuilder.append(COL_FAILURE_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_STRONG_ID);
		queryBuilder.append(", ");
		queryBuilder.append(COL_OPERATOR_TYPE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_OPERATION_JSON);
		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(pDto.getVin()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIntervalCode()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIntervalId().toString()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.retreiveFromExactValueByMpType(MpType.MP_KM)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.retreiveFromExactValueByMpType(MpType.MP_MONTH)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.retreiveFromExactValueByMpType(MpType.MP_HOUR)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIntValue(MpType.MP_KM)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIntValue(MpType.MP_MONTH)));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIntValue(MpType.MP_HOUR)));
		queryBuilder.append(", now(), ");
		queryBuilder.append(pDto.getPlanExternalId());
		queryBuilder.append(", ");
		queryBuilder.append(pDto.getIsSapOrigin());
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getIdClaim()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getFailureDate()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getStrongId()));
		queryBuilder.append(", ");
		queryBuilder.append(pDto.getOperatorType());
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getOperationJsonForUcr()));
		queryBuilder.append(")");

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			created = true;
		}
		return created;
	}

	@Override
	public MpHistoryIntervalDto read(MpHistoryIntervalDto pDto, Integer filterOrigin) throws SystemException {
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(pDto.getLstPinVin().toArray(), "','");

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);

		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);

		queryBuilder.append(" WHERE ");
		queryBuilder.append(" MPH_VIN in (");
		queryBuilder.append(formatString(vinList));
		queryBuilder.append(") ");
		queryBuilder.append(" AND MPH_DELETED = 0 ");
		if (pDto.getIntervalCode() != null)
		{
			and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_INTERVAL_CODE, pDto.getIntervalCode());
		}
		if (pDto.getPlanExternalId() != null)
		{
			and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_PLAN_EXT_ID, pDto.getPlanExternalId());
		}
		if (filterOrigin != null)
		{
			and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ORIGIN, filterOrigin);
		}
		// and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_INTERVAL_ID,
		// pDto.getIntervalId());
		if (and == false)
		{
			throw new IllegalArgumentException("cannot build where clause with " + pDto.toString());
		}
		// -- this ordering is used in MPi to select only the most recent history
		queryBuilder.append(" ORDER BY -");
		queryBuilder.append(COL_MONTH);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_KM);
		queryBuilder.append(" ASC");

		pDto = (MpHistoryIntervalDto) executeQuery1(queryBuilder.toString());
		return pDto;
	}

	@Override
	public List<MpHistoryIntervalDto> readList(MpHistoryIntervalDto pDto) throws SystemException {
		List<MpHistoryIntervalDto> read = new ArrayList<MpHistoryIntervalDto>();
		List<Dto> tmp = null;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(pDto.getLstPinVin().toArray(), "','");

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);

		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);

		queryBuilder.append(" WHERE MPH_VIN in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");
		queryBuilder.append(" AND MPH_DELETED = 0 ");
		QueryBuilderAccess.whereColumn(queryBuilder, true, COL_INTERVAL_ID, pDto.getIntervalId());
		QueryBuilderAccess.whereColumn(queryBuilder, true, COL_PLAN_EXT_ID, pDto.getPlanExternalId());

		// -- this ordering is used in MPi to select only the most recent history
		queryBuilder.append(" ORDER BY -");
		queryBuilder.append(COL_MONTH);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_KM);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(" ASC");

		tmp = executeQueryN(queryBuilder.toString());
		for (Dto it : tmp)
		{
			read.add((MpHistoryIntervalDto) it);
		}
		return read;
	}

	@Override
	public List<MpHistoryIntervalDto> readListFromDateByOrigin(List<String> lstPinVin, Integer filterOrigin, long dateFrom)
			throws SystemException {
		List<MpHistoryIntervalDto> read = new ArrayList<MpHistoryIntervalDto>();
		List<Dto> tmp = null;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(lstPinVin.toArray(), "','");

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);
		queryBuilder.append(", INT_PLAN_ID ");

		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" left outer join MP_INTERVAL on (MPH_INT_ID = INT_ID) ");

		queryBuilder.append(" WHERE ");
		queryBuilder.append(COL_VIN);
		queryBuilder.append(" in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");

		queryBuilder.append(" AND MPH_DELETED = 0 ");
		if (filterOrigin != null)
		{
			QueryBuilderAccess.whereColumn(queryBuilder, true, COL_ORIGIN, filterOrigin);
		}
		queryBuilder.append(" AND ").append(COL_MONTH).append(" >= ").append(dateFrom);
		// -- this ordering is used in MPi to select only the most recent history
		queryBuilder.append(" ORDER BY -");
		queryBuilder.append(COL_MONTH);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_KM);
		queryBuilder.append(" ASC, -");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(" ASC");

		tmp = executeQueryN(queryBuilder.toString());
		for (Dto it : tmp)
		{
			read.add((MpHistoryIntervalDto) it);
		}
		return read;
	}

	@Override
	public boolean update(MpHistoryIntervalDto pDto) throws SystemException {
		Long ret = null;
		boolean updated = false;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("UPDATE ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" SET ");

		QueryBuilderAccess.equalColumn(queryBuilder, COL_KM, pDto.retreiveFromExactValueByMpType(MpType.MP_KM));
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_MONTH, pDto.retreiveFromExactValueByMpType(MpType.MP_MONTH));
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_HOUR, pDto.retreiveFromExactValueByMpType(MpType.MP_HOUR));
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_INT_KM, pDto.getIntValue(MpType.MP_KM));
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_INT_MONTH, pDto.getIntValue(MpType.MP_MONTH));
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_INT_HOUR, pDto.getIntValue(MpType.MP_HOUR));
		// case of new version of a project
		queryBuilder.append(", ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_INTERVAL_ID, pDto.getIntervalId());

		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ID, pDto.getId());
		// and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VIN,
		// pDto.getVin());
		// and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_INTERVAL_ID,
		// pDto.getIntervalId());
		if (and == false)
		{
			throw new IllegalArgumentException("cannot build where clause with " + pDto.toString());
		}

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	@Override
	public boolean delete(MpHistoryIntervalDto pDto) throws SystemException {
		Long ret = null;
		boolean deleted = false;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(pDto.getLstPinVin().toArray(), "','");

		queryBuilder.append("DELETE FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		// and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ID,
		// pDto.getId());
		queryBuilder.append(COL_VIN);
		queryBuilder.append(" in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");
		QueryBuilderAccess.whereColumn(queryBuilder, true, COL_INTERVAL_CODE, pDto.getIntervalCode());
		QueryBuilderAccess.whereColumn(queryBuilder, true, COL_PLAN_EXT_ID, pDto.getPlanExternalId());

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			deleted = true;
		}
		return deleted;
	}

	@Override
	public boolean delete(String id) throws SystemException {
		Long ret = null;
		boolean deleted = false;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("DELETE FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ID, id);
		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			deleted = true;
		}
		return deleted;
	}

	@Override
	public List<MpHistoryIntervalDto> readListWithoutClaim(String vin) throws SystemException {
		List<MpHistoryIntervalDto> read = new ArrayList<MpHistoryIntervalDto>();
		List<Dto> tmp = null;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT ");
		selectColumn(queryBuilder);
		queryBuilder.append(", INT_PLAN_ID ");

		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" left outer join MP_INTERVAL on (MPH_INT_ID = INT_ID) ");

		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_VIN, vin);
		queryBuilder.append(" AND ");
		queryBuilder.append("sysdate - ");
		queryBuilder.append(COL_UPDATE);
		queryBuilder.append(" > 30");

		// -- this ordering is used in MPi to select only the most recent history
		queryBuilder.append(" ORDER BY ");
		queryBuilder.append(COL_MONTH);
		queryBuilder.append(" DESC NULLS LAST, ");
		queryBuilder.append(COL_KM);
		queryBuilder.append(" DESC NULLS LAST, ");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(" DESC NULLS LAST");

		tmp = executeQueryN(queryBuilder.toString());
		for (Dto it : tmp)
		{
			read.add((MpHistoryIntervalDto) it);
		}
		return read;
	}

	@Override
	public boolean updateDeleted(String id, int deleted) throws SystemException {
		Long ret = null;
		boolean result = false;
		boolean and = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append(" UPDATE ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" SET ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_DELETED, deleted);
		queryBuilder.append(" WHERE ");
		and = QueryBuilderAccess.whereColumn(queryBuilder, and, COL_ID, id);
		ret = executeQueryI(queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			result = true;
		}
		return result;
	}

	/**
	 * Select the VIN without sap claim.
	 * 
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> getVinWithoutSapClaim() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT etim.mph_vin FROM ");
		query.append(
				"   (SELECT DISTINCT  mph_vin, mph_interval_code, MAX(MP_failure_date) sapdate  FROM MP_HISTORY_INTERVAL  WHERE MPH_ORIGIN = 1 AND MPH_DELETED = 0 ");
		query.append(" GROUP BY  mph_vin, mph_interval_code) sap,");
		query.append(
				" (  SELECT DISTINCT  mph_vin, mph_interval_code, MAX(MP_failure_date) etimdate FROM MP_HISTORY_INTERVAL  WHERE MPH_ORIGIN = 0 AND MPH_DELETED = 0  ");
		// We wait 7 days before to check if a claim is received
		query.append(
				"  GROUP BY  mph_vin, mph_interval_code having to_date('01/01/1970', 'MM/DD/YYYY') + MAX(MPH_EXACT_VALUE_MONTH/ 86400000) < (sysdate - 7)) etim ");
		query.append(", MP_FLEX_CONTRACT_WK mp_flex_contract ");
		query.append("  WHERE etim.mph_vin = sap.mph_vin  ");
		query.append(" AND etim.mph_vin = mp_flex_contract.vin ");
		// We convert time in ms (15*24*3600*1000) = 1296000000
		query.append(
				" AND etim.mph_interval_code = sap.mph_interval_code  AND (etim.etimdate -  (1728000000) > sap.sapdate )");
		query.append("  union ");
		// We wait 7 days before to check if a claim is received
		query.append(" SELECT DISTINCT etim.mph_vin FROM ");
		query.append(
				" ( SELECT DISTINCT  mph_vin, mph_interval_code, MAX(MP_failure_date) etimdate FROM MP_HISTORY_INTERVAL  WHERE MPH_ORIGIN = 0 AND MPH_DELETED = 0  ");
		query.append(
				"  GROUP BY  mph_vin, mph_interval_code having to_date('01/01/1970', 'MM/DD/YYYY') + MAX(MPH_EXACT_VALUE_MONTH/ 86400000) < (sysdate - 7)) etim ");
		query.append("  ,MP_FLEX_CONTRACT_WK mp_flex_contract  ");
		query.append("  WHERE etim.mph_vin = mp_flex_contract.vin ");
		query.append("  and (mph_vin, mph_interval_code) ");
		query.append("  not in (SELECT DISTINCT  mph_vin, mph_interval_code");
		query.append("  FROM MP_HISTORY_INTERVAL  WHERE MPH_ORIGIN = 1 AND MPH_DELETED = 0 )");

		// query.append(" SELECT DISTINCT etim.mph_vin FROM ");
		// query.append(" (SELECT DISTINCT mph_vin, mph_interval_code,
		// MAX(MPH_EXACT_VALUE_MONTH) sapdate ");
		// query.append(" FROM MP_HISTORY_INTERVAL ");
		// query.append(" WHERE MPH_ORIGIN = 1 AND MPH_DELETED = 0 ");
		// query.append(" GROUP BY mph_vin, mph_interval_code) sap, ");
		// query.append(" (SELECT DISTINCT mph_vin, mph_interval_code,
		// MAX(MPH_EXACT_VALUE_MONTH) etimdate");
		// query.append(" FROM MP_HISTORY_INTERVAL ");
		// query.append(" WHERE MPH_ORIGIN = 0 AND MPH_DELETED = 0 ");
		// query.append(" AND to_date('01/01/1970', 'MM/DD/YYYY') +
		// (MPH_EXACT_VALUE_MONTH/ 86400000) < (sysdate - 7) ");
		// query.append(" GROUP BY mph_vin, mph_interval_code) etim, ");
		// query.append(" MP_FLEX_CONTRACT_WK mp_flex_contract ");
		// query.append(" WHERE etim.mph_vin = sap.mph_vin(+) ");
		// query.append(" AND etim.mph_vin = mp_flex_contract.vin ");
		// query.append(" AND etim.mph_interval_code = sap.mph_interval_code(+) ");
		// //We convert time in ms (15*24*3600*1000) = 1296000000
		// query.append(" AND etim.etimdate - (1296000000) > sap.sapdate(+) ");

		return executeQueryN(query.toString());
	}

	@Override
	public boolean updateHourHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException {
		return updateHourOrKmHistoryInterval(sapDto, secondToMatch, true);
	}

	@Override
	public boolean updateKmHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException {
		return updateHourOrKmHistoryInterval(sapDto, secondToMatch, false);
	}

	private boolean updateHourOrKmHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch, boolean hourElseKm)
			throws SystemException {
		StringBuilder query = new StringBuilder();
		boolean result = false;
		String fieldExact = hourElseKm ? "mph_exact_value_hour" : "mph_exact_value_km";
		String fieldInt = hourElseKm ? "MPH_INT_VALUE_HOUR" : "MPH_INT_VALUE_KM";

		query.append("update MP_HISTORY_INTERVAL h1 set (h1.").append(fieldExact).append(",h1.").append(fieldInt)
				.append(") = (select IFNULL(max(h2.").append(fieldExact).append("),0), IFNULL(max(h2.").append(fieldInt)
				.append("),0) from MP_HISTORY_INTERVAL h2");
		query.append(
				" where h2.mph_vin=h1.mph_vin and h2.MPH_ORIGIN=0 and h2.MPH_DELETED = 0 and h2.MPH_INTERVAL_CODE=h1.MPH_INTERVAL_CODE and ABS(h1.MP_FAILURE_DATE-h2.MP_FAILURE_DATE)<= ");
		query.append(secondToMatch);
		query.append(" ) where  MPH_ORIGIN=1 and h1.MPH_DELETED = 0  and h1.mph_vin=");
		query.append(formatString(sapDto.getVin()));
		query.append(" and MPH_INTERVAL_CODE =");
		query.append(formatString(sapDto.getIntervalCode()));
		query.append(" and MPH_EXACT_VALUE_MONTH=");
		query.append(sapDto.retreiveFromExactValueByMpType(MpType.MP_MONTH));
		Long ret = executeQueryI(query.toString());
		if (ret != null && ret.longValue() > 0)
		{
			result = true;
		}
		return result;
	}

	/**
	 * Return the complete list of history for a VIN and origin.
	 * 
	 * @param pinVin The PIN or VIN
	 * @param origin the origin of the history: - 0 --> TIDB - 1 --> SAP - 2 --> UCR
	 * 
	 * @return the complete list of UCR history for a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpHistoryIntervalDto> getHistoryByVinAndOrigin(String pinVin, Integer origin) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select ");
		selectColumn(query);
		query.append(" from mp_history_interval ");
		query.append(" where mph_vin = ");
		query.append(formatString(pinVin));
		query.append(" and mph_origin = ");
		query.append(origin);

		return executeQueryN(query.toString());
	}

	/**
	 * Update the failure date of a claim.
	 * 
	 * @param idToUpdate claim id
	 * @param timestampFailure failure date in milliseconds
	 * @param vin VIN
	 */
	public void updateFailureDateForClaim(String idToUpdate, long timestampFailure, String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		// update MP_HISTORY_INTERVAL set MP_FAILURE_DATE = '' where MPH_CLAIM_ID = ''
		// and mph_vin = '';

		query.append("update MP_HISTORY_INTERVAL set MP_FAILURE_DATE = ");
		query.append(timestampFailure);
		query.append(" where MPH_CLAIM_ID = ");
		query.append(formatString(idToUpdate));
		query.append(" and mph_vin = ");
		query.append(formatString(vin));

		executeQueryI(query.toString());
	}

	@Override
	protected Dto rs2Dto(ResultSet rs) throws SQLException {
		MpHistoryIntervalDto dto = new MpHistoryIntervalDto(getStringIfExists(COL_ID), getLongIfExists(COL_INTERVAL_ID),
				getStringIfExists(COL_VIN), getStringIfExists(COL_INTERVAL_CODE), getLongIfExists(COL_PLAN_EXT_ID),
				getStringIfExists(COL_STRONG_ID));

		dto.setIdPlan(getLongIfExists("INT_PLAN_ID"));
		dto.setUpdateDate(getStringIfExists(COL_UPDATE));
		dto.addToExactValue(MpType.MP_KM, getLongIfExists(COL_KM));
		dto.addToExactValue(MpType.MP_MONTH, getLongIfExists(COL_MONTH));
		dto.addToExactValue(MpType.MP_HOUR, getLongIfExists(COL_HOUR));
		dto.setIntValue(MpType.MP_KM, getLongIfExists(COL_INT_KM));
		dto.setIntValue(MpType.MP_MONTH, getLongIfExists(COL_INT_MONTH));
		dto.setIntValue(MpType.MP_HOUR, getLongIfExists(COL_INT_HOUR));
		dto.setIsSapOrigin(getIntIfExists(COL_ORIGIN));
		dto.setIdClaim(getStringIfExists(COL_CLAIM_ID));
		dto.setFailureDate(getLongIfExists(COL_FAILURE_DATE));
		dto.setIsDeleted(getIntIfExists(COL_DELETED));
		dto.setContractType(getStringIfExists("Contract_type"));

		return dto;
	}

	@Override
	public MpHistoryIntervalDto getMaxEngineHour(MpHistoryIntervalDto pDto) throws SystemException {
		boolean and = true;
		StringBuilder queryBuilder = new StringBuilder();

		String vinList = StringUtils.join(pDto.getLstPinVin().toArray(), "','");

		queryBuilder.append("SELECT MAX(MPH_EXACT_VALUE_HOUR) MPH_EXACT_VALUE_HOUR, MAX(MPH_EXACT_VALUE_KM) MPH_EXACT_VALUE_KM ");
		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" ,( SELECT MPH_INTERVAL_CODE INTERNALCODE, MAX(MPH_EXACT_VALUE_MONTH) LASTMONTH ");
		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		queryBuilder.append(" MPH_VIN IN ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') AND MPH_DELETED = 0  ");
		if (pDto.getPlanExternalId() != null)
		{
			QueryBuilderAccess.whereColumn(queryBuilder, and, COL_PLAN_EXT_ID, pDto.getPlanExternalId());
		}
		queryBuilder.append(" GROUP BY MPH_INTERVAL_CODE) TBL  ");
		queryBuilder.append(" WHERE ");
		queryBuilder.append(" MPH_VIN in ('");
		queryBuilder.append(vinList);
		queryBuilder.append("') ");
		queryBuilder.append(" AND MPH_DELETED = 0 ");
		if (pDto.getIntervalCode() != null)
		{
			QueryBuilderAccess.whereColumn(queryBuilder, and, COL_INTERVAL_CODE, pDto.getIntervalCode());
		}
		if (pDto.getPlanExternalId() != null)
		{
			QueryBuilderAccess.whereColumn(queryBuilder, and, COL_PLAN_EXT_ID, pDto.getPlanExternalId());
		}
		queryBuilder.append(" AND MPH_INTERVAL_CODE = INTERNALCODE and MPH_EXACT_VALUE_MONTH = LASTMONTH ");

		pDto = (MpHistoryIntervalDto) executeQuery1(queryBuilder.toString());
		return pDto;
	}

	public Optional<Long> fetchLatestHoursValue(MpHistoryIntervalDto sapDto) throws SystemException {
		String sql = String.format(
				"SELECT MPH_INT_VALUE_HOUR FROM MP_HISTORY_INTERVAL WHERE mph_vin=%s AND MPH_ORIGIN=1 AND MPH_DELETED=0 AND MPH_INTERVAL_CODE=%s ORDER BY mp_failure_date DESC FETCH FIRST 1 ROWS ONLY",
				formatString(sapDto.getVin()),
				formatString(sapDto.getIntervalCode()));
		MpHistoryIntervalDto result = (MpHistoryIntervalDto) executeQuery1(sql);
		return Optional.ofNullable(result).map(r -> r.getIntValue(MpType.MP_HOUR));
	}

	public Optional<Long> fetchLastRecordHoursValue(MpHistoryIntervalDto sapDto) throws SystemException {
		String sql = String.format(
				"SELECT MPH_INT_VALUE_HOUR FROM MP_HISTORY_INTERVAL WHERE mph_vin=%s AND MPH_ORIGIN=1 AND MPH_INTERVAL_CODE=%s AND MPH_INT_VALUE_MONTH < %s ORDER BY MP_FAILURE_DATE DESC FETCH FIRST 1 ROWS ONLY",
				formatString(sapDto.getVin()),
				formatString(sapDto.getIntervalCode()),
				formatString(sapDto.getIntervalValue().get(MpType.MP_MONTH)));
		MpHistoryIntervalDto result = (MpHistoryIntervalDto) executeQuery1(sql);
		return Optional.ofNullable(result).map(r -> r.getIntValue(MpType.MP_HOUR));
	}

	public boolean executeUpdateHoursHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException {
		String updateQuery = buildNewUpdateQuery(sapDto, secondToMatch);
		Long ret = executeQueryI(updateQuery);
		return ret != null && ret > 0;
	}

	private String buildNewUpdateQuery(MpHistoryIntervalDto sapDto, long secondToMatch) {
		StringBuilder query = new StringBuilder();

		query.append(
				"update MP_HISTORY_INTERVAL h1 set (h1.mph_exact_value_hour,h1.MPH_INT_VALUE_HOUR) = (select nvl(max(h2.mph_exact_value_hour),0), nvl(max(h2.MPH_INT_VALUE_HOUR),0) from MP_HISTORY_INTERVAL h2");
		query.append(" where h2.mph_vin=h1.mph_vin and h2.MPH_ORIGIN=0 and h2.MPH_INTERVAL_CODE=h1.MPH_INTERVAL_CODE and ABS(h1.MP_FAILURE_DATE-h2.MP_FAILURE_DATE)<= ")
				.append(secondToMatch)
				.append(" and h2.mph_int_value_month=")
				.append(formatString(sapDto.getIntValue(MpType.MP_MONTH)))
				.append(" ) where h1.MPH_ORIGIN=1 and h1.mph_vin=").append(formatString(sapDto.getVin()))
				.append(" and h1.MPH_INTERVAL_CODE =").append(formatString(sapDto.getIntervalCode()))
				.append(" and h1.MPH_EXACT_VALUE_MONTH=").append(sapDto.retreiveFromExactValueByMpType(MpType.MP_MONTH));

		return query.toString();
	}

	/**
	 * Function for retrieving the coupons for the maintenance history export cron job of 22:00 P.M.
	 * 
	 * @param lastExportDate The date of the last export from which to retrieve the records.
	 * @return The list of coupons.
	 * @throws SystemException Cannot execute query or access to database
	 */
	@Override
	public List<MpHistoryIntervalDto> getCouponsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		StringBuilder query = new StringBuilder();

		SimpleDateFormat expDateSdf = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		expDateSdf.setTimeZone(TimeZone.getTimeZone("UTC"));

		query.append("SELECT "
				+ "    distinct Coupon.MPH_ID,"
				+ "    COALESCE(Contract.CTRT_TYPE, '00') AS Contract_type, "
				+ "    Coupon.MPH_INT_ID, "
				+ "    Coupon.MPH_UPDATE_DATE, "
				+ "    Coupon.MPH_EXACT_VALUE_KM, "
				+ "    Coupon.MPH_EXACT_VALUE_MONTH, "
				+ "    Coupon.MPH_EXACT_VALUE_HOUR, "
				+ "    Coupon.MPH_INT_VALUE_KM, "
				+ "    Coupon.MPH_INT_VALUE_HOUR, "
				+ "    Coupon.MPH_INT_VALUE_MONTH,"
				+ "    Coupon.MPH_PLAN_EXT_ID, "
				+ "    Coupon.MPH_INTERVAL_CODE, "
				+ "    Coupon.MPH_CLAIM_ID, "
				+ "    Coupon.MPH_ORIGIN, "
				+ "    Coupon.MPH_DELETED, "
				+ "    Coupon.MP_FAILURE_DATE, "
				+ "    Coupon.MPH_VIN "
				+ "FROM MP_HISTORY_INTERVAL@ICEWEB Coupon "
				+ "LEFT JOIN mp_contract_vehicle Contract "
				+ "    ON Coupon.MPH_VIN = Contract.SAP_VIN "
				+ "    AND TRUNC((TO_DATE('1970-01-01', 'YYYY-MM-DD') + NUMTODSINTERVAL(Coupon.MPH_EXACT_VALUE_MONTH / 1000, 'SECOND'))) "
				+ "    BETWEEN TRUNC(Contract.START_DATE) AND TRUNC(Contract.END_DATE) "
				+ "WHERE Coupon.MPH_UPDATE_DATE >= TO_DATE('");

		query.append(expDateSdf.format(lastExportDate));

		query.append("', 'dd/MM/yy HH24:MI:SS') ");
		query.append("AND Coupon.MPH_UPDATE_DATE < TO_DATE('");

		query.append(expDateSdf.format(firstExportDate));
		query.append("', 'dd/MM/yy HH24:MI:SS') ");

		return executeQueryN(query.toString());

	}
}
