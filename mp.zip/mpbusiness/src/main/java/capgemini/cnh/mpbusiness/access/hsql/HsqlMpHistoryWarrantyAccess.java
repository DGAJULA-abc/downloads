package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.access.QueryBuilderAccess;
import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;

/**
 * Access to the table MP_HISTORY_WARRANTY.
 * 
 * @author dbabillo
 */
public class HsqlMpHistoryWarrantyAccess extends HsqlAccess implements IMpHistoryWarrantyAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException Cannot get data source.
	 */
	public HsqlMpHistoryWarrantyAccess() throws SystemException {
		super();
	}

	@Override
	protected Dto rs2Dto(ResultSet rs) throws SQLException {
		MpHistoryWarrantyDto dto = new MpHistoryWarrantyDto();

		dto.setVin(getStringIfExists(COL_VIN));
		dto.setWarrantyDate(getStringIfExists(COL_WARRANTY_DATE));
		dto.setMileage(getInt(COL_MILEAGE).intValue());
		dto.setSelectedUsage(getInt(COL_USAGE).intValue());
		dto.setHour(getInt(COL_HOUR).intValue());
		dto.setNowDate(getStringIfExists(COL_DATE));

		return dto;
	}

	@Override
	public boolean create(MpHistoryWarrantyDto pDto) throws SystemException {
		Long ret = null;
		boolean created = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" (");

		queryBuilder.append(COL_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_WARRANTY_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_MILEAGE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_USAGE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(", ");
		queryBuilder.append(COL_DATE);

		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(pDto.getVin()));
		queryBuilder.append(", ");
		queryBuilder.append("STR_TO_DATE(");
		queryBuilder.append(formatString(pDto.getWarrantyDate()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append("), ");
		queryBuilder.append(formatString(pDto.getMileage()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getSelectedUsage()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pDto.getHour()));
		queryBuilder.append(", ");
		queryBuilder.append("STR_TO_DATE(");
		queryBuilder.append(formatString(pDto.getNowDate()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append(")");
		queryBuilder.append(")");

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			created = true;
		}
		return created;
	}

	@Override
	public MpHistoryWarrantyDto read(MpHistoryWarrantyDto pDto) throws SystemException {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT ");
		queryBuilder.append(COL_VIN);
		queryBuilder.append(", DATE_FORMAT(");
		queryBuilder.append(COL_WARRANTY_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append(") AS ");
		queryBuilder.append(COL_WARRANTY_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_USAGE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_MILEAGE);
		queryBuilder.append(", DATE_FORMAT(");
		queryBuilder.append(COL_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append(") AS ");
		queryBuilder.append(COL_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_HOUR);

		queryBuilder.append(" FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_VIN, pDto.getVin());

		pDto = (MpHistoryWarrantyDto) executeQuery1(queryBuilder.toString());
		return pDto;
	}

	@Override
	public boolean update(MpHistoryWarrantyDto pDto) throws SystemException {
		Long ret = null;
		boolean updated = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("UPDATE ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" SET ");

		queryBuilder.append(COL_WARRANTY_DATE);
		queryBuilder.append(" = ");
		queryBuilder.append("STR_TO_DATE(");
		queryBuilder.append(formatString(pDto.getWarrantyDate()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append("), ");

		queryBuilder.append(COL_MILEAGE);
		queryBuilder.append(" = ");
		queryBuilder.append(formatString(pDto.getMileage()));
		queryBuilder.append(", ");

		queryBuilder.append(COL_USAGE);
		queryBuilder.append(" = ");
		queryBuilder.append(formatString(pDto.getSelectedUsage()));
		queryBuilder.append(", ");

		queryBuilder.append(COL_DATE);
		queryBuilder.append(" = ");
		queryBuilder.append("STR_TO_DATE(");
		queryBuilder.append(formatString(pDto.getNowDate()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(HSQL_DATE_FORMAT));
		queryBuilder.append("), ");

		queryBuilder.append(COL_HOUR);
		queryBuilder.append(" = ");
		queryBuilder.append(formatString(pDto.getHour()));

		queryBuilder.append(" WHERE ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_VIN, pDto.getVin());

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	@Override
	public boolean delete(MpHistoryWarrantyDto pDto) throws SystemException {
		Long ret = null;
		boolean deleted = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("DELETE FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		QueryBuilderAccess.equalColumn(queryBuilder, COL_VIN, pDto.getVin());

		ret = executeQueryI(TABLE_NAME, queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			deleted = true;
		}
		return deleted;
	}
}
