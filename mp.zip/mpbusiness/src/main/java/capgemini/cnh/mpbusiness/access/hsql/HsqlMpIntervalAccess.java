package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpIntervalAccess;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * 
 * @author mmartel
 *
 */
public class HsqlMpIntervalAccess extends HsqlAccess<MpIntervalDto> implements IMpIntervalAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpIntervalAccess() throws SystemException {
		super();
	}

	/**
	 * Get the list of intervals for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @param isIveco : true if is Iveco
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervals(Long planId, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT SAP_OPERATION.SAP_GROUP_CODE || SAP_OPERATION.SAP_SUBGROUP_CODE || SAP_OPERATION.SAP_DEFECT_CODE || SAP_OPERATION.SAP_OPERATION_CODE COUPON, INT_ID,  INT_TYPE, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_COMMENT_ID, INT_REPAIR_TIME, INT_CUSTOMER, INT_FLAG_COUPON ");
		if (isIveco)
		{
			query.append(" , ");
			query.append(formatString(Constants.MP_IVECO_FAILURE_CODE_PREFIX));
			query.append(" || SAP_OPERATION.SAP_GROUP_CODE || SAP_OPERATION.SAP_SUBGROUP_CODE || SAP_OPERATION.SAP_DEFECT_CODE || ");
			query.append(formatString(Constants.MP_IVECO_FAILURE_CODE_SUFFIX));
			query.append(" FAILURE_CODE,  SAP_OPERATION.SAP_GROUP_CODE || SAP_OPERATION.SAP_SUBGROUP_CODE || SAP_OPERATION.SAP_DEFECT_CODE DEFECT ");
		}
		else
		{
			query.append(" , ");
			query.append(formatString(Constants.MP_AGCE_FAILURE_CODE_SUFFIX));
			query.append(" FAILURE_CODE ");
			query.append(" ,SAP_OPERATION.SAP_GROUP_CODE || SAP_OPERATION.SAP_SUBGROUP_CODE || SAP_OPERATION.SAP_DEFECT_CODE ");
			query.append(" DEFECT ");

		}

		query.append(" WHERE INT_PLAN_ID =");
		query.append(planId);
		query.append(" AND INT_CODE =SGROUP_NAME");
		query.append(" and FAM_ICECODE = SAP_GROUP_CODE ");
		query.append("and GROUP_ICECODE = SAP_SUBGROUP_CODE ");
		query.append("and SGROUP_ICECODE = SAP_DEFECT_CODE  ");
		query.append(" AND FAM_ICECODE =");
		query.append(formatString(famIceCode));
		query.append(" AND LANG =");
		query.append(formatString(defaultLanguage));

		return executeQueryN(query.toString());
	}

	/**
	 * Get the list of intervals for a maintenance plan and a list of coupons.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param couponsList : a list of coupons
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsByCoupons(Long planId, String[] couponsList, String defaultLanguage, String famIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT SAP_OPERATION.SAP_GROUP_CODE || SAP_OPERATION.SAP_SUBGROUP_CODE || SAP_OPERATION.SAP_DEFECT_CODE || SAP_OPERATION.SAP_OPERATION_CODE COUPON, INT_ID,  INT_TYPE, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_COMMENT_ID, INT_REPAIR_TIME ");
		query.append(" FROM  MP_INTERVAL, VIEW_LOCATIONS, SAP_OPERATION ");
		query.append(" WHERE INT_PLAN_ID =");
		query.append(planId);
		query.append(" AND INT_CODE =SGROUP_NAME");
		query.append(" and FAM_ICECODE = SAP_GROUP_CODE ");
		query.append("and GROUP_ICECODE = SAP_SUBGROUP_CODE ");
		query.append("and SGROUP_ICECODE = SAP_DEFECT_CODE  ");
		query.append(" AND FAM_ICECODE =");
		query.append(formatString(famIceCode));
		query.append(" AND LANG =");
		query.append(formatString(defaultLanguage));
		query.append(" AND INT_CODE IN (select COLUMN_VALUE from table(?)) ");

		return executeQueryNWithInClause(query.toString(), couponsList);
	}

	/**
	 * Get the list of intervals for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsWithoutOperation(Long planId, String defaultLanguage, String famIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT VIEW_LOCATIONS.FAM_ICECODE || VIEW_LOCATIONS.GROUP_ICECODE || VIEW_LOCATIONS.SGROUP_ICECODE COUPON,INT_PLAN_ID, INT_ID,  INT_TYPE, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_COMMENT_ID, INT_REPAIR_TIME, INT_FLAG_COUPON, INT_CUSTOMER  ");
		query.append(" FROM  MP_INTERVAL, VIEW_LOCATIONS ");
		query.append(" WHERE INT_PLAN_ID =");
		query.append(planId);
		query.append(" AND INT_CODE =SGROUP_NAME");
		query.append(" AND FAM_ICECODE =");
		query.append(formatString(famIceCode));
		query.append(" AND LANG =");
		query.append(formatString(defaultLanguage));

		return executeQueryN(query.toString());
	}

	/**
	 * Get a coupon name giving the sub group name.
	 * 
	 * @param intervalCode : interval code name
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the coupon
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getCouponName(String intervalCode, String defaultLanguage, String famIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT VIEW_LOCATIONS.FAM_ICECODE || VIEW_LOCATIONS.GROUP_ICECODE || VIEW_LOCATIONS.SGROUP_ICECODE COUPON ");
		query.append(" FROM   VIEW_LOCATIONS ");
		query.append(" WHERE SGROUP_NAME =");
		query.append(formatString(intervalCode));
		query.append(" AND FAM_ICECODE =");
		query.append(formatString(famIceCode));
		query.append(" AND LANG =");
		query.append(formatString(defaultLanguage));

		return executeQuery1(query.toString());
	}

	/**
	 * Get the list of intervals for a maintenance plan from interval id.
	 * 
	 * @param intervalId :nterval id.
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsFromIntervalId(Long intervalId, String defaultLanguage, String famIceCode) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT VIEW_LOCATIONS.FAM_ICECODE || VIEW_LOCATIONS.GROUP_ICECODE || VIEW_LOCATIONS.SGROUP_ICECODE COUPON,INT_PLAN_ID, INT_ID,  INT_TYPE, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_COMMENT_ID, INT_REPAIR_TIME ");
		query.append(" FROM  MP_INTERVAL, VIEW_LOCATIONS  ");
		query.append(" WHERE INT_PLAN_ID in (select int_plan_id from  MP_INTERVAL where int_id= ");
		query.append(intervalId);
		query.append(" ) ");
		query.append(" AND INT_CODE =SGROUP_NAME");
		query.append(" AND FAM_ICECODE =");
		query.append(formatString(famIceCode));
		query.append(" AND LANG =");
		query.append(formatString(defaultLanguage));

		return executeQueryN(query.toString());
	}

	/**
	 * Get the interval for a maintenance plan and an interval.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param intervalId : interval identifier
	 * @return interval for a maintenance plan and interval identifier
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getMaintenanceInterval(String planId, String intervalId) throws SystemException {

		MpIntervalDto result = new MpIntervalDto();
		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT INT_ID, INT_TYPE, INT_CODE, INT_START_VALUE_KM, INT_START_VALUE_MONTH, INT_START_VALUE_HOUR, INT_AFTER_VALUE_KM, INT_AFTER_VALUE_MONTH, INT_AFTER_VALUE_HOUR, INT_GROUP, INT_COMMENT_ID, INT_REPAIR_TIME ");
		query.append(" FROM MP_INTERVAL ");
		query.append(" WHERE INT_PLAN_ID =");
		query.append(formatString(planId));
		query.append(" AND INT_ID =");
		query.append(formatString(intervalId));

		result = (MpIntervalDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get value of coupon code for tolerance for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @return value of coupon code for tolerance
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getCouponTolerance(String planId) throws SystemException {

		MpIntervalDto result = new MpIntervalDto();
		StringBuilder query = new StringBuilder();

		query.append(
				" SELECT INT_AFTER_VALUE_KM, INT_AFTER_VALUE_HOUR ");
		query.append(" FROM MP_INTERVAL ");
		query.append(" WHERE INT_PLAN_ID =");
		query.append(formatString(planId));
		query.append(" AND (INT_CODE  =");
		query.append(formatString(Constants.COUPON_TOL));
		query.append(" OR INT_CODE  =");
		query.append(formatString(Constants.COUPON_TOL_HARM));
		query.append(" )");

		result = (MpIntervalDto) executeQuery1(query.toString());

		return result;
	}

	/**
	 * Get all the coupons with the description of the coupons by language.
	 * 
	 * @param lang the language
	 * @param famGroupIceCode family and group icecode concatenated.
	 * @return the list of coupons.
	 * @throws SystemException
	 */
	public List<MpIntervalDto> getAllCouponsByLang(String lang, String famGroupIceCode) throws SystemException {
		/*
		 *  select sgroup_name, sap_main_description 
		from SAP_OPERATION_translation, VIEW_LOCATIONS
		where FAM_ICECODE || GROUP_ICECODE ='00500'
		and  FAM_ICECODE = SAP_GROUP_CODE 
		and GROUP_ICECODE = SAP_SUBGROUP_CODE 
		and SGROUP_ICECODE = SAP_DEFECT_CODE
		and sap_language = lang
		        and sgroup_valid <> 2
		
		and lang = 'EN';
		 */

		StringBuilder query = new StringBuilder();

		query.append("select sgroup_name INT_CODE, sap_main_description ");
		query.append(" from SAP_OPERATION_translation, VIEW_LOCATIONS ");
		query.append(" where FAM_ICECODE || GROUP_ICECODE = ");
		query.append(formatString(famGroupIceCode));

		query.append("  and  FAM_ICECODE = SAP_GROUP_CODE ");
		query.append("  and GROUP_ICECODE = SAP_SUBGROUP_CODE ");
		query.append(" and SGROUP_ICECODE = SAP_DEFECT_CODE  ");
		query.append(" and sap_language = lang  ");
		query.append(" and sgroup_valid <> 2 ");
		query.append(" and lang = ");

		query.append(formatString(lang));

		return executeQueryN(query.toString());

	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpIntervalDto rs2Dto(ResultSet rs) throws SQLException {
		// New dto
		MpIntervalDto dto = new MpIntervalDto();

		// Set Dto
		dto.setId(getLongIfExists("INT_ID"));
		dto.setIdPlan(getLongIfExists("INT_PLAN_ID"));
		dto.setType(getStringIfExists("INT_TYPE"));
		dto.setCode(getStringIfExists("INT_CODE"));
		dto.setCoupon(getStringIfExists("COUPON"));
		dto.setFailureCode(getStringIfExists("FAILURE_CODE"));
		dto.setDefect(getStringIfExists("DEFECT"));
		dto.setStartValueKm(getLongIfExists("INT_START_VALUE_KM"));
		dto.setStartValueHour(getLongIfExists("INT_START_VALUE_HOUR"));
		dto.setStartValueMonth(getLongIfExists("INT_START_VALUE_MONTH"));
		dto.setAfterValueKm(getLongIfExists("INT_AFTER_VALUE_KM"));
		dto.setAfterValueHour(getLongIfExists("INT_AFTER_VALUE_HOUR"));
		dto.setAfterValueMonth(getLongIfExists("INT_AFTER_VALUE_MONTH"));
		dto.setRepairTime(getLongIfExists("INT_REPAIR_TIME"));
		dto.setCommentId(getLongIfExists("INT_COMMENT_ID"));
		dto.setGroup(getLongIfExists("INT_GROUP"));
		dto.setRepairTime(getLongIfExists("INT_REPAIR_TIME"));
		dto.setCustomer(getBooleanIfExists("INT_CUSTOMER"));
		if (getBooleanIfExists("INT_FLAG_COUPON") != null)
		{
			dto.setFlag(getBooleanIfExists("INT_FLAG_COUPON").booleanValue());
		}
		dto.setDescription(getStringIfExists("SAP_MAIN_DESCRIPTION"));
		return dto;
	}
}
