package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.dto.MpKitCompositionDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpKitCompositionAccess extends HsqlAccess<MpKitCompositionDto> implements IMpKitCompositionAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpKitCompositionAccess() throws SystemException {
		super();
	}

	/**
	 * @param arg0 the resultset
	 * @throws SQLException an exception
	 * @return a Dto
	 */
	protected MpKitCompositionDto rs2Dto(ResultSet arg0) throws SQLException {

		// New dto
		MpKitCompositionDto dto = new MpKitCompositionDto();

		// Set Dto
		dto.setCompKitCode(getStringIfExists("COMP_KIT_CODE"));
		dto.setCompPnCode(getStringIfExists("COMP_PN_CODE"));
		//dto.setCompDate(Util.dateToString(getDateIfExists("COMP_DATE")));
		dto.setCompPnQty(getDoubleIfExists("COMP_PN_QTY"));
		dto.setCompPnLabel(getStringIfExists("COMP_PN_LABEL"));

		return dto;
	}

	/**
	 * Get the composition (list of part number) of a kit.
	 * 
	 * @param selectedKitId to search
	 * @return a list of associated part number
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpKitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT COMP_PN_CODE, COMP_PN_LABEL, COMP_PN_QTY");
		query.append(" FROM MP_KIT_COMPOSITION");
		query.append(" WHERE COMP_KIT_CODE = ");
		query.append(formatString(selectedKitId));

		return executeQueryN(query.toString());
	}
}
