package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpNextStopAccess;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * @author bmilcend
 */
public class HsqlMpNextStopAccess extends HsqlAccess<MpNextStopDto> implements IMpNextStopAccess {

	/**
	 * Default constructor.
	 *
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpNextStopAccess() throws SystemException {
		super();
	}

	/**
	 * Default constructor.
	 *
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpNextStopAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	@Override
	public Long addNextStop(MpNextStopDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		String proposalDateMonth = null;
		String proposalDateKm = null;
		String proposalDateHour = null;
		if (nextStop.getProposalDate(MpType.MP_MONTH) != null)
		{
			proposalDateMonth = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getProposalDate(MpType.MP_MONTH), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (nextStop.getProposalDate(MpType.MP_HOUR) != null)
		{
			proposalDateHour = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getProposalDate(MpType.MP_HOUR), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (nextStop.getProposalDate(MpType.MP_KM) != null)
		{
			proposalDateKm = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getProposalDate(MpType.MP_KM), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		query.append(" INSERT INTO MP_NEXT_STOP  (VIN, PLAN_ID, COUPON_CODE, NEXT_KM, NEXT_HOUR, NEXT_MONTH , DATE_KM, DATE_HOUR, DATE_MONTH) VALUES (");
		query.append(formatString(nextStop.getVin()));
		query.append(",");
		query.append(formatString(nextStop.getIdPlan()));
		query.append(",");
		query.append(formatString(nextStop.getIntervalCode()));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_KM));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_HOUR));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_MONTH));
		query.append(",");
		query.append(proposalDateKm);
		query.append(",");
		query.append(proposalDateHour);
		query.append(",");
		query.append(proposalDateMonth);
		query.append(")");
		return executeQueryI(query.toString());
	}

	@Override
	public Long addNextStopFlex(MpNextStopDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" INSERT INTO MP_NEXT_FLEX_STOP_WK  (VIN,  COUPON_CODE, NEXT_KM , FROM_CROOM) VALUES (");
		query.append(formatString(nextStop.getVin()));
		query.append(",");
		query.append(formatString(nextStop.getIntervalCode()));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_KM));
		query.append(",");
		query.append(nextStop.getExternal());
		query.append(")");
		return executeQueryI(query.toString());
	}

	@Override
	public Long updateNextStopFlex(MpNextStopDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		String proposalDateKm = null;
		if (nextStop.getProposalDate(MpType.MP_KM) != null)
		{
			proposalDateKm = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getProposalDate(MpType.MP_KM), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		query.append(" UPDATE MP_NEXT_FLEX_STOP_WK  SET  NEXT_KM = ");
		query.append(nextStop.getNextValue(MpType.MP_KM));
		query.append(" ,  DATE_KM  = ");
		query.append(proposalDateKm);
		query.append(" WHERE VIN= ");
		query.append(formatString(nextStop.getVin()));
		query.append(" AND COUPON_CODE= ");
		query.append(formatString(nextStop.getIntervalCode()));
		return executeQueryI(query.toString());
	}

	@Override
	public Long updateNextStopFlexAlertNoValue(String vin, Long currentKm) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" UPDATE MP_NEXT_FLEX_STOP_WK  SET  NEXT_KM = ");
		query.append(currentKm);
		query.append(" WHERE VIN= ");
		query.append(formatString(vin));
		query.append(" AND FROM_CROOM= 1 and NEXT_KM = -1");
		return executeQueryI(query.toString());
	}

	@Override
	public Long deleteNextStopFlexible(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" DELETE FROM MP_NEXT_FLEX_STOP_WK WHERE VIN= ");
		query.append(formatString(vin));
		return executeQueryI(query.toString());
	}

	@Override
	public Long deleteCouponExternalAlert(MpNextStopDto dto) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" DELETE FROM MP_NEXT_FLEX_STOP_WK WHERE FROM_CROOM <> 0 AND VIN= ");
		query.append(formatString(dto.getVin()));
		query.append(" AND COUPON_CODE= ");
		query.append(formatString(dto.getIntervalCode()));

		return executeQueryI(query.toString());
	}

	@Override
	public List<MpNextStopDto> getNextFlexibleStopNotDone(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT VIN, COUPON_CODE, NEXT_KM,FROM_CROOM");
		query.append(" FROM  MP_NEXT_FLEX_STOP_WK ");
		query.append(" WHERE VIN= ");
		query.append(formatString(vin));
		query.append(" AND (VIN, COUPON_CODE) not in (select VIN, COUPON_CODE from MP_FLEX_DONE_WK WHERE VIN= ");
		query.append(formatString(vin));
		query.append(" ) ");
		// Execute the query and get the result list
		List<MpNextStopDto> result = executeQueryN(query.toString());
		return result;
	}

	@Override
	public Long deleteNextStop(List<String> lstPinVin) throws SystemException {

		String vinList = StringUtils.join(lstPinVin.toArray(), "','");
		StringBuilder query = new StringBuilder();
		query.append(" DELETE FROM MP_NEXT_STOP WHERE VIN in ('");
		query.append(vinList);
		query.append("')");
		return executeQueryI(query.toString());
	}

	@Override
	public List<MpNextStopDto> getNextStops(List<String> lstPinVin) throws SystemException {
		StringBuilder query = new StringBuilder();
		String vinList = StringUtils.join(lstPinVin.toArray(), "','");
		query.append(" SELECT PLAN_ID,VIN,COUPON_CODE,NEXT_MONTH,NEXT_HOUR,NEXT_KM,DATE_HOUR,DATE_KM,DATE_MONTH FROM MP_NEXT_STOP WHERE VIN in('");
		query.append(vinList);
		query.append("')");
		return executeQueryN(query.toString());
	}

	@Override
	public MpNextStopDto getNextStop(String vin, String coupon) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT PLAN_ID,VIN,COUPON_CODE,NEXT_MONTH,NEXT_HOUR,NEXT_KM,DATE_HOUR,DATE_KM,DATE_MONTH FROM MP_NEXT_STOP WHERE VIN= ");
		query.append(formatString(vin));
		query.append(" AND COUPON_CODE=");
		query.append(formatString(coupon));
		return executeQuery1(query.toString());
	}

	@Override
	public List<MpNextStopDto> getAllNextStopFlexibles(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT VIN, COUPON_CODE, NEXT_KM, FROM_CROOM FROM MP_NEXT_FLEX_STOP_WK WHERE VIN= ");
		query.append(formatString(vin));
		return executeQueryN(query.toString());
	}

	@Override
	public boolean checkPlanChange(List<String> lstPinVin, Long planId) throws SystemException {
		String vinList = StringUtils.join(lstPinVin.toArray(), "','");

		boolean result = true;
		StringBuilder query = new StringBuilder();
		query.append(" SELECT count(*) as nb FROM MP_NEXT_STOP WHERE VIN in ('");
		query.append(vinList);
		query.append("') AND  PLAN_ID = ");
		query.append(planId);
		Long nbPlans = executeQueryCount(query.toString(), "nb");
		if (nbPlans.compareTo(0L) > 0)
		{
			result = false;
		}
		return result;
	}

	@Override
	protected MpNextStopDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpNextStopDto dto = new MpNextStopDto();

		dto.setVin(getStringIfExists("VIN"));
		dto.setIdPlan(getLongIfExists("PLAN_ID"));
		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		dto.setNextValue(MpType.MP_MONTH, getLongIfExists("NEXT_MONTH"));
		dto.setNextValue(MpType.MP_HOUR, getLongIfExists("NEXT_HOUR"));
		dto.setNextValue(MpType.MP_KM, getLongIfExists("NEXT_KM"));
		dto.setProposalDate(MpType.MP_HOUR, getDateIfExists("DATE_HOUR"));
		dto.setProposalDate(MpType.MP_KM, getDateIfExists("DATE_KM"));
		dto.setProposalDate(MpType.MP_MONTH, getDateIfExists("DATE_MONTH"));
		dto.setExternal(getIntIfExists("FROM_CROOM"));

		return dto;
	}

	@Override
	public MpNextStopDto getNextStopFlexible(String vin, String coupon, Integer fromCroom) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT VIN, COUPON_CODE, NEXT_KM, FROM_CROOM FROM MP_NEXT_FLEX_STOP_WK  WHERE VIN= ");
		query.append(formatString(vin));
		query.append(" AND COUPON_CODE=");
		query.append(formatString(coupon));
		query.append(" AND FROM_CROOM=");
		query.append(fromCroom);
		return executeQuery1(query.toString());
	}

	public void setNextStopComparison(String vin, Integer comparisonResult, String edsNextStopJson, String etimNextStopJson) throws SystemException {

		LocalDateTime now = LocalDateTime.now();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String formattedDateCreation = now.format(formatter);

		StringBuilder query = new StringBuilder();

		query.append(" INSERT INTO MP_Nextstop_Comparison (MP_Nextstop_Comparison_ID, EDS_NEXTSTOP_JSON, ETIM_NEXTSTOP_JSON, COMPARISON_RESULTS_JSON, COMPARISON_DATE, VIN)");

		query.append("VALUES (");
		query.append("SQ_MP_NEXTSTOP_COMPARISON_ID.NEXTVAL");
		query.append(",");
		query.append(formatString(edsNextStopJson));
		query.append(",");
		query.append(formatString(etimNextStopJson));
		query.append(",");
		query.append(formatString(comparisonResult));
		query.append(",");
		query.append("TO_DATE('" + formattedDateCreation + "', 'YYYY-MM-DD HH24:MI:SS')");
		query.append(",");
		query.append(formatString(vin));
		query.append(")");

		executeQueryI(query.toString());

	}

}
