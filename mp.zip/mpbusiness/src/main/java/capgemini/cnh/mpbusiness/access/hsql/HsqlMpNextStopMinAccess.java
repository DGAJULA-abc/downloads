package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.externals.eds.model.EdsComparisonDto;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.dto.MpCallStatus;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * @author bmilcend
 */
public class HsqlMpNextStopMinAccess extends HsqlAccess<MpNextStopMinDto> implements IMpNextStopMinAccess {

	/**
	 * Default constructor.
	 *
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpNextStopMinAccess() throws SystemException {
		super();
	}

	/**
	 * Default constructor.
	 *
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpNextStopMinAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	@Override
	public Long addMpNextStopMin(MpNextStopMinDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		String minProposalDateMonth = null;
		String minProposalDateHour = null;
		String minProposalDateKm = null;
		String callStatus = null;

		if (nextStop.getMinProposalDate(MpType.MP_MONTH) != null)
		{
			minProposalDateMonth = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getMinProposalDate(MpType.MP_MONTH), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (nextStop.getMinProposalDate(MpType.MP_HOUR) != null)
		{
			minProposalDateHour = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getMinProposalDate(MpType.MP_HOUR), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (nextStop.getMinProposalDate(MpType.MP_KM) != null)
		{
			minProposalDateKm = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getMinProposalDate(MpType.MP_KM), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		query.append(
				" INSERT INTO MP_NEXT_STOP_MIN  (VIN, PLAN_ID, CONTRACT_NB, NEXT_KM, NEXT_HOUR, NEXT_MONTH , DATE_PROPOSAL_KM, DATE_PROPOSAL_HOUR, DATE_PROPOSAL_MONTH, CURRENT_MILEAGE, CURRENT_HOUR, ALERT_KM,ALERT_HOUR,ALERT_MONTH,CALL_STATUS,ALERT_GROUP_ID ) VALUES (");
		query.append(formatString(nextStop.getVin()));
		query.append(",");
		query.append(formatString(nextStop.getIdPlan()));
		query.append(",");
		query.append(formatString(nextStop.getContractNb()));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_KM));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_HOUR));
		query.append(",");
		query.append(nextStop.getNextValue(MpType.MP_MONTH));
		query.append(",");
		query.append(minProposalDateKm);
		query.append(",");
		query.append(minProposalDateHour);
		query.append(",");
		query.append(minProposalDateMonth);
		query.append(",");
		query.append(nextStop.getCurrentMileage());
		query.append(",");
		query.append(nextStop.getCurrentHour());
		query.append(",");
		query.append(nextStop.getAlert(MpType.MP_KM));
		query.append(",");
		query.append(nextStop.getAlert(MpType.MP_HOUR));
		query.append(",");
		query.append(nextStop.getAlert(MpType.MP_MONTH));
		query.append(",");
		query.append(callStatus);
		query.append(",");
		query.append(nextStop.getAlertGroupId());
		query.append(")");
		return executeQueryI(query.toString());
	}

	@Override
	public Long deleteMpNextStopMin(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" DELETE FROM MP_NEXT_STOP_MIN WHERE VIN= ");
		query.append(formatString(vin));
		return executeQueryI(query.toString());
	}

	@Override
	public MpNextStopMinDto getMpNextStopMin(List<String> lstPinVin) throws SystemException {
		StringBuilder query = new StringBuilder();
		String vinList = StringUtils.join(lstPinVin.toArray(), "','");

		query.append(
				" SELECT VIN, PLAN_ID, CONTRACT_NB, NEXT_KM, NEXT_HOUR, NEXT_MONTH ,DATE_PROPOSAL_KM,DATE_PROPOSAL_HOUR,DATE_PROPOSAL_MONTH,CURRENT_MILEAGE, CURRENT_HOUR,ALERT_KM,ALERT_HOUR,ALERT_MONTH,CALL_STATUS,ALERT_GROUP_ID FROM MP_NEXT_STOP_MIN WHERE VIN in ('");
		query.append(vinList);
		query.append("') ");
		return executeQuery1(query.toString());
	}

	@Override
	public MpNextStopMinDto getMpNextStopMinWithLastMileage(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(
				" SELECT MP_VEHICLE_KM_HOUR_AV.CURRENT_KM, MP_NEXT_STOP_MIN.VIN, PLAN_ID, CONTRACT_NB, NEXT_KM, NEXT_HOUR, NEXT_MONTH ,DATE_PROPOSAL_KM,DATE_PROPOSAL_HOUR,DATE_PROPOSAL_MONTH,MP_NEXT_STOP_MIN.CURRENT_MILEAGE, MP_NEXT_STOP_MIN.CURRENT_HOUR,ALERT_KM,ALERT_HOUR,ALERT_MONTH FROM MP_NEXT_STOP_MIN LEFT JOIN MP_VEHICLE_KM_HOUR_AV ON MP_VEHICLE_KM_HOUR_AV.VIN=MP_NEXT_STOP_MIN.VIN WHERE MP_NEXT_STOP_MIN.VIN= ");
		query.append(formatString(vin));
		return executeQuery1(query.toString());
	}

	@Override
	public Long updateNextStopMinProposalDate(MpNextStopMinDto minNextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		String minProposalDateMonth = null;
		String minProposalDateHour = null;
		String minProposalDateKm = null;
		if (minNextStop.getMinProposalDate(MpType.MP_MONTH) != null)
		{
			minProposalDateMonth = "TO_DATE (" + formatString(UtilDate.dateToString(minNextStop.getMinProposalDate(MpType.MP_MONTH), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (minNextStop.getMinProposalDate(MpType.MP_HOUR) != null)
		{
			minProposalDateHour = "TO_DATE (" + formatString(UtilDate.dateToString(minNextStop.getMinProposalDate(MpType.MP_HOUR), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		if (minNextStop.getMinProposalDate(MpType.MP_KM) != null)
		{
			minProposalDateKm = "TO_DATE (" + formatString(UtilDate.dateToString(minNextStop.getMinProposalDate(MpType.MP_KM), "dd/MM/yyyy")) + ", 'DD/MM/YYYY')";
		}
		query.append(" UPDATE MP_NEXT_STOP_MIN SET DATE_PROPOSAL_KM = ");
		query.append(minProposalDateKm);
		query.append(" , DATE_PROPOSAL_HOUR = ");
		query.append(minProposalDateHour);
		query.append(" , DATE_PROPOSAL_MONTH = ");
		query.append(minProposalDateMonth);
		query.append("  , ALERT_KM = ");
		query.append(minNextStop.getAlert(MpType.MP_KM));
		query.append(" , ALERT_HOUR = ");
		query.append(minNextStop.getAlert(MpType.MP_HOUR));
		query.append(" , ALERT_MONTH = ");
		query.append(minNextStop.getAlert(MpType.MP_MONTH));
		if (minNextStop.getCurrentMileage() != null)
		{
			query.append(" , CURRENT_MILEAGE = ");
			query.append(minNextStop.getCurrentMileage());
		}
		if (minNextStop.getCurrentHour() != null)
		{
			query.append(" , CURRENT_HOUR = ");
			query.append(minNextStop.getCurrentHour());
		}
		query.append(" , ALERT_GROUP_ID = ");
		query.append(minNextStop.getAlertGroupId());
		query.append(" WHERE VIN= ");
		query.append(formatString(minNextStop.getVin()));
		return executeQueryI(query.toString());
	}

	/**
	 * Get VIN list with updated plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPlan() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT MP_NEXT_STOP_MIN.VIN ");
		query.append(" FROM MP_NEXT_STOP_MIN, MP_FLEX_CONTRACT_WK ");
		query.append(" where MP_NEXT_STOP_MIN.VIN = MP_FLEX_CONTRACT_WK.VIN ");
		query.append(" and (MP_NEXT_STOP_MIN.PLAN_ID <> MP_FLEX_CONTRACT_WK.PLAN_ID ");
		query.append(" OR MP_NEXT_STOP_MIN.CONTRACT_NB <> MP_FLEX_CONTRACT_WK.SAP_CONTRACT) ");

		// Execute the query and get the result list
		List<MpNextStopMinDto> result = executeQueryN(query.toString());
		return result;
	}

	/**
	 * Get VIN list with updated performance EDS.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPerformanceEDS() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT MP_NEXT_FLEX_STOP_WK.VIN ");
		query.append(" FROM  MP_NEXT_FLEX_STOP_WK, MP_NEXT_FLEX_STOP_WK_SAVE ");
		query.append(" WHERE MP_NEXT_FLEX_STOP_WK.VIN = MP_NEXT_FLEX_STOP_WK_SAVE.VIN ");
		query.append(" AND MP_NEXT_FLEX_STOP_WK.COUPON_CODE = MP_NEXT_FLEX_STOP_WK_SAVE.COUPON_CODE ");
		query.append(" AND MP_NEXT_FLEX_STOP_WK.NEXT_KM <> MP_NEXT_FLEX_STOP_WK_SAVE.NEXT_KM ");
		query.append(" AND MP_NEXT_FLEX_STOP_WK.FROM_CROOM = 0 ");
		query.append(" AND MP_NEXT_FLEX_STOP_WK_SAVE.FROM_CROOM = 0 ");

		// Execute the query and get the result list
		List<MpNextStopMinDto> result = executeQueryN(query.toString());
		return result;
	}

	/**
	 * Get VIN list with coupon in overdue.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithCouponOverdue() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT MP_NEXT_STOP_MIN.VIN, MP_NEXT_STOP_MIN.PLAN_ID ");
		query.append(" FROM MP_NEXT_STOP_MIN, MP_VEHICLE_KM_HOUR_AV ");
		query.append(" WHERE MP_NEXT_STOP_MIN.VIN = MP_VEHICLE_KM_HOUR_AV.VIN ");
		query.append(" AND (MP_NEXT_STOP_MIN.NEXT_KM < MP_VEHICLE_KM_HOUR_AV.CURRENT_KM ");
		query.append(" OR MP_NEXT_STOP_MIN.NEXT_HOUR < MP_VEHICLE_KM_HOUR_AV.CURRENT_HOUR ");
		query.append(" OR MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH < sysdate)");

		// Execute the query and get the result list
		List<MpNextStopMinDto> result = executeQueryN(query.toString());
		return result;
	}

	/**
	 * Update the proposal date into the table .
	 *
	 * @return
	 * @throws SystemException SystemException
	 */
	public Long updateNextStopProposalDate() throws SystemException {
		StringBuilder query = new StringBuilder();
		//Update the date_proposal with the min value between the date_km, date_hour and date_month
		query.append(" UPDATE MP_NEXT_STOP_MIN ");
		query.append(" set DATE_PROPOSAL_KM = ");
		query.append(" (SELECT ((NEXT_KM - CURRENT_KM) / AVERAGE_KM) + sysdate ");
		query.append(" FROM MP_VEHICLE_KM_HOUR_AV WHERE MP_NEXT_STOP_MIN.VIN = MP_VEHICLE_KM_HOUR_AV.VIN   ");
		query.append(" AND AVERAGE_KM >= 1 AND AVERAGE_KM is not null ");
		query.append(" AND NEXT_KM is not null AND NEXT_KM <> 0 AND  NEXT_KM <> -1), ");
		query.append(" DATE_PROPOSAL_HOUR = ");
		query.append(" (SELECT ((NEXT_HOUR - MP_VEHICLE_KM_HOUR_AV.CURRENT_HOUR) / AVERAGE_HOUR) + sysdate ");
		query.append(" FROM MP_VEHICLE_KM_HOUR_AV WHERE MP_NEXT_STOP_MIN.VIN = MP_VEHICLE_KM_HOUR_AV.VIN ");
		query.append(" AND AVERAGE_HOUR >= 1 AND AVERAGE_HOUR is not null ");
		query.append(" AND NEXT_HOUR is not null AND NEXT_HOUR <> 0 AND  NEXT_HOUR <> -1) ");
		query.append(" WHERE EXISTS (SELECT 1 ");
		query.append(" FROM mp_vehicle_km_hour_av ");
		query.append(" WHERE mp_next_stop_min.vin = mp_vehicle_km_hour_av.vin) ");

		return executeQueryI(query.toString());
	}

	/**
	 * Get VIN list with new plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithNewPlan() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT MP_FLEX_CONTRACT_WK.VIN, MP_FLEX_CONTRACT_WK.PLAN_ID ");
		query.append(" FROM  MP_FLEX_CONTRACT_WK ");
		query.append(" MINUS ");
		query.append(" SELECT MP_NEXT_STOP_MIN.VIN, MP_NEXT_STOP_MIN.PLAN_ID ");
		query.append(" FROM  MP_NEXT_STOP_MIN ");

		// Execute the query and get the result list
		List<MpNextStopMinDto> result = executeQueryN(query.toString());
		return result;
	}

	/**
	 * Set the flag to 1 for new KM alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public Long setFlagForNewKmAlerts() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" UPDATE MP_NEXT_STOP_MIN ");
		query.append(" SET ALERT_KM = 1  ");
		query.append(" WHERE MP_NEXT_STOP_MIN.VIN IN ");
		query.append(" (SELECT distinct MNSM.VIN ");
		query.append(" FROM MP_ALERT_TOLERANCE MAT, MP_VEHICLE_KM_HOUR_AV  MVHKA, MP_NEXT_STOP_MIN MNSM, MP_FLEX_CONTRACT_WK MCFW ");
		query.append(" WHERE  MNSM.PLAN_ID = MAT.PLAN_ID ");
		query.append(" AND MNSM.VIN = MVHKA.VIN ");
		query.append(" AND MCFW.VIN = MNSM.VIN ");
		query.append(" AND ((MNSM.NEXT_KM - MVHKA.CURRENT_KM) <= MAT.TOL_KM AND MNSM.NEXT_KM is not null AND MNSM.NEXT_KM <> 0 AND MNSM.NEXT_KM <> -1)) ");

		return executeQueryI(query.toString());
	}

	/**
	 * Set the flag to 1 for new Hour alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public Long setFlagForNewHourAlerts() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" UPDATE MP_NEXT_STOP_MIN ");
		query.append(" SET ALERT_HOUR = 1  ");
		query.append(" WHERE MP_NEXT_STOP_MIN.VIN IN ");
		query.append(" (SELECT distinct MNSM.VIN ");
		query.append(" FROM MP_ALERT_TOLERANCE MAT, MP_VEHICLE_KM_HOUR_AV  MVHKA, MP_NEXT_STOP_MIN MNSM, MP_FLEX_CONTRACT_WK MCFW ");
		query.append(" WHERE  MNSM.PLAN_ID = MAT.PLAN_ID ");
		query.append(" AND MNSM.VIN = MVHKA.VIN ");
		query.append(" AND MCFW.VIN = MNSM.VIN ");
		query.append(" AND ((MNSM.NEXT_HOUR - MVHKA.CURRENT_HOUR) <= MAT.TOL_HOUR AND MNSM.NEXT_HOUR is not null AND MNSM.NEXT_HOUR <> 0 AND MNSM.NEXT_HOUR <> -1)) ");

		return executeQueryI(query.toString());
	}

	/**
	 * Set the flag to 1 for new Month alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public Long setFlagForNewMonthAlerts() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" UPDATE MP_NEXT_STOP_MIN ");
		query.append(" SET ALERT_MONTH = 1  ");
		query.append(" WHERE MP_NEXT_STOP_MIN.VIN IN ");
		query.append(" (SELECT distinct MNSM.VIN ");
		query.append(" FROM MP_ALERT_TOLERANCE MAT, MP_VEHICLE_KM_HOUR_AV  MVHKA, MP_NEXT_STOP_MIN MNSM, MP_FLEX_CONTRACT_WK MCFW ");
		query.append(" WHERE  MNSM.PLAN_ID = MAT.PLAN_ID ");
		query.append(" AND MNSM.VIN = MVHKA.VIN ");
		query.append(" AND MCFW.VIN = MNSM.VIN ");
		query.append(" AND (ADD_MONTHS(MNSM.date_proposal_month,-tol_month) <= sysdate AND  MNSM.date_proposal_month is not null)) ");

		return executeQueryI(query.toString());
	}

	/**
	 * Update call state of MpNextStopMin .
	 *
	 * @throws SystemException SystemException
	 */
	@Override
	public boolean updateCallStatus(String vin, Integer mpCallStatusValue) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" UPDATE MP_NEXT_STOP_MIN ");
		query.append(" SET CALL_STATUS =");
		query.append(mpCallStatusValue);
		query.append(" WHERE MP_NEXT_STOP_MIN.VIN='");
		query.append(vin);
		query.append("'");
		return executeQuery0(query.toString());

	}

	@Override
	protected MpNextStopMinDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpNextStopMinDto dto = new MpNextStopMinDto();

		dto.setVin(getStringIfExists("VIN"));
		dto.setIdPlan(getLongIfExists("PLAN_ID"));
		dto.setContractNb(getStringIfExists("CONTRACT_NB"));
		dto.setNextValue(MpType.MP_MONTH, getLongIfExists("NEXT_MONTH"));
		dto.setNextValue(MpType.MP_HOUR, getLongIfExists("NEXT_HOUR"));
		dto.setNextValue(MpType.MP_KM, getLongIfExists("NEXT_KM"));
		dto.setMpCallStatus(MpCallStatus.getMpCallStatusFromValue(getIntIfExists("CALL_STATUS")));
		dto.setMinProposalDate(MpType.MP_KM, getDateIfExists("DATE_PROPOSAL_KM"));
		dto.setMinProposalDate(MpType.MP_HOUR, getDateIfExists("DATE_PROPOSAL_HOUR"));
		dto.setMinProposalDate(MpType.MP_MONTH, getDateIfExists("DATE_PROPOSAL_MONTH"));

		dto.setAlert(MpType.MP_KM, getIntIfExists("ALERT_KM"));
		dto.setAlert(MpType.MP_HOUR, getIntIfExists("ALERT_HOUR"));
		dto.setAlert(MpType.MP_MONTH, getIntIfExists("ALERT_MONTH"));

		if (getLongIfExists("CURRENT_KM") != null && getLongIfExists("CURRENT_MILEAGE") != null)
		{
			if (getLongIfExists("CURRENT_KM") > getLongIfExists("CURRENT_MILEAGE"))
			{
				dto.setCurrentMileage(getLongIfExists("CURRENT_KM"));
			}
			else
			{
				dto.setCurrentMileage(getLongIfExists("CURRENT_MILEAGE"));
			}
		}
		else
		{
			dto.setCurrentMileage(getLongIfExists("CURRENT_MILEAGE"));
		}

		dto.setCurrentHour(getLongIfExists("CURRENT_HOUR"));
		dto.setAlertGroupId(getLongIfExists("ALERT_GROUP_ID"));
		return dto;
	}

	@Override
	public Map<String, Date> getProposalDateByVin(Set<String> vins) throws SystemException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Date> getProposalDateByVinInAlertNotInVins(Set<String> vins) throws SystemException {
		// TODO Auto-generated method stub
		return null;
	}

}
