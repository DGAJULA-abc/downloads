package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.access.Table;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.access.table.Consumables;
import capgemini.cnh.framework.access.table.statik.CONSUMABLES;
import capgemini.cnh.framework.access.table.statik.CONS_BRAND;
import capgemini.cnh.framework.access.table.statik.MP_CONSUMABLE_APPLICABILITY;
import capgemini.cnh.framework.access.table.statik.MP_OPERATION_CONSUMABLE;
import capgemini.cnh.framework.access.table.statik.MP_OPERATION_SERIES;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.mpbusiness.access.IMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;

/**
 * 
 * @author mamestoy
 *
 */
public class HsqlMpOperationConsumableAccess extends HsqlAccess<MpOperationConsumableDto> implements IMpOperationConsumableAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpOperationConsumableAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpOperationConsumableDto> getListConsumablesByOp(Long idSeriesOperation, String language, String defaultLanguage, Long brandId, IceContextDto context) throws SystemException {
		/* Query example:
		 * select distinct 
		 * mp_operation_consumable.ope_cons_id
		 * , mp_operation_consumable.ope_cons_cn_id
		 * , mp_operation_consumable.ope_cons_qty
		 * , mp_operation_consumable.ope_cons_unit
		 * , consumables.cn_brandid
		 * , consumables.cn_description
		 * , consumables.cn_group
		 * , consumables.cn_name
		 * , cons_brand.brand_prefix
		 * , mp_consumable_applicability.appli_config 
		 * 
		 * from 
		 * 
		 * mp_operation_consumable 
		 * inner join consumables on mp_operation_consumable.ope_cons_cn_id = consumables.cn_id 
		 * inner join mp_operation_series on mp_operation_consumable.ope_cons_ope_series_id = mp_operation_series.ope_ser_id and mp_operation_series.ope_ser_id = '677' 
		 * left join mp_consumable_applicability on mp_operation_consumable.ope_cons_id = mp_consumable_applicability.appli_cons_id 
		 * left join cons_brand on consumables.cn_brandid = cons_brand.cons_brand_id and cons_brand.brand_id = '2' 
		 * 
		 * where 
		 * 
		 * mp_operation_series.ope_app_bra = '2' 
		 * and mp_operation_series.ope_app_typ = '1' 
		 * and mp_operation_series.ope_app_pro = '40' 
		 * and mp_operation_series.ope_app_ser = '186' 
		 * and (consumables.cn_lg = 'IT' or (consumables.cn_lg = 'EN' and mp_operation_consumable.ope_cons_cn_id not in (select c.cn_id from consumables c where c.cn_lg = 'IT'))) 
		 * and (mp_consumable_applicability.appli_mod = 'IT' or mp_consumable_applicability.appli_mod is null) 
		 * and (mp_consumable_applicability.appli_tt = 'IT' or mp_consumable_applicability.appli_tt is null) 
		 * and (mp_consumable_applicability.appli_market = '001' or mp_consumable_applicability.appli_market is null);
		 */
		QueryBuilder builder = QueryBuilder.createQueryBuilder(true);
		builder.selectDistinct()
				.select(MP_OPERATION_CONSUMABLE.OPE_CONS_ID)
				.select(MP_OPERATION_CONSUMABLE.OPE_CONS_CN_ID)
				.select(MP_OPERATION_CONSUMABLE.OPE_CONS_QTY)
				.select(MP_OPERATION_CONSUMABLE.OPE_CONS_UNIT)
				.select(CONSUMABLES.CN_BRANDID)
				.select(CONSUMABLES.CN_DESCRIPTION)
				.select(CONSUMABLES.CN_GROUP)
				.select(CONSUMABLES.CN_NAME)
				.select(CONSUMABLES.CN_PARTNUMBER)
				.select(CONS_BRAND.BRAND_PREFIX)
				.select(MP_CONSUMABLE_APPLICABILITY.APPLI_CONFIG)

				.from(MP_OPERATION_CONSUMABLE.table())
				.innerJoinColumn(MP_OPERATION_CONSUMABLE.OPE_CONS_CN_ID, CONSUMABLES.CN_ID)
				.innerJoinColumn(MP_OPERATION_CONSUMABLE.OPE_CONS_OPE_SERIES_ID, MP_OPERATION_SERIES.OPE_SER_ID).joinValue(MP_OPERATION_SERIES.OPE_SER_ID, idSeriesOperation)

				.leftJoin(MP_OPERATION_CONSUMABLE.OPE_CONS_ID, MP_CONSUMABLE_APPLICABILITY.APPLI_CONS_ID)
				//.leftJoin(CONSUMABLES.CN_BRANDID, CONS_BRAND.CONS_BRAND_ID).joinValue(CONS_BRAND.BRAND_ID, brandId)
				// The method innerJoinColumn doesn't allow adding parenthesis between the 'on' and the columns
				.append(" inner join cons_brand on ((consumables.cn_brandid = cons_brand.cons_brand_id or consumables.cn_brandid = '0') and cons_brand.brand_id = ")
				.append(formatString(brandId))
				.append(") ")

				.where();
		builder.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_BRA, context.getBrand() != null ? context.getBrand().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_TYP, context.getType() != null ? context.getType().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_PRO, context.getProduct() != null ? context.getProduct().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_SER, context.getSeries() != null ? context.getSeries().getIceCode() : null);
		// -- filter on language get default language if current not available
		builder.where().openBracket().equalValue(CONSUMABLES.CN_LG, language)
				.or().openBracket().equalValue(CONSUMABLES.CN_LG, defaultLanguage)
				.and().term(MP_OPERATION_CONSUMABLE.OPE_CONS_CN_ID).not().in().openBracket();
		Consumables c = Table.valueOf(Consumables.class, "c");
		builder.append(QueryBuilder.createQueryBuilder(true).select(c.CN_ID).from(c).whereEqualValue(c.CN_LG, language));
		builder.closeBracket().closeBracket().closeBracket();

		if (context.getModel() != null)
		{
			builder.whereEqualValueOrIsNull(MP_CONSUMABLE_APPLICABILITY.APPLI_MOD, context.getModel().getIceCode());
			if (context.getTechnicalType() != null)
			{
				builder.whereEqualValueOrIsNull(MP_CONSUMABLE_APPLICABILITY.APPLI_TT, context.getTechnicalType().getIceCode());
			}
		}
		if (context.getMarket() != null && context.getMarket().getMkId() != null)
		{
			builder.whereEqualValueOrIsNull(MP_CONSUMABLE_APPLICABILITY.APPLI_MARKET, context.getMarket().getMkId().intValue());
		}

		List<MpOperationConsumableDto> result = executeQueryN(builder);
		return (result);
	}

	@Override
	protected MpOperationConsumableDto rs2Dto(ResultSet rs) throws SQLException {
		MpOperationConsumableDto dto = new MpOperationConsumableDto(ComplexConfigDto.valueOf(getColumnIfExist(MP_CONSUMABLE_APPLICABILITY.APPLI_CONFIG)));

		dto.setId(getColumnIfExist(MP_OPERATION_CONSUMABLE.OPE_CONS_ID));
		dto.setIdConsumable(getColumnIfExist(MP_OPERATION_CONSUMABLE.OPE_CONS_CN_ID));
		Float qty = getColumnIfExist(MP_OPERATION_CONSUMABLE.OPE_CONS_QTY);
		if (qty != null)
		{
			dto.setQuantity(new StringBuilder().append(qty.toString()).append(" ").append(getColumnIfExist(MP_OPERATION_CONSUMABLE.OPE_CONS_UNIT)).toString());
			dto.setQty(qty);
			dto.setUnit(getColumnIfExist(MP_OPERATION_CONSUMABLE.OPE_CONS_UNIT).trim());
		}
		dto.setBrandId(getColumnIfExist(CONSUMABLES.CN_BRANDID));
		dto.setDescription(getColumnIfExist(CONSUMABLES.CN_DESCRIPTION));
		String group = getColumnIfExist(CONSUMABLES.CN_GROUP);
		String name = getColumnIfExist(CONSUMABLES.CN_NAME);
		dto.setConsumable(new StringBuilder().append(group).append(" - ").append(name).toString());
		dto.setBrandPrefix(getColumnIfExist(CONS_BRAND.BRAND_PREFIX));
		dto.setPartnumber(getColumnIfExist(CONSUMABLES.CN_PARTNUMBER));

		return dto;
	}

	@Override
	public MpOperationConsumableDto getConsumablesPnByConsIdAndCountryAndMarket(Long consId, Long consOccId, String country, String marketId) throws SystemException {
		StringBuilder query = new StringBuilder();

		// select CN_ID,CN_OCC_ID,CN_OCC_PART,CN_OCC_P_MK_ID,CN_OCC_P_COUNTRY from CONSUMABLES_OCCURRENCE_PART where cn_id = and CN_OCC_ID and CN_OCC_P_MK_ID and CN_OCC_P_COUNTRY;

		query.append(" select CN_OCC_PART as " + CONSUMABLES.CN_PARTNUMBER.getColumnName());
		query.append(" from CONSUMABLES_OCCURRENCE_PART ");
		query.append(" where cn_id = ").append(consId);
		query.append(" and cn_occ_id = ").append(consOccId);
		query.append(" and CN_OCC_P_MK_ID = ").append(formatString(marketId));
		query.append(" and CN_OCC_P_COUNTRY = ").append(formatString(country));

		return executeQuery1(query.toString());
	}

	@Override
	public MpOperationConsumableDto getConsumablesOccByConsId(Long consId, boolean defaultLanguage, IceContextDto dtoIceContext) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT CLC.CN_ID AS " + MP_OPERATION_CONSUMABLE.OPE_CONS_CN_ID.getColumnName());
		query.append(" , CO.CN_OCC_NAME AS " + CONSUMABLES.CN_DESCRIPTION.getColumnName());
		query.append(" , COP.CN_OCC_PART AS  " + CONSUMABLES.CN_PARTNUMBER.getColumnName());
		query.append(" FROM CONS_BRAND CB, CONSUMABLES_LIST_CONTENT CLC, CONSUMABLES_OCCURRENCES  CO, CONSUMABLES C, CONSUMABLES_LIST_APP CLP, CONSUMABLES_LIST CL, CONSUMABLES_OCCURRENCE_PART COP ");
		query.append(" WHERE ( CLP.CN_LIST_MK_ID = " + dtoIceContext.getMarketId() + " OR CLP.CN_LIST_MK_ID = -1 ) ");
		query.append(" AND ( UPPER(CLP.CN_LIST_COUNTRY) = " + formatString(dtoIceContext.getCountry().toUpperCase()) + " OR CLP.CN_LIST_COUNTRY = '-1' ) ");
		query.append(" AND ( CLP.CN_LIST_BRAND_ICECODE = " + formatString(dtoIceContext.getBrand().getIceCode()) + " OR CLP.CN_LIST_BRAND_ICECODE = '-1' ) ");
		query.append(" AND CLC.CN_ID = " + consId);
		query.append(" AND CB.BRAND_ID = " + dtoIceContext.getBrand().getId());
		query.append(" AND ( CB.CONS_BRAND_ID = CLC.CN_BRANDID OR CLC.CN_BRANDID = 0 ) ");
		query.append(" AND CLC.CN_ID = CO.CN_ID ");
		query.append(" AND CO.CN_ID = COP.CN_ID(+) ");
		query.append(" AND CO.CN_OCC_ID = COP.CN_OCC_ID(+) ");
		query.append(" AND ( CLC.CN_BRANDID = CO.CN_OCC_TIDB_BRAND OR CO.CN_OCC_TIDB_BRAND = 0 ) ");
		query.append(" AND CLC.CN_OCC_ID(+) = CO.CN_OCC_ID ");
		query.append(" AND CLC.CN_ID = C.CN_ID ");
		query.append(" AND CLP.CN_LIST_ID = CL.CN_LIST_ID  ");
		query.append(" AND CLP.CN_LIST_VERSION = CL.CN_LIST_VERSION ");
		query.append(" AND CL.CN_LIST_ID = CLC.CN_LIST_ID ");
		query.append(" AND CL.CN_LIST_VERSION = CLC.CN_LIST_VERSION ");

		if (defaultLanguage)
		{
			query.append(" AND C.CN_LG = " + formatString(dtoIceContext.getDefaultLanguage()));
		}
		else
		{
			query.append(" AND C.CN_LG = " + formatString(dtoIceContext.getLanguage().getIdlanguage()));
		}

		query.append(" AND  CL.CN_LIST_STATUS = 'VALID' ");
		query.append(" AND CL.CN_LIST_DATE_BEGIN <= SYSDATE ");
		query.append(" AND ( CL.CN_LIST_DATE_END >= SYSDATE OR CL.CN_LIST_DATE_END IS NULL ) ");

		return executeQuery1(query.toString());
	}

}
