package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.dto.MpOperationIuLinkDto;

/**
 * 
 * @author mamestoy
 *
 */
public class HsqlMpOperationIuLinkAccess extends HsqlAccess<MpOperationIuLinkDto> implements IMpOperationIuLinkAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpOperationIuLinkAccess() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpOperationIuLinkDto rs2Dto(ResultSet rs) throws SQLException {
		MpOperationIuLinkDto dto = new MpOperationIuLinkDto();

		dto.setId(getLongIfExists("IU_OPE_ID"));
		dto.setIdOperationSeries(getLongIfExists("IU_OPE_SER_ID"));
		dto.setIuId(getStringIfExists("IU_ID"));
		dto.setIuTitle(getStringIfExists("IU_TITLE"));
		dto.setIuLocation(getStringIfExists("IU_LOCATION"));
		dto.setIuInfotype(getStringIfExists("IU_INFOTYPE"));

		return dto;
	}

	/**
	 * Get the List of IUs for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of IUs
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpOperationIuLinkDto> getListIusByOp(Long idSeriesOperation) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append(" select IU_OPE_ID, IU_OPE_SER_ID, IU_ID, IU_TITLE, IU_LOCATION, IU_INFOTYPE ");
		query.append(" from MP_OPERATION_IULINK ");
		query.append(" where IU_OPE_SER_ID = ");
		query.append(idSeriesOperation);

		return executeQueryN(query.toString());
	}

}
