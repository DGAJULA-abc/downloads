package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.access.table.statik.MP_OPERATION_PART_NUMBER;
import capgemini.cnh.framework.access.table.statik.MP_OPERATION_SERIES;
import capgemini.cnh.framework.access.table.statik.MP_PART_APPLICABILITY;
import capgemini.cnh.framework.access.table.statik.MP_PART_NUMBER;
import capgemini.cnh.framework.access.table.statik.WEB_MP_PART_DESCRIPTION;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.mpbusiness.access.IMpOperationPartAccess;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;

/**
 * 
 * @author mamestoy
 *
 */
public class HsqlMpOperationPartAccess extends HsqlAccess<MpOperationPartDto> implements IMpOperationPartAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpOperationPartAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpOperationPartDto> getParts(List<String> partList) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT PN_CODE,PN_LABEL ")
				.append(" FROM MP_PART_NUMBER  ");

		int i = 0;
		if (!partList.isEmpty())
		{
			query.append(" WHERE PN_CODE in ( ");
			for (String part : partList)
			{
				if (i > 0)
				{
					query.append(",");
				}
				query.append(formatString(part));
				i++;
			}
			query.append(")");
		}
		return executeQueryN(query.toString());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpOperationPartAccess#getPart(java.lang.String)
	 */
	@Override
	public MpOperationPartDto getPart(String part) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT PN_CODE,PN_LABEL ")
				.append(" FROM MP_PART_NUMBER  ")
				.append(" WHERE ")
				.append(" PN_CODE =")
				.append(formatString(part));

		return executeQuery1(query.toString());
	}

	@Override
	public List<MpOperationPartDto> getListPartsByOp(String idSeriesOperation, IceContextDto context) throws SystemException {
		/* Query example:
		 * 
		 * select distinct 
		 * mp_operation_part_number.ope_pn_id
		 * , mp_operation_part_number.ope_pn_qty
		 * , mp_operation_part_number.ope_pn_in_kit
		 * , mp_operation_part_number.ope_pn_group
		 * , mp_part_number.pn_code
		 * , mp_part_number.pn_label
		 * , web_mp_part_description.description
		 * , mp_part_applicability.appli_config 
		 * 
		 * from 
		 * 
		 * mp_operation_part_number 
		 * left join mp_part_applicability on mp_operation_part_number.ope_pn_id = mp_part_applicability.appli_pn_id 
		 * inner join mp_operation_series on mp_operation_part_number.ope_pn_ope_series_id = mp_operation_series.ope_ser_id 
		 * inner join mp_part_number on mp_operation_part_number.ope_pn_code = mp_part_number.pn_code 
		 * left join web_mp_part_description on mp_part_number.pn_code = web_mp_part_description.desc_pn_code and (web_mp_part_description.desc_language = 'IT' or (web_mp_part_description.desc_language = 'EN' and mp_part_number.pn_code not in (select d.desc_pn_code from web_mp_part_description d where d.desc_language = 'IT')))
		 * 
		 * where 
		 * 
		 * mp_operation_series.ope_app_bra = '2' 
		 * and mp_operation_series.ope_app_typ = '1' 
		 * and mp_operation_series.ope_app_pro = '40' 
		 * and mp_operation_series.ope_app_ser = '186' 
		 * and (mp_part_applicability.appli_mod = 'IT' or mp_part_applicability.appli_mod is null) 
		 * and (mp_part_applicability.appli_tt = '001' or mp_part_applicability.appli_tt is null) 
		 * and (mp_part_applicability.appli_market = '3' or mp_part_applicability.appli_market is null) 
		 */
		QueryBuilder builder = QueryBuilder.createQueryBuilder(true);
		builder.selectDistinct()
				.select(MP_OPERATION_PART_NUMBER.OPE_PN_ID)
				.select(MP_OPERATION_PART_NUMBER.OPE_PN_QTY)
				.select(MP_OPERATION_PART_NUMBER.OPE_PN_IN_KIT)
				.select(MP_OPERATION_PART_NUMBER.OPE_PN_GROUP)
				.select(MP_PART_NUMBER.PN_CODE)
				.select(MP_PART_NUMBER.PN_LABEL)
				.select(WEB_MP_PART_DESCRIPTION.DESCRIPTION)
				.select(MP_PART_APPLICABILITY.APPLI_CONFIG)
				.select(MP_OPERATION_PART_NUMBER.OPE_PN_NOTE)

				.from(MP_OPERATION_PART_NUMBER.table())
				.leftJoin(MP_OPERATION_PART_NUMBER.OPE_PN_ID, MP_PART_APPLICABILITY.APPLI_PN_ID)
				.innerJoinColumn(MP_OPERATION_PART_NUMBER.OPE_PN_OPE_SERIES_ID, MP_OPERATION_SERIES.OPE_SER_ID).joinValue(MP_OPERATION_SERIES.OPE_SER_ID, idSeriesOperation)
				.innerJoinColumn(MP_OPERATION_PART_NUMBER.OPE_PN_CODE, MP_PART_NUMBER.PN_CODE)
				.leftJoin(MP_PART_NUMBER.PN_CODE, WEB_MP_PART_DESCRIPTION.DESC_PN_CODE)
				// -- filter on language get default language if current not available
				.and().equalValue(WEB_MP_PART_DESCRIPTION.DESC_LANGUAGE, context.getLanguage().getIdlanguage());
		//			.and().openBracket().equalValue(WEB_MP_PART_DESCRIPTION.DESC_LANGUAGE, context.getLanguage().getIdlanguage())
		//			.or().openBracket().equalValue(WEB_MP_PART_DESCRIPTION.DESC_LANGUAGE, context.getDefaultLanguage())
		//			.and().term(MP_PART_NUMBER.PN_CODE).not().in().openBracket();
		//	WebMpPartDescription d = Table.valueOf(WebMpPartDescription.class, "d");
		//		builder.append(QueryBuilder.createQueryBuilder(true).select(d.DESC_PN_CODE).from(d).whereEqualValue(d.DESC_LANGUAGE, context.getLanguage().getIdlanguage()));
		//	builder.closeBracket().closeBracket().closeBracket();

		builder.where()
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_BRA, context.getBrand() != null ? context.getBrand().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_TYP, context.getType() != null ? context.getType().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_PRO, context.getProduct() != null ? context.getProduct().getIceCode() : null)
				.whereEqualValue(MP_OPERATION_SERIES.OPE_APP_SER, context.getSeries() != null ? context.getSeries().getIceCode() : null);

		if (context.getModel() != null)
		{
			builder.whereEqualValueOrIsNull(MP_PART_APPLICABILITY.APPLI_MOD, context.getModel().getIceCode());
			if (context.getTechnicalType() != null)
			{
				builder.whereEqualValueOrIsNull(MP_PART_APPLICABILITY.APPLI_TT, context.getTechnicalType().getIceCode());
			}
		}
		if (context.getMarket() != null && context.getMarket().getMkId() != null)
		{
			builder.whereEqualValueOrIsNull(MP_PART_APPLICABILITY.APPLI_MARKET, context.getMarket().getMkId().intValue());
		}
		builder.order(MP_OPERATION_PART_NUMBER.OPE_PN_GROUP);

		List<MpOperationPartDto> result = executeQueryN(builder);
		return (result);
	}

	@Override
	protected MpOperationPartDto rs2Dto(ResultSet rs) throws SQLException {
		String config = getStringIfExists("APPLI_CONFIG");
		MpOperationPartDto dto = new MpOperationPartDto(ComplexConfigDto.valueOf(config));

		dto.setId(getLongIfExists("OPE_PN_ID"));
		dto.setPartLabel(getStringIfExists("PN_LABEL"));
		dto.setCodePart(getStringIfExists("PN_CODE"));
		String note = getStringIfExists("OPE_PN_NOTE");
		if (null != note && !note.isEmpty())
		{
			dto.setNote(note);
		}
		dto.setQuantity(getDoubleIfExists("OPE_PN_QTY"));
		Integer inKit = getIntIfExists("OPE_PN_IN_KIT");
		if (null != inKit && 0 != inKit.intValue())
		{
			dto.setInKit(true);
		}
		else
		{
			dto.setInKit(false);
		}
		dto.setPartGroup(getIntIfExists("OPE_PN_GROUP"));
		dto.setDescription(getStringIfExists("DESCRIPTION"));
		return dto;
	}

}
