package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpPartDescriptionAccess extends HsqlAccess<MpPartDescriptionDto> implements IMpPartDescriptionAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpPartDescriptionAccess() throws SystemException {
		super();
	}

	/**
	 * Get the List of parts for a given part for all the languages.
	 * 
	 * @param code the part code
	 * @return the list of parts
	 * @throws SystemException system exception
	 */
	@Override
	public List<MpPartDescriptionDto> getPartsByCode(String code) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append(" wpd.DESC_PN_CODE = ")
				.append(formatString(code));

		// Execute the query and get the result list
		return executeQueryN(query.toString());
	}

	/**
	 * Get the part for a given part and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	@Override
	public MpPartDescriptionDto getPartsByCodeAndLanguage(String code, String language) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append(" wpd.DESC_PN_CODE = ")
				.append(formatString(code))
				.append(" AND wpd.DESC_LANGUAGE = ")
				.append(formatString(language));

		return (MpPartDescriptionDto) executeQuery1(query.toString());
	}

	@Override
	public List<MpPartDescriptionDto> getPartsDescriptionByLanguage(List<String> partList, String language) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append("  wpd.DESC_LANGUAGE = ")
				.append(formatString(language));

		int i = 0;
		if (!partList.isEmpty())
		{
			query.append(" AND wpd.DESC_PN_CODE in ( ");
			for (String part : partList)
			{
				if (i > 0)
				{
					query.append(",");
				}
				query.append(formatString(part));
				i++;
			}
			query.append(")");
		}
		return executeQueryN(query.toString());
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpPartDescriptionDto rs2Dto(ResultSet rs) throws SQLException {
		MpPartDescriptionDto dto = new MpPartDescriptionDto();

		dto.setDescPnCode(getStringIfExists("DESC_PN_CODE"));
		dto.setDescLanguage(getStringIfExists("DESC_LANGUAGE"));
		dto.setDescription(getStringIfExists("DESCRIPTION"));

		return dto;
	}
}
