package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.dto.MpPartSupersessionDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpPartSupersessionAccess extends HsqlAccess<MpPartSupersessionDto> implements IMpPartSupersessionAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpPartSupersessionAccess() throws SystemException {
		super();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess#getSupersessionList(java.lang.String)
	 */
	@Override
	public List<MpPartSupersessionDto> getSupersessionList(String partNumber) throws SystemException {
		//not used but if needed implement the connect by and keep the same order

		return new ArrayList<MpPartSupersessionDto>();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.framework.access.Access#rs2Dto(java.sql.ResultSet)
	 */
	@Override
	protected MpPartSupersessionDto rs2Dto(ResultSet rs) throws SQLException {
		MpPartSupersessionDto dto = new MpPartSupersessionDto();
		dto.setPnsFather(getStringIfExists("PNS_FATHER"));
		dto.setPnsChild(getStringIfExists("PNS_CHILD"));
		dto.setPnsQuantity(getLongIfExists("PNS_QUANTITY"));
		dto.setPnsType(getStringIfExists("PNS_TYPE"));
		dto.setPnsStatus(getStringIfExists("PND_STATUS"));
		dto.setPnsLabel(getStringIfExists("PND_LABEL_EN"));

		return dto;
	}
}
