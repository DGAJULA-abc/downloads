package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.dto.MpPerfFreeTextDto;

/**
 * 
 * @author mmartel
 *
 */
public class HsqlMpPerfFreeTextAccess extends HsqlAccess implements IMpPerfFreeTextAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpPerfFreeTextAccess() throws SystemException {
		super();
	}

	/**
	 * Get the free text performances for a series.
	 * 
	 * @param planId the plan id
	 * @return the list of all the free text performances for a series.
	 * @throws SystemException SystemException
	 */
	public List<MpPerfFreeTextDto> getPerformancesForSeries(String planId, String language) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("select MP_OPERATION_PERFORMANCE_TEXT.*, MESSAGE FREE_TEXT_LABEL  ");
		query.append(" from mp_operation_series, MP_OPERATION_PERFORMANCE_TEXT, TABLE_TITLE, MP_MAINTENANCE_PLAN ");
		query.append(" where ope_ser_id = perf_ope_ser_id ");
		query.append(" and free_text = IDREF_TABLE_TITLE(+) ");
		query.append(" and ope_mp_id = plan_project_id ");
		query.append(" and idlanguage(+) =  ");
		query.append(formatString(language));
		query.append(" and PLAN_ID =  ");
		query.append(formatString(planId));

		return executeQueryN(query.toString());
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpPerfFreeTextDto rs2Dto(ResultSet rs) throws SQLException {
		// New dto
		MpPerfFreeTextDto dto = new MpPerfFreeTextDto();

		// Set Dto
		dto.setFreeTextPerfId(getLongIfExists("PERF_ID"));
		dto.setFreeTextPerfOpeSerId(getLongIfExists("PERF_OPE_SER_ID"));
		dto.setFreeTextPerfName(getStringIfExists("PERF_NAME"));
		dto.setFreeTextPerfLabelId(getLongIfExists("FREE_TEXT"));
		dto.setFreeTextPerfLabel(getStringIfExists("FREE_TEXT_LABEL"));

		return dto;
	}
}
