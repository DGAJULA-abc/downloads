package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.dto.MpSapSerialNumber17Dto;

/**
 * @author jdespeau
 *
 */
public class HsqlMpSapSerialNumber17Access extends HsqlAccess<MpSapSerialNumber17Dto> implements IMpSapSerialNumber17Access {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public HsqlMpSapSerialNumber17Access(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpSapSerialNumber17Access() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	@Override
	protected MpSapSerialNumber17Dto rs2Dto(ResultSet rs) throws SQLException {

		MpSapSerialNumber17Dto dto = new MpSapSerialNumber17Dto();
		dto.setSapVin(getStringIfExists(COL_SAP_VIN));
		dto.setSapVin17(getStringIfExists(COL_SAP_VIN_17));

		return dto;
	}

	@Override
	public MpSapSerialNumber17Dto getSapSerialNumber17FromSapVin(String sapVin) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append(COL_SAP_VIN);
		query.append(", ");
		query.append(COL_SAP_VIN_17);
		query.append(" FROM ");
		query.append(TABLE_NAME);
		query.append(" WHERE ");
		query.append(COL_SAP_VIN);
		query.append(" = ");
		query.append(formatString(sapVin));

		return executeQuery1(query.toString());
	}

}
