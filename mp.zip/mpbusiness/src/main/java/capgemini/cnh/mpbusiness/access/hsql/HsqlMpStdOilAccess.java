package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.mpbusiness.access.IMpStdOilAccess;
import capgemini.cnh.mpbusiness.dto.MpStdOilDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpStdOilAccess extends HsqlAccess<MpStdOilDto> implements IMpStdOilAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpStdOilAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpStdOilDto> getStdOilsyProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT o.OIL_PROJECT , o.OIL_ID, a.OIL_CONFIG ");
		query.append(" FROM MP_STD_OIL o, MP_STD_OIL_APPLICABILITY a");
		query.append(" WHERE o.OIL_STD_ID = a.OIL_STD_ID(+) ");
		if (context.getModel() != null && context.getModel().getIceCode() != null)
		{
			query.append(" AND ( a.OIL_MOD =");
			query.append(context.getModel().getIceCode());
			query.append(" or a.OIL_MOD is null)");
			if (context.getTechnicalType() != null && context.getTechnicalType().getIceCode() != null)
			{
				query.append(" AND ( a.OIL_TT =");
				query.append(context.getTechnicalType().getIceCode());
				query.append(" or a.OIL_TT is null)");
			}
		}
		if (context.getMarket() != null && context.getMarket().getMkId() != null)
		{
			query.append(" AND ( a.OIL_MARKET =");
			query.append(context.getMarket().getMkId());
			query.append(" or a.OIL_MARKET is null)");
		}
		if (projectIdList != null && projectIdList.size() > 0)
		{
			int i = 0;
			int size = projectIdList.size();
			query.append(" AND o.OIL_PROJECT in (");
			for (Integer projectId : projectIdList)
			{
				query.append(projectId);
				i++;
				if (i < size)
				{
					query.append(" , ");
				}
			}
			query.append(" )");
		}
		List<MpStdOilDto> result = executeQueryN(query.toString());
		return result;
	}

	@Override
	protected MpStdOilDto rs2Dto(ResultSet rs) throws SQLException {
		IObjectConfiguration configuration = ComplexConfigDto.valueOf(getStringIfExists("OIL_CONFIG"));
		MpStdOilDto dto = new MpStdOilDto(configuration);

		dto.setOilId(getLongIfExists("OIL_ID"));
		dto.setProjectId(getIntIfExists("OIL_PROJECT"));

		return dto;
	}
}
