package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpToleranceAcess;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;

/**
 * class HsqlAlertContentAccess.
 */
public class HsqlMpToleranceAccess extends HsqlAccess implements IMpToleranceAcess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public HsqlMpToleranceAccess() throws SystemException {
		super();
	}

	@Override
	protected MpToleranceDto rs2Dto(ResultSet rs) throws SQLException {
		MpToleranceDto dto = new MpToleranceDto();
		dto.setBrandIceCode(getStringIfExists(BRAND_ICE_CODE));
		dto.setMarketId(getLongIfExists(MARKET_ID));
		dto.setSchedulingType(getIntIfExists(SCHEDULING_TYPE));
		dto.setTechnicalKmMin(getLongIfExists(TECHNICAL_KM_MIN));
		dto.setTechnicalKmMax(getLongIfExists(TECHNICAL_KM_MAX));
		dto.setTechnicalHourMin(getLongIfExists(TECHNICAL_HOUR_MIN));
		dto.setTechnicalHourMax(getLongIfExists(TECHNICAL_HOUR_MAX));
		dto.setTechnicalMonthMin(getLongIfExists(TECHNICAL_MONTH_MIN));
		dto.setTechnicalMonthMax(getLongIfExists(TECHNICAL_MONTH_MAX));
		dto.setCommercialKmMin(getLongIfExists(COMMERCIAL_KM_MIN));
		dto.setCommercialKmMax(getLongIfExists(COMMERCIAL_KM_MAX));
		dto.setCommercialHourMin(getLongIfExists(COMMERCIAL_HOUR_MIN));
		dto.setCommercialHourMax(getLongIfExists(COMMERCIAL_HOUR_MAX));
		dto.setCommercialMonthMin(getLongIfExists(COMMERCIAL_MONTH_MIN));
		dto.setCommercialMonthMax(getLongIfExists(COMMERCIAL_MONTH_MAX));

		return dto;
	}

	/**
	 * Get tolerance by brand and market
	 * 
	 * @param mpAlertToleranceDto : MpAlertToleranceDto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpToleranceDto getToleranceByBrandAndMarket(String brandIceCode, Long marketId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT *");
		query.append(" FROM ").append(TABLE);
		query.append(" WHERE ").append(BRAND_ICE_CODE).append(" = ").append(formatString(brandIceCode));
		query.append(" AND ").append(MARKET_ID).append(" = ").append(marketId);

		return (MpToleranceDto) executeQuery1(query.toString());

	}
}
