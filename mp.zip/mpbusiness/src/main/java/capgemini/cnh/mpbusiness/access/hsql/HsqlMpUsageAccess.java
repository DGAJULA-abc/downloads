package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * 
 * @author cblois
 *
 */
public class HsqlMpUsageAccess extends HsqlAccess<MpUsageDto> implements IMpUsageAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public HsqlMpUsageAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpUsageDto> getListByPlanList(String planList, String language, String defaultLanguage) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" SELECT DISTINCT v.us_value_id, i.us_item_id ");
		query.append(" FROM mp_usage_item i, mp_usage_value v, mp_maintenance_condition co ");
		query.append(" WHERE v.us_item_id = i.us_item_id ");
		query.append(" AND v.us_value_id = co.cond_usage_value ");
		query.append(" AND co.cond_plan_id IN ( ");
		query.append(planList);
		query.append(" ) ");
		query.append(" UNION SELECT DISTINCT c.cond_usage_value, NULL ");
		query.append(" FROM  mp_maintenance_condition c ");
		query.append(" WHERE c.cond_usage_value IS NULL ");
		query.append(" AND c.cond_plan_id IN (");
		query.append(planList);
		query.append(" ) ");
		query.append(" order by 2 ");

		List<MpUsageDto> toReturn = executeQueryN(query.toString());

		return toReturn;

	}

	@Override
	public MpUsageDto getMpUsageItemTranslation(Long itemId, String language) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT i.us_item_id, i.us_item_title_id, ti.message AS item_title ");
		query.append(" FROM mp_usage_item i, table_title ti ");
		query.append(" WHERE i.us_item_title_id = ti.idref_table_title ");
		query.append(" AND i.us_item_id = ");
		query.append(itemId);
		query.append(" AND ti.idlanguage = ");
		query.append(formatString(language));

		return executeQuery1(query.toString());
	}

	@Override
	public MpUsageDto getMpUsageValueTranslation(int valueId, String language) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT v.us_value_id, v.us_title_id, ti.message AS value_title ");
		query.append(" FROM mp_usage_value v, table_title ti ");
		query.append(" WHERE v.us_title_id = ti.idref_table_title ");
		query.append(" AND v.us_value_id = ");
		query.append(valueId);
		query.append(" AND ti.idlanguage = ");
		query.append(formatString(language));

		return executeQuery1(query.toString());
	}

	@Override
	public Map<Long, MpUsageDto> getMpUsageItemTranslationsByLang(String language) throws SystemException {
		Map<Long, MpUsageDto> map = new HashMap<>();

		StringBuilder query = new StringBuilder();

		query.append("SELECT i.us_item_id, i.us_item_title_id, ti.message AS item_title ");
		query.append(" FROM mp_usage_item i, table_title ti ");
		query.append(" WHERE i.us_item_title_id = ti.idref_table_title ");
		query.append(" AND ti.idlanguage = ");
		query.append(formatString(language));

		List<MpUsageDto> listMpUsageItem = executeQueryN(query.toString());
		for (MpUsageDto mpUsageItem : listMpUsageItem)
		{
			map.put(mpUsageItem.getItemId(), mpUsageItem);
		}

		return map;
	}

	@Override
	public Map<Integer, MpUsageDto> getMpUsageValueTranslationsByLang(String language) throws SystemException {
		Map<Integer, MpUsageDto> map = new HashMap<>();

		StringBuilder query = new StringBuilder();

		query.append("SELECT v.us_value_id, v.us_title_id, ti.message AS value_title ");
		query.append(" FROM mp_usage_value v, table_title ti ");
		query.append(" WHERE v.us_title_id = ti.idref_table_title ");
		query.append(" AND ti.idlanguage = ");
		query.append(formatString(language));

		List<MpUsageDto> listMpUsageValue = executeQueryN(query.toString());
		for (MpUsageDto mpUsageValue : listMpUsageValue)
		{
			map.put(mpUsageValue.getValueId(), mpUsageValue);
		}

		return map;
	}

	@Override
	protected MpUsageDto rs2Dto(ResultSet rs) throws SQLException {
		MpUsageDto mpUsageDto = new MpUsageDto();
		mpUsageDto.setValueId(getIntIfExists("US_VALUE_ID"));
		mpUsageDto.setValueTitleId(getLongIfExists("US_TITLE_ID"));
		mpUsageDto.setValueTitle(getStringIfExists("VALUE_TITLE"));
		mpUsageDto.setItemId(getLongIfExists("US_ITEM_ID"));
		mpUsageDto.setItemTitleId(getLongIfExists("US_ITEM_TITLE_ID"));
		mpUsageDto.setItemTitle(getStringIfExists("ITEM_TITLE"));

		return mpUsageDto;
	}

	/**
	 * Get all the avalable missions.
	 * 
	 * @return all the mission ids.
	 * @throws SystemException SystemException
	 */
	@Override
	public List<MpUsageDto> getAllAvailableMissionsIds() throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT distinct us_value_id FROM mp_usage_value ");

		return executeQueryN(query.toString());
	}
}
