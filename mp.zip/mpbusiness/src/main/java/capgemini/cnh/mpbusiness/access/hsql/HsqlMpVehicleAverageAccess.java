package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpVehicleAverageDto;

/**
 * 
 * @author bmilcend
 *
 */
public class HsqlMpVehicleAverageAccess extends HsqlAccess<MpVehicleAverageDto> implements IMpVehicleAverageAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpVehicleAverageAccess() throws SystemException {
		super();
	}

	@Override
	protected MpVehicleAverageDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpVehicleAverageDto dto = new MpVehicleAverageDto();

		dto.setVin(getStringIfExists("VIN"));
		dto.setCurrentValue(MpType.MP_HOUR, getLongIfExists("CURRENT_HOUR"));
		dto.setCurrentValue(MpType.MP_KM, getLongIfExists("CURRENT_KM"));
		dto.setAverageValue(MpType.MP_HOUR, getDoubleIfExists("AVERAGE_HOUR"));
		dto.setAverageValue(MpType.MP_KM, getDoubleIfExists("AVERAGE_KM"));
		dto.setExportDate(getDateIfExists("EXPORT_DATE"));

		return dto;
	}

	@Override
	public MpVehicleAverageDto getVehicleAverageForVin(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT VIN, CURRENT_HOUR, CURRENT_KM, AVERAGE_HOUR, AVERAGE_KM ,EXPORT_DATE FROM MP_VEHICLE_KM_HOUR_AV WHERE VIN= ");
		query.append(formatString(vin));
		return executeQuery1(query.toString());
	}
}
