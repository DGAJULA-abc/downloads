package capgemini.cnh.mpbusiness.access.hsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.HsqlAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpVinMissionAccess;
import capgemini.cnh.mpbusiness.dto.MpVinMissionDto;

/**
 * 
 * @author mamestoy
 *
 */
public class HsqlMpVinMissionAccess extends HsqlAccess<MpVinMissionDto> implements IMpVinMissionAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public HsqlMpVinMissionAccess() throws SystemException {
		super();
	}

	/**
	 * Get the mission for a vin.
	 * 
	 * @param vinCode : selected vin
	 * @return a list of table title
	 * @throws SystemException system exception
	 */
	public MpVinMissionDto getMpMissionForVin(String vinCode) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT MISSION_VIN, MISSION_ID ");
		query.append(" FROM MP_VIN_MISSION ");
		query.append(" WHERE MISSION_VIN = ");
		query.append(formatString(vinCode));

		return executeQuery1(query.toString());
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpVinMissionDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpVinMissionDto mpMpVinMissionDto = new MpVinMissionDto();

		// Set Dto
		mpMpVinMissionDto.setValueMissionId(getLongIfExists("MISSION_ID"));
		mpMpVinMissionDto.setVinCode(getStringIfExists("MISSION_VIN"));

		return mpMpVinMissionDto;
	}
}
