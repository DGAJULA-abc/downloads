package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpAlertToleranceAcess;
import capgemini.cnh.mpbusiness.dto.MpAlertToleranceDto;

/**
 * 
 * 
 * @author lestrabo
 *
 */
public class OracleMpAlertToleranceAccess extends OracleAccess<MpAlertToleranceDto> implements IMpAlertToleranceAcess {

	/**
	 * @throws SystemException
	 */
	public OracleMpAlertToleranceAccess() throws SystemException {
		super();

	}

	/**
	 * @param dbAccess
	 * @throws SystemException
	 */
	public OracleMpAlertToleranceAccess(Access<MpAlertToleranceDto> dbAccess) throws SystemException {
		super(dbAccess);

	}

	@Override
	protected MpAlertToleranceDto rs2Dto(ResultSet rs) throws SQLException {
		MpAlertToleranceDto dto = new MpAlertToleranceDto();

		dto.setPlanId(getLongIfExists("PLAN_ID"));
		dto.setPlanExtId(getLongIfExists("PLAN_EXT_ID"));
		dto.setKmTolerance(getDoubleIfExists("TOL_KM"));
		dto.setHourTolerance(getDoubleIfExists("TOL_HOUR"));
		dto.setMonthTolerance(getDoubleIfExists("TOL_MONTH"));

		return dto;
	}

	/**
	 * Get tolerance km by plan id
	 * 
	 * @param mpAlertToleranceDto : MpAlertToleranceDto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpAlertToleranceDto getToleranceByPlanId(Long planId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT TOL_KM , PLAN_ID FROM MP_ALERT_TOLERANCE ");
		query.append(" WHERE PLAN_ID = ");
		query.append(planId);

		return executeQuery1(query.toString());

	}
}
