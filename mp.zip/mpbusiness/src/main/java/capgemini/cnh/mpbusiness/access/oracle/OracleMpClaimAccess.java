package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpClaimAccess;
import capgemini.cnh.mpbusiness.dto.MpClaimDto;

/**
 * Claim table access for Oracle database.
 * 
 * @author mamestoy
 *
 */
public class OracleMpClaimAccess extends OracleAccess<MpClaimDto> implements IMpClaimAccess {

	/** Transaction access. */
	private Access dbAccess;

	private static final String TABLE_WEB = "MP_CLAIM@ICEWEB";

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public OracleMpClaimAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException can't get data source
	 */
	public OracleMpClaimAccess() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	@Override
	protected MpClaimDto rs2Dto(ResultSet rs) throws SQLException {
		//		SimpleDateFormat simpDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat simpDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		MpClaimDto dto = new MpClaimDto();

		dto.setVinCode(getStringIfExists(COL_VIN));
		if (getDateIfExists(COL_DATE) != null)
		{
			dto.setCreationDate(simpDate.format(getDateIfExists(COL_DATE)));
		}
		if (getDateIfExists(COL_DATE_MODIF) != null)
		{
			dto.setModifDate(simpDate.format(getDateIfExists(COL_DATE_MODIF)));
		}
		if (getDateIfExists(COL_FAILURE_DATE) != null)
		{
			dto.setFailureDate(simpDate.format(getDateIfExists(COL_FAILURE_DATE)));
		}

		dto.setId(getStringIfExists(COL_ID));

		Clob xmlClob = getClobIfExists(COL_XML);
		if (xmlClob != null)
		{
			Long clobLength = xmlClob.length();
			String xml = xmlClob.getSubString(1, clobLength.intValue());
			dto.setFilterXML(xml);
		}

		Clob xmlSapClob = getClobIfExists(COL_SAP_XML);
		if (xmlSapClob != null)
		{
			Long clobLength = xmlSapClob.length();
			String xml = xmlSapClob.getSubString(1, clobLength.intValue());
			dto.setFilterSAPXML(xml);
		}

		Clob originalXmlSapClob = getClobIfExists(COL_ORIGINAL_SAP_XML);
		if (originalXmlSapClob != null)
		{
			Long clobLength = originalXmlSapClob.length();
			String xml = originalXmlSapClob.getSubString(1, clobLength.intValue());
			dto.setFilterOriginalSAPXML(xml);
		}

		dto.setKm(getLongIfExists(COL_KM));
		dto.setHour(getLongIfExists(COL_HOUR));
		dto.setPdfPath(getStringIfExists(COL_PDF_PATH));
		dto.setPdfParts(getStringIfExists(COL_PDF_PARTS));
		dto.setPdfService(getStringIfExists(COL_PDF_SERVICE));

		if ((getIntIfExists(COL_HAS_CONTRACT) != null))
		{
			dto.setHasContract((getIntIfExists(COL_HAS_CONTRACT) == 1 || getIntIfExists(COL_HAS_CONTRACT) == 2));
		}

		return dto;
	}

	/**
	 * @param pClaim : the claim to record
	 * 
	 * @return true or false
	 * @throws SystemException Cannot execute query or access to database.
	 */
	@Override
	public boolean create(MpClaimDto pClaim) throws SystemException {

		Long ret = null;
		boolean created = false;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" (");

		queryBuilder.append(COL_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_DATE_MODIF);
		queryBuilder.append(", ");
		queryBuilder.append(COL_FAILURE_DATE);
		queryBuilder.append(", ");
		queryBuilder.append(COL_SAP_XML);
		queryBuilder.append(", ");
		queryBuilder.append(COL_ORIGINAL_SAP_XML);
		queryBuilder.append(", ");
		queryBuilder.append(COL_XML);
		queryBuilder.append(", ");
		queryBuilder.append(COL_KM);
		queryBuilder.append(", ");
		queryBuilder.append(COL_HOUR);
		queryBuilder.append(", ");
		queryBuilder.append(COL_HAS_CONTRACT);
		queryBuilder.append(", ");
		queryBuilder.append(COL_PDF_PATH);
		queryBuilder.append(",");
		queryBuilder.append(COL_PDF_PARTS);
		queryBuilder.append(",");
		queryBuilder.append(COL_PDF_SERVICE);
		queryBuilder.append(",");
		queryBuilder.append(COL_CERTIFIED_PARTS);

		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(pClaim.getVinCode()));
		queryBuilder.append(", ");
		queryBuilder.append("to_date(").append(formatString(pClaim.getCreationDate())).append(", 'YYYY-MM-DD HH24:MI:SS')");
		queryBuilder.append(", sysdate, ");
		queryBuilder.append("to_date(").append(formatString(pClaim.getFailureDate())).append(", 'YYYY-MM-DD')");
		queryBuilder.append(", ");
		queryBuilder.append("?");
		queryBuilder.append(", ");
		queryBuilder.append("?");
		queryBuilder.append(", ");
		queryBuilder.append("?");
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getKm()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getHour()));
		queryBuilder.append(", ");
		if (pClaim.hasContract())
		{
			queryBuilder.append("1");
		}
		else
		{
			queryBuilder.append("0");
		}
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getPdfPath()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getPdfParts()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getPdfService()));
		queryBuilder.append(", ");
		queryBuilder.append(formatString(pClaim.getCertifiedParts()));
		queryBuilder.append(")");

		ret = executeQueryIWithClob(queryBuilder.toString(), pClaim.getFilterSAPXML(), pClaim.getFilterOriginalSAPXML(), pClaim.getFilterXML());
		if (ret != null && ret.longValue() > 0)
		{
			created = true;
		}
		return created;
	}

	/**
	 * Get list of claims in database for a VIN.
	 * 
	 * @param vinList : selected VIN
	 * @return a list of claims
	 * @throws SystemException Cannot execute query or access to database.
	 */
	@Override
	public List<MpClaimDto> getClaimForVin(List<String> vinList) throws SystemException {

		String vins = StringUtils.join(vinList.toArray(), "','");
		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append(COL_DATE);
		query.append(", ");
		query.append(COL_FAILURE_DATE);
		query.append(", ");
		query.append(COL_XML);
		query.append(", ");
		query.append(COL_SAP_XML);
		query.append(", ");
		query.append(COL_ORIGINAL_SAP_XML);
		query.append(", ");
		query.append(COL_ID);
		query.append(", ");
		query.append(COL_PDF_PATH);
		query.append(", ");
		query.append(COL_PDF_PARTS);
		query.append(", ");
		query.append(COL_PDF_SERVICE);
		query.append(" FROM ");
		query.append(TABLE_NAME);
		query.append(" WHERE ");
		query.append(COL_VIN);
		query.append(" in ('");
		query.append(vins);
		query.append("') ");

		return executeQueryN(query.toString());
	}

	/**
	 * Get a claim in database for an Id.
	 * 
	 * @param id : selected id
	 * @return a claim
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	@Override
	public MpClaimDto getClaimForId(String id) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append(COL_DATE);
		query.append(", ");
		query.append(COL_FAILURE_DATE);
		query.append(", ");
		query.append(COL_XML);
		query.append(", ");
		query.append(COL_SAP_XML);
		query.append(", ");
		query.append(COL_ORIGINAL_SAP_XML);
		query.append(", ");
		query.append(COL_ID);
		query.append(", ");
		query.append(COL_PDF_PATH);
		query.append(" FROM ");
		query.append(TABLE_NAME);
		query.append(" WHERE ");
		query.append(COL_ID);
		query.append(" = ");
		query.append(formatString(id));

		return executeQuery1(query.toString());
	}

	/**
	 * Update the creation time date in a new field.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	@Override
	public boolean updateDateClaim(String id, String dateEdit) throws SystemException {

		StringBuilder query = new StringBuilder();
		Long ret = null;
		boolean updated = false;

		String date = "TO_DATE(" + formatString(dateEdit) + " , 'YYYY-MM-DD')";

		query.append(" UPDATE ");
		query.append(TABLE_NAME);
		query.append(" SET ");
		query.append(COL_DATE_MODIF);
		query.append(" = sysdate, ");
		query.append(COL_FAILURE_DATE);
		query.append(" = ");
		query.append(date);
		query.append(" WHERE ");
		query.append(COL_ID);
		query.append(" = ");
		query.append(formatString(id));

		//Long count = executeQueryCount(query.toString(), "nb");

		//return count > 0;

		ret = executeQueryI(TABLE_NAME, query.toString());
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	/**
	 * update the XML content in database.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @param XMLFile the content of the XML
	 * @param XMLSapFile the content of the XML sap
	 * @param originalXMLSapFile the content of the original XML sap
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	@Override
	public boolean updateXMLClaim(String id, String dateEdit, String XMLFile, String XMLSapFile, String originalXMLSapFile) throws SystemException {

		StringBuilder query = new StringBuilder();
		String date = "TO_DATE(" + formatString(dateEdit) + " , 'YYYY-MM-DD')";

		Long ret = null;
		boolean updated = false;

		query.append(" UPDATE ");
		query.append(TABLE_NAME);
		query.append(" SET ");
		query.append(COL_XML);
		query.append(" = ");
		query.append("?");
		query.append(",");
		query.append(COL_SAP_XML);
		query.append(" = ");
		query.append("?");
		query.append(",");
		query.append(COL_ORIGINAL_SAP_XML);
		query.append(" = ");
		query.append("?");
		query.append(",");
		query.append("mpcl_has_contract=decode(mpcl_has_contract,2,1, mpcl_has_contract)");
		query.append(",");
		query.append(COL_DATE_MODIF);
		query.append(" = sysdate, ");
		query.append(COL_FAILURE_DATE);
		query.append(" = ");
		query.append(date);
		query.append(" WHERE ");
		query.append(COL_ID);
		query.append(" = ");
		query.append(formatString(id));

		ret = executeQueryIWithClob(query.toString(), XMLFile, XMLSapFile, originalXMLSapFile);
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	/**
	 * update PDF_PATH content in database.
	 * 
	 * @param id to update
	 */
	@Override
	public boolean updatePDFPath(String id, String PdfPath) throws SystemException {

		StringBuilder query = new StringBuilder();

		Long ret = null;
		boolean updated = false;

		query.append(" UPDATE ");
		query.append(TABLE_WEB);
		query.append(" SET ");
		query.append(COL_PDF_PATH);
		query.append(" = '");
		query.append(PdfPath);
		query.append("' WHERE ");
		query.append(COL_ID);
		query.append(" = ");
		query.append(formatString(id));

		ret = executeQueryI(TABLE_WEB, query.toString());
		if (ret != null && ret.longValue() > 0)
		{
			updated = true;
		}
		return updated;
	}

	/**
	 * Get the max of Id in the MP_CLAIM table.
	 * 
	 * @return the max Id
	 * @throws SystemException Cannot execute query or access to database.
	 */
	@Override
	public String getMaxClaimId() throws SystemException {

		String query = "select max(mpcl_id) as MPCL_ID from MP_CLAIM";
		String result = executeQueryMaxId(query, "MPCL_ID");

		return result;
	}

	@Override
	public List<MpClaimDto> getClaimToExport() throws SystemException {

		StringBuilder query = new StringBuilder();

		query.append("SELECT ");
		query.append(COL_ID);
		query.append(", ");
		query.append(COL_XML);
		query.append(", ");
		query.append(COL_PDF_PATH);
		query.append(", ");
		query.append(COL_DATE);
		query.append(", ");
		query.append(COL_SAP_XML);
		query.append(" FROM ");
		query.append(TABLE_WEB);
		query.append(" WHERE ");

		// request is commented for tests
		query.append(
				"to_date(mpcl_date, 'dd/mm/yy hh24:mi:ss') > to_date('24/08/23 16:37:00', 'dd/mm/yy hh24:mi:ss')");
		query.append(" AND ");

		query.append("  to_date(mpcl_date, 'dd/mm/yy hh24:mi:ss') < to_date('31/08/23 21:04:00', 'dd/mm/yy hh24:mi:ss') ");

		return executeQueryN(query.toString());
	}

	/**
	 * Function which retrieves the claims for the CSV export which is part of the maintenance history
	 * export.
	 * 
	 * @param lastExportDate Date from which to get the claims.
	 * @return The list of claims.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	@Override
	public List<MpClaimDto> getClaimsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		SimpleDateFormat expDateSdf = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		StringBuilder query = new StringBuilder();
		query.append("SELECT MPCL_VIN, MPCL_DATE, MPCL_DATE_MODIF, MPCL_ID, MPCL_XML, MPCL_KM, MPCL_HOUR, MPCL_SAP_XML, MPCL_HAS_CONTRACT, MPCL_PDF_PATH, MPCL_FAILURE_DATE FROM mp_claim@ICEWEB"
				+ " WHERE MPCL_DATE >= TO_DATE('");
		query.append(expDateSdf.format(lastExportDate));
		query.append("', 'dd/MM/yy HH24:MI:SS')");
		query.append("AND MPCL_DATE < TO_DATE('");
		query.append(expDateSdf.format(firstExportDate));
		query.append("', 'dd/MM/yy HH24:MI:SS')");

		System.out.println("+++++++++++++++++++++++++");
		System.out.println(query);
		System.out.println("+++++++++++++++++++++++++");
		return executeQueryN(query.toString());

	}

}
