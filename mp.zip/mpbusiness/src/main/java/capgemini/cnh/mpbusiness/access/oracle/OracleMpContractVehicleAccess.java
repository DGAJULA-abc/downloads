package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;

/**
 * 
 * @author mmartel
 *
 */
public class OracleMpContractVehicleAccess extends OracleAccess<MpContractVehicleDto> implements IMpContractVehicleAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public OracleMpContractVehicleAccess() throws SystemException {
		super();
	}

	/** date format. **/
	private SimpleDateFormat simpDate = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpContractVehicleDto rs2Dto(ResultSet rs) throws SQLException {
		MpContractVehicleDto dto = new MpContractVehicleDto();

		dto.setSapVin(getStringIfExists("SAP_VIN"));
		dto.setPlanId(getLongIfExists("PLAN_ID"));
		dto.setPlanExtId(getLongIfExists("PLAN_EXT_ID"));
		dto.setMpVersion(getIntIfExists("MP_VERSION"));
		if (getDateIfExists("WAR_START_DATE") != null)
		{
			dto.setWarrantyStartDate(simpDate.format(getDateIfExists("WAR_START_DATE")));
		}
		dto.setContractStartDate(getDateIfExists("START_DATE"));
		dto.setContractEndDate(getDateIfExists("END_DATE"));

		dto.setMpGroupConf(getStringIfExists("MP_GROUP_CONF"));
		dto.setEngOilId(getLongIfExists("ENG_OIL_ID"));
		dto.setGbOilId(getLongIfExists("GB_OIL_ID"));
		dto.setAxleOilId(getLongIfExists("AXLE_OIL_ID"));

		dto.setTypeContract(getStringIfExists("CTRT_TYPE"));
		dto.setContractNumber(getStringIfExists("SAP_CONTRACT_NB"));
		dto.setConnectedType(getStringIfExists("CONNECTED_TYPE"));
		dto.setMissionCode(getStringIfExists("MISSION_CODE"));
		dto.setMissionDescription(getStringIfExists("MISSION_DESC"));
		dto.setIsDeleted(getStringIfExists("IS_DELETED"));
		dto.setSapSystem(getStringIfExists("SAP_SYSTEM"));
		dto.setAmountOfUse(getLongIfExists("AMOUNT_OF_USE"));
		dto.setDuration(getLongIfExists("DURATION"));
		dto.setNumberOfStops(getLongIfExists("NUMBER_OF_TRAVEL"));

		MpCustomerDto customerDto = new MpCustomerDto();
		customerDto.setName1(getStringIfExists("FIRST_NAME"));
		customerDto.setName2(getStringIfExists("SURNAME"));
		customerDto.setCustomerCode(getStringIfExists("CUSTOMER_CODE"));
		customerDto.setCustomerPhone(getStringIfExists("TELEPHONE"));
		customerDto.setCustomerMail(getStringIfExists("EMAIL"));
		customerDto.setSecondPhone(getStringIfExists("SECOND_TELEPHONE"));
		customerDto.setSecondMail(getStringIfExists("SECOND_EMAIL"));
		customerDto.setStreet(getStringIfExists("STREET"));
		customerDto.setCity(getStringIfExists("CITY"));
		customerDto.setCountry(getStringIfExists("COUNTRY"));
		customerDto.setZipCode(getStringIfExists("ZIP_CODE"));

		dto.setCustomerData(customerDto);

		return dto;
	}

	/**
	 * Get all the Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the list of plan
	 * @throws SystemException system exception
	 */
	public List<MpContractVehicleDto> getAllMpContracts(List<String> lstPinVin) throws SystemException {
		StringBuilder query = new StringBuilder();

		String vinList = StringUtils.join(lstPinVin.toArray(), "','");

		query.append(
				"SELECT SAP_CONTRACT_NB, SAP_VIN, PLAN_ID, PLAN_EXT_ID, MP_VERSION, WAR_START_DATE ,START_DATE, END_DATE, MP_GROUP_CONF,ENG_OIL_ID,GB_OIL_ID,AXLE_OIL_ID, CTRT_TYPE, "
						+ "CUSTOMER_CODE, TELEPHONE, FIRST_NAME, SURNAME, STREET, CITY, COUNTRY, ZIP_CODE, EMAIL, SECOND_TELEPHONE, SECOND_EMAIL, AMOUNT_OF_USE, DURATION, NUMBER_OF_TRAVEL, ");
		// MP Light Targa CONNECTED_TYPE column
		query.append(" CASE (SELECT MP_VEHICLE_KM_HOUR_AV.CONNECTED_TYPE FROM MP_VEHICLE_KM_HOUR_AV WHERE MP_VEHICLE_KM_HOUR_AV.VIN = MP_CONTRACT_VEHICLE.SAP_VIN) ");
		query.append("  WHEN '0' THEN '10' ");
		query.append("  WHEN '1' THEN '03'");
		query.append("  ELSE null ");
		query.append(" END AS CONNECTED_TYPE, MISSION_CODE, MISSION_DESC, IS_DELETED, SAP_SYSTEM ");
		query.append(" FROM MP_CONTRACT_VEHICLE ");
		query.append(" WHERE SAP_VIN in ('");
		query.append(vinList);
		query.append("') ");
		query.append(" ORDER BY START_DATE DESC, PLAN_EXT_ID, MP_VERSION DESC");
		return executeQueryN(query.toString());
	}

	/**
	 * Get the the applicable Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public MpContractVehicleDto getMpActiveContract(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String todayDate = df.format(new Date());

		query.append(
				"SELECT SAP_CONTRACT_NB, SAP_VIN, c.PLAN_ID, c.PLAN_EXT_ID, MP_VERSION, WAR_START_DATE, START_DATE, END_DATE, MP_GROUP_CONF,ENG_OIL_ID,GB_OIL_ID,AXLE_OIL_ID, CTRT_TYPE FROM MP_CONTRACT_VEHICLE c, MP_MAINTENANCE_PLAN p");
		query.append(" WHERE SAP_VIN = ");
		query.append(formatString(vin));
		query.append(" AND c.PLAN_ID = p.PLAN_ID");
		query.append(" and START_DATE <= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");
		query.append(" and END_DATE >= TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");

		return executeQuery1(query.toString());

	}

	/**
	 * Get all the expired Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the list of plan
	 * @throws SystemException system exception
	 */
	public MpContractVehicleDto getExpiredMpContract(String vin) throws SystemException {
		StringBuilder query = new StringBuilder();

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String todayDate = df.format(new Date());

		query.append(
				"SELECT SAP_CONTRACT_NB, SAP_VIN, c.PLAN_ID, c.PLAN_EXT_ID, MP_VERSION, WAR_START_DATE, START_DATE, END_DATE, MP_GROUP_CONF,ENG_OIL_ID,GB_OIL_ID,AXLE_OIL_ID, CTRT_TYPE FROM MP_CONTRACT_VEHICLE c, MP_MAINTENANCE_PLAN p");
		query.append(" WHERE SAP_VIN = ");
		query.append(formatString(vin));
		query.append(" AND c.PLAN_ID = p.PLAN_ID");
		query.append(" and END_DATE < TO_DATE(" + formatString(todayDate) + ",'YYYYMMDD')");

		return executeQuery1(query.toString());
	}

}
