package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpCustomerAccess;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;

/**
 * table access for Oracle database.
 * 
 * @author lestrabo
 *
 */
public class OracleMpCustomerAccess extends OracleAccess<MpCustomerDto> implements IMpCustomerAccess {

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	private static final String MP_FLEX_CONTRACT = "MP_FLEX_CONTRACT_WK";
	private static final String COLUMN_VIN_CONTRACT = "MP_FLEX_CONTRACT_WK.VIN";
	private static final String COLUMN_CUSTOMER_CODE_CONTRACT = "MP_FLEX_CONTRACT_WK.CUSTOMER_CODE";
	private static final String MP_FLEX_CUSTOMER_SAP = "MP_FLEX_CUSTOMER_SAP";
	private static final String COLUMN_CUSTOMER_CUSTOMER = "MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE";
	private static final String COLUMN_CUSTOMER_CODE = "CUSTOMER_CODE";
	private static final String COLUMN_CUSTOMER_NAME1 = "CUSTOMER_NAME1";
	private static final String COLUMN_CUSTOMER_NAME2 = "CUSTOMER_NAME2";

	/**
	 * @throws SystemException
	 */
	public OracleMpCustomerAccess() throws SystemException {
		super();

	}

	/**
	 * Request to get customers of MP_FLEX_CUSTOMER_SAP
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpCustomerDto> getCustomersFromMpCustomers(String dealerCode, String brand) throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());

		//TO ADD 
		QueryBuilder builder = QueryBuilder.createQueryBuilder(true);
		builder.selectDistinct()
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_CODE)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME1)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME2)
				.from(MP_FLEX_CONTRACT)
				.append(" inner join ").append(MP_FLEX_CUSTOMER_SAP).append(" on " + COLUMN_CUSTOMER_CUSTOMER + "=" + COLUMN_CUSTOMER_CODE_CONTRACT)
				.append(" WHERE MP_FLEX_CONTRACT_WK.CONTRACT_DATE_START  <= TO_DATE( " + formatString(todayDate) + ",'DD/MM/YYYY')"
						+ " AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_EXP  >= TO_DATE(" + formatString(todayDate) + ",'DD/MM/YYYY')")
				.append(" AND MP_FLEX_CONTRACT_WK.DEALER_CODE=").append(formatString(dealerCode));
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.framework.access.Access#rs2Dto(java.sql.ResultSet)
	 */
	@Override
	protected MpCustomerDto rs2Dto(ResultSet rs) throws SQLException {
		return new MpCustomerDto(getStringIfExists(COLUMN_CUSTOMER_NAME1),
				getStringIfExists(COLUMN_CUSTOMER_NAME2),
				getStringIfExists("CUSTOMER_CODE"));

	}

}
