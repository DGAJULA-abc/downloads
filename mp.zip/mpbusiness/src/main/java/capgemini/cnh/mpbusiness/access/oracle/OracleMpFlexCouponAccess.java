package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author bmilcend
 *
 */
public class OracleMpFlexCouponAccess extends OracleAccess<MpFlexCouponDto> implements IMpFlexCouponAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpFlexCouponAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT COUPON_CODE FROM MP_COUPON_FLEX");
		return executeQueryN(query.toString());
	}

	@Override
	public MpFlexCouponDto getFlexibleCoupon(String coupon) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT COUPON_CODE FROM MP_COUPON_FLEX WHERE COUPON_CODE=");
		query.append(formatString(coupon));
		return executeQuery1(query.toString());
	}

	@Override
	protected MpFlexCouponDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpFlexCouponDto dto = new MpFlexCouponDto();

		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		return dto;
	}

}
