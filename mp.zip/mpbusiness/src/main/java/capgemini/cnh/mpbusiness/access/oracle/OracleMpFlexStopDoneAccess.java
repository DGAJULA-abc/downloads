package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.dto.MpFlexStopDoneDto;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * 
 * @author mmartel
 *
 */
public class OracleMpFlexStopDoneAccess extends OracleAccess<MpFlexStopDoneDto> implements IMpFlexStopDoneAccess {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public OracleMpFlexStopDoneAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpFlexStopDoneAccess() throws SystemException {
		super();
	}

	@Override
	public Long addFlexStopDone(MpFlexStopDoneDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		String dateDone = "TO_DATE (" + formatString(UtilDate.dateToString(nextStop.getDateDone(), "dd/MM/yyyy HH:mm:ss")) + ", 'DD/MM/YYYY HH24:MI:SS')";

		query.append(" INSERT INTO MP_FLEX_DONE_WK  (VIN, COUPON_CODE, NEXT_KM, DATE_DONE) VALUES (");
		query.append(formatString(nextStop.getVin()));
		query.append(",");
		query.append(formatString(nextStop.getIntervalCode()));
		query.append(",");
		query.append(formatString(nextStop.getKmDone()));
		query.append(",");
		query.append(dateDone);
		query.append(")");
		return executeQueryI(query.toString());
	}

	@Override
	public Long deleteFlexStopDone(MpFlexStopDoneDto nextStop) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" DELETE FROM MP_FLEX_DONE_WK  WHERE VIN=");
		query.append(formatString(nextStop.getVin()));
		query.append(" AND COUPON_CODE=");
		query.append(formatString(nextStop.getIntervalCode()));
		return executeQueryI(query.toString());
	}

	@Override
	protected MpFlexStopDoneDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpFlexStopDoneDto dto = new MpFlexStopDoneDto();

		dto.setVin(getStringIfExists("VIN"));
		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		dto.setDateDone(getDateIfExists("DATE_DONE"));
		dto.setKmDone(getLongIfExists("NEXT_KM"));
		return dto;
	}

}
