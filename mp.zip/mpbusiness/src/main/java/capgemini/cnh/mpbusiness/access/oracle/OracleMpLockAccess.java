package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpLockAccess;
import capgemini.cnh.mpbusiness.dto.MpLockDto;

/**
 * MP_LOCK table access for Oracle database.
 * 
 * @author cblois
 *
 */
public class OracleMpLockAccess extends OracleAccess<MpLockDto> implements IMpLockAccess {
	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 * @throws SystemException a system exception.
	 */
	public OracleMpLockAccess(Access dbAccess) throws SystemException {
		super(dbAccess);
	}
	
	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException can't get data source
	 */
	public OracleMpLockAccess() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpLockDto rs2Dto(ResultSet rs) throws SQLException {
		MpLockDto dto = new MpLockDto();

		dto.setVin(getStringIfExists(COL_VIN));
		dto.setCreationDate(getDateIfExists(COL_DATE));

		return dto;
	}

	/**
	 * @param vin : the MP lock to record for the vin.
	 * 
	 * @return true if created
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean addMpLock(String vin) throws SystemException {

		boolean created = false;
		Long ret = null;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("INSERT INTO ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" (");

		queryBuilder.append(COL_VIN);
		queryBuilder.append(", ");
		queryBuilder.append(COL_DATE);

		queryBuilder.append(") VALUES (");

		queryBuilder.append(formatString(vin));
		queryBuilder.append(", ");
		queryBuilder.append("sysdate");
		queryBuilder.append(")");

		ret = executeQueryI(queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			created = true;
		}
		return created;
	}

	/**
	 * @param vin : the MP lock to remove for the vin.
	 * 
	 * @return true if removed
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public boolean removeMpLock(String vin) throws SystemException {

		boolean removed = false;
		Long ret = null;
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("DELETE FROM ");
		queryBuilder.append(TABLE_NAME);
		queryBuilder.append(" WHERE ");
		queryBuilder.append(COL_VIN);
		queryBuilder.append("= ");
		queryBuilder.append(formatString(vin));

		ret = executeQueryI(queryBuilder.toString());
		if (ret != null && ret.longValue() > 0)
		{
			removed = true;
		}
		return removed;
	}

}
