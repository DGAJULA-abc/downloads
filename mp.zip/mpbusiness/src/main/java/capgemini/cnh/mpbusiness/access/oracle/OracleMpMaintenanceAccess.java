package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.access.table.statik.MP_NEXT_STOP_MIN;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.dto.MpAppointmentStatusEnum;
import capgemini.cnh.mpbusiness.dto.MpCallStatus;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;
import capgemini.cnh.mpbusiness.dto.MpMaintenanceDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * table access for Oracle database.
 * 
 * @author lestrabo
 *
 */
public class OracleMpMaintenanceAccess extends OracleAccess<MpMaintenanceDto> implements IMpMaintenanceAccess {

	/**
	 * Date format.
	 */
	public static final String DATE_FORMAT = "DD/MM/YYYY";

	/**
	 * Space ' ' string.
	 */
	public static final String SPACE = " ";
	public static final String POINT = ".";
	private static final String MP_FLEX_CONTRACT = "MP_FLEX_CONTRACT_WK";
	private static final String COLUMN_VIN_CONTRACT = "MP_FLEX_CONTRACT_WK.VIN";
	private static final String COLUMN_CUSTOMER_CODE_CONTRACT = "MP_FLEX_CONTRACT_WK.CUSTOMER_CODE";
	private static final String COLUMN_CONTRACT = "SAP_CONTRACT";
	private static final String MP_FLEX_CUSTOMER_SAP = "MP_FLEX_CUSTOMER_SAP";
	private static final String COLUMN_CUSTOMER_CODE = "MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE";
	private static final String COLUMN_CUSTOMER_NAME1 = "CUSTOMER_NAME1";
	private static final String COLUMN_CUSTOMER_NAME2 = "CUSTOMER_NAME2";
	private static final String COLUMN_CUSTOMER_PHONE = "PHONE_NUMBER";
	private static final String COLUMN_CUSTOMER_MAIL = "E_MAIL";
	private static final String MP_APPOINTMENT = "MP_APPOINTMENT";
	private static final String COLUMN_STATUS = "MP_APPOINTMENT_STATUS";

	/**
	 * @throws SystemException
	 */
	public OracleMpMaintenanceAccess() throws SystemException {
		super();

	}

	/**
	 * @param dbAccess
	 * @throws SystemException
	 */
	public OracleMpMaintenanceAccess(Access<MpMaintenanceDto> dbAccess) throws SystemException {
		super(dbAccess);

	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.framework.access.Access#rs2Dto(java.sql.ResultSet)
	 */
	@Override
	protected MpMaintenanceDto rs2Dto(ResultSet rs) throws SQLException {
		MpMaintenanceDto mpUrgentMaintenanceDto = new MpMaintenanceDto();

		MpCustomerDto mpCustomerDto = new MpCustomerDto(
				getStringIfExists(COLUMN_CUSTOMER_NAME1),
				getStringIfExists(COLUMN_CUSTOMER_NAME2),
				getStringIfExists(COLUMN_CUSTOMER_MAIL),
				getStringIfExists(COLUMN_CUSTOMER_PHONE));
		mpCustomerDto.setMpCallStatus(
				MpCallStatus.getMpCallStatusFromValue(getIntIfExists(MP_NEXT_STOP_MIN.CALL_STATUS.getColumnName())));
		mpUrgentMaintenanceDto.setMpCustomerDto(mpCustomerDto);
		MpNextStopMinDto mpNextStopMinDto = new MpNextStopMinDto();
		mpNextStopMinDto.setVin(getStringIfExists(MP_NEXT_STOP_MIN.VIN.getColumnName()));
		mpNextStopMinDto.setContractNb(getStringIfExists(COLUMN_CONTRACT));
		mpNextStopMinDto.setIdPlan(getLongIfExists(MP_NEXT_STOP_MIN.PLAN_ID.getColumnName()));
		mpNextStopMinDto.setAlert(MpType.MP_HOUR, getIntIfExists(MP_NEXT_STOP_MIN.ALERT_HOUR.getColumnName()));
		mpNextStopMinDto.setAlert(MpType.MP_KM, getIntIfExists(MP_NEXT_STOP_MIN.ALERT_KM.getColumnName()));
		mpNextStopMinDto.setAlert(MpType.MP_MONTH, getIntIfExists(MP_NEXT_STOP_MIN.ALERT_MONTH.getColumnName()));
		mpNextStopMinDto.setMinProposalDate(MpType.MP_HOUR, getDateIfExists(MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR.getColumnName()));
		mpNextStopMinDto.setMinProposalDate(MpType.MP_KM, getDateIfExists(MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM.getColumnName()));
		mpNextStopMinDto.setMinProposalDate(MpType.MP_MONTH, getDateIfExists(MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH.getColumnName()));
		mpNextStopMinDto.setNextValue(MpType.MP_MONTH, getLongIfExists(MP_NEXT_STOP_MIN.NEXT_MONTH.getColumnName()));
		mpNextStopMinDto.setNextValue(MpType.MP_KM, getLongIfExists(MP_NEXT_STOP_MIN.NEXT_KM.getColumnName()));
		mpNextStopMinDto.setNextValue(MpType.MP_HOUR, getLongIfExists(MP_NEXT_STOP_MIN.NEXT_HOUR.getColumnName()));
		mpNextStopMinDto.setAlertGroupId(getLongIfExists(MP_NEXT_STOP_MIN.ALERT_GROUP_ID.getColumnName()));
		mpUrgentMaintenanceDto.setMpNextStopMinDto(mpNextStopMinDto);
		mpUrgentMaintenanceDto.setDateAppointment(getDateIfExists("MP_APPOINTMENT_DATE"));
		mpUrgentMaintenanceDto.setIdAppointment(getLongIfExists("APPOINTMENT_ID"));
		mpUrgentMaintenanceDto.setCallStatus(getStringIfExists(COLUMN_STATUS));

		return mpUrgentMaintenanceDto;
	}

	//NEW
	public boolean getBooleanFromInt(Integer integer) {
		return (integer.intValue() == 1);
	}

	/**
	 * Request to get urgent maintenances
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCode(String dealerCode, String brandIceCode, String date, String customerCode) throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());

		QueryBuilder builder = buildMainQuerry(dealerCode, date, todayDate);
		//add filter on customer code
		builder.append(" AND  MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE=").append(formatString(customerCode));
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * Request to get urgent maintenances
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomers(String dealerCode, String brandIceCode, String date) throws SystemException {

		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());
		QueryBuilder builder = buildMainQuerry(dealerCode, date, todayDate);
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * Request to get urgent maintenances
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCodeAndCallStatus(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue)
			throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());

		QueryBuilder builder = buildMainQuerry(dealerCode, date, todayDate);

		if (customerCode != null && !customerCode.isEmpty())
		{
			//add filter on customer code
			builder.append(" AND  MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE=").append(formatString(customerCode));
		}
		if (mpCallStatusValue != null && (mpCallStatusValue.equals(MpCallStatus.CALLED.toString()) || mpCallStatusValue.equals(MpAppointmentStatusEnum.RECALL.toString())))
		{
			builder.append(" AND MP_APPOINTMENT.MP_APPOINTMENT_STATUS=").append(formatString(mpCallStatusValue));
		}
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * Request to get urgent maintenances
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpMaintenanceDto> getUrgentMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue, String connectedType)
			throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());

		QueryBuilder builder = buildMainQuerry(dealerCode, date, todayDate);

		if (customerCode != null && !customerCode.isEmpty())
		{
			//add filter on customer code
			builder.append(" AND  MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE=").append(formatString(customerCode));
		}
		if (mpCallStatusValue != null && (mpCallStatusValue.equals(MpCallStatus.CALLED.toString()) || mpCallStatusValue.equals(MpAppointmentStatusEnum.RECALL.toString())))
		{
			builder.append(" AND MP_APPOINTMENT.MP_APPOINTMENT_STATUS=").append(formatString(mpCallStatusValue));
		}

		if (connectedType != null && !connectedType.isEmpty())
		{
			//add filter on customer code
			builder.append(" AND MP_FLEX_CONTRACT_WK.CONNECTED_TYPE=").append(formatString(connectedType));
		}
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * Request to get urgent maintenances
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getUrgentMaintenances(java.lang.String)
	 */
	@Override
	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomersAndCallStatus(String dealerCode, String brandIceCode, String date, String mpCallStatusValue)
			throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());
		QueryBuilder builder = buildMainQuerry(dealerCode, date, todayDate);

		if (mpCallStatusValue != null && (mpCallStatusValue.equals(MpCallStatus.CALLED.toString()) || mpCallStatusValue.equals(MpAppointmentStatusEnum.RECALL.toString())))
		{
			builder.append(" AND MP_APPOINTMENT.MP_APPOINTMENT_STATUS=").append(formatString(mpCallStatusValue));
		}
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * 
	 * Method creating main query to get maintenance join valid contract,customer and MP_Next_STOP_Min
	 * this query is the same for all urgent maintenances and use in request to filter those maintenances
	 * 
	 * @param dealerCode
	 * @param date
	 * @param todayDate
	 * @param builder
	 */
	private QueryBuilder buildMainQuerry(String dealerCode, String date, String todayDate) {

		/*select  MP_FLEX_CONTRACT_WK.SAP_CONTRACT
		mp_next_stop_min.VIN, 
		mp_next_stop_min.ALERT_HOUR,
		mp_next_stop_min.ALERT_KM,
		mp_next_stop_min.ALERT_MONTH,
		mp_next_stop_min.DATE_PROPOSAL_HOUR, 
		mp_next_stop_min.DATE_PROPOSAL_KM,
		mp_next_stop_min.DATE_PROPOSAL_MONTH,
		mp_next_stop_min.CALL_STATUS,
		MP_FLEX_CUSTOMER_SAP.CUSTOMER_NAME1, 
		MP_FLEX_CUSTOMER_SAP.CUSTOMER_NAME2,
		MP_FLEX_CUSTOMER_SAP.PHONE_NUMBER,
		MP_FLEX_CUSTOMER_SAP.E_MAIL from mp_next_stop_min 
		inner join MP_FLEX_CONTRACT_WK on MP_FLEX_CONTRACT_WK.VIN=MP_NEXT_STOP_MIN.VIN 
		left join MP_FLEX_CUSTOMER_SAP on MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE=MP_FLEX_CONTRACT_WK.CUSTOMER_CODE
		WHERE  MP_FLEX_CONTRACT_WK.PLAN_ID=MP_NEXT_STOP_MIN.PLAN_ID AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_START  <= TO_DATE( todayDate,'DD/MM/YYYY') AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_EXP  >= TO_DATE(todayDate,'DD/MM/YYYY') 
		AND MP_FLEX_CONTRACT_WK.DEALER_CODE=dealerCode 
		AND (( MP_NEXT_STOP_MIN.ALERT_HOUR=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR IS NULL OR MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR <= TO_DATE(date,'DD/MM/YYYY'))) 
		OR (MP_NEXT_STOP_MIN.ALERT_KM=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM IS NULL OR MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM <= TO_DATE(date,'DD/MM/YYYY')))
		OR ( MP_NEXT_STOP_MIN.ALERT_MONTH=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH IS NULL OR MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH <= TO_DATE(date,'DD/MM/YYYY'))))*/

		// conversion todate (to char) to exclude time hh:mm:ss
		QueryBuilder builder = QueryBuilder.createQueryBuilder(true);
		builder.select()
				.select(MP_FLEX_CONTRACT, COLUMN_CONTRACT)
				.select(MP_NEXT_STOP_MIN.VIN)
				.select(MP_NEXT_STOP_MIN.PLAN_ID)
				.select(MP_NEXT_STOP_MIN.ALERT_HOUR)
				.select(MP_NEXT_STOP_MIN.ALERT_KM)
				.select(MP_NEXT_STOP_MIN.ALERT_MONTH)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH)
				.select(MP_NEXT_STOP_MIN.CALL_STATUS)
				.select(MP_NEXT_STOP_MIN.ALERT_GROUP_ID)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME1)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME2)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_PHONE)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_MAIL)
				.select(MP_APPOINTMENT, COLUMN_STATUS)
				.append(", nvl(MP_APPOINTMENT.MP_APPOINTMENT_UPDATE_DATE, MP_APPOINTMENT.MP_APPOINTMENT_OPEN_DATE) as MP_APPOINTMENT_DATE ")
				.append(", MP_APPOINTMENT.APPOINTMENT_ID ")
				.from(MP_NEXT_STOP_MIN.table())
				.append(" inner join ").append(MP_FLEX_CONTRACT).append(" on ").append(COLUMN_VIN_CONTRACT).append("=").append("MP_NEXT_STOP_MIN.VIN")
				.append(" left join ").append(MP_FLEX_CUSTOMER_SAP).append(" on ").append(COLUMN_CUSTOMER_CODE).append("=").append(COLUMN_CUSTOMER_CODE_CONTRACT)
				.append(" left join MP_APPOINTMENT on MP_NEXT_STOP_MIN.ALERT_GROUP_ID = MP_APPOINTMENT.ALERT_GROUP_ID and MP_APPOINTMENT.MP_APPOINTMENT_STATUS IN ('CALLED', 'RECALL') and MP_APPOINTMENT.DEALER_CODE = ")
				.append(formatString(dealerCode))
				.append(" WHERE  MP_FLEX_CONTRACT_WK.PLAN_ID=MP_NEXT_STOP_MIN.PLAN_ID AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_START  <= TO_DATE( ").append(formatString(todayDate))
				.append(",'DD/MM/YYYY')")
				.append(" AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_EXP  >= TO_DATE(").append(formatString(todayDate)).append(",'DD/MM/YYYY')")
				.append(" AND MP_FLEX_CONTRACT_WK.DEALER_CODE=").append(formatString(dealerCode))
				.append(" AND (( MP_NEXT_STOP_MIN.ALERT_HOUR=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR IS NULL OR TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR,'DD-MM-YYYY'),'DD/MM/YYYY')  <= TO_DATE("
						+ formatString(date)
						+ ",'DD/MM/YYYY')))")
				.append(" OR (MP_NEXT_STOP_MIN.ALERT_KM=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM IS NULL OR TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM,'DD-MM-YYYY'),'DD/MM/YYYY')   <= TO_DATE(")
				.append(formatString(date))
				.append(",'DD/MM/YYYY')))")
				.append(" OR ( MP_NEXT_STOP_MIN.ALERT_MONTH=1 AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH IS NULL OR TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH,'DD-MM-YYYY'),'DD/MM/YYYY')  <= TO_DATE(")
				.append(formatString(date))
				.append(",'DD/MM/YYYY'))))");

		return builder;
	}

	/**
	 * Request to get NEXT maintenances.
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#getNextMaintenances(java.lang.String)
	 */
	/**
	 */
	@Override
	public List<MpMaintenanceDto> getNextMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String connectedType) throws SystemException {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());

		QueryBuilder builder = QueryBuilder.createQueryBuilder(true);
		builder.select()
				.select(MP_FLEX_CONTRACT, COLUMN_CONTRACT)
				.select(MP_NEXT_STOP_MIN.VIN)
				.select(MP_NEXT_STOP_MIN.PLAN_ID)
				.select(MP_NEXT_STOP_MIN.ALERT_HOUR)
				.select(MP_NEXT_STOP_MIN.ALERT_KM)
				.select(MP_NEXT_STOP_MIN.ALERT_MONTH)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM)
				.select(MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH)
				.select(MP_NEXT_STOP_MIN.NEXT_HOUR)
				.select(MP_NEXT_STOP_MIN.NEXT_KM)
				.select(MP_NEXT_STOP_MIN.NEXT_MONTH)
				.select(MP_NEXT_STOP_MIN.CALL_STATUS)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME1)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_NAME2)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_PHONE)
				.select(MP_FLEX_CUSTOMER_SAP, COLUMN_CUSTOMER_MAIL)
				.from(MP_NEXT_STOP_MIN.table())
				.append(" inner join " + MP_FLEX_CONTRACT + " on " + COLUMN_VIN_CONTRACT + "=" + MP_NEXT_STOP_MIN.table().getName() + "." + MP_NEXT_STOP_MIN.VIN.getColumnName())
				.append(" left join " + MP_FLEX_CUSTOMER_SAP + " on " + COLUMN_CUSTOMER_CODE + "=" + COLUMN_CUSTOMER_CODE_CONTRACT)
				.append(" WHERE MP_FLEX_CONTRACT_WK.PLAN_ID=MP_NEXT_STOP_MIN.PLAN_ID ");

		if (customerCode != null && !customerCode.isEmpty())
		{
			//add filter on customer code
			builder.append(" AND  MP_FLEX_CUSTOMER_SAP.CUSTOMER_CODE=").append(formatString(customerCode));
		}

		if (connectedType != null && !connectedType.isEmpty())
		{
			//add filter on customer code
			builder.append(" AND MP_FLEX_CONTRACT_WK.CONNECTED_TYPE=").append(formatString(connectedType));
		}

		builder.append(" AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_START  <= TO_DATE( " + formatString(todayDate) + ",'DD/MM/YYYY')"
				+ " AND MP_FLEX_CONTRACT_WK.CONTRACT_DATE_EXP  >= TO_DATE(" + formatString(todayDate) + ",'DD/MM/YYYY')")
				.append(" AND MP_FLEX_CONTRACT_WK.DEALER_CODE=").append(formatString(dealerCode))
				.append(" AND (( MP_NEXT_STOP_MIN.ALERT_HOUR=0 AND (MP_NEXT_STOP_MIN.NEXT_HOUR IS NOT NULL AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR IS NULL OR  TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_HOUR,'DD-MM-YYYY'),'DD/MM/YYYY') <= TO_DATE("
						+ formatString(date)
						+ ",'DD/MM/YYYY'))))")
				.append(" OR (MP_NEXT_STOP_MIN.ALERT_KM=0 AND (MP_NEXT_STOP_MIN.NEXT_KM IS NOT NULL  AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM IS NULL OR TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_KM,'DD-MM-YYYY'),'DD/MM/YYYY') <= TO_DATE("
						+ formatString(date)
						+ ",'DD/MM/YYYY'))))")
				.append(" OR ( MP_NEXT_STOP_MIN.ALERT_MONTH=0 AND (MP_NEXT_STOP_MIN.NEXT_MONTH IS NOT NULL AND (MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH IS NULL OR TO_DATE(TO_CHAR(MP_NEXT_STOP_MIN.DATE_PROPOSAL_MONTH,'DD-MM-YYYY'),'DD/MM/YYYY') <= TO_DATE("
						+ formatString(date)
						+ ",'DD/MM/YYYY')))))");
		// Execute the query and get the result list
		return executeQueryN(builder);

	}

	/**
	 * Request to know if the plan is existing in database.
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess#isExistingPlanId(java.lang.String)
	 */
	@Override
	public boolean isExistingPlanId(Long planId) throws SystemException {

		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("select PLAN_ID,PLAN_PROJECT_ID,PLAN_NAME,PLAN_STATUS,PLAN_LAST_MODIFIER,PLAN_DATE_MODIF,PLAN_STANDARD,PLAN_PERF_TYPE,PLAN_EXT_ID,PLAN_OLD_EXT_ID ");
		queryBuilder.append(" from mp_maintenance_plan where plan_id=");
		queryBuilder.append(formatString(planId));
		queryBuilder.append(" OR plan_ext_id=");
		queryBuilder.append(formatString(planId));

		return executeQuery0(queryBuilder.toString());

	}

}
