package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * 
 * @author bmilcend
 *
 */
public class OracleMpNextStopAlertAccess extends OracleAccess<MpNextStopAlertDto> implements IMpNextStopAlertAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpNextStopAlertAccess() throws SystemException {
		super();
	}

	/**
	 * 
	 * Get the list of VIN-COUPON in alerts.
	 * 
	 * @param alertType: the alertType
	 * @param isFlexibleCoupons: true if we want to get flexible coupons (MP_NEXT_FLEX_STOP_WK table)
	 * @return the list of VIN-COUPON in alerts.
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopAlertDto> getCouponInAlert(MpType alertType, boolean isFlexibleCoupons) throws SystemException {
		StringBuilder query = new StringBuilder();
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = df.format(new Date());
		query.append(" SELECT distinct MNS.VIN, MNS.COUPON_CODE, MCFW.DEALER_CODE, MCFW.BRAND_ICECODE ");

		if (alertType.equals(MpType.MP_KM))
		{
			query.append(" , MNS.NEXT_KM ");
		}
		else if (alertType.equals(MpType.MP_HOUR))
		{
			query.append(" , MNS.NEXT_HOUR ");
		}
		else if (alertType.equals(MpType.MP_MONTH))
		{
			query.append(" , MNS.NEXT_MONTH, MNS.DATE_MONTH ");
		}

		query.append(" FROM MP_ALERT_TOLERANCE MAT, MP_VEHICLE_KM_HOUR_AV  MVHKA, MP_FLEX_CONTRACT_WK MCFW, MP_NEXT_STOP_MIN MNSM, ");
		if (isFlexibleCoupons)
		{
			query.append(" MP_NEXT_FLEX_STOP_WK MNS ");
		}
		else
		{
			query.append(" MP_NEXT_STOP MNS ");
		}
		query.append(" WHERE  MNSM.VIN = MNS.VIN ");
		if (isFlexibleCoupons)
		{
			query.append(" AND MNSM.PLAN_ID = MAT.PLAN_ID ");
		}
		else
		{
			query.append(" AND MNS.PLAN_ID = MAT.PLAN_ID ");
		}
		query.append(" AND MNS.VIN = MVHKA.VIN ");
		query.append(" AND MCFW.VIN = MNS.VIN ");
		query.append(" AND MCFW.CONTRACT_DATE_START  <= TO_DATE( " + formatString(todayDate) + ",'DD/MM/YYYY')");
		query.append(" AND MCFW.CONTRACT_DATE_EXP  >= TO_DATE(" + formatString(todayDate) + ",'DD/MM/YYYY')");

		//Exclude alerts from CROOM
		if (isFlexibleCoupons)
		{
			query.append(" AND MNS.FROM_CROOM = 0 ");
		}

		if (alertType.equals(MpType.MP_KM))
		{
			query.append(" AND (MNS.NEXT_KM is not null AND MNS.NEXT_KM <> 0 AND MNS.NEXT_KM <> -1 AND (MNS.NEXT_KM - MVHKA.CURRENT_KM) <= MAT.TOL_KM) ");
			query.append(" AND MNSM.ALERT_KM = 1 ");
		}
		else if (alertType.equals(MpType.MP_HOUR))
		{
			query.append(" AND (MNS.NEXT_HOUR is not null AND MNS.NEXT_HOUR <> 0 AND MNS.NEXT_HOUR <> -1 AND (MNS.NEXT_HOUR - MVHKA.CURRENT_HOUR) <= MAT.TOL_HOUR) ");
			query.append(" AND MNSM.ALERT_HOUR = 1 ");
		}
		else if (alertType.equals(MpType.MP_MONTH))
		{
			query.append(" AND MNS.DATE_MONTH is not null ");
			query.append(" AND ADD_MONTHS(mns.date_month,-tol_month) < =sysdate ");
			query.append(" AND MNSM.ALERT_MONTH = 1 ");
		}

		query.append(" ORDER by MNS.VIN ");

		return executeQueryN(query.toString());
	}

	@Override
	protected MpNextStopAlertDto rs2Dto(ResultSet rs) throws SQLException {

		// New dto
		MpNextStopAlertDto dto = new MpNextStopAlertDto();

		dto.setVin(getStringIfExists("VIN"));
		dto.setIdPlan(getLongIfExists("PLAN_ID"));
		dto.setIntervalCode(getStringIfExists("COUPON_CODE"));
		dto.setDealerCode(getStringIfExists("DEALER_CODE"));
		dto.setBrandIceCode(getStringIfExists("BRAND_ICECODE"));
		dto.setNextValue(MpType.MP_MONTH, getLongIfExists("NEXT_MONTH"));
		dto.setNextValue(MpType.MP_HOUR, getLongIfExists("NEXT_HOUR"));
		dto.setNextValue(MpType.MP_KM, getLongIfExists("NEXT_KM"));
		dto.setProposalDate(MpType.MP_HOUR, getDateIfExists("DATE_HOUR"));
		dto.setProposalDate(MpType.MP_KM, getDateIfExists("DATE_KM"));
		dto.setProposalDate(MpType.MP_MONTH, getDateIfExists("DATE_MONTH"));

		return dto;
	}
}
