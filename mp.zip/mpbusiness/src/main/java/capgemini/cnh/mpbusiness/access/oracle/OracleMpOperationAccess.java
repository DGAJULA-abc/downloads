package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.BindDto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpOperationAccess;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;

/**
 * 
 * @author mamestoy
 *
 */
public class OracleMpOperationAccess extends OracleAccess<MpIntervalOperationDto> implements IMpOperationAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public OracleMpOperationAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpIntervalOperationDto> getListOperations(String intervalId, String language, String defaultLanguage) throws SystemException {
		StringBuilder query = new StringBuilder();
		List<BindDto> bindList = new LinkedList<BindDto>();

		query.append(
				" Select MP_OPERATION_SERIES.OPE_SER_ID,  OPE_CODE, OPE_SRT, OPE_LOC_FAM, OPE_LOC_GRO, OPE_LOC_SUG, OPE_INF_TOP, OPE_INF_SUT, OPE_INF_CAT, OPE_INF_INF, t1.message OPE_TITLE , t2.message OPE_DESCRIPTION, ope_description_title_id, ope_Title_ID, OPE_LABEL, N_NAME ");
		query.append(" from mp_interval_operation, mp_operation_series, mp_operation, MP_OPERATION_TITLE t1, MP_OPERATION_TITLE t2, FAMILIES, NAMES ");
		query.append(" where def_interval_id= ? ");
		bindList.add(new BindDto(Access.STRING_TYPE, intervalId));
		query.append(" and def_ope_series_id=ope_ser_id ");
		query.append(" and ope_operation_id=ope_id ");
		query.append(" AND (OPE_CODE <> '-' or OPE_CODE  is null) ");
		query.append(" and ope_Title_ID=t1.idref_table_title ");
		query.append(" and (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" or (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, defaultLanguage));
		query.append(" AND t1.idref_table_title NOT IN");
		query.append(" (SELECT tt.idref_table_title FROM table_title tt WHERE tt.IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(")))");
		query.append(" and ope_description_title_id = t2.idref_table_title(+) ");
		query.append(" and ((t2.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" or (t2.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, defaultLanguage));
		query.append(" AND t2.idref_table_title NOT IN");
		query.append(" (SELECT tt1.idref_table_title FROM table_title tt1 WHERE tt1.IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(")))");
		query.append(" or t2.idlanguage is null) and OPE_LOC_FAM = ICE_CODE and N_ID = NAM_N_ID and N_IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" order by SUBSTR(OPE_CODE,  LENGTH(OPE_CODE), 1) || SUBSTR(OPE_CODE, 1,  LENGTH(OPE_CODE)-1), ope_srt ");

		List<MpIntervalOperationDto> toReturn = executeQueryNWithBind(query.toString(), bindList);
		return toReturn;

	}

	/**
	 * Get the operation by operation series id.
	 * 
	 * @param planId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	@Override
	public List<MpIntervalOperationDto> getOperation(Long opeSerId, String language, String defaultLanguage) throws SystemException {

		StringBuilder query = new StringBuilder();
		List<BindDto> bindList = new LinkedList<BindDto>();

		query.append(
				" Select MP_OPERATION_SERIES.OPE_SER_ID, OPE_CODE, OPE_SRT, OPE_LOC_FAM, OPE_LOC_GRO, OPE_LOC_SUG, OPE_INF_TOP, OPE_INF_SUT, OPE_INF_CAT, OPE_INF_INF, t1.message OPE_TITLE , t2.message OPE_DESCRIPTION, ope_description_title_id, ope_Title_ID, OPE_LABEL ");
		query.append(" from mp_operation_series, mp_operation, MP_OPERATION_TITLE t1, MP_OPERATION_TITLE t2 ");
		query.append(" where ope_ser_id = ? ");
		bindList.add(new BindDto(Access.LONG_TYPE, opeSerId));
		query.append(" and ope_operation_id=ope_id ");
		query.append(" AND (OPE_CODE <> '-' or OPE_CODE  is null) ");
		query.append(" and ope_Title_ID=t1.idref_table_title ");
		query.append(" and (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" or (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, defaultLanguage));
		query.append(" AND t1.idref_table_title NOT IN");
		query.append(" (SELECT tt.idref_table_title FROM table_title tt WHERE tt.IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(")))");
		query.append(" and ope_description_title_id = t2.idref_table_title(+) ");
		query.append(" and ((t2.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" or (t2.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, defaultLanguage));
		query.append(" AND t2.idref_table_title NOT IN");
		query.append(" (SELECT tt1.idref_table_title FROM table_title tt1 WHERE tt1.IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(")))");
		query.append(" or t2.idlanguage is null)");

		query.append(" order by SUBSTR(OPE_CODE,  LENGTH(OPE_CODE), 1) || SUBSTR(OPE_CODE, 1,  LENGTH(OPE_CODE)-1), ope_srt ");

		List<MpIntervalOperationDto> toReturn = executeQueryNWithBind(query.toString(), bindList);

		return toReturn;
	}

	@Override
	public List<MpIntervalOperationDto> getOperationWithSeriesLabel(MpIntervalOperationDto operation, String language, String defaultLanguage) throws SystemException {
		StringBuilder query = new StringBuilder();
		List<BindDto> bindList = new LinkedList<BindDto>();

		query.append(" Select MP_OPERATION_SERIES.OPE_SER_ID, t1.message OPE_LABEL_SERIES ");
		query.append(" from mp_operation_series, MP_OPERATION_TITLE t1 ");
		query.append(" where ope_ser_id = ? ");
		bindList.add(new BindDto(Access.LONG_TYPE, operation.getIdOperationSeries()));
		query.append(" and ope_label = t1.idref_table_title ");
		query.append(" and (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(" or (t1.idlanguage = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, defaultLanguage));
		query.append(" AND t1.idref_table_title NOT IN");
		query.append(" (SELECT tt.idref_table_title FROM MP_OPERATION_TITLE tt WHERE tt.IDLANGUAGE = ?");
		bindList.add(new BindDto(Access.STRING_TYPE, language));
		query.append(")))");

		// Only one result is retrieved at a time but bind queries only return a list
		List<MpIntervalOperationDto> toReturn = executeQueryNWithBind(query.toString(), bindList);

		return toReturn;
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpIntervalOperationDto rs2Dto(ResultSet rs) throws SQLException {
		MpIntervalOperationDto dto = new MpIntervalOperationDto();
		dto.setIdOperationSeries(getLongIfExists("OPE_SER_ID"));
		dto.setOperationLabel(getStringIfExists("OPE_TITLE"));
		dto.setOperationLabelId(getStringIfExists("OPE_TITLE_ID"));
		dto.setOperationDescription(getStringIfExists("OPE_DESCRIPTION"));
		dto.setOperationDescriptionId(getStringIfExists("OPE_DESCRIPTION_TITLE_ID"));
		dto.setOperationLabelForSeriesId(getLongIfExists("OPE_LABEL"));
		dto.setOperationLabelForSeries(getStringIfExists("OPE_LABEL_SERIES"));
		dto.setMicroOperation(getStringIfExists("OPE_CODE"));
		dto.setSrtOperation(getStringIfExists("OPE_SRT"));

		dto.setLocationFamilyIceCode(getStringIfExists("OPE_LOC_FAM"));
		dto.setLocationGroupIceCode(getStringIfExists("OPE_LOC_GRO"));
		dto.setLocationSubGroupIceCode(getStringIfExists("OPE_LOC_SUG"));

		dto.setInfotypeTopicIceCode(getStringIfExists("OPE_INF_TOP"));
		dto.setInfotypeSubTopicIceCode(getStringIfExists("OPE_INF_SUT"));
		dto.setInfotypeCategoryIceCode(getStringIfExists("OPE_INF_CAT"));
		dto.setInfotypeInfotypeIceCode(getStringIfExists("OPE_INF_INF"));
		dto.setLocation(getStringIfExists("N_NAME"));

		return dto;
	}
}
