package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.dto.BindDto;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;

/**
 * 
 * @author cblois
 *
 */
public class OracleMpPartDescriptionAccess extends OracleAccess<MpPartDescriptionDto> implements IMpPartDescriptionAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException
	 *             Can't get data source.
	 */
	public OracleMpPartDescriptionAccess() throws SystemException {
		super();
	}

	/**
	 * @param rs
	 *            a resultset
	 * @throws SQLException
	 *             an exception
	 * @return a Dto
	 */
	protected MpPartDescriptionDto rs2Dto(ResultSet rs) throws SQLException {
		MpPartDescriptionDto dto = new MpPartDescriptionDto();

		dto.setDescPnCode(getStringIfExists("DESC_PN_CODE"));
		dto.setDescLanguage(getStringIfExists("DESC_LANGUAGE"));
		dto.setDescription(getStringIfExists("DESCRIPTION"));

		return dto;
	}

	/**
	 * Get the List of parts for a given part for all the languages.
	 * 
	 * @param code the part code
	 * @return the list of parts
	 * @throws SystemException system exception
	 */
	@Override
	public List<MpPartDescriptionDto> getPartsByCode(String code) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append(" wpd.DESC_PN_CODE = ")
				.append(formatString(code));

		// Execute the query and get the result list
		return executeQueryN(query.toString());
	}

	/**
	 * Get the part for a given part and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	@Override
	public MpPartDescriptionDto getPartsByCodeAndLanguage(String code, String language) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append(" wpd.DESC_PN_CODE = ")
				.append(formatString(code))
				.append(" AND wpd.DESC_LANGUAGE = ")
				.append(formatString(language));

		return executeQuery1(query.toString());
	}

	@Override
	public List<MpPartDescriptionDto> getPartsDescriptionByLanguage(List<String> partList, String language) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT wpd.DESC_PN_CODE, wpd.DESC_LANGUAGE, wpd.DESCRIPTION ")
				.append(" FROM WEB_MP_PART_DESCRIPTION wpd ")
				.append(" WHERE ")
				.append(" wpd.DESC_PN_CODE in (SELECT COLUMN_VALUE FROM TABLE(?)) ")
				.append(" AND wpd.DESC_LANGUAGE = ")
				.append(formatString(language));

		BindDto bindDto1 = new BindDto(Access.STRING_ARRAY_TYPE, partList.toArray());
		List<BindDto> bindList = new ArrayList<>();
		bindList.add(bindDto1);

		return executeQueryNWithBind(query.toString(), bindList);
	}
}
