package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPartDetailAccess;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;

/**
 * 
 * @author cblois
 *
 */
public class OracleMpPartDetailAccess extends OracleAccess<MpPartDetailDto> implements IMpPartDetailAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpPartDetailAccess() throws SystemException {
		super();
	}

	@Override
	public MpPartDetailDto getPartDetail(String partNumber) throws SystemException {
		//get the father child with the correct order by following each node
		StringBuilder query = new StringBuilder();
		query.append(" SELECT PND_PART_NUMBER , PND_STATUS  , PND_LABEL_EN  ");
		query.append("FROM  MP_PART_NUMBER_DETAIL ");
		query.append(" WHERE PND_PART_NUMBER =");
		query.append(formatString(partNumber));

		return executeQuery1(query.toString());
	}

	@Override
	protected MpPartDetailDto rs2Dto(ResultSet rs) throws SQLException {
		MpPartDetailDto dto = new MpPartDetailDto();
		dto.setPndPartNumber(getStringIfExists("PND_PART_NUMBER"));
		dto.setPndStatus(getStringIfExists("PND_STATUS"));
		dto.setPndLabelEn(getStringIfExists("PND_LABEL_EN"));
		return dto;
	}
}
