package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.dto.MpPartSupersessionDto;

/**
 * 
 * @author cblois
 *
 */
public class OracleMpPartSupersessionAccess extends OracleAccess<MpPartSupersessionDto> implements IMpPartSupersessionAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpPartSupersessionAccess() throws SystemException {
		super();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess#getSupersessionList(java.lang.String)
	 */
	@Override
	public List<MpPartSupersessionDto> getSupersessionList(String partNumber) throws SystemException {
		//get the father child with the correct order by following each node
		StringBuilder query = new StringBuilder();
		query.append(" SELECT PNS_FATHER, PNS_CHILD, PNS_QUANTITY ,PNS_TYPE , PND_STATUS  , PND_LABEL_EN  ");
		query.append("FROM MP_PART_SUPERSESSION , MP_PART_NUMBER_DETAIL ");
		query.append(" WHERE PNS_CHILD  = PND_PART_NUMBER(+) ");
		query.append(" START WITH PNS_FATHER = ");
		query.append(formatString(partNumber));
		query.append("CONNECT BY NOCYCLE  PRIOR   PNS_CHILD = PNS_FATHER ");

		return executeQueryN(query.toString());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.framework.access.Access#rs2Dto(java.sql.ResultSet)
	 */
	@Override
	protected MpPartSupersessionDto rs2Dto(ResultSet rs) throws SQLException {
		MpPartSupersessionDto dto = new MpPartSupersessionDto();
		dto.setPnsFather(getStringIfExists("PNS_FATHER"));
		dto.setPnsChild(getStringIfExists("PNS_CHILD"));
		dto.setPnsQuantity(getLongIfExists("PNS_QUANTITY"));
		dto.setPnsType(getStringIfExists("PNS_TYPE"));
		dto.setPnsStatus(getStringIfExists("PND_STATUS"));
		dto.setPnsLabel(getStringIfExists("PND_LABEL_EN"));

		return dto;
	}
}
