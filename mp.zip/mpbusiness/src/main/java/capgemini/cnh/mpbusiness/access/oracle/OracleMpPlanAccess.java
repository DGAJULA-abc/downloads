package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.access.table.statik.MP_MAINTENANCE_CONDITION;
import capgemini.cnh.framework.access.table.statik.MP_MAINTENANCE_PLAN;
import capgemini.cnh.framework.access.table.statik.MP_MAINTENANCE_PROJECT;
import capgemini.cnh.framework.access.table.statik.MP_PLAN_APPLICABILITY;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.FormatUtil;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.product.SeriesDto;
import capgemini.cnh.mpbusiness.access.IMpPlanAccess;
import capgemini.cnh.mpbusiness.dto.MpConditionDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * 
 * @author cblois
 *
 */
public class OracleMpPlanAccess extends OracleAccess<MpPlanDto> implements IMpPlanAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpPlanAccess() throws SystemException {
		super();
	}

	@Override
	public List<MpPlanDto> getListByProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException {
		/* Query example:
		 * 
		 * select distinct 
		 * 
		 * mp_maintenance_plan.plan_id
		 * , mp_maintenance_plan.plan_project_id
		 * , mp_maintenance_project.mp_number
		 * , mp_maintenance_project.mp_version
		 * , mp_plan_applicability.plan_config 
		 * 
		 * from 
		 * 
		 * mp_maintenance_plan 
		 * left join mp_plan_applicability on mp_maintenance_plan.plan_id = mp_plan_applicability.plan_id 
		 * left join mp_maintenance_condition on mp_maintenance_plan.plan_id = mp_maintenance_condition.cond_plan_id
		 * inner join mp_maintenance_project on mp_maintenance_plan.plan_project_id = mp_maintenance_project.mp_id 
		 * 
		 * where 
		 * 
		 * mp_maintenance_plan.plan_project_id in (145, 146) 
		 * and (mp_plan_applicability.plan_market = '3' or mp_plan_applicability.plan_market is null)
		 */
		QueryBuilder builder = QueryBuilder.createQueryBuilder(true)
				.selectDistinct()
				.select(MP_MAINTENANCE_PLAN.PLAN_ID)
				.select(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID)
				.select(MP_MAINTENANCE_PLAN.PLAN_STANDARD)
				.select(MP_MAINTENANCE_PROJECT.MP_NUMBER)
				.select(MP_MAINTENANCE_PROJECT.MP_VERSION)
				.select(MP_PLAN_APPLICABILITY.PLAN_CONFIG)
				.select(MP_MAINTENANCE_CONDITION.COND_USAGE_VALUE)
				.select(MP_MAINTENANCE_PLAN.PLAN_EXT_ID)
				.from(MP_MAINTENANCE_PLAN.table())
				.leftJoin(MP_MAINTENANCE_PLAN.PLAN_ID, MP_PLAN_APPLICABILITY.PLAN_ID)
				.leftJoin(MP_MAINTENANCE_PLAN.PLAN_ID, MP_MAINTENANCE_CONDITION.COND_PLAN_ID)
				.innerJoinColumn(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID, MP_MAINTENANCE_PROJECT.MP_ID)
				.where()
				.whereColumnIn(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID).appendList(projectIdList.toArray());
		if (context.getModel() != null && context.getModel().getIceCode() != null)
		{
			builder.whereEqualValueOrIsNull(MP_PLAN_APPLICABILITY.PLAN_MOD, context.getModel().getIceCode());
			if (context.getTechnicalType() != null && context.getTechnicalType().getIceCode() != null)
			{
				builder.whereEqualValueOrIsNull(MP_PLAN_APPLICABILITY.PLAN_TT, context.getTechnicalType().getIceCode());
			}
		}
		if (context.getMarket() != null && context.getMarket().getMkId() != null)
		{
			builder.whereEqualValueOrIsNull(MP_PLAN_APPLICABILITY.PLAN_MARKET, context.getMarket().getMkId().intValue());
		}
		List<MpPlanDto> result = executeQueryN(builder);
		return result;
	}

	/**
	 * Get the plan by id.
	 * 
	 * @param planId filter on plan id
	 * 
	 * @return the plan
	 * @throws SystemException system exception
	 */
	public MpPlanDto getPlan(Long planId) throws SystemException {

		QueryBuilder builder = QueryBuilder.createQueryBuilder(true)
				.selectDistinct()
				.select(MP_MAINTENANCE_PLAN.PLAN_ID)
				.select(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID)
				.select(MP_MAINTENANCE_PROJECT.MP_NUMBER)
				.select(MP_MAINTENANCE_PROJECT.MP_VERSION)
				.select(MP_PLAN_APPLICABILITY.PLAN_CONFIG)
				.from(MP_MAINTENANCE_PLAN.table())
				.leftJoin(MP_MAINTENANCE_PLAN.PLAN_ID, MP_PLAN_APPLICABILITY.PLAN_ID)
				.innerJoinColumn(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID, MP_MAINTENANCE_PROJECT.MP_ID)
				.where()
				.whereEqualValue(MP_MAINTENANCE_PLAN.PLAN_ID, planId);
		MpPlanDto result = executeQuery1(builder);
		return result;

	}

	/**
	 * Get the performance list by plan list.
	 * 
	 * @param planList for filter
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getPerformanceListByPlanList(String planList) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select distinct PLAN_PERF_TYPE from mp_maintenance_plan where PLAN_ID in ( ");
		query.append(planList);
		query.append(") order by 1 desc");

		List<MpPlanDto> toReturn = executeQueryN(query.toString());

		return toReturn;

	}

	/**
	 * Get the number of plans with hour in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithHour(String planList) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select count(distinct int_id) as nb from mp_interval where int_plan_id in ( ");
		query.append(planList);
		query.append(") and (int_after_value_hour is not null or int_start_value_hour is not null)");

		Long nbPlans = executeQueryCount(query.toString(), "nb");

		return nbPlans;

	}

	public MpPlanDto getPerformanceForPlanId(String planExtId, String projectNumber, String version) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select PLAN_PERF_TYPE from mp_maintenance_plan where PLAN_EXT_ID = ");
		query.append(planExtId);
		query.append(" AND ");
		query.append(" PLAN_PROJECT_ID =(select MP_ID from ICE_DBA.MP_MAINTENANCE_PROJECT where MP_NUMBER = ");
		query.append(projectNumber);
		query.append(" and MP_VERSION= ");
		query.append(version);
		query.append(")");

		MpPlanDto toReturn = executeQuery1(query.toString());

		return toReturn;

	}

	/**
	 * Get the number of plans with mileage in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithMileage(String planList) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select count(distinct int_id) as nb from mp_interval where int_plan_id in ( ");
		query.append(planList);
		query.append(") and (int_after_value_km is not null or int_start_value_km is not null)");

		Long nbPlans = executeQueryCount(query.toString(), "nb");

		return nbPlans;

	}

	@Override
	public List<MpPlanDto> getPlanWithCriteria(List<Long> planIdList, int usageId, String performance) throws SystemException {
		/* Query example:
		 * 
		 * select 
		 * 
		 * mp_maintenance_plan.plan_id
		 * , mp_maintenance_plan.plan_name
		 * , mp_maintenance_plan.plan_perf_type
		 * , mp_maintenance_plan.plan_project_id
		 * , mp_plan_applicability.plan_config 
		 * 
		 * from 
		 * 
		 * mp_maintenance_plan 
		 * 
		 * left join mp_plan_applicability on mp_maintenance_plan.plan_id = mp_plan_applicability.plan_id 
		 * 
		 * inner join mp_maintenance_condition on mp_maintenance_plan.plan_id = mp_maintenance_condition.cond_plan_id 
		 * 
		 * where 
		 * 
		 * mp_maintenance_plan.plan_perf_type = 'max' 
		 * and mp_maintenance_plan.plan_id in ('581', '696', '583', '578', '579', '580')
		 * 
		 */
		QueryBuilder query = QueryBuilder.createQueryBuilder(true);
		query.selectDistinct().select(MP_MAINTENANCE_PLAN.PLAN_ID)
				.select(MP_MAINTENANCE_PLAN.PLAN_NAME)
				.select(MP_MAINTENANCE_PLAN.PLAN_PERF_TYPE)
				.select(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID)
				.select(MP_MAINTENANCE_PROJECT.MP_NUMBER)
				.select(MP_MAINTENANCE_PROJECT.MP_VERSION)
				.select(MP_MAINTENANCE_PROJECT.MP_DATE_MODIF)
				.select(MP_PLAN_APPLICABILITY.PLAN_CONFIG)
				.append(" ,nvl(MP_MAINTENANCE_PLAN.PLAN_EXT_ID,MP_MAINTENANCE_PLAN.PLAN_ID) as PLAN_EXT_ID ")
				.from(MP_MAINTENANCE_PLAN.table())
				.leftJoin(MP_MAINTENANCE_PLAN.PLAN_ID, MP_PLAN_APPLICABILITY.PLAN_ID)
				.innerJoinColumn(MP_MAINTENANCE_PLAN.PLAN_ID, MP_MAINTENANCE_CONDITION.COND_PLAN_ID)
				.innerJoinColumn(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID, MP_MAINTENANCE_PROJECT.MP_ID)
				.where();
		if (usageId == MpUsageDto.DEFAULT_VALUE_ID)
		{
			query.whereColumnIsNull(MP_MAINTENANCE_CONDITION.COND_USAGE_VALUE);
		}
		else if (usageId > 0)
		{
			query.whereEqualValue(MP_MAINTENANCE_CONDITION.COND_USAGE_VALUE, Integer.valueOf(usageId));
		}
		query.whereEqualValue(MP_MAINTENANCE_PLAN.PLAN_PERF_TYPE, performance); // -- [dbabillo] see MML 12/09/2017 mail alessendro
		query.whereColumnInList(MP_MAINTENANCE_PLAN.PLAN_ID, planIdList);

		List<MpPlanDto> result = executeQueryN(query);
		return (result);
	}

	/**
	 * eTIM GO base copy script.
	 * 
	 * @param serieDto serie
	 * @return list of Mp
	 * @throws SystemException a system exception
	 */
	public List<MpPlanDto> getMaintenancePlanBySerie(SeriesDto serieDto) throws SystemException {
		String icecodes[] = serieDto.getFullIceCode().split("[.]");
		// Getting brand
		String brand = icecodes[0].trim();
		// Getting type
		String type = icecodes[1].trim();
		// Getting type
		String product = icecodes[2].trim();
		// Getting serie
		String serie = icecodes[3].trim();
		StringBuilder query = new StringBuilder();

		query.append("SELECT mp.PLAN_ID, mp.PLAN_PROJECT_ID, mp.PLAN_NAME, mp.PLAN_STATUS, mp.PLAN_LAST_MODIFIER, mp.PLAN_DATE_MODIF, mp.PLAN_STANDARD, mp.PLAN_PERF_TYPE, mp.PLAN_EXT_ID")
				.append(" FROM MP_MAINTENANCE_PLAN mp, MP_MAINTENANCE_PROJECT mpp, MP_PROJECT_APPLICABILITY@ICE app ")
				.append(" WHERE ")
				.append(" app.MP_PROJECT_ID = mpp.MP_ID ")
				.append(" AND mpp.MP_ID = mp.PLAN_PROJECT_ID ")
				.append(" AND app.MP_APP_BRA=" + FormatUtil.formatString(brand))
				.append(" AND app.MP_APP_TYP=" + FormatUtil.formatString(type))
				.append(" AND app.MP_APP_PRO=" + FormatUtil.formatString(product))
				.append(" AND app.MP_APP_SER=" + FormatUtil.formatString(serie));

		List<MpPlanDto> toReturn = executeQueryN(query.toString());

		return toReturn;
	}

	/**
	 * Get the external plan id.
	 * 
	 * @param planId for filter
	 * @return external plan id
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getExternalPlanId(Long planId) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append(" select nvl(plan_ext_id,plan_id) as plan_ext_id  from mp_maintenance_plan where plan_id = ");
		query.append(planId);

		return (MpPlanDto) executeQuery1(query.toString());

	}

	/**
	 * Get the publication date of the IU.
	 * 
	 * @param planId the id of the plan
	 * @param projectVersion the version of the project
	 * @return the IU information
	 * @throws SystemException a system exception
	 */
	public MpPlanDto getMpIuPublicationDate(Long planId, Integer projectVersion) throws SystemException {
		StringBuilder query = new StringBuilder();

		query.append("SELECT DISTINCT plan_id, WEB_DATEPUB as MP_DATE_MODIF, MP_VERSION ");
		query.append(" from mp_maintenance_plan, mp_maintenance_project, mp_project_document, WEBIULINK ");
		query.append(" WHERE (plan_id = ");
		query.append(planId);
		query.append(" or plan_ext_id = ");
		query.append(planId);
		query.append(") and MP_ID =PLAN_PROJECT_ID AND MP_VERSION >= ");
		query.append(projectVersion);
		query.append(" and MP_PROJECT_ID= PLAN_PROJECT_ID and MP_IU_ID=WEB_IUIFSID ");
		query.append(" ORDER BY MP_VERSION desc, WEB_DATEPUB");

		return executeQuery1(query.toString());
	}

	/**
	 * Get the last version of the plan applicable.
	 * 
	 * @param planExtId the id of the plan
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto getMpCurrentPlanApplicable(Long planExtId) throws SystemException {
		StringBuilder query = new StringBuilder();
		query.append(" select mp_maintenance_plan.plan_id,  mp_plan_applicability.plan_config  from mp_maintenance_plan,mp_project_document,mp_plan_applicability ");
		query.append(" WHERE (mp_maintenance_plan.plan_id = ");
		query.append(planExtId);
		query.append(" or mp_maintenance_plan.plan_ext_id = ");
		query.append(planExtId);
		query.append(" ) and MP_PROJECT_ID = PLAN_PROJECT_ID ");
		query.append("and mp_maintenance_plan.PLAN_ID = mp_plan_applicability.PLAN_ID(+) ");
		query.append(" ORDER BY mp_maintenance_plan.plan_id desc");

		return executeQuery1(query.toString());
	}

	/**
	 * Return plan id if applicable to the context.
	 * 
	 * @param planExtId the external id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkLastVersionPlanApplicable(Long planExtId, IceContextDto context, List<Integer> projectList) throws SystemException {
		StringBuilder query = new StringBuilder();
		int index = 0;

		query.append(
				" select mp_maintenance_plan.plan_id, mp_maintenance_plan.plan_project_id, mp_maintenance_project.mp_number, mp_maintenance_project.mp_version, mp_plan_applicability.plan_config, cond_usage_value ");
		query.append(" from mp_maintenance_plan,mp_project_document,mp_plan_applicability, mp_maintenance_project, MP_MAINTENANCE_CONDITION ");
		query.append(" WHERE (mp_maintenance_plan.plan_id = ");
		query.append(planExtId);
		query.append(" or mp_maintenance_plan.plan_ext_id = ");
		query.append(planExtId);
		query.append(" ) and MP_PROJECT_ID = PLAN_PROJECT_ID ");
		query.append(" and mp_maintenance_plan.PLAN_ID = mp_plan_applicability.PLAN_ID(+) ");
		query.append(" and mp_maintenance_plan.plan_project_id = mp_maintenance_project.mp_id ");
		query.append(" and mp_maintenance_plan.plan_id = cond_plan_id ");
		query.append(" and MP_PROJECT_ID in (");
		for (Integer projectId : projectList)
		{
			if (index != 0)
			{
				query.append(" , ");
			}
			query.append(projectId);
			index++;
		}

		query.append(" ) ");
		query.append(filterApplicability(context));
		query.append(" ORDER BY mp_maintenance_plan.plan_id desc");

		return executeQuery1(query.toString());
	}

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkPlanApplicable(Long planId, IceContextDto context, List<Integer> projectList) throws SystemException {
		StringBuilder query = new StringBuilder();
		int index = 0;

		query.append(" select p.plan_id, p.plan_project_id, pr.mp_number, pr.mp_version, mp_plan_applicability.plan_config, cond_usage_value, p.plan_ext_id");
		query.append(" from mp_maintenance_plan p, mp_maintenance_project pr, mp_plan_applicability, MP_MAINTENANCE_CONDITION ");
		query.append(" WHERE pr.mp_id=p.plan_project_id and p.plan_id=mp_plan_applicability.plan_id(+) and p.plan_id= ");
		query.append(planId);
		query.append(" and p.plan_id = cond_plan_id ");
		query.append(" and mp_id in (");
		for (Integer projectId : projectList)
		{
			if (index != 0)
			{
				query.append(" , ");
			}
			query.append(projectId);
			index++;
		}

		query.append(" ) ");
		query.append(filterApplicability(context));
		return executeQuery1(query.toString());
	}

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	private StringBuilder filterApplicability(IceContextDto context) {
		StringBuilder query = new StringBuilder();
		if (context.getModel() != null && context.getModel().getIceCode() != null)
		{
			query.append(" and ( mp_plan_applicability.plan_mod = ");
			query.append(formatString(context.getModel().getIceCode()));
			query.append(" or mp_plan_applicability.plan_mod is null) ");
			if (context.getTechnicalType() != null && context.getTechnicalType().getIceCode() != null)
			{
				query.append(" and (mp_plan_applicability.plan_tt = ");
				query.append(formatString(context.getTechnicalType().getIceCode()));
				query.append(" or mp_plan_applicability.plan_tt is null) ");
			}
		}
		if (context.getMarket() != null && context.getMarket().getMkId() != null)
		{
			query.append(" and (mp_plan_applicability.plan_market = ");
			query.append(context.getMarket().getMkId().intValue());
			query.append(" or mp_plan_applicability.plan_market is null) ");
		}
		return query;
	}

	/**
	 * Get the plan by external plan id.
	 * 
	 * @param planExtId the external plan id
	 * @return the plan
	 * @throws SystemException SystemException
	 */
	public MpPlanDto getPlanByExtId(Long planExtId) throws SystemException {

		/*
		select mp_maintenance_plan.plan_id, plan_name, plan_ext_id, plan_project_id, mp_number, mp_version, plan_perf_type, plan_config  
		from mp_maintenance_plan, mp_maintenance_project, mp_plan_applicability
		where (mp_maintenance_plan.plan_id = 2530 or plan_ext_id = 2530) 
		and plan_project_id = mp_id
		and mp_plan_applicability.PLAN_ID = mp_maintenance_plan.PLAN_ID;
		 */
		StringBuilder query = new StringBuilder();
		query.append(
				" select mp_maintenance_plan.plan_id, plan_name, plan_ext_id, plan_project_id, mp_number, mp_version, plan_perf_type, plan_config from mp_maintenance_plan, mp_maintenance_project, mp_plan_applicability ");
		query.append(" WHERE (mp_maintenance_plan.plan_id = ");
		query.append(planExtId);
		query.append(" or plan_ext_id = ");
		query.append(planExtId);
		query.append(" ) and plan_project_id = mp_id ");
		query.append(" and mp_plan_applicability.PLAN_ID(+) = mp_maintenance_plan.PLAN_ID ");

		return executeQuery1(query.toString());
	}

	/**
	 * Get all the plans for a series.
	 * 
	 * @param brandIcecode
	 * @param typeIcecode
	 * @param productIcecode
	 * @param seriesIcecode
	 * @return
	 * @throws SystemException
	 */
	@Override
	public List<MpPlanDto> getPlanAndApplicabilityBySeries(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException {
		/*
		 
		 SELECT MP_MAINTENANCE_plan.* 
		 FROM MP_MAINTENANCE_plan, MP_PROJECt_applicability 
		 where PLAN_PROJECT_ID = MP_PROJECT_ID
		 and  MP_APP_BRA = 'X'
		 and  MP_APP_TYP = 'Y'
		 and MP_APP_PRO = 'Z'
		 and MP_APP_SER = 'ZZZ'
		 
		 */
		StringBuilder query = new StringBuilder();

		query.append(" select PLAN_ID, PLAN_PROJECT_ID, PLAN_NAME, PLAN_STATUS, PLAN_LAST_MODIFIER, PLAN_DATE_MODIF, PLAN_STANDARD, PLAN_PERF_TYPE, PLAN_EXT_ID, PLAN_OLD_EXT_ID, plan_configs ");
		query.append(" FROM MP_MAINTENANCE_plan, MP_PROJECT_applicability, mp_plan_applicability ");
		query.append(" where PLAN_PROJECT_ID = MP_PROJECT_ID and mp_maintenance_plan.plan_id = mp_plan_applicability.plan_id ");
		query.append(" and MP_APP_BRA = ");
		query.append(formatString(brandIcecode));
		query.append(" and MP_APP_TYP = ");
		query.append(formatString(typeIcecode));
		query.append(" and MP_APP_PRO = ");
		query.append(formatString(productIcecode));
		query.append(" and MP_APP_SER = ");
		query.append(formatString(seriesIcecode));

		return executeQueryN(query.toString());
	}

	@Override
	protected MpPlanDto rs2Dto(ResultSet rs) throws SQLException {
		IObjectConfiguration configuration = ComplexConfigDto.valueOf(getColumnIfExist(MP_PLAN_APPLICABILITY.PLAN_CONFIG));
		MpPlanDto dto = new MpPlanDto(configuration);

		dto.setId(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_ID));
		dto.setName(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_NAME));
		dto.setLastModifier(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_LAST_MODIFIER));
		dto.setModifDate(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_DATE_MODIF));

		dto.setPerformanceId(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_PERF_TYPE));
		dto.setIdProject(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_PROJECT_ID));
		dto.setExtId(getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_EXT_ID));
		dto.setStandard(false);
		if (getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_STANDARD) != null && getColumnIfExist(MP_MAINTENANCE_PLAN.PLAN_STANDARD).equals(new Integer(1)))
		{
			dto.setStandard(true);
		}

		dto.setProjectNumber(getColumnIfExist(MP_MAINTENANCE_PROJECT.MP_NUMBER));
		Long version = getColumnIfExist(MP_MAINTENANCE_PROJECT.MP_VERSION);
		dto.setProjectVersion(version != null ? Integer.valueOf(version.intValue()) : null);
		dto.setModifDate(getColumnIfExist(MP_MAINTENANCE_PROJECT.MP_DATE_MODIF));

		MpConditionDto condDto = new MpConditionDto();
		MpUsageDto usageDto = new MpUsageDto();
		dto.setCondition(condDto);
		dto.getCondition().setUsage(usageDto);
		dto.getCondition().getUsage().setValueId(getColumnIfExist(MP_MAINTENANCE_CONDITION.COND_USAGE_VALUE) != null ? getColumnIfExist(MP_MAINTENANCE_CONDITION.COND_USAGE_VALUE) : 0);

		return dto;
	}
}
