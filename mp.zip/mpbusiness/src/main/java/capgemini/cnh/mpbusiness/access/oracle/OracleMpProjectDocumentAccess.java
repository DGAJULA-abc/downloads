/**
 * 
 */
package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.table.MpMaintenanceProject;
import capgemini.cnh.framework.access.table.statik.DOCLINKS_COUNTRY;
import capgemini.cnh.framework.access.table.statik.MP_MAINTENANCE_PROJECT;
import capgemini.cnh.framework.access.table.statik.MP_PROJECT_DOCUMENT;
import capgemini.cnh.framework.access.table.statik.PUB_LANGUAGE;
import capgemini.cnh.framework.access.table.statik.WEB_DOC_IU;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.access.builder.IuQueryBuilder;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.mpbusiness.access.IMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.dto.MpProjectDocumentDto;

/**
 * @author sdomecq
 *
 */
public class OracleMpProjectDocumentAccess extends OracleAccess<MpProjectDocumentDto> implements IMpProjectDocumentAccess {

	/**
	 * constructor.
	 * 
	 * @throws SystemException Can't get data source.
	 */
	public OracleMpProjectDocumentAccess() throws SystemException {
		super();
	}

	@Override
	protected MpProjectDocumentDto rs2Dto(ResultSet arg0) throws SQLException {
		MpProjectDocumentDto dto = new MpProjectDocumentDto(ComplexConfigDto.valueOf(super.getColumn(WEB_DOC_IU.IU_CONFIG)));

		dto.setMpDocumentId(super.getColumn(MP_PROJECT_DOCUMENT.MP_DOCUMENT_ID));
		dto.setMpProjectId(super.getColumn(MP_MAINTENANCE_PROJECT.MP_ID, "mp_project_id"));
		dto.setMpProjectVersion(super.getColumn(MP_MAINTENANCE_PROJECT.MP_VERSION, "mp_project_version").intValue());
		dto.setMpProjectNumber(super.getColumn(MP_MAINTENANCE_PROJECT.MP_NUMBER));
		dto.setMpIuId(super.getColumn(MP_PROJECT_DOCUMENT.MP_IU_ID));
		dto.setMpIuVersion(super.getColumn(MP_PROJECT_DOCUMENT.MP_IU_VERSION));

		return dto;
	}

	@Override
	public List<MpProjectDocumentDto> getList(IceContextDto context) throws SystemException {
		/*Query example:
		 * select distinct 
		 * mp_project_document.mp_document_id
		 * , mp_maintenance_project.mp_id as mp_project_id
		 * , mp_maintenance_project.mp_version as mp_project_version
		 * , mp_maintenance_project.mp_number
		 * , mp_project_document.mp_iu_id
		 * , mp_project_document.mp_iu_version
		 * , web_doc_iu.iu_config 
		 * 
		 * from 
		 * 
		 * web_doc_iu 
		 * inner join pub_language on web_doc_iu.web_pubnumber = pub_language.pub_number 
		 * inner join mp_project_document on web_doc_iu.iu_masteriuref = mp_project_document.mp_iu_id 
		 * inner join mp_maintenance_project on mp_maintenance_project.mp_id = mp_project_document.mp_project_id 
		 * left join DOCLINKS_COUNTRY on WEB_DOC_IU.WEB_DOCIFSID = DOCLINKS_COUNTRY.DOC_ID and DOCLINKS_COUNTRY.MK_ID = '3' 
		 * 
		 * where 
		 * 
		 * web_doc_iu.iu_market_3 = '1' 
		 * and (doclinks_country.country_name = 'FRANCE' or doclinks_country.country_name is null) 
		 * and web_doc_iu.iu_app_bra = '2' 
		 * and web_doc_iu.iu_app_typ = '1' 
		 * and web_doc_iu.iu_app_pro = '40' 
		 * and web_doc_iu.iu_app_ser = '186' 
		 * and (web_doc_iu.iu_app_mod = '001' or web_doc_iu.iu_app_mod is null) 
		 * and (web_doc_iu.iu_app_tt = '001' or web_doc_iu.iu_app_tt is null) 
		 * and pub_language.pub_language = 'IT';
		 */

		MpMaintenanceProject p1 = new MpMaintenanceProject("p1");

		IuQueryBuilder builder = IuQueryBuilder.getNewInstance(context.getLanguage());
		builder.selectDistinct()
				.select(MP_PROJECT_DOCUMENT.MP_DOCUMENT_ID)
				.selectAs(p1.MP_ID, "mp_project_id")
				.selectAs(p1.MP_VERSION, "mp_project_version")
				.select(p1.MP_NUMBER)
				.select(MP_PROJECT_DOCUMENT.MP_IU_ID)
				.select(MP_PROJECT_DOCUMENT.MP_IU_VERSION)
				.select(WEB_DOC_IU.IU_CONFIG)

				.from(WEB_DOC_IU.table())
				.innerJoinColumn(WEB_DOC_IU.WEB_PUBNUMBER, PUB_LANGUAGE.PUB_NUMBER) // -- Filter on the language
				.innerJoinColumn(WEB_DOC_IU.IU_MASTERIUREF, MP_PROJECT_DOCUMENT.MP_IU_ID)
				.innerJoinColumn(MP_PROJECT_DOCUMENT.MP_PROJECT_ID, p1.MP_ID)
				.append(" and p1.mp_version in (select max(p2.mp_version) from mp_maintenance_project p2 where p1.mp_number = p2.mp_number) ");
		if (context.getMarketId() != null)
		{
			builder.leftJoin(WEB_DOC_IU.WEB_DOCIFSID, DOCLINKS_COUNTRY.DOC_ID).joinValue(DOCLINKS_COUNTRY.MK_ID, context.getMarketId());
		}

		builder.where();

		builder.getFilterIuMarket(context)
				.getFilterIuProduct(context)
				.getFilterPublishedDocNoFilterLang(context)
				.getFilterSubscribedCategories(context.getIwdSubscription().getIwdSubscribedCategories(context.getLanguage()));

		List<MpProjectDocumentDto> result = executeQueryN(builder);
		return result;
	}

}
