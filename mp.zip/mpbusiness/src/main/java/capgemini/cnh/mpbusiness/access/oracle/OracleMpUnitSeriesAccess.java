package capgemini.cnh.mpbusiness.access.oracle;

import java.sql.ResultSet;
import java.sql.SQLException;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.access.builder.QueryBuilder;
import capgemini.cnh.framework.access.table.statik.MP_UNIT_SERIES;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;

/**
 * 
 * @author jdespeau
 *
 */
public class OracleMpUnitSeriesAccess extends OracleAccess<MpUnitSeriesDto> implements IMpUnitSeriesAccess {

	/**
	 * Default constructor.
	 * 
	 * @throws SystemException cannot get data source
	 */
	public OracleMpUnitSeriesAccess() throws SystemException {
		super();
	}

	@Override
	protected MpUnitSeriesDto rs2Dto(ResultSet rs) throws SQLException {

		MpUnitSeriesDto dto = new MpUnitSeriesDto();

		dto.setAppBra(getColumnIfExist(MP_UNIT_SERIES.UNITSER_APP_BRA));
		dto.setAppTyp(getColumnIfExist(MP_UNIT_SERIES.UNITSER_APP_TYP));
		dto.setAppPro(getColumnIfExist(MP_UNIT_SERIES.UNITSER_APP_PRO));
		dto.setAppSer(getColumnIfExist(MP_UNIT_SERIES.UNITSER_APP_SER));
		dto.setUnitKey(getColumnIfExist(MP_UNIT_SERIES.UNITSER_UNIT_KEY));
		dto.setUnit(getColumnIfExist(MP_UNIT_SERIES.UNITSER_UNIT));
		dto.setToleranceDelta(getColumnIfExist(MP_UNIT_SERIES.UNITSER_TOLERANCE_DELTA));
		dto.setToleranceFar(getColumnIfExist(MP_UNIT_SERIES.UNITSER_TOLERANCE_FAR));

		return dto;
	}

	@Override
	public MpUnitSeriesDto getUnitBySerie(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException {

		QueryBuilder builder = QueryBuilder.createQueryBuilder(true)
				.selectDistinct()
				.select(MP_UNIT_SERIES.UNITSER_APP_BRA)
				.select(MP_UNIT_SERIES.UNITSER_APP_TYP)
				.select(MP_UNIT_SERIES.UNITSER_APP_PRO)
				.select(MP_UNIT_SERIES.UNITSER_APP_SER)
				.select(MP_UNIT_SERIES.UNITSER_UNIT_KEY)
				.select(MP_UNIT_SERIES.UNITSER_UNIT)
				.select(MP_UNIT_SERIES.UNITSER_TOLERANCE_DELTA)
				.select(MP_UNIT_SERIES.UNITSER_TOLERANCE_FAR)
				.from(MP_UNIT_SERIES.table())
				.where()
				.whereEqualValue(MP_UNIT_SERIES.UNITSER_APP_BRA, brandIcecode)
				.whereEqualValue(MP_UNIT_SERIES.UNITSER_APP_TYP, typeIcecode)
				.whereEqualValue(MP_UNIT_SERIES.UNITSER_APP_PRO, productIcecode)
				.whereEqualValue(MP_UNIT_SERIES.UNITSER_APP_SER, seriesIcecode);

		MpUnitSeriesDto mpUnitSeriesDto = executeQuery1(builder);

		if (mpUnitSeriesDto != null)
		{
			return mpUnitSeriesDto;
		}
		else
		{
			return new MpUnitSeriesDto();
		}

	}

}
