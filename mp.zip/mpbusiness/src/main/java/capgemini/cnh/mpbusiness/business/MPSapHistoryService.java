/**
 *
 */
package capgemini.cnh.mpbusiness.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import capgemini.cnh.externals.sap.business.MpClaimStatusBusiness;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.RepairHistoryDto;
import capgemini.cnh.externals.sap.model.ResponseData.VehicleDataDto;
import capgemini.cnh.externals.util.RepairHistoryComparator;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.ConnectedTypeEnum;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.MpIntervalByCodeComparator;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * ApplicableIUService class, Runnable called by ExecutorService.
 */
public class MPSapHistoryService extends Business implements Runnable {

	/** Logging element. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MPSapHistoryService.class);

	/** default Language : EN. */
	private String defaultLanguage;

	/** warranty start date. */
	private long warrantyDate;

	/** map between a coupon and the last calculated LHCV / initialized with last SAP history. */
	private Map<String, MpHistoryIntervalDto> mapCouponLHCV;
	private List<MpHistoryIntervalDto> listLHCV;

	/** list of history for each coupon for all the managed contract get from SAP broker. */
	private SortedMap<MpContractVehicleDto, Map<String, List<RepairHistoryDto>>> mapContract;

	/** map of all new coupon from SAP broker to manage. */
	private Map<String, String> newSapCoupon;

	/** list of all coupon managed (in sap history in cache or in sap etim history). */
	private List<String> potentialMultipleCoupon;

	/** list of history for each coupon for all the contiguous contract. */
	private Map<String, MpHistoryIntervalDto> mapLastEtimDBRepairsForSap;

	/** list intervals for an internal plan id. */
	private Map<Long, List<MpIntervalDto>> mapPlanIntervals;

	/** Mp Family Code. */
	private String mpFamilyCode = Context.getStringProperty("mp.family.code");

	/** To be filled at the beginning: vin, defaultLanguage */
	/** VIN number set by the dealer. */
	private String vin;
	/** VIN mapping 9/17 for AG. */
	private List<String> vinList;
	/** Sap vehicle info. */
	private ResponseData sapVehicleInfo;
	/** Contracts. **/
	private MpContractDto mpContract;
	/** tolerance to associate a coupon eTIM with a coupon SAP. **/
	private int toleranceToMatch;
	/** tolerance to wait SAP claim. **/
	private int toleranceToWait;
	/** Mp coupon flexible. **/
	private Map<String, MpFlexCouponDto> couponFlexibles;

	/**
	 * Customer CNH/IVECO.
	 * 
	 * @see {@link Constants#CUSTOMER_CNH}
	 * @see {@link Constants#CUSTOMER_IVECO}
	 */
	private String customer = "";

	//	/**
	//	 * Intervals to use for AG&CE.
	//	 */
	//	private List<MpIntervalDto> useIntervals;

	private IceContextDto context;

	/**
	 * Default constructor.
	 * 
	 * @param vin the vehicle number.
	 * @param defaultLanguage the default language.
	 * @param sapVehicleInfo :repair history and vehicle general info(for warranty).
	 * @param mpContract : contracts linked to the VIN.
	 * @param toleranceToMatch : tolerance to associate a coupon eTIM with a coupon SAP
	 * @param toleranceToWait : tolerance to wait SAP claim
	 */
	public MPSapHistoryService(String vin, List<String> vinList, String defaultLanguage, ResponseData sapVehicleInfo, MpContractDto mpContract, int toleranceToMatch, int toleranceToWait,
			IceContextDto context) {
		super();
		logger.debug("MPSapHistoryService.Constructor");
		this.vin = vin;
		this.vinList = vinList;
		this.mpContract = mpContract;
		this.sapVehicleInfo = sapVehicleInfo;
		this.defaultLanguage = defaultLanguage;
		this.toleranceToMatch = toleranceToMatch;
		this.toleranceToWait = toleranceToWait;
		this.context = context;

	}

	/**
	 * (non-Javadoc).
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		logger.warn(String.format("Start MPSapHistoryService"));
		long begin = System.currentTimeMillis();

		updateMpHistoryWithSapData();

		long end = System.currentTimeMillis();
		long delta = end - begin;
		logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY: %d ", delta));
	}

	/**
	 * (non-Javadoc).
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void runWithoutThread() {
		logger.warn(String.format("Start MPSapHistoryService"));
		long begin = System.currentTimeMillis();

		updateMpHistoryWithSapData();

		long end = System.currentTimeMillis();
		long delta = end - begin;
		logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY: %d ", delta));
	}

	/**
	 * Update the sap history stored in eTIM from the SAP Broker.
	 * 
	 * @return true if the history has been updated with sap claim (update/add or delete of eTIM history)
	 * @throws SystemException System Exception
	 */
	public boolean updateMpHistoryWithSapData() {

		boolean result = false;
		if (vin != null && vinList != null && !vinList.isEmpty())
		{
			try
			{
				logger.warn("MPSapHistoryService.run");
				warrantyDate = 0;
				List<RepairHistoryDto> listSapHisto = new ArrayList<RepairHistoryDto>();
				long begin = System.currentTimeMillis();
				//Initialization warranty start date
				if (mpContract != null)
				{
					boolean isFlexHeavy = ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(mpContract.getActiveMpContract().getTypeContract());

					List<MpContractVehicleDto> listContracts = mpContract.getContracts();
					long fistContractTime = listContracts.get(listContracts.size() - 1).getContractStartDate().getTime();

					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					if (sapVehicleInfo != null)
					{
						//  IAZ Keep only the status flagged "for maintenance" in listSapHisto
						listSapHisto = removeNonMaintenanceClaims(sapVehicleInfo.getRepairHistory());

						List<VehicleDataDto> listVehicle = sapVehicleInfo.getVehicleData();
						if (listVehicle.size() > 0)
						{
							if (listVehicle.get(0).getWtyStart() != null)
							{
								warrantyDate = formatter.parse(listVehicle.get(0).getWtyStart()).getTime();
							}
						}
					}
					if (mpContract.getWarrantyStartDate() != null)
					{
						warrantyDate = formatter.parse(mpContract.getWarrantyStartDate()).getTime();
					}

					if (listSapHisto != null && !listSapHisto.isEmpty() && warrantyDate != 0)
					{
						// LANGUANGE='EN' to get the coupon name
						if (defaultLanguage == null)
						{
							defaultLanguage = Constants.ENGLISH;
						}

						//Get List of interval for the plan under contract
						//Get the history in SAP broker not yet managed group by contract and then by coupon in a map (not in the ETIM history table)
						//For each contract
						//     For each interval
						//     Get List of history for the interval  in the map
						//        call calculate LHCV from the last SAP history stored in eTIM => LHCV
						//If LHCV != null
						//Insert the SAP history in eTIM History

						//Get list of interval managed for the active plan
						MpIntervalBusiness intervalBusiness = new MpIntervalBusiness();
						List<MpIntervalDto> intervals = new ArrayList<MpIntervalDto>();
						Long planId = mpContract.getActiveMpContract().getPlanId();
						intervals = intervalBusiness.getMaintenanceIntervalsWithoutOperation(planId, defaultLanguage, mpFamilyCode);
						if (customer.equals(Constants.CUSTOMER_CNH) && intervals != null)
						{
							intervals.removeIf(x -> x.isCustomer() != null && x.isCustomer());
						}
						//						}
						Collections.sort(intervals, new MpIntervalByCodeComparator(couponFlexibles)); //needed in order to calculate the LHCV in order for multiple

						//create mapping coupon
						// do not take call mappingDefectCoupon for AG&CE
						Map<String, String> mappingDefectCoupon = customer.equals(Constants.CUSTOMER_CNH) ? new HashMap<String, String>() : mappingDefectCoupon();
						for (MpIntervalDto interval : intervals)
						{
							mappingDefectCoupon.put(interval.getCoupon(), interval.getCoupon());
						}

						//Get all the last sap history from eTIM DB
						//and with date >= date of the first contract start
						// TODO IAZ GETTER = vin list
						List<MpHistoryIntervalDto> lastEtimDBRepairsForSap = intervalBusiness.readListFromDateByOrigin(vinList, new Integer(1), fistContractTime);

						//  IAZ Loop over lastEtimDBRepairsForSap & listSapHisto:
						// If Coupon code eTIM = coupon code sap && failure date etim (from CR 39) = failure date SAP
						//  => Set status to deleted in DB and delete from lastEtimDBRepairsForSap
						Iterator<MpHistoryIntervalDto> iterEtimList = lastEtimDBRepairsForSap.iterator();

						while (iterEtimList.hasNext())
						{
							boolean remove = false;
							MpHistoryIntervalDto etimHistory = iterEtimList.next();

							for (RepairHistoryDto sapHistory : listSapHisto)
							{
								// Get the failure date as long
								Calendar timeFailure = Calendar.getInstance();
								timeFailure.setTime(sapHistory.getDateFailDate());
								long timestampFailure = sapHistory.getDateFailDate().getTime() + timeFailure.getTimeZone().getOffset(timeFailure.getTime().getTime());

								// Get the repair date as long
								Calendar timeRepair = Calendar.getInstance();
								timeRepair.setTime(sapHistory.getDateRepairDate());
								long timestampRepair = sapHistory.getDateRepairDate().getTime() + timeRepair.getTimeZone().getOffset(timeRepair.getTime().getTime());

								String defect = getDefectFromIntervalCode(etimHistory.getIntervalCode(), mappingDefectCoupon, intervals);

								int endIndex = customer.equals(Constants.CUSTOMER_CNH) ? 10 : 9; // 7 digit pour CNH / 6 digit pour IVECO
								MpType mpType = customer.equals(Constants.CUSTOMER_CNH) ? MpType.MP_HOUR : MpType.MP_KM;
								if (defect.equals(sapHistory.getDefect().substring(3, endIndex)) && Long.valueOf(timestampFailure).equals(etimHistory.getFailureDate())
										&& ((etimHistory.retreiveFromExactValueByMpType(mpType) != 0
												&& Long.valueOf(sapHistory.getHoursKm()).compareTo(etimHistory.retreiveFromExactValueByMpType(mpType)) != 0)
												|| Long.valueOf(timestampRepair).compareTo(etimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH)) != 0))
								{
									new MpIntervalBusiness().updateDeleted(etimHistory.getId());
									remove = true;
								}
							}

							if (remove)
							{
								iterEtimList.remove();
							}
						}

						potentialMultipleCoupon = new ArrayList<String>();
						mapLastEtimDBRepairsForSap = new HashMap<String, MpHistoryIntervalDto>();
						String coupon = "";
						boolean intervalFound = false;
						String currentCode = "";
						MpIntervalDto tmpInt = null;
						mapCouponLHCV = new HashMap<String, MpHistoryIntervalDto>();
						listLHCV = new ArrayList<MpHistoryIntervalDto>();

						// Ajout de coupons venu de SAP, n'existant pas/plus chez nous
						for (MpHistoryIntervalDto dto : lastEtimDBRepairsForSap)
						{
							coupon = "";
							if (dto.getIntervalCode().equals(currentCode))
							{
								continue;
							}
							intervalFound = false;
							currentCode = dto.getIntervalCode();
							for (MpIntervalDto interval : intervals)
							{
								if (interval.getCode().equals(dto.getIntervalCode()))
								{
									coupon = interval.getCoupon();
									intervalFound = true;
									break;
								}
							}
							if (intervalFound)
							{
								mapLastEtimDBRepairsForSap.put(coupon, dto);
								mapCouponLHCV.put(coupon, dto);
								listLHCV.add(dto);
								potentialMultipleCoupon.add(coupon);
							}
							else
							{
								//case of coupon doesn't exist anymore in the current contract plan
								tmpInt = intervalBusiness.getCouponName(dto.getIntervalCode(), defaultLanguage, mpFamilyCode);
								if (tmpInt != null)
								{
									mapLastEtimDBRepairsForSap.put(tmpInt.getCoupon(), dto);
									mapCouponLHCV.put(tmpInt.getCoupon(), dto);
									listLHCV.add(dto);
									potentialMultipleCoupon.add(tmpInt.getCoupon());
								}
							}

						}

						long end = System.currentTimeMillis();
						long delta = end - begin;
						logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY phase 1-request current int + history: %d ", delta));

						//Create hash map of contract with the different coupon to manage and the list of sap broker history : c1-M1-h1/h2 c1-M2-h11/h21 c2-M1/h3/h4,...
						long begin1 = System.currentTimeMillis();

						newSapCoupon = new HashMap<String, String>();
						long end1 = 0;
						long delta1 = 0;
						if (!isFlexHeavy)
						{
							mapContract = getMaintenanceSapRepairHistoryForAllContract(listSapHisto, mappingDefectCoupon);

							for (String key : newSapCoupon.keySet())
							{
								if (!potentialMultipleCoupon.contains(key))
								{
									potentialMultipleCoupon.add(key);
								}
							}

							end1 = System.currentTimeMillis();
							delta1 = end1 - begin1;
							logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY phase 2-buildmap: %d ", delta1));

							begin1 = System.currentTimeMillis();

							mapPlanIntervals = new HashMap<Long, List<MpIntervalDto>>();

							Iterator<MpContractVehicleDto> iter = mapContract.keySet().iterator();
							MpContractVehicleDto contract;

							while (iter.hasNext())
							{
								contract = iter.next();
								Map<String, List<RepairHistoryDto>> mapSapRepairHistory = mapContract.get(contract);

								//  IAZ - Boite magique qui me calule les next stop si je passe bein les données
								createSapHistoryInEtim(contract, mapSapRepairHistory, intervals, context);
							}

							end1 = System.currentTimeMillis();
							delta1 = end1 - begin1;
							logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY phase 3-buildLCHV: %d ", delta1));
							begin1 = System.currentTimeMillis();

							MpHistoryIntervalDto historyToSave = null;
							Iterator<String> iterCoupon = mapCouponLHCV.keySet().iterator();
							long millisecondToMatch = toleranceToMatch * 24 * 3600 * 1000;
							while (iterCoupon.hasNext())
							{
								coupon = iterCoupon.next();
								historyToSave = mapCouponLHCV.get(coupon);
								if (historyToSave != null && !historyToSave.equals(mapLastEtimDBRepairsForSap.get(coupon)))
								{
									intervalBusiness.createHistoryInterval(historyToSave);

									if (customer.equals(Constants.CUSTOMER_CNH))
									{
										intervalBusiness.updateKmHistoryInterval(historyToSave, millisecondToMatch);
									}
									else
									{
										intervalBusiness.updateHourHistoryInterval(historyToSave, millisecondToMatch);
									}
									result = true;
								}
							}
						}
						else
						{
							//for flexible, the LHCV= exact value : no realignement of coupon
							//only the last claim is used for each coupon
							getMaintenanceSapRepairHistoryForFlexibleContract(listSapHisto, mappingDefectCoupon, intervals, mpContract.getActiveMpContract().getPlanExtId(), warrantyDate);

							begin1 = System.currentTimeMillis();
							long millisecondToMatch = toleranceToMatch * 24 * 3600 * 1000;
							
							listLHCV.sort((o1, o2) -> Long.compare(o1.retreiveFromExactValueByMpType(MpType.MP_MONTH), o2.retreiveFromExactValueByMpType(MpType.MP_MONTH)));

							for (MpHistoryIntervalDto historyToSave : listLHCV)
							{
								// Check if the historyInterval already exist in the list 
								Boolean intervalExist = false;
								Iterator<Entry<String, MpHistoryIntervalDto>> historyIterator = mapLastEtimDBRepairsForSap.entrySet().iterator();
								while (historyIterator.hasNext())
								{
									Entry<String, MpHistoryIntervalDto> interval = historyIterator.next();
									if (historyToSave != null && historyToSave.getId() != null && interval.getValue().getId().equals(historyToSave.getId()))
									{
										intervalExist = true;
										break;
									}
								}

								// Add the interval in the history db
								if (!intervalExist)
								{
									intervalBusiness.createHistoryInterval(historyToSave);

									if (customer.equals(Constants.CUSTOMER_CNH))
									{
										intervalBusiness.updateKmHistoryInterval(historyToSave, millisecondToMatch);
									}
									else
									{
										boolean success = intervalBusiness.updateHourHistoryInterval(historyToSave, millisecondToMatch);
										// RC1
										if (success) {
											intervalBusiness.postCheckAndUpdateIfNecessary(historyToSave, millisecondToMatch);
										}
									}
									result = true;
								}
							}
						}

						end1 = System.currentTimeMillis();
						delta1 = end1 - begin1;
						logger.warn(String.format("TIME EXECUTION MP SAP BROKER HISTORY phase 4- insert: %d ", delta1));

						//update the coupon history and delete the coupon eTIM not having claim since 60 days.

					}
					//it means that the sap broker gave an answer
					//if (sapVehicleInfo != null && sapVehicleInfo.getGeneral() != null && !sapVehicleInfo.getGeneral().isEmpty())
					if (sapVehicleInfo != null && sapVehicleInfo.isMpRepairHistoFromSapOk())
					{
						result = MpIntervalBusiness.removeCouponsWithoutClaim(vinList, toleranceToMatch, toleranceToWait, fistContractTime, couponFlexibles, isFlexHeavy) || result;
					}
					else
					{
						logger.info(String.format(" updateMpHistoryWithSapData - SAP Broker called failed for the VIN %s", vinList));
					}

					mpContract.setHistoryModified(result);
				}
			}
			catch (ParseException p)
			{
				logger.error("Cannot create SAP history.", p);
			}
			catch (SystemException e)
			{
				logger.error("Cannot create SAP history.", e);
			}
			catch (ApplicativeException e)
			{
				logger.error("Cannot create SAP history.", e);
			}
		}
		logger.warn(String.format("flag end history set"));

		return result;
	}

	/**
	 * Get the defect from an interval code.
	 * 
	 * @param intervalCode the interval code
	 * @param mappingDefectCoupon the defect mapping from eTIM/SAP
	 * @param intervals the intervals with the defect information
	 * @return the defect information
	 */
	private static String getDefectFromIntervalCode(String intervalCode, Map<String, String> mappingDefectCoupon, List<MpIntervalDto> intervals) {

		String result = intervalCode;
		for (MpIntervalDto interval : intervals)
		{
			if (interval.getCode().equals(intervalCode))
			{
				result = mappingDefectCoupon.get(interval.getCoupon());
			}
		}

		return result;
	}

	/**
	 * Remove the claims that are not flagged for maintenance.
	 * 
	 * @param listSapHisto the list of all the claims.
	 * @return the list of the MP claims.
	 * @throws SystemException SystemException
	 */
	private List<RepairHistoryDto> removeNonMaintenanceClaims(List<RepairHistoryDto> listSapHisto) throws SystemException {

		List<RepairHistoryDto> result = new ArrayList<>();
		List<String> mpClaimStatusList = new MpClaimStatusBusiness().getClaimStatusStringForMp();

		for (RepairHistoryDto sapHisto : listSapHisto)
		{
			if (mpClaimStatusList.contains(sapHisto.getSapStatus()))
			{
				result.add(sapHisto);
			}
		}

		return result;
	}

	/**
	 * Get the sap history from the SAP cache.
	 * 
	 * @param contract : current contract
	 * @param mapSapRepairHistory : list of SAP repair for a contract
	 * @param intervals : intervals for the active contract
	 * 
	 * @throws SystemException System Exception
	 * @throws ApplicativeException Applicative Exception
	 */
	public void createSapHistoryInEtim(MpContractVehicleDto contract, Map<String, List<RepairHistoryDto>> mapSapRepairHistory, List<MpIntervalDto> intervals, IceContextDto context)
			throws SystemException, ApplicativeException {
		//		String vin = userSession.getSessionVin();

		// do not take planId and planExtId from contract for AG&CE
		Long planId = customer.equals(Constants.CUSTOMER_CNH) ? intervals.get(0).getIdPlan() : contract.getPlanId();
		Long planExtId = customer.equals(Constants.CUSTOMER_CNH) ? new MpPlanBusiness().getExternalPlanId(planId).getExtId() : contract.getPlanExtId();

		MpIntervalBusiness intervalBusiness = new MpIntervalBusiness();
		MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(warrantyDate, customer, context);

		//		List<MpHistoryIntervalDto> sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
		//		MpHistoryIntervalDto historyToSave = null;

		Map<String, List<String>> mapMultiple = new HashMap<String, List<String>>();

		Map<String, RepairHistoryDto> mapCouponLHVCToGet = new HashMap<String, RepairHistoryDto>();
		Map<String, MpHistoryIntervalDto> mapCouponAction = new HashMap<String, MpHistoryIntervalDto>();

		//map to save the  LHCV (for non multiple coupon
		// use to store the previous LHCV for multiple coupon
		Map<String, List<MpHistoryIntervalDto>> mapCouponLHCVFound = new HashMap<String, List<MpHistoryIntervalDto>>();

		if (!planId.equals(intervals.get(0).getIdPlan()))
		{
			intervals = intervalBusiness.getMaintenanceIntervalsWithoutOperation(planId, defaultLanguage, mpFamilyCode);
			if (customer.equals(Constants.CUSTOMER_CNH) && intervals != null)
			{
				intervals.removeIf(x -> x.isCustomer() != null && x.isCustomer());
			}
			Collections.sort(intervals, new MpIntervalByCodeComparator(couponFlexibles));

		}

		mapPlanIntervals.put(contract.getPlanId(), intervals);

		MpHistoryIntervalDto lastSapEtimHistory;

		for (MpIntervalDto interval : intervals)
		{
			if (newSapCoupon.get(interval.getCoupon()) != null)
			{
				lastSapEtimHistory = mapLastEtimDBRepairsForSap.get(interval.getCoupon());
				mapMultiple = mpBusiness.getMultiInterval(intervals);
				//get Mulitple interval, if exists copy all the history if it greater
				List<String> listIntervalMulti = mapMultiple.get(interval.getCoupon());

				List<RepairHistoryDto> cacheSapRepairHistory = mapSapRepairHistory.get(interval.getCoupon());
				//				if (listIntervalMulti == null)
				//				{
				//					if (cacheSapRepairHistory != null && cacheSapRepairHistory.size() > 0)
				//					{
				//						Collections.sort(cacheSapRepairHistory, new RepairHistoryComparator());
				//
				//						sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
				//						for (RepairHistoryDto dto : cacheSapRepairHistory)
				//						{
				//							MpHistoryIntervalDto sapHistoryDto = new MpHistoryIntervalDto(null, interval.getId(), vin, interval.getCode(), planExtId, new Integer(1));
				//							setHistoryValue(interval, sapHistoryDto, dto);
				//							sapHistoryList.add(sapHistoryDto);
				//						}
				//
				//						mpBusiness.calculateLHCVFromPartHistory(sapHistoryList, mapCouponLHCV.get(interval.getCoupon()), intervals);
				//
				//						historyToSave = sapHistoryList.get(sapHistoryList.size() - 1);
				//						mapCouponLHCV.put(interval.getCoupon(), historyToSave);
				//						mapCouponLHCVFound.put(interval.getCoupon(), sapHistoryList);
				//					}
				//				}
				//				else
				//				{
				couponManagement(contract, cacheSapRepairHistory, listIntervalMulti, mapCouponLHCVFound, mapCouponLHVCToGet, mapSapRepairHistory,
						interval, mpBusiness, mapCouponAction, planExtId, intervals, lastSapEtimHistory, context);
				//	}
			}
		}

		Iterator<String> iter1 = mapCouponLHVCToGet.keySet().iterator();
		String coupon1;
		while (iter1.hasNext())
		{
			//coupon1 format : coupon - multiple coupon - after/before
			coupon1 = iter1.next();
			String[] tmp = coupon1.split("-");
			if (mapCouponLHCVFound.get(tmp[0]) == null)
			{
				getLHCVFromMulitple(coupon1, mapCouponLHVCToGet.get(coupon1), mapCouponLHCVFound, mapCouponLHVCToGet, mapSapRepairHistory, mapCouponAction, mpBusiness, intervals);
			}
		}
	}

	/**
	 * Manage coupon that have multiple and not (manage all).
	 * 
	 * @param contract : current contract
	 * @param cacheSapRepairHistory : repair history of the coupon
	 * @param listIntervalMulti : list of multiple for the coupon
	 * @param mapCouponLHCVFound : l LHCV already calculated for each coupon
	 * @param mapCouponLHVCToGet : coupon of the LHCV to retreive by coupon
	 * @param mapSapRepairHistory : list of SAP repair for a contract
	 * @param interval : current interval
	 * @param mpBusiness : mp Business
	 * @param mapCouponAction : action to perform to get the LHCV for each coupon
	 * @param planExtId : plan Ext Id
	 * @param intervals : list of intervals for the current contract
	 * @param lastSapEtimHistory : last history SAP saved in eTIM database
	 * 
	 * @throws SystemException System Exception
	 */
	public void couponManagement(MpContractVehicleDto contract,
			List<RepairHistoryDto> cacheSapRepairHistory, List<String> listIntervalMulti, Map<String, List<MpHistoryIntervalDto>> mapCouponLHCVFound,
			Map<String, RepairHistoryDto> mapCouponLHVCToGet, Map<String, List<RepairHistoryDto>> mapSapRepairHistory, MpIntervalDto interval, MaintenancePlanBusiness mpBusiness,
			Map<String, MpHistoryIntervalDto> mapCouponAction, Long planExtId, List<MpIntervalDto> intervals, MpHistoryIntervalDto lastSapEtimHistory, IceContextDto context) throws SystemException {

		List<RepairHistoryDto> cacheMultiSapRepairHistory = null;
		String vin = this.vin;

		//find element after
		RepairHistoryDto maxMultiAfter = null;
		RepairHistoryDto maxMultiBefore = null;
		String maxMultiAfterCoupon = null;
		String maxMultiBeforeCoupon = null;

		if (cacheSapRepairHistory != null && cacheSapRepairHistory.size() > 0)
		{
			Collections.sort(cacheSapRepairHistory, new RepairHistoryComparator());
		}
		if (listIntervalMulti != null)
		{
			for (String mutiInterval : listIntervalMulti)
			{
				cacheMultiSapRepairHistory = mapSapRepairHistory.get(mutiInterval);
				if (cacheMultiSapRepairHistory != null)
				{
					Collections.sort(cacheMultiSapRepairHistory, new RepairHistoryComparator());
					for (RepairHistoryDto multiHistory : cacheMultiSapRepairHistory)
					{
						if (cacheSapRepairHistory == null || multiHistory.getDateFailDate().after(cacheSapRepairHistory.get(cacheSapRepairHistory.size() - 1).getDateFailDate()))
						{
							if (maxMultiAfter == null || multiHistory.getDateFailDate().after(maxMultiAfter.getDateFailDate()))
							{
								maxMultiAfter = multiHistory;
								maxMultiAfterCoupon = mutiInterval;
							}
						}
						else if (maxMultiBefore == null || multiHistory.getDateFailDate().after(maxMultiBefore.getDateFailDate()))
						{
							maxMultiBefore = multiHistory;
							maxMultiBeforeCoupon = mutiInterval;
						}
					}
				}
			}
		}
		//element is in the current contract
		if (cacheSapRepairHistory != null && cacheSapRepairHistory.size() > 0)
		{
			//element in the last contract
			if (!findCouponInNextContract(mapContract, contract, interval.getCoupon()))
			{
				//element has no multiple is in the current contract
				if (maxMultiBefore == null)
				{
					calculateLHVCWhenNoMultipleInTheContract(contract, cacheSapRepairHistory, listIntervalMulti, mapCouponLHCVFound,
							mapSapRepairHistory, interval, mpBusiness,
							planExtId, intervals, lastSapEtimHistory, context);
				}
				//element a multiple is in the current contract
				else
				{
					// Keep VIN and not ListVIN as used as setter in the DB
					//calculate LHCV with the previous
					MpHistoryIntervalDto sapHistoryDto = new MpHistoryIntervalDto(null, interval.getId(), vin, interval.getCode(), planExtId, interval.getIdPlan(), new Integer(1));
					setHistoryValue(interval, sapHistoryDto, cacheSapRepairHistory.get(cacheSapRepairHistory.size() - 1));

					mapCouponLHVCToGet.put(interval.getCoupon() + "-" + maxMultiBeforeCoupon + "-before", maxMultiBefore);
					mapCouponAction.put(interval.getCoupon() + "-CalculateLHVC", sapHistoryDto);
				}
			}
			//element existing  in the following contracts
			else
			{
				//element has no mulitple is in the current contract
				if (maxMultiAfter == null && maxMultiBefore == null)
				{
					calculateLHVCWhenNoMultipleInTheContract(contract, cacheSapRepairHistory, listIntervalMulti, mapCouponLHCVFound,
							mapSapRepairHistory, interval, mpBusiness,
							planExtId, intervals, lastSapEtimHistory, context);
				}

				else if (maxMultiAfter != null)
				{
					//get LHCV of the maxMultiAfter
					mapCouponLHVCToGet.put(interval.getCoupon() + "-" + maxMultiAfterCoupon + "-after", maxMultiAfter);
					mapCouponAction.put(interval.getCoupon() + "-UpdateLHCV", null);
				}
				else if (maxMultiBefore != null)
				{
					// Keep VIN and not ListVIN as used as setter in the DB
					//calculate LHCV with the previous
					MpHistoryIntervalDto sapHistoryDto = new MpHistoryIntervalDto(null, interval.getId(), vin, interval.getCode(), planExtId, interval.getIdPlan(), new Integer(1));
					setHistoryValue(interval, sapHistoryDto, cacheSapRepairHistory.get(cacheSapRepairHistory.size() - 1));

					mapCouponLHVCToGet.put(interval.getCoupon() + "-" + maxMultiBeforeCoupon + "-before", maxMultiBefore);
					mapCouponAction.put(interval.getCoupon() + "-CalculateLHVC", sapHistoryDto);
				}
			}
		}
		//element is not in the current contract
		else
		{
			if (maxMultiAfter != null && findCouponInNextContract(mapContract, contract, interval.getCoupon()))
			{
				//element existing  in the next contract
				if (mapCouponLHCV.get(interval.getCoupon()) == null
						|| contract.getContractStartDate().after(UtilDate.getDateDDMMYYYYFromTime(mapCouponLHCV.get(interval.getCoupon()).retreiveFromExactValueByMpType(MpType.MP_MONTH))))
				{
					//get LHCV of the maxMultiAfter  of the current contract
					mapCouponLHVCToGet.put(interval.getCoupon() + "-" + maxMultiAfterCoupon + "-after", maxMultiAfter);
					mapCouponAction.put(interval.getCoupon() + "-UpdateLHCV", null);
				}
			}
		}

	}

	/**
	 * Manage coupon that have multiple.
	 * 
	 * @param contract : current contract
	 * @param cacheSapRepairHistory : repair history of the coupon
	 * @param listIntervalMulti : list of multiple for the coupon
	 * @param mapCouponLHCVFound : l LHCV already calculated for each coupon
	 * @param mapSapRepairHistory : list of SAP repair for a contract
	 * @param interval : current interval
	 * @param mpBusiness : mp Business
	 * @param planExtId : plan Ext Id
	 * @param intervals : list of intervals for the current contract
	 * @param lastSapEtimHistory : last history SAP saved in eTIM database
	 * 
	 * @throws SystemException System Exception
	 */
	public void calculateLHVCWhenNoMultipleInTheContract(MpContractVehicleDto contract,
			List<RepairHistoryDto> cacheSapRepairHistory, List<String> listIntervalMulti, Map<String, List<MpHistoryIntervalDto>> mapCouponLHCVFound,
			Map<String, List<RepairHistoryDto>> mapSapRepairHistory, MpIntervalDto interval, MaintenancePlanBusiness mpBusiness,
			Long planExtId, List<MpIntervalDto> intervals, MpHistoryIntervalDto lastSapEtimHistory, IceContextDto context) throws SystemException {

		List<MpHistoryIntervalDto> sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
		MpHistoryIntervalDto historyToSave;
		String vin = this.vin;
		MpHistoryIntervalDto lastMultiSapEtimHistory;

		//calculate get the LHCV of the greater previous multiple			
		MpHistoryIntervalDto previousLHCV = mapCouponLHCV.get(interval.getCoupon());
		if (previousLHCV == null || previousLHCV.equals(lastSapEtimHistory))
		{
			//case of no history
			//or case of the LHVC has not been modified
			//calculate LHCV with the greater multiple from history
			for (String mutiInterval : potentialMultipleCoupon)
			{
				if (!mutiInterval.equals(interval.getCoupon()))
				{
					lastMultiSapEtimHistory = mapCouponLHCV.get(mutiInterval);
					if (lastMultiSapEtimHistory != null)
					{
						if (previousLHCV == null || capgemini.cnh.ticd.component.util.UtilDate.compareDate(lastMultiSapEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH),
								previousLHCV.retreiveFromExactValueByMpType(MpType.MP_MONTH),
								0) > 0)
						{
							// check if the multi is also multi for the plan during the contract of the last sap etim history
							if (isMultiple(interval.getCoupon(), mutiInterval, lastMultiSapEtimHistory, contract, listIntervalMulti, context))
							{
								previousLHCV = lastMultiSapEtimHistory;
							}
						}
					}
				}

			}
		}
		sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
		for (RepairHistoryDto dto : cacheSapRepairHistory)
		{
			// Keep VIN and not ListVIN as used as setter in the DB
			MpHistoryIntervalDto sapHistoryDto = new MpHistoryIntervalDto(null, interval.getId(), vin, interval.getCode(), planExtId, interval.getIdPlan(), new Integer(1));
			setHistoryValue(interval, sapHistoryDto, dto);
			sapHistoryList.add(sapHistoryDto);
		}

		mpBusiness.calculateLHCVFromPartHistory(sapHistoryList, previousLHCV, intervals);
		historyToSave = sapHistoryList.get(sapHistoryList.size() - 1);
		mapCouponLHCV.put(interval.getCoupon(), historyToSave);
		mapCouponLHCVFound.put(interval.getCoupon(), sapHistoryList);
	}

	/**
	 * calculateLHCVFromMulitple.
	 * 
	 * @param coupon : coupon
	 * @param mpBusiness : mpBusiness
	 * @param mapCouponLHCVFound : l LHCV already calculated for each coupon
	 * @param mapCouponAction : action to do for each multiple coupon
	 * @param intervals : list of intervals
	 * @param previousLHCV : previousLHCV
	 * 
	 * @throws SystemException System Exception
	 */
	public void calculateLHCVFromMulitple(String coupon, Map<String, List<MpHistoryIntervalDto>> mapCouponLHCVFound,
			Map<String, MpHistoryIntervalDto> mapCouponAction, MaintenancePlanBusiness mpBusiness, List<MpIntervalDto> intervals, MpHistoryIntervalDto previousLHCV) {

		List<MpHistoryIntervalDto> sapHistoryList;
		Iterator<String> iter = mapCouponAction.keySet().iterator();
		String key;
		List<MpHistoryIntervalDto> list = new ArrayList<MpHistoryIntervalDto>();
		MpHistoryIntervalDto value;
		while (iter.hasNext())
		{
			//coupon format : coupon - CalculateLHVC/UpdateLHCV - 
			//value : last element (M1) 
			key = iter.next();
			String[] tmp = key.split("-");
			if (tmp[0].equals(coupon))
			{
				if (tmp[1].equals("CalculateLHVC"))
				{
					value = mapCouponAction.get(key);
					sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
					sapHistoryList.add(value);
					mpBusiness.calculateLHCVFromPartHistory(sapHistoryList, previousLHCV, intervals);
					mapCouponLHCV.put(tmp[0], value);
					list.add(value);
					mapCouponLHCVFound.put(tmp[0], list);
				}
				else
				{
					mapCouponLHCV.put(tmp[0], previousLHCV);
					list.add(previousLHCV);
					mapCouponLHCVFound.put(tmp[0], list);
				}
				break;
			}
		}
	}

	/**
	 * get LHCV from the mulitple.
	 * 
	 * @param elt : elt
	 * @param eltToFind : element to find
	 * @param mapCouponLHCVFound : l LHCV already calculated for each coupon
	 * @param mapCouponLHVCToGet : current LHCV for each coupon
	 * @param mapSapRepairHistory : list of SAP repair for a contract
	 * @param mapCouponAction : action to do for each coupon
	 * @param mpBusiness : mp Business
	 * @param intervals : list of intevals
	 * 
	 * @throws SystemException System Exception
	 */
	public void getLHCVFromMulitple(String elt, RepairHistoryDto eltToFind, Map<String, List<MpHistoryIntervalDto>> mapCouponLHCVFound,
			Map<String, RepairHistoryDto> mapCouponLHVCToGet,
			Map<String, List<RepairHistoryDto>> mapSapRepairHistory, Map<String, MpHistoryIntervalDto> mapCouponAction, MaintenancePlanBusiness mpBusiness, List<MpIntervalDto> intervals) {
		List<RepairHistoryDto> cacheMultiSapRepairHistory = null;
		List<RepairHistoryDto> cacheSapRepairHistory = null;
		List<MpHistoryIntervalDto> sapHistoryList = new ArrayList<MpHistoryIntervalDto>();
		String[] tmp = elt.split("-");
		if (tmp[2].equals("after"))
		{
			if (mapCouponLHCVFound.get(tmp[1]) == null)
			{
				//need to be calculated recursivly
				for (String key : mapCouponLHVCToGet.keySet())
				{
					String[] tmpToFind = key.split("-");
					if (tmp[1].equals(tmpToFind[0]))
					{
						getLHCVFromMulitple(key, mapCouponLHVCToGet.get(key), mapCouponLHCVFound, mapCouponLHVCToGet, mapSapRepairHistory, mapCouponAction, mpBusiness, intervals);
						break;
					}
				}
			}
			//calculate the LHCV with the one of the last multiple
			calculateLHCVFromMulitple(tmp[0], mapCouponLHCVFound, mapCouponAction, mpBusiness, intervals, mapCouponLHCVFound.get(tmp[1]).get(mapCouponLHCVFound.get(tmp[1]).size() - 1));

		}
		else
		{
			if (mapCouponLHCVFound.get(tmp[1]) == null)
			{
				//need to be calculated recursivly
				for (String key : mapCouponLHVCToGet.keySet())
				{

					String[] tmpToFind = key.split("-");
					if (tmp[1].equals(tmpToFind[0]))
					{
						getLHCVFromMulitple(key, mapCouponLHVCToGet.get(key), mapCouponLHCVFound, mapCouponLHVCToGet, mapSapRepairHistory, mapCouponAction, mpBusiness, intervals);
						break;
					}
				}
			}
			if (mapCouponLHCVFound.get(tmp[1]) != null)
			{
				boolean found = false;
				MpHistoryIntervalDto previousLHCVOfMultiple = null;
				for (MpHistoryIntervalDto dto : mapCouponLHCVFound.get(tmp[1]))
				{
					Date sapDbDate = UtilDate.getDateDDMMYYYYFromTime(dto.retreiveFromExactValueByMpType(MpType.MP_MONTH));
					if (eltToFind.getDateFailDate().equals(sapDbDate))
					{
						previousLHCVOfMultiple = dto;
						found = true;
						break;
					}
				}
				if (!found)
				{
					//This case should not happen it would in the case of the following sequence
					// M4 M1 M2 M1 M2
					// a correct sequence is M4 M1 M2 M1 M4
					cacheMultiSapRepairHistory = mapSapRepairHistory.get(tmp[1]);
					cacheSapRepairHistory = mapSapRepairHistory.get(tmp[0]);
					String codeMulti = "";
					if (cacheMultiSapRepairHistory != null)
					{
						Collections.sort(cacheMultiSapRepairHistory, new RepairHistoryComparator());
						for (MpIntervalDto dto : intervals)
						{
							if (tmp[1].equals(dto.getCoupon()))
							{
								codeMulti = dto.getCode();
								break;
							}
						}
						for (int i = cacheMultiSapRepairHistory.size() - 1; i >= 0; i--)
						{
							if (cacheMultiSapRepairHistory.get(i).getDateFailDate().before(cacheSapRepairHistory.get(cacheSapRepairHistory.size() - 1).getDateFailDate()))
							{
								MpHistoryIntervalDto sapHistoryDto = new MpHistoryIntervalDto(null, null, null, codeMulti, null, null, new Integer(1));
								setHistoryValue(null, sapHistoryDto, cacheMultiSapRepairHistory.get(i));
								//calculate a false LHCV in this case
								sapHistoryList.add(sapHistoryDto);
								mpBusiness.calculateLHCVFromPartHistory(sapHistoryList, null, intervals);
								previousLHCVOfMultiple = sapHistoryDto;
								break;
							}
						}
					}
				}
				//calculate the LHCV with the one of the last multiple
				calculateLHCVFromMulitple(tmp[0], mapCouponLHCVFound, mapCouponAction, mpBusiness, intervals, previousLHCVOfMultiple);

			}
		}
	}

	/**
	 * Check if a coupon exists in the following contract.
	 * 
	 * @param currentContract : current contract
	 * @param coupon : current coupon
	 * @param mapContract : list of history for each coupon for all the managed contract
	 * @return true if the coupon is found
	 */
	public boolean findCouponInNextContract(SortedMap<MpContractVehicleDto, Map<String, List<RepairHistoryDto>>> mapContract, MpContractVehicleDto currentContract, String coupon) {
		//browse the list of coupon from the current coupon
		//check if there is a M1 , if yes return yes
		boolean result = false;
		Iterator<MpContractVehicleDto> iter = mapContract.keySet().iterator();
		MpContractVehicleDto contract;
		Map<String, List<RepairHistoryDto>> mapSapRepairHistory;
		while (iter.hasNext())
		{
			contract = iter.next();

			if (contract.getContractStartDate().after(currentContract.getContractStartDate()))
			{
				mapSapRepairHistory = mapContract.get(contract);
				if (mapSapRepairHistory.get(coupon) != null)
				{
					result = true;
					break;
				}
			}
		}
		return result;
	}

	/**
	 * Check if a two coupon are multiple.
	 * 
	 * @param coupon : current coupon
	 * @param couponMultiple : coupon multiple
	 * @param lastMultiSapEtimHistory : lastMultiSapEtimHistory
	 * @param listIntervalMulti : multiple of the coupon in the current contract
	 * @param currentContract : current contract
	 * @return true if the coupon are multiple
	 * @throws SystemException : SystemException
	 */
	public boolean isMultiple(String coupon, String couponMultiple, MpHistoryIntervalDto lastMultiSapEtimHistory,
			MpContractVehicleDto currentContract, List<String> listIntervalMulti, IceContextDto context) throws SystemException {

		boolean result = false;
		boolean found = false;
		Iterator<MpContractVehicleDto> iter = mapContract.keySet().iterator();
		MpContractVehicleDto contract;
		List<MpIntervalDto> intervals;
		Date sapDbDate = UtilDate.getDateDDMMYYYYFromTime(lastMultiSapEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH));
		MaintenancePlanBusiness business = getMaintenancePlanBusiness(null, customer, context);

		if ((currentContract.getContractStartDate().before(sapDbDate) || currentContract.getContractStartDate().equals(sapDbDate)) &&
				(currentContract.getContractEndDate().after(sapDbDate) || currentContract.getContractEndDate().equals(sapDbDate)))
		{
			if (listIntervalMulti != null && listIntervalMulti.contains(couponMultiple))
			{
				result = true;
			}
		}
		else
		{
			while (iter.hasNext())
			{
				contract = iter.next();

				if ((contract.getContractStartDate().before(sapDbDate) || contract.getContractStartDate().equals(sapDbDate)) &&
						(contract.getContractEndDate().after(sapDbDate) || contract.getContractEndDate().equals(sapDbDate)))
				{
					intervals = mapPlanIntervals.get(contract.getPlanId());
					if (intervals != null)
					{
						result = business.isMultiple(coupon, couponMultiple, intervals);
					}
					found = true;
					break;
				}
			}
			if (found == false)
			{
				intervals = mapPlanIntervals.get(lastMultiSapEtimHistory.getIdPlan());
				if (intervals == null)
				{
					intervals = new MpIntervalBusiness().getMaintenanceIntervalsFromIntervalId(lastMultiSapEtimHistory.getIntervalId(), defaultLanguage, mpFamilyCode);
					if (intervals != null && !intervals.isEmpty())
					{
						Collections.sort(intervals, new MpIntervalByCodeComparator(couponFlexibles));
						mapPlanIntervals.put(intervals.get(0).getIdPlan(), intervals);
					}
				}
				result = business.isMultiple(coupon, couponMultiple, intervals);
			}
		}
		return result;
	}

	/**
	 * Get the sap history from the SAP cache.
	 * 
	 * @param listRepair : list of SAP repair
	 * @param mapDefectCoupon : list of mapping coupon sap/eTIM
	 * 
	 * @return a list of Object
	 * @throws SystemException System Exception
	 */
	public SortedMap<MpContractVehicleDto, Map<String, List<RepairHistoryDto>>> getMaintenanceSapRepairHistoryForAllContract(List<RepairHistoryDto> listRepair, Map<String, String> mapDefectCoupon) {

		List<String> warrantyTypes = Arrays.asList(customer.equals(Constants.CUSTOMER_CNH) ? Constants.WARRANTY_TYPES_CNH : Constants.WARRANTY_TYPES_IVECO);
		String code = "";

		Comparator<MpContractVehicleDto> contractComparator = new Comparator<MpContractVehicleDto>() {

			@Override
			public int compare(MpContractVehicleDto c1, MpContractVehicleDto c2) {
				return c1.getContractStartDate().compareTo(c2.getContractStartDate());
			}
		};

		SortedMap<MpContractVehicleDto, Map<String, List<RepairHistoryDto>>> mapContractRepair = new TreeMap<MpContractVehicleDto, Map<String, List<RepairHistoryDto>>>(contractComparator);
		Map<String, List<RepairHistoryDto>> mapRepair = new HashMap<String, List<RepairHistoryDto>>();
		MpContractVehicleDto correspondingContract = null;
		List<RepairHistoryDto> repairList;

		String sapCode = "";
		for (RepairHistoryDto elt : listRepair)
		{
			int endIndex = customer.equals(Constants.CUSTOMER_CNH) ? 10 : 9;
			// 0 ou M => CNH / M => IVECO
			if (elt.getWtype() != null && warrantyTypes.contains(elt.getWtype()) && elt.getDefect().startsWith("000") && elt.getDefect().length() >= endIndex)
			{
				sapCode = elt.getDefect().substring(3, endIndex); // 7 digit pour CNH / 6 digit pour IVECO
				code = mapDefectCoupon.get(sapCode);
				if (code != null)
				{
					correspondingContract = getApplicableContract(elt, code, mapLastEtimDBRepairsForSap);

					if (correspondingContract != null)
					{
						mapRepair = mapContractRepair.get(correspondingContract);
						if (mapRepair != null)
						{
							repairList = mapRepair.get(code);
							if (repairList != null)
							{
								repairList.add(elt);
							}
							else
							{
								repairList = new ArrayList<RepairHistoryDto>();
								repairList.add(elt);
								mapRepair.put(code, repairList);
								newSapCoupon.put(code, code);
							}
						}
						else
						{
							mapRepair = new HashMap<String, List<RepairHistoryDto>>();
							repairList = new ArrayList<RepairHistoryDto>();
							repairList.add(elt);
							mapRepair.put(code, repairList);
							mapContractRepair.put(correspondingContract, mapRepair);
							newSapCoupon.put(code, code);
						}

					}
				}
			}
		}
		return mapContractRepair;

	}

	/**
	 * Get the sap history from the SAP cache.
	 * 
	 * @param listRepair : list of SAP repair
	 * @param mapDefectCoupon : list of mapping coupon sap/eTIM
	 * @param intervals : list of intervals
	 * @param planExtId : plan external Id
	 * @param warrantyDate : in epoch
	 * @return a list of Object
	 * @throws SystemException System Exception
	 */
	public Map<String, List<RepairHistoryDto>> getMaintenanceSapRepairHistoryForFlexibleContract(List<RepairHistoryDto> listRepair, Map<String, String> mapDefectCoupon,
			List<MpIntervalDto> intervals, Long planExtId, long warrantyDate) {
		String warrantyType = "M";
		Map<String, List<RepairHistoryDto>> lastSapCoupon = new HashMap<>();
		MpContractVehicleDto correspondingContract = null;
		MpHistoryIntervalDto sapHistoryDto;
		MpIntervalDto intervalFound = null;
		MaintenancePlanBusiness mpBusiness = getMaintenancePlanBusiness(warrantyDate, customer, context);

		//comparator of date and order listRepair in reverse order
		Comparator<RepairHistoryDto> sapClaimDescComparator = new Comparator<RepairHistoryDto>() {

			//  IAZ Repair date instead of failure date
			@Override
			public int compare(RepairHistoryDto elt1, RepairHistoryDto elt2) {
				return elt2.getDateRepairDate().compareTo(elt1.getDateRepairDate());
			}
		};
		listRepair.removeIf(Objects::isNull);
		Collections.sort(listRepair, sapClaimDescComparator);
		String code = "";
		String intervalCode = "";
		String sapCode = "";

		for (RepairHistoryDto elt : listRepair)
		{
			if (elt.getWtype().equals(warrantyType) && elt.getDefect().startsWith("000") && elt.getDefect().length() >= 9)
			{
				int endIndex = customer.equals(Constants.CUSTOMER_CNH) ? 10 : 9;
				sapCode = elt.getDefect().substring(3, endIndex); // 7 digit pour CNH / 6 digit pour IVECO
				code = mapDefectCoupon.get(sapCode);
				intervalCode = elt.getDefectDesc().split(",")[0];
				if (code != null)
				{
					correspondingContract = getApplicableContract(elt, code, mapLastEtimDBRepairsForSap);

					if (correspondingContract != null)
					{
						String finalIntervalCode = intervalCode;
						List<MpHistoryIntervalDto> matchingCoupons = listLHCV.stream()
								.filter(coupon -> coupon.getIntervalCode().equals(finalIntervalCode))
								.collect(Collectors.toList());
						
						Boolean updateCoupon = matchingCoupons.isEmpty() ||
								matchingCoupons.stream().noneMatch(coupon -> areSameDay(coupon.getFailureDate(), elt.getDateFailDate().getTime())
										&& areSameDay(elt.getDateRepairDate().getTime(), coupon.getExactValue().get(MpType.MP_MONTH)));
																			
						if (updateCoupon)
						{
							intervalFound = null;

							// Get the corresponding intervalDto 
							for (MpIntervalDto interval : intervals)
							{
								if (interval.getCode().equals(intervalCode))
								{
									intervalFound = interval;
									break;
								}
							}

							// Create new sapHistory from interval and add it in the listLHCV
							if (intervalFound != null)
							{
								// Keep VIN and not ListVIN as used as setter in the DB
								sapHistoryDto = new MpHistoryIntervalDto(null, intervalFound.getId(), vin, intervalFound.getCode(), planExtId, intervalFound.getIdPlan(), new Integer(1));
								setHistoryValue(intervalFound, sapHistoryDto, elt);
								mpBusiness.setHistoryIntValue(sapHistoryDto);
								listLHCV.add(sapHistoryDto);
							}
						}
					}
				}
			}
		}
		return lastSapCoupon;
	}

	/**
	 * get the contract for which the element from Sap broker is applicable .
	 * 
	 * @param sapRepairElt : element from SAP broker
	 * @param code : coupon
	 * @param mapLastEtimDBRepairsForSap : list of SAP history for all coupons of the current contract
	 * @return the contract for which the element from Sap broker is applicable
	 */
	public MpContractVehicleDto getApplicableContract(RepairHistoryDto sapRepairElt, String code, Map<String, MpHistoryIntervalDto> mapLastEtimDBRepairsForSap) {

		MpContractVehicleDto result = null;
		List<MpContractVehicleDto> contracts = mpContract.getContracts();
		MpHistoryIntervalDto lastSap = mapLastEtimDBRepairsForSap.get(code);
		Date dbDate = null;
		if (lastSap != null)
		{
			dbDate = UtilDate.getDateDDMMYYYYFromTime(lastSap.retreiveFromExactValueByMpType(MpType.MP_MONTH));
		}
		//Changes for INC6647968
		//  IAZ 
		if (lastSap == null || (null != sapRepairElt && null != sapRepairElt.getDateRepairDate() && null != dbDate && sapRepairElt.getDateRepairDate().after(dbDate)))
		{
			for (MpContractVehicleDto contract : contracts)
			{

				if ((contract.getContractStartDate().before(sapRepairElt.getDateRepairDate()) || contract.getContractStartDate().equals(sapRepairElt.getDateRepairDate()))
						&& (contract.getContractEndDate().after(sapRepairElt.getDateRepairDate()) || contract.getContractEndDate().equals(sapRepairElt.getDateRepairDate())))
				{

					result = contract;
					break;
				}
			}

		}
		return result;
	}

	/**
	 * set the history value from sap broker history.
	 * 
	 * @param interval : interval
	 * @param sapHistoryDto : sap History Dto
	 * @param repairDto : repair Dto
	 */
	public static void setHistoryValue(MpIntervalDto interval, MpHistoryIntervalDto sapHistoryDto, RepairHistoryDto repairDto) {

		if (interval == null || (interval.getAfterMath(MpType.MP_KM) > 0 || interval.getStartMath(MpType.MP_KM) > 0))
		{
			sapHistoryDto.addToExactValue(MpType.MP_KM, new Long(repairDto.getHoursKm()));
		}
		else
		{
			sapHistoryDto.addToExactValue(MpType.MP_KM, Long.valueOf(0L));
		}

		if (interval == null || (interval.getAfterMath(MpType.MP_HOUR) > 0 || interval.getStartMath(MpType.MP_HOUR) > 0))
		{
			sapHistoryDto.addToExactValue(MpType.MP_HOUR, new Long(repairDto.getHoursKm()));
		}
		else
		{
			sapHistoryDto.addToExactValue(MpType.MP_HOUR, Long.valueOf(0L));
		}

		// IAZ Store repair date (ms) in MP_EXACT_VALUE_MONTH
		Calendar time = Calendar.getInstance();
		time.setTime(repairDto.getDateRepairDate());
		long timestamp = repairDto.getDateRepairDate().getTime() + time.getTimeZone().getOffset(time.getTime().getTime());

		sapHistoryDto.addToExactValue(MpType.MP_MONTH, Long.valueOf(timestamp));

		//Store failure date (ms) in MPH_FAILURE_DATE
		Calendar timeFailure = Calendar.getInstance();
		timeFailure.setTime(repairDto.getDateFailDate());
		long timestampFailure = repairDto.getDateFailDate().getTime() + timeFailure.getTimeZone().getOffset(timeFailure.getTime().getTime());

		sapHistoryDto.setFailureDate(Long.valueOf(timestampFailure));
	}

	/**
	 * @return the list of mapping defect.
	 */
	public Map<String, String> mappingDefectCoupon() {
		Map<String, String> mapDefectCoupon = new HashMap<String, String>();

		//old coupon
		mapDefectCoupon.put("EO0000", "MPEO00");

		mapDefectCoupon.put("EP1000", "MPEP01");
		mapDefectCoupon.put("EP2000", "MPEP02");
		mapDefectCoupon.put("EP3000", "MPEP03");
		mapDefectCoupon.put("EP4000", "MPEP04");
		mapDefectCoupon.put("EP5000", "MPEP05");
		mapDefectCoupon.put("EP6000", "MPEP06");
		mapDefectCoupon.put("EP7000", "MPEP07");
		mapDefectCoupon.put("EP8000", "MPEP08");
		mapDefectCoupon.put("EP9000", "MPEP09");

		mapDefectCoupon.put("M00000", "MPMM00");

		mapDefectCoupon.put("M0B000", "MPMM00");
		mapDefectCoupon.put("M10000", "MPMM01");

		mapDefectCoupon.put("M1B000", "MPMM01");
		mapDefectCoupon.put("M20000", "MPMM02");

		mapDefectCoupon.put("M2B000", "MPMM02");
		mapDefectCoupon.put("M30000", "MPMM03");

		mapDefectCoupon.put("M3B000", "MPMM03");
		mapDefectCoupon.put("M40000", "MPMM04");
		mapDefectCoupon.put("M4B000", "MPMM04");
		mapDefectCoupon.put("M50000", "MPMM05");
		mapDefectCoupon.put("M5B000", "MPMM05");
		mapDefectCoupon.put("M60000", "MPMM06");
		mapDefectCoupon.put("M6B000", "MPMM06");
		mapDefectCoupon.put("M70000", "MPMM07");
		mapDefectCoupon.put("M80000", "MPMM08");
		mapDefectCoupon.put("M90000", "MPMM09");
		mapDefectCoupon.put("MO0000", "MPMM0O");

		mapDefectCoupon.put("PDI000", "MPPD00");
		mapDefectCoupon.put("PDIB00", "MPPD00");
		mapDefectCoupon.put("PDIC00", "MPPD01");

		mapDefectCoupon.put("T10000", "MPTT01");
		mapDefectCoupon.put("T20000", "MPTT02");
		mapDefectCoupon.put("T30000", "MPTT03");
		mapDefectCoupon.put("T40000", "MPTT04");
		mapDefectCoupon.put("T50000", "MPTT05");
		mapDefectCoupon.put("T60000", "MPTT06");
		mapDefectCoupon.put("T70000", "MPTT07");
		mapDefectCoupon.put("T80000", "MPTT08");
		mapDefectCoupon.put("T90000", "MPTT09");
		mapDefectCoupon.put("T9A000", "MPTT10");

		//new coupon (it is needed because in previous contract, the coupon are not added)

		//Flexible coupons
		//AF
		mapDefectCoupon.put("MPAF00", "MPAF00");
		//FF
		mapDefectCoupon.put("MPFF00", "MPFF00");
		//EO
		mapDefectCoupon.put("MPEO00", "MPEO00");

		mapDefectCoupon.put("MPEP01", "MPEP01");
		mapDefectCoupon.put("MPEP02", "MPEP02");
		mapDefectCoupon.put("MPEP03", "MPEP03");
		mapDefectCoupon.put("MPEP04", "MPEP04");
		mapDefectCoupon.put("MPEP05", "MPEP05");
		mapDefectCoupon.put("MPEP06", "MPEP06");
		mapDefectCoupon.put("MPEP07", "MPEP07");
		mapDefectCoupon.put("MPEP08", "MPEP08");
		mapDefectCoupon.put("MPEP09", "MPEP09");
		mapDefectCoupon.put("MPEP10", "MPEP10");

		mapDefectCoupon.put("MPEP11", "MPEP11");
		mapDefectCoupon.put("MPEP12", "MPEP12");
		mapDefectCoupon.put("MPEP13", "MPEP13");
		mapDefectCoupon.put("MPEP14", "MPEP14");
		mapDefectCoupon.put("MPEP15", "MPEP15");
		mapDefectCoupon.put("MPEP16", "MPEP16");
		mapDefectCoupon.put("MPEP17", "MPEP17");
		mapDefectCoupon.put("MPEP18", "MPEP18");
		mapDefectCoupon.put("MPEP19", "MPEP19");
		mapDefectCoupon.put("MPEP20", "MPEP20");

		mapDefectCoupon.put("MPEP21", "MPEP21");
		mapDefectCoupon.put("MPEP22", "MPEP22");
		mapDefectCoupon.put("MPEP23", "MPEP23");
		mapDefectCoupon.put("MPEP24", "MPEP24");
		mapDefectCoupon.put("MPEP25", "MPEP25");
		mapDefectCoupon.put("MPEP26", "MPEP26");
		mapDefectCoupon.put("MPEP27", "MPEP27");
		mapDefectCoupon.put("MPEP28", "MPEP28");
		mapDefectCoupon.put("MPEP29", "MPEP29");
		mapDefectCoupon.put("MPEP30", "MPEP30");

		mapDefectCoupon.put("MPEP31", "MPEP31");

		//MM
		mapDefectCoupon.put("MPMM00", "MPMM00");
		mapDefectCoupon.put("MPMM01", "MPMM01");
		mapDefectCoupon.put("MPMM02", "MPMM02");
		mapDefectCoupon.put("MPMM03", "MPMM03");
		mapDefectCoupon.put("MPMM04", "MPMM04");
		mapDefectCoupon.put("MPMM05", "MPMM05");
		mapDefectCoupon.put("MPMM06", "MPMM06");
		mapDefectCoupon.put("MPMM07", "MPMM07");
		mapDefectCoupon.put("MPMM08", "MPMM08");
		mapDefectCoupon.put("MPMM09", "MPMM09");
		mapDefectCoupon.put("MPMM10", "MPMM10");
		mapDefectCoupon.put("MPMM11", "MPMM11");
		mapDefectCoupon.put("MPMM12", "MPMM12");
		mapDefectCoupon.put("MPMM13", "MPMM13");

		//TT
		mapDefectCoupon.put("MPTT01", "MPTT01");
		mapDefectCoupon.put("MPTT02", "MPTT02");
		mapDefectCoupon.put("MPTT03", "MPTT03");
		mapDefectCoupon.put("MPTT04", "MPTT04");
		mapDefectCoupon.put("MPTT05", "MPTT05");
		mapDefectCoupon.put("MPTT06", "MPTT06");
		mapDefectCoupon.put("MPTT07", "MPTT07");
		mapDefectCoupon.put("MPTT08", "MPTT08");
		mapDefectCoupon.put("MPTT09", "MPTT09");
		mapDefectCoupon.put("MPTT10", "MPTT10");

		mapDefectCoupon.put("MPTT11", "MPTT11");
		mapDefectCoupon.put("MPTT12", "MPTT12");
		mapDefectCoupon.put("MPTT13", "MPTT13");
		mapDefectCoupon.put("MPTT14", "MPTT14");
		mapDefectCoupon.put("MPTT15", "MPTT15");
		mapDefectCoupon.put("MPTT16", "MPTT16");
		mapDefectCoupon.put("MPTT17", "MPTT17");
		mapDefectCoupon.put("MPTT18", "MPTT18");
		mapDefectCoupon.put("MPTT19", "MPTT19");
		mapDefectCoupon.put("MPTT20", "MPTT20");

		mapDefectCoupon.put("MPTT21", "MPTT21");
		mapDefectCoupon.put("MPTT22", "MPTT22");
		mapDefectCoupon.put("MPTT23", "MPTT23");
		mapDefectCoupon.put("MPTT24", "MPTT24");
		mapDefectCoupon.put("MPTT25", "MPTT25");
		mapDefectCoupon.put("MPTT26", "MPTT26");
		mapDefectCoupon.put("MPTT27", "MPTT27");
		mapDefectCoupon.put("MPTT28", "MPTT28");
		mapDefectCoupon.put("MPTT29", "MPTT29");
		mapDefectCoupon.put("MPTT30", "MPTT30");

		mapDefectCoupon.put("MPTT31", "MPTT31");
		mapDefectCoupon.put("MPTT32", "MPTT32");
		mapDefectCoupon.put("MPTT33", "MPTT33");
		mapDefectCoupon.put("MPTT34", "MPTT34");
		mapDefectCoupon.put("MPTT35", "MPTT35");
		mapDefectCoupon.put("MPTT36", "MPTT36");
		mapDefectCoupon.put("MPTT37", "MPTT37");
		mapDefectCoupon.put("MPTT38", "MPTT38");
		mapDefectCoupon.put("MPTT39", "MPTT39");
		mapDefectCoupon.put("MPTT40", "MPTT40");

		//NN
		mapDefectCoupon.put("MPNN00", "MPNN00");
		mapDefectCoupon.put("MPNN01", "MPNN01");
		mapDefectCoupon.put("MPNN02", "MPNN02");
		mapDefectCoupon.put("MPNN03", "MPNN03");
		mapDefectCoupon.put("MPNN04", "MPNN04");
		mapDefectCoupon.put("MPNN05", "MPNN05");
		mapDefectCoupon.put("MPNN06", "MPNN06");
		mapDefectCoupon.put("MPNN07", "MPNN07");
		mapDefectCoupon.put("MPNN08", "MPNN08");
		mapDefectCoupon.put("MPNN09", "MPNN09");
		mapDefectCoupon.put("MPNN10", "MPNN10");

		mapDefectCoupon.put("MPNN11", "MPNN11");
		mapDefectCoupon.put("MPNN12", "MPNN12");
		mapDefectCoupon.put("MPNN13", "MPNN13");
		mapDefectCoupon.put("MPNN14", "MPNN14");
		mapDefectCoupon.put("MPNN15", "MPNN15");
		mapDefectCoupon.put("MPNN16", "MPNN16");
		mapDefectCoupon.put("MPNN17", "MPNN17");
		mapDefectCoupon.put("MPNN18", "MPNN18");
		mapDefectCoupon.put("MPNN19", "MPNN19");
		mapDefectCoupon.put("MPNN20", "MPNN20");

		return mapDefectCoupon;
	}

	/**
	 * MaintenancePlanBusiness Scheduling algo for CV and AG&CE for tolerance calculation
	 * 
	 * @param customer
	 * @param transaction
	 * @param iceContextDto
	 * @return
	 */
	private MaintenancePlanBusiness getMaintenancePlanBusiness(Long warrantyDate, String customer, IceContextDto iceContextDto) {
		MpToleranceDto mpToleranceDto = new MpToleranceBusiness().getToleranceByBrandAndMarket(iceContextDto);
		MaintenancePlanBusiness mpBusiness = null;
		switch (mpToleranceDto.getSchedulingType())
		{
		case Constants.VARIABLE_SCHEDULING:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(warrantyDate, customer, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(customer, iceContextDto);
			}
			break;
		case Constants.FIXED_SCHEDULING:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanFixedSchedulingBusiness(warrantyDate, customer, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanFixedSchedulingBusiness(customer, iceContextDto);
			}
			break;
		default:
			if (warrantyDate != null)
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(warrantyDate, customer, iceContextDto);
			}
			else
			{
				mpBusiness = new MaintenancePlanVariableSchedulingBusiness(customer, iceContextDto);
			}
			break;
		}
		return mpBusiness;
	}

	/**
	 * @return the couponFlexibles
	 */
	public Map<String, MpFlexCouponDto> getCouponFlexibles() {
		return couponFlexibles;
	}

	/**
	 * @param couponFlexibles the couponFlexibles to set
	 */
	public void setCouponFlexibles(Map<String, MpFlexCouponDto> couponFlexibles) {
		this.couponFlexibles = couponFlexibles;
	}

	/**
	 * 
	 * @return The customer.
	 */
	public String getCustomer() {
		return customer;
	}

	/**
	 * 
	 * @param customer The customer.
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	
	private boolean areSameDay(Long timestamp1, Long timestamp2) {
		if (timestamp1 == null || timestamp2 == null) {
			return false;
		}
		
		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		
		cal1.setTimeInMillis(timestamp1);
		cal2.setTimeInMillis(timestamp2);
		
		return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
				&& cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
	}

	//	/**
	//	 * Set intervals to use for AG&CE.
	//	 * 
	//	 * @param useIntervals Intervals to use for AG&CE.
	//	 */
	//	public void setUseIntervals(List<MpIntervalDto> useIntervals) {
	//		this.useIntervals = useIntervals;
	//	}
}
