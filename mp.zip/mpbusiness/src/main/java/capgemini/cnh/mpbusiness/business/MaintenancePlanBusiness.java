package capgemini.cnh.mpbusiness.business;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.mutable.MutableBoolean;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.externals.sap.SAPBroker;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.VehicleDataDto;
import capgemini.cnh.externals.sap.model.SAPParameters;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.ResourceLabel;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.WebParamBusiness;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.WebParamDto;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopByScoreDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpScoreDto;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.ContractVisibility;
import capgemini.cnh.mpbusiness.util.MpIntervalStatusEnum;
import capgemini.cnh.mpbusiness.util.MpNextFlexComparator;
import capgemini.cnh.ticd.component.business.TableTitleBusiness;
import capgemini.cnh.ticd.component.dto.TableTitleDto;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * Business treatment for mp.
 */
public abstract class MaintenancePlanBusiness extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * logger variable.
	 */
	protected static TIDBLogger logger = TIDBLogger.getLogger(MaintenancePlanBusiness.class);

	/**
	 * @deprecated
	 *             Multiple interval list.
	 */
	@Deprecated
	private Map<MpType, List<MpScoreDto>> multiple;

	/**
	 * Actual performance value for the vehicle.
	 */
	protected Map<MpType, Long> actual;

	/**
	 * Tolerated delta for interval recommendation.
	 */
	protected Map<MpType, Long> delta = null;

	/**
	 * Tolerated far for interval comment.
	 */
	protected Map<MpType, Long> far = new HashMap<>();

	/**
	 * Translator.
	 */
	private Locale locale;

	/**
	 * Epoch warranty start date.
	 */
	public long warranty;

	/**
	 * Customer: "IVECO" or "CNH".
	 */
	protected String customer = null;

	/** Flexible coupons. **/
	protected Map<String, MpFlexCouponDto> flexibleCoupons = new HashMap<>();

	/** MpToleranceDto **/
	MpToleranceDto mpToleranceDto = new MpToleranceDto();

	/* *************************************** */
	/* ************* Constructors ************ */
	/* *************************************** */

	/**
	 * Constructor.
	 * 
	 * @param customer the customer
	 */
	public MaintenancePlanBusiness(String customer, IceContextDto dtoIceContext) {
		// dtoIceContext can be null (IVECO case)
		this(customer, null, dtoIceContext);
	}

	/**
	 * Constructor.
	 * 
	 * @param customer the customer
	 * @param dbAccess the transaction
	 */
	public MaintenancePlanBusiness(String customer, Access dbAccess, IceContextDto context) {
		super();
		this.dbAccess = dbAccess;
		this.multiple = new HashMap<>();
		this.far = new HashMap<>();
		this.actual = new HashMap<>();
		this.delta = new HashMap<>();
		this.customer = customer;

		// Get the tolerance by brand and market in the DB
		this.mpToleranceDto = getTolerance(context);

		this.warranty = 0L;
	}

	/**
	 * Default constructor.
	 * 
	 * @param warrantyStartDate the warranty start date
	 * @param customer the customer
	 */
	public MaintenancePlanBusiness(long warrantyStartDate, String customer, IceContextDto context) {  //No need of context

		// FOR SAP
		this(warrantyStartDate, customer, null, context);
	}

	/**
	 * Default constructor.
	 * 
	 * @param warrantyStartDate the warranty start date
	 * @param customer the customer
	 * @param dbAccess the transaction
	 */
	public MaintenancePlanBusiness(long warrantyStartDate, String customer, Access dbAccess, IceContextDto context) {
		super();
		this.dbAccess = dbAccess;
		this.far = new HashMap<>();
		this.actual = new HashMap<>();
		this.delta = new HashMap<>();
		this.customer = customer;

		// Get the tolerance by brand and market in the DB
		this.mpToleranceDto = getTolerance(context);

		this.warranty = warrantyStartDate;
	}

	/**
	 * Constructor from actual values.
	 * 
	 * @param pActualMileage the mileage
	 * @param pActualHour the hours of service
	 * @param pWarrantyStartDate the warranty start date
	 * @param pNowDate the current date
	 * @param pLocale local for translation
	 * @param customer the customer
	 */
	public MaintenancePlanBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, IceContextDto context) {
		this(pActualMileage, pActualHour, pWarrantyStartDate, pNowDate, pLocale, customer, null, context);
	}

	/**
	 * Constructor from actual values.
	 * 
	 * @param pActualMileage the mileage
	 * @param pActualHour the hours of service
	 * @param pWarrantyStartDate the warranty start date
	 * @param pNowDate the current date
	 * @param pLocale local for translation
	 * @param customer the customer
	 * @param dbAccess the transaction
	 */
	public MaintenancePlanBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, Access dbAccess, IceContextDto context) {
		super();
		this.dbAccess = dbAccess;
		this.multiple = new HashMap<>();
		this.actual = new HashMap<>();
		this.far = new HashMap<>();
		this.delta = new HashMap<>();
		this.customer = customer;

		// Get the tolerance by brand and market in the DB
		this.mpToleranceDto = getTolerance(context);

		this.locale = pLocale;
		this.warranty = pWarrantyStartDate != null ? Long.parseLong(pWarrantyStartDate) : 0L;

		this.setActualMileage(pActualMileage);
		this.setActualHour(pActualHour);
		if (pWarrantyStartDate != null && pNowDate != null)
		{
			this.actual.put(MpType.MP_MONTH, getElapsedMonth(pWarrantyStartDate, pNowDate));
		}
		else
		{
			this.actual.put(MpType.MP_MONTH, 0L);
		}
		//this.testGetElapsedMonth();
	}

	/**
	 * Cast the input mileage into select algorithm compatible value.
	 * 
	 * @param pActualMileage
	 *            the mileage
	 */
	private void setActualMileage(String pActualMileage) {
		Long actualMileage = 0L;
		try
		{
			actualMileage = Long.parseLong(pActualMileage);
		}
		catch (NullPointerException | NumberFormatException e)
		{
			logger.debug("No mileage: " + e.getMessage());
		}
		this.actual.put(MpType.MP_KM, actualMileage);
	}

	/**
	 * Cast the input hour into select algorithm compatible value.
	 * 
	 * @param pActualHour
	 *            the hour
	 */
	private void setActualHour(String pActualHour) {
		Long actualHour = 0L;
		try
		{
			actualHour = Long.parseLong(pActualHour);
		}
		catch (NullPointerException | NumberFormatException e)
		{
			logger.debug("No hour: " + e.getMessage());
		}
		this.actual.put(MpType.MP_HOUR, actualHour);
	}

	/* ********************************************************************************** */
	/* ************* Abstract Methods, implemented in Implementation classes : ********** */
	/*  - MaintenancePlanVariableSchedulingBusiness (default)                  ********** */
	/*  - MaintenancePlanFixedSchedulingBusiness                               ********** */
	/* ********************************************************************************** */

	/**
	 * Update delta value based on M1 interval (10 % of M1).
	 * 
	 * @param intervalList the interval list
	 */
	public abstract void updateDelta(List<MpIntervalDto> intervalList);

	/**
	 * Update delta value based on M1 interval (10 % of M1).
	 * 
	 * @param perfKm : perf of M1 in km
	 * @param perfHour : perf of M1 in hour
	 */
	public abstract void updateDelta(Long perfKm, Long perfHour);

	/**
	 * Check if an interval should be selected.
	 * 
	 * @param pScore score of the interval
	 * @param pType interval type
	 * @return selected flag
	 */
	protected abstract boolean selectPerformance(MpScoreDto pScore, MpType pType);

	/**
	 * Update the interval value for the history for computation.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * <p>
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM.
	 * At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * </p>
	 * 
	 * @param historyList interval history
	 * @param pListIntervals list of all the intervals of the plan
	 */
	public abstract void calculateLHCVFromPartHistory(List<MpHistoryIntervalDto> historyList, MpHistoryIntervalDto previousHistoryConsiderValue, List<MpIntervalDto> pListIntervals);

	/**
	 * Update the interval value for the history for computation.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * <p>
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM.
	 * At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * </p>
	 * 
	 * @param historyList interval history
	 * @param pListIntervals list of all the intervals of the plan
	 */
	public abstract void calculateLHCVFromFullHistory(List<MpHistoryIntervalDto> historyList, List<MpIntervalDto> pListIntervals);

	/**
	 * Apply multiple rules for interval selection.
	 * 
	 * @param pScore the score
	 */
	protected abstract void applyMultiples(MpScoreDto pScore);

	/**
	 * Apply multiple rules for interval comment.
	 * Remove unwanted comments.
	 * 
	 * @param pScore the score
	 */
	protected abstract void applyMultiplesComment(MpScoreDto pScore);

	/**
	 * Clear the multipleList in the Variable Scheduling
	 */
	protected abstract void clearMultipleList();

	/**
	 * Apply multiple rules for selecting interval for next stop .
	 * Remove unwanted comments.
	 * 
	 * @param pScore the score
	 */
	public abstract void applyNextStopMultiples(List<MpNextStopByScoreDto> scoreList, MpType type, Long minNextStop);

	/**
	 * Check if an interval flexible should be selected.
	 * 
	 * @param nextStopFlex : next stop to determine if needs to be selected
	 * @param scoreList list score of the interval
	 * @return selected flag
	 */
	protected abstract void selectPerformanceFlexible(MpNextStopDto nextStopFlex, List<MpScoreDto> scoreList);

	/**
	 * Update the history of the score depending on multiple history.
	 * 
	 * @param pScore the score to update
	 * @param pMultipleList the multiple list
	 */
	protected abstract void updateHistoryFromMultiple(MpScoreDto pScore, List<MpScoreDto> pMultipleList);

	/**
	 * Calculate next flexible stop.
	 * 
	 * @param listToRecalculate : list to recalculate
	 * @param listPreviousNextStop : list of previous next stop
	 * @param listPreviousHistory : list of previous history
	 * @param intervals : list of intervals
	 * @param vin : vehicle indentifier number
	 * @return next flexible stop to update
	 */
	public abstract List<MpNextStopDto> calculateNextFlexibleStop(List<MpHistoryIntervalDto> listToRecalculate, List<MpNextStopDto> listPreviousNextStop,
			List<MpHistoryIntervalDto> listPreviousHistory,
			List<MpIntervalDto> intervals, String vin);

	/**
	 * Apply New Multiple Rule
	 * 
	 * @param scoreList
	 */
	protected abstract void applyNewMultipleRule(List<MpScoreDto> scoreList);

	/**
	 * Get the multiple of an elements.
	 * 
	 * @param intervals : intervals
	 * 
	 * @return a list of Object
	 * @throws SystemException System Exception
	 */
	public abstract Map<String, List<String>> getMultiInterval(List<MpIntervalDto> intervals) throws SystemException;

	/**
	 * Check element is multiple of an element.
	 * 
	 * @param intervals : intervals
	 * @param couponMultiple : couponMultiple
	 * @param coupon : coupon
	 * 
	 * @return a list of Object
	 * @throws SystemException System Exception
	 */
	public abstract boolean isMultiple(String coupon, String couponMultiple, List<MpIntervalDto> intervals);

	/**
	 * Update the interval value for the history for saving.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * <p>
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM.
	 * At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * </p>
	 * 
	 * @param type performance type (km, hour, date)
	 * @param actual actual history value
	 * @param history interval history
	 * @param interval interval matching the history
	 * @return the interval value to be saved in database
	 */
	protected abstract long getIntValueHistory(MpType type, long actual, MpHistoryIntervalDto history, MpIntervalDto interval);

	/**
	 * Update the interval value for the history.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM. At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * 
	 * @param actual exact history value
	 * @param after interval after value
	 * @param at interval at value
	 * @return the interval history value for the type
	 */
	protected abstract long getInterval(long actual, long after, long at, long far);

	/**
	 * Build the score list based on MP intervals.
	 * 
	 * @param pListInterval the interval list
	 * @param pListQuestion the interval question list
	 * @return the possible interval as score
	 */
	protected abstract List<MpScoreDto> getScore(List<MpIntervalDto> pListInterval, List<MpHistoryIntervalDto> questionList);

	/**
	 * Build the score list based on MP intervals.
	 * 
	 * @param listInterval the interval list
	 * @param listHistory the interval question list
	 * @param listFlexNextStop the list of next stop
	 * @param isHeavyFlex is contract flexible
	 * @return the possible interval as score
	 */
	protected abstract List<MpNextStopByScoreDto> getNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, boolean isHeavyFlex);

	/**
	 * Calculate next stop and record it in DB.
	 * 
	 * @param listInterval the interval list for the selected plan
	 * @param listHistory the history of intervals for the selected plan
	 * @param listFlexNextStop next stop coming from EDS (in this case no need to recalculate the value)
	 * @param vin the vin
	 * @param isHeavyFlexContract the contract is flexible
	 * @param planId the plan Id selected
	 * @param warrantyStartDate warrantyStartDate
	 * @param lastCurrentMileage : last current mileage
	 * @param lastCurrentHour : last current hour
	 * 
	 * @return the next stop in the tolerance
	 */
	public abstract List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour);

	public abstract List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> fullListNextStop);

	/**
	 * Calculate proposal date.
	 * 
	 * @param warrantyStartDate : warranty Start Date
	 * @param lastCurrentMileage : current mileage
	 * @param lastCurrentHour : current hour
	 * @param scoreList : score List
	 * @param type : type
	 * @param contractVisibility : contract flex or targa
	 * @return min value by type
	 */
	public abstract Long calculateMinScore(Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> scoreList, MpType type,
			ContractVisibility contractVisibility);

	/* ************************************************* */
	/* **************** Common Methods ***************** */
	/* ************************************************* */

	/**
	 * Cast the time from start date to end date into elapsed month.
	 * 
	 * @param pStartDate
	 *            the start date in UTC epoch
	 * @param pEndDate
	 *            the end date in UTC epoch
	 * @return The elapsed month from start to end date.
	 */
	protected static Long getElapsedMonth(String pStartDate, String pEndDate) {
		Long actualMonth = 0L;
		Long wepoch = 0L;
		Long nepoch = 0L;
		int delta_y = 0;
		int delta_m = 0;
		int delta_d = 0;
		int nb_month = 0;
		try
		{
			wepoch = Long.parseLong(pStartDate);
			nepoch = Long.parseLong(pEndDate);
			if (wepoch != null && wepoch.compareTo(0L) > 0 && nepoch != null && nepoch.compareTo(0L) > 0)
			{
				Calendar warranty = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
				warranty.clear();
				Date dStart = new Date(wepoch);
				warranty.setTime(dStart);

				Calendar now = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
				now.clear();
				Date dEnd = new Date(nepoch);
				now.setTime(dEnd);

				delta_y = now.get(Calendar.YEAR) - warranty.get(Calendar.YEAR);
				if (delta_y < 0)
				{
					throw new IllegalArgumentException("Warranty year is greater than current year!");
				}
				// -- else date valid
				nb_month = now.getActualMaximum(Calendar.MONTH) + 1; // -- cause months start at 0
				actualMonth = (long) (nb_month * delta_y);

				delta_m = now.get(Calendar.MONTH) - warranty.get(Calendar.MONTH);
				actualMonth += (long) delta_m;

				delta_d = now.get(Calendar.DAY_OF_MONTH) - warranty.get(Calendar.DAY_OF_MONTH);
				if (delta_d < -15)
				{
					actualMonth -= 1L;
				}
				else if (delta_d > 15)
				{
					actualMonth += 1L;
				}
				// -- else same day exact match nothing to do
				logger.debug("delta years(" + delta_y + ") months(" + delta_m + ") delta days(" + delta_d + ") = " + actualMonth);

				if (actualMonth.compareTo(0L) < 0)
				{
					throw new IllegalArgumentException("Warranty date seems greater than current date!");
				}
			}
			else
			{
				throw new IllegalArgumentException("Null or 0 date.");
			}
		}
		catch (IllegalArgumentException | NullPointerException e)
		{
			logger.debug("No valid warranty start date found: " + e.getMessage());
			actualMonth = 0L;
		}
		return (actualMonth);
	}

	/**
	 * Inner comment builder.
	 * 
	 * @param pScore the interval to comment
	 * @return the comment
	 */
	private StringBuilder setCommentSelected(MpScoreDto pScore, boolean isIveco, String unit) {
		Long delta = 0L;

		MutableBoolean messageWritten = new MutableBoolean();
		messageWritten.setFalse();
		MpIntervalDto interval = pScore.getInterval();
		StringBuilder comment = new StringBuilder();

		MpType[] mpTypes;
		if (isIveco)
		{
			// For Iveco (km, hour, month)
			mpTypes = MpType.values();
		}
		else
		{
			// For AG (hour, month, km(unit))
			mpTypes = MpType.valuesForAG();
		}

		boolean onTimeForType = false;

		// Set the correct status for the intervals
		for (MpType type : mpTypes)
		{
			if (pScore.isValid(type))
			{
				delta = pScore.getScoreByType(type);
				if (pScore.getSelectedByType(type))
				{
					Long absDelta = new Long(java.lang.Math.abs(delta));
					// if delta (actual-selected) - tolerance > 0
					// If over the technical tolerance
					if (delta.compareTo(this.delta.get(type)) > 0)
					{
						// If high overdue
						// If over the warranty/commercial tolerance
						if (delta.compareTo(this.far.get(type)) > 0)
						{
							interval.setStatus(MpIntervalStatusEnum.HIGH_OVERDUE);
						}
						// If normal overdue
						else if (!interval.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE))
						{
							interval.setStatus(MpIntervalStatusEnum.OVERDUE);
						}
					}
					// If coming soon = Between Technical and Warranty/Commercial tolerance
					else if (!onTimeForType && this.actual.get(type).compareTo(0L) > 0 && delta != null && delta.compareTo(0L) < 0 && absDelta.compareTo(this.delta.get(type)) > 0
							&& absDelta.compareTo(this.far.get(type)) <= 0
							&& !interval.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE) && !interval.getStatus().equals(MpIntervalStatusEnum.OVERDUE))
					{
						interval.setStatus(MpIntervalStatusEnum.COMING_SOON);
					}
					else
					{
						// onTimeForType set to true means for example that the coupon is on type for Km but coming soon for hours, and this will prevent the message to be displayed
						onTimeForType = true;
						if (!interval.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE) && !interval.getStatus().equals(MpIntervalStatusEnum.OVERDUE))
						{
							interval.setStatus(MpIntervalStatusEnum.ON_TIME);
						}
					}
				}
			}
		}

		// Write the correct values for the intervals
		for (MpType type : mpTypes)
		{
			if (pScore.isValid(type))
			{
				delta = pScore.getScoreByType(type);
				if (interval.isSelected())
				{
					Long absDelta = new Long(java.lang.Math.abs(delta));

					// High Overdue and Delta > Commercial & Technical tolerance (as Commercial tolerance can in some case be < than Technical tolerance)
					if (interval.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE) && delta.compareTo(this.delta.get(type)) > 0 && delta.compareTo(this.far.get(type)) > 0)
					{
						comment.append(generateComment(messageWritten, Constants.MESSAGE_HIGH_OVERDUE_OF, type, delta, isIveco, unit, interval, false));
					}
					else if (interval.getStatus().equals(MpIntervalStatusEnum.OVERDUE) && delta.compareTo(this.delta.get(type)) > 0)
					{
						comment.append(generateComment(messageWritten, Constants.MESSAGE_OVERDUE_OF, type, delta, isIveco, unit, interval, false));
					}
					else if (interval.getStatus().equals(MpIntervalStatusEnum.COMING_SOON) && this.actual.get(type).compareTo(0L) > 0 && delta != null && delta.compareTo(0L) < 0
							&& absDelta.compareTo(this.delta.get(type)) > 0 && absDelta.compareTo(this.far.get(type)) <= 0)
					{
						comment.append(generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, type, delta, isIveco, unit, interval, false));
					}
					else if (interval.getStatus().equals(MpIntervalStatusEnum.ON_TIME) && this.actual.get(type).compareTo(0L) > 0 && delta != null && delta.compareTo(0L) < 0
							&& absDelta.compareTo(this.delta.get(type)) <= 0)
					{
						comment.append(generateComment(messageWritten, Constants.MESSAGE_NEXT_STOP_FORECAST, type, delta, isIveco, unit, interval, false));
					}
				}
			}
		}
		return (comment);
	}

	/**
	 * Generate comment depending if something has already been started and with the correct numbers to display.
	 * 
	 * @param messageWritten
	 * @param labelProperties
	 * @param type
	 * @param delta
	 * @param isIveco
	 * @param unit
	 * @param interval
	 * @return
	 */

	public String generateComment(MutableBoolean messageWritten, String labelProperties, MpType type, Long delta, boolean isIveco, String unit, MpIntervalDto interval, boolean useDaysMessage) {
		StringBuilder result = new StringBuilder();
		String singular = new String();
		if (!messageWritten.booleanValue())
		{
			// only in struts environment
			if (null != ResourceLabel.getInstance())
			{
				result.append(ResourceLabel.getInstance().getLabel(labelProperties, this.locale));
				result.append(" ");
			}
			else
			{
				result.append(labelProperties);
				result.append(" ");
			}
			messageWritten.setTrue();
		}
		else
		{
			// only in struts environment
			if (null != ResourceLabel.getInstance())
			{
				result.append(" ");
				result.append(ResourceLabel.getInstance().getLabel("label.or", this.locale));
				result.append(" ");
			}
			else
			{
				result.append(" ");
				result.append("label.or");
				result.append(" ");
			}
		}

		result.append(java.lang.Math.abs(delta));
		interval.getDeltaValue().put(type, delta);
		result.append(" ");
		if ((type == MpType.MP_KM && isIveco) || java.lang.Math.abs(delta) < 2)
		{
			singular = "singular";
		}
		else
		{
			singular = "plural";
		}

		String typeStr = type.toString();
		if (type == MpType.MP_KM && !isIveco && !unit.isEmpty())
		{
			typeStr = unit;
		}

		// only in struts environment
		if (null != ResourceLabel.getInstance())
		{
			if (useDaysMessage && type == MpType.MP_MONTH)
			{
				result.append(ResourceLabel.getInstance().getLabel("label.day." + singular, this.locale));
			}
			else
			{
				result.append(ResourceLabel.getInstance().getLabel("label." + typeStr + "." + singular, this.locale));
			}
		}
		else
		{
			if (useDaysMessage && type == MpType.MP_MONTH)
			{
				result.append("label.day." + singular);
			}
			else
			{
				result.append("label." + typeStr + "." + singular);
			}
		}

		return result.toString();
	}

	/**
	 * Set the comment of an interval based on its score (do not overwrite the existing comment).
	 * 
	 * @param pScore the score of the interval
	 */
	private void setComment(MpScoreDto pScore, boolean isIveco, String unit) {
		MpIntervalDto interval = pScore.getInterval();
		StringBuilder comment = null;

		// -- reset interval delta comment
		interval.setDeltaComment(null);

		comment = this.setCommentSelected(pScore, isIveco, unit);

		if (comment.length() > 0 && comment.charAt(comment.length() - 1) == ' ')
		{ // -- remove possible trailing white space
			comment.setLength(comment.length() - 1);
		}
		if (comment.length() > 0)
		{
			interval.setDeltaComment(comment.toString());
		}
	}

	/**
	 * @param aInterval
	 *            the interval
	 * @param aType
	 *            the type to get
	 * @return the after value for the given interval type
	 */
	public static long getEvery(MpIntervalDto aInterval, MpType aType) {
		long value = 0L;
		if (aInterval.getAfterValue(aType) != null)
		{
			value = aInterval.getAfterValue(aType);
		}
		return (value);
	}

	/**
	 * @param aInterval
	 *            the interval
	 * @param aType
	 *            the type to get
	 * @return the start value for the given interval type
	 */
	public static long getAt(MpIntervalDto aInterval, MpType aType) {
		long value = 0L;
		if (aInterval.getStartValue(aType) != null)
		{
			value = aInterval.getStartValue(aType);
		}
		return (value);
	}

	/**
	 * Determine if an interval should be selected based on its score.
	 * An interval is selected if any of its performance is selected.
	 * 
	 * @param pScore score of the interval
	 * @return the select interval flag
	 */
	private boolean selectInterval(MpScoreDto pScore) {
		boolean selected = false; // -- select the interval flag

		for (MpType type : MpType.values())
		{
			if (pScore.getSelectedByType(type) == true)
			{
				selected = true;
			}
		}
		return (selected);
	}

	/**
	 * Find recommended intervals (set the select flag of intervals).
	 * 
	 * @param pListInterval the interval list
	 * @param pListQuestion the interval questions list
	 * @param listNextStopFlexible the next stop for flexible coupons
	 * @param pIntervalIds interval labels
	 */
	public void selectRecommandedIntervals(List<MpIntervalDto> pListInterval, List<MpHistoryIntervalDto> pListQuestion, List<MpNextStopDto> listNextStopFlexible, Map<String, String> pIntervalIds,
			boolean isIveco, String unit) {
		boolean selected = false; // -- select flag for the interval
		// -- Retrieve score list from intervals and history
		List<MpHistoryIntervalDto> questionList = new ArrayList<>(pListQuestion);
		List<MpScoreDto> scoreList = getScore(pListInterval, questionList);

		// -- clear the multiple list which will be used by applyMultiples
		clearMultipleList();

		this.updateDelta(pListInterval);

		// -- for potential interval to be selected
		for (MpScoreDto score : scoreList)
		{
			// -- for each possible type of the interval
			for (MpType type : MpType.values())
			{
				this.selectPerformance(score, type);
			}

			// -- select the interval based on selected performances
			selected = this.selectInterval(score);
			MpIntervalDto interval = score.getInterval();
			interval.setSelected(selected);
			// If selected, status On time otherwise not recommended
			interval.setStatus(interval.isSelected() ? MpIntervalStatusEnum.ON_TIME : MpIntervalStatusEnum.NOT_RECOMMENDED);
			interval.setDeltaComment(null); // -- reset delta comment

			// -- remove multiples from selection
			if (selected == true)
			{
				this.applyMultiples(score);
			}
		}

		// -- clear the multiple list which will be used by applyMultiplesComment
		clearMultipleList();

		//assumption : flexible coupon are not multiple
		if (listNextStopFlexible != null && !listNextStopFlexible.isEmpty())
		{
			// for contract flexible, update theoritical stop with stop from telelmatics
			Collections.sort(listNextStopFlexible, new MpNextFlexComparator());
			String previousCouponCode = null;
			for (MpNextStopDto nextStopFlex : listNextStopFlexible)
			{
				//consider only the smallest between alert from CR and EDS
				if (previousCouponCode == null || !previousCouponCode.equals(nextStopFlex.getIntervalCode()))
				{
					this.selectPerformanceFlexible(nextStopFlex, scoreList);
				}
				previousCouponCode = nextStopFlex.getIntervalCode();
			}
		}

		// -- comment intervals with delta information
		for (MpScoreDto score : scoreList)
		{
			this.setComment(score, isIveco, unit);
		}
		for (MpScoreDto score : scoreList)
		{
			this.applyMultiplesComment(score);
		}

		this.applyNewMultipleRule(scoreList);

		// IAZ Now that all the calculations have been done, set the delta value for the non selected coupons
		for (MpScoreDto score : scoreList)
		{
			if (!score.getInterval().isSelected())
			{
				for (MpType type : MpType.values())
				{
					Long deltaValue = score.getScoreByType(type);
					score.getInterval().getDeltaValue().put(type, deltaValue);
				}
			}
		}
	}

	/****************************************************************************************************************/
	/************************************** GET NEXT STOP ***********************************************************/
	/****************************************************************************************************************/
	/****************************************************************************************************************/

	/**
	 * Calculate the next stop for the contract and save in DB.
	 * 
	 * @param contract : list of all contract contiguous for a VIN
	 * @param vin : VIN
	 * @param contractHeavyFlex : true if flex contract
	 * @param currentVehicleDate : current vehicle data
	 * @param warrantyDate : warrantyDate
	 * @param minNextStop : previous min Next Stop
	 * @return list of next stop recalculated
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public List<MpNextStopDto> calculateNextStopAndSave(MpContractDto contract, String vin, ContractVisibility contractVisibility, CurrentVehicleDataDto currentVehicleDate, String warrantyDate,
			MpNextStopMinDto minNextStop, List<String> lstPinVin, List<MpNextStopByScoreDto> fullListNextStop)
			throws SystemException, ApplicativeException {

		MpNextStopBusiness nextStopBussiness = new MpNextStopBusiness(this.dbAccess);
		MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness(this.dbAccess);
		List<MpNextStopDto> listNextStop = new ArrayList<>();
		Long lastCurrentMileage = null;
		Long lastCurrentHour = null;

		if (contract != null && contract.getActiveMpContract().getPlanId() != null)
		{
			//get list of interval 
			//TODO MML we could skip this request if we set in usersession the list interval when the SAP history is set 
			List<MpIntervalDto> listInterval = mpIntervalBusiness.getMaintenanceIntervalsWithoutOperation(contract.getActiveMpContract().getPlanId(), Constants.ENGLISH,
					Context.getStringProperty("mp.family.code"));
			//get list of history
			int toleranceToMatch = new Integer(Context.getStringProperty("mp.tolerance.tomatch"));
			int toleranceToWait = new Integer(Context.getStringProperty("mp.tolerance.towait"));
			long fistContractTime = contract.getContracts().get(contract.getContracts().size() - 1).getContractStartDate().getTime();

			List<MpHistoryIntervalDto> listHistory = mpIntervalBusiness.readListHistoryIntervalWithContract(lstPinVin, toleranceToMatch, toleranceToWait, fistContractTime,
					flexibleCoupons, contractVisibility.hasComponentFlexible());

			//get flexible coupon
			List<MpNextStopDto> listFlexNextStop = new ArrayList<>();
			MpNextStopMinDto oldMinStop = null;
			if (contractVisibility.hasProposalDateAndAlert())
			{
				if (contractVisibility.hasComponentFlexible())
				{
					//Build the list of flexible next stop (recalculate missing one if needed)
					listFlexNextStop = nextStopBussiness.getAllNextStopFlexibles(vin);
					List<MpHistoryIntervalDto> listFlexNextStopMissing = getMissingFlexibleNextStop(listFlexNextStop, vin);
					List<MpNextStopDto> listFlexNextStopCalculated = calculateNextFlexibleStop(listFlexNextStopMissing, new ArrayList<MpNextStopDto>(), listHistory, listInterval, vin);
					listFlexNextStop.addAll(listFlexNextStopCalculated);

				}

				//Set the min next stop

				if (minNextStop != null && minNextStop.getVin() != null) // if MINSTOP exists
				{
					oldMinStop = new MpNextStopMinDto(minNextStop);

					minNextStop.update(contract.getActiveMpContract().getPlanId(), contract.getActiveMpContract().getContractNumber(), currentVehicleDate);
				}
				else
				{
					minNextStop.setVin(vin);
					minNextStop.setIdPlan(contract.getActiveMpContract().getPlanId());
					minNextStop.setContractNb(contract.getActiveMpContract().getContractNumber());
					if (currentVehicleDate != null)
					{
						minNextStop.setCurrentHour(currentVehicleDate.getCurrentHours());
						minNextStop.setCurrentMileage(currentVehicleDate.getCurrentMileage());
					}

				}
				lastCurrentMileage = minNextStop.getCurrentMileage();
				lastCurrentHour = minNextStop.getCurrentHour();

			}

			//Calculate the warranty start date
			Long warrantyStartDate = getWarrantyDateInTime(warrantyDate);
			//TODO MML put the currentVehicleCaracteristic (to be retrieved from WebService EDS)
			listNextStop = calculateNextStop(listInterval, listHistory, listFlexNextStop, vin, contract.getActiveMpContract().getPlanId(),
					contractVisibility, warrantyStartDate, lastCurrentMileage, lastCurrentHour, fullListNextStop);
			//if possible get the next stop instead of doing again a request
			nextStopBussiness.addNextStop(listNextStop, listFlexNextStop, contractVisibility, currentVehicleDate, warrantyStartDate, minNextStop, oldMinStop, this, lstPinVin);

		}

		return listNextStop;
	}

	public List<MpNextStopDto> calculateNextStopAndSave(MpContractDto contract, String vin, ContractVisibility contractVisibility, CurrentVehicleDataDto currentVehicleDate, String warrantyDate,
			MpNextStopMinDto minNextStop, List<String> lstPinVin)
			throws SystemException, ApplicativeException {

		MpNextStopBusiness nextStopBussiness = new MpNextStopBusiness(this.dbAccess);
		MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness(this.dbAccess);
		List<MpNextStopDto> listNextStop = new ArrayList<>();
		Long lastCurrentMileage = null;
		Long lastCurrentHour = null;

		if (contract != null && contract.getActiveMpContract().getPlanId() != null)
		{
			//get list of interval 
			//TODO MML we could skip this request if we set in usersession the list interval when the SAP history is set 
			List<MpIntervalDto> listInterval = mpIntervalBusiness.getMaintenanceIntervalsWithoutOperation(contract.getActiveMpContract().getPlanId(), Constants.ENGLISH,
					Context.getStringProperty("mp.family.code"));
			//get list of history
			int toleranceToMatch = new Integer(Context.getStringProperty("mp.tolerance.tomatch"));
			int toleranceToWait = new Integer(Context.getStringProperty("mp.tolerance.towait"));
			long fistContractTime = contract.getContracts().get(contract.getContracts().size() - 1).getContractStartDate().getTime();

			List<MpHistoryIntervalDto> listHistory = mpIntervalBusiness.readListHistoryIntervalWithContract(lstPinVin, toleranceToMatch, toleranceToWait, fistContractTime,
					flexibleCoupons, contractVisibility.hasComponentFlexible());

			//get flexible coupon
			List<MpNextStopDto> listFlexNextStop = new ArrayList<>();
			MpNextStopMinDto oldMinStop = null;
			if (contractVisibility.hasProposalDateAndAlert())
			{
				if (contractVisibility.hasComponentFlexible())
				{
					//Build the list of flexible next stop (recalculate missing one if needed)
					listFlexNextStop = nextStopBussiness.getAllNextStopFlexibles(vin);
					List<MpHistoryIntervalDto> listFlexNextStopMissing = getMissingFlexibleNextStop(listFlexNextStop, vin);
					List<MpNextStopDto> listFlexNextStopCalculated = calculateNextFlexibleStop(listFlexNextStopMissing, new ArrayList<MpNextStopDto>(), listHistory, listInterval, vin);
					listFlexNextStop.addAll(listFlexNextStopCalculated);
				}

				//Set the min next stop

				if (minNextStop != null && minNextStop.getVin() != null) // if MINSTOP exists
				{
					oldMinStop = new MpNextStopMinDto(minNextStop);

					minNextStop.update(contract.getActiveMpContract().getPlanId(), contract.getActiveMpContract().getContractNumber(), currentVehicleDate);
				}
				else
				{
					minNextStop.setVin(vin);
					minNextStop.setIdPlan(contract.getActiveMpContract().getPlanId());
					minNextStop.setContractNb(contract.getActiveMpContract().getContractNumber());
					if (currentVehicleDate != null)
					{
						minNextStop.setCurrentHour(currentVehicleDate.getCurrentHours());
						minNextStop.setCurrentMileage(currentVehicleDate.getCurrentMileage());
					}

				}
				lastCurrentMileage = minNextStop.getCurrentMileage();
				lastCurrentHour = minNextStop.getCurrentHour();

			}

			//Calculate the warranty start date
			Long warrantyStartDate = getWarrantyDateInTime(warrantyDate);
			//TODO MML put the currentVehicleCaracteristic (to be retrieved from WebService EDS)
			listNextStop = calculateNextStop(listInterval, listHistory, listFlexNextStop, vin, contract.getActiveMpContract().getPlanId(),
					contractVisibility, warrantyStartDate, lastCurrentMileage, lastCurrentHour);
			//if possible get the next stop instead of doing again a request
			nextStopBussiness.addNextStop(listNextStop, listFlexNextStop, contractVisibility, currentVehicleDate, warrantyStartDate, minNextStop, oldMinStop, this, lstPinVin);
		}

		return listNextStop;
	}

	/**
	 * Get list of missing next stop flexible to calculate.
	 * 
	 * @param listFlexNextStop : list of all contract contiguous for a VIN
	 * @param vin : vin
	 * @return list of missing next stop flexible to calculate
	 */
	public List<MpHistoryIntervalDto> getMissingFlexibleNextStop(List<MpNextStopDto> listFlexNextStop, String vin) {
		List<MpHistoryIntervalDto> listFlexNextStopMissing = new ArrayList<>();
		Iterator<String> index = flexibleCoupons.keySet().iterator();
		while (index.hasNext())
		{
			String flexCoupon = index.next();
			boolean found = false;
			String code = flexibleCoupons.get(flexCoupon).getIntervalCode();
			for (MpNextStopDto nextStopDto : listFlexNextStop)
			{
				if (nextStopDto.getIntervalCode().equals(code) && nextStopDto.getExternal() == 0)
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				listFlexNextStopMissing.add(new MpHistoryIntervalDto(null, null, vin, code, null, null));
			}
		}
		return listFlexNextStopMissing;

	}

	/**
	 * Get warranty start date in number of ms from the 01-01-1970 .
	 * 
	 * @param warrantyStartDate wararnty start date (get from contract or from history saved on etIM)
	 * 
	 * @return the warranty start date in ms
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public Long getWarrantyDateInTime(String warrantyStartDate) {
		Long result = null;
		if (warrantyStartDate != null)
		{
			try
			{
				DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				result = format.parse(warrantyStartDate).getTime();
			}
			catch (ParseException e)
			{
				try// -- [dbabillo][TODO][MPI] very bad coding
				{
					DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					result = format.parse(warrantyStartDate).getTime();
				}
				catch (ParseException e1)
				{
					try
					{
						result = new Date(Long.parseLong(warrantyStartDate)).getTime();
					}
					catch (NumberFormatException e2)
					{
						e.printStackTrace();
						e2.printStackTrace();
					}
				}
			}
		}
		return result;
	}

	/**
	 * calculate Delta For Manual Selected Coupon .
	 * 
	 * @param listHistory : listHistory
	 * @param listFlexNextStop : listFlexNextStop
	 * @param isHeavyFlexContract : isHeavyFlexContract
	 * @param mpIntervalOp : mpIntervalOp
	 * @param currentHour : currentHour
	 * @param currentKm : currentKm
	 */
	public void calculateDeltaForManualSelectedCoupon(List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop,
			boolean isHeavyFlexContract, List<MpIntervalOperationDto> mpIntervalOp, Long currentHour, Long currentKm) {
		//
		//		List<MpIntervalDto> couponSelectedByUser = new ArrayList<>();
		//		for (MpIntervalOperationDto op : mpIntervalOp)
		//		{
		//			if (op.getSelectionType().equals("A"))
		//			{
		//				couponSelectedByUser.add(op);
		//			}
		//		}
		//		List<MpNextStopByScoreDto> scoreList = getNextStop(couponSelectedByUser, listHistory, listFlexNextStop, isHeavyFlexContract);
		//		for (MpNextStopByScoreDto mpNextStop : scoreList)
		//		{
		//			for (MpIntervalDto op : couponSelectedByUser)
		//			{
		//				if (op.getCode().equals(mpNextStop.getInterval().getCode()))
		//				{
		//					Long afterHoursValue = mpNextStop.getInterval().getAfterValue(MpType.MP_HOUR);
		//					Long afterMonthValue = mpNextStop.getInterval().getAfterValue(MpType.MP_MONTH);
		//					Long afterKMValue = mpNextStop.getInterval().getAfterValue(MpType.MP_KM);
		//					Long atHoursValue = mpNextStop.getInterval().getStartValue(MpType.MP_HOUR);
		//					Long atMonthValue = mpNextStop.getInterval().getStartValue(MpType.MP_MONTH);
		//					Long atKMValue = mpNextStop.getInterval().getStartValue(MpType.MP_KM);
		//					if ((afterHoursValue != 0 && afterHoursValue != null) || (atHoursValue != 0 && atHoursValue != null))
		//					{
		//						if (mpNextStop.getNextStopByType(MpType.MP_HOUR) == null || mpNextStop.getNextStopByType(MpType.MP_HOUR).equals(0L))
		//						{
		//							op.getDeltaValue().put(MpType.MP_HOUR, 0L);
		//						}
		//						else
		//						{
		//							op.getDeltaValue().put(MpType.MP_HOUR, mpNextStop.getNextStopByType(MpType.MP_HOUR) - currentHour);
		//						}
		//
		//					}
		//					if ((afterKMValue != 0 && afterKMValue != null) || (atKMValue != 0 && atKMValue != null))
		//					{
		//						if (mpNextStop.getNextStopByType(MpType.MP_KM) == null || mpNextStop.getNextStopByType(MpType.MP_KM).equals(0L))
		//						{
		//							op.getDeltaValue().put(MpType.MP_KM, 0L);
		//						}
		//						else
		//						{
		//							op.getDeltaValue().put(MpType.MP_KM, mpNextStop.getNextStopByType(MpType.MP_KM) - currentKm);
		//						}
		//					}
		//					if ((afterMonthValue != 0 && afterMonthValue != null) || (atMonthValue != 0 && atMonthValue != null))
		//					{
		//						if (mpNextStop.getNextStopByType(MpType.MP_MONTH) == null || mpNextStop.getNextStopByType(MpType.MP_MONTH).equals(0L))
		//						{
		//							op.getDeltaValue().put(MpType.MP_MONTH, 0L);
		//						}
		//						else
		//						{
		//							Long nbMonth = mpNextStop.getNextStopByType(MpType.MP_MONTH) - getElapsedMonth(Long.toString(warranty), Long.toString((new Date().getTime())));
		//							if (nbMonth.compareTo(0L) > 0)
		//							{
		//								op.getDeltaValue().put(MpType.MP_MONTH, nbMonth);
		//							}
		//							else
		//							{
		//								op.getDeltaValue().put(MpType.MP_MONTH, 0L);
		//							}
		//						}
		//					}
		//				}
		//			}
		//		}
	}

	/**
	 * Calculate proposal date.
	 * 
	 * @param warrantyStartDate : warranty Start Date
	 * @param currentVehicleData : current vehicle data
	 * @param nextStopDto : next Stop Dto
	 * @param oldMinNextStop : old min next stop initialized : if value are not changed and the current mileage/ last current hour is missing data are not recalculated
	 */
	public void calculateProposalDate(CurrentVehicleDataDto currentVehicleData, MpNextStopMinDto nextStopDto, Long warrantyStartDate, MpNextStopMinDto oldMinNextStop) {
		// if we are not able to recalculate the min proposal date, we keep the previous one
		Date proposalDate;

		Long value = null;
		Long currentValue = null;
		Double averageValue = null;
		boolean keepOldValue = false;

		for (MpType type : MpType.values())
		{
			keepOldValue = false;
			if (type.equals(MpType.MP_MONTH))
			{
				value = nextStopDto.getNextValue(MpType.MP_MONTH);
				if (value != null && warrantyStartDate != null)
				{
					proposalDate = UtilDate.addMonth(warrantyStartDate, value.intValue());
					nextStopDto.setMinProposalDate(MpType.MP_MONTH, proposalDate);
				}

			}
			else
			{
				if (currentVehicleData != null)
				{
					if (type.equals(MpType.MP_KM))
					{
						currentValue = currentVehicleData.getCurrentMileage();
						averageValue = currentVehicleData.getAverageMileage();
					}
					else if (type.equals(MpType.MP_HOUR))
					{
						currentValue = currentVehicleData.getCurrentHours();
						averageValue = currentVehicleData.getAverageHours();
					}
				}
				value = nextStopDto.getNextValue(type);
				if (value != null && !(Constants.DEFAULT_VALUE_NEXT_STOP).equals(value))
				{
					//if the averageValue is too small : ex 0,04 the number of year is on 5 digits
					if (currentValue != null && averageValue != null && averageValue >= 1)
					{
						proposalDate = UtilDate.addDay(new Date(), (int) (Math.round((value - currentValue) / averageValue)));
						nextStopDto.setMinProposalDate(type, proposalDate);
					}
					else if (oldMinNextStop != null)
					{
						keepOldValue = true;

					}
				}
			}
			if (keepOldValue == true)
			{
				//if data not changed and no new current value (mileage/hour) : no update
				Long oldValue = oldMinNextStop.getNextValue(type);
				if (value.equals(oldValue))
				{
					nextStopDto.setMinProposalDate(type, oldMinNextStop.getMinProposalDate(type));
				}
			}
		}
	}

	/**
	 * Calculate alert.
	 * 
	 * @param nextStopDto : next Stop Dto
	 */
	public void calculateAlert(MpNextStopMinDto nextStopDto) {
		Long lastCurrentValue = null;

		for (MpType type : MpType.values())
		{
			if (type.equals(MpType.MP_MONTH))
			{
				Date value = nextStopDto.getMinProposalDate(MpType.MP_MONTH);
				if (value != null)
				{
					if (value != null && UtilDate.compareDate(value, null, -far.get(MpType.MP_MONTH).intValue(), true) <= 0)
					{
						nextStopDto.setAlert(MpType.MP_MONTH, 1);
					}
					else
					{
						nextStopDto.setAlert(MpType.MP_MONTH, 0);
					}
				}
			}
			else
			{
				// the last current value if the actual value of the vehicle or the previous one used for the calculation of the min if the actual value is not received from EDS
				if (type.equals(MpType.MP_KM))
				{
					lastCurrentValue = nextStopDto.getCurrentMileage();
				}
				else if (type.equals(MpType.MP_HOUR))
				{
					lastCurrentValue = nextStopDto.getCurrentHour();
				}
				Long value = nextStopDto.getNextValue(type);
				if (value != null && (Constants.DEFAULT_VALUE_NEXT_STOP).equals(value))
				{
					nextStopDto.setAlert(type, 1);
				}
				else if (lastCurrentValue != null && value != null)
				{
					if (value - lastCurrentValue <= far.get(type))
					{
						nextStopDto.setAlert(type, 1);
					}
					else
					{
						nextStopDto.setAlert(type, 0);
					}
				}
			}
		}

	}

	/**
	 * Voodoo stuff to get translated interval title token.
	 * 
	 * @param intervalsId the intervals ids
	 * @return the list
	 * @throws SystemException system exception
	 * @throws ApplicativeException applicative exception
	 */
	private static List<String> getElementList(HashMap<String, String> intervalsId, String unitKey) throws SystemException, ApplicativeException {
		// Get the list of intervals id defined in the web_param table
		List<String> listValue = new ArrayList<>();

		HashMap<String, WebParamDto> listParam = (new WebParamBusiness()).getWebParams();

		WebParamDto webParamDto = listParam.get(Constants.MP_ID_AND_THEN);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(Constants.MP_ID_AT);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(Constants.MP_ID_EVERY);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(Constants.MP_ID_HOURS);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(Constants.MP_ID_MONTHS);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(Constants.MP_ID_OR);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}
		webParamDto = listParam.get(unitKey);
		if (webParamDto != null)
		{
			intervalsId.put(webParamDto.getWeb_value(), webParamDto.getWeb_id());
			listValue.add(webParamDto.getWeb_value());
		}

		return listValue;
	}

	/**
	 * Get List of interval element.
	 * 
	 * @param pMap
	 *            Session data
	 * @param dtoIceContext
	 *            dto IceContext
	 * 
	 * @return intervals id
	 * 
	 * @throws SystemException
	 *             System Exception
	 * @throws ApplicativeException
	 *             Applicative Exception
	 */
	public static HashMap<String, String> setIntervalElementList(HashMap<String, HashMap<String, String>> pMap, IceContextDto dtoIceContext, String unitKey)
			throws SystemException, ApplicativeException {
		boolean isDefaultLoaded = false;
		HashMap<String, String> intervalElements = pMap.get(dtoIceContext.getLanguage().getIdlanguage());
		if (intervalElements == null)
		{
			HashMap<String, String> intervalsId = new HashMap<>();
			List<String> listValue = getElementList(intervalsId, unitKey);

			List<TableTitleDto> list = (new TableTitleBusiness()).getListTableTitle(listValue, dtoIceContext.getLanguage().getIdlanguage());
			String defaultLanguage = dtoIceContext.getDefaultLanguage();
			if (defaultLanguage == null)
			{
				defaultLanguage = Constants.ENGLISH;
			}
			// if id are not translated, there are retrieved in english
			if ((list.isEmpty() || list.size() != listValue.size()) && !dtoIceContext.getLanguage().getIdlanguage().equals(defaultLanguage))
			{
				intervalElements = pMap.get(defaultLanguage);
				if (intervalElements == null)
				{
					list = (new TableTitleBusiness()).getListTableTitle(listValue, defaultLanguage);
					isDefaultLoaded = true;
				}
			}
			if (intervalElements == null)
			{
				intervalElements = new HashMap<>();
				for (TableTitleDto elt : list)
				{
					String ref = intervalsId.get(elt.getIdRefTableTitle());
					intervalElements.put(ref, elt.getMessage());
				}
				pMap.put(dtoIceContext.getLanguage().getIdlanguage(), intervalElements);
				if (isDefaultLoaded)
				{
					pMap.put(defaultLanguage, intervalElements);
				}
			}
			else
			{
				pMap.put(dtoIceContext.getLanguage().getIdlanguage(), intervalElements);
			}
		}
		return (intervalElements);
	}

	/**
	 * Get List of interval element.
	 * 
	 * @param pMap
	 *            Session data
	 * @param dtoIceContext
	 *            dto IceContext
	 * @param language a given language
	 * @return intervals id
	 * 
	 * @throws SystemException
	 *             System Exception
	 * @throws ApplicativeException
	 *             Applicative Exception
	 */
	public static HashMap<String, String> setIntervalElementList(HashMap<String, HashMap<String, String>> pMap, String defaultLanguage, String language, String unitKey)
			throws SystemException, ApplicativeException {
		boolean isDefaultLoaded = false;
		HashMap<String, String> intervalElements = pMap.get(language);

		if (intervalElements == null)
		{
			HashMap<String, String> intervalsId = new HashMap<>();
			List<String> listValue = getElementList(intervalsId, unitKey);

			List<TableTitleDto> list = (new TableTitleBusiness()).getListTableTitle(listValue, language);

			if (defaultLanguage == null)
			{
				defaultLanguage = Constants.ENGLISH;
			}
			// if id are not translated, there are retrieved in english
			if ((list.isEmpty() || list.size() != listValue.size()) && !language.equals(defaultLanguage))
			{
				intervalElements = pMap.get(defaultLanguage);
				if (intervalElements == null)
				{
					list = (new TableTitleBusiness()).getListTableTitle(listValue, defaultLanguage);
					isDefaultLoaded = true;
				}
			}
			if (intervalElements == null)
			{
				intervalElements = new HashMap<>();
				for (TableTitleDto elt : list)
				{
					String ref = intervalsId.get(elt.getIdRefTableTitle());
					intervalElements.put(ref, elt.getMessage());
				}
				pMap.put(language, intervalElements);
				if (isDefaultLoaded)
				{
					pMap.put(defaultLanguage, intervalElements);
				}
			}
			else
			{
				pMap.put(language, intervalElements);
			}
		}
		return (intervalElements);
	}

	/**
	 * Get the question for an interval if any.
	 * 
	 * @param interval interval to get the question from
	 * @param vin the V.I.N.
	 * @param externalPLanId the external PLan Id
	 * 
	 * @return null if no question shall be asked the question i otherwise
	 */
	private MpHistoryIntervalDto getQuestion(MpIntervalDto interval, List<String> lstPinVin, Long externalPLanId) {
		boolean hasValue = false;
		MpHistoryIntervalDto question = new MpHistoryIntervalDto(null, interval.getId(), lstPinVin, interval.getCode(), externalPLanId, null);

		// -- for each type if we are in the delta
		for (MpType type : MpType.values())
		{
			Long at = MaintenancePlanBusiness.getAt(interval, type);
			Long every = MaintenancePlanBusiness.getEvery(interval, type);
			Long actual = this.actual.get(type);
			if (actual.compareTo(0L) > 0)
			{
				// -- valid actual value
				if (at.compareTo(0L) > 0 || every.compareTo(0L) > 0)
				{
					question.addToExactValue(type, 0L);
				}
				if (at.compareTo(0L) <= 0)
				{
					if (every.compareTo(0L) > 0 && every.longValue() - actual.longValue() < 0L)
					{
						// -- ask if below every and no at
						hasValue = true;
					}
				}
				else if (at.longValue() - actual.longValue() < 0L)
				{
					// -- ask if below at
					hasValue = true;
				}
				// -- else do not ask the question
			}
			// -- else the actual value is not valid ignore performance
		}
		if (hasValue != true)
		{
			question = null;
		}
		return (question);
	}

	/**
	 * Return the necessary questions to ask the user to be able to auto select needed interval.
	 * 
	 * @param vin the V.I.N.
	 * @param pListHistory the known history
	 * @param pListIntervals the intervals
	 * @param externalPlanId external Plan Id
	 * @return the list of questions.
	 */
	public List<MpHistoryIntervalDto> getNewQuestionList(List<String> lstPinVin, List<MpHistoryIntervalDto> pListHistory, List<MpIntervalDto> pListIntervals, Long externalPlanId,
			boolean isFlexHeavy) {
		List<MpHistoryIntervalDto> listQuestion = new ArrayList<>();
		boolean hasHistory = false;

		// -- for each interval
		for (MpIntervalDto interval : pListIntervals)
		{
			if (!isFlexHeavy || !flexibleCoupons.containsKey(interval.getCode())) //flexible coupon cannot be modified
			{
				// -- if an history exist for the interval ask confirmation.
				hasHistory = false;

				for (MpHistoryIntervalDto history : pListHistory)
				{
					// in the history only the interval corresponding to the current external plan id is taken into account
					if (history.getIntervalCode().equals(interval.getCode()))
					{
						hasHistory = true;
						break;
					}
				}
				// -- no history exist for the interval ask if within delta
				if (!hasHistory)
				{
					MpHistoryIntervalDto question = this.getQuestion(interval, lstPinVin, externalPlanId);
					if (question != null)
					{
						listQuestion.add(question);
					}
				}
			}
		}
		return listQuestion;
	}

	/**
	 * Return the relevant history questions to ask the user for confirmation.
	 * 
	 * @param pListHistory the known history
	 * @param pListIntervals the intervals
	 * @return the list of questions.
	 */
	public List<MpHistoryIntervalDto> getHistoryQuestionList(List<MpHistoryIntervalDto> pListHistory, List<MpIntervalDto> pListIntervals) {
		List<MpHistoryIntervalDto> listQuestion = new ArrayList<>();

		// -- for each interval
		for (MpIntervalDto interval : pListIntervals)
		{
			for (MpHistoryIntervalDto history : pListHistory) // -- for each history
			{
				//MML: in the history only the interval corresponding to the current external plan id is taken into account
				if (history.getIntervalCode().equals(interval.getCode()) == true) // history is in the interval list
				{
					history.setIntervalCode(interval.getCode());
					// MML the interval id is erased with the new one to eventually update the database (management of Project New Version)
					history.setIntervalId(interval.getId());
					// -- prevent non relevant type from showing up in form
					for (MpType type : MpType.values())
					{
						if (history.retreiveFromExactValueByMpType(type).equals(0L) == true)
						{
							history.addToExactValue(type, null);
						}
					}
					listQuestion.add(history);
					break;
				}
			}
		}
		return listQuestion;
	}

	/**
	 * Check that for the current user input actual value, no history beyond the actual exist.
	 * In such case history is move to new question list for correction.
	 * 
	 * @param historyList history list
	 * @param questionList question list
	 * @return true if the input actual value is lower than history, false otherwise
	 */
	public boolean getValidActual(List<MpHistoryIntervalDto> historyList, List<MpHistoryIntervalDto> questionList, List<MpIntervalDto> listInterval) {
		boolean valid = true;
		boolean tmpValid = true;

		// -- for each interval
		Iterator<MpHistoryIntervalDto> it = historyList.iterator();
		while (it.hasNext())
		{
			tmpValid = true;
			MpHistoryIntervalDto history = it.next();
			for (MpType type : MpType.values())
			{
				// -- if it exist an history after the actual value (which is non-sens)
				if (this.actual.get(type) != null && history.retreiveFromExactValueByMpType(type) != null)
				{
					if (type == MpType.MP_MONTH)
					{
						if (this.warranty > 0 && history.retreiveFromExactValueByMpType(type).compareTo(0L) > 0)
						{
							double delta = ((double) (this.warranty - history.retreiveFromExactValueByMpType(type).longValue())) / (1000 * 24 * 60 * 60); // -- compare on day basis not full UTC
							Long month = getElapsedMonth(Long.toString(this.warranty), history.retreiveFromExactValueByMpType(type).toString());
							if (delta >= 1 || (this.actual.get(type).compareTo(0L) > 0 && month.compareTo(this.actual.get(type)) > 0)) // -- date before warranty start date or in future (after today)
							{
								valid = false;
								tmpValid = false;
								questionList.add(history); // -- add to question list
								it.remove(); // -- remove from history list
								break;
							}
						}
					}
					else if (this.actual.get(type).compareTo(0L) > 0 && this.actual.get(type).compareTo(history.retreiveFromExactValueByMpType(type)) < 0) // -- performance in future
					{
						valid = false;
						tmpValid = false;
						questionList.add(history); // -- add to question list
						it.remove(); // -- remove from history list
						break;
					}
					if (tmpValid && (type == MpType.MP_MONTH || type == MpType.MP_KM))
					{
						tmpValid = true;
					}
					else
					{
						tmpValid = false;
					}
				}
			}
			// if interval has hour and the history is not filled it means that the question needs to be asked : case for contract because SAP doesn't manage hour
			if (tmpValid && this.actual.get(MpType.MP_HOUR) != null && this.actual.get(MpType.MP_HOUR).compareTo(0L) > 0
					&& (history.retreiveFromExactValueByMpType(MpType.MP_HOUR) == null || history.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(0L) == 0))
			{
				MpIntervalDto intervalFound = null;
				for (MpIntervalDto interval : listInterval)
				{
					if (history.getIntervalCode().equals(interval.getCode()))
					{
						intervalFound = interval;
						break;
					}
				}
				if (intervalFound != null && (intervalFound.getAfterValueHour() != null || intervalFound.getStartValueHour() != null))
				{
					valid = false;
					questionList.add(history); // -- add to question list
					it.remove(); // -- remove from history list
				}
			}
		}
		return valid;
	}

	/**
	 * Update the interval value for the history for computation.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * <p>
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM.
	 * At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * </p>
	 * 
	 * @param history interval history
	 * @param pListIntervals list of all the intervals of the plan
	 * @param questionHistory list of initial question
	 * @param heavyFlexContract : heavy Flex Contract
	 */
	public void setInterval(MpHistoryIntervalDto history, List<MpIntervalDto> pListIntervals, List<MpHistoryIntervalDto> questionHistory, boolean heavyFlexContract) {
		this.updateDelta(pListIntervals); // -- update delta value based on M1 if exists
		for (MpIntervalDto interval : pListIntervals)
		{
			//MML: in the history only the interval corresponding to the current external plan id is taken into account
			if (interval.getCode().equals(history.getIntervalCode()))
			{
				for (MpType type : MpType.values())
				{
					Long intValue = null;
					long historyValue = history.retreiveFromExactValueByMpType(type) != null ? history.retreiveFromExactValueByMpType(type).longValue() : 0L;
					// MML month value is always filled (from contract integration)
					//, so we manage the int history only if month exists in the interval definition
					if (type == MpType.MP_MONTH && (interval.getAfterMath(type) > 0 || interval.getStartMath(type) > 0)) // -- convert date to elapsed months
					{
						historyValue = getElapsedMonth(Long.toString(this.warranty), Long.toString(history.retreiveFromExactValueByMpType(type)));
					}
					else if (type == MpType.MP_MONTH)
					{
						historyValue = 0L;
					}
					if (history.getIntValue(type).compareTo(0L) <= 0) // -- first time we enter history
					{
						intValue = historyValue; // for flex value is not realigned
						if (!heavyFlexContract)
						{
							intValue = this.getInterval(historyValue, interval.getAfterMath(type), interval.getStartMath(type), this.far.get(type)); // -- estimate from interval value
						}
					}
					else // -- intValue already exist we must update it
					{
						for (MpHistoryIntervalDto question : questionHistory)
						{ // -- look for changed value
							//MML: in the history only the interval corresponding to the current external plan id is taken into account
							if (question.getIntervalCode().equals(history.getIntervalCode()))
							{
								if (history.retreiveFromExactValueByMpType(type).compareTo(question.retreiveFromExactValueByMpType(type)) != 0)
								{ // -- value has changed
									intValue = historyValue; // for flex value is not realigned
									if (!heavyFlexContract)
									{
										intValue = this.getInterval(historyValue, interval.getAfterMath(type), interval.getStartMath(type), this.far.get(type)); // -- recompute from scratch
									}
								}
								else
								{ // -- else no change nothing to do
									intValue = question.getIntValue(type); // -- keep old value
								}
								break;
							}
						}
					}
					history.setIntValue(type, intValue);
				}
			}
		}
	}

	/**
	 * set the history value int from sap broker history without realignment.
	 * 
	 * @param sapHistoryDto : sap History Dto
	 */
	public void setHistoryIntValue(MpHistoryIntervalDto sapHistoryDto) {

		if (sapHistoryDto.retreiveFromExactValueByMpType(MpType.MP_KM) != null)
		{
			sapHistoryDto.setIntValue(MpType.MP_KM, sapHistoryDto.retreiveFromExactValueByMpType(MpType.MP_KM));
		}
		sapHistoryDto.addToExactValue(MpType.MP_HOUR, Long.valueOf(0L));
		if (sapHistoryDto.retreiveFromExactValueByMpType(MpType.MP_MONTH) != null)
		{
			Long nbMonth = getElapsedMonth(Long.toString(this.warranty), Long.toString(sapHistoryDto.retreiveFromExactValueByMpType(MpType.MP_MONTH)));
			sapHistoryDto.setIntValue(MpType.MP_MONTH, nbMonth);
		}
	}

	/**
	 * Generate the list of history for performed maintenance.
	 * Compute the interval value for the history.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM. At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * 
	 * @param vin the vin
	 * @param pListIntervals the interval list
	 * @param pNowDate user date UTC epoch
	 * @param listHistory history list before doing maintenance
	 * @return the list of interval history
	 */
	public List<MpHistoryIntervalDto> getIntervalHistory(String vin, List<MpIntervalDto> pListIntervals, String pNowDate, List<MpHistoryIntervalDto> listHistory, Long planExtId, boolean isHeavyFlex) {
		List<MpHistoryIntervalDto> historyList = new ArrayList<>();
		MpHistoryIntervalDto history = null;
		MpHistoryIntervalDto oldHistory = null;
		long actual = 0;

		for (MpIntervalDto interval : pListIntervals)
		{
			oldHistory = null;
			if (interval.isSelected() == true) // -- save only selected
			{
				history = new MpHistoryIntervalDto(null, interval.getId(), vin, interval.getCode(), planExtId, null); // -- id will be set on insert

				for (MpHistoryIntervalDto old : listHistory)
				{
					//MML: in the history only the interval corresponding to the current external plan id is taken into account
					if (old.getIntervalCode().equals(interval.getCode()))
					{
						oldHistory = old;
						break;
					}
				}

				for (MpType type : MpType.values())
				{
					if ((interval.getAfterMath(type) > 0 || interval.getStartMath(type) > 0) && type != MpType.MP_MONTH)
					{
						actual = this.actual.get(type).longValue(); // -- get actual value for given type
						history.addToExactValue(type, Long.valueOf(actual)); // -- set history to actual
						if (!isHeavyFlex)
						{
							history.setIntValue(type, Long.valueOf(this.getIntValueHistory(type, actual, oldHistory, interval)));
						}
						else
						{
							history.setIntValue(type, actual);
						}
					}
					else
					{
						history.addToExactValue(type, Long.valueOf(0L));
						history.setIntValue(type, Long.valueOf(0L));
					}
				}
				try
				{
					actual = Long.parseLong(pNowDate);
					history.addToExactValue(MpType.MP_MONTH, Long.valueOf(actual));
					// No calculation of int value if the interval doesnot have month in the interval definition
					if (interval.getStartMath(MpType.MP_MONTH) > 0 || interval.getAfterMath(MpType.MP_MONTH) > 0)
					{
						actual = getElapsedMonth(Long.toString(this.warranty), pNowDate).longValue();
						if (!isHeavyFlex)
						{
							history.setIntValue(MpType.MP_MONTH, Long.valueOf(this.getIntValueHistory(MpType.MP_MONTH, actual, oldHistory, interval)));
						}
						else
						{
							history.setIntValue(MpType.MP_MONTH, actual);
						}
					}
				}
				catch (NumberFormatException | NullPointerException e)
				{
					history.addToExactValue(MpType.MP_MONTH, 0L);
				}
				historyList.add(history);
			}
		}
		return historyList;
	}

	/**
	 * Build an history interval list from 2 lists: first one, add everything and 2nd one, add element not in first one.
	 * 
	 * @param historyList first interval history
	 * @param fullHistoryList second interval history
	 * @return merged list
	 */
	public List<MpHistoryIntervalDto> mergedHistoryList(List<MpHistoryIntervalDto> historyList, List<MpHistoryIntervalDto> fullHistoryList) {
		List<MpHistoryIntervalDto> result = new ArrayList<>();
		result.addAll(historyList);
		boolean found = false;
		for (MpHistoryIntervalDto tobeAdded : fullHistoryList)
		{
			for (MpHistoryIntervalDto existing : historyList)
			{
				if (tobeAdded.getIntervalCode().equals(existing.getIntervalCode()))
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				result.add(tobeAdded);
			}
			found = false;
		}
		return result;
	}

	/**
	 * Retrieve the warranty start date (first in contract, if not in SAP broker.
	 * 
	 * @param vechicleDto : retrieved from SAP broker
	 * @param contract : object contract
	 * @return the warranty start date
	 */
	public String getWarrantyStartDate(ResponseData vechicleDto, String vin, MpContractDto contract, boolean isIveco) {
		String warrantyDate = null;
		if (contract != null)
		{
			if (contract.getWarrantyStartDate() != null)
			{
				warrantyDate = contract.getWarrantyStartDate();
			}
			else if (vechicleDto != null)
			{
				List<VehicleDataDto> listVehicle = vechicleDto.getVehicleData();

				if (listVehicle.size() > 0)
				{
					warrantyDate = listVehicle.get(0).getWtyStart();
				}
			}
			else if (vechicleDto == null && vin != null)
			{
				String subflowName = null;
				if (isIveco)
				{
					subflowName = Context.getStringProperty("cms.subflow.name.iveco");
				}
				else
				{
					subflowName = Context.getStringProperty("cms.subflow.name.na");
				}
				//get the vehicledata object in database
				SAPParameters sapParameters = new SAPParameters(vin, "EN", subflowName);
				sapParameters.setVehicle(1);
				ResponseData response = SAPBroker.getCache(sapParameters);
				List<VehicleDataDto> vehicleDataDtoList = response.getVehicleData();

				if (!isIveco && vehicleDataDtoList.size() == 0)
				{
					subflowName = Context.getStringProperty("cms.subflow.name.eu");
					sapParameters = new SAPParameters(vin, "EN", subflowName);
					sapParameters.setVehicle(1);
					response = SAPBroker.getCache(sapParameters);
					vehicleDataDtoList = response.getVehicleData();
				}

				if (vehicleDataDtoList != null && vehicleDataDtoList.size() > 0)
				{
					warrantyDate = vehicleDataDtoList.get(0).getWtyStart();
				}
			}
		}
		return warrantyDate;
	}

	/**
	 * Get the coupons in alert.
	 * 
	 * @param couponFromExternal the coupon coming from the external system with the routine alert.
	 * @param listCouponDto the coupons to check
	 * @param currentVehicleDataDto vehicle data from EDS
	 * @param mpContractVehicleDto MP contract data
	 * @param contract the contract
	 * @return the coupons in alert or not
	 */
	public List<MpNextStopAlertDto> getCouponInAlert(String couponFromExternal, List<MpNextStopDto> listCouponDto, MpContractVehicleDto mpContractVehicleDto,
			CurrentVehicleDataDto currentVehicleDataDto) {
		List<MpNextStopAlertDto> couponsInAlert = new ArrayList<>();
		MpNextStopAlertDto couponAlert = null;

		for (MpNextStopDto coupon : listCouponDto)
		{
			// coupon from external
			if (coupon.getIntervalCode().equals(couponFromExternal))
			{
				couponAlert = new MpNextStopAlertDto();
				couponAlert.setVin(coupon.getVin());
				couponAlert.setIntervalCode(coupon.getIntervalCode());
				if (null != coupon.getNextValue(MpType.MP_MONTH))
				{
					couponAlert.setNextValue(MpType.MP_MONTH, coupon.getNextValue(MpType.MP_MONTH));
				}
				if (null != coupon.getNextValue(MpType.MP_HOUR))
				{
					couponAlert.setNextValue(MpType.MP_HOUR, coupon.getNextValue(MpType.MP_HOUR));
				}
				if (null != coupon.getNextValue(MpType.MP_KM))
				{
					couponAlert.setNextValue(MpType.MP_KM, coupon.getNextValue(MpType.MP_KM));
				}
				if (null != coupon.getProposalDate(MpType.MP_MONTH))
				{
					couponAlert.setProposalDate(MpType.MP_MONTH, coupon.getProposalDate(MpType.MP_MONTH));
				}
				couponAlert.setDealerCode(mpContractVehicleDto.getDealerCode());
				couponAlert.setExternal(1);
				couponAlert.setBrandIceCode(mpContractVehicleDto.getBrandIceCode());
				couponsInAlert.add(couponAlert);
			}
			// others coupons
			// they can be also external but we process them as if they were internal because we suppose that a notification is already sent
			else
			{
				MpNextStopDto couponCopied = new MpNextStopDto(coupon);
				if (isCouponInAlert(couponCopied, currentVehicleDataDto) && (null == couponCopied.getExternal() || (null != couponCopied.getExternal() && couponCopied.getExternal().intValue() != 1)))
				{
					couponAlert = new MpNextStopAlertDto();
					couponAlert.setVin(couponCopied.getVin());
					couponAlert.setIntervalCode(couponCopied.getIntervalCode());
					if (null != couponCopied.getNextValue(MpType.MP_MONTH))
					{
						couponAlert.setNextValue(MpType.MP_MONTH, couponCopied.getNextValue(MpType.MP_MONTH));
					}
					if (null != couponCopied.getNextValue(MpType.MP_HOUR))
					{
						couponAlert.setNextValue(MpType.MP_HOUR, couponCopied.getNextValue(MpType.MP_HOUR));
					}
					if (null != couponCopied.getNextValue(MpType.MP_KM))
					{
						couponAlert.setNextValue(MpType.MP_KM, couponCopied.getNextValue(MpType.MP_KM));
					}
					if (null != couponCopied.getProposalDate(MpType.MP_MONTH))
					{
						couponAlert.setProposalDate(MpType.MP_MONTH, couponCopied.getProposalDate(MpType.MP_MONTH));
					}
					couponAlert.setDealerCode(mpContractVehicleDto.getDealerCode());
					couponAlert.setExternal(0);
					couponAlert.setBrandIceCode(mpContractVehicleDto.getBrandIceCode());
					couponsInAlert.add(couponAlert);
				}
			}
		}

		return couponsInAlert;
	}

	/**
	 * Test if the coupon is in alert for at least one MP type and update the values to null if no alert for the MP type.
	 * 
	 * @param couponDto : coupon parameter in and out with the values updated if no amert on the MP type
	 * @param currentVehicleDataDto the vehicle data coming from EDS
	 * 
	 * @return true if in alert
	 */
	private boolean isCouponInAlert(MpNextStopDto couponDto, CurrentVehicleDataDto currentVehicleDataDto) {
		boolean inAlert = false;
		Long lastCurrentValue = null;

		for (MpType type : MpType.values())
		{
			if (type.equals(MpType.MP_MONTH))
			{
				Date value = couponDto.getProposalDate(MpType.MP_MONTH);
				if (value != null)
				{
					if (value != null && UtilDate.compareDate(value, null, -far.get(MpType.MP_MONTH).intValue(), true) <= 0)
					{
						inAlert = true;
					}
					else
					{
						couponDto.setProposalDate(MpType.MP_MONTH, null);
						couponDto.setNextValue(MpType.MP_MONTH, null);
					}
				}
			}
			else
			{
				if (type.equals(MpType.MP_KM))
				{
					if (null != currentVehicleDataDto)
					{
						lastCurrentValue = currentVehicleDataDto.getCurrentMileage();
					}
				}
				else if (type.equals(MpType.MP_HOUR))
				{
					if (null != currentVehicleDataDto)
					{
						lastCurrentValue = currentVehicleDataDto.getCurrentHours();
					}
				}
				Long value = couponDto.getNextValue(type);
				if (lastCurrentValue != null && value != null && !value.equals(0L))
				{
					if (value - lastCurrentValue <= far.get(type))
					{
						inAlert = true;
					}
					else
					{
						if (type.equals(MpType.MP_KM))
						{
							couponDto.setNextValue(MpType.MP_KM, null);
						}
						else if (type.equals(MpType.MP_HOUR))
						{
							couponDto.setNextValue(MpType.MP_HOUR, null);
						}
					}
				}
			}
		}

		return inAlert;
	}

	/**
	 * Get the Tolerance in the DB :
	 * - For IVECO : defaults values in the MP_TOLERANCE table in the DB
	 * - For AG&CE : values in the MP_TOLERANCE table in the DB according to the brand and the market,
	 * the technical KM tolerance (delta) and the commercial KM tolerance (far) according to the Unit in MP_UNIT_SERIES table
	 * 
	 * @param context the IceContextDto
	 */
	private MpToleranceDto getTolerance(IceContextDto context) {

		MpToleranceDto mpToleranceDto = new MpToleranceBusiness().getToleranceByBrandAndMarket(context);

		// 1 - Technical and Commercial KM Tolerance
		if (context != null && !this.customer.equals(Constants.CUSTOMER_IVECO))
		{
			// AG&CE : Get the technical tolerance (delta) and the commercial tolerance (far) according to the Unit (km replaced by "unit" if exists)
			try
			{
				MpUnitSeriesDto mpUnitSeriesDto = new MpUnitSeriesBusiness().getUnitKeyBySerie(context.getBrand().getIceCode(), context.getType().getIceCode(), context.getProduct().getIceCode(),
						context.getSeries().getIceCode());

				if (mpUnitSeriesDto.getToleranceDelta() != null)
				{
					this.delta.put(MpType.MP_KM, mpUnitSeriesDto.getToleranceDelta());
				}
				else
				{
					this.delta.put(MpType.MP_KM, mpToleranceDto.getTechnicalKmMin());
				}

				if (mpUnitSeriesDto.getToleranceFar() != null)
				{
					this.far.put(MpType.MP_KM, mpUnitSeriesDto.getToleranceFar());
				}
				else
				{
					this.far.put(MpType.MP_KM, mpToleranceDto.getCommercialKmMin());
				}
			}
			catch (SystemException | ApplicativeException e)
			{
				logger.error(e.getMessage());
			}

		}
		else
		{
			// IVECO
			this.delta.put(MpType.MP_KM, mpToleranceDto.getTechnicalKmMin());
			this.far.put(MpType.MP_KM, mpToleranceDto.getCommercialKmMin());
		}

		// 2 - Others Technical and Commercial Tolerances
		this.delta.put(MpType.MP_HOUR, mpToleranceDto.getTechnicalHourMin());
		this.delta.put(MpType.MP_MONTH, mpToleranceDto.getTechnicalMonthMin());
		this.far.put(MpType.MP_HOUR, mpToleranceDto.getCommercialHourMin());
		this.far.put(MpType.MP_MONTH, mpToleranceDto.getCommercialMonthMin());

		return mpToleranceDto;
	}

	/**
	 * calculate next stop.
	 * 
	 * @param score score of the interval
	 * @param isHeavyFlex : is flexible contract
	 * @param type interval type
	 */
	public void calculateNextStop(MpNextStopByScoreDto score, MpType type, boolean isHeavyFlex) {
		Long next = 0L; // -- next occurrence of the interval
		MpIntervalDto interval = score.getInterval(); // -- interval to select

		long every = MaintenancePlanBusiness.getEvery(interval, type);
		long at = MaintenancePlanBusiness.getAt(interval, type);

		if (score.getHistory(type).compareTo(0L) > 0)
		{
			// -- the interval has already been performed
			next = score.getHistory(type); // -- the next occurrence will at least be beyond the last
			if (every > 0L)
			{
				// -- the interval has an every step
				next += every; // -- add the step to the history
			}
			else
			{
				// -- the interval does not have a every step
				next = 0L; // -- do not keep the interval for next stop
			}
		}
		else
		{
			// -- the interval has never been performed
			if (at > 0L)
			{
				// -- the interval has an at step
				next = at; // -- next match the at value
			}
			else if (every > 0)
			{
				// -- the interval has an every step
				next = every; // -- next match the every value
			}
			// -- else interval has neither at or every (imposible) do not select by default
		}
		if (isHeavyFlex && !type.equals(MpType.MP_KM) && flexibleCoupons.containsKey(score.getInterval().getCode()) && !Constants.COUPON_FF.equals(score.getInterval().getCode()))
		{
			next = 0L;
		}

		score.setNextStopByType(next, type);
		score.setNextStopRecalculatedByType(next, type);

	}

	/* ************************************************* */
	/* ************* GETTERS and SETTERS *************** */
	/* ************************************************* */

	/**
	 * @return the tolerance in KM
	 */
	public Long getTolKm() {
		return this.far.get(MpType.MP_KM);
	}

	/**
	 * @param dbAccess the dbAccess to set
	 */
	public void setDbAccess(Access dbAccess) {
		this.dbAccess = dbAccess;
	}

	/**
	 * @return the delta
	 */
	public Map<MpType, Long> getDelta() {
		return delta;
	}

	/**
	 * @param delta the delta to set
	 */
	public void setDelta(Map<MpType, Long> delta) {
		this.delta = delta;
	}

	/**
	 * @return the far
	 */
	public Map<MpType, Long> getFar() {
		return far;
	}

	/**
	 * @param far the far to set
	 */
	public void setFar(Map<MpType, Long> far) {
		this.far = far;
	}

	/**
	 * @return the mpToleranceDto
	 */
	public MpToleranceDto getMpToleranceDto() {
		return mpToleranceDto;
	}

	/**
	 * @param mpToleranceDto the mpToleranceDto to set
	 */
	public void setMpToleranceDto(MpToleranceDto mpToleranceDto) {
		this.mpToleranceDto = mpToleranceDto;
	}

	/**
	 * @param flexibleCoupons the flexibleCoupons to set
	 */
	public void setFlexibleCoupons(Map<String, MpFlexCouponDto> flexibleCoupons) {
		this.flexibleCoupons = flexibleCoupons;
	}

	/**
	 * @return the warranty
	 */
	public long getWarranty() {
		return warranty;
	}

	/**
	 * @param warranty the warranty to set
	 */
	public void setWarranty(long warranty) {
		this.warranty = warranty;
	}

}
