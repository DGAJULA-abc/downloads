package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopByScoreDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpScoreDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpScoreDto.ScoreComparator;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.ContractVisibility;
import capgemini.cnh.mpbusiness.util.MpNextFlexComparator;
import capgemini.cnh.ticd.component.util.UtilDate;

public class MaintenancePlanFixedSchedulingBusiness extends MaintenancePlanBusiness {

	/* *************************************** */
	/* ************* Constructors ************ */
	/* *************************************** */

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param warrantyStartDate
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanFixedSchedulingBusiness(long warrantyStartDate, String customer, Access dbAccess, IceContextDto context) {
		super(warrantyStartDate, customer, dbAccess, context);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param warrantyStartDate
	 * @param customer
	 * @param context
	 */
	public MaintenancePlanFixedSchedulingBusiness(long warrantyStartDate, String customer, IceContextDto context) {
		super(warrantyStartDate, customer, context);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanFixedSchedulingBusiness(String customer, Access dbAccess, IceContextDto context) {
		super(customer, dbAccess, context);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param customer
	 * @param dtoIceContext
	 */
	public MaintenancePlanFixedSchedulingBusiness(String customer, IceContextDto dtoIceContext) {
		super(customer, dtoIceContext);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param pActualMileage
	 * @param pActualHour
	 * @param pWarrantyStartDate
	 * @param pNowDate
	 * @param pLocale
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanFixedSchedulingBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, Access dbAccess,
			IceContextDto context) {
		super(pActualMileage, pActualHour, pWarrantyStartDate, pNowDate, pLocale, customer, dbAccess, context);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 * 
	 * @param pActualMileage
	 * @param pActualHour
	 * @param pWarrantyStartDate
	 * @param pNowDate
	 * @param pLocale
	 * @param customer
	 * @param context
	 */
	public MaintenancePlanFixedSchedulingBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, IceContextDto context) {
		super(pActualMileage, pActualHour, pWarrantyStartDate, pNowDate, pLocale, customer, context);
	}

	/* ************************************************************* */
	/* ************* Implementation of abstract Methods ************ */
	/* ************************************************************* */

	/**
	 * Build the score list based on MP intervals.
	 * 
	 * @param pListInterval the interval list
	 * @param pListQuestion the interval question list
	 * @return the possible interval as score
	 */
	@Override
	public List<MpScoreDto> getScore(List<MpIntervalDto> pListInterval, List<MpHistoryIntervalDto> pListQuestion) {
		List<MpScoreDto> scoreList = new ArrayList<>(); // -- result score list
		MpScoreDto score = null; // -- score of an interval
		MpHistoryIntervalDto question = null; // -- question local
		boolean candidate = false; // -- flag for valid multiple
		Iterator<MpHistoryIntervalDto> itQuestion = null; // -- question list iterator
		List<MpScoreDto> multipleList = new ArrayList<>(); // -- multiple list

		// -- for each interval of the MP
		for (MpIntervalDto interval : pListInterval)
		{
			score = null;
			// -- search a matching question
			itQuestion = pListQuestion.iterator();
			while (itQuestion.hasNext() == true)
			{
				question = itQuestion.next();
				//MML: in the history only the interval corresponding to the current external plan id is taken into account
				if (interval.getCode().equals(question.getIntervalCode()) == true)
				{
					// -- interval with matching history
					candidate = false; // -- init interval cannot be a multiple
					interval.setModifiable(question.isCanBeModified());
					interval.setSavable(question.isCanBeSaved());
					score = new MpScoreDto(interval, this.customer); // -- init the score

					for (MpType type : MpType.values())
					{
						// -- init the history for the score
						if (question.getIntValue(type) != null)
						{
							// -- we have the interval taken into account value
							if (type == MpType.MP_MONTH)
							{
								//score.setHistory(type, this.getElapsedMonth(String.valueOf(this.warranty), question.getIntValue(type).toString()));
								score.setHistory(type, question.getIntValue(type));
							}
							else
							{
								score.setHistory(type, question.getIntValue(type));
							}
						}
						else if (question.retreiveFromExactValueByMpType(type) != null && question.retreiveFromExactValueByMpType(type).compareTo(0L) > 0)
						{
							// -- we have only the exact value
							score.setHistory(type, question.retreiveFromExactValueByMpType(type));
						}
						// -- can the interval be a multiple
						if (score.getMultipleByType(type) > 0L)
						{
							candidate = true;
						}
					}

					// -- the interval can be a multiple
					if (candidate == true)
					{
						// -- for each multiple update the history if needed
						// -- e.g. when M2 every 200 KM is performed M1 every 100 KM 
						// -- which is silently included in M2 
						// -- must be considered also performed for the selection algorithm
						this.updateHistoryFromMultiple(score, multipleList);
						// -- add the interval to the list of valid multiple
						multipleList.add(score);
					}

					// -- stop the loop 1 interval = max one question
					itQuestion.remove(); // -- delete the question
					break;
				}
			}
			// -- if no question the interval cannot be selected (no score is created)
			// -- still we add it to the list for comment writing
			if (score == null)
			{
				interval.setModifiable(true);
				interval.setSavable(true);
				score = new MpScoreDto(interval, this.customer); // -- init the score
				for (MpType type : MpType.values())
				{
					score.setHistory(type, 0L);
				}
			}
			// -- add to the score list
			scoreList.add(score);
		}

		return (scoreList);
	}

	@Override
	public boolean selectPerformance(MpScoreDto pScore, MpType pType) {
		Long next = 0L; // -- next occurrence of the interval
		Long value = 0L; // -- distance information from the interval
		boolean selected = false; // -- select the performance flag
		MpIntervalDto interval = pScore.getInterval(); // -- interval to select

		long every = MaintenancePlanBusiness.getEvery(interval, pType);
		long at = MaintenancePlanBusiness.getAt(interval, pType);

		// -- For CE vehicles always retrieve the frequency of the coupon as the next
		if (at > 0L)
		{
			// -- the interval has an at step
			next = at; // -- next match the at value
		}
		else if (every > 0)
		{
			// -- the interval has an every step
			next = every; // -- next match the every value
		}
		// -- else interval has neither at or every (imposible) do not select by default

		// -- save the distance information from the interval
		value = this.actual.get(pType) - next;

		// -- is hour actual value match the next occurrence of the interval
		// The current hour must be between (coupon - Tolerance 75) and (coupon + Tolerance 75)
		// EX.: for Repetitive Coupon R500H, the current hour (actual) must be >= 425 and <= 575 OR >= 925 and <= 1075 OR >= 1425 and <= 1575 etc...
		// for Initial coupon I100H, the current hour (actual) must be >= 25 and <= 175
		// Calculate correctly the value for the multiple cases.
		// Tolerance defined in constant FIXED_COMMERCIAL_TOLERANCE_HOURS
		if (this.actual.get(pType).compareTo(0L) > 0 && next.compareTo(0L) > 0)
		{
			int multiplier = (int) ((this.actual.get(pType) + this.far.get(pType)) / next);

			// Check if Coupon already performed
			boolean isCouponPerformedInInterval = false;
			if (pScore.getHistory(pType) != 0L)
			{
				Long intervalMin = pScore.getHistory(pType) - this.far.get(pType);
				Long intervalMax = pScore.getHistory(pType) + this.far.get(pType);
				if (this.actual.get(pType) >= intervalMin && this.actual.get(pType) <= intervalMax)
				{
					isCouponPerformedInInterval = true;
				}
			}

			// Only for repetitive coupons
			if (at == 0 && multiplier > 0)
			{
				value = this.actual.get(pType) - multiplier * next;

				if (!isCouponPerformedInInterval && this.actual.get(pType).compareTo(multiplier * next - this.far.get(pType)) >= 0
						&& this.actual.get(pType).compareTo(multiplier * next + this.far.get(pType)) <= 0)
				{
					selected = true;
				}
			}
			else if (!isCouponPerformedInInterval && this.actual.get(pType).compareTo(next - this.far.get(pType)) >= 0 && this.actual.get(pType).compareTo(next + this.far.get(pType)) <= 0)
			{
				selected = true;
			}
		}

		if (every == 0 && at == 0)
		{
			value = 0L;
		}

		// -- else do not select he interval based on this type (performance)
		pScore.setScoreByType(value, pType, selected);
		return (selected);
	}

	@Override
	public void updateDelta(List<MpIntervalDto> intervalList) {
		//		for (MpIntervalDto interval : intervalList)
		//		{
		//
		//			// AG&CE : The tolerance is calculated as follows: tolerance = 10% x ‘flagged coupon’.
		//			// Only Hour (No km for AG&CE)
		//			if (interval.isFlag())
		//			{
		//				Long value = interval.getAfterValue(MpType.MP_HOUR);
		//				if (value != null && value.compareTo(0L) > 0)
		//				{
		//					this.far.put(MpType.MP_HOUR, (long) (FIXED_COMMERCIAL_TOLERANCE_HOURS));
		//					//						this.delta.put(MpType.MP_HOUR, (long) (value.longValue() * 0.1));
		//				}
		//
		//				// KM are used for specific units
		//				value = interval.getAfterValue(MpType.MP_KM);
		//				if (value != null && value.compareTo(0L) > 0)
		//				{
		//					this.far.put(MpType.MP_KM, (long) (FIXED_COMMERCIAL_TOLERANCE_KM));
		//					//						this.delta.put(MpType.MP_KM, (long) (value.longValue() * 0.1));
		//
		//				}
		//			}
		//
		//		}
	}

	@Override
	public void updateDelta(Long perfKm, Long perfHour) {
		//
		//		if (perfKm != null && perfKm.compareTo(0L) > 0)
		//		{
		//			this.far.put(MpType.MP_KM, (long) (FIXED_COMMERCIAL_TOLERANCE_KM));
		//		}
		//		if (perfHour != null && perfHour.compareTo(0L) > 0)
		//		{
		//			this.far.put(MpType.MP_HOUR, (long) (FIXED_COMMERCIAL_TOLERANCE_HOURS));
		//		}

	}

	@Override
	public void calculateLHCVFromPartHistory(List<MpHistoryIntervalDto> historyList, MpHistoryIntervalDto previousHistoryConsiderValue, List<MpIntervalDto> pListIntervals) {
		// Nothing to do

	}

	@Override
	public void calculateLHCVFromFullHistory(List<MpHistoryIntervalDto> historyList, List<MpIntervalDto> pListIntervals) {
		// Nothing to do

	}

	@Override
	protected void applyMultiples(MpScoreDto pScore) {
		// Nothing to do

	}

	@Override
	protected void applyMultiplesComment(MpScoreDto pScore) {
		// Nothing to do

	}

	@Override
	protected void clearMultipleList() {
		// Nothing to do

	}

	@Override
	public void applyNextStopMultiples(List<MpNextStopByScoreDto> scoreList, MpType type, Long minNextStop) {
		// Nothing to do

	}

	@Override
	protected void selectPerformanceFlexible(MpNextStopDto nextStopFlex, List<MpScoreDto> scoreList) {
		// Nothing to do

	}

	@Override
	protected void updateHistoryFromMultiple(MpScoreDto pScore, List<MpScoreDto> pMultipleList) {
		// Nothing to do

	}

	@Override
	public List<MpNextStopDto> calculateNextFlexibleStop(List<MpHistoryIntervalDto> listToRecalculate, List<MpNextStopDto> listPreviousNextStop, List<MpHistoryIntervalDto> listPreviousHistory,
			List<MpIntervalDto> intervals, String vin) {
		// Nothing to do
		return new ArrayList<>();
	}

	@Override
	protected void applyNewMultipleRule(List<MpScoreDto> scoreList) {
		// Nothing to do

	}

	@Override
	public Map<String, List<String>> getMultiInterval(List<MpIntervalDto> intervals) throws SystemException {
		// Nothing to do
		return new HashMap<>();
	}

	@Override
	public boolean isMultiple(String coupon, String couponMultiple, List<MpIntervalDto> intervals) {
		// Nothing to do
		return false;
	}

	/**
	 * For CE, the history of the vehicle is not needed to calculate the next stop as the theoretical stop is always realigned to a multiple of the coupon frequency.
	 * 
	 * @param type performance type (km, hour, date)
	 * @param actual actual history value
	 * @param history interval history
	 * @param interval interval matching the history
	 * @return the interval value to be saved in database
	 */
	@Override
	public long getIntValueHistory(MpType type, long actual, MpHistoryIntervalDto history, MpIntervalDto interval) {

		return this.getInterval(actual, interval.getAfterMath(type), interval.getStartMath(type), this.far.get(type));
	}

	/**
	 * Update the interval value for the history.
	 * This interval value field has been introduce for overdue interval.
	 * For those overdue we want to use not the overdue value as history but the interval exact value.
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM. At 204 000 M1 is performed with an overdue of 6 000 KM.
	 * When saved we register 204 000 the exact value and 200 000 KM as the interval value.
	 * The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * 
	 * @param actual exact history value
	 * @param after interval after value
	 * @param at interval at value
	 * @return the interval history value for the type
	 */
	@Override
	public long getInterval(long actual, long after, long at, long far) {

		long result = 0L;
		int multiplier = 0;

		// 2 cases: Recurrent coupons or Initial coupons
		if (at != 0)
		{
			// actual >= at - far
			result = (actual >= at - far) ? at : 0L;
		}
		else
		{
			// if n*after - far <= actual < (n+1)*after + far => n*after 
			if (after != 0)
			{
				multiplier = (int) ((actual + far) / after);
				result = multiplier * after;
			}
		}

		return (result);
	}

	/**
	 * Build the score list based on MP intervals.
	 * 
	 * @param listInterval the interval list
	 * @param listHistory the interval question list
	 * @param listFlexNextStop the list of next stop
	 * @param isHeavyFlex is contract flexible
	 * @return the possible interval as score
	 */
	@Override
	public List<MpNextStopByScoreDto> getNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop,
			boolean isHeavyFlex) {
		List<MpNextStopByScoreDto> scoreList = new ArrayList<>(); // -- result score list
		MpNextStopByScoreDto score = null; // -- score of an interval
		MpHistoryIntervalDto history = null; // -- question local
		Iterator<MpHistoryIntervalDto> itHistory = null; // -- history list iterator
		List<MpScoreDto> multipleList = new ArrayList<>(); // -- multiple list

		// -- for each interval of the MP
		for (MpIntervalDto interval : listInterval)
		{
			score = new MpNextStopByScoreDto(interval, this.customer); // -- init the score
			for (MpType type : MpType.values())
			{
				score.setHistory(type, 0L);
			}
			// -- search a matching history
			itHistory = listHistory.iterator();
			while (itHistory.hasNext() == true)
			{
				history = itHistory.next();
				//MML: in the history only the interval corresponding to the current external plan id is taken into account
				if (interval.getCode().equals(history.getIntervalCode()) == true)
				{
					// -- interval with matching history
					for (MpType type : MpType.values())
					{
						// -- init the history for the score
						if (history.getIntValue(type) != null) // *** SPECIFIC FIXED ALGO
						{
							// -- we have the interval taken into account value
							score.setHistory(type, history.getIntValue(type));
						}
						else if (history.retreiveFromExactValueByMpType(type) != null) // *** SPECIFIC FIXED ALGO
						{
							// -- we have only the exact value
							score.setHistory(type, history.retreiveFromExactValueByMpType(type));
						}
					}
					// -- stop the loop 1 interval = max one question
					break;
				}
			}
			// -- the interval can be a multiple
			if (score.isCanBeMultiple())
			{
				// -- for each multiple update the history if needed
				// -- e.g. when M2 every 200 KM is performed M1 every 100 KM 
				// -- which is silently included in M2 
				// -- must be considered also performed for the selection algorithm
				this.updateHistoryFromMultiple(score, multipleList);
				// -- add the interval to the list of valid multiple
				multipleList.add(score);
			}
			// -- add to the score list
			scoreList.add(score);
		}
		// -- for each interval of the MP
		//keep only the smallest between alert from control room and EDS
		Collections.sort(listFlexNextStop, new MpNextFlexComparator());
		for (MpNextStopByScoreDto scoreInitialiszed : scoreList)
		{
			//calculate next stop
			for (MpType type : MpType.values())
			{
				calculateNextStop(scoreInitialiszed, type, isHeavyFlex);
				//update calculated by the value from EDS and get the smallest between alert from control room and EDS	
				if (type.equals(MpType.MP_KM) && flexibleCoupons.containsKey(scoreInitialiszed.getInterval().getCode()))
				{
					for (MpNextStopDto flex : listFlexNextStop)
					{
						if (scoreInitialiszed.getInterval().getCode().equals(flex.getIntervalCode()))
						{
							scoreInitialiszed.setNextStopByType(flex.getNextValue(type), type);
							scoreInitialiszed.setNextStopRecalculatedByType(flex.getNextValue(type), type);
							scoreInitialiszed.setExternal(flex.getExternal());
							break;
						}
					}
				}

			}
		}

		return (scoreList);
	}

	/**
	 * Calculate next stop and record it in DB.
	 * 
	 * @param listInterval the interval list for the selected plan
	 * @param listHistory the history of intervals for the selected plan
	 * @param listFlexNextStop next stop coming from EDS (in this case no need to recalculate the value)
	 * @param vin the vin
	 * @param isHeavyFlexContract the contract is flexible
	 * @param planId the plan Id selected
	 * @param warrantyStartDate warrantyStartDate
	 * @param lastCurrentMileage : last current mileage
	 * @param lastCurrentHour : last current hour
	 * 
	 * @return the next stop in the tolerance
	 */
	@Override
	public List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour) {
		List<MpNextStopDto> nextStops = new ArrayList<>();

		List<MpHistoryIntervalDto> tmpListHistory = new ArrayList<>(listHistory);
		// -- Initialize the score:the history for each interval (from exact value or theoritical value + update multiple)
		// if listFlexNextStop is not null, no need to recalculate the next flexible stop (come from EDS)
		// and calculate the next stop
		List<MpNextStopByScoreDto> scoreList = getNextStop(listInterval, tmpListHistory, listFlexNextStop, contractVisibility.hasComponentFlexible());
		Collections.sort(scoreList, new MpScoreDto().new ScoreComparator());

		this.updateDelta(listInterval);

		// Get the max real value of the last stop
		Map<MpType, Long> lastRealHisto = new HashMap<>();
		for (MpType type : MpType.values())
		{
			Long maxValue = 0L;

			for (MpHistoryIntervalDto histo : tmpListHistory)
			{
				if (maxValue < histo.retreiveFromExactValueByMpType(type))
				{
					maxValue = histo.retreiveFromExactValueByMpType(type);
				}
			}

			lastRealHisto.put(type, maxValue);
		}

		//For each type, select the coupon in the tolerance and apply the rules for multiples to get the correct coupon among the multiple
		//		List<MpNextStopByScoreDto> possibleMultipleList = new ArrayList<>();
		Long minNextStop = null;
		for (MpType type : MpType.values())
		{
			//			possibleMultipleList = new ArrayList<>();
			minNextStop = calculateMinScore(lastRealHisto.get(MpType.MP_MONTH), lastRealHisto.get(MpType.MP_KM), lastRealHisto.get(MpType.MP_HOUR), scoreList, type, contractVisibility);
			if (minNextStop != null && !(Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop)))
			{
				//Get only the intervals inside the tolerance 
				//and Get only possible coupon multiple
				//				Long maxValue = (lastRealHisto.get(type) == 0L) ? (minNextStop) : (lastRealHisto.get(type));

				// Create List of HashMap for multiples

				for (MpNextStopByScoreDto score : scoreList)
				{
					if (score.getNextStopRecalculatedByType(type) != 0
							&& (score.getNextStopRecalculatedByType(type) < (minNextStop - this.far.get(type)) || score.getNextStopRecalculatedByType(type) > (minNextStop + this.far.get(type))))
					{

						//for element not to record, the next stop is set to 0
						score.setNextStopRecalculatedByType(0L, type);

						//						if (score.getNextStopRecalculatedByType(type) <= maxValue /*|| score.hasMultipleInList(possibleMultipleList)*/)
						//						{
						//							//							//TODO MML : implement content for MpNextStopByScoreDto
						//							//							if (score.isCanBeMultiple() && !possibleMultipleList.contains(score))
						//							//							{
						//							//								possibleMultipleList.add(score);
						//							//							}
						//						}
						//						else
						//						{
						//							//for element not to record, the next stop is set to 0
						//							score.setNextStopRecalculatedByType(0L, type);
						//						}
					}
				}
				//select the best multiple
				//				if (!possibleMultipleList.isEmpty())
				//				{
				//					this.applyNextStopMultiples(possibleMultipleList, type, minNextStop);
				//				}
			}
			// case of an alert with the current mileage not calculated (we keep only this coupon in the next stop)
			else if (Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop))
			{
				for (MpNextStopByScoreDto score : scoreList)
				{
					if (!Constants.DEFAULT_VALUE_NEXT_STOP.equals(score.getNextStopRecalculatedByType(type)))
					{
						score.setNextStopRecalculatedByType(0L, type);
					}
				}
			}
		}

		//Record only interval in the tolerance : mandatory regarding the way to select the multiple
		//otherwise we could have this problem
		// M2 
		// M3 = nextM2 + 50 000
		// M12 = nextM3 + 1 000
		//regarding the algo, M12 would be selected with nextM12=nextM3	
		//the correct coupon are then only get when display?
		//record coupon with next stop <> from 0 for all unit

		MpNextStopDto nextStopDto;
		boolean toBeAdded = false;
		List<String> tmp = new ArrayList<>();
		for (MpNextStopByScoreDto score : scoreList)
		{
			nextStopDto = new MpNextStopDto(vin, score.getInterval().getCode(), planId, score.getExternal());
			if (flexibleCoupons.containsKey(nextStopDto.getIntervalCode()))
			{
				nextStopDto.setFlexible(true);
			}

			// For the scores
			// Get real last EH (actual +- far)
			// Get the min next stop > actual - far

			// 
			for (MpType type : MpType.values())
			{
				// Get only the next stops more in the future than the last real EH (or actual) - commTol (in the commercial tolerance)
				// CASE 1
				// If a VIN with no history has the coupons I100H, R500H, R1000H, R2000H 
				// If the last real EH = 1550, performed coupon is R500H
				// The next stop is at 2000H and contains the coupons R500H, R1000H and R2000H
				//
				// CASE 2
				// If a VIN with no history has the coupons I100H, R500H, R1000H, R2000H 
				// If the last real EH = 1050, performed coupon is R500H (R1000H not saved)
				// The next stop is at 1000H and contains the coupons R1000H
				if (score.getNextStopRecalculatedByType(type) != 0L)
				{
					nextStopDto.setNextValue(type, score.getNextStopRecalculatedByType(type));
					if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
					{
						nextStopDto.setProposalDate(MpType.MP_MONTH, UtilDate.addMonth(warrantyStartDate, nextStopDto.getNextValue(MpType.MP_MONTH).intValue()));
					}

					toBeAdded = true;
				}
			}
			if (toBeAdded)
			{
				if (tmp.contains(score.getInterval().getCode()))
				{
					logger.error("MML calculateNextStop :" + score.getInterval().getCode() + "-" + score);
				}
				nextStops.add(nextStopDto);
			}
			toBeAdded = false;
		}
		//the next stops contains: all the coupon (in the tolerance)
		// listFlexNextStop if flag added/updated : update the next stop flexible
		return nextStops;

	}

	/**
	 * Calculate proposal date.
	 * 
	 * @param warrantyStartDate : warranty Start Date
	 * @param lastCurrentMileage : current mileage
	 * @param lastCurrentHour : current hour
	 * @param scoreList : score List
	 * @param type : type
	 * @param contractVisibility : contract flex or targa
	 * @return min value by type
	 */
	@Override
	public Long calculateMinScore(Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> scoreList, MpType type, ContractVisibility contractVisibility) {
		Long minNextStop = null;
		//get the smallest coupon

		for (MpNextStopByScoreDto score : scoreList)
		{

			if (type.equals(MpType.MP_HOUR) && lastCurrentHour != null)
			{
				if ((score.getNextStopRecalculatedByType(type) != 0 && score.getNextStopRecalculatedByType(type) > lastCurrentHour
						&& (minNextStop == null || score.getNextStopRecalculatedByType(type) < minNextStop)))
				{
					minNextStop = score.getNextStopRecalculatedByType(type);
				}
			}
			else if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
			{
				Long month = getElapsedMonth(Long.toString(warrantyStartDate), Long.toString((new Date().getTime())));
				if ((score.getNextStopRecalculatedByType(type) != 0 && score.getNextStopRecalculatedByType(type) > warrantyStartDate
						&& (minNextStop == null || score.getNextStopRecalculatedByType(type) < minNextStop)))
				{
					//					if (minNextStop < month)
					//					{
					minNextStop = month;
					//					}
				}
			}
		}
		if (contractVisibility.hasProposalDateAndAlert() && minNextStop != null)
		{

			if (type.equals(MpType.MP_KM) && lastCurrentMileage != null)
			{
				if (minNextStop < lastCurrentMileage)
				{
					minNextStop = lastCurrentMileage;
				}
			}
			else if (type.equals(MpType.MP_HOUR) && lastCurrentHour != null)
			{
				if (minNextStop < lastCurrentHour)
				{
					minNextStop = lastCurrentHour;
				}
			}
			else if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
			{
				Long month = getElapsedMonth(Long.toString(warrantyStartDate), Long.toString((new Date().getTime())));
				if (minNextStop < month)
				{
					minNextStop = month;
				}
			}

		}
		return minNextStop;
	}

	@Override
	public List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> fullListNextStop) {
		// TODO Auto-generated method stub
		return null;
	}
}
