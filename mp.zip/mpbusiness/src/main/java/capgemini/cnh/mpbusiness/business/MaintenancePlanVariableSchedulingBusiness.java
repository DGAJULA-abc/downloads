package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopByScoreDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpScoreDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.ContractVisibility;
import capgemini.cnh.mpbusiness.util.MpIntervalStatusEnum;
import capgemini.cnh.mpbusiness.util.MpNextFlexComparator;
import capgemini.cnh.ticd.component.util.UtilDate;

public class MaintenancePlanVariableSchedulingBusiness extends MaintenancePlanBusiness {

	/**
	 * Multiple interval list.
	 */
	private List<MpScoreDto> multipleList;

	/* *************************************** */
	/* ************* Constructors ************ */
	/* *************************************** */

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param warrantyStartDate
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanVariableSchedulingBusiness(long warrantyStartDate, String customer, Access dbAccess, IceContextDto context) {
		super(warrantyStartDate, customer, dbAccess, context);

		this.multipleList = new ArrayList<>();
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param warrantyStartDate
	 * @param customer
	 * @param context
	 */
	public MaintenancePlanVariableSchedulingBusiness(long warrantyStartDate, String customer, IceContextDto context) {
		super(warrantyStartDate, customer, context);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanVariableSchedulingBusiness(String customer, Access dbAccess, IceContextDto context) {
		super(customer, dbAccess, context);

		this.multipleList = new ArrayList<>();
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param customer
	 * @param dtoIceContext
	 */
	public MaintenancePlanVariableSchedulingBusiness(String customer, IceContextDto dtoIceContext) {
		super(customer, dtoIceContext);
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param pActualMileage
	 * @param pActualHour
	 * @param pWarrantyStartDate
	 * @param pNowDate
	 * @param pLocale
	 * @param customer
	 * @param dbAccess
	 * @param context
	 */
	public MaintenancePlanVariableSchedulingBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, Access dbAccess,
			IceContextDto context) {
		super(pActualMileage, pActualHour, pWarrantyStartDate, pNowDate, pLocale, customer, dbAccess, context);

		this.multipleList = new ArrayList<>();
	}

	/**
	 * MaintenancePlanVariableSchedulingBusiness Constructor
	 *
	 * @param pActualMileage
	 * @param pActualHour
	 * @param pWarrantyStartDate
	 * @param pNowDate
	 * @param pLocale
	 * @param customer
	 * @param context
	 */
	public MaintenancePlanVariableSchedulingBusiness(String pActualMileage, String pActualHour, String pWarrantyStartDate, String pNowDate, Locale pLocale, String customer, IceContextDto context) {
		super(pActualMileage, pActualHour, pWarrantyStartDate, pNowDate, pLocale, customer, context);
	}

	/* ************************************************************* */
	/* ************* Implementation of abstract Methods ************ */
	/* ************************************************************* */

	/**
	 * Build the score list based on MP intervals.
	 *
	 * @param pListInterval the interval list
	 * @param pListQuestion the interval question list
	 * @return the possible interval as score
	 */
	@Override
	public List<MpScoreDto> getScore(List<MpIntervalDto> pListInterval, List<MpHistoryIntervalDto> pListQuestion) {
		List<MpScoreDto> scoreList = new ArrayList<>(); // -- result score list
		MpScoreDto score = null; // -- score of an interval
		MpHistoryIntervalDto question = null; // -- question local
		boolean candidate = false; // -- flag for valid multiple
		Iterator<MpHistoryIntervalDto> itQuestion = null; // -- question list iterator
		List<MpScoreDto> multipleList = new ArrayList<>(); // -- multiple list

		// -- for each interval of the MP
		for (MpIntervalDto interval : pListInterval)
		{
			score = null;
			// -- search a matching question
			itQuestion = pListQuestion.iterator();
			while (itQuestion.hasNext() == true)
			{
				question = itQuestion.next();
				//MML: in the history only the interval corresponding to the current external plan id is taken into account
				if (interval.getCode().equals(question.getIntervalCode()) == true)
				{
					// -- interval with matching history
					candidate = false; // -- init interval cannot be a multiple
					interval.setModifiable(question.isCanBeModified());
					interval.setSavable(question.isCanBeSaved());
					score = new MpScoreDto(interval, this.customer); // -- init the score

					for (MpType type : MpType.values())
					{
						// -- init the history for the score
						if (question.getIntValue(type) != null && question.getIntValue(type).compareTo(0L) > 0)
						{
							// -- we have the interval taken into account value
							if (type == MpType.MP_MONTH)
							{
								//score.setHistory(type, this.getElapsedMonth(String.valueOf(this.warranty), question.getIntValue(type).toString()));
								score.setHistory(type, question.getIntValue(type));
							}
							else
							{
								score.setHistory(type, question.getIntValue(type));
							}
						}
						else if (question.retreiveFromExactValueByMpType(type) != null && question.retreiveFromExactValueByMpType(type).compareTo(0L) > 0)
						{
							// -- we have only the exact value
							score.setHistory(type, question.retreiveFromExactValueByMpType(type));
						}
						// -- can the interval be a multiple
						if (score.getMultipleByType(type) > 0L)
						{
							candidate = true;
						}
					}

					// -- the interval can be a multiple
					if (candidate == true)
					{
						// -- for each multiple update the history if needed
						// -- e.g. when M2 every 200 KM is performed M1 every 100 KM 
						// -- which is silently included in M2 
						// -- must be considered also performed for the selection algorithm
						this.updateHistoryFromMultiple(score, multipleList);
						// -- add the interval to the list of valid multiple
						multipleList.add(score);
					}

					// -- stop the loop 1 interval = max one question
					itQuestion.remove(); // -- delete the question
					break;
				}
			}
			// -- if no question the interval cannot be selected (no score is created)
			// -- still we add it to the list for comment writing
			if (score == null)
			{
				interval.setModifiable(true);
				interval.setSavable(true);
				score = new MpScoreDto(interval, this.customer); // -- init the score
				for (MpType type : MpType.values())
				{
					score.setHistory(type, 0L);
				}
			}
			// -- add to the score list
			scoreList.add(score);
		}

		return (scoreList);
	}

	@Override
	public void updateDelta(List<MpIntervalDto> intervalList) {
		for (MpIntervalDto interval : intervalList)
		{
			// CV
			if (customer.equals(Constants.CUSTOMER_IVECO))
			{
				// -- change far delta if interval M1 exist
				if (interval.getCode().equals("M1") || interval.getCode().equals("N1"))
				{
					Long value = interval.getAfterValue(MpType.MP_KM);
					if (value != null && value.compareTo(0L) > 0)
					{
						this.far.put(MpType.MP_KM, (long) (value.longValue() * 0.1));
					}
					value = interval.getAfterValue(MpType.MP_HOUR);
					if (value != null && value.compareTo(0L) > 0)
					{
						this.far.put(MpType.MP_HOUR, (long) (value.longValue() * 0.1));
					}
				}
			}
			//			else
			//			// DEPRECATED AG&CE : The tolerance is calculated as follows: tolerance = 10% x ‘flagged coupon’.
			//			// Only Hour (No km for AG&CE)
			//				// FOR AG&CE NO RECALCULATION, TOLERANCE IS FIXED
			//			{
			//				if (interval.isFlag())
			//				{
			//					Long value = interval.getAfterValue(MpType.MP_HOUR);
			//					if (value != null && value.compareTo(0L) > 0)
			//					{
			//						this.far.put(MpType.MP_HOUR, (long) (value.longValue() * 0.1));
			//						//						this.delta.put(MpType.MP_HOUR, (long) (value.longValue() * 0.1));
			//					}
			//
			//					// KM are used for specific units
			//					value = interval.getAfterValue(MpType.MP_KM);
			//					if (value != null && value.compareTo(0L) > 0)
			//					{
			//						this.far.put(MpType.MP_KM, (long) (value.longValue() * 0.1));
			//						//						this.delta.put(MpType.MP_KM, (long) (value.longValue() * 0.1));
			//					}
			//				}
			//			}
		}
	}

	@Override
	public void updateDelta(Long perfKm, Long perfHour) {

		// CV
		if (customer.equals(Constants.CUSTOMER_IVECO))
		{
			if (perfKm != null && perfKm.compareTo(0L) > 0)
			{
				this.far.put(MpType.MP_KM, (long) (perfKm.longValue() * 0.1));
			}
			if (perfHour != null && perfHour.compareTo(0L) > 0)
			{
				this.far.put(MpType.MP_HOUR, (long) (perfHour.longValue() * 0.1));
			}
		}
	}

	@Override
	protected boolean selectPerformance(MpScoreDto pScore, MpType pType) {
		Long next = 0L; // -- next occurrence of the interval
		Long value = 0L; // -- distance information from the interval
		boolean selected = false; // -- select the performance flag
		MpIntervalDto interval = pScore.getInterval(); // -- interval to select

		long every = MaintenancePlanBusiness.getEvery(interval, pType);
		long at = MaintenancePlanBusiness.getAt(interval, pType);

		if (pScore.getHistory(pType).compareTo(0L) > 0)
		{
			// -- the interval has already been performed
			next = pScore.getHistory(pType); // -- the next occurrence will at least be beyond the last
			if (every > 0L)
			{
				// -- the interval has an every step
				next += every; // -- add the step to the history
			}
			else
			{
				// -- the interval does not have a every step
				next = 0L; // -- do not select the interval
			}
		}
		else
		{
			// -- the interval has never been performed
			if (at > 0L)
			{
				// -- the interval has an at step
				next = at; // -- next match the at value
			}
			else if (every > 0)
			{
				// -- the interval has an every step
				next = every; // -- next match the every value
			}
			// -- else interval has neither at or every (imposible) do not select by default
		}

		// -- save the distance information from the interval
		value = this.actual.get(pType) - next;
		if (every == 0 && at == 0)
		{
			value = 0L;
		}

		// -- is hour actual value match the next occurrence of the interval
		//  IAZ => My line	
		if (this.actual.get(pType).compareTo(0L) > 0 && next.compareTo(0L) > 0 && this.actual.get(pType).compareTo(next - this.far.get(pType)) >= 0)
		//		if (this.actual.get(pType).compareTo(0L) > 0 && next.compareTo(0L) > 0 && this.actual.get(pType).compareTo(next - this.delta.get(pType)) >= 0)
		{
			selected = true;
		}
		// -- else do not select he interval based on this type (performance)
		pScore.setScoreByType(value, pType, selected);
		return (selected);
	}

	@Override
	public void calculateLHCVFromPartHistory(List<MpHistoryIntervalDto> historyList, MpHistoryIntervalDto previousHistoryConsiderValue, List<MpIntervalDto> pListIntervals) {
		//TODO MML, the list of historyList must be sorted by date croissante
		this.updateDelta(pListIntervals); // -- update delta value based on M1 if exists
		for (MpHistoryIntervalDto history : historyList)
		{
			calculateLHCV(history, previousHistoryConsiderValue, pListIntervals);
			previousHistoryConsiderValue = history;
		}
	}

	@Override
	public void calculateLHCVFromFullHistory(List<MpHistoryIntervalDto> historyList, List<MpIntervalDto> pListIntervals) {
		//TODO MML, the list of historyList must be sorted by date croissante
		this.updateDelta(pListIntervals); // -- update delta value based on M1 if exists
		MpHistoryIntervalDto previousHistoryConsiderValue = null;
		for (MpHistoryIntervalDto history : historyList)
		{
			calculateLHCV(history, previousHistoryConsiderValue, pListIntervals);
			previousHistoryConsiderValue = history;
		}
	}

	private void calculateLHCV(MpHistoryIntervalDto history, MpHistoryIntervalDto previousHistoryConsiderValue, List<MpIntervalDto> pListIntervals) {
		//MML todo update the delta only once
		//then pass in parameter only the interval and not the full list
		this.updateDelta(pListIntervals); // -- update delta value based on M1 if exists
		/*
		history contain:
		 exact value in month
		 exact value in hour
		 exact value in km
		*/
		for (MpIntervalDto interval : pListIntervals)
		{
			//MML: in the history only the interval corresponding to the current external plan id is taken into account
			if (interval.getCode().equals(history.getIntervalCode()))
			{
				if (previousHistoryConsiderValue == null)
				{
					Long intValue;
					long historyValue = 0;
					for (MpType type : MpType.values())
					{
						if ((interval.getAfterMath(type) > 0 || interval.getStartMath(type) > 0) && type != MpType.MP_MONTH)
						{
							historyValue = history.retreiveFromExactValueByMpType(type) != null ? history.retreiveFromExactValueByMpType(type).longValue() : 0L;
							intValue = this.getInterval(historyValue, interval.getAfterMath(type), interval.getStartMath(type), this.far.get(type)); // -- estimate from interval value
							history.setIntValue(type, intValue);
						}
						else
						{
							history.setIntValue(type, Long.valueOf(0L));
						}

					}
					if (interval.getStartMath(MpType.MP_MONTH) > 0 || interval.getAfterMath(MpType.MP_MONTH) > 0) // -- convert date to elapsed months
					{
						historyValue = history.retreiveFromExactValueByMpType(MpType.MP_MONTH) != null ? history.retreiveFromExactValueByMpType(MpType.MP_MONTH).longValue() : 0L;
						if (historyValue > 0)
						{
							historyValue = getElapsedMonth(Long.toString(this.warranty), Long.toString(historyValue));
							intValue = this.getInterval(historyValue, interval.getAfterMath(MpType.MP_MONTH), interval.getStartMath(MpType.MP_MONTH),
									this.far.get(MpType.MP_MONTH)); // -- estimate from interval value
							history.setIntValue(MpType.MP_MONTH, intValue);
						}
					}
				}
				else
				{
					for (MpType type : MpType.values())
					{
						if ((interval.getAfterMath(type) > 0 || interval.getStartMath(type) > 0) && type != MpType.MP_MONTH)
						{

							long historyValue = history.retreiveFromExactValueByMpType(type) != null ? history.retreiveFromExactValueByMpType(type).longValue() : 0L;
							history.setIntValue(type, Long.valueOf(this.getIntValueHistory(type, historyValue, previousHistoryConsiderValue, interval)));
						}
						else
						{
							history.setIntValue(type, Long.valueOf(0L));
						}
					}
					try
					{
						// No calculation of int value if the interval doesnot have month in the interval definition
						if (interval.getStartMath(MpType.MP_MONTH) > 0 || interval.getAfterMath(MpType.MP_MONTH) > 0)
						{
							long historyValue = getElapsedMonth(Long.toString(this.warranty), Long.toString(history.retreiveFromExactValueByMpType(MpType.MP_MONTH)));
							history.setIntValue(MpType.MP_MONTH, Long.valueOf(this.getIntValueHistory(MpType.MP_MONTH, historyValue, previousHistoryConsiderValue, interval)));
						}
					}
					catch (NumberFormatException | NullPointerException e)
					{
						history.setIntValue(MpType.MP_MONTH, 0L);
					}

				}
				break;
			}

		}
	}

	@Override
	protected void applyMultiples(MpScoreDto pScore) {

		boolean candidate = false;
		boolean selected = false;
		MpScoreDto score = null;

		// -- check if the interval has valid multiple value
		for (MpType type : MpType.values())
		{
			if (pScore.getMultipleByType(type) > 0L)
			{
				candidate = true;
				break;
			}
		}

		// -- the interval is potentially a multiple
		if (candidate == true)
		{
			Iterator<MpScoreDto> it = this.multipleList.iterator();
			while (it.hasNext() == true)
			{
				score = it.next();
				if (pScore.isMultiple(score) == true)
				{
					// -- find the greatest multiple
					for (MpType type : MpType.values())
					{
						if (pScore.getMultipleByType(type) > score.getMultipleByType(type))
						{
							selected = true;
							break;
						}
					}
					// -- apply selection
					score.getInterval().setSelected(!selected);
					pScore.getInterval().setSelected(selected);

					// apply status
					score.getInterval().setStatus(score.getInterval().isSelected() ? MpIntervalStatusEnum.ON_TIME : MpIntervalStatusEnum.NOT_RECOMMENDED);
					pScore.getInterval().setStatus(pScore.getInterval().isSelected() ? MpIntervalStatusEnum.ON_TIME : MpIntervalStatusEnum.NOT_RECOMMENDED);

					// -- change multiple list
					if (selected == true)
					{
						it.remove();
					}
					else
					{
						candidate = false;
					}
				}
			}
			// -- add score to multiple list if necessary
			if (candidate == true)
			{
				this.multipleList.add(pScore);
			}
		}
	}

	@Override
	protected void applyMultiplesComment(MpScoreDto pScore) {
		boolean candidate = false;
		boolean selected = false;
		MpScoreDto score = null;
		MpIntervalDto low = null;
		MpIntervalDto high = null;

		// -- check if the interval has valid multiple value
		for (MpType type : MpType.values())
		{
			if (pScore.getMultipleByType(type) > 0L)
			{
				candidate = true;
				break;
			}
		}

		// -- the interval is potentially a multiple
		if (candidate == true)
		{
			Iterator<MpScoreDto> it = this.multipleList.iterator();
			while (it.hasNext() == true)
			{
				score = it.next();
				if (pScore.isMultiple(score) == true &&
						(score.getInterval().getDeltaComment() != null || pScore.getInterval().getDeltaComment() != null))
				{
					// -- find the greatest multiple
					for (MpType type : MpType.values())
					{
						if (pScore.getMultipleByType(type) > score.getMultipleByType(type))
						{
							selected = true;
							break;
						}
					}
					// -- apply selection
					//pScore.getInterval().setSelected(selected);
					if (selected == true)
					{
						low = score.getInterval();
						high = pScore.getInterval();
						//it.remove(); // -- remove from multiple list it is treated now
					}
					else
					{
						low = pScore.getInterval();
						high = score.getInterval();
						//candidate = false; // -- do not add multiple to list
					}

					// IAZ
					// -- both overdue keep only the higher comment
					if ((low.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE) || low.getStatus().equals(MpIntervalStatusEnum.OVERDUE))
							&& (high.getStatus().equals(MpIntervalStatusEnum.HIGH_OVERDUE) && high.getStatus().equals(MpIntervalStatusEnum.OVERDUE)) && !low.isSelected())
					{
						low.setDeltaComment(null);
						low.setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
					}
					// -- both coming soon keep only the higher comment
					// -- low is coming soon and high is selected do not show coming soon
					else if (low.getStatus().equals(MpIntervalStatusEnum.COMING_SOON) && (high.getStatus().equals(MpIntervalStatusEnum.COMING_SOON) || high.isSelected()))
					{
						low.setDeltaComment(null);
						low.setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
					}
				}
			}
			// -- add score to multiple list if necessary
			if (candidate == true)
			{
				this.multipleList.add(pScore);
			}
		}
	}

	@Override
	protected void clearMultipleList() {
		this.multipleList.clear();

	}

	@Override
	public void applyNextStopMultiples(List<MpNextStopByScoreDto> scoreList, MpType type, Long minNextStop) {

		//order scoreList and get only the possible multiple
		List<MpNextStopByScoreDto> finalCouponsToKeep = selectMinimumMultiple(scoreList, type, minNextStop);

		//browse finalCouponsToKeep
		// get the greater multiple, and keep the smallest recalculated value 
		MpNextStopByScoreDto score1;
		MpNextStopByScoreDto score2;
		List<MpNextStopByScoreDto> couponsAlreadyTreated = new ArrayList<>();
		List<String> couponCodesAlreadyTreated = new ArrayList<>();

		Collections.sort(finalCouponsToKeep, new MpScoreDto().new ScoreComparatorDesc());
		for (int i = 0; i < finalCouponsToKeep.size(); i++)
		{
			score1 = finalCouponsToKeep.get(i);

			if (couponsAlreadyTreated.isEmpty() || (!couponCodesAlreadyTreated.contains(score1.getInterval().getCode()) && !score1.hasMultipleInList(couponsAlreadyTreated)))
			{
				couponsAlreadyTreated.add(score1);
				couponCodesAlreadyTreated.add(score1.getInterval().getCode());
			}
			else
			{
				for (int j = 0; j < couponsAlreadyTreated.size(); j++)
				{
					score2 = couponsAlreadyTreated.get(j);

					if (score1.getInterval().getCode().equals(score2.getInterval().getCode()))
					{
						score2.setNextStopRecalculatedByType(Math.min(score1.getNextStopRecalculatedByType(type), score2.getNextStopRecalculatedByType(type)), type);
					}
				}
			}
		}

		// Update the scoreList
		for (MpNextStopByScoreDto score : scoreList)
		{
			if (couponCodesAlreadyTreated.contains(score.getInterval().getCode()))
			{
				for (MpNextStopByScoreDto couponToKeep : couponsAlreadyTreated)
				{
					if (score.getInterval().getCode().equals(couponToKeep.getInterval().getCode()))
					{
						score.setNextStopRecalculatedByType(couponToKeep.getNextStopRecalculatedByType(type), type);
					}
				}
			}
			else
			{
				score.setNextStopRecalculatedByType(0L, type);
			}
		}
	}

	/**
	 * Apply multiple rules for interval comment. Remove unwanted comments.
	 *
	 * @param pScore the score
	 */
	private List<MpNextStopByScoreDto> selectMinimumMultiple(List<MpNextStopByScoreDto> scoreList, MpType type, Long minValue) {
		List<MpNextStopByScoreDto> finalCouponsToKeep = new ArrayList<>();
		List<MpNextStopByScoreDto> multiplesAlreadyUsed = new ArrayList<>();
		List<List<MpNextStopByScoreDto>> listMultiples = new ArrayList<>();

		// Create a new working copy of scoreList in order not to modify it during the calculations
		List<MpNextStopByScoreDto> workScoreList = new ArrayList<>();
		for (MpNextStopByScoreDto score : scoreList)
		{
			MpNextStopByScoreDto workScore = new MpNextStopByScoreDto(score);

			workScoreList.add(workScore);
		}

		if (scoreList.size() == 1)
		{
			finalCouponsToKeep.add(scoreList.get(0));
		}
		else
		{
			// Loop over all the couponList to build a list with all the coupons multiple between them. Example of Matrix:
			// M1, M2, M4, M8
			// M1, M3, M6, M12
			// M1, M5, M10
			// M1, M7
			// M1, M3, M9
			// M1, M11
			// M1, M2, M4, M12

			for (int i = 0; i < workScoreList.size(); i++)
			{
				MpNextStopByScoreDto multiple1 = workScoreList.get(i);

				if (!multiplesAlreadyUsed.contains(multiple1))
				{
					// If the score is not multiple to any other score, add it directly to the final list without modifying it
					if (multiple1.hasMultipleInList(workScoreList))
					{
						for (int j = i + 1; j < workScoreList.size(); j++)
						{
							MpNextStopByScoreDto multiple2 = workScoreList.get(j);

							if (multiple1.isMultiple(multiple2))
							{
								if (listMultiples.isEmpty())
								{
									// Initilaize Matrix
									List<MpNextStopByScoreDto> listOfMultiplesForMatrix = new ArrayList<>();
									listOfMultiplesForMatrix.add(multiple1);
									listOfMultiplesForMatrix.add(multiple2);

									// Add first list to final Matrix
									listMultiples.add(listOfMultiplesForMatrix);

									// Add the multiples already used in multiplesAlreadyUsed
									if (!multiplesAlreadyUsed.contains(multiple1))
									{
										multiplesAlreadyUsed.add(multiple1);
									}
									if (!multiplesAlreadyUsed.contains(multiple2))
									{
										multiplesAlreadyUsed.add(multiple2);
									}
								}
								else
								{
									// Loop over the matrix to check if an already exiting set is multiple to multiple2
									ListIterator<List<MpNextStopByScoreDto>> iterator = listMultiples.listIterator();
									while (iterator.hasNext())
									{
										List<MpNextStopByScoreDto> multipleSet = iterator.next();

										if (!multipleSet.contains(multiple2) && multiple2.isMultiple(multipleSet))
										{
											multipleSet.add(multiple2);

											// Add the multiples already used in multiplesAlreadyUsed
											if (!multiplesAlreadyUsed.contains(multiple2))
											{
												multiplesAlreadyUsed.add(multiple2);
											}
										}
										else
										{
											//Get all the multiple below multiple two and add a new list to listMultiples
											List<MpNextStopByScoreDto> listOfMultiplesForMatrix = new ArrayList<>();
											listOfMultiplesForMatrix.add(multiple1);
											listOfMultiplesForMatrix.add(multiple2);

											for (int k = 0; k < j; k++)
											{
												MpNextStopByScoreDto smallerMultiple = workScoreList.get(k);

												if (!listOfMultiplesForMatrix.contains(smallerMultiple) && smallerMultiple.isMultiple(listOfMultiplesForMatrix))
												{
													listOfMultiplesForMatrix.add(smallerMultiple);
												}
											}

											Collections.sort(listOfMultiplesForMatrix, new MpScoreDto().new ScoreComparator());

											// Add the new list if it does not yet exist
											if (!listMultiples.contains(listOfMultiplesForMatrix))
											{
												iterator.add(listOfMultiplesForMatrix);

												for (MpNextStopByScoreDto m1 : listOfMultiplesForMatrix)
												{
													// Add the multiples already used in multiplesAlreadyUsed
													if (!multiplesAlreadyUsed.contains(m1))
													{
														multiplesAlreadyUsed.add(m1);
													}
												}
											}
										}
										Collections.sort(multipleSet, new MpScoreDto().new ScoreComparator());
									}
								}
							}
						}
					}
					else
					{
						List<MpNextStopByScoreDto> noMultiples = new ArrayList<>();
						noMultiples.add(multiple1);
						listMultiples.add(noMultiples);
					}
				}
			}

			for (List<MpNextStopByScoreDto> multipleSet : listMultiples)
			{
				MpNextStopByScoreDto largestMultipleToBeSelected = getLargestMultipleInTolerance(multipleSet, minValue, type);

				if (largestMultipleToBeSelected != null)
				{
					finalCouponsToKeep.add(largestMultipleToBeSelected);
				}
			}
		}

		return finalCouponsToKeep;
	}

	/**
	 * Return the
	 *
	 * @param multipleSet
	 * @return
	 */
	private MpNextStopByScoreDto getLargestMultipleInTolerance(List<MpNextStopByScoreDto> multipleSet, Long minValue, MpType type) {

		// Create a new working copy of multipleSet in order not to modify it during the calculations
		List<MpNextStopByScoreDto> workScoreList = new ArrayList<>();
		for (MpNextStopByScoreDto score : multipleSet)
		{
			MpNextStopByScoreDto workScore = new MpNextStopByScoreDto(score);

			workScoreList.add(workScore);
		}

		MpNextStopByScoreDto result = null;

		for (int i = 0; i < workScoreList.size(); i++)
		{
			MpNextStopByScoreDto multiple = workScoreList.get(i);

			//Compare coupon 1 and coupon 2 next stop
			Long nextMultiple = multiple.getNextStopByType(type);
			//if coupon 2 next stop is inferior to coupon 1 next stop or in the tolerance (to prefer c2 instead of c1), keep coupon2
			if ((nextMultiple - 0.1 * nextMultiple) < minValue)
			{
				// First entry that is valid
				if (result == null)
				{
					result = multiple;
				}
				else
				{
					if (multiple.getMultipleByType(type).compareTo(result.getMultipleByType(type)) > 0)
					{
						//update the next stop recalculated : take the next stop of c1 for c2
						multiple.setNextStopRecalculatedByType(Math.min(multiple.getNextStopRecalculatedByType(type), result.getNextStopRecalculatedByType(type)), type);
					}
					if (multiple.getNextStopRecalculatedByType(type).compareTo(result.getNextStopRecalculatedByType(type)) <= 0)
					{
						result = multiple;
					}
				}
			}
		}

		return result;
	}

	@Override
	protected void selectPerformanceFlexible(MpNextStopDto nextStopFlex, List<MpScoreDto> scoreList) {
		Long next = 0L; // -- next occurrence of the interval
		Long value = 0L; // -- distance information from the interval
		boolean selected = false; // -- select the performance flag
		MpScoreDto scoreFlex = null;
		MpType type = MpType.MP_KM;
		for (MpScoreDto score : scoreList)
		{
			if (nextStopFlex.getIntervalCode().equals(score.getInterval().getCode()))
			{
				scoreFlex = score;
				break;
			}
		}
		if (scoreFlex != null)
		{
			MpIntervalDto interval = scoreFlex.getInterval();
			scoreFlex.setScoreByType(null, MpType.MP_KM, false);
			if (!interval.getCode().equals(Constants.COUPON_FF))
			{
				//Reset month and hour (not used for algorithm for coupon different from FF)
				// IAZ
				scoreFlex.setScoreByType(0L, MpType.MP_HOUR, false);
				scoreFlex.setScoreByType(0L, MpType.MP_MONTH, false);
				interval.setSelected(false);
				interval.setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
			}
			// -- save the distance information from the interval
			next = nextStopFlex.getNextValue(type);
			//case of alert from control room without mileage
			if (next.equals(Constants.DEFAULT_VALUE_NEXT_STOP))
			{
				next = this.actual.get(type);
			}
			value = this.actual.get(type) - next;

			// -- is hour actual value match the next occurrence of the interval
			//  IAZ ==> My Line 
			if (this.actual.get(type).compareTo(0L) > 0 && next.compareTo(0L) > 0 && this.actual.get(type).compareTo(next - this.far.get(type)) >= 0)
			//			if (this.actual.get(type).compareTo(0L) > 0 && next.compareTo(0L) > 0 && this.actual.get(type).compareTo(next - this.delta.get(type)) >= 0)
			{
				selected = true;
			}
			// -- else do not select he interval based on this type (performance)
			scoreFlex.setScoreByType(value, type, selected);

			interval.setSelected(scoreFlex.getSelectedByType(MpType.MP_MONTH) || selected);
			interval.setStatus(interval.isSelected() ? MpIntervalStatusEnum.ON_TIME : MpIntervalStatusEnum.NOT_RECOMMENDED);
			interval.setDeltaComment(null); // -- reset delta comment
			interval.setExternal(nextStopFlex.getExternal());
		}
	}

	@Override
	protected void updateHistoryFromMultiple(MpScoreDto pScore, List<MpScoreDto> pMultipleList) {
		for (MpScoreDto multiple : pMultipleList)
		{
			if (pScore.isMultiple(multiple) == true)
			{
				// -- multiple interval found
				for (MpType type : MpType.values())
				{
					// -- does our interval includes the multiple
					if (pScore.getMultipleByType(type).compareTo(multiple.getMultipleByType(type)) > 0 && pScore.getHistory(type).compareTo(multiple.getHistory(type)) > 0)
					{
						// -- score M2 200 contains multiple M1 100
						// -- history M2 198 beats history M1 102
						multiple.setHistory(type, pScore.getHistory(type)); // -- change M1 history to 198
					}
					else if (multiple.getMultipleByType(type).compareTo(pScore.getMultipleByType(type)) > 0 && multiple.getHistory(type).compareTo(pScore.getHistory(type)) > 0)
					{
						// -- score M1 100 is included in multiple M2 200
						// -- history M2 198 beats history M1 102
						pScore.setHistory(type, multiple.getHistory(type)); // -- change M1 history to 198
					}
					// -- else nothing to do
				}
			}
		}
	}

	@Override
	public List<MpNextStopDto> calculateNextFlexibleStop(List<MpHistoryIntervalDto> listToRecalculate, List<MpNextStopDto> listPreviousNextStop, List<MpHistoryIntervalDto> listPreviousHistory,
			List<MpIntervalDto> intervals, String vin) {
		boolean previousFlexStopFound = false;
		boolean previousHistoryFound = false;
		Long value = null;
		List<MpNextStopDto> result = new ArrayList<>();
		for (MpHistoryIntervalDto couponSaved : listToRecalculate)
		{
			previousFlexStopFound = false;
			previousHistoryFound = false;
			if (flexibleCoupons.containsKey(couponSaved.getIntervalCode()))
			{

				//case EDS data exists (only possible when the next stop is recalculated from IMP)
				for (MpNextStopDto previousFlexStop : listPreviousNextStop)
				{
					if (previousFlexStop.getIntervalCode().equals(couponSaved.getIntervalCode()))
					{
						for (MpHistoryIntervalDto previousHisto : listPreviousHistory)
						{
							if (previousHisto.getIntervalCode().equals(couponSaved.getIntervalCode()))
							{
								value = this.actual.get(MpType.MP_KM) + previousFlexStop.getNextValue(MpType.MP_KM) - previousHisto.getIntValue(MpType.MP_KM);
								previousHistoryFound = true;
								break;
							}
						}
						if (!previousHistoryFound)
						{
							value = this.actual.get(MpType.MP_KM) + previousFlexStop.getNextValue(MpType.MP_KM);
						}
						previousFlexStopFound = true;
						previousFlexStop.setNextValue(MpType.MP_KM, value);
						previousFlexStop.setToBeAddedUpdated(2);
						break;
					}
				}
				//case of none value in EDS (data never filled) : the next stop is last history + theoritical value
				if (!previousFlexStopFound)
				{
					Long previousKm = 0L;
					//case come from serachByVIn, retrieve the last history
					if (this.actual.get(MpType.MP_KM) == null)
					{
						for (MpHistoryIntervalDto previousHisto : listPreviousHistory)
						{
							if (previousHisto.getIntervalCode().equals(couponSaved.getIntervalCode()))
							{
								previousKm = previousHisto.getIntValue(MpType.MP_KM);
								break;
							}
						}
					}
					else
					{
						previousKm = this.actual.get(MpType.MP_KM);
					}
					// use the theoritical performance
					for (MpIntervalDto interval : intervals)
					{
						if (interval.getCode().equals(couponSaved.getIntervalCode()))
						{
							value = previousKm + interval.getAfterMath(MpType.MP_KM);
							break;
						}
					}
					if (value != null)
					{
						MpNextStopDto nextStop = new MpNextStopDto(vin, couponSaved.getIntervalCode(), null, Integer.valueOf(0));
						nextStop.setNextValue(MpType.MP_KM, value);
						nextStop.setToBeAddedUpdated(1);
						result.add(nextStop);

					}
				}
			}

		}
		return result;
	}

	@Override
	protected void applyNewMultipleRule(List<MpScoreDto> scoreList) {

		List<MpScoreDto> listSelectedAndComingSoon = new ArrayList<>();
		List<MpScoreDto> listPossibleGreatMultiples = new ArrayList<>();

		for (MpScoreDto score : scoreList)
		{
			if (score.getInterval().isSelected())
			{
				listSelectedAndComingSoon.add(score);
			}
		}
		for (MpScoreDto multiple1 : listSelectedAndComingSoon)
		{
			MpScoreDto possibleGreaterMultiple = null;
			for (MpScoreDto multiple2 : scoreList)
			{
				// If both intervals are multiple check which one is the greatest.
				if (multiple1.isMultiple(multiple2))
				{
					// If one of them is selected and not the next one check if the new multiple interval rule applies to them
					// Or one of them is "Coming soon"
					if (multiple1.getInterval().isSelected())
					{
						// -- for each possible type of the interval
						for (MpType type : MpType.values())
						{
							// Get the greatest interval
							Long m1 = multiple1.getMultipleByType(type);
							Long m2 = multiple2.getMultipleByType(type);

							if (m1 < m2)
							{
								Long nextMultiple = multiple2.getHistory(type) + m2;

								// LHCVcoupon2 + frequencycoupon2 – 10%.(LHCVcoupon2 + frequencycoupon2) < Actual Value
								if ((nextMultiple - 0.1 * nextMultiple) <= this.actual.get(type))
								{
									// Get the greatest multiple possible
									if ((possibleGreaterMultiple == null) || (possibleGreaterMultiple != null && possibleGreaterMultiple.getMultipleByType(type) > m2))
									{
										possibleGreaterMultiple = multiple2;
									}
								}
							}
						}
					}
				}
			}

			if (possibleGreaterMultiple != null)
			{
				// If low multiple is selected, great multiple has to be selected and NOT soon and/or with delta comment
				if (multiple1.getInterval().isSelected())
				{
					multiple1.getInterval().setSelected(false);
					multiple1.getInterval().setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
					multiple1.getInterval().setDeltaComment(null);

					possibleGreaterMultiple.getInterval().setSelected(true);
					possibleGreaterMultiple.getInterval().setStatus(MpIntervalStatusEnum.ON_TIME);
					possibleGreaterMultiple.getInterval().setDeltaComment(null);
				}
				// If (low multiple is soon and great multiple is not selected), great multiple has to be soon
				// if great multiple is selected keep it that way
				else if (multiple1.getInterval().getStatus().equals(MpIntervalStatusEnum.COMING_SOON) && !possibleGreaterMultiple.getInterval().isSelected())
				{
					possibleGreaterMultiple.getInterval().setSelected(true);
					possibleGreaterMultiple.getInterval().setStatus(MpIntervalStatusEnum.COMING_SOON);
					possibleGreaterMultiple.getInterval().setDeltaComment(multiple1.getInterval().getDeltaComment());

					multiple1.getInterval().setSelected(false);
					multiple1.getInterval().setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
					multiple1.getInterval().setDeltaComment(null);
				}

				listPossibleGreatMultiples.add(possibleGreaterMultiple);
			}
		}

		for (MpScoreDto possibleGreaterMultiple : listPossibleGreatMultiples)
		{
			for (MpScoreDto multiple : scoreList)
			{
				// If both intervals are multiple check which one is the greatest.
				if (possibleGreaterMultiple.isMultiple(multiple))
				{
					// If one of them is selected
					if (multiple.getInterval().isSelected())
					{
						// Check if there are still lower intervals that need to be unselected
						// -- for each possible type of the interval
						for (MpType type : MpType.values())
						{
							// Get the greatest interval
							Long m1 = possibleGreaterMultiple.getMultipleByType(type);
							Long m2 = multiple.getMultipleByType(type);

							if (m1 > m2)
							{
								multiple.getInterval().setSelected(false);
								multiple.getInterval().setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
								multiple.getInterval().setDeltaComment(null);
							}
						}
					}
				}
			}
		}

		for (MpScoreDto multiple : scoreList)
		{
			// TODO IAZ possible code mort? à revoir
			if (!multiple.getInterval().isSelected() && multiple.getInterval().getStatus().equals(MpIntervalStatusEnum.OVERDUE))
			{
				multiple.getInterval().setStatus(MpIntervalStatusEnum.NOT_RECOMMENDED);
				multiple.getInterval().setDeltaComment(null);
			}
		}
	}

	@Override
	public Map<String, List<String>> getMultiInterval(List<MpIntervalDto> intervals) throws SystemException {
		MpScoreDto score;
		List<MpScoreDto> listPossibleMultiple = new ArrayList<>();
		Map<String, List<String>> mapMultiple = new HashMap<>();
		boolean isIncluded = false;
		List<String> listMultiple;

		for (MpIntervalDto interval : intervals)
		{
			score = new MpScoreDto(interval, this.customer);
			if (score.isCanBeMultiple())
			{
				listPossibleMultiple.add(score);
			}
		}
		for (MpScoreDto multiple1 : listPossibleMultiple)
		{
			isIncluded = false;
			for (MpScoreDto multiple2 : listPossibleMultiple)
			{
				if (multiple1.isMultiple(multiple2) == true)
				{
					// -- multiple interval found
					// -- find the greatest multiple
					for (MpType type : MpType.values())
					{
						if (multiple1.getMultipleByType(type) < multiple2.getMultipleByType(type))
						{
							isIncluded = true;
							break;
						}
					}
					if (isIncluded)
					{
						listMultiple = mapMultiple.get(multiple1.getInterval().getCoupon());
						if (listMultiple == null)
						{
							listMultiple = new ArrayList<>();
							listMultiple.add(multiple2.getInterval().getCoupon());
							mapMultiple.put(multiple1.getInterval().getCoupon(), listMultiple);
						}
						else
						{
							listMultiple.add(multiple2.getInterval().getCoupon());
						}
					}
				}

			}
		}
		return mapMultiple;
	}

	@Override
	public boolean isMultiple(String coupon, String couponMultiple, List<MpIntervalDto> intervals) {
		MpScoreDto score = null;
		MpScoreDto scoreMultiple = null;
		boolean isMultiple = false;
		for (MpIntervalDto interval : intervals)
		{
			if (interval.getCoupon().equals(coupon))
			{
				score = new MpScoreDto(interval, this.customer);
			}
			if (interval.getCoupon().equals(couponMultiple))
			{
				scoreMultiple = new MpScoreDto(interval, this.customer);
			}
			if (score != null && scoreMultiple != null)
			{
				break;
			}
		}
		if (score != null && scoreMultiple != null && score.isMultiple(scoreMultiple) == true)
		{
			for (MpType type : MpType.values())
			{
				if (score.getMultipleByType(type) < scoreMultiple.getMultipleByType(type))
				{
					isMultiple = true;
					break;
				}
			}
		}
		return isMultiple;
	}

	/**
	 * Update the interval value for the history for saving. This interval value field has been introduce for overdue interval. For those overdue we want to use not the overdue value as history but
	 * the interval exact value.
	 * <p>
	 * E.g. M1 every 100 000 KM. performed and saved at 98 000 KM. At 204 000 M1 is performed with an overdue of 6 000 KM. When saved we register 204 000 the exact value and 200 000 KM as the interval
	 * value. The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 * </p>
	 *
	 * @param type     performance type (km, hour, date)
	 * @param actual   actual history value
	 * @param history  interval history
	 * @param interval interval matching the history
	 * @return the interval value to be saved in database
	 */
	@Override
	public long getIntValueHistory(MpType type, long actual, MpHistoryIntervalDto history, MpIntervalDto interval) {
		/*
		 * E.g. M1 every 100 000
		 *
		 * M1 old history 80 000 value 80 000 considered
		 * vehicle at 190 000
		 * => M1 new history 190 000 value 190 000 considered
		 *
		 * M1 old history 80 000 value 80 000 considered
		 * vehicle at 210 000
		 * => M1 new history 210 000 value 200 000 considered
		 */
		//TODO IAZ
		long at = interval.getStartMath(type);
		long after = interval.getAfterMath(type);
		long intValue = history != null && history.getIntValue(type) != null ? history.getIntValue(type) : 0L;
		if (intValue > 0)
		{
			intValue += after; // -- from old history find new next
			long dif = 0L;
			if (after > 0)
			{
				dif = after - intValue % after; // -- compute difference to exact next value
				dif = (dif + at) % after; // -- I don't know why I put that here put it makes everything works somehow... \-_-/
			}
			long exact = intValue + dif;
			if (actual <= exact) // -- actual lower than exact value
			{
				intValue = actual; // -- set actual
			}
			else // -- actual greater than exact value
			{
				intValue += dif; // -- set exact value
				// -- if we jump from more than one interval.getAfterMath(type) go to the next
				while (actual - intValue >= after && after > 0)
				{
					intValue += after;
				}
			}
		}
		else
		{
			intValue = this.getInterval(actual, after, at, this.far.get(type));
		}
		return (intValue);
	}

	/**
	 * Update the interval value for the history. This interval value field has been introduce for overdue interval. For those overdue we want to use not the overdue value as history but the interval
	 * exact value. E.g. M1 every 100 000 KM. performed and saved at 98 000 KM. At 204 000 M1 is performed with an overdue of 6 000 KM. When saved we register 204 000 the exact value and 200 000 KM as
	 * the interval value. The next maintenance for M1 will be at 300 000 KM and not 304 000 KM.
	 *
	 * @param actual exact history value
	 * @param after  interval after value
	 * @param at     interval at value
	 * @return the interval history value for the type
	 */
	@Override
	public long getInterval(long actual, long after, long at, long far) {
		// -- PLEASE RUN UNIT TEST IF ANY CHANGE APPLIED
		long intervalValue = 0L;
		long step = 0L;
		long stepFlag = 1L;
		long threshold = 0L;
		if (after > 0)
		{
			step = (long) ((actual - at) / after); // -- what is the suppose iteration
			threshold = (long) ((double) (after * 0.1)); // -- 10% of every value
		}
		else
		{
			threshold = (long) ((double) (at * 0.1)); // -- 10% of at value
		}
		if (actual >= at - threshold)
		{
			if (actual <= at)
			{
				intervalValue = actual;
			}
			else if (at > 0L && at < actual && actual < after + at - threshold)
			{
				intervalValue = at;
			}
			else
			{
				// -- start counting
				long low = at + (step + stepFlag) * after - threshold;
				long high = at + (step + stepFlag) * after;
				if (low <= actual && actual <= high) // -- in threshold
				{
					intervalValue = actual; // -- match
				}
				else if (at == 0L && step == 0L)
				{
					intervalValue = actual;
				}
				else
				{
					intervalValue = at + step * after; // -- rollback
				}
			}
		}
		else
		{ // -- ignore history
			intervalValue = 0L;
		}
		return (intervalValue);

	}

	/**
	 * Build the score list based on MP intervals.
	 *
	 * @param listInterval     the interval list
	 * @param listHistory      the interval question list
	 * @param listFlexNextStop the list of next stop
	 * @param isHeavyFlex      is contract flexible
	 * @return the possible interval as score
	 */
	@Override
	public List<MpNextStopByScoreDto> getNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop,
			boolean isHeavyFlex) {
		List<MpNextStopByScoreDto> scoreList = new ArrayList<>(); // -- result score list
		MpNextStopByScoreDto score = null; // -- score of an interval
		MpHistoryIntervalDto history = null; // -- question local
		Iterator<MpHistoryIntervalDto> itHistory = null; // -- history list iterator
		List<MpScoreDto> multipleList = new ArrayList<>(); // -- multiple list

		// -- for each interval of the MP
		for (MpIntervalDto interval : listInterval)
		{
			score = new MpNextStopByScoreDto(interval, this.customer); // -- init the score
			for (MpType type : MpType.values())
			{
				score.setHistory(type, 0L);
			}
			// -- search a matching history
			itHistory = listHistory.iterator();
			while (itHistory.hasNext() == true)
			{
				history = itHistory.next();
				//MML: in the history only the interval corresponding to the current external plan id is taken into account
				if (interval.getCode().equals(history.getIntervalCode()) == true)
				{
					// -- interval with matching history
					for (MpType type : MpType.values())
					{
						// -- init the history for the score
						if (history.getIntValue(type) != null && history.getIntValue(type).compareTo(0L) > 0) // *** SPECIFIC VARIABLE ALGO
						{
							// -- we have the interval taken into account value
							score.setHistory(type, history.getIntValue(type));
						}
						else if (history.retreiveFromExactValueByMpType(type) != null && history.retreiveFromExactValueByMpType(type).compareTo(0L) > 0) // *** SPECIFIC VARIABLE ALGO
						{
							// -- we have only the exact value
							if (customer.equals(Constants.CUSTOMER_IVECO))
							{
								score.setHistory(type, history.retreiveFromExactValueByMpType(type));
							}
							else if (type != MpType.MP_MONTH)
							{
								score.setHistory(type, history.retreiveFromExactValueByMpType(type));
							}
						}
					}
					// -- stop the loop 1 interval = max one question
					break;
				}
			}
			// -- the interval can be a multiple
			if (score.isCanBeMultiple())
			{
				// -- for each multiple update the history if needed
				// -- e.g. when M2 every 200 KM is performed M1 every 100 KM 
				// -- which is silently included in M2 
				// -- must be considered also performed for the selection algorithm
				this.updateHistoryFromMultiple(score, multipleList);
				// -- add the interval to the list of valid multiple
				multipleList.add(score);
			}
			// -- add to the score list
			scoreList.add(score);
		}
		// -- for each interval of the MP
		//keep only the smallest between alert from control room and EDS
		Collections.sort(listFlexNextStop, new MpNextFlexComparator());
		for (MpNextStopByScoreDto scoreInitialiszed : scoreList)
		{
			//calculate next stop
			for (MpType type : MpType.values())
			{
				calculateNextStop(scoreInitialiszed, type, isHeavyFlex);
				//update calculated by the value from EDS and get the smallest between alert from control room and EDS	
				if (type.equals(MpType.MP_KM) && flexibleCoupons.containsKey(scoreInitialiszed.getInterval().getCode()))
				{
					for (MpNextStopDto flex : listFlexNextStop)
					{
						if (scoreInitialiszed.getInterval().getCode().equals(flex.getIntervalCode()))
						{
							scoreInitialiszed.setNextStopByType(flex.getNextValue(type), type);
							scoreInitialiszed.setNextStopRecalculatedByType(flex.getNextValue(type), type);
							scoreInitialiszed.setExternal(flex.getExternal());
							break;
						}
					}
				}

			}
		}

		return (scoreList);
	}

	/**
	 * Calculate next stop and record it in DB.
	 *
	 * @param listInterval        the interval list for the selected plan
	 * @param listHistory         the history of intervals for the selected plan
	 * @param listFlexNextStop    next stop coming from EDS (in this case no need to recalculate the value)
	 * @param vin                 the vin
	 * @param isHeavyFlexContract the contract is flexible
	 * @param planId              the plan Id selected
	 * @param warrantyStartDate   warrantyStartDate
	 * @param lastCurrentMileage  : last current mileage
	 * @param lastCurrentHour     : last current hour
	 * @return the next stop in the tolerance
	 */
	public List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> fullListNextStop) {
		List<MpNextStopDto> nextStops = new ArrayList<>();

		List<MpHistoryIntervalDto> tmpListHistory = new ArrayList<>(listHistory);
		// -- Initialize the score:the history for each interval (from exact value or theoritical value + update multiple)
		// if listFlexNextStop is not null, no need to recalculate the next flexible stop (come from EDS)
		// and calculate the next stop
		List<MpNextStopByScoreDto> scoreList = getNextStop(listInterval, tmpListHistory, listFlexNextStop, contractVisibility.hasComponentFlexible());
		Collections.sort(scoreList, new MpScoreDto().new ScoreComparator());

		this.updateDelta(listInterval);

		//For each type, select the coupon in the tolerance and apply the rules for multiples to get the correct coupon among the multiple
		List<MpNextStopByScoreDto> possibleMultipleList = new ArrayList<>();
		Long minNextStop = null;
		for (MpType type : MpType.values())
		{
			possibleMultipleList = new ArrayList<>();
			minNextStop = calculateMinScore(warrantyStartDate, lastCurrentMileage, lastCurrentHour, scoreList, type, contractVisibility);
			if (minNextStop != null && !(Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop)))
			{
				//Get only the intervals inside the tolerance 
				//and Get only possible coupon multiple
				Long maxValue = minNextStop + far.get(type);

				// Create List of HashMap for multiples

				for (MpNextStopByScoreDto score : scoreList)
				{
					if (score.getNextStopRecalculatedByType(type) != 0)
					{
						if (score.getNextStopRecalculatedByType(type) <= maxValue || score.hasMultipleInList(possibleMultipleList))
						{
							//TODO MML : implement content for MpNextStopByScoreDto
							if (score.isCanBeMultiple() && !possibleMultipleList.contains(score))
							{
								possibleMultipleList.add(score);
							}
						}
						else
						{
							//for element not to record, the next stop is set to 0
							score.setNextStopRecalculatedByType(0L, type);
						}
					}
				}
				//select the best multiple
				if (!possibleMultipleList.isEmpty())
				{
					this.applyNextStopMultiples(possibleMultipleList, type, minNextStop);
				}
			}
			// case of an alert with the current mileage not calculated (we keep only this coupon in the next stop)
			else if (Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop))
			{
				for (MpNextStopByScoreDto score : scoreList)
				{
					if (!Constants.DEFAULT_VALUE_NEXT_STOP.equals(score.getNextStopRecalculatedByType(type)))
					{
						score.setNextStopRecalculatedByType(0L, type);
					}
				}
			}
		}

		//Record only interval in the tolerance : mandatory regarding the way to select the multiple
		//otherwise we could have this problem
		// M2 
		// M3 = nextM2 + 50 000
		// M12 = nextM3 + 1 000
		//regarding the algo, M12 would be selected with nextM12=nextM3	
		//the correct coupon are then only get when display?
		//record coupon with next stop <> from 0 for all unit
		MpNextStopDto nextStopDto;
		boolean toBeAdded = false;
		List<String> tmp = new ArrayList<>();
		for (MpNextStopByScoreDto score : scoreList)
		{
			nextStopDto = new MpNextStopDto(vin, score.getInterval().getCode(), planId, score.getExternal());
			if (flexibleCoupons.containsKey(nextStopDto.getIntervalCode()))
			{
				nextStopDto.setFlexible(true);
			}
			for (MpType type : MpType.values())
			{
				if (score.getNextStopRecalculatedByType(type) != 0L)
				{
					nextStopDto.setNextValue(type, score.getNextStopRecalculatedByType(type));
					if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
					{
						nextStopDto.setProposalDate(MpType.MP_MONTH, UtilDate.addMonth(warrantyStartDate, nextStopDto.getNextValue(MpType.MP_MONTH).intValue()));
					}

					toBeAdded = true;
				}

			}
			//add score
			fullListNextStop.add(score);
			if (toBeAdded)
			{
				// Check if we have already this coupon code in the list of nextStops 
				// we can't insert twice coupon code on the BDD 
				if (tmp.contains(score.getInterval().getCode()))
				{
					logger.error("MML calculateNextStop coupon already exists :" + score.getInterval().getCode() + "-" + score);
				}
				else
				{
					tmp.add(score.getInterval().getCode());
					nextStops.add(nextStopDto);
				}
			}
			toBeAdded = false;
		}
		//the next stops contains: all the coupon (in the tolerance)
		// listFlexNextStop if flag added/updated : update the next stop flexible
		return nextStops;

	}

	public List<MpNextStopDto> calculateNextStop(List<MpIntervalDto> listInterval, List<MpHistoryIntervalDto> listHistory, List<MpNextStopDto> listFlexNextStop, String vin, Long planId,
			ContractVisibility contractVisibility, Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour) {
		List<MpNextStopDto> nextStops = new ArrayList<>();

		List<MpHistoryIntervalDto> tmpListHistory = new ArrayList<>(listHistory);
		// -- Initialize the score:the history for each interval (from exact value or theoritical value + update multiple)
		// if listFlexNextStop is not null, no need to recalculate the next flexible stop (come from EDS)
		// and calculate the next stop
		List<MpNextStopByScoreDto> scoreList = getNextStop(listInterval, tmpListHistory, listFlexNextStop, contractVisibility.hasComponentFlexible());
		Collections.sort(scoreList, new MpScoreDto().new ScoreComparator());

		this.updateDelta(listInterval);

		//For each type, select the coupon in the tolerance and apply the rules for multiples to get the correct coupon among the multiple
		List<MpNextStopByScoreDto> possibleMultipleList = new ArrayList<>();
		Long minNextStop = null;
		for (MpType type : MpType.values())
		{
			possibleMultipleList = new ArrayList<>();
			minNextStop = calculateMinScore(warrantyStartDate, lastCurrentMileage, lastCurrentHour, scoreList, type, contractVisibility);
			if (minNextStop != null && !(Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop)))
			{
				//Get only the intervals inside the tolerance 
				//and Get only possible coupon multiple
				Long maxValue = minNextStop + far.get(type);

				// Create List of HashMap for multiples

				for (MpNextStopByScoreDto score : scoreList)
				{
					if (score.getNextStopRecalculatedByType(type) != 0)
					{
						if (score.getNextStopRecalculatedByType(type) <= maxValue || score.hasMultipleInList(possibleMultipleList))
						{
							//TODO MML : implement content for MpNextStopByScoreDto
							if (score.isCanBeMultiple() && !possibleMultipleList.contains(score))
							{
								possibleMultipleList.add(score);
							}
						}
						else
						{
							//for element not to record, the next stop is set to 0
							score.setNextStopRecalculatedByType(0L, type);
						}
					}
				}
				//select the best multiple
				if (!possibleMultipleList.isEmpty())
				{
					this.applyNextStopMultiples(possibleMultipleList, type, minNextStop);
				}
			}
			// case of an alert with the current mileage not calculated (we keep only this coupon in the next stop)
			else if (Constants.DEFAULT_VALUE_NEXT_STOP.equals(minNextStop))
			{
				for (MpNextStopByScoreDto score : scoreList)
				{
					if (!Constants.DEFAULT_VALUE_NEXT_STOP.equals(score.getNextStopRecalculatedByType(type)))
					{
						score.setNextStopRecalculatedByType(0L, type);
					}
				}
			}
		}

		//Record only interval in the tolerance : mandatory regarding the way to select the multiple
		//otherwise we could have this problem
		// M2 
		// M3 = nextM2 + 50 000
		// M12 = nextM3 + 1 000
		//regarding the algo, M12 would be selected with nextM12=nextM3	
		//the correct coupon are then only get when display?
		//record coupon with next stop <> from 0 for all unit
		MpNextStopDto nextStopDto;
		boolean toBeAdded = false;
		List<String> tmp = new ArrayList<>();
		for (MpNextStopByScoreDto score : scoreList)
		{
			nextStopDto = new MpNextStopDto(vin, score.getInterval().getCode(), planId, score.getExternal());
			if (flexibleCoupons.containsKey(nextStopDto.getIntervalCode()))
			{
				nextStopDto.setFlexible(true);
			}
			for (MpType type : MpType.values())
			{
				if (score.getNextStopRecalculatedByType(type) != 0L)
				{
					nextStopDto.setNextValue(type, score.getNextStopRecalculatedByType(type));
					if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
					{
						nextStopDto.setProposalDate(MpType.MP_MONTH, UtilDate.addMonth(warrantyStartDate, nextStopDto.getNextValue(MpType.MP_MONTH).intValue()));
					}

					toBeAdded = true;
				}

			}
			if (toBeAdded)
			{
				// Check if we have already this coupon code in the list of nextStops 
				// we can't insert twice coupon code on the BDD 
				if (tmp.contains(score.getInterval().getCode()))
				{
					logger.error("MML calculateNextStop coupon already exists :" + score.getInterval().getCode() + "-" + score);
				}
				else
				{
					tmp.add(score.getInterval().getCode());
					nextStops.add(nextStopDto);
				}
			}
			toBeAdded = false;
		}
		//the next stops contains: all the coupon (in the tolerance)
		// listFlexNextStop if flag added/updated : update the next stop flexible
		return nextStops;

	}

	/**
	 * Calculate proposal date.
	 *
	 * @param warrantyStartDate  : warranty Start Date
	 * @param lastCurrentMileage : current mileage
	 * @param lastCurrentHour    : current hour
	 * @param scoreList          : score List
	 * @param type               : type
	 * @param contractVisibility : contract flex or targa
	 * @return min value by type
	 */
	@Override
	public Long calculateMinScore(Long warrantyStartDate, Long lastCurrentMileage, Long lastCurrentHour, List<MpNextStopByScoreDto> scoreList, MpType type, ContractVisibility contractVisibility) {
		Long minNextStop = null;
		//get the smallest coupon

		for (MpNextStopByScoreDto score : scoreList)
		{
			if (score.getNextStopRecalculatedByType(type) != 0 && (minNextStop == null || score.getNextStopRecalculatedByType(type) < minNextStop))
			{
				minNextStop = score.getNextStopRecalculatedByType(type);
			}
		}
		if (contractVisibility.hasProposalDateAndAlert() && minNextStop != null)
		{

			if (type.equals(MpType.MP_KM) && lastCurrentMileage != null)
			{
				if (minNextStop < lastCurrentMileage)
				{
					minNextStop = lastCurrentMileage;
				}
			}
			else if (type.equals(MpType.MP_HOUR) && lastCurrentHour != null)
			{
				if (minNextStop < lastCurrentHour)
				{
					minNextStop = lastCurrentHour;
				}
			}
			else if (type.equals(MpType.MP_MONTH) && warrantyStartDate != null)
			{
				Long month = getElapsedMonth(Long.toString(warrantyStartDate), Long.toString((new Date().getTime())));
				if (minNextStop < month)
				{
					minNextStop = month;
				}
			}

		}
		return minNextStop;
	}

}
