package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MonMaintenancePlanDomain;
import capgemini.cnh.mpbusiness.dto.MonMaintenancePlanDto;

public class MonMaintenancePlanBusiness extends Business {

	/**
	 * Constructor.
	 */
	public MonMaintenancePlanBusiness() {
		super();
	}

	public void trackMaintenancePlan(String vin, Long id, Long extId) throws SystemException, ApplicativeException {

		MonMaintenancePlanDomain monMaintenancePlanDomain = new MonMaintenancePlanDomain();

		MonMaintenancePlanDto mmpDto = new MonMaintenancePlanDto();
		mmpDto.setMonVin(vin);
		mmpDto.setMonEtimExtPlanId(extId);
		mmpDto.setMonEtimPlanId(id);

		monMaintenancePlanDomain.saveMaintenancePlan(mmpDto);
	}

}
