/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpAlertToleranceDomain;
import capgemini.cnh.mpbusiness.dto.MpAlertToleranceDto;

/**
 *
 * @author lestrabo
 */
public class MpAlertToleranceBusiness extends Business {

	/**
	 * 
	 */
	public MpAlertToleranceBusiness() {
		super();
	}

	/**
	 * @param access
	 */
	public MpAlertToleranceBusiness(OracleAccess access) {
		super(access);
	}

	/**
	 * Get tolerance by plan Id
	 * 
	 * @param mpAlertToleranceDto : the data to delete
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException
	 */
	public Double getToleranceByPlanId(Long planId) throws SystemException, ApplicativeException {
		if (planId != null)
		{
			MpAlertToleranceDto mpAlertToleranceDto = new MpAlertToleranceDomain().getToleranceByPlanId(planId);
			if (mpAlertToleranceDto != null)
			{
				return mpAlertToleranceDto.getKmTolerance();

			}
		}
		return null;
	}

}
