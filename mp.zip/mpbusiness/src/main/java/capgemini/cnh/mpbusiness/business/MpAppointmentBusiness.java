/**
 * Management of MP Appointments.
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.MpAppointmentDomain;
import capgemini.cnh.mpbusiness.dto.MpAppointmentDto;

/**
 * @author cblois
 *
 */
public class MpAppointmentBusiness extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpAppointmentBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpAppointmentBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpAppointmentBusiness() throws SystemException {
		super();
	}

	/**
	 * Close the appointment.
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long closeAppointment(Long alertGroupId) throws SystemException {
		return new MpAppointmentDomain().closeAppointment(alertGroupId);
	}

	/**
	 * Create/Move/Cancel the appointment.
	 * 
	 * @param mpAppointment the appointment
	 * @return the updated appointment (date, status ...)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpAppointmentDto manageAppointment(MpAppointmentDto mpAppointment) throws SystemException {
		return new MpAppointmentDomain().manageAppointment(mpAppointment);
	}

	/**
	 * Get the appointment by id.
	 * 
	 * @param id the id of the appointment
	 * @return the appointment
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpAppointmentDto getAppointmentById(Long id) throws SystemException {
		return new MpAppointmentDomain().getAppointmentById(id);
	}

	/**
	 * Update the appointement to set recall .
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long updateAppointementToRecall(Long alertGroupId) throws SystemException {
		return new MpAppointmentDomain().updateAppointementToRecall(alertGroupId);
	}
}
