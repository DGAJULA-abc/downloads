/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.MpClaimDomain;
import capgemini.cnh.mpbusiness.dto.MpClaimDto;

/**
 * @author pospital
 *
 */
public class MpClaimBusiness extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpClaimBusiness.class);

	/** Creation_time Tag. */
	private static final String CREATION_TIME_ATTR = "Creation_time";

	/** failure_date Tag. */
	private static final String FAILURE_DATE_ATTR = "failure_date";

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpClaimBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpClaimBusiness() throws SystemException {
		super();
	}

	/**
	 * changeRecordDate.
	 *
	 * @param servletRequest for HttpServletRequest
	 * @param servletResponse for HttpServletResponse
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException an applicative exception
	 */
	public boolean changeRecordDate(String idClaim, String newFailureDate) throws SystemException,
			ApplicativeException {
		boolean result = false;

		if (idClaim != null)
		{
			MpClaimDto claimDto = new MpClaimDto();
			claimDto = (new MpClaimBusiness()).getClaimForId(idClaim);
			if (claimDto != null)
			{

				// Update of the field MPCL_XML of the MP_CLAIM table : export DMS
				// XML
				String xmlString = updateFailureDateDms(claimDto.getFilterXML(), newFailureDate);
				String xmlSapString = updateFailureDateDraftClaim(claimDto.getFilterSAPXML(), newFailureDate);
				String originalXmlSapString = updateFailureDateDraftClaim(claimDto.getFilterOriginalSAPXML(), newFailureDate);

				try
				{
					if (!xmlString.equals("") || !xmlSapString.equals("") || !originalXmlSapString.equals(""))
					{
						// Update of the field MPCL_XML of the MP_CLAIM table
						(new MpClaimBusiness()).updateXMLClaim(idClaim, newFailureDate, xmlString, xmlSapString, originalXmlSapString);
						// Update of the field MPCL_DATE_MODIF/MPCL_FAILURE_DATE of the MP_CLAIM table
						//	(new MpClaimBusiness()).updateDateClaim(idClaim, newFailureDate);
						result = true;
					}
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	/**
	 * Add a claim in database for a VIN.
	 * 
	 * @param claimDto claim to add
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean addClaim(MpClaimDto claimDto) throws SystemException, ApplicativeException {
		return (new MpClaimDomain(this.dbAccess)).addClaim(claimDto);
	}

	/**
	 * Get list of claims in database for a VIN.
	 * 
	 * @param vinList : selected VIN 9/17
	 * @return a list of claims
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<MpClaimDto> getClaimForVin(List<String> vinList) throws SystemException, ApplicativeException {
		return (new MpClaimDomain()).getClaimForVin(vinList);
	}

	/**
	 * Get a claim in database for an Id.
	 * 
	 * @param id : selected id
	 * @return a claim
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpClaimDto getClaimForId(String id) throws SystemException, ApplicativeException {
		return (new MpClaimDomain()).getClaimForId(id);
	}

	/**
	 * Update the creation time date in a new field.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean updateDateClaim(String id, String dateEdit) throws SystemException, ApplicativeException {
		return (new MpClaimDomain()).updateDateClaim(id, dateEdit);
	}

	/**
	 * update the XML content in database.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @param XMLFile the content of the XML
	 * @param XMLSapFile the content of the XML sap
	 * @param originalXMLSapFile the content of the original XML sap
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean updateXMLClaim(String id, String dateEdit, String XMLFile, String XMLSapFile, String originalXMLSapFile) throws SystemException, ApplicativeException {
		return (new MpClaimDomain()).updateXMLClaim(id, dateEdit, XMLFile, XMLSapFile, originalXMLSapFile);
	}

	public boolean updatePDFPath(String id, String pdfPath) throws SystemException, ApplicativeException {
		return (new MpClaimDomain()).updatePDFPath(id, pdfPath);
	}

	/**
	 * get Claim to generate PDF
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpClaimDto> getClaimToExport() throws SystemException {
		return (new MpClaimDomain(this.dbAccess)).getClaimToExport();
	}

	/**
	 * Get the max of Id in the MP_CLAIM table.
	 * 
	 * @return the max Id
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public String getMaxClaimId() throws SystemException, ApplicativeException {
		return (new MpClaimDomain(this.dbAccess)).getMaxClaimId();
	}

	/**
	 * Parsing of XML Document.
	 *
	 * The content of the XML document is get from a stream.
	 * 
	 * @param pXmlStream to filter result on a TDS Type (optional parameter)
	 * @return the document
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public Document parse(InputStream pXmlStream)
			throws SystemException, ApplicativeException {
		Document returnValue = null;

		try
		{
			System.setProperty("javax.xml.parsers.SAXParserFactory",
					"org.apache.xerces.jaxp.SAXParserFactoryImpl");

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder;
			docBuilder = docBuilderFactory.newDocumentBuilder();
			returnValue = docBuilder.parse(pXmlStream);
		}
		catch (ParserConfigurationException e)
		{
			logger.error("Error : " + e);
			throw new SystemException(e);
		}
		catch (SAXException e)
		{
			logger.error("Error : " + e);
			throw new SystemException(e);
		}
		catch (IOException e)
		{
			logger.error("Error : " + e);
			throw new SystemException(e);
		}

		return returnValue;
	}

	/**
	 * Update dsm draft claim.
	 * 
	 * @param xmlContent original content
	 * @param newFailureDate new Failure Date
	 * @return the new content
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	private String updateFailureDateDms(String xmlContent, String newFailureDate) throws ApplicativeException, SystemException {
		// Update of the field MPCL_XML of the MP_CLAIM table
		// XML
		StringBuilder result = new StringBuilder();
		if (xmlContent != null)
		{
			int indexFailureDate = xmlContent.indexOf(CREATION_TIME_ATTR);
			if (indexFailureDate >= 0)
			{
				int firstQuoteFailureDate = xmlContent.indexOf('\"', indexFailureDate);
				if (firstQuoteFailureDate >= 0)
				{
					int secondQuoteFailureDate = xmlContent.indexOf('\"', firstQuoteFailureDate + 1);
					//11 : size of the date dd-mm-yyyy + 1
					if (secondQuoteFailureDate >= 0 && (secondQuoteFailureDate - firstQuoteFailureDate) <= 11)
					{
						String year = newFailureDate.substring(0, 4);
						String month = newFailureDate.substring(5, 7);
						String day = newFailureDate.substring(8, 10);
						String dateToInsert = day + "-" + month + "-" + year;
						result.append(xmlContent.substring(0, firstQuoteFailureDate + 1))
								.append(dateToInsert)
								.append(xmlContent.substring(secondQuoteFailureDate));
					}
				}
			}
		}
		return result.toString();
	}

	/**
	 * Update sap/eds draft claim.
	 * ATTEENNNTION: it is not used dom lib to parse and update xml draft because it modifed the attribute order and SAP doesn't manage it
	 * 
	 * @param xmlContent original content
	 * @param newFailureDate new Failure Date
	 * @return the new content
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	private String updateFailureDateDraftClaim(String xmlContent, String newFailureDate) throws ApplicativeException, SystemException {
		// Update of the field MPCL_XML_SAP of the MP_CLAIM table
		// XML
		StringBuilder result = new StringBuilder();
		if (xmlContent != null)
		{
			int indexFailureDate = xmlContent.indexOf(FAILURE_DATE_ATTR);
			if (indexFailureDate >= 0)
			{
				int firstQuoteFailureDate = xmlContent.indexOf('\"', indexFailureDate);
				if (firstQuoteFailureDate >= 0)
				{
					int secondQuoteFailureDate = xmlContent.indexOf('\"', firstQuoteFailureDate + 1);
					//11 : size of the date dd-mm-yyyy + 1
					if (secondQuoteFailureDate >= 0 && (secondQuoteFailureDate - firstQuoteFailureDate) <= 11)
					{
						String year = newFailureDate.substring(0, 4);
						String month = newFailureDate.substring(5, 7);
						String day = newFailureDate.substring(8, 10);
						String dateToInsert = day + "-" + month + "-" + year;
						result.append(xmlContent.substring(0, firstQuoteFailureDate + 1))
								.append(dateToInsert)
								.append(xmlContent.substring(secondQuoteFailureDate));
					}
				}
			}
		}
		return result.toString();
	}

	/**
	 * Function for retrieving the claims for the maintenance history export cron job of 22:00 P.M.
	 * 
	 * @param lastExportDate The date of the last export from which to retrieve the records.
	 * @throws SystemException Cannot execute query or access to database
	 */
	public List<MpClaimDto> getClaimsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		return (new MpClaimDomain()).getClaimsForCsvExport(lastExportDate, firstExportDate);
	}

}
