/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpCustomerDomain;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;

/**
 *
 * @author lestrabo
 */
public class MpCustomerBusiness extends Business {

	/**
	 * 
	 */
	public MpCustomerBusiness() {
		super();
	}

	/**
	 * @param access
	 */
	public MpCustomerBusiness(OracleAccess access) {
		super(access);
	}

	public List<MpCustomerDto> getCustomersFromMpCustomers(String dealerCode, String brand) throws SystemException, ApplicativeException {
		return (new MpCustomerDomain()).getCustomersFromMpCustomers(dealerCode, brand);
	}

}
