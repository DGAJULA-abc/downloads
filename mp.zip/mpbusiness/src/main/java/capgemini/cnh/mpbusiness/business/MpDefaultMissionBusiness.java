/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.domain.MpDefaultMissionDomain;
import capgemini.cnh.mpbusiness.dto.MpDefaultMissionDto;

/**
 * @author mamestoy
 *
 */
public class MpDefaultMissionBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpDefaultMissionBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the mission for an applicability.
	 * 
	 * @param dtoIceContext : context (series, model, tt)
	 * @param level : series, model or tt level
	 * @return a mission dto
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpDefaultMissionDto getMpMissionForApp(IceContextDto dtoIceContext, String level) throws SystemException, ApplicativeException {
		return (new MpDefaultMissionDomain()).getMpMissionForApp(dtoIceContext, level);
	}

}
