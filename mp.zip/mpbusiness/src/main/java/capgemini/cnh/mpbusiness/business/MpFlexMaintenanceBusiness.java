package capgemini.cnh.mpbusiness.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.MpFlexContractDomain;
import capgemini.cnh.mpbusiness.domain.MpFlexCouponDomain;
import capgemini.cnh.mpbusiness.domain.MpFlexCustomerSapDomain;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCustomerSapDto;

/**
 * @author cblois
 * 
 */
public class MpFlexMaintenanceBusiness extends Business {

	/** Define a logger for this class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpFlexMaintenanceBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpFlexMaintenanceBusiness() throws SystemException {
		super();
	}

	/**
	 * Get coupons flexible.
	 * 
	 * @return list of coupons flexible
	 * @throws SystemException SystemException
	 */
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		return (new MpFlexCouponDomain()).getFlexibleCoupons();
	}

	/**
	 * Test if the coupon is flexible.
	 * 
	 * @param couponCode th coupon
	 * @return true if the coupon is flexible
	 * @throws SystemException SystemException
	 */
	public boolean existsFlexibleCoupon(String couponCode) throws SystemException {
		boolean isFlexible = false;
		MpFlexCouponDto mpFlexCouponDto = (new MpFlexCouponDomain()).getFlexibleCoupon(couponCode);
		if (null != mpFlexCouponDto && null != mpFlexCouponDto.getIntervalCode() && !mpFlexCouponDto.getIntervalCode().isEmpty())
		{
			isFlexible = true;
		}
		return isFlexible;
	}

	/**
	 * Get the the applicable Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public MpContractVehicleDto getMpActiveFlexContract(String vin) throws SystemException {
		return (new MpFlexContractDomain()).getMpActiveFlexContract(vin);
	}

	/**
	 * Return true if dealer has contract valid false if doesn't have.
	 * 
	 * @param dealerCode : dealer code
	 * @param brandIceCode : brand Ice Code
	 * @return true or false
	 * @throws SystemException system exception
	 */
	public boolean hasDealerActiveContract(String dealerCode, String brandIceCode) throws SystemException {
		return (new MpFlexContractDomain()).hasDealerActiveContract(dealerCode, brandIceCode);
	}

	/**
	 * Get Customer Details from MP FLEX based on VIN.
	 * 
	 * @param vin vin
	 * @return MpFlexCustomerSapDto
	 * @throws SystemException SystemException
	 */
	public MpFlexCustomerSapDto selectCustomerFromVinDetail(String vin) throws SystemException {
		return new MpFlexCustomerSapDomain().selectCustomerFromVinDetail(vin);
	}
}
