/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpIntervalDomain;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryConfigDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryOrigin;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.MpIntervalComparator;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * @author pospital
 *
 */
public class MpIntervalBusiness extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpIntervalBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpIntervalBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the intervals by plan.
	 * 
	 * @param planId for filter
	 * @param language for display
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of interval
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public static List<MpIntervalDto> getMaintenanceIntervals(Long planId, String language, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {
		return (new MpIntervalDomain()).getMaintenanceIntervals(planId, language, defaultLanguage, famIceCode, isIveco);
	}

	/**
	 * Get all the customer intervals by plan.
	 * 
	 * @param planId for filter
	 * @param language for display
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of interval
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpIntervalDto> getCustomerIntervals(String planId, String language, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {
		return (new MpIntervalDomain()).getCustomerIntervals(planId, language, defaultLanguage, famIceCode, isIveco);
	}

	/**
	 * Get the list of intervals for a maintenance plan and a list of coupons.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param language for language
	 * @param couponsList : a list of coupons
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public static List<MpIntervalDto> getMaintenanceIntervalsByCoupons(Long planId, String language, String[] couponsList, String defaultLanguage, String famIceCode)
			throws SystemException, ApplicativeException {
		return (new MpIntervalDomain()).getMaintenanceIntervalsByCoupons(planId, language, couponsList, defaultLanguage, famIceCode);
	}

	/**
	 * Get the intervals for a maintenance plan.
	 * 
	 * @param planId for filter
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervals(Long planId, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {
		return (new MpIntervalDomain()).getMaintenanceIntervals(planId, defaultLanguage, famIceCode, isIveco);
	}

	/**
	 * Get the list of intervals for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsWithoutOperation(Long planId, String defaultLanguage, String famIceCode) throws SystemException {
		return (new MpIntervalDomain()).getMaintenanceIntervalsWithoutOperation(planId, defaultLanguage, famIceCode);
	}

	/**
	 * Get a coupon name giving the sub group name.
	 * 
	 * @param intervalCode : interval code name
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the coupon
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getCouponName(String intervalCode, String defaultLanguage, String famIceCode) throws SystemException {
		return (new MpIntervalDomain()).getCouponName(intervalCode, defaultLanguage, famIceCode);
	}

	/**
	 * Get the list of intervals for a maintenance plan from interval id.
	 * 
	 * @param intervalId :nterval id.
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsFromIntervalId(Long intervalId, String defaultLanguage, String famIceCode) throws SystemException {
		return (new MpIntervalDomain()).getMaintenanceIntervalsFromIntervalId(intervalId, defaultLanguage, famIceCode);
	}

	/**
	 * Get the interval for a maintenance plan and an interval.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param intervalId : interval identifier
	 * @param language for language
	 * @param defaultLanguage for default Language
	 * @return interval for a maintenance plan and interval identifier
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public static MpIntervalDto getMaintenanceInterval(String planId, String intervalId, String language, String defaultLanguage) throws SystemException, ApplicativeException {
		return (new MpIntervalDomain()).getMaintenanceInterval(planId, intervalId, language, defaultLanguage);
	}

	/**
	 * Insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean createHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain(this.dbAccess);

		return (domain.createHistoryInterval(pDto));
	}

	/**
	 * Insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param sapDto
	 *            the sap interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateHourHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain(this.dbAccess);

		return (domain.updateHourHistoryInterval(sapDto, toleranceToMatch));
	}

	/**
	 * Insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param sapDto
	 *            the sap interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateKmHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain(this.dbAccess);

		return (domain.updateKmHistoryInterval(sapDto, toleranceToMatch));
	}

	/**
	 * Select an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval to select
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static MpHistoryIntervalDto readHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {

		return (readHistoryInterval(pDto, null));
	}

	/**
	 * Select an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval to select
	 * @param filterOrigin : filter origin
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static MpHistoryIntervalDto readHistoryInterval(MpHistoryIntervalDto pDto, Integer filterOrigin) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		return (domain.readHistoryInterval(pDto, filterOrigin));
	}

	/**
	 * Select a list of interactive maintenance plan interval history in the database.
	 * 
	 * @param pVin
	 *            the V.I.N.
	 * @param extPlanId
	 *            the external plan identifier
	 * @param intervalId
	 *            the interval identifier
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static List<MpHistoryIntervalDto> readListHistoryInterval(List<String> lstPinVin, Long intervalId, Long extPlanId) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryIntervalDto dto = new MpHistoryIntervalDto(null, intervalId, lstPinVin, null, extPlanId, null);

		return (domain.readListHistoryInterval(dto));
	}

	/**
	 * Select a list of interactive maintenance plan interval history in the database for a plan and an an origin SAP/eTIM.
	 * 
	 * @param vin
	 *            the vin
	 * @param filterOrigin
	 *            the filterOrigin
	 * @param dateFrom
	 *            the date of history beginning
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static List<MpHistoryIntervalDto> readListFromDateByOrigin(List<String> lstPinVin, Integer filterOrigin, long dateFrom) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		List<MpHistoryIntervalDto> returnList = new ArrayList<MpHistoryIntervalDto>();
		MpIntervalComparator comparator = new MpIntervalComparator();
		String currentCode = "";

		List<MpHistoryIntervalDto> list = domain.readListFromDateByOrigin(lstPinVin, filterOrigin, dateFrom);
		Collections.sort(list, comparator);

		for (MpHistoryIntervalDto histo : list)
		{
			//get the last history SAP 
			if (!currentCode.equals(histo.getIntervalCode()))
			{
				returnList.add(histo);
			}
			currentCode = histo.getIntervalCode();
		}
		return returnList;
	}

	/**
	 * Get list of history for a VIN underContract.
	 * 
	 * @param pVin
	 *            the V.I.N.
	 * @param toleranceToMatch
	 *            the tolerance To match
	 * @param toleranceToWait
	 *            the tolerance To Wait
	 * @param dateFrom
	 *            the date From which the history must be retrieved
	 * @param flexCoupon : flexible co
	 * @param isHeavyFlex : tolerance to wait SAP claim
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> readListHistoryIntervalWithContract(List<String> lstPinVin, int toleranceToMatch, int toleranceToWait,
			long dateFrom, Map<String, MpFlexCouponDto> flexCoupon, boolean isHeavyFlex)
			throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		String currentCode = "";
		//List<MpHistoryIntervalDto> list = domain.readListHistoryInterval(pVin, extPlanId, previousExtPlanId);
		//get only history on the current contract
		//	List<MpHistoryIntervalDto> list = domain.readListHistoryInterval(new MpHistoryIntervalDto(null, null, pVin, null, extPlanId));
		List<MpHistoryIntervalDto> list = domain.readListFromDateByOrigin(lstPinVin, null, dateFrom);
		List<MpHistoryIntervalDto> returnList = new ArrayList<MpHistoryIntervalDto>();
		MpHistoryIntervalDto lastSapHistory = null;
		MpHistoryIntervalDto lastEtimHistory = null;
		MpIntervalComparator comparator = new MpIntervalComparator();

		Collections.sort(list, comparator);
		for (MpHistoryIntervalDto histo : list)
		{
			//get the last history SAP or eTIM according tolerance
			//if no sap history canBeModified = true
			if (!currentCode.equals(histo.getIntervalCode()) && !currentCode.equals(""))
			{
				getLastHistory(lastSapHistory, lastEtimHistory, returnList, toleranceToMatch, toleranceToWait, flexCoupon, isHeavyFlex);
				lastSapHistory = null;
				lastEtimHistory = null;
			}
			currentCode = histo.getIntervalCode();
			if (lastSapHistory != null && lastEtimHistory != null)
			{
				continue;
			}
			if (lastSapHistory == null && MpHistoryOrigin.SAP.getValue().equals(histo.getIsSapOrigin()))
			{
				lastSapHistory = histo;
			}
			else if (lastEtimHistory == null && (MpHistoryOrigin.TIDB.getValue().equals(histo.getIsSapOrigin()) || MpHistoryOrigin.UCR.getValue().equals(histo.getIsSapOrigin())))
			{
				lastEtimHistory = histo;
			}
		}

		getLastHistory(lastSapHistory, lastEtimHistory, returnList, toleranceToMatch, toleranceToWait, flexCoupon, isHeavyFlex);
		return returnList;
	}

	/**
	 * Get list of the last history for the VIN.
	 * 
	 * @param lastSapHistory
	 *            the last SAP history.
	 * @param lastEtimHistory
	 *            the last eTIM historyr
	 * @param returnList
	 *            the list of the last history for the VIN
	 * 
	 */
	public static void getLastHistory_old(MpHistoryIntervalDto lastSapHistory, MpHistoryIntervalDto lastEtimHistory, List<MpHistoryIntervalDto> returnList, int toleranceToMatch, int toleranceToWait)
			throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		if (lastSapHistory != null || lastEtimHistory != null)
		{
			if (lastSapHistory == null)
			{
				//si current date is superior to eTIM + 30 days the history is removed (needs to take into account the previous history and erase it)				
				if (UtilDate.compareDate(lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), 0, toleranceToWait) < 0)
				{
					//remove from history
					domain.delete(lastEtimHistory.getId());
				}
				else
				{
					returnList.add(lastEtimHistory);
				}
			}
			else
			{
				int diffMatch = 0;
				if (lastEtimHistory != null)
				{
					diffMatch = UtilDate.compareDate(lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), toleranceToMatch);
				}
				if (lastEtimHistory != null && diffMatch < 0)
				{
					if (UtilDate.compareDate(lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), 0, toleranceToWait) < 0)
					{
						//remove from history and carry on finding the correct interval
						domain.delete(lastEtimHistory.getId());
						lastSapHistory.setCanBeModified(false);
						returnList.add(lastSapHistory);
					}
					else
					{
						lastEtimHistory.setCanBeModified(false);
						//can not be saved because the last SAP claim is not received
						lastEtimHistory.setCanBeSaved(false);
						returnList.add(lastEtimHistory);
					}
				}
				else
				{
					lastSapHistory.setCanBeModified(false);
					returnList.add(lastSapHistory);
					//TODO MML TOLERANCE TO BE DEFINED : difference between 2 dates to consider that they are linked
					if (lastEtimHistory != null
							&& (lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR) == null || lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(0L) == 0)
							&& (lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR) != null && lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(0L) > 0))
					{
						int diffMatch2 = UtilDate.compareDate(lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH),
								-toleranceToMatch);
						if (lastEtimHistory != null && diffMatch >= 0 && diffMatch2 <= 0)
						{
							lastSapHistory.addToExactValue(MpType.MP_HOUR, lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR));
							lastSapHistory.setIntValue(MpType.MP_HOUR, lastEtimHistory.getIntValue(MpType.MP_HOUR));
						}
					}
				}

			}
		}
	}

	/**
	 * Get list of the last history for the VIN.
	 * 
	 * @param lastSapHistory
	 *            the last SAP history.
	 * @param lastEtimHistory
	 *            the last eTIM history
	 * @param toleranceToMatch : tolerance to associate a coupon eTIM with a coupon SAP
	 * @param toleranceToWait : tolerance to wait SAP claim
	 * @param returnList
	 *            the list of the last history for the VIN
	 * @param flexCoupon : flexible co
	 * @param isHeavyFlex : tolerance to wait SAP claim
	 */
	public static void getLastHistory(MpHistoryIntervalDto lastSapHistory, MpHistoryIntervalDto lastEtimHistory, List<MpHistoryIntervalDto> returnList, int toleranceToMatch, int toleranceToWait,
			Map<String, MpFlexCouponDto> flexCoupon, boolean isHeavyFlex) {
		if (isHeavyFlex && (lastEtimHistory != null && flexCoupon.get(lastEtimHistory.getIntervalCode()) != null
				|| lastSapHistory != null && flexCoupon.get(lastSapHistory.getIntervalCode()) != null))
		{
			if (lastEtimHistory != null)
			{
				lastEtimHistory.setCanBeModified(false);
				returnList.add(lastEtimHistory);
			}
		}
		else if (lastSapHistory != null || lastEtimHistory != null)
		{
			if (lastSapHistory == null)
			{
				//coupon entered manually by the dealer in the history (coupon not transmitted to SAP)
				// in this case the coupon can be manually  selected by the dealer or by the algorithm
				//the value of the history can also be modified (it can happen only at the beginning before the coupon is saved and then transmitted to SAP)
				if (lastEtimHistory.getIdClaim() == null)
				{
					returnList.add(lastEtimHistory);
				}
				else if (UtilDate.compareDate(lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), 0, toleranceToWait) >= 0)
				{
					returnList.add(lastEtimHistory);
					lastEtimHistory.setCanBeModified(false);
					//if no sap claim and the etim save is recent  (from history or from coupon saved)=> this coupon cannot be saved again
					lastEtimHistory.setCanBeSaved(false);
				}
			}
			// If there has been a claim assessed from SAP
			else
			{
				int diffMatch = 0;
				if (lastEtimHistory != null)
				{
					// IAZ Change Exact month with failure date
					// if diffMatch < 0: SAP FD too early eTIM FD - 20 = Out of tolerance
					// 		EX: SAP FD 01/12/20, eTIM FD 01/02/21
					// if diffMatch >= 0: SAP FD > ETIM FD - 20 = In tolerance
					//		EX: SAP FD 30/12/20, eTIM FD 01/01/21;
					//			SAP FD 01/02/21, eTIM FD 01/01/21;
					diffMatch = UtilDate.compareDate(lastSapHistory.getFailureDate(), lastEtimHistory.getFailureDate(), toleranceToMatch);
				}
				if (lastEtimHistory != null && diffMatch < 0)
				{
					// If eTIM history saved more than 2 months ago
					if (UtilDate.compareDate(lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), 0, toleranceToWait) < 0)
					{
						lastSapHistory.setCanBeModified(false);
						returnList.add(lastSapHistory);
					}
					// else waiting for the claim
					else
					{
						//can not be saved because the last SAP claim is not received
						lastEtimHistory.setCanBeModified(false);
						lastEtimHistory.setCanBeSaved(false);
						returnList.add(lastEtimHistory);
					}
				}
				else
				{
					lastSapHistory.setCanBeModified(false);
					returnList.add(lastSapHistory);
					//TODO MML TOLERANCE TO BE DEFINED : difference between 2 dates to consider that they are linked
					if (lastEtimHistory != null
							&& (lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR) == null || lastSapHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(0L) == 0)
							&& (lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR) != null && lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR).compareTo(0L) > 0))
					{
						// IAZ Change Exact month with failure date
						int diffMatch2 = UtilDate.compareDate(lastSapHistory.getFailureDate(), lastEtimHistory.getFailureDate(), -toleranceToMatch);
						if (lastEtimHistory != null && diffMatch >= 0 && diffMatch2 <= 0)
						{
							lastSapHistory.addToExactValue(MpType.MP_HOUR, lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_HOUR));
							lastSapHistory.setIntValue(MpType.MP_HOUR, lastEtimHistory.getIntValue(MpType.MP_HOUR));
						}
					}
				}
			}
		}
	}

	/**
	 * Get list of history for a VIN underContract.
	 * 
	 * @param pVin
	 *            the V.I.N.
	 * @param toleranceToMatch
	 *            the tolerance To match
	 * @param toleranceToWait
	 *            the tolerance To Wait
	 * @param dateFrom
	 *            the date From which the history must be retrieved
	 * @param flexCoupons : coupons not flexible
	 * @param isFlexHeavy : is contract flex heavy
	 * @return true if the history is updated
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static boolean removeCouponsWithoutClaim(List<String> lstPinVin, int toleranceToMatch, int toleranceToWait,
			long dateFrom, Map<String, MpFlexCouponDto> flexCoupons, boolean isFlexHeavy)
			throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		String currentCode = "";
		List<MpHistoryIntervalDto> list = domain.readListFromDateByOrigin(lstPinVin, null, dateFrom);
		MpHistoryIntervalDto lastSapHistory = null;
		MpHistoryIntervalDto lastEtimHistory = null;
		MpIntervalComparator comparator = new MpIntervalComparator();
		boolean result = false;

		Collections.sort(list, comparator);
		for (MpHistoryIntervalDto histo : list)
		{
			if (!isFlexHeavy || !flexCoupons.containsKey(histo.getIntervalCode()))
			{
				//get the last history SAP or eTIM according tolerance
				if (!currentCode.equals(histo.getIntervalCode()) && !currentCode.equals(""))
				{
					result = removeCouponWithoutClaim(lastSapHistory, lastEtimHistory, toleranceToMatch, toleranceToWait) || result;
					lastSapHistory = null;
					lastEtimHistory = null;
				}
				currentCode = histo.getIntervalCode();
				if (lastSapHistory != null && lastEtimHistory != null)
				{
					continue;
				}
				if (lastSapHistory == null && MpHistoryOrigin.SAP.getValue().equals(histo.getIsSapOrigin()))
				{
					lastSapHistory = histo;
				}
				else if (lastEtimHistory == null && (MpHistoryOrigin.TIDB.getValue().equals(histo.getIsSapOrigin()) || MpHistoryOrigin.UCR.getValue().equals(histo.getIsSapOrigin())))
				{
					lastEtimHistory = histo;
				}
			}
		}
		if (!isFlexHeavy
				|| (lastSapHistory != null && !flexCoupons.containsKey(lastSapHistory.getIntervalCode()) || lastEtimHistory != null && !flexCoupons.containsKey(lastEtimHistory.getIntervalCode())))
		{
			result = removeCouponWithoutClaim(lastSapHistory, lastEtimHistory, toleranceToMatch, toleranceToWait) || result;
		}
		return result;
	}

	/**
	 * remove the coupons wihtout claim.
	 * 
	 * @param lastSapHistory
	 *            the last SAP history.
	 * @param lastEtimHistory
	 *            the last eTIM historyr
	 * @param toleranceToMatch : tolerance to associate a coupon eTIM with a coupon SAP
	 * @param toleranceToWait : tolerance to wait SAP claim
	 * @return true if the history is updated
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static boolean removeCouponWithoutClaim(MpHistoryIntervalDto lastSapHistory, MpHistoryIntervalDto lastEtimHistory, int toleranceToMatch,
			int toleranceToWait)
			throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		boolean modified = false;
		if (lastEtimHistory != null)
		{
			int diffMatch = 0;
			if (lastSapHistory != null)
			{
				//  IAZ Use failure date instead of exact month
				diffMatch = UtilDate.compareDate(lastSapHistory.getFailureDate(), lastEtimHistory.getFailureDate(), toleranceToMatch);

			}
			if (diffMatch < 0 || lastSapHistory == null)
			{
				//si current date is superior to eTIM + 60 days the history is removed (needs to take into account the previous history and erase it)				
				if (UtilDate.compareDate(lastEtimHistory.retreiveFromExactValueByMpType(MpType.MP_MONTH), 0, toleranceToWait) < 0)
				{
					//remove from history (do an update instead of a delete)
					domain.updateDeleted(lastEtimHistory.getId(), 1);
					modified = true;
				}
			}
		}
		return modified;
	}

	/**
	 * Update the status of the coupon to deleted.
	 * 
	 * @param intervalId interval id
	 * @throws SystemException SystemException
	 */
	public void updateDeleted(String intervalId) throws SystemException {
		new MpIntervalDomain().updateDeleted(intervalId, 1);
	}

	/**
	 * Update an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static boolean updateHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		return (domain.updateHistoryInterval(pDto));
	}

	/**
	 * Update or insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateOrInsertHistoryInterval(MpHistoryIntervalDto pDto, List<MpHistoryIntervalDto> listQuestionsToKeep, boolean isIveco, List<MpHistoryIntervalDto> listHistoryContract,
			boolean hasContractAg) throws SystemException {
		boolean success = false;
		MpHistoryIntervalDto old = null;

		//TODO MML read history with origin eTIM to set the history on the eTIM one (specially for the hour)
		if (isIveco)
		{
			old = MpIntervalBusiness.readHistoryInterval(pDto, pDto.getIsSapOrigin());
		}
		else if (hasContractAg)
		{
			old = listHistoryContract.stream().filter(x -> Objects.equals(x.getIntervalCode(), pDto.getIntervalCode())).findFirst().orElse(null);
		}
		else
		{
			old = MpIntervalBusiness.readHistoryInterval(pDto, null);
		}

		if (old != null)
		{
			// -- object exist in database
			// -- before update, check there is actually a change worth to update
			for (MpType type : MpType.values())
			{
				if (old.retreiveFromExactValueByMpType(type).equals(pDto.retreiveFromExactValueByMpType(type)) == false)
				{
					success = true;
					break; // -- one change is enough to do the update
				}
			}
			// -- update if needed
			if (success == true)
			{
				if (pDto.getId() == null)
				{
					pDto.setId(old.getId());
				}

				success = updateHistoryInterval(pDto);
				listQuestionsToKeep.add(pDto);
			}
		}
		else
		{
			// -- object do NOT exist in database
			// -- insert!
			success = createHistoryInterval(pDto);
			listQuestionsToKeep.add(pDto);
		}
		return (success);
	}

	/**
	 * Delete an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static boolean deleteHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		boolean success = false;
		MpHistoryIntervalDto old = null;

		old = MpIntervalBusiness.readHistoryInterval(pDto);
		if (old != null)
		{
			// -- object exist in database
			success = domain.deleteHistoryInterval(pDto);
		}
		// -- else object not found cannot delete
		return (success);
	}

	/**
	 * Insert an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pVin the V.I.N.
	 * @param pWarrantyDate the warranty date
	 * @param usageId the selected usage
	 * @param mileage the actual mileage
	 * @param hour the actual working hours
	 * @param nowDate the actual date
	 * 
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public boolean createHistoryWarranty(String pVin, String pWarrantyDate, int usageId, int mileage, int hour, String nowDate) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryWarrantyDto dto = new MpHistoryWarrantyDto();

		dto.setVin(pVin);
		dto.setWarrantyDate(pWarrantyDate);
		dto.setSelectedUsage(usageId);
		dto.setMileage(mileage);
		dto.setHour(hour);
		dto.setNowDate(nowDate);

		return (domain.createHistoryWarranty(dto));
	}

	/**
	 * Select an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pVin
	 *            the V.I.N.
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public MpHistoryWarrantyDto readHistoryWarranty(String pVin) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryWarrantyDto dto = new MpHistoryWarrantyDto();

		dto.setVin(pVin);

		return (domain.readHistoryWarranty(dto));
	}

	/**
	 * Update an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pVin the V.I.N.
	 * @param pWarrantyDate the warranty date
	 * @param usageId the selected usage
	 * @param mileage the actual mileage
	 * @param hour the actual working hours
	 * @param nowDate the actual date
	 * 
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public boolean updateHistoryWarranty(String pVin, String pWarrantyDate, int usageId, int mileage, int hour, String nowDate) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryWarrantyDto dto = new MpHistoryWarrantyDto();

		dto.setVin(pVin);
		dto.setWarrantyDate(pWarrantyDate);
		dto.setSelectedUsage(usageId);
		dto.setMileage(mileage);
		dto.setHour(hour);
		dto.setNowDate(nowDate);

		return (domain.updateHistoryWarranty(dto));
	}

	/**
	 * Delete an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pVin
	 *            the V.I.N.
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean deleteHistoryWarranty(String pVin) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryWarrantyDto dto = new MpHistoryWarrantyDto();

		dto.setVin(pVin);

		return (domain.deleteHistoryWarranty(dto));
	}

	/**
	 * Get the list of config saved for a V.I.N.
	 * 
	 * @param pVin the V.I.N.
	 * @param pLanguageId the language identifier of request information
	 * 
	 * @return a list of configs
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static List<MpHistoryConfigDto> getHistoryConfigs(List<String> lstPinVin, String pLanguageId) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryConfigDto dto = new MpHistoryConfigDto();

		return (domain.readListHistoryConfig(dto, pLanguageId, lstPinVin));
	}

	/**
	 * Delete a history config.
	 * 
	 * @param pDto config to delete
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public static boolean deleteHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		return (domain.deleteHistoryConfig(pDto));
	}

	/**
	 * Update a history config.
	 * 
	 * @param pDto the config
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public static boolean updateHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		return (domain.updateHistoryConfig(pDto));
	}

	/**
	 * Save (add to db) a history config.
	 * 
	 * @param pDto the config
	 * @return the request result
	 * @throws SystemException cannot execute query or access to database
	 */
	public static boolean addHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		return (domain.addHistoryConfig(pDto));
	}

	/**
	 * Select a list of interactive maintenance plan interval history without claim in the database for a vin.
	 * 
	 * @param vin
	 *            the vin
	 * @param filterOrigin
	 *            the filterOrigin
	 * @param dateFrom
	 *            the date of history beginning
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public static List<MpHistoryIntervalDto> readListWithoutClaim(String vin) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		List<MpHistoryIntervalDto> returnList = new ArrayList<MpHistoryIntervalDto>();
		MpIntervalComparator comparator = new MpIntervalComparator();
		String currentCode = "";

		List<MpHistoryIntervalDto> list = domain.readListWithoutClaim(vin);
		Collections.sort(list, comparator);

		for (MpHistoryIntervalDto histo : list)
		{
			//get the last history SAP 
			if (!currentCode.equals(histo.getIntervalCode()))
			{
				returnList.add(histo);
			}
			currentCode = histo.getIntervalCode();
		}
		return returnList;
	}

	/**
	 * Select the VIN without sap claim.
	 * 
	 * @return the request result
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> getVinWithoutSapClaim() throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		List<MpHistoryIntervalDto> returnList = new ArrayList<MpHistoryIntervalDto>();

		returnList = domain.getVinWithoutSapClaim();

		return returnList;
	}

	/**
	 * Get the tolerance for M1 .
	 * 
	 * @param planId : plan Id to find
	 * @return the tolerance for M1
	 * @throws SystemException SystemException
	 */
	public MpIntervalDto getCouponTolerance(Long planId) throws SystemException {
		return new MpIntervalDomain().getCouponTolerance(planId.toString());
	}

	/**
	 * Return true if there is a UCR history for a PIN/VIN.
	 * 
	 * @param isIveco true if the customer is CV
	 * @param pinVin the PIN for AG&CE or VIN for CV.
	 * @return true if there is a UCR history for a PIN/VIN
	 * @throws SystemException SystemException
	 */
	public boolean hasUcrHistoryByVin(boolean isIveco, String pinVin) throws SystemException {
		boolean result = false;

		if (!isIveco)
		{
			List<MpHistoryIntervalDto> returnList = new MpIntervalDomain().getHistoryByVinAndOrigin(pinVin, MpHistoryOrigin.UCR.getValue());

			if (!returnList.isEmpty())
			{
				result = true;
			}
		}

		return result;
	}

	/**
	 * Update the failure date of a claim.
	 * 
	 * @param idToUpdate claim id
	 * @param timestampFailure failure date in milliseconds
	 * @param vin VIN
	 */
	public void updateFailureDateForClaim(String idToUpdate, long timestampFailure, String vin) throws SystemException {
		new MpIntervalDomain().updateFailureDateForClaim(idToUpdate, timestampFailure, vin);
	}

	/**
	 * Get all the coupons with the description of the coupons by language.
	 * 
	 * @param lang the language
	 * @param famGroupIceCode family and group icecode concatenated.
	 * @return the list of coupons.
	 * @throws SystemException
	 */
	public List<MpIntervalDto> getAllCouponsByLang(String lang, String famGroupIceCode) throws SystemException {
		return new MpIntervalDomain().getAllCouponsByLang(lang, famGroupIceCode);
	}

	/**
	 * Get the maxEngineHour from a list of intervals for the last month of each interval
	 * 
	 * @param lstPinVin
	 * @param extPlanId
	 * @return String
	 */
	public static MpHistoryIntervalDto getMaxEngineHour(List<String> lstPinVin, Long extPlanId) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		MpHistoryIntervalDto dto = new MpHistoryIntervalDto(null, null, lstPinVin, null, extPlanId, null);

		return (domain.getMaxEngineHour(dto));
	}

	public boolean postCheckAndUpdateIfNecessary(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();

		if (domain.shouldUpdateHoursHistoryInterval(sapDto))
		{
			return domain.executeUpdateHoursHistoryInterval(sapDto, secondToMatch);
		}
		return false;
	}

	/**
	 * Function which will retrieve the history intervals for the maintenance history export cron job of 22:00 P.M.
	 * 
	 * @param lastExportDate The last export date from which to retrieve the records.
	 * @return List of the retrieved history interval dtos.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpHistoryIntervalDto> getCouponsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		MpIntervalDomain domain = new MpIntervalDomain();
		return domain.getCouponsForCsvExport(lastExportDate, firstExportDate);

	}
}
