/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpKitCompositionDomain;
import capgemini.cnh.mpbusiness.dto.MpKitCompositionDto;

/**
 *
 * Maintenance Plan.
 *
 * @author MAY
 *
 *
 */
public class MpKitCompositionBusiness extends Business {

	/**
	 * Constructor.
	 */
	public MpKitCompositionBusiness() {
		super();
	}

	/**
	 * Get the kit composition.
	 * 
	 * @param selectedKitId for filter
	 * @return a list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpKitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException, ApplicativeException {
		return (new MpKitCompositionDomain()).getPartsListByKit(selectedKitId);
	}

}
