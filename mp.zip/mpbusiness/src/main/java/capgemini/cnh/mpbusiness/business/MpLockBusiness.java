package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpLockDomain;
import capgemini.cnh.mpbusiness.dto.MpLockDto;

/**
 * 
 * @author cblois
 *
 */
public class MpLockBusiness extends Business {
	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpLockBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}


	/**
	 * Constructor.
	 * 
	 */
	public MpLockBusiness() {
		super();
	}

	/**
	 * Add MP lock in database.
	 * 
	 * @param vin : a vin to be inserted
	 * @param enabled : if true try to add a lock, else do not add a lock
	 * @return true if row inserted so that means update can be proceeded
	 */
	public boolean addMpLock(String vin, boolean enabled) {
		boolean added = false;
		if (enabled)
		{
			try
			{
				added = (new MpLockDomain()).addMpLock(vin);
			}
			catch (SystemException | ApplicativeException e)
			{
				added = false;
			}
		}
		else
		{
			added = true;
		}
		
		return added;
	}

	/**
	 * Remove MP lock in database.
	 * 
	 * @param vin : a vin
	 * @param enabled : if true try to remove a lock, else do not remove a lock
	 * @return true if row removed
	 */
	public boolean removeMpLock(String vin, boolean enabled) {
		boolean added = false;
		if (enabled)
		{
			try
			{
				added = (new MpLockDomain()).removeMpLock(vin);
			}
			catch (SystemException | ApplicativeException e)
			{
				added = false;
			}
		}
		else
		{
			added = true;
		}
		
		return added;
	}

}
