package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.MpFlexCouponDomain;
import capgemini.cnh.mpbusiness.domain.MpFlexDoneDomain;
import capgemini.cnh.mpbusiness.domain.MpNextStopDomain;
import capgemini.cnh.mpbusiness.domain.MpVehicleAverageDomain;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpFlexStopDoneDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.dto.MpVehicleAverageDto;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.mpbusiness.util.ContractVisibility;
import capgemini.cnh.mpbusiness.util.MpNextFlexComparator;

/**
 * @author mmartel
 * 
 */
public class MpNextStopBusiness extends Business {

	/** Define a logger for this class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpNextStopBusiness.class);

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpNextStopBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpNextStopBusiness() throws SystemException {
		super();
	}

	/**
	 * add Mp next stop in database.
	 * 
	 * @param nextStops : next stop in the tolerance (contains not flex and flex coupons)
	 * @param flexToUpdateList : flex to be updated/added
	 * @param heavyFlexContract : if contract is flexible
	 * @param currentVehicleData : current vehicle data used to calculate proposal date
	 * @param warrantyStartDate : warrantyStartDate of the vehicle
	 * @param minNextStop : min next stop initialized : contains also the last current mileage/ last current hour
	 * @param oldMinNextStop : old min next stop initialized : if value are not changed and the current mileage/ last current hour is missing data are not recalculated
	 * @param mpBusiness : contains the tolerance to calculate alert
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStop(List<MpNextStopDto> nextStops, List<MpNextStopDto> flexToUpdateList, ContractVisibility contractVisibility, CurrentVehicleDataDto currentVehicleData,
			Long warrantyStartDate, MpNextStopMinDto minNextStop, MpNextStopMinDto oldMinNextStop, MaintenancePlanBusiness mpBusiness, List<String> lstPinVin)
			throws SystemException {
		Long result = null;
		//MML TO BE DONE
		//add in table MpNextStopDto
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		if (nextStops != null && !nextStops.isEmpty())
		{
			domain.deleteNextStop(lstPinVin);
			if (!contractVisibility.hasComponentFlexible() && !contractVisibility.hasProposalDateAndAlert())
			{ // For classic contract
				for (MpNextStopDto nextStop : nextStops)
				{
					domain.addNextStop(nextStop);
				}
			}
			else if (!contractVisibility.hasComponentFlexible() && contractVisibility.hasProposalDateAndAlert())
			{ // For targa contract

				// get next stop not flexible
				for (MpNextStopDto nextStop : nextStops)
				{
					//get the smallest coupon
					for (MpType type : MpType.values())
					{
						if (nextStop.getNextValue(type) != null && nextStop.getNextValue(type) != 0
								&& (minNextStop.getNextValue(type) == null || nextStop.getNextValue(type) < minNextStop.getNextValue(type)))
						{
							minNextStop.setNextValue(type, nextStop.getNextValue(type));
						}
					}

					domain.addNextStop(nextStop);

				}

				mpBusiness.calculateProposalDate(currentVehicleData, minNextStop, warrantyStartDate, oldMinNextStop);
				//MML TODO recalculate alert (need to have the tolerance)
				mpBusiness.calculateAlert(minNextStop);

				//update call status
				updateCallStatus(minNextStop, oldMinNextStop);
				//update group alert id only if there is alert (attention should be called after calculateAlert)
				updateAlertGroupId(minNextStop, oldMinNextStop);

				domain.deleteNextStopMin(minNextStop.getVin());
				domain.addNextStopMin(minNextStop);

			}
			else
			{ // For flexible contract

				if (flexToUpdateList != null)
				{
					//TODO MML not modify the external alert
					for (MpNextStopDto nextflexStop : flexToUpdateList)
					{
						if (nextflexStop.getToBeAddedUpdated() == 1)
						{
							domain.addNextStopFlex(nextflexStop);
						}
						else if (nextflexStop.getToBeAddedUpdated() == 2)
						{
							domain.updateNextStopFlex(nextflexStop);
						}

					}
				}
				// get next stop not flexible

				for (MpNextStopDto nextStop : nextStops)
				{
					//get the smallest coupon
					for (MpType type : MpType.values())
					{
						if (nextStop.getNextValue(type) != null && nextStop.getNextValue(type) != 0
								&& (minNextStop.getNextValue(type) == null || nextStop.getNextValue(type) < minNextStop.getNextValue(type)))
						{
							minNextStop.setNextValue(type, nextStop.getNextValue(type));
						}
					}

					if (!nextStop.isFlexible() || nextStop.getIntervalCode().equals(Constants.COUPON_FF))
					{
						if (nextStop.getIntervalCode().equals(Constants.COUPON_FF))
						{
							if (nextStop.getNextValue(MpType.MP_MONTH) != null && (!(new Long(0)).equals(nextStop.getNextValue(MpType.MP_MONTH))))
							{
								//record only month value for Fuel Filter component
								MpNextStopDto nextStopFF = new MpNextStopDto(nextStop);
								nextStopFF.setNextValue(MpType.MP_KM, 0L);
								nextStopFF.setProposalDate(MpType.MP_KM, null);
								nextStopFF.setNextValue(MpType.MP_HOUR, 0L);
								nextStopFF.setProposalDate(MpType.MP_HOUR, null);
								domain.addNextStop(nextStopFF);
							}
						}
						else
						{
							domain.addNextStop(nextStop);
						}

					}
				}

				mpBusiness.calculateProposalDate(currentVehicleData, minNextStop, warrantyStartDate, oldMinNextStop);
				//MML TODO recalculate alert (need to have the tolerance)
				mpBusiness.calculateAlert(minNextStop);

				//update call status
				updateCallStatus(minNextStop, oldMinNextStop);
				//update group alert id only if there is alert (attention should be called after calculateAlert)
				updateAlertGroupId(minNextStop, oldMinNextStop);
				domain.deleteNextStopMin(minNextStop.getVin());
				domain.addNextStopMin(minNextStop);

			}

		}
		return result;
	}

	/**
	 * update call status, if call status was at CALLED check must be done to see if it must passed at TO RECALL.
	 * if status doesn't not exist it is set a NOT_CALLED by default
	 */
	public void updateCallStatus(MpNextStopMinDto minNextStop, MpNextStopMinDto oldMinNextStop) throws SystemException {
		//Get all the appointment with the Status called for the group id defined in oldMinNextStop
		//For those appointment put the value to the status TORECALL and update the field 
		if (oldMinNextStop != null)
		{
			List<MpType> mpTypeAlertListOld = getTypeInAlert(oldMinNextStop.getAlertMap());
			List<MpType> mpTypeAlertListNew = getTypeInAlert(minNextStop.getAlertMap());
			boolean toRecall = false;
			for (MpType mpType : mpTypeAlertListOld)
			{
				Long oldValue = oldMinNextStop.getNextValue(mpType);
				Long newValue = minNextStop.getNextValue(mpType);

				if (oldValue != null && newValue != null
						&& mpTypeAlertListNew.contains(mpType) // units still on alert
						&& newValue.longValue() < oldValue.longValue()) // new value updated smaller thant old one
				{
					toRecall = true;
					break;
				}
			}

			// means that a new alert of a new type for a same vin has been created
			if (mpTypeAlertListNew.size() > mpTypeAlertListOld.size() || toRecall)
			{
				new MpAppointmentBusiness().updateAppointementToRecall(oldMinNextStop.getAlertGroupId());
			}
		}

	}

	/**
	 * update alert group id, put the same as the old ones : normally alert group id is always correctly set TIAM (at creation or closure of alerts)
	 * 
	 * @param minNextStop : current min next stop
	 * @return oldMinNextStop : old min next stop
	 */
	public void updateAlertGroupId(MpNextStopMinDto minNextStop, MpNextStopMinDto oldMinNextStop) throws SystemException {

		List<MpType> mpTypeAlertListNew = getTypeInAlert(minNextStop.getAlertMap());
		if (!mpTypeAlertListNew.isEmpty() && oldMinNextStop != null)
		{
			minNextStop.setAlertGroupId(oldMinNextStop.getAlertGroupId());
		}
		if (mpTypeAlertListNew.isEmpty())
		{
			minNextStop.setAlertGroupId(null);
		}
	}

	/**
	 * Recover MpType list to get mp type in alert.
	 * 
	 * @param alert map
	 * @return the value
	 */
	public static List<MpType> getTypeInAlert(Map<MpType, Integer> alert) {
		List<MpType> listMpType = new ArrayList<MpType>();
		for (MpType mpType : alert.keySet())
		{
			boolean isInAlert = (alert.get(mpType).intValue() == 1);
			if (isInAlert)
			{
				listMpType.add(mpType);
			}
		}
		return listMpType;
	}

	/**
	 * add Mp next stop flex in database.
	 * 
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStopFlex(MpNextStopDto nextStops) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		Long result = domain.addNextStopFlex(nextStops);
		return result;
	}

	/**
	 * Get flexible next stop.
	 * 
	 * @param vin : vin to find
	 * @param coupon : coupon code to find
	 * @param fromCroom : 1 external 0 internal
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public boolean existsNextStopFlexible(String coupon, String vin, Integer fromCroom) throws SystemException {
		boolean exists = false;
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		MpNextStopDto mpNextStopDto = domain.getNextStopFlexible(vin, coupon, fromCroom);
		if (null != mpNextStopDto && mpNextStopDto.getIntervalCode().equals(coupon))
		{
			exists = true;
		}
		return exists;
	}

	/**
	 * update Mp next stop flexible in database for alert without mileage.
	 * 
	 * @param vin : vin
	 * @param currentKm : currentKm
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopFlexAlertNoValue(String vin, Long currentKm) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		Long result = domain.updateNextStopFlexAlertNoValue(vin, currentKm);
		return result;
	}

	/**
	 * Update Mp next stop min proposal date and alert.
	 * 
	 * @param minNextStop : to be updated
	 * @param currentVehicleData :current Vehicle Data
	 * @param warrantyStartDate : warrantyStartDate
	 * @param mpBusiness : mp Business
	 * @throws SystemException system exception
	 */
	public void updateMinProposalDateAndAlert(MpNextStopMinDto minNextStop, CurrentVehicleDataDto currentVehicleData, Long warrantyStartDate, MaintenancePlanBusiness mpBusiness)
			throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		if (currentVehicleData != null)
		{
			if (currentVehicleData.getCurrentMileage() != null)
			{
				minNextStop.setCurrentMileage(currentVehicleData.getCurrentMileage());
			}
			if (currentVehicleData.getCurrentMileage() != null)
			{
				minNextStop.setCurrentHour(currentVehicleData.getCurrentHours());
			}
		}
		mpBusiness.calculateProposalDate(currentVehicleData, minNextStop, warrantyStartDate, null);
		mpBusiness.calculateAlert(minNextStop);
		List<MpType> mpTypeAlertListNew = getTypeInAlert(minNextStop.getAlertMap());
		if (mpTypeAlertListNew.isEmpty())
		{
			minNextStop.setAlertGroupId(null);
		}

		domain.updateNextStopMinProposalDate(minNextStop);

	}

	/**
	 * Get next flexible stop not done.
	 * 
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextFlexibleStopNotDone(String vin) throws SystemException {
		return (new MpNextStopDomain().getNextFlexibleStopNotDone(vin));
	}

	/**
	 * Get VIN list with updated plan.
	 * 
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPlan() throws SystemException {
		return (new MpNextStopDomain().getVinWithUpdatedPlan());
	}

	/**
	 * Get VIN list with new plan.
	 * 
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithNewPlan() throws SystemException {
		return (new MpNextStopDomain().getVinWithNewPlan());
	}

	/**
	 * Get VIN list with updated performance EDS.
	 * 
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPerformanceEDS() throws SystemException {
		return (new MpNextStopDomain().getVinWithUpdatedPerformanceEDS());
	}

	/**
	 * Get VIN list with coupon in overdue.
	 * 
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithCouponOverdue() throws SystemException {
		return (new MpNextStopDomain().getVinWithCouponOverdue());
	}

	/**
	 * add Mp flexible stop done in database.
	 * 
	 * @param history : to be inserted
	 * @param flexCoupons : list of flexible coupons
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addFlexStopDone(MpHistoryIntervalDto history, Map<String, MpFlexCouponDto> flexCoupons, Long nowDate) throws SystemException {
		Long result = null;
		//add in table MP_FLEX_DONE_WK
		MpFlexDoneDomain domain = new MpFlexDoneDomain(this.dbAccess);
		MpFlexStopDoneDto addDto;
		if (history != null)
		{

			if (flexCoupons.get(history.getIntervalCode()) != null)
			{
				addDto = new MpFlexStopDoneDto();
				addDto.setIntervalCode(history.getIntervalCode());
				addDto.setVin(history.getVin());
				addDto.setKmDone(history.retreiveFromExactValueByMpType(MpType.MP_KM));
				addDto.setDateDone(new Date(nowDate));
				domain.deleteFlexStopDone(addDto);
				domain.addFlexStopDone(addDto);
			}

		}
		return result;
	}

	/**
	 * add Mp flexible stop done in database.
	 * 
	 * @param history : to be inserted
	 * @param flexCoupons : list of flexible coupons
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long deleteFlexExternalAlert(MpHistoryIntervalDto history, Map<String, MpFlexCouponDto> flexCoupons) throws SystemException {
		Long result = null;
		//delete from table MP_NEXT_STOP_FLEX_WK
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		MpNextStopDto addDto;
		if (history != null)
		{
			if (flexCoupons.get(history.getIntervalCode()) != null)
			{
				addDto = new MpNextStopDto();
				addDto.setIntervalCode(history.getIntervalCode());
				addDto.setVin(history.getVin());
				domain.deleteCouponExternalAlert(addDto);
			}

		}
		return result;
	}

	/**
	 * Get VIN list of coupons flexible.
	 * 
	 * @return list of coupons flexible
	 * @throws SystemException SystemException
	 */
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		return (new MpFlexCouponDomain()).getFlexibleCoupons();
	}

	/**
	 * Update the proposal date into the table .
	 * 
	 * @throws SystemException SystemException
	 */
	public void updateNextStopProposalDate() throws SystemException {
		(new MpNextStopDomain(this.dbAccess)).updateNextStopProposalDate();
	}

	/**
	 * Get next stop .
	 * 
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextStops(List<String> lstPinVin) throws SystemException {
		return (new MpNextStopDomain()).getNextStops(lstPinVin);
	}

	/**
	 * Get next flexible stop in the tolerance .
	 * 
	 * @param vin : vin to find
	 * @param tol : tol for km
	 * @param minNextStop : minNextStop
	 * @return list of next flexible stop in the tolerance
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextStopFlexiblesInTol(String vin, MpNextStopMinDto minNextStop, Long tol) throws SystemException {
		List<MpNextStopDto> result = new ArrayList<>();

		List<MpNextStopDto> listNext = new MpNextStopDomain().getAllNextStopFlexibles(vin);
		Long minNextKm = minNextStop.getNextValue(MpType.MP_KM);
		if (minNextKm == null) //should not happen
		{
			minNextKm = 0L;
		}
		Long limit = Constants.DEFAULT_VALUE_NEXT_STOP;
		if (!(Constants.DEFAULT_VALUE_NEXT_STOP).equals(minNextKm))
		{
			limit = minNextKm + tol;
			if (minNextStop.getCurrentMileage() != null)
			{
				limit = Math.max(minNextKm, minNextStop.getCurrentMileage()) + tol;
			}
		}
		else
		{
			if (minNextStop.getCurrentMileage() != null)
			{
				limit = minNextStop.getCurrentMileage() + tol;
			}
		}
		//sort by coupon and then by km (null is first)
		//keep the mimimum between coupon in alert from CR and alert calculated by EDS
		String previousCouponCode = null;
		Collections.sort(listNext, new MpNextFlexComparator());
		for (MpNextStopDto nextStop : listNext)
		{
			if (previousCouponCode != null && previousCouponCode.equals(nextStop.getIntervalCode()))
			{
				continue;
			}
			else if (nextStop.getNextValue(MpType.MP_KM) == null || nextStop.getNextValue(MpType.MP_KM) <= limit)
			{
				result.add(nextStop);
			}
			previousCouponCode = nextStop.getIntervalCode();
		}
		return result;

	}

	/**
	 * Get all next flexible stop .
	 * 
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getAllNextStopFlexibles(String vin) throws SystemException {
		return (new MpNextStopDomain(this.dbAccess)).getAllNextStopFlexibles(vin);
	}

	/**
	 * Get next flexible stop without doublon (min between alert and EDS).
	 * 
	 * @param nextFlexStops : nextFlexStops
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextStopFlexiblesNoDoublon(List<MpNextStopDto> nextFlexStops) {
		//if there is alert keep only the minimum between coupon with alert from CR and coupon from EDS
		//if no value for next km, get alert
		//sort by coupon and then by km (null is first)
		String previousCouponCode = null;
		Collections.sort(nextFlexStops, new MpNextFlexComparator());
		for (ListIterator<MpNextStopDto> it = nextFlexStops.listIterator(); it.hasNext();)
		{
			MpNextStopDto element = it.next();
			if (previousCouponCode != null && previousCouponCode.equals(element.getIntervalCode()))
			{
				it.remove();
			}
			previousCouponCode = element.getIntervalCode();
		}
		return nextFlexStops;
	}

	/**
	 * Get min next stop.
	 * 
	 * @param vin : vin to find
	 * @return min next stop
	 * @throws SystemException SystemException
	 */
	public MpNextStopMinDto getMpNextStopMin(List<String> lstPinVin) throws SystemException {
		return (new MpNextStopDomain()).getMpNextStopMin(lstPinVin);
	}

	/**
	 * Check if plan changed .
	 * 
	 * @param vin : vin to find
	 * @param planId : planId to find
	 * @return true if plan change
	 * @throws SystemException SystemException
	 */
	public boolean checkPlanChange(List<String> lstPinVin, Long planId) throws SystemException {
		return (new MpNextStopDomain()).checkPlanChange(lstPinVin, planId);
	}

	/**
	 * Set the flag to 1 for new KM alerts.
	 * 
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewKmAlerts() throws SystemException {
		(new MpNextStopDomain(this.dbAccess)).setFlagForNewKmAlerts();
	}

	/**
	 * Set the flag to 1 for new hour alerts.
	 * 
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewHourAlerts() throws SystemException {
		(new MpNextStopDomain(this.dbAccess)).setFlagForNewHourAlerts();
	}

	/**
	 * Set the flag to 1 for new KM alerts.
	 * 
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewMonthAlerts() throws SystemException {
		(new MpNextStopDomain(this.dbAccess)).setFlagForNewMonthAlerts();
	}

	/**
	 * 
	 * Get the list of VIN-COUPON in alerts.
	 * 
	 * @param alertType: the alertType
	 * @param isFlexibleCoupons: true if we want to get flexible coupons (MP_NEXT_FLEX_STOP_WK table)
	 * @return the list of VIN-COUPON in alerts.
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopAlertDto> getCouponInAlert(MpType alertType, boolean isFlexibleCoupons) throws SystemException {
		return (new MpNextStopDomain()).getCouponInAlert(alertType, isFlexibleCoupons);
	}

	/**
	 * Get the vehicle values for a vin.
	 * 
	 * @param vin : vin
	 * @return a vehicleAverage dto
	 * @throws SystemException system exception
	 */
	public MpVehicleAverageDto getVehicleAverageForVin(String vin) throws SystemException {
		return (new MpVehicleAverageDomain()).getVehicleAverageForVin(vin);
	}

	/**
	 * delete Mp next stop in database for one vin.
	 * 
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteNextStop(List<String> lstPinVin) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		return domain.deleteNextStop(lstPinVin);
	}

	/**
	 * delete Mp next stop min in database for one vin.
	 * 
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteNextStopMin(String vin) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		return domain.deleteNextStopMin(vin);
	}

	/**
	 * delete Mp next flex stop min in database for one vin.
	 * 
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteNextFlexStop(String vin) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain(this.dbAccess);
		return domain.deleteNextStopFlexible(vin);
	}

	/**
	 * Merge Mp Next Stop alert list to one list.
	 * 
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public List<MpNextStopAlertDto> mergeMpNextStopAlertLists(List<MpNextStopAlertDto> mpAlertListKmToMerge, List<MpNextStopAlertDto> mpAlertListHourToMerge,
			List<MpNextStopAlertDto> mpAlertListMonthToMerge, List<MpNextStopAlertDto> mpFlexAlertListKmToMerge) throws SystemException {

		List<MpNextStopAlertDto> mpAlertList = new ArrayList<MpNextStopAlertDto>();

		//For each alert in mpAlertListKmToMerge, we check if the same VIN/coupon is present in others list to merge in one MpNextStopAlertDto 
		for (MpNextStopAlertDto mpNextStopAlertDto : mpAlertListKmToMerge)
		{
			if (mpAlertListHourToMerge.contains(mpNextStopAlertDto))
			{
				Iterator<MpNextStopAlertDto> iter = mpAlertListHourToMerge.iterator();

				while (iter.hasNext())
				{
					MpNextStopAlertDto mpAlertHour = iter.next();

					//Check if the same VIN/COUPON is present into the hour list to merge it
					if (mpAlertHour.equals(mpNextStopAlertDto))
					{
						mpNextStopAlertDto.merge(mpAlertHour);
						break;
					}
				}
			}

			if (mpAlertListMonthToMerge.contains(mpNextStopAlertDto))
			{
				Iterator<MpNextStopAlertDto> iter = mpAlertListMonthToMerge.iterator();

				while (iter.hasNext())
				{
					MpNextStopAlertDto mpAlertMonth = iter.next();

					//Check if the same VIN/COUPON is present into the month list to merge it
					if (mpAlertMonth.equals(mpNextStopAlertDto))
					{
						mpNextStopAlertDto.merge(mpAlertMonth);
						break;
					}
				}
			}

			if (mpFlexAlertListKmToMerge.contains(mpNextStopAlertDto))
			{
				Iterator<MpNextStopAlertDto> iter = mpFlexAlertListKmToMerge.iterator();

				while (iter.hasNext())
				{
					MpNextStopAlertDto mpFlexAlertKm = iter.next();

					//Check if the same VIN/COUPON is present into the flex km list to merge it
					if (mpFlexAlertKm.equals(mpNextStopAlertDto))
					{
						mpNextStopAlertDto.merge(mpFlexAlertKm);
						break;
					}
				}
			}

			mpAlertList.add(mpNextStopAlertDto);
		}

		// For each alert in mpAlertListHourToMerge, we check if the same VIN/coupon is present in others list (global list, month list and flex km list)
		// to merge in one MpNextStopAlertDto 
		for (MpNextStopAlertDto mpNextStopAlertDto : mpAlertListHourToMerge)
		{

			//We check if the object is not into the global list (if present, it's already processed)
			if (!mpAlertList.contains(mpNextStopAlertDto))
			{
				if (mpAlertListMonthToMerge.contains(mpNextStopAlertDto))
				{
					Iterator<MpNextStopAlertDto> iter = mpAlertListMonthToMerge.iterator();

					while (iter.hasNext())
					{
						MpNextStopAlertDto mpAlertMonth = iter.next();

						//Check if the same VIN/COUPON is present into the month list to merge it
						if (mpAlertMonth.equals(mpNextStopAlertDto))
						{
							mpNextStopAlertDto.merge(mpAlertMonth);
							break;
						}
					}
				}

				if (mpFlexAlertListKmToMerge.contains(mpNextStopAlertDto))
				{
					Iterator<MpNextStopAlertDto> iter = mpFlexAlertListKmToMerge.iterator();

					while (iter.hasNext())
					{
						MpNextStopAlertDto mpFlexAlertKm = iter.next();

						//Check if the same VIN/COUPON is present into the flex km list to merge it
						if (mpFlexAlertKm.equals(mpNextStopAlertDto))
						{
							mpNextStopAlertDto.merge(mpFlexAlertKm);
							break;
						}
					}
				}

				mpAlertList.add(mpNextStopAlertDto);
			}
		}

		// For each alert in mpAlertListMonthToMerge, we check if the same VIN/coupon is present in others list (global list and flex km list)
		// If yes, we do nothing because it 
		for (MpNextStopAlertDto mpNextStopAlertDto : mpAlertListMonthToMerge)
		{
			if (!mpAlertList.contains(mpNextStopAlertDto))
			{
				if (mpFlexAlertListKmToMerge.contains(mpNextStopAlertDto))
				{
					Iterator<MpNextStopAlertDto> iter = mpFlexAlertListKmToMerge.iterator();

					while (iter.hasNext())
					{
						MpNextStopAlertDto mpFlexAlertKm = iter.next();

						//Check if the same VIN/COUPON is present into the flex km list to merge it
						if (mpFlexAlertKm.equals(mpNextStopAlertDto))
						{
							mpNextStopAlertDto.merge(mpFlexAlertKm);
							break;
						}
					}
				}

				mpAlertList.add(mpNextStopAlertDto);
			}
		}

		// For each alert in mpFlexAlertListKmToMerge, we check if the same VIN/coupon is present in the global list 
		// If yes, we do nothing because it 
		for (MpNextStopAlertDto mpNextStopAlertDto : mpFlexAlertListKmToMerge)
		{
			if (!mpAlertList.contains(mpNextStopAlertDto))
			{
				mpAlertList.add(mpNextStopAlertDto);
			}
		}

		return mpAlertList;
	}

	/**
	 * Get next stop .
	 * 
	 * @param vin : vin to find
	 * @param coupon : coupon code to find
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public MpNextStopDto getNextStop(String vin, String coupon) throws SystemException {
		MpNextStopDomain domain = new MpNextStopDomain();
		return domain.getNextStop(vin, coupon);
	}

	/**
	 * Get min next stop with last mileage.
	 * 
	 * @param vin : vin to find
	 * @return min next stop
	 * @throws SystemException SystemException
	 */
	public MpNextStopMinDto getMpNextStopMinWithLastMileage(String vin) throws SystemException {
		return (new MpNextStopDomain()).getMpNextStopMinWithLastMileage(vin);
	}

	/**
	 * Get min next stop with last mileage.
	 * 
	 * @param vin : vin to find
	 * @return min next stop
	 * @throws SystemException SystemException
	 */
	public boolean updateCallStatusByVin(String vin, Integer mpCallStatusValue) throws SystemException {
		return (new MpNextStopDomain()).updateCallStatusByVin(vin, mpCallStatusValue);
	}

	/**
	 * Get the min proposal date by vin.
	 * 
	 * @param vins the vins
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<String, Date> getProposalDateByVin(Set<String> vins) throws SystemException {
		return (new MpNextStopDomain()).getProposalDateByVin(vins);
	}

	/**
	 * Get the min proposal date by vin. (called by MpServices)
	 * Vins not identified for the recreation of alert but in alert.
	 * 
	 * @param vins the vins already recreated
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<String, Date> getProposalDateByVinInAlertNotInVins(Set<String> vins) throws SystemException {
		return (new MpNextStopDomain()).getProposalDateByVinInAlertNotInVins(vins);
	}

}
