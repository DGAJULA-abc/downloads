/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.domain.MpOperationDomain;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;
import capgemini.cnh.mpbusiness.dto.MpOperationDto;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;

/**
 * @author mamestoy
 *
 */
public class MpOperationBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of operations by plan and intervals.
	 * 
	 * @param planId to filter
	 * @param intervalId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getListOperations(String intervalId, String language, String defaultLanguage) throws SystemException {

		List<MpIntervalOperationDto> resultList = new MpOperationDomain().getListOperations(intervalId, language, defaultLanguage);

		this.manageTranslationsForOperations(resultList, language, defaultLanguage);

		return resultList;
	}

	/**
	 * Get the operation by operation series id.
	 * 
	 * @param planId to filter
	 * @param intervalId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getOperation(Long operationSeriesId, String language, String defaultLanguage)
			throws SystemException {

		List<MpIntervalOperationDto> resultList = new MpOperationDomain().getOperation(operationSeriesId, language,
				defaultLanguage);

		this.manageTranslationsForOperations(resultList, language, defaultLanguage);

		return resultList;
	}

	/**
	 * Manage the translations of the operations.
	 * 
	 * @param resultList the list of operations
	 * @param language language
	 * @param defaultLanguage default language
	 * @throws SystemException SystemException
	 */
	private void manageTranslationsForOperations(List<MpIntervalOperationDto> resultList, String language,
			String defaultLanguage) throws SystemException {
		List<MpIntervalOperationDto> opWithDescriptionList = new ArrayList<>();

		// Create a list with the operations that have a secondary description id
		for (MpIntervalOperationDto operation : resultList)
		{
			if (operation.getOperationLabelForSeriesId() != null)
			{
				opWithDescriptionList.add(operation);
			}
		}

		// Get the label from MP_OPERATION_TITLE
		if (!opWithDescriptionList.isEmpty())
		{
			for (MpIntervalOperationDto operation : opWithDescriptionList)
			{
				List<MpIntervalOperationDto> opWithSeriesLabel = new MpOperationDomain()
						.getOperationWithSeriesLabel(operation, language, defaultLanguage);

				if (!opWithSeriesLabel.isEmpty())
				{
					for (MpIntervalOperationDto op : resultList)
					{
						if (op.getIdOperationSeries().compareTo(opWithSeriesLabel.get(0).getIdOperationSeries()) == 0)
						{
							// Get the only result retrieved
							op.setOperationLabelForSeries(opWithSeriesLabel.get(0).getOperationLabelForSeries());
						}
					}
				}
			}
		}
	}

	/**
	 * Get the operations for an interval of a maintenance plan.
	 * 
	 * @param intervalDto the interval
	 * @param context the user Ice context
	 * @param defaultLanguage the default language
	 * @param productConfiguration the product configuration
	 * @param planId the maintenance plan id
	 * 
	 * @return the operations
	 * @throws SystemException a system exception
	 * @throws ApplicativeException an applicative exception
	 */
	public static List<MpOperationDto> getOperation(MpIntervalDto intervalDto, IceContextDto context,
			String defaultLanguage, ProductConfiguration productConfiguration, String planId)
			throws SystemException, ApplicativeException {
		List<MpOperationDto> mpOpIntList = new ArrayList<>();
		List<MpIntervalOperationDto> listOp = (new MpOperationBusiness()).getListOperations(intervalDto.getId().toString()/* pInterval */, context.getLanguage().getIdlanguage(), defaultLanguage);
		if (listOp != null && !listOp.isEmpty())
		{
			for (MpIntervalOperationDto dto : listOp)
			{
				MpOperationDto mpOperationDto = new MpOperationDto();

				///////////// CONSUMABLES
				List<MpOperationConsumableDto> listOpCons = MpOperationConsumableBusiness
						.getListConsumablesByOp(dto.getIdOperationSeries(), context, productConfiguration);
				///////////// PARTS
				List<MpOperationPartDto> listOpParts = MpOperationPartBusiness
						.getListPartsByOp(dto.getIdOperationSeries().toString(), context, productConfiguration);

				// Operations
				if (dto.getSrtOperation() != null)
				{
					mpOperationDto.setSrtOperation(dto.getSrtOperation());
				}
				else if (dto.getMicroOperation() != null)
				{
					mpOperationDto.setMicroOperation(dto.getMicroOperation());
				}
				mpOperationDto.setOperationLabelId(dto.getOperationLabelId());
				mpOperationDto.setOperationDescriptionId(dto.getOperationDescriptionId());
				mpOperationDto.setOperationDescription(dto.getOperationDescription());
				mpOperationDto.setOperationLabel(dto.getOperationLabel());
				mpOperationDto.setOperationLabelForSeriesId(dto.getOperationLabelForSeriesId());
				mpOperationDto.setOperationLabelForSeries(dto.getOperationLabelForSeries());
				mpOperationDto.setIceCode(dto.getIceCode());
				mpOperationDto.setRepairTime(dto.getRepairTime());

				// Consumables attached to the operation
				mpOperationDto.setConsumables(new ArrayList<MpOperationConsumableDto>());
				mpOperationDto.getConsumables().addAll(new HashSet<>(listOpCons));

				// Parts attached to the operation
				mpOperationDto.setParts(new ArrayList<MpOperationPartDto>());
				mpOperationDto.getParts().addAll(new HashSet<>(listOpParts));

				mpOpIntList.add(mpOperationDto);

			}
		}
		return mpOpIntList;
	}

}
