/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;
import java.util.ListIterator;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.LanguageDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.domain.MpOperationConsumableDomain;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;

/**
 * @author mamestoy
 *
 */
public class MpOperationConsumableBusiness extends Business {

	private static final String ALL_VALUES = "-1";

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationConsumableBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param context filter on context
	 * @param productConfiguration current product configuration
	 * 
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public static List<MpOperationConsumableDto> getListConsumablesByOp(Long idSeriesOperation, IceContextDto context,
			ProductConfiguration productConfiguration) throws SystemException, ApplicativeException {

		String defaultLanguage = context.getDefaultLanguage();
		if (defaultLanguage == null)
		{
			defaultLanguage = LanguageDto.valueOfDefault().getIdlanguage();
		}
		String language = context.getLanguage().getIdlanguage();
		Long brandId = context.getBrand().getId();

		MpOperationConsumableDomain domain = new MpOperationConsumableDomain();

		List<MpOperationConsumableDto> consumableList = domain.getListConsumablesByOp(idSeriesOperation, language, defaultLanguage, brandId, context);

		// -- remove non-applicable parts
		for (ListIterator<MpOperationConsumableDto> it = consumableList.listIterator(); it.hasNext();)
		{
			if (!it.next().isApplicable(productConfiguration))
			{
				it.remove();
			}
		}

		return consumableList;
	}

	/**
	 * Get part number and occurrences name by consumable id and language.
	 * 
	 * @param consId consId
	 * @param language language
	 * @param isUsingDefaultLanguage defaultLanguage
	 * @param dtoIceContext dtoIceContext
	 * @return MpOperationConsumableDto dto
	 * @throws SystemException SystemException
	 */
	public static MpOperationConsumableDto getConsPnByConsId(Long consId, Long consOccId, String country, String marketId) throws SystemException {

		//Filter by country and by Market 11
		MpOperationConsumableDto mpOperationConsumableDto = new MpOperationConsumableDomain().getConsumablesPnByConsIdAndCountryAndMarket(consId, consOccId, country, marketId);

		//if no consumable found, filter by market only 01
		if (mpOperationConsumableDto == null)
		{
			mpOperationConsumableDto = new MpOperationConsumableDomain().getConsumablesPnByConsIdAndCountryAndMarket(consId, consOccId, ALL_VALUES, marketId);

			//if no consumable found, filter by all country and all Market 00
			if (mpOperationConsumableDto == null)
			{
				mpOperationConsumableDto = new MpOperationConsumableDomain().getConsumablesPnByConsIdAndCountryAndMarket(consId, consOccId, ALL_VALUES, ALL_VALUES);
			}
		}

		return mpOperationConsumableDto;
	}

	/**
	 * Get Occurrence Id and Part Number based on Conusmable Id and Context.
	 * 
	 * @param consId
	 * @param defaultLanguage
	 * @param dtoIceContext
	 * @return
	 * @throws SystemException
	 */
	public MpOperationConsumableDto getConsumablesOccByConsId(Long consId, boolean defaultLanguage, IceContextDto dtoIceContext) throws SystemException {
		return new MpOperationConsumableDomain().getConsumablesOccByConsId(consId, defaultLanguage, dtoIceContext);
	}

}
