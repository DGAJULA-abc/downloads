/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpOperationIuLinkDomain;
import capgemini.cnh.mpbusiness.dto.MpOperationIuLinkDto;

/**
 * @author mamestoy
 *
 */
public class MpOperationIuLinkBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationIuLinkBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of IU Links for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @return the list of IUs
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public static List<MpOperationIuLinkDto> getListIusByOp(String idSeriesOperation) throws SystemException, ApplicativeException {
		List<MpOperationIuLinkDto> iuLinksList = new MpOperationIuLinkDomain().getListIusByOp(Long.parseLong(idSeriesOperation));
		return iuLinksList;
	}

}
