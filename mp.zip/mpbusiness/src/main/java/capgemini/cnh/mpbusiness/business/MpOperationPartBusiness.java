/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;
import java.util.ListIterator;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.domain.MpOperationPartDomain;
import capgemini.cnh.mpbusiness.domain.MpPartDetailDomain;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;

/**
 * @author mamestoy
 *
 */
public class MpOperationPartBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpOperationPartBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param context context
	 * @param productConfiguration the current product configuration
	 * 
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public static List<MpOperationPartDto> getListPartsByOp(String idSeriesOperation, IceContextDto context, ProductConfiguration productConfiguration) throws SystemException, ApplicativeException {
		List<MpOperationPartDto> partList = new MpOperationPartDomain().getListPartsByOp(idSeriesOperation, context);
		// -- remove non-applicable parts
		for (ListIterator<MpOperationPartDto> it = partList.listIterator(); it.hasNext();)
		{
			if (it.next().isApplicable(productConfiguration) == false)
			{
				it.remove();
			}
		}
		return partList;
	}

	/**
	 * Get the List of parts for a given part for all the languages.
	 * 
	 * @param code the part code
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPartDescriptionDto> getPartsByCode(String code) throws SystemException {
		return (new MpOperationPartDomain()).getPartsByCode(code);
	}

	/**
	 * Get the part for a given part and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public MpPartDescriptionDto getPartsByCodeAndLanguage(String code, String language) throws SystemException {
		return (new MpOperationPartDomain()).getPartsByCodeAndLanguage(code, language);
	}

	/**
	 * Get the part for a given part list and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public List<MpPartDescriptionDto> getPartsDescriptionByLanguage(List<String> partList, String language) throws SystemException {
		return (new MpOperationPartDomain()).getPartsDescriptionByLanguage(partList, language);
	}

	/**
	 * Get the List of parts for label for a list of parts.
	 * 
	 * @param partList the part list
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpOperationPartDto> getParts(List<String> partList) throws SystemException {
		return (new MpOperationPartDomain()).getParts(partList);
	}

	/**
	 * Get the pars label .
	 * 
	 * @param part the part
	 * @return the parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpOperationPartDto getPart(String part) throws SystemException {
		return (new MpOperationPartDomain()).getPart(part);
	}

	/**
	 * Get the part in table MP_PART_NUMBER_DETAIL .
	 * 
	 * @param part the part
	 * @return the parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPartDetailDto getPartDetail(String part) throws SystemException, ApplicativeException {
		return (new MpPartDetailDomain()).getPartDetail(part);
	}

}
