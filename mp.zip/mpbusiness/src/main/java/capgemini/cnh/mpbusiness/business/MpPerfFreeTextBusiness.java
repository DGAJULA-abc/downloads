/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpPerfFreeTextDomain;
import capgemini.cnh.mpbusiness.dto.MpPerfFreeTextDto;

/**
 * @author pospital
 *
 */
public class MpPerfFreeTextBusiness extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpPerfFreeTextBusiness(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpPerfFreeTextBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the free text performances for a series.
	 * 
	 * @param planId the plan id
	 * @return the list of all the free text performances for a series.
	 * @throws SystemException SystemException
	 */
	public List<MpPerfFreeTextDto> getPerformancesForSeries(String planId, String language) throws SystemException {
		return (new MpPerfFreeTextDomain()).getPerformancesForSeries(planId, language);
	}
}
