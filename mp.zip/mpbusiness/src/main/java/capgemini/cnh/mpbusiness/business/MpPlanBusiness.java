/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.FormatUtil;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.ice.dto.product.SeriesDto;
import capgemini.cnh.mpbusiness.domain.MpContractConfigurationDomain;
import capgemini.cnh.mpbusiness.domain.MpContractVehicleDomain;
import capgemini.cnh.mpbusiness.domain.MpPlanDomain;
import capgemini.cnh.mpbusiness.dto.MpContractConfigurationDto;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpProjectDocumentDto;
import capgemini.cnh.mpbusiness.util.Constants;
import capgemini.cnh.ticd.component.util.Constantes;
import capgemini.cnh.ticd.component.util.UtilDate;

/**
 * @author pospital
 *
 */
public class MpPlanBusiness extends Business {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpPlanBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpPlanBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the plan list by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * @param productConfiguration filter on product configuration
	 * 
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getListByProjectList(List<Integer> projectIdList, IceContextDto context, ProductConfiguration productConfiguration)
			throws SystemException, ApplicativeException {

		List<MpPlanDto> planList = (new MpPlanDomain()).getListByProjectList(projectIdList, context);
		// -- [dbabillo][CC] filter on configuration
		for (ListIterator<MpPlanDto> it = planList.listIterator(); it.hasNext();)
		{
			if (it.next().isApplicable(productConfiguration) == false)
			{
				it.remove();
			}
		}
		return planList;
	}

	/**
	 * Get the plan list by project list.
	 * 
	 * @param planList filter on plan list
	 * @param productConfiguration filter on product configuration
	 * 
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getApplicablePLan(List<MpPlanDto> planList, ProductConfiguration productConfiguration)
			throws SystemException, ApplicativeException {
		// -- filter on configuration
		for (ListIterator<MpPlanDto> it = planList.listIterator(); it.hasNext();)
		{
			if (it.next().isApplicable(productConfiguration) == false)
			{
				it.remove();
			}
		}
		return planList;
	}

	//FOR 8.1.1
	/**
	 * Get the plan by id.
	 * 
	 * @param planId filter on plan id
	 * 
	 * @return the plan
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getPlan(Long planId) throws SystemException, ApplicativeException {

		MpPlanDto planDto = (new MpPlanDomain()).getPlan(planId);
		return planDto;
	}

	/**
	 * Get the performance list by plan list.
	 * 
	 * @param planList for filter
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getPerformanceListByPlanList(String planList) throws SystemException, ApplicativeException {
		return (new MpPlanDomain()).getPerformanceListByPlanList(planList);
	}

	public MpPlanDto getPerformanceForPlanId(String planExtId, String projectNumber, String version) throws SystemException {
		return (new MpPlanDomain()).getPerformanceForPlanId(planExtId, projectNumber, version);
	}

	/**
	 * Get the number of plans with hour in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithHour(String planList) throws SystemException, ApplicativeException {
		return (new MpPlanDomain()).getNbPlanWithHour(planList);
	}

	/**
	 * Get the number of plans with mileage in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plans
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithMileage(String planList) throws SystemException, ApplicativeException {
		return (new MpPlanDomain()).getNbPlanWithMileage(planList);
	}

	/**
	 * Get the plan applicable to the criteria.
	 * Filter on usage, performance and configuration.
	 * 
	 * @param planList list of plan
	 * @param usageId usage Id
	 * @param performance performance
	 * @param productConfiguration the current product configuration
	 * 
	 * @return list of plans
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getPlanWithCriteria(List<Long> planList, int usageId, String performance, ProductConfiguration productConfiguration) throws SystemException, ApplicativeException {
		List<MpPlanDto> filteredPlanList = (new MpPlanDomain()).getPlanWithCriteria(planList, usageId, performance);
		// -- [dbabillo][CC] filter on configuration
		for (ListIterator<MpPlanDto> it = filteredPlanList.listIterator(); it.hasNext();)
		{
			MpPlanDto next = it.next();
			// -- plan without configuration are considered applicable
			if (next.hasConfiguration() && next.isApplicable(productConfiguration) == false)
			{
				it.remove();// -- remove non applicable plans from list
			}
		}
		return (filteredPlanList);
	}

	/**
	 * Get the plan applicable given the external plan id.
	 * 
	 * @param extPlanId ext Plan Id
	 * @param productConfiguration the current product configuration
	 * 
	 * @return the plan
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getMpCurrentPlanApplicable(Long extPlanId, ProductConfiguration productConfiguration) throws SystemException, ApplicativeException {
		MpPlanDto planDto = (new MpPlanDomain()).getMpCurrentPlanApplicable(extPlanId);
		MpPlanDto result = null;
		if (planDto != null)
		{
			// -- plan without configuration are considered applicable
			if (!planDto.hasConfiguration() || planDto.isApplicable(productConfiguration))
			{
				result = planDto;
			}
		}
		return result;
	}

	/**
	 * <b>Publication Etim-Offline</b> <br>
	 * get Maintenance Plan By Serie.
	 * 
	 * @param serie serie
	 * @return List of MpPlanDto
	 * @throws SystemException a system exception
	 */
	public List<MpPlanDto> getMaintenancePlanBySerie(SeriesDto serie) throws SystemException {
		return (new MpPlanDomain()).getMaintenancePlanBySerie(serie);
	}

	/**
	 * Get the external plan id.
	 * 
	 * @param planId for filter
	 * @return external plan id
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getExternalPlanId(Long planId) throws SystemException, ApplicativeException {
		return (new MpPlanDomain()).getExternalPlanId(planId);
	}

	/**
	 * Get all the plans for a series.
	 * 
	 * @param brandIcecode
	 * @param typeIcecode
	 * @param productIcecode
	 * @param seriesIcecode
	 * @return
	 * @throws SystemException
	 */
	public List<MpPlanDto> getPlanAndApplicabilityBySeries(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException {
		return new MpPlanDomain().getPlanAndApplicabilityBySeries(brandIcecode, typeIcecode, productIcecode, seriesIcecode);
	}

	/**
	 * <b>Publication Etim-Offline</b> <br>
	 * generate Script.
	 * 
	 * @param serie serie
	 * @param outFile outFile
	 * @param isMysqlFormat isMysqlFormat
	 */
	public void generateMaintenancePlanTablePef(SeriesDto serie, Writer outFile, boolean isMysqlFormat) {
		logger.debug("generateMaintenancePlanTablePef - IN, MySQL = " + isMysqlFormat);

		List<MpPlanDto> listDto = new ArrayList<MpPlanDto>();

		try
		{

			listDto = getMaintenancePlanBySerie(serie);

			StringBuilder out = new StringBuilder();

			out = new StringBuilder();
			out.append("--");
			outFile.write(out.toString());
			outFile.write("\n");
			out = new StringBuilder();

			out.append("insert IGNORE into MP_MAINTENANCE_PLAN ( ")
					.append("PLAN_ID, ")
					.append("PLAN_PROJECT_ID, ")
					.append("PLAN_NAME, ")
					.append("PLAN_STATUS, ")
					.append("PLAN_LAST_MODIFIER, ")
					.append("PLAN_DATE_MODIF, ")
					.append("PLAN_STANDARD, ")
					.append("PLAN_PERF_TYPE, ")
					.append("PLAN_EXT_ID ")
					.append(" ) values (?,?,?,?,?,?,?,?,?) ");// 9 "?"

			outFile.write(out.toString());
			outFile.write("\n");

			Set<String> sortedList = new TreeSet<String>();
			for (MpPlanDto dto : listDto)
			{
				out = new StringBuilder();
				out.append("(")
						.append(dto.getId() + ", ")
						.append(dto.getIdProject() + ", ")
						.append(FormatUtil.formatStringForDatabase(isMysqlFormat, dto.getName()) + ", ")
						.append(dto.getStatus() + ", ")
						.append(FormatUtil.formatStringForDatabase(isMysqlFormat, dto.getLastModifier()) + ", ")
						.append(FormatUtil.formatStringForDatabase(isMysqlFormat, FormatUtil.formatDateMySQL(dto.getModifDate())) + ", ");
				if (dto.getStandard())
				{
					out.append("1, ");
				}
				else
				{
					out.append("0, ");
				}
				out.append(FormatUtil.formatStringForDatabase(isMysqlFormat, dto.getPerformanceId()) + ", ");
				out.append(dto.getExtId());
				out.append(")");

				sortedList.add(out.toString());
			}

			for (String entry : sortedList)
			{//loop temporary Set to guarantee the sorted output and uniqueness
				outFile.write(entry);
				outFile.write("\n");
			}
			out = new StringBuilder();
			out.append("--");

			outFile.write(out.toString());

		}
		catch (IOException e)
		{
			logger.error("generateMaintenancePlanTablePef ERROR " + e);
		}
		catch (SystemException e)
		{
			logger.error("generateMaintenancePlanTablePef ERROR " + e);
		}

	}
	//FOR 8.1.1

	/**
	 * Get the all the contracts for a VIN.
	 * 
	 * @param vin the vehicle number
	 * @param customer
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractDto getAllMpContracts(List<String> lstPinVin, boolean withTolerance, boolean isIveco) throws SystemException, ApplicativeException {

		if (withTolerance)
		{
			return getAllMpContractsWithTolerance(lstPinVin, isIveco);
		}
		else
		{
			return getAllMpContractsWithoutTolerance(lstPinVin, isIveco);
		}

	}

	/**
	 * Get the all the contracts for a VIN.
	 * 
	 * @param vin the vehicle number
	 * @param customer
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractDto getAllMpContractsWithTolerance(List<String> lstPinVin, boolean isIveco) throws SystemException, ApplicativeException {
		//list order by date desc, plan ext id and version desc
		List<MpContractVehicleDto> contractList = new ArrayList<>();

		//Manage VIN 9/17 in Contract
		contractList.addAll((new MpContractVehicleDomain()).getAllMpContracts(lstPinVin));

		MpContractVehicleDto activeMpContract = null;
		List<MpContractVehicleDto> selectedContractList = new ArrayList<>();
		MpContractVehicleDto previousPlan = null;
		int index = 0;
		int nbContract = contractList.size();
		if (nbContract > 0)
		{
			//get active Procare contract, that take place of an active classic contract
			MpContractVehicleDto activeProcareContract = getActiveProcareContract(contractList);

			if (activeProcareContract != null)
			{
				activeMpContract = activeProcareContract;
				selectedContractList.add(activeMpContract);
			}

			for (index = 0; index < nbContract; index++)
			{

				//if the contract is active 
				// CR - The contract should be active 2 months after expiration -
				if (activeMpContract == null && UtilDate.compareDate(contractList.get(index).getContractStartDate(), null, 0, true) <= 0
						&& UtilDate.compareDate(contractList.get(index).getContractEndDate(), null, 2, true) >= 0)
				{
					activeMpContract = contractList.get(index);
					selectedContractList.add(activeMpContract);
				}
				//then get all the previous contracts that are contiguous
				if (activeMpContract != null && !activeMpContract.equals(contractList.get(index)) && previousPlan != null)
				{
					if (!isIveco)
					{
						selectedContractList.add(contractList.get(index));
					}
					else
					{
						if (UtilDate.compareDate(contractList.get(index).getContractEndDate(), previousPlan.getContractStartDate(), 1, false) == 0)
						{
							selectedContractList.add(contractList.get(index));
						}
						else
						{
							break;
						}
					}
				}
				previousPlan = contractList.get(index);
			}
		}

		MpContractDto contract = null;
		if (activeMpContract != null)
		{
			contract = new MpContractDto();
			contract.setActiveMpContract(activeMpContract);
			contract.setWarrantyStartDate(activeMpContract.getWarrantyStartDate());
			contract.setContracts(selectedContractList);
			contract.setAllContracts(contractList);
			//			updateLastContract(contract);
		}

		return contract;
	}

	private MpContractVehicleDto getActiveProcareContract(List<MpContractVehicleDto> contractList) {
		MpContractVehicleDto contract = null;
		Date today = new Date();

		for (MpContractVehicleDto currentContract : contractList)
		{
			Date startDate = currentContract.getContractStartDate();
			Date endDate = currentContract.getContractEndDate();

			if (Constants.WARRANTY_TYPE_CNH_PROCARE.equals(currentContract.getTypeContract())
					&& (startDate.before(today) || startDate.equals(today))
					&& (endDate.equals(today) || endDate.after(today)))
			{
				contract = currentContract;
				break;
			}
		}
		return contract;
	}

	/**
	 * Get the all the contracts for a VIN without Tolerance (used by message calculation).
	 * 
	 * @param vin the vehicle number
	 * @param customer
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractDto getAllMpContractsWithoutTolerance(List<String> lstPinVin, boolean isIveco) throws SystemException, ApplicativeException {
		//list order by date desc, plan ext id and version desc
		List<MpContractVehicleDto> contractList = new ArrayList<>();

		//Manage VIN 9/17 in Contract
		contractList.addAll((new MpContractVehicleDomain()).getAllMpContracts(lstPinVin));

		MpContractVehicleDto activeMpContract = null;
		List<MpContractVehicleDto> selectedContractList = new ArrayList<>();
		MpContractVehicleDto previousPlan = null;
		int index = 0;
		int nbContract = contractList.size();

		Date today = new Date();

		if (nbContract > 0)
		{
			//get active Procare contract, that take place of an active classic contract
			MpContractVehicleDto activeProcareContract = getActiveProcareContract(contractList);

			if (activeProcareContract != null)
			{
				activeMpContract = activeProcareContract;
				selectedContractList.add(activeMpContract);
			}

			for (index = 0; index < nbContract; index++)
			{
				MpContractVehicleDto currentContract = contractList.get(index);

				Date startDate = currentContract.getContractStartDate();
				Date endDate = currentContract.getContractEndDate();

				if (activeMpContract == null
						&& (startDate.before(today) || startDate.equals(today))
						&& (endDate.equals(today) || endDate.after(today)))
				{
					activeMpContract = currentContract;
					selectedContractList.add(activeMpContract);
				}
				//then get all the previous contracts that are contiguous
				if (activeMpContract != null && !activeMpContract.equals(currentContract) && previousPlan != null)
				{
					if (!isIveco)
					{
						selectedContractList.add(currentContract);
					}
					else
					{
						if (UtilDate.compareDate(currentContract.getContractEndDate(), previousPlan.getContractStartDate(), 1, false) == 0)
						{
							selectedContractList.add(currentContract);
						}
						else
						{
							break;
						}
					}
				}
				previousPlan = currentContract;
			}
		}

		MpContractDto contract = new MpContractDto();;
		contract.setAllContracts(contractList);

		if (activeMpContract != null)
		{
			contract.setActiveMpContract(activeMpContract);
			contract.setWarrantyStartDate(activeMpContract.getWarrantyStartDate());
			contract.setContracts(selectedContractList);
			updateLastContract(contract);
		}
		else
		{
			// Used by getTypeOfContractMessage(),
			// Display in eTIM the type of contract to the dealer in order he understands if a claim can be done and if digital claim
			contract.setContracts(contractList);
		}

		return contract;

	}

	/**
	 * Update last contrat .
	 * 
	 * @param context for applicability
	 * @param configuration the product configuration (filter on configuration)
	 * 
	 * @return the list of projects applicable
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public void updateLastContract(MpContractDto contract) throws SystemException, ApplicativeException {

		// get the project with last version of the plan available superior to the SAP version
		//and retrieve the date of publication (the more ancient)
		MpContractVehicleDto activeContract = contract.getActiveMpContract();

		MpPlanDto planDto = (new MpPlanDomain()).getMpIuPublicationDate(activeContract.getPlanExtId(), activeContract.getMpVersion());
		//Remark :  the availability of the IU is not checked :if must be done it is in the MaintenancePlanAction 
		//add a new contract with the last  version
		if (planDto != null)
		{
			Date datePub = UtilDate.getDateDDMMYYYYFromTime(planDto.getModifDate().getTime());
			if (activeContract.getMpVersion().equals(planDto.getProjectVersion()))
			{
				//if the active version is the same as last version on eTIM, need to update the start date of the active plan
				//with the date of the iu publication if the date publication is anterior to the start date of active plan

				if (contract.getContracts().size() > 1)
				{
					MpContractVehicleDto previousContract = contract.getContracts().get(1);

					if (activeContract.getContractStartDate() != null && activeContract.getContractStartDate().after(datePub)
							&& previousContract != null && previousContract.getPlanExtId() != null
							&& previousContract.getPlanExtId().equals(activeContract.getPlanExtId()))
					{
						//if the date publication is after  the start date of previous version
						if (previousContract.getContractStartDate().before(datePub))
						{
							previousContract.setContractEndDate(UtilDate.addDay(datePub, -1));
							activeContract.setContractStartDate(datePub);
						}
						//else, the active contract starts just after the previous contract (the previous contract is not erased in order to avoid
						//recursive cases and because it should be very rare)
						else
						{
							activeContract.setContractStartDate(previousContract.getContractStartDate());
							//remove previous contract
							contract.getContracts().remove(1);
						}
					}
				}
			}
			else
			{
				// update the active contract
				if (activeContract.getContractStartDate().before(datePub))
				{
					MpContractVehicleDto moreRecentContract = new MpContractVehicleDto(activeContract);
					moreRecentContract.setPlanId(planDto.getId());
					moreRecentContract.setMpVersion(planDto.getProjectVersion());

					activeContract.setContractEndDate(UtilDate.addDay(datePub, -1));
					moreRecentContract.setContractStartDate(datePub);

					//set the last version of plan for the active contract
					contract.setActiveMpContract(moreRecentContract);
					contract.getContracts().add(0, moreRecentContract);
				}
				else
				{
					activeContract.setPlanId(planDto.getId());
					activeContract.setMpVersion(planDto.getProjectVersion());

				}
			}
		}

	}

	/**
	 * Get the applicable mp plan from contract.
	 * 
	 * @param vin the vehicle number
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractVehicleDto getMpActiveContract(String vin) throws SystemException, ApplicativeException {
		MpContractVehicleDto contractDto = (new MpContractVehicleDomain()).getMpActiveContract(vin);
		return contractDto;
	}

	/**
	 * Get the configuration linked to a plan under contract.
	 * 
	 * @param contractDto the mp contract
	 * @param isIveco is application CV
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<MpContractConfigurationDto> getMpContractConfiguration(MpContractVehicleDto contractDto, boolean isIveco) throws SystemException, ApplicativeException {
		List<MpContractConfigurationDto> configurations = (new MpContractConfigurationDomain()).getMpContractConfiguration(contractDto.getMpGroupConf());
		if (configurations == null)
		{
			configurations = new ArrayList<MpContractConfigurationDto>();
		}
		if (isIveco)
		{
			if (contractDto.getEngOilId() != null)
			{
				MpContractConfigurationDto oil = new MpContractConfigurationDto(contractDto.getMpGroupConf(), Constantes.ENGINE_OIL_ITEM_CV, contractDto.getEngOilId());
				if (!configurations.contains(oil))
				{
					configurations.add(oil);
				}
			}
			if (contractDto.getGbOilId() != null)
			{
				MpContractConfigurationDto gearBox = new MpContractConfigurationDto(contractDto.getMpGroupConf(), Constantes.GEARBOX_OIL_ITEM_CV, contractDto.getGbOilId());
				if (!configurations.contains(gearBox))
				{
					configurations.add(gearBox);
				}
			}
			if (contractDto.getAxleOilId() != null)
			{

				MpContractConfigurationDto axle = new MpContractConfigurationDto(contractDto.getMpGroupConf(), Constantes.AXLE_OIL_ITEM_CV, contractDto.getAxleOilId());
				if (!configurations.contains(axle))
				{
					configurations.add(axle);
				}
			}
		}
		return configurations;
	}

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkPlanApplicable(Long planId, IceContextDto context, ProductConfiguration productConfiguration) throws ApplicativeException, SystemException {
		//get project applicable
		MpPlanDto filteredPlan = null;
		List<Integer> projectList = new ArrayList<>();
		List<MpProjectDocumentDto> listProject = new MpProjectDocumentBusiness().getList(context, productConfiguration);
		if (listProject != null && !listProject.isEmpty())
		{
			for (MpProjectDocumentDto projectDto : listProject)
			{
				projectList.add(projectDto.getMpProjectId());
			}
			filteredPlan = (new MpPlanDomain()).checkPlanApplicable(planId, context, projectList);
			// -- plan without configuration are considered applicable
			if (filteredPlan != null && filteredPlan.hasConfiguration() && filteredPlan.isApplicable(productConfiguration) == false)
			{
				filteredPlan = null;
			}
		}
		return filteredPlan;
	}

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkLastVersionPlanApplicable(Long extPlanId, IceContextDto context, ProductConfiguration productConfiguration) throws ApplicativeException, SystemException {
		//get project applicable
		MpPlanDto filteredPlan = null;
		List<Integer> projectList = new ArrayList<>();
		List<MpProjectDocumentDto> listProject = new MpProjectDocumentBusiness().getList(context, productConfiguration);
		if (listProject != null && !listProject.isEmpty())
		{
			for (MpProjectDocumentDto projectDto : listProject)
			{
				projectList.add(projectDto.getMpProjectId());
			}
			filteredPlan = (new MpPlanDomain()).checkLastVersionPlanApplicable(extPlanId, context, projectList);
			// -- plan without configuration are considered applicable
			if (filteredPlan != null && filteredPlan.hasConfiguration() && filteredPlan.isApplicable(productConfiguration) == false)
			{
				filteredPlan = null;
			}
		}
		return filteredPlan;
	}

	/**
	 * Get the plan by external plan id.
	 * 
	 * @param planExtId the external plan id
	 * @return the plan
	 * @throws SystemException SystemException
	 */
	public MpPlanDto getPlanByExtId(Long planExtId) throws SystemException {
		return new MpPlanDomain().getPlanByExtId(planExtId);
	}

	/**
	 * @param session : session
	 * @param failureDate : failureDate
	 * @return
	 */
	public boolean hasContractValid(MpContractDto contract, Date failureDate) {
		if (contract != null && failureDate != null)
		{
			MpContractVehicleDto mpActiveContract = contract.getActiveMpContract();

			if (capgemini.cnh.ticd.component.util.UtilDate.compareDate(mpActiveContract.getContractEndDate().getTime(), failureDate.getTime(), 0) >= 0)
			{

				// Get startdate list for all contracts
				List<Date> listDate = getStartDateListForContracts(contract);

				Date olderStartDate = getOlderStartDate(listDate);
				if (capgemini.cnh.ticd.component.util.UtilDate.compareDate(failureDate.getTime(), olderStartDate.getTime(), 0) >= 0)
				{
					return true;
				}
				else
				{
					return false;
				}

			}
			else
			{
				return false;
			}

		}
		else
		{
			return false;
		}
	}

	/**
	 * 
	 * @param contract
	 * @return List<Date> list start date for all contracts
	 */
	private List<Date> getStartDateListForContracts(MpContractDto contract) {

		MpContractVehicleDto mpActiveContract = contract.getActiveMpContract();
		List<MpContractVehicleDto> listMpContract = contract.getContracts();

		List<Date> listDate = new ArrayList<>();
		listDate.add(mpActiveContract.getContractStartDate());

		// list contract number and old contract to have all date
		for (MpContractVehicleDto mpContract : listMpContract)
		{
			listDate.add(mpContract.getContractStartDate());
		}
		return listDate;
	}

	/**
	 * @param mpActiveContract
	 * @param dateListByContractNumber
	 * @return Date older date
	 */
	private Date getOlderStartDate(List<Date> listDate) {

		Date olderStartDate = listDate.get(0);
		if (listDate.size() > 1)
		{
			for (Date date : listDate)
			{
				if (date.before(olderStartDate))
				{
					olderStartDate = date;
				}
			}

		}
		return olderStartDate;
	}

	/**
	 * Is expired contract exists for a VIN.
	 * 
	 * @param vin the vehicle number
	 * @return true if Expired Mp Contract exists, else false
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean isExpiredMpContract(String vin) throws SystemException, ApplicativeException {

		if (!(new MpContractVehicleDomain()).getAllMpContracts(Arrays.asList(vin)).isEmpty())
		{
			MpContractVehicleDto expiredContract = (new MpContractVehicleDomain()).getExpiredMpContract(vin);
			return expiredContract == null ? false : true;
		}
		return false;

	}
}
