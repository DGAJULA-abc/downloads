/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import java.util.List;
import java.util.ListIterator;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.domain.MpProjectDocumentDomain;
import capgemini.cnh.mpbusiness.dto.MpProjectDocumentDto;

/**
 * @author sdomecq
 *
 */
public class MpProjectDocumentBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpProjectDocumentBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the List of project.
	 * 
	 * @param context for applicability
	 * @param configuration the product configuration (filter on configuration)
	 * 
	 * @return the list of projects applicable
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpProjectDocumentDto> getList(IceContextDto context, ProductConfiguration configuration) throws SystemException, ApplicativeException {
		List<MpProjectDocumentDto> projectList = new MpProjectDocumentDomain().getList(context);
		for (ListIterator<MpProjectDocumentDto> it = projectList.listIterator(); it.hasNext();)
		{ // -- filter non applicable project on configuration
			if (it.next().isApplicable(configuration) == false)
			{
				it.remove();
			}
		}
		return projectList;
	}
}
