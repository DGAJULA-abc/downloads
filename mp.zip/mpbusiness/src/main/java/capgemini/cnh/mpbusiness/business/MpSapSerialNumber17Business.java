/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.MpSapSerialNumber17Domain;
import capgemini.cnh.mpbusiness.dto.MpSapSerialNumber17Dto;

/**
 * @author jdespeau
 *
 */
public class MpSapSerialNumber17Business extends Business {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpSapSerialNumber17Business.class);

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpSapSerialNumber17Business(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpSapSerialNumber17Business() throws SystemException {
		super();
	}

	/**
	 * Get Sap Vin 17 From Sap Vin.
	 * 
	 * @param sapVin
	 * @return MpSapSerialNumber17Dto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpSapSerialNumber17Dto getSapSerialNumber17FromSapVin(String vin) throws SystemException, ApplicativeException {
		return (new MpSapSerialNumber17Domain()).getSapSerialNumber17FromSapVin(vin);
	}

}
