/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.domain.MpStdOilDomain;
import capgemini.cnh.mpbusiness.dto.MpStdOilDto;

/**
 * @author pospital
 *
 */
public class MpStdOilBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpStdOilBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the list of standard oil by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * @param productConfiguration filter on product configuration
	 * @param mapStdOilByProject : standard oil not filtered on app in the mp session
	 * 
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpStdOilDto> getStdOilsyProjectList(List<Integer> projectIdList, IceContextDto context, ProductConfiguration productConfiguration, Map<Integer, List<MpStdOilDto>> mapStdOilByProject)
			throws SystemException, ApplicativeException {

		List<MpStdOilDto> fullOilList;
		List<Integer> projectListNotStored = new ArrayList<Integer>();
		List<MpStdOilDto> stdOilList = new ArrayList<MpStdOilDto>();
		for (Integer projectId : projectIdList)
		{
			if (mapStdOilByProject.get(projectId) == null)
			{
				projectListNotStored.add(projectId);
			}
		}
		if (!projectListNotStored.isEmpty())
		{
			stdOilList = (new MpStdOilDomain()).getStdOilsyProjectList(projectIdList, context);
			//store the standard oil not filtered on app in the mp session

			for (MpStdOilDto stdOilDto : stdOilList)
			{
				fullOilList = mapStdOilByProject.get(stdOilDto.getProjectId());
				if (fullOilList == null)
				{
					fullOilList = new ArrayList<MpStdOilDto>();
					fullOilList.add(stdOilDto);
					mapStdOilByProject.put(stdOilDto.getProjectId(), fullOilList);
				}
				else
				{
					fullOilList.add(stdOilDto);
				}
			}

		}
		// filter on configuration
		stdOilList.clear();
		for (Integer projectId : projectIdList)
		{
			fullOilList = mapStdOilByProject.get(projectId);
			if (fullOilList == null)
			{
				fullOilList = new ArrayList<MpStdOilDto>();
				mapStdOilByProject.put(projectId, fullOilList);
			}
			for (MpStdOilDto stdOilDto : fullOilList)
			{
				if (stdOilDto.isApplicable(productConfiguration) == true)
				{
					stdOilList.add(stdOilDto);
				}
			}
		}
		return stdOilList;
	}

}
