/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpPartDetailDomain;
import capgemini.cnh.mpbusiness.domain.MpPartSupersessionDomain;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;
import capgemini.cnh.mpbusiness.dto.MpPartNodeDto;
import capgemini.cnh.mpbusiness.dto.MpPartSupersessionDto;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * @author pospital
 *
 */
public class MpSupersessionBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpSupersessionBusiness() throws SystemException {
		super();
	}

	//extract from the supersession list all the unitary part
	//TODO get the list of label part number in a hashmap to fill the status + label
	//transform dto in json
	/**
	 * @param partNumber : partNumber to find
	 * @return the list of supersession for a part.
	 * 
	 * @throws SystemException system exception
	 * @throws JsonProcessingException
	 */
	public MpPartNodeDto getSupersessions(String partNumberRoot, String labelRoot, String language, Boolean listForXml) throws SystemException, ApplicativeException, JsonProcessingException {
		//get the supersession chain
		//the data comes back ordered
		List<MpPartSupersessionDto> supersessionList = new MpPartSupersessionDomain().getSupersessionList(partNumberRoot);

		// remove duplicate
		for (int i = 0; i < supersessionList.size(); i++)
		{
			for (int j = supersessionList.size() - 1; j > 0; j--)
			{
				if (i != j && supersessionList.get(j) != null && supersessionList.get(i) != null
						&& supersessionList.get(i).getPnsFather().equals(supersessionList.get(j).getPnsFather())
						&& supersessionList.get(i).getPnsChild().equals(supersessionList.get(j).getPnsChild()))
				{
					supersessionList.remove(j);
				}
			}
		}

		//get the chidren translation for the label
		Map<String, MpPartDescriptionDto> partDesriptionMap = new HashMap<>();
		String label;
		if (language == null || language.equals(""))
		{
			language = Constants.ENGLISH;
		}
		if (!language.equals(Constants.ENGLISH))
		{
			//retrieve the part_number unique
			List<String> allPartList = new ArrayList<>();
			for (MpPartSupersessionDto dto : supersessionList)
			{
				if (!allPartList.contains(dto.getPnsFather()))
				{
					allPartList.add(dto.getPnsFather());
				}
				if (!allPartList.contains(dto.getPnsChild()))
				{
					allPartList.add(dto.getPnsChild());
				}
			}

		}
		//build the supersession tree node
		MpPartNodeDto rootNode = new MpPartNodeDto();
		int i = 0;
		MpPartNodeDto previousChildren = null;
		MpPartNodeDto previousFather = null;
		List<MpPartNodeDto> fatherList = new ArrayList<>();
		//not correct status or in the chain of father with incorrect status

		for (MpPartSupersessionDto node1 : supersessionList)
		{
			MpPartNodeDto children;
			//first time
			if (i == 0)
			{
				//get the root node info 
				MpPartDetailDto partDetailRoot = (new MpPartDetailDomain()).getPartDetail(partNumberRoot);
				String statusRoot = null;
				if (partDetailRoot != null)
				{
					statusRoot = partDetailRoot.getPndStatus();
				}
				MpPartNodeDto father = new MpPartNodeDto(node1.getPnsFather(), i, 0, null, null, statusRoot, labelRoot);
				i++;
				rootNode = father;
			}
			if (previousChildren == null && previousFather == null)
			{
				if (!node1.getPnsChild().equals(Constants.MP_PART_NO_CHILD) && !Constants.MP_PART_STATUS_X.equals(node1.getPnsStatus()) && node1.getPnsFather().equals(rootNode.getName()))
				{
					//get the first element
					label = node1.getPnsLabel();
					if (!language.equals(Constants.ENGLISH))
					{
						MpPartDescriptionDto dto = partDesriptionMap.get(node1.getPnsChild());
						if (dto != null && dto.getDescription() != null)
						{
							label = dto.getDescription();
						}
					}
					children = new MpPartNodeDto(node1.getPnsChild(), i, rootNode.getNodeId(), node1.getPnsQuantity(), node1.getPnsType(), node1.getPnsStatus(), label);
					rootNode.getChildren().add(children);
					previousFather = rootNode;
					previousChildren = children;
					if (getElt(fatherList, previousFather.getName()) == null)
					{
						fatherList.add(previousFather);
					}
					i++;
				}
			}
			else if (node1.getPnsChild().equals(Constants.MP_PART_NO_CHILD) || Constants.MP_PART_STATUS_X.equals(node1.getPnsStatus()))
			{
				continue;
			}
			else if (previousChildren != null && previousChildren.getName().equals(node1.getPnsFather()))
			{
				//case same row : ...->PN1->PN2->PN3
				label = node1.getPnsLabel();
				if (!language.equals(Constants.ENGLISH))
				{
					MpPartDescriptionDto dto = partDesriptionMap.get(node1.getPnsChild());
					if (dto != null && dto.getDescription() != null)
					{
						label = dto.getDescription();
					}
				}
				children = new MpPartNodeDto(node1.getPnsChild(), i, previousChildren.getNodeId(), node1.getPnsQuantity(), node1.getPnsType(), node1.getPnsStatus(), label);

				if (Boolean.TRUE.equals(listForXml))
				{
					previousChildren.getChildren().add(children);

					if (getElt(fatherList, children.getName()) == null)
					{
						previousFather = previousChildren;
						previousChildren = children;
						if (getElt(fatherList, previousFather.getName()) == null)
						{
							fatherList.add(previousFather);
						}
					}
				}
				else
				{
					if (getElt(fatherList, children.getName()) == null)
					{
						previousChildren.getChildren().add(children);
						previousFather = previousChildren;
						previousChildren = children;
						if (getElt(fatherList, previousFather.getName()) == null)
						{
							fatherList.add(previousFather);
						}
					}
				}

				i++;
			}
			else if (previousFather != null && previousFather.getName().equals(node1.getPnsFather()))
			{
				//case sibling PN2->PN3, PN2->PN4
				label = node1.getPnsLabel();
				if (!language.equals(Constants.ENGLISH))
				{
					MpPartDescriptionDto dto = partDesriptionMap.get(node1.getPnsChild());
					if (dto != null && dto.getDescription() != null)
					{
						label = dto.getDescription();
					}
				}
				children = new MpPartNodeDto(node1.getPnsChild(), i, previousFather.getNodeId(), node1.getPnsQuantity(), node1.getPnsType(), node1.getPnsStatus(), label);
				previousFather.getChildren().add(children);
				previousFather = previousChildren;
				previousChildren = children;
				if (getElt(fatherList, previousFather.getName()) == null)
				{
					fatherList.add(previousFather);
				}
				i++;
			}
			else
			{
				//go back to the parent
				previousFather = getElt(fatherList, node1.getPnsFather());
				if (previousFather != null)
				{
					label = node1.getPnsLabel();
					if (!language.equals(Constants.ENGLISH))
					{
						MpPartDescriptionDto dto = partDesriptionMap.get(node1.getPnsChild());
						if (dto != null && dto.getDescription() != null)
						{
							label = dto.getDescription();
						}
					}
					children = new MpPartNodeDto(node1.getPnsChild(), i, previousFather.getNodeId(), node1.getPnsQuantity(), node1.getPnsType(), node1.getPnsStatus(), label);
					previousFather.getChildren().add(children);
					previousChildren = children;
					i++;
					//delete the intermediary nodes
					removeNodeFromElt(fatherList, previousFather);
				}
			}
		}
		return rootNode;
	}

	/**
	 * @param fatherList : list to find the elet
	 * @param partNumber : partNumber to find
	 * @return the elt.
	 */
	private MpPartNodeDto getElt(List<MpPartNodeDto> fatherList, String partToFind) {
		MpPartNodeDto result = null;
		for (MpPartNodeDto dto : fatherList)
		{
			if (partToFind.equals(dto.getName()))
			{
				result = dto;
				break;
			}
		}
		return result;
	}

	/**
	 * Remove all the node where all the child have been set
	 * 
	 * @param fatherList : list to find the elt
	 * @param partNumber : partNumber from where the elt should be remmoved
	 */
	private void removeNodeFromElt(List<MpPartNodeDto> fatherList, MpPartNodeDto elt) {
		int i = 0;
		for (MpPartNodeDto dto : fatherList)
		{
			if (elt.getName().equals(dto.getName()))
			{
				break;
			}
			i++;
		}
		int sizeList = fatherList.size() - 1;
		for (int j = sizeList; j > i; j--)
		{
			fatherList.remove(j);
		}
	}

	/**
	 * Transform all the node to an MpOperationPartDto List
	 * 
	 * @param nodeList : node list to transform
	 */
	public List<MpOperationPartDto> transformNodeToList(List<MpPartNodeDto> nodeList) {

		List<MpOperationPartDto> parts = new ArrayList<MpOperationPartDto>();

		for (MpPartNodeDto dto : nodeList)
		{
			MpOperationPartDto part = new MpOperationPartDto(null);
			part.setCodePart(dto.getName());
			part.setPartLabel(dto.getLabel());
			part.setQuantity(dto.getQuantity().doubleValue());
			part.setId((long) dto.getNodeId());
			part.setFatherId((long) dto.getFatherNodeId());
			part.setType(dto.getType());

			// get the all chain of parts if exists
			if (dto.getChildren() != null && !dto.getChildren().isEmpty())
			{
				part.setReplacedByList(this.transformNodeToList(dto.getChildren()));
			}
			parts.add(part);
		}

		return parts;
	}

}
