/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.domain.MpToleranceDomain;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * 
 * @author jdespeau
 *
 */
public class MpToleranceBusiness extends Business {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpToleranceBusiness.class);

	/**
	 * 
	 */
	public MpToleranceBusiness() {
		super();
	}

	/**
	 * @param access
	 */
	public MpToleranceBusiness(OracleAccess access) {
		super(access);
	}

	/**
	 * Get the Tolerance By Brand And Market
	 * 
	 * @param context the IceContextDto
	 * @return MpToleranceDto
	 */
	public MpToleranceDto getToleranceByBrandAndMarket(IceContextDto context) {

		// By default brand and market = IVECO (IVECO case)
		String brandIceCode = "0";
		Long marketId = 0L;

		if (context != null && context.getCustomer() != null  && !context.getCustomer().equals(Constants.CUSTOMER_IVECO))
		{
			// Only for AG&CE
			if (context.getBrand() != null && context.getBrand().getIceCode() != null)
			{
				brandIceCode = context.getBrand().getIceCode();
			}
			if (context.getMarket() != null && context.getMarket().getMkId() != null)
			{
				marketId = context.getMarket().getMkId();
			}

		}

		MpToleranceDto mpToleranceDto = new MpToleranceDto();
		try
		{
			mpToleranceDto = new MpToleranceDomain().getToleranceByBrandAndMarket(brandIceCode, marketId);
		}
		catch (SystemException | ApplicativeException e)
		{
			logger.error("Error during getToleranceByBrandAndMarket: " + e.getMessage());
		}
		return mpToleranceDto;
	}

	//	/**
	//	 * Get tolerance by brand and market
	//	 * 
	//	 * @param mpAlertToleranceDto : the data to delete
	//	 * @throws SystemException Cannot execute query or access to database.
	//	 * @throws ApplicativeException
	//	 */
	//	public MpToleranceDto getToleranceByBrandAndMarket(String brandIceCode, Long marketId) throws SystemException, ApplicativeException {
	//		if (brandIceCode != null && marketId != null)
	//		{
	//			MpToleranceDto mpCommercialToleranceDto = new MpToleranceDomain().getToleranceByBrandAndMarket(brandIceCode, marketId);
	//			if (mpCommercialToleranceDto != null)
	//			{
	//				return mpCommercialToleranceDto;
	//			}
	//		}
	//		return new MpToleranceDto();
	//	}

}
