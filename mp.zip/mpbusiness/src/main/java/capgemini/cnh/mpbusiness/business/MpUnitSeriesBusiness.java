/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.io.IOException;
import java.io.Writer;
import java.util.Set;
import java.util.TreeSet;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.FormatUtil;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.domain.MpUnitSeriesDomain;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;

/**
 * 
 * @author jdespeau
 *
 */
public class MpUnitSeriesBusiness extends Business {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpUnitSeriesBusiness.class);

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpUnitSeriesBusiness() throws SystemException {
		super();
	}

	/**
	 * Get unit by serie.
	 * 
	 * @param context
	 * @return the MpUnitSeriesDto
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	public MpUnitSeriesDto getUnitKeyBySerie(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException, ApplicativeException {
		return (new MpUnitSeriesDomain()).getUnitBySerie(brandIcecode, typeIcecode, productIcecode, seriesIcecode);
	}

	/**
	 * <b>Publication Etim-Offline</b> <br>
	 * generateMpProjectDocumentTablePerf by serie..
	 * 
	 * @param printer printer
	 * @param iceContextDto serie
	 * @throws SystemException
	 * @throws IOException
	 * @throws ApplicativeException
	 */
	public void generateMpUnitSeriesTablePerf(IceContextDto iceContextDto, Writer printer, boolean isMysqlFormat) throws SystemException, IOException, ApplicativeException {

		MpUnitSeriesDto mpUnitSeries = getUnitKeyBySerie(iceContextDto.getBrand().getIceCode(), iceContextDto.getType().getIceCode(), iceContextDto.getProduct().getIceCode(),
				iceContextDto.getSeries().getIceCode());

		StringBuilder mySqlQuery = new StringBuilder();
		mySqlQuery.append("--");
		printer.write(mySqlQuery.toString());
		printer.write("\n");
		mySqlQuery = new StringBuilder();
		mySqlQuery.append(" insert IGNORE into MP_UNIT_SERIES ( ")

				.append("UNITSER_APP_BRA, ")
				.append("UNITSER_APP_TYP, ")
				.append("UNITSER_APP_PRO, ")
				.append("UNITSER_APP_SER, ")
				.append("UNITSER_UNIT_KEY, ")
				.append("UNITSER_UNIT, ")
				.append("UNITSER_TOLERANCE_DELTA, ")
				.append("UNITSER_TOLERANCE_FAR ")
				.append(" ) values (?,?,?,?,?,?,?,?) ");
		printer.write(mySqlQuery.toString());
		printer.write("\n");

		if (null != mpUnitSeries.getAppBra())
		{
			Set<String> sortedList = new TreeSet<>();
			mySqlQuery = new StringBuilder();
			mySqlQuery.append("(");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getAppBra()));

			mySqlQuery.append(", ");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getAppTyp()));
			mySqlQuery.append(", ");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getAppPro()));
			mySqlQuery.append(", ");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getAppSer()));
			mySqlQuery.append(", ");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getUnitKey()));
			mySqlQuery.append(", ");
			mySqlQuery.append(FormatUtil.formatStringForDatabase(isMysqlFormat, mpUnitSeries.getUnit()));
			mySqlQuery.append(", ");
			mySqlQuery.append(mpUnitSeries.getToleranceDelta());
			mySqlQuery.append(", ");
			mySqlQuery.append(mpUnitSeries.getToleranceFar());
			mySqlQuery.append("  )");
			sortedList.add(mySqlQuery.toString());

			for (String entry : sortedList)
			{//loop temporary Set to guarantee the sorted output and uniqueness
				printer.write(entry);
				printer.write("\n");
			}
		}
		mySqlQuery = new StringBuilder();
		mySqlQuery.append("--");
		printer.write(mySqlQuery.toString());

	}

}
