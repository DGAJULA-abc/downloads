/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpUsageDomain;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * @author pospital
 *
 */
public class MpUsageBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpUsageBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the usage list by plan list.
	 * 
	 * @param planList for filter
	 * @param language to display
	 * @param defaultLanguage : default Language
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpUsageDto> getListByPlanList(String planList, String language, String defaultLanguage, boolean isIveco) throws SystemException, ApplicativeException {
		List<MpUsageDto> listMpUsageId = (new MpUsageDomain()).getListByPlanList(planList, language, defaultLanguage);
		List<MpUsageDto> list = getMpUsageDtoById(listMpUsageId, language, defaultLanguage, isIveco);
		return list;
	}

	private List<MpUsageDto> getMpUsageDtoById(List<MpUsageDto> listMpUsageId, String language, String defaultLanguage, boolean isIveco) throws SystemException {
		List<MpUsageDto> list = null;

		if (language != null && !language.equals(""))
		{
			MpUsageDomain mpUsageDomain = new MpUsageDomain();
			list = new ArrayList<>();
			MpUsageDto tmpMpUsageItemDto = null;
			MpUsageDto tmpMpUsageValueDto = null;
			MpUsageDto mpUsageDto = null;
			for (MpUsageDto mpUsageId : listMpUsageId)
			{
				tmpMpUsageItemDto = null;
				tmpMpUsageValueDto = null;

				tmpMpUsageItemDto = mpUsageDomain.getMpUsageItemTranslation(mpUsageId.getItemId(), language);
				if (tmpMpUsageItemDto == null && defaultLanguage != null && !language.equals(defaultLanguage))
				{
					tmpMpUsageItemDto = mpUsageDomain.getMpUsageItemTranslation(mpUsageId.getItemId(), defaultLanguage);
				}

				tmpMpUsageValueDto = mpUsageDomain.getMpUsageValueTranslation(mpUsageId.getValueId(), language);
				if (tmpMpUsageValueDto == null && defaultLanguage != null && !language.equals(defaultLanguage))
				{
					tmpMpUsageValueDto = mpUsageDomain.getMpUsageValueTranslation(mpUsageId.getValueId(), defaultLanguage);
				}

				if (tmpMpUsageItemDto != null && tmpMpUsageValueDto != null)
				{
					mpUsageDto = new MpUsageDto();
					mpUsageDto.setItemId(tmpMpUsageItemDto.getItemId());
					mpUsageDto.setItemTitleId(tmpMpUsageItemDto.getItemTitleId());
					mpUsageDto.setValueId(tmpMpUsageValueDto.getValueId());
					mpUsageDto.setValueTitleId(tmpMpUsageValueDto.getValueTitleId());
					mpUsageDto.setValueTitle(tmpMpUsageValueDto.getValueTitle());
					if (isIveco)
					{
						// Item title is used as both strings (item and value) merged
						mpUsageDto.setItemTitle(tmpMpUsageItemDto.getItemTitle() + " - " + tmpMpUsageValueDto.getValueTitle());
					}
					else
					{
						// Item value for AG
						mpUsageDto.setItemTitle(tmpMpUsageValueDto.getValueTitle());
					}
					list.add(mpUsageDto);
				}
			}
		}

		if (list != null)
		{
			Collections.sort(list);
		}

		return list;
	}

	private MpUsageDto getMpUsageValueByIdAndLanguage(int valueId, String language) throws SystemException {

		if (language != null && !language.isEmpty())
		{
			MpUsageDomain mpUsageDomain = new MpUsageDomain();

			return mpUsageDomain.getMpUsageValueTranslation(valueId, language);

		}

		return null;
	}

	public String getMpUsageDtoValueTitleByIdAndLanguage(int valueId, String language) throws SystemException {

		MpUsageDto mpUsageDto = getMpUsageValueByIdAndLanguage(valueId, language);
		if (mpUsageDto != null)
		{
			return mpUsageDto.getValueTitle();
		}
		return "";
	}

	/**
	 * Get all the avalable missions.
	 * 
	 * @return all the mission ids.
	 * @throws SystemException SystemException
	 */
	public List<Long> getAllAvailableMissionsIds() throws SystemException {

		List<Long> resultList = new ArrayList<>();
		List<MpUsageDto> missionList = new MpUsageDomain().getAllAvailableMissionsIds();

		for (MpUsageDto mission : missionList)
		{
			resultList.add(Long.valueOf(mission.getValueId()));
		}

		return resultList;
	}
}
