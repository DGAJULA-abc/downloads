/**
 * Management of Locations.
 */
package capgemini.cnh.mpbusiness.business;

import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpVinMissionDomain;
import capgemini.cnh.mpbusiness.dto.MpVinMissionDto;

/**
 * @author mamestoy
 *
 */
public class MpVinMissionBusiness extends Business {

	/**
	 * Constructor.
	 * 
	 * @throws SystemException system exception
	 */
	public MpVinMissionBusiness() throws SystemException {
		super();
	}

	/**
	 * Get the mission for a vin.
	 * 
	 * @param vinCode : vin
	 * @return a mission dto
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpVinMissionDto getMpMissionForVin(String vinCode) throws SystemException, ApplicativeException {
		return (new MpVinMissionDomain()).getMpMissionForVin(vinCode);
	}

}
