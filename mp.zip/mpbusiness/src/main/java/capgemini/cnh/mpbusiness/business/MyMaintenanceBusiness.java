/**
 * 
 */
package capgemini.cnh.mpbusiness.business;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.access.OracleAccess;
import capgemini.cnh.framework.business.Business;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.domain.MpMaintenanceDomain;
import capgemini.cnh.mpbusiness.dto.MpAppointmentStatusEnum;
import capgemini.cnh.mpbusiness.dto.MpCallStatus;
import capgemini.cnh.mpbusiness.dto.MpMaintenanceDto;
import capgemini.cnh.mpbusiness.util.ConnectedTypeEnum;

/**
 *
 * @author lestrabo
 */
public class MyMaintenanceBusiness extends Business {

	/**
	 * 
	 */
	public MyMaintenanceBusiness() {
		super();
	}

	/**
	 * @param access
	 */
	public MyMaintenanceBusiness(OracleAccess access) {
		super(access);
	}

	public List<MpMaintenanceDto> getUrgentMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String callStatus, String connectedType)
			throws SystemException, ApplicativeException {
		connectedType = ConnectedTypeEnum.getEnumValueByKey(connectedType);
		List<MpMaintenanceDto> mpMaintenanceDtos = (new MpMaintenanceDomain().getUrgentMaintenances(dealerCode, brandIceCode, date, customerCode, callStatus, connectedType));
		List<MpMaintenanceDto> maintenanceDtos = new ArrayList<MpMaintenanceDto>();
		if (!mpMaintenanceDtos.isEmpty() && callStatus != null && callStatus.length() > 0 && callStatus.equals(MpAppointmentStatusEnum.NOTCALLED.toString()))
		{
			maintenanceDtos = filter(mpMaintenanceDtos);
			return maintenanceDtos;
		}
		return mpMaintenanceDtos;
	}

	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCode(String dealerCode, String brandIceCode, String date, String customerCode) throws SystemException, ApplicativeException {
		return (new MpMaintenanceDomain().getUrgentMaintenancesByCustomerCode(dealerCode, brandIceCode, date, customerCode));
	}

	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomers(String dealerCode, String brandIceCode, String date) throws SystemException, ApplicativeException {
		return (new MpMaintenanceDomain().getUrgentMaintenancesForAllCustomers(dealerCode, brandIceCode, date));
	}

	public List<MpMaintenanceDto> getNextMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String connectedType) throws SystemException, ApplicativeException {
		connectedType = ConnectedTypeEnum.getEnumValueByKey(connectedType);
		return (new MpMaintenanceDomain().getNextMaintenances(dealerCode, brandIceCode, date, customerCode, connectedType));
	}

	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCodeAndCallStatus(String dealerCode, String brandIceCode, String date, String customerCode, String callStatus)
			throws SystemException, ApplicativeException {
		List<MpMaintenanceDto> mpMaintenanceDtos = (new MpMaintenanceDomain().getUrgentMaintenancesByCustomerCodeAndCallStatus(dealerCode, brandIceCode, date, customerCode, callStatus));
		List<MpMaintenanceDto> maintenanceDtos = new ArrayList<MpMaintenanceDto>();
		if (!mpMaintenanceDtos.isEmpty() && callStatus != null && callStatus.length() > 0 && callStatus.equals(MpAppointmentStatusEnum.NOTCALLED.toString()))
		{
			maintenanceDtos = filter(mpMaintenanceDtos);
			return maintenanceDtos;
		}
		return mpMaintenanceDtos;
	}

	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomersAndCallStatus(String dealerCode, String brandIceCode, String date, String callStatus)
			throws SystemException, ApplicativeException {
		List<MpMaintenanceDto> mpMaintenanceDtos = (new MpMaintenanceDomain().getUrgentMaintenancesForAllCustomersAndCallStatus(dealerCode, brandIceCode, date, callStatus));
		List<MpMaintenanceDto> maintenanceDtos = new ArrayList<MpMaintenanceDto>();
		if (!mpMaintenanceDtos.isEmpty() && callStatus != null && callStatus.length() > 0 && callStatus.equals(MpAppointmentStatusEnum.NOTCALLED.toString()))
		{
			maintenanceDtos = filter(mpMaintenanceDtos);
			return maintenanceDtos;
		}

		return mpMaintenanceDtos;
	}

	private List<MpMaintenanceDto> filter(List<MpMaintenanceDto> mpMaintenanceDtos) {
		List<MpMaintenanceDto> maintenanceDtos = new ArrayList<MpMaintenanceDto>();
		for (MpMaintenanceDto mpMaintenanceDto : mpMaintenanceDtos)
		{
			if (mpMaintenanceDto.getCallStatus() == null || (mpMaintenanceDto.getCallStatus().equals(MpAppointmentStatusEnum.NOTCALLED.toString())))
			{
				maintenanceDtos.add(mpMaintenanceDto);
			}
		}
		return maintenanceDtos;
	}

	/**
	 * @param isCustomerCalled
	 * @return
	 */
	private List<Integer> getMpCallStatusListFromBoolean(Boolean isCustomerCalled) {
		List<Integer> mpCallStatusValueLst = new ArrayList<Integer>();
		if (Boolean.TRUE.equals(isCustomerCalled))
		{
			mpCallStatusValueLst.add(MpCallStatus.getValueFromStringIfExist(MpCallStatus.CALLED.toString()));
		}
		else if (Boolean.FALSE.equals(isCustomerCalled))
		{
			mpCallStatusValueLst.add(MpCallStatus.getValueFromStringIfExist(MpCallStatus.NOT_CALLED.toString()));
			mpCallStatusValueLst.add(MpCallStatus.getValueFromStringIfExist(MpCallStatus.TO_RECALL.toString()));
		}
		return mpCallStatusValueLst;
	}

	public boolean isExistingPlanId(Long planId)
			throws SystemException, ApplicativeException {

		return (new MpMaintenanceDomain()).isExistingPlanId(planId);
	}

}
