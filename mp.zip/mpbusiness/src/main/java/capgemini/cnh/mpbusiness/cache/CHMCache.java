package capgemini.cnh.mpbusiness.cache;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * class CHMCache
 * Very simple implementation of cache based on Java ConcurrentHashMap.
 * Used in offline mode.
 * 
 * @author etrappga
 *
 */
public class CHMCache implements ICache {

	/**
	 * Cache singleton.
	 */
	private static CHMCache instance = null;

	/**
	 * Cache storage.
	 */
	private ConcurrentHashMap<Object, Object> map = null;

	/**
	 * Default constructor.
	 */
	private CHMCache() {
		map = new ConcurrentHashMap<>();
	}

	/**
	 * Get the CHMCache singleton (lazy initialization).
	 * 
	 * @return CHMCache singleton.
	 */
	public synchronized static CHMCache getInstance() {
		if (instance == null)
		{
			instance = new CHMCache();
		}
		return instance;
	}

	/**
	 * Get an entry from cache with specified key.
	 * 
	 * @param key Key of entry to get.
	 * @return Object Entry of cache with key specified in parameter.
	 */
	@Override
	public Object get(Object key) {
		return this.map.get(key);
	}

	/**
	 * Put an immortal entry into cache.
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @return Object Value value of entry.
	 */
	@Override
	public Object put(Object key, Object value) {
		return this.map.put(key, value);
	}

	/**
	 * Put a mortal entry into cache.
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param time Amount of time after that entry will expire.
	 * @param timeUnit Unit of amount of time after entry will expire.
	 * @return Object Value of entry.
	 */
	@Override
	public Object put(Object key, Object value, long time, TimeUnit timeUnit) {
		// No mortal entries with CHM cache
		return put(key, value);
	}

	/**
	 * Put a mortal entry into cache which will expire on a specified date
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param expireDate Expire date for the entry.
	 * @return Object Value of entry.
	 */
	@Override
	public Object put(Object key, Object value, Date expireDate) {
		// No mortal entries with CHM cache
		return put(key, value);
	}

	/**
	 * Put a mortal entry into cache which will expire on next hours/minutes/seconds (today, or tomorrow).
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param hours Hours in 24 hours format.
	 * @param minutes Minutes.
	 * @param seconds Seconds.
	 * @return
	 */
	@Override
	public Object putDaily(Object key, Object value, int hours, int minutes, int seconds) {
		// No mortal entries with CHM cache
		return put(key, value);
	}

	/**
	 * Check if an entry is present in cache by its key.
	 * 
	 * @param key Key of the entry searched.
	 * @return boolean True if entry with specified key exists in cache.
	 */
	@Override
	public boolean containsKey(Object key) {
		return this.map.containsKey(key);
	}

	/**
	 * Check if an entry is present in cache by its value.
	 * 
	 * @param value Value of the entry searched.
	 * @return boolean True if entry with specified value exists in cache.
	 */
	@Override
	public boolean containsValue(Object value) {
		return this.map.containsValue(value);
	}

	/**
	 * Remove a cache entry by its key.
	 * 
	 * @param key Key of the entry to remove.
	 * @return Object Value removed associated to key.
	 */
	public Object remove(Object key) {
		return this.map.remove(key);
	}

	/**
	 * Clear cache.
	 */
	@Override
	public void clear() {
		this.map.clear();
	}
}
