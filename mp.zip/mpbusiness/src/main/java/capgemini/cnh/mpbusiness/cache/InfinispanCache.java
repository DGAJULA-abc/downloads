package capgemini.cnh.mpbusiness.cache;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

import org.infinispan.Cache;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.configuration.global.GlobalConfiguration;
import org.infinispan.configuration.global.GlobalConfigurationBuilder;
import org.infinispan.eviction.EvictionStrategy;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;

public class InfinispanCache implements ICache {

	/**
	 * Cache singleton.
	 */
	private static InfinispanCache instance = null;

	/**
	 * Cache storage.
	 */
	private Cache<Object, Object> c = null;

	/**
	 * Default constructor.
	 */
	private InfinispanCache() {
		GlobalConfigurationBuilder globalConfigBuilder = new GlobalConfigurationBuilder();
		globalConfigBuilder.globalJmxStatistics().enable();
		globalConfigBuilder.globalJmxStatistics().allowDuplicateDomains(true);
		GlobalConfiguration globalConfig = globalConfigBuilder.build();
		EmbeddedCacheManager mgr = new DefaultCacheManager(globalConfig);
		ConfigurationBuilder configBuilder = new ConfigurationBuilder();
		configBuilder.eviction().strategy(EvictionStrategy.LRU).size(512000);

		mgr.defineConfiguration("cnhCache", configBuilder.build());
		this.c = mgr.getCache("cnhCache");
	}

	/**
	 * Get the InfinispanCache singleton (lazy initialization).
	 * 
	 * @return InfinispanCache singleton.
	 */
	public synchronized static InfinispanCache getInstance() {
		if (instance == null)
		{
			instance = new InfinispanCache();
		}
		return instance;
	}

	/**
	 * Get an entry from cache with specified key.
	 * 
	 * @param key Key of entry to get.
	 * @return Object Entry of cache with key specified in parameter.
	 */
	@Override
	public Object get(Object key) {
		return this.c.get(key);
	}

	/**
	 * Put an immortal entry into cache.
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @return Object Value value of entry.
	 */
	@Override
	public Object put(Object key, Object value) {
		return this.c.put(key, value);
	}

	/**
	 * Put a mortal entry into cache.
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param time Amount of time after that entry will expire.
	 * @param timeUnit Unit of amount of time after entry will expire.
	 * @return Object Value of entry.
	 */
	@Override
	public Object put(Object key, Object value, long time, TimeUnit timeUnit) {
		return this.c.put(key, value, time, timeUnit);
	}

	/**
	 * Put a mortal entry into cache which will expire on a specified date
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param expireDate Expire date for the entry.
	 * @return Object Value of entry.
	 */
	@Override
	public Object put(Object key, Object value, Date expireDate) {
		Date dateNow = new Date();
		long expireSecs = (expireDate.getTime() - dateNow.getTime()) / 1000;
		if (expireSecs > 0)
			return this.put(key, value, expireSecs, TimeUnit.SECONDS);
		else return null;
	}

	/**
	 * Put a mortal entry into cache which will expire on next hours/minutes/seconds (today, or tomorrow).
	 * 
	 * @param key Key of entry.
	 * @param value Value of entry.
	 * @param hours Hours in 24 hours format.
	 * @param minutes Minutes.
	 * @param seconds Seconds.
	 * @return
	 */
	@Override
	public Object putDaily(Object key, Object value, int hours, int minutes, int seconds) {
		Calendar calendar = GregorianCalendar.getInstance();
		if (calendar.get(Calendar.HOUR_OF_DAY) > hours || (calendar.get(Calendar.HOUR_OF_DAY) == hours &&
				(calendar.get(Calendar.MINUTE) > minutes || (calendar.get(Calendar.MINUTE) == minutes && calendar.get(Calendar.SECOND) > seconds))))
		{
			calendar.add(Calendar.DATE, 1);
		}
		calendar.set(Calendar.HOUR_OF_DAY, hours);
		calendar.set(Calendar.MINUTE, minutes);
		calendar.set(Calendar.SECOND, seconds);

		Date nextDate = calendar.getTime();
		return put(key, value, nextDate);
	}

	/**
	 * Check if an entry is present in cache by its key.
	 * 
	 * @param key Key of the entry searched.
	 * @return boolean True if entry with specified key exists in cache.
	 */
	@Override
	public boolean containsKey(Object key) {
		return this.c.containsKey(key);
	}

	/**
	 * Check if an entry is present in cache by its value.
	 * 
	 * @param value Value of the entry searched.
	 * @return boolean True if entry with specified value exists in cache.
	 */
	@Override
	public boolean containsValue(Object value) {
		return this.c.containsValue(value);
	}

	/**
	 * Remove a cache entry by its key.
	 * 
	 * @param key Key of the entry to remove.
	 * @return Object Value removed associated to key.
	 */
	public Object remove(Object key) {
		return this.c.remove(key);
	}

	/**
	 * Clear cache.
	 */
	@Override
	public void clear() {
		this.c.clear();
	}
}
