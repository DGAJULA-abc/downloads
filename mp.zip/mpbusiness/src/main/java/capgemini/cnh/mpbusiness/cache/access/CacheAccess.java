package capgemini.cnh.mpbusiness.cache.access;

import capgemini.cnh.mpbusiness.cache.ICache;

abstract public class CacheAccess {

	/**
	 * Cache enable state.
	 */
	private static boolean enable = false;

	/**
	 * Hours in which cache will be daily refreshed.
	 */
	private static int refreshHours = 4;

	/**
	 * Minutes in which cache will be daily refreshed.
	 */
	private static int refreshMinutes = 0;

	/**
	 * Get cache singleton.
	 * 
	 * @return Cache singleton.
	 */
	protected abstract ICache getCacheInstance();

	/**
	 * Refresh cache datas relative to scope.
	 */
	public abstract void refresh();

	/**
	 * Enable or disable cache - if disabled, cache will be cleared.
	 * 
	 * @param enable Is cache enabled?
	 */
	public static synchronized void setEnable(boolean enable) {
		CacheAccess.enable = enable;
	}

	/**
	 * Is caching system enable ?
	 * 
	 * @return True if caching system is enable.
	 */
	public static boolean isEnabled() {
		return CacheAccess.enable;
	}

	/**
	 * Set hours and minutes in which cache will be daily refreshed.
	 * 
	 * @param hours Hours.
	 * @param minutes Minutes.
	 */
	public static synchronized void setRefreshHoursMinutes(int hours, int minutes) {
		CacheAccess.refreshHours = hours;
		CacheAccess.refreshMinutes = minutes;
	}

	/**
	 * Get hours in which cache will be daily refreshed.
	 * 
	 * @return Hours.
	 */
	public static int getRefreshHours() {
		return CacheAccess.refreshHours;
	}

	/**
	 * Get minutes in which cache will be daily refreshed.
	 * 
	 * @return Minutes.
	 */
	public static int getRefreshMinutes() {
		return CacheAccess.refreshMinutes;
	}
}
