package capgemini.cnh.mpbusiness.cache.access;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.cache.ICache;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * Class to manage MP_USAGE_ITEM table in cache.
 */
public abstract class CacheMpUsageItemAccess extends CacheAccess {

	/**
	 * Cache keys relative to names and used.
	 */
	private static Set<String> usedCacheKeys = new HashSet<>();

	/**
	 * Constructor.
	 */
	public CacheMpUsageItemAccess() {
		super();
	}

	/**
	 * Get the DB Access to MP_USAGE_ITEM.
	 * 
	 * @return DB Access to MP_USAGE_ITEM.
	 * @throws SystemException Can't get data source.
	 */
	protected abstract IMpUsageAccess getDbAccess() throws SystemException;

	@Override
	public synchronized void refresh() {
		ICache cache = getCacheInstance();
		for (String key : usedCacheKeys)
		{
			if (cache.containsKey(key))
			{
				cache.remove(key);
			}
		}
		usedCacheKeys.clear();
	}

	public Map<Long, MpUsageDto> getMpUsageItemTranslation(Long itemId, String language) throws SystemException {
		Map<Long, MpUsageDto> map = null;
		String key = generateCacheKey(language);

		ICache cache = getCacheInstance();
		if (cache.containsKey(key))
		{
			map = (Map<Long, MpUsageDto>) cache.get(key);
		}
		else
		{
			map = initCacheMpUsageItem(language);
		}

		return map;
	}

	/**
	 * Initialize cache for a specific language.
	 * 
	 * @param language Language id.
	 * @return Initialized value retrieved from DB access.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<Long, MpUsageDto> initCacheMpUsageItem(String language) throws SystemException {
		Map<Long, MpUsageDto> res = null;

		res = getDbAccess().getMpUsageItemTranslationsByLang(language);

		if (res != null)
		{
			putCacheMpUsageItem(generateCacheKey(language), res);
		}

		return res;
	}

	/**
	 * Called to put mp usage items into cache.
	 * 
	 * @param key Cache key.
	 * @param datas Cache value (datas).
	 */
	private void putCacheMpUsageItem(String key, Map<Long, MpUsageDto> datas) {
		getCacheInstance().putDaily(key, datas, CacheAccess.getRefreshHours(), CacheAccess.getRefreshMinutes(), 0);
		usedCacheKeys.add(key);
	}

	/**
	 * Generate unique cache key.
	 * 
	 * @param language the language
	 * @return a key
	 */
	private String generateCacheKey(String language) {
		String key = "MpUsageItem_lang_" + language;
		return key;
	}
}
