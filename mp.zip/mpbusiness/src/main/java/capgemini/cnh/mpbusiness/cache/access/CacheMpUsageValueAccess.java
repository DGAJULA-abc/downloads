package capgemini.cnh.mpbusiness.cache.access;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.cache.ICache;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * Class to manage MP_USAGE_VALUE table in cache.
 */
public abstract class CacheMpUsageValueAccess extends CacheAccess {

	/**
	 * Cache keys relative to names and used.
	 */
	private static Set<String> usedCacheKeys = new HashSet<>();

	/**
	 * Constructor.
	 */
	public CacheMpUsageValueAccess() {
		super();
	}

	/**
	 * Get the DB Access to MP_USAGE_VALUE.
	 * 
	 * @return DB Access to MP_USAGE_VALUE.
	 * @throws SystemException Can't get data source.
	 */
	protected abstract IMpUsageAccess getDbAccess() throws SystemException;

	@Override
	public void refresh() {
		ICache cache = getCacheInstance();
		for (String key : usedCacheKeys)
		{
			if (cache.containsKey(key))
			{
				cache.remove(key);
			}
		}
		usedCacheKeys.clear();
	}

	public Map<Integer, MpUsageDto> getMpUsageValueTranslation(int valueId, String language) throws SystemException {
		Map<Integer, MpUsageDto> map = null;
		String key = generateCacheKey(language);

		ICache cache = getCacheInstance();
		if (cache.containsKey(key))
		{
			map = (Map<Integer, MpUsageDto>) cache.get(key);
		}
		else
		{
			map = initCacheMpUsageValue(language);
		}

		return map;
	}

	/**
	 * Initialize cache for a specific language.
	 * 
	 * @param language Language id.
	 * @return Initialized value retrieved from DB access.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<Integer, MpUsageDto> initCacheMpUsageValue(String language) throws SystemException {
		Map<Integer, MpUsageDto> res = null;

		res = getDbAccess().getMpUsageValueTranslationsByLang(language);

		if (res != null)
		{
			putCacheMpUsageValue(generateCacheKey(language), res);
		}

		return res;
	}

	/**
	 * Called to put mp usage values into cache.
	 * 
	 * @param key Cache key.
	 * @param datas Cache value (datas).
	 */
	private void putCacheMpUsageValue(String key, Map<Integer, MpUsageDto> datas) {
		getCacheInstance().putDaily(key, datas, CacheAccess.getRefreshHours(), CacheAccess.getRefreshMinutes(), 0);
		usedCacheKeys.add(key);
	}

	/**
	 * Generate unique cache key.
	 * 
	 * @param language the language
	 * @return a key
	 */
	private String generateCacheKey(String language) {
		String key = "MpUsageValue_lang_" + language;
		return key;
	}
}
