package capgemini.cnh.mpbusiness.cache.access.chm;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpUsageAccess;
import capgemini.cnh.mpbusiness.cache.CHMCache;
import capgemini.cnh.mpbusiness.cache.ICache;
import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageItemAccess;

/**
 * Class to manage MP_USAGE_ITEM table in cache.
 */
public class CHMCacheMpUsageItemAccess extends CacheMpUsageItemAccess {

	/**
	 * Constructor.
	 */
	public CHMCacheMpUsageItemAccess() {
		super();
	}

	@Override
	protected IMpUsageAccess getDbAccess() throws SystemException {
		return (new HsqlMpUsageAccess());
	}

	@Override
	protected ICache getCacheInstance() {
		return CHMCache.getInstance();
	}
}
