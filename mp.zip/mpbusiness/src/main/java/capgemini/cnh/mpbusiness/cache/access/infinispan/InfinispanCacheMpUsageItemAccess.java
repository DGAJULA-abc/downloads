package capgemini.cnh.mpbusiness.cache.access.infinispan;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpUsageAccess;
import capgemini.cnh.mpbusiness.cache.ICache;
import capgemini.cnh.mpbusiness.cache.InfinispanCache;
import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageItemAccess;

/**
 * Class to manage MP_USAGE_ITEM table in cache.
 */
public class InfinispanCacheMpUsageItemAccess extends CacheMpUsageItemAccess {

	/**
	 * Constructor.
	 */
	public InfinispanCacheMpUsageItemAccess() {
		super();
	}

	@Override
	protected IMpUsageAccess getDbAccess() throws SystemException {
		return (new OracleMpUsageAccess());
	}

	@Override
	protected ICache getCacheInstance() {
		return InfinispanCache.getInstance();
	}
}
