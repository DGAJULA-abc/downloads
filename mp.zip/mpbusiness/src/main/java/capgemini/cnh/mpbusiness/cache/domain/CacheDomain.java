package capgemini.cnh.mpbusiness.cache.domain;

import capgemini.cnh.mpbusiness.cache.access.CacheAccess;
import capgemini.cnh.mpbusiness.cache.domain.chm.CHMCacheAccessFactory;
import capgemini.cnh.mpbusiness.cache.domain.infinispan.InfinispanCacheAccessFactory;

public abstract class CacheDomain {

	/**
	 * Cache access factory.
	 */
	private ICacheAccessFactory accessFactory = null;

	/**
	 * Default constructor.
	 */
	public CacheDomain() {
		setCacheAccessFactory();
	}

	/**
	 * Define the proper access factory (Infinispan if Java 8 - web, CHM else).
	 */
	private void setCacheAccessFactory() {
		String[] javaVersionElements = System.getProperty("java.version").split("\\.");

		int major = Integer.parseInt(javaVersionElements[1]);

		if (major >= 8)
		{
			accessFactory = new InfinispanCacheAccessFactory();
		}
		else
		{
			accessFactory = new CHMCacheAccessFactory();
		}
	}

	/**
	 * Get the cache access factory.
	 * 
	 * @return Cache access factory.
	 */
	protected ICacheAccessFactory getCacheAccessFactory() {
		return accessFactory;
	}

	/**
	 * Enable the cache.
	 */
	public static void enableCache() {
		CacheAccess.setEnable(true);
	}

	/**
	 * Disable the cache.
	 */
	public static void disableCache() {
		CacheAccess.setEnable(false);
	}

	/**
	 * Check if cache is enabled.
	 * 
	 * @return True if cache is enabled.
	 */
	public static boolean isCacheEnabled() {
		return CacheAccess.isEnabled();
	}

	/**
	 * Set hours and minutes in which cache will be daily refreshed.
	 * 
	 * @param hours Hours.
	 * @param minutes Minutes.
	 */
	public static void setRefreshHoursMinutes(int hours, int minutes) {
		CacheAccess.setRefreshHoursMinutes(hours, minutes);
	}
}
