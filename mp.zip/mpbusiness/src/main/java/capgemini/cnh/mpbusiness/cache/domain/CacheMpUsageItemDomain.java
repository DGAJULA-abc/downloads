package capgemini.cnh.mpbusiness.cache.domain;

import java.util.Map;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * Class to manage MP_USAGE_ITEM table in cache.
 */
public class CacheMpUsageItemDomain extends CacheDomain {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(CacheMpUsageItemDomain.class);

	/**
	 * Constructor.
	 */
	public CacheMpUsageItemDomain() {
		super();
	}

	/**
	 * Force the cache to refresh.
	 */
	public void refresh() {
		getCacheAccessFactory().getMpUsageItemAccess().refresh();
	}

	/**
	 * Get mp usage item translation for the given language.
	 * 
	 * @param itemId the mp usage item id
	 * @param language the language for translation
	 * @return the mp usage item translated
	 * @throws SystemException system exception
	 */
	public MpUsageDto getMpUsageItemTranslation(Long itemId, String language) throws SystemException {
		MpUsageDto mpUsageDto = null;

		if (itemId == null || language == null)
		{
			logger.error("getMpUsageItemTranslation: the id and/or the language are not defined!");
		}
		else
		{
			Map<Long, MpUsageDto> mapMpUsage = getCacheAccessFactory().getMpUsageItemAccess().getMpUsageItemTranslation(itemId, language);
			if (mapMpUsage != null && mapMpUsage.containsKey(itemId))
			{
				mpUsageDto = mapMpUsage.get(itemId);
			}
		}

		return mpUsageDto;
	}
}
