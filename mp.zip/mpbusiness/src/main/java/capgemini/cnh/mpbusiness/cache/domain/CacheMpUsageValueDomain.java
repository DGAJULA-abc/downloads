package capgemini.cnh.mpbusiness.cache.domain;

import java.util.Map;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * Class to manage MP_USAGE_ITEM table in cache.
 */
public class CacheMpUsageValueDomain extends CacheDomain {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(CacheMpUsageValueDomain.class);

	/**
	 * Constructor.
	 */
	public CacheMpUsageValueDomain() {
		super();
	}

	/**
	 * Force the cache to refresh.
	 */
	public void refresh() {
		getCacheAccessFactory().getMpUsageItemAccess().refresh();
	}

	/**
	 * Get mp usage value translation for the given language.
	 * 
	 * @param valueId the mp usage value id
	 * @param language the language for translation
	 * @return the mp usage value translated
	 * @throws SystemException system exception
	 */
	public MpUsageDto getMpUsageValueTranslation(int valueId, String language) throws SystemException {
		MpUsageDto mpUsageDto = null;

		if (language == null)
		{
			logger.error("getMpUsageValueTranslation: the id and/or the language are not defined!");
		}
		else
		{
			Map<Integer, MpUsageDto> mapMpUsage = getCacheAccessFactory().getMpUsageValueAccess().getMpUsageValueTranslation(valueId, language);
			if (mapMpUsage != null && mapMpUsage.containsKey(valueId))
			{
				mpUsageDto = mapMpUsage.get(valueId);
			}
		}

		return mpUsageDto;
	}
}
