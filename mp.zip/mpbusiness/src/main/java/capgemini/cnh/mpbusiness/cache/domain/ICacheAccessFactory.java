package capgemini.cnh.mpbusiness.cache.domain;

import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageItemAccess;
import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageValueAccess;

public interface ICacheAccessFactory {

	/**
	 * Get cache access to MP_USAGE_ITEM.
	 * 
	 * @return cache access to MP_USAGE_ITEM
	 */
	public CacheMpUsageItemAccess getMpUsageItemAccess();

	/**
	 * Get cache access to MP_USAGE_VALUE.
	 * 
	 * @return cache access to MP_USAGE_VALUE
	 */
	public CacheMpUsageValueAccess getMpUsageValueAccess();
}
