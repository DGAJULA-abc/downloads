package capgemini.cnh.mpbusiness.cache.domain.chm;

import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageItemAccess;
import capgemini.cnh.mpbusiness.cache.access.chm.CHMCacheMpUsageItemAccess;
import capgemini.cnh.mpbusiness.cache.access.chm.CHMCacheMpUsageValueAccess;
import capgemini.cnh.mpbusiness.cache.domain.ICacheAccessFactory;

public class CHMCacheAccessFactory implements ICacheAccessFactory {

	@Override
	public CacheMpUsageItemAccess getMpUsageItemAccess() {
		return (new CHMCacheMpUsageItemAccess());
	}

	@Override
	public CHMCacheMpUsageValueAccess getMpUsageValueAccess() {
		return (new CHMCacheMpUsageValueAccess());
	}
}
