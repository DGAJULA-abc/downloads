package capgemini.cnh.mpbusiness.cache.domain.infinispan;

import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageItemAccess;
import capgemini.cnh.mpbusiness.cache.access.CacheMpUsageValueAccess;
import capgemini.cnh.mpbusiness.cache.access.infinispan.InfinispanCacheMpUsageItemAccess;
import capgemini.cnh.mpbusiness.cache.access.infinispan.InfinispanCacheMpUsageValueAccess;
import capgemini.cnh.mpbusiness.cache.domain.ICacheAccessFactory;

public class InfinispanCacheAccessFactory implements ICacheAccessFactory {

	@Override
	public CacheMpUsageItemAccess getMpUsageItemAccess() {
		return (new InfinispanCacheMpUsageItemAccess());
	}

	@Override
	public CacheMpUsageValueAccess getMpUsageValueAccess() {
		return (new InfinispanCacheMpUsageValueAccess());
	}
}
