/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.mpbusiness.domain.hsql.HsqlTableAccessFactory;
import capgemini.cnh.mpbusiness.domain.oracle.OracleTableAccessFactory;

/**
 * Super class of Domain.
 * 
 */
public class Domain {

	/**
	 * logger variable.
	 */
	private static TIDBLogger logger = TIDBLogger.getLogger(Domain.class);

	/**
	 * Default constructor.
	 */
	public Domain() {
		setTableAccessFactory();
	}

	/**
	 * attribute.
	 */
	private ITableAccessFactory accessFactory;

	/**
	 * Set the factory depending of database type.
	 */
	private void setTableAccessFactory() {

		if (accessFactory != null)
		{
			return;
		}

		logger.debug("Creating table access factory");

		if (Context.isLocal())
		{

			logger.debug("Mode is local - table access factory is Hsql ");
			// mode Local 
			accessFactory = new HsqlTableAccessFactory();
		}
		else if (Context.isWeb())
		{

			// web mode 
			accessFactory = new OracleTableAccessFactory();
		}
		else
		{
			if ((Context.getTestMode() == Context.TestMode.HSQL_SRT)
					|| (Context.getTestMode() == Context.TestMode.HSQL_TICD))
			{
				// test mode - mode Local
				logger.debug("Mode is test local - table access factory is hsql");
				accessFactory = new HsqlTableAccessFactory();
			}
			else if ((Context.getTestMode() == Context.TestMode.ORACLE_SRT)
					|| (Context.getTestMode() == Context.TestMode.ORACLE_TICD)
					|| (Context.getTestMode() == Context.TestMode.ORACLE_TIDB))
			{
				// test mode -  mode Local
				logger.debug("Mode is test local - table access factory is oracle");
				accessFactory = new OracleTableAccessFactory();
			}
			else
			{
				// test mode -  unknown
				logger.error("unknown mode");
				accessFactory = null;
			}

		}
	}

	/**
	 * Get AccessFactory : the class that construct the right Access classes depending on which type of database used.
	 * 
	 * @return accessFactory
	 */
	public ITableAccessFactory getAccessFactory() {
		return accessFactory;
	}
}
