/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMonMaintenancePlanAccess;
import capgemini.cnh.mpbusiness.access.IMpAlertToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpAppointmentAccess;
import capgemini.cnh.mpbusiness.access.IMpClaimAccess;
import capgemini.cnh.mpbusiness.access.IMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.access.IMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.access.IMpCustomerAccess;
import capgemini.cnh.mpbusiness.access.IMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexContractAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.access.IMpIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.access.IMpLockAccess;
import capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationPartAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDetailAccess;
import capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.access.IMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.access.IMpPlanAccess;
import capgemini.cnh.mpbusiness.access.IMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.access.IMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.access.IMpStdOilAccess;
import capgemini.cnh.mpbusiness.access.IMpToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.access.IMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.access.IMpVinMissionAccess;

/**
 * 
 * 
 * List of Access Factory.
 */
public interface ITableAccessFactory {

	/**
	 * Gives access to MP usage.
	 * 
	 * @return IMpUsageAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpUsageAccess getMpUsageAccess() throws SystemException;

	/**
	 * Gives access to MP operation.
	 * 
	 * @return IMpOperationAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpOperationAccess getMpOperationAccess() throws SystemException;

	/**
	 * Gives access to MP operation consumable.
	 * 
	 * @return IMpOperationConsumableAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpOperationConsumableAccess getMpOperationConsumableAccess() throws SystemException;

	/**
	 * Gives access to MP operation part.
	 * 
	 * @return IMpOperationPartAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpOperationPartAccess getMpOperationPartAccess() throws SystemException;

	/**
	 * Gives access to MP interval.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpIntervalAccess getMpIntervalAccess() throws SystemException;

	/**
	 * Gives access to MP Perf Free text.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpPerfFreeTextAccess getMpPerfFreeTextAccess() throws SystemException;

	/**
	 * Gives access to MP plan.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpPlanAccess getMpPlanAccess() throws SystemException;

	/**
	 * Gives access to MP history warranty.
	 * 
	 * @return IMpHistoryWarrantyAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess() throws SystemException;

	/**
	 * Gives access to MP history warranty.
	 * 
	 * @param dbAccess the transaction
	 * @return IMpHistoryWarrantyAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP history interval.
	 * 
	 * @return IMpHistoryIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryIntervalAccess getMpHistoryIntervalAccess() throws SystemException;

	/**
	 * Gives access to MP history interval.
	 * 
	 * @param dbAccess transaction access
	 * @return IMpHistoryIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryIntervalAccess getMpHistoryIntervalAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP history config.
	 * 
	 * @return IMpHistoryConfigAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryConfigAccess getMpHistoryConfigAccess() throws SystemException;

	/**
	 * Gives access to MP history config.
	 * 
	 * @param dbAccess the transaction
	 * @return IMpHistoryConfigAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpHistoryConfigAccess getMpHistoryConfigAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP part description.
	 * 
	 * @return IMpPartDescriptionAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpPartDescriptionAccess getMpPartDescriptionAccess() throws SystemException;

	/**
	 * Gives access to MP vehicle contract.
	 * 
	 * @return IMpContractVehicleAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpContractVehicleAccess getMpContractVehicleAccess() throws SystemException;

	/**
	 * Gives access to MP configuration from contract.
	 * 
	 * @return IMpContractConfigurationAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpContractConfigurationAccess getMpContractConfigurationAccess() throws SystemException;

	/**
	 * Gives access to MP kit composition.
	 * 
	 * @return IMpKitCompositionAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpKitCompositionAccess getMpKitCompositionAccess() throws SystemException;

	/**
	 * Gives access to MP standard oil.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpStdOilAccess getMpStdOilAccess() throws SystemException;

	/**
	 * Gives access to MP claim.
	 * 
	 * @return IMpClaimAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpClaimAccess getMpClaimAccess() throws SystemException;

	/**
	 * Gives access to MP claim.
	 * 
	 * @param dbAccess transaction access
	 * @return IMpClaimAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpClaimAccess getMpClaimAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP Sap Serial Number 17.
	 * 
	 * @return IMpClaimAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpSapSerialNumber17Access getMpSapSerialNumber17Access() throws SystemException;

	/**
	 * Gives access to MP Sap Serial Number 17.
	 * 
	 * @param dbAccess transaction access
	 * @return IMpClaimAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpSapSerialNumber17Access getMpSapSerialNumber17Access(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP vin mission.
	 * 
	 * @return IMpVinMissionAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpVinMissionAccess getMpVinMissionAccess() throws SystemException;

	/**
	 * Gives access to MP default mission.
	 * 
	 * @return IMpDefaultMissionAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpDefaultMissionAccess getMpDefaultMissionAccess() throws SystemException;

	/**
	 * Gives access to MP next flex stop.
	 * 
	 * @return IMpNextFlexStopAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpNextStopAccess getMpNextFlexStopAccess() throws SystemException;

	/**
	 * Gives access to MP next flex stop.
	 * 
	 * @param dbAccess transaction access
	 * @return IMpNextFlexStopAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpNextStopAccess getMpNextFlexStopAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP flex stop done.
	 * 
	 * @return IMpFlexStopDoneAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpFlexStopDoneAccess getMpFlexStopDoneAccess() throws SystemException;

	/**
	 * Gives access to MP flex stop done.
	 * 
	 * @param dbAccess the transaction
	 * @return IMpFlexStopDoneAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpFlexStopDoneAccess getMpFlexStopDoneAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP flex coupons.
	 * 
	 * @return IMpFlexCouponAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpFlexCouponAccess getMpFlexCouponAccess() throws SystemException;

	/**
	 * Gives access to MP next min stop.
	 * 
	 * @return IMpNextFlexStopAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpNextStopMinAccess getMpNextFlexStopMinAccess() throws SystemException;

	/**
	 * Gives access to MP next min stop.
	 * 
	 * @param dbAccess transaction access
	 * @return IMpNextFlexStopAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpNextStopMinAccess getMpNextFlexStopMinAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP flex contract.
	 * 
	 * @return IMpFlexContractAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpFlexContractAccess getMpFlexContractAccess() throws SystemException;

	/**
	 * Gives access to MP next flex stop.
	 * 
	 * @return IMpNextFlexStopAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpNextStopAlertAccess getMpNextFlexStopAlertAccess() throws SystemException;

	/**
	 * Gives access to MP maintenance.
	 * 
	 * @return IMpFlexCouponAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpMaintenanceAccess getMpMaintenanceAccess() throws SystemException;

	/**
	 * Gives access to MP vehicle average/current values.
	 * 
	 * @return IMpVehicleAverageAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpVehicleAverageAccess getMpVehicleAverageAccess() throws SystemException;

	/**
	 * Gives access to MP maintenance.
	 * 
	 * @return IMpFlexCouponAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpCustomerAccess getMpCustomerAccess() throws SystemException;

	/**
	 * Gives access to MP lock.
	 * 
	 * @param dbAccess the transaction
	 * @return IMpLockAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpLockAccess getMpLockAccess(Access dbAccess) throws SystemException;

	/**
	 * Gives access to MP ALERT TOLERANCE
	 * 
	 * @param dbAccess the transaction
	 * @return IMpLockAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpAlertToleranceAcess getMpAlertToleranceAccess() throws SystemException;

	/**
	 * Gives access to MP TOLERANCE
	 * 
	 * @param dbAccess the transaction
	 * @return IMpLockAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpToleranceAcess getMpToleranceAccess() throws SystemException;

	/**
	 * 
	 * @return
	 * @throws SystemException
	 */
	IMpFlexCustomerSapAccess getMpFlexCustomerSapAccess() throws SystemException;

	/**
	 * 
	 * @return A IProjectDocumentAccess
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	IMpProjectDocumentAccess getProjectDocumentAccess() throws SystemException, ApplicativeException;

	/**
	 * Gives access to MP operation iu link.
	 * 
	 * @return IMpOperationIuLinkAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpOperationIuLinkAccess getMpOperationIuLinkAccess() throws SystemException;

	/**
	 * Gives access to MP part supersession.
	 * 
	 * @return IMpPartSupersessionAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpPartSupersessionAccess MpPartSupersessionAccess() throws SystemException;

	/**
	 * Gives access to MP part detail.
	 * 
	 * @return IMpPartDetailAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpPartDetailAccess MpPartDetailAccess() throws SystemException;

	/**
	 * Gives access to MP unit series.
	 * 
	 * @return IMpPartDetailAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpUnitSeriesAccess getMpUnitSeriesAccess() throws SystemException;

	/**
	 * Gives access to MP appointment.
	 * 
	 * @return IMpAppointmentAccess interface.
	 * @throws SystemException a system exception.
	 */
	IMpAppointmentAccess getMpAppointmentAccess() throws SystemException;

	IMonMaintenancePlanAccess getMonMaintenancePlanAccess() throws SystemException;
}
