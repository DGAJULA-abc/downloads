package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MonMaintenancePlanDto;

public class MonMaintenancePlanDomain extends Domain {

	public MonMaintenancePlanDomain() {
		super();
	}

	public boolean saveMaintenancePlan(MonMaintenancePlanDto mmpDto)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMonMaintenancePlanAccess().saveMonMaintenancePlan(mmpDto);
	}
}
