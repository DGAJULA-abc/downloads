/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpAlertToleranceDto;

/**
 *
 * @author lestrabo
 */
public class MpAlertToleranceDomain extends Domain {

	/**
	 * 
	 */
	public MpAlertToleranceDomain() {
		super();
	}

	public MpAlertToleranceDto getToleranceByPlanId(Long planId)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpAlertToleranceAccess().getToleranceByPlanId(planId);
	}

}
