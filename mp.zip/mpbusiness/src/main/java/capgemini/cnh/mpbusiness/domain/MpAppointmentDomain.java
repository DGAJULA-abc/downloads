package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpAppointmentDto;

/**
 * 
 * @author cblois
 *
 */
public class MpAppointmentDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpAppointmentDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpAppointmentDomain() {
		super();
	}

	/**
	 * Update the .
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long updateAppointementToRecall(Long alertGroupId) throws SystemException {
		return getAccessFactory().getMpAppointmentAccess().updateAppointementToRecall(alertGroupId);
	}

	/**
	 * Create/Move/Cancel the appointment.
	 * 
	 * @param mpAppointment the appointment
	 * @return the updated appointment (date, status ...)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpAppointmentDto manageAppointment(MpAppointmentDto mpAppointment) throws SystemException {
		return getAccessFactory().getMpAppointmentAccess().manageAppointment(mpAppointment);
	}

	/**
	 * Get the appointment by id.
	 * 
	 * @param id the id of the appointment
	 * @return the appointment
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpAppointmentDto getAppointmentById(Long id) throws SystemException {
		return getAccessFactory().getMpAppointmentAccess().getAppointmentById(id);
	}

	/**
	 * Close the appointment.
	 * 
	 * @param alertGroupId the alert group id to identify the appointment to close
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Long closeAppointment(Long alertGroupId) throws SystemException {
		return getAccessFactory().getMpAppointmentAccess().closeAppointment(alertGroupId);
	}

}
