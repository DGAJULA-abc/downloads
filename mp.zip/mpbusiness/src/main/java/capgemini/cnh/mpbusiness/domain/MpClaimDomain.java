package capgemini.cnh.mpbusiness.domain;

import java.util.Date;
import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpClaimDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpClaimDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpClaimDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpClaimDomain() {
		super();
	}

	/**
	 * Add a claim in database for a selected VIN.
	 * 
	 * @param claimDto
	 *            claim to add
	 * 
	 * @return request result
	 * 
	 * @throws SystemException
	 *             Cannot execute query or access to database.
	 * @throws ApplicativeException
	 *             application exception
	 */
	public boolean addClaim(MpClaimDto claimDto) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpClaimAccess(this.dbAccess).create(claimDto));
	}

	/**
	 * Get list of claims in database for a VIN.
	 * 
	 * @param vinList : selected VIN
	 * @return a list of claims
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<MpClaimDto> getClaimForVin(List<String> vinList) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpClaimAccess().getClaimForVin(vinList));
	}

	/**
	 * Get a claim in database for an Id.
	 * 
	 * @param id : selected id
	 * @return a claim
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpClaimDto getClaimForId(String id) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpClaimAccess().getClaimForId(id));
	}

	/**
	 * Update the creation time date in a new field.
	 *
	 * @param id to update
	 * @param dateEdit to update
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean updateDateClaim(String id, String dateEdit) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpClaimAccess().updateDateClaim(id, dateEdit));
	}

	/**
	 * update the XML content in database.
	 * 
	 * @param id to update
	 * @param dateEdit to update
	 * @param XMLFile the content of the XML
	 * @param XMLSapFile the content of the XML sap
	 * @param original XMLSapFile the content of the original XML sap
	 * @return request result
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean updateXMLClaim(String id, String dateEdit, String XMLFile, String XMLSapFile, String originalXMLSapFile) throws SystemException {
		return (getAccessFactory().getMpClaimAccess().updateXMLClaim(id, dateEdit, XMLFile, XMLSapFile, originalXMLSapFile));
	}

	public boolean updatePDFPath(String id, String pdfPath) throws SystemException {
		return (getAccessFactory().getMpClaimAccess().updatePDFPath(id, pdfPath));
	}

	/**
	 * Get the max of Id in the MP_CLAIM table.
	 * 
	 * @return the max Id
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public String getMaxClaimId() throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpClaimAccess(this.dbAccess).getMaxClaimId());
	}

	/**
	 * get Claims to generate PDF.
	 * 
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpClaimDto> getClaimToExport() throws SystemException {
		return (getAccessFactory().getMpClaimAccess(this.dbAccess).getClaimToExport());
	}

	/**
	 * Function for retrieving the claims for the maintenance history export cron job of 22:00 P.M.
	 * 
	 * @param lastExportDate The date of the last export from which to retrieve the records.
	 * @throws SystemException Cannot execute query or access to database
	 */
	public List<MpClaimDto> getClaimsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		return getAccessFactory().getMpClaimAccess(this.dbAccess).getClaimsForCsvExport(lastExportDate, firstExportDate);

	}

}
