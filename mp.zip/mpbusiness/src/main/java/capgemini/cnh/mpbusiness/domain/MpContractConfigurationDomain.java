package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractConfigurationDto;

/**
 * Super class of Domain.
 * 
 */
public class MpContractConfigurationDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpContractConfigurationDomain() {
		super();
	}

	/**
	 * Get the configuration linked to a plan under contract.
	 * 
	 * @param group the configuration group
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<MpContractConfigurationDto> getMpContractConfiguration(String group) throws SystemException, ApplicativeException {
		List<MpContractConfigurationDto> configurations = getAccessFactory().getMpContractConfigurationAccess().getMpContractConfiguration(group);
		return configurations;
	}
}
