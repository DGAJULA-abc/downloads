package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;

/**
 * Super class of Domain.
 * 
 */
public class MpContractVehicleDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpContractVehicleDomain() {
		super();
	}

	/**
	 * Get all the Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the list of plan
	 * @throws SystemException system exception
	 */
	public List<MpContractVehicleDto> getAllMpContracts(List<String> lstPinVin) throws SystemException {
		return getAccessFactory().getMpContractVehicleAccess().getAllMpContracts(lstPinVin);
	}

	/**
	 * Get the applicable mp plan from contract.
	 * 
	 * @param vin the vehicle number
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractVehicleDto getMpActiveContract(String vin) throws SystemException, ApplicativeException {
		MpContractVehicleDto contractDto = getAccessFactory().getMpContractVehicleAccess().getMpActiveContract(vin);
		return contractDto;
	}

	/**
	 * Get the expired mp plan from contract.
	 * 
	 * @param vin the vehicle number
	 * @return the contract plan
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public MpContractVehicleDto getExpiredMpContract(String vin) throws SystemException, ApplicativeException {
		MpContractVehicleDto contractDto = getAccessFactory().getMpContractVehicleAccess().getExpiredMpContract(vin);
		return contractDto;
	}
}
