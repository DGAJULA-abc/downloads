/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpCustomerDto;

/**
 *
 * @author lestrabo
 */
public class MpCustomerDomain extends Domain {

	/**
	 * 
	 */
	public MpCustomerDomain() {
		super();
	}

	public List<MpCustomerDto> getCustomersFromMpCustomers(String dealerCode, String brand) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpCustomerAccess().getCustomersFromMpCustomers(dealerCode, brand);

	}

}
