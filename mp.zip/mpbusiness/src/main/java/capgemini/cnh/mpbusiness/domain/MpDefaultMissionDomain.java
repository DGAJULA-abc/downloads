package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpDefaultMissionDto;

/**
 * Super class of Domain.
 * 
 */
public class MpDefaultMissionDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpDefaultMissionDomain() {
		super();
	}

	/**
	 * Get the mission for an applicability.
	 * 
	 * @param dtoIceContext : context (series, model, tt)
	 * @param level : series, model or tt level
	 * @return a mission dto
	 * @throws SystemException system exception
	 */

	public MpDefaultMissionDto getMpMissionForApp(IceContextDto dtoIceContext, String level) throws SystemException {
		return getAccessFactory().getMpDefaultMissionAccess().getMpMissionForApp(dtoIceContext, level);
	}

}
