package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpContractVehicleDto;

/**
 * Super class of Domain.
 * 
 */
public class MpFlexContractDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpFlexContractDomain() {
		super();
	}

	/**
	 * Get the the applicable Mp contract for a VIN.
	 * 
	 * @param vin the vin
	 * @return the applicable plan
	 * @throws SystemException system exception
	 */
	public MpContractVehicleDto getMpActiveFlexContract(String vin) throws SystemException {
		return getAccessFactory().getMpFlexContractAccess().getMpActiveFlexContract(vin);
	}

	/**
	 * Return true if dealer has contract valid false if doesn't have.
	 * 
	 * @param dealerCode : dealer code
	 * @param brandIceCode : brandIceCode
	 * @return true or false
	 * @throws SystemException system exception
	 */
	public boolean hasDealerActiveContract(String dealerCode, String brandIceCode) throws SystemException {
		return getAccessFactory().getMpFlexContractAccess().hasDealerActiveContract(dealerCode, brandIceCode);
	}
}
