package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpFlexCouponDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpFlexCouponDomain() {
	}

	/**
	 * get list of potential flexible coupons.
	 * 
	 * @return get list of potential flexible coupons.
	 * @throws SystemException system exception
	 */
	public List<MpFlexCouponDto> getFlexibleCoupons() throws SystemException {
		return getAccessFactory().getMpFlexCouponAccess().getFlexibleCoupons();
	}

	/**
	 * Get the flexible coupon.
	 * 
	 * @param coupon the coupon
	 * @return the coupon or null
	 * @throws SystemException system exception
	 */
	public MpFlexCouponDto getFlexibleCoupon(String coupon) throws SystemException {
		return getAccessFactory().getMpFlexCouponAccess().getFlexibleCoupon(coupon);
	}
	
}
