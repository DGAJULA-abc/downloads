/**
 * 2:40:58 PM
 * MpFlexCustomerSapDomain.java
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexCustomerSapDto;

/**
 * @author mshaikh4
 *
 */
public class MpFlexCustomerSapDomain extends Domain {

	/**
	 * 
	 */
	public MpFlexCustomerSapDomain() {
		super();
	}

	/**
	 * Get Customer Details from MP FLEX based on VIN.
	 * 
	 * @param vin vin
	 * @return MpFlexCustomerSapDto
	 * @throws SystemException SystemException
	 */
	public MpFlexCustomerSapDto selectCustomerFromVinDetail(String vin) throws SystemException {
		return getAccessFactory().getMpFlexCustomerSapAccess().selectCustomerFromVinDetail(vin);
	}

}
