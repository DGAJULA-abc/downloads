package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpFlexStopDoneDto;

/**
 * 
 * @author bmilcend
 *
 */
public class MpFlexDoneDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpFlexDoneDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpFlexDoneDomain() {
		super();
	}

	/**
	 * add Mp next stop in database.
	 * 
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addFlexStopDone(MpFlexStopDoneDto nextStops) throws SystemException {
		Long result = null;
		getAccessFactory().getMpFlexStopDoneAccess(this.dbAccess).addFlexStopDone(nextStops);
		return result;
	}

	/**
	 * delete Mp next stop in database.
	 * 
	 * @param nextStops : to be deleted
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteFlexStopDone(MpFlexStopDoneDto nextStops) throws SystemException {
		Long result = null;
		getAccessFactory().getMpFlexStopDoneAccess(this.dbAccess).deleteFlexStopDone(nextStops);
		return result;
	}

}
