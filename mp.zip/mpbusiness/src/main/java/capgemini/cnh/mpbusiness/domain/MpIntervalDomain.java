package capgemini.cnh.mpbusiness.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.dto.MpHistoryConfigDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpHistoryWarrantyDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.ticd.component.domain.TableTitleDomain;
import capgemini.cnh.ticd.component.dto.TableTitleDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpIntervalDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpIntervalDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpIntervalDomain() {
		super();
	}

	/**
	 * Get the intervals list by plan.
	 * 
	 * @param planId for filter
	 * @param language for language
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervals(Long planId, String language, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {

		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervals(planId, defaultLanguage, famIceCode, isIveco);
		List<MpIntervalDto> resultList = new ArrayList<>();

		for (MpIntervalDto dto : myDto)
		{
			if (dto.getCommentId() != null)
			{
				TableTitleDto tableTitleDto = (new TableTitleDomain()).getRefTableTitle(dto.getCommentId().toString(), language, defaultLanguage);
				if (tableTitleDto != null)
				{
					dto.setCommentLabel(tableTitleDto.getMessage());
				}
			}

			// For CV, isCustomer is null || For AG&CE, get only the non-customer intervals
			if (dto.isCustomer() == null || !dto.isCustomer())
			{
				resultList.add(dto);
			}
		}
		return resultList;
	}

	/**
	 * Get the customer interval list by plan.
	 * 
	 * @param planId for filter
	 * @param language for language
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpIntervalDto> getCustomerIntervals(String planId, String language, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {

		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervals(Long.parseLong(planId), defaultLanguage, famIceCode, isIveco);
		List<MpIntervalDto> resultList = new ArrayList<>();

		for (MpIntervalDto dto : myDto)
		{
			if (dto.getCommentId() != null)
			{
				TableTitleDto tableTitleDto = (new TableTitleDomain()).getRefTableTitle(dto.getCommentId().toString(), language, defaultLanguage);
				if (tableTitleDto != null)
				{
					dto.setCommentLabel(tableTitleDto.getMessage());
				}
			}

			// For AG&CE, get only the customer intervals
			if (dto.isCustomer())
			{
				resultList.add(dto);
			}
		}
		return resultList;
	}

	/**
	 * Get the list of intervals for a maintenance plan and a list of coupons.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param language for language
	 * @param couponsList : a list of coupons
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsByCoupons(Long planId, String language, String[] couponsList, String defaultLanguage, String famIceCode)
			throws SystemException, ApplicativeException {
		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervalsByCoupons(planId, couponsList, defaultLanguage, famIceCode);
		for (MpIntervalDto dto : myDto)
		{
			if (dto.getCommentId() != null)
			{
				TableTitleDto tableTitleDto = (new TableTitleDomain()).getRefTableTitle(dto.getCommentId().toString(), language, defaultLanguage);
				if (tableTitleDto != null)
				{
					dto.setCommentLabel(tableTitleDto.getMessage());
				}
			}
		}
		return myDto;
	}

	/**
	 * Get the intervals for a maintenance plan.
	 * 
	 * @param planId for filter
	 * @param defaultLanguage for default Language
	 * @param famIceCode family IceCode for maintenance
	 * @param isIveco true if is IVECO customer
	 * @return a list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervals(Long planId, String defaultLanguage, String famIceCode, boolean isIveco) throws SystemException, ApplicativeException {
		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervals(planId, defaultLanguage, famIceCode, isIveco);
		return myDto;
	}

	/**
	 * Get the interval for a maintenance plan and an interval.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param intervalId : interval identifier
	 * @param language for language
	 * @param defaultLanguage for default Language
	 * @return interval for a maintenance plan and interval identifier
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpIntervalDto getMaintenanceInterval(String planId, String intervalId, String language, String defaultLanguage) throws SystemException, ApplicativeException {
		MpIntervalDto myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceInterval(planId, intervalId);
		if (myDto.getCommentId() != null)
		{
			TableTitleDto tableTitleDto = (new TableTitleDomain()).getRefTableTitle(myDto.getCommentId().toString(), language, defaultLanguage);
			if (tableTitleDto != null)
			{
				myDto.setCommentLabel(tableTitleDto.getMessage());
			}
		}

		return myDto;
	}

	/**
	 * Get the list of intervals for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsWithoutOperation(Long planId, String defaultLanguage, String famIceCode) throws SystemException {
		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervalsWithoutOperation(planId, defaultLanguage, famIceCode);
		return myDto;
	}

	/**
	 * Get a coupon name giving the sub group name.
	 * 
	 * @param intervalCode : interval code name
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the coupon
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getCouponName(String intervalCode, String defaultLanguage, String famIceCode) throws SystemException {
		MpIntervalDto myDto = getAccessFactory().getMpIntervalAccess().getCouponName(intervalCode, defaultLanguage, famIceCode);
		return myDto;
	}

	/**
	 * Get the list of intervals for a maintenance plan from interval id.
	 * 
	 * @param intervalId :nterval id.
	 * @param defaultLanguage : default Language
	 * @param famIceCode : family Ice Code for maintenance
	 * @return the list of intervals for a maintenance plan
	 * @throws SystemException system exception
	 */
	public List<MpIntervalDto> getMaintenanceIntervalsFromIntervalId(Long intervalId, String defaultLanguage, String famIceCode) throws SystemException {
		List<MpIntervalDto> myDto = getAccessFactory().getMpIntervalAccess().getMaintenanceIntervalsFromIntervalId(intervalId, defaultLanguage, famIceCode);
		return myDto;
	}

	/**
	 * Insert an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean createHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).create(pDto));
	}

	/**
	 * Select an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to select
	 * @param filterOrigin : filter origin
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public MpHistoryIntervalDto readHistoryInterval(MpHistoryIntervalDto pDto, Integer filterOrigin) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().read(pDto, filterOrigin));
	}

	/**
	 * Select a list of interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to select
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> readListHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().readList(pDto));
	}

	/**
	 * Select a list of interactive maintenance plan interval history in the database for a plan and an an origin SAP/eTIM.
	 * 
	 * @param vin
	 *            the vin
	 * @param filterOrigin
	 *            the filterOrigin
	 * @param dateFrom
	 *            the date of history beginning
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> readListFromDateByOrigin(List<String> lstPinVin, Integer filterOrigin, long dateFrom) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().readListFromDateByOrigin(lstPinVin, filterOrigin, dateFrom));
	}

	/**
	 * Select a list of interactive maintenance plan interval history without claim in the database for a vin.
	 * 
	 * @param vin
	 *            the vin
	 * @param currentExtPlan
	 *            the currentExtPlan
	 * @param previousExtPlan
	 *            the previousExtPlan
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> readListWithoutClaim(String vin) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().readListWithoutClaim(vin));
	}

	/**
	 * Update an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).update(pDto));
	}

	/**
	 * Delete an interactive maintenance plan interval history in the database.
	 * 
	 * @param pDto
	 *            the interval history to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean deleteHistoryInterval(MpHistoryIntervalDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).delete(pDto));
	}

	/**
	 * Delete an record id in the maintenance plan interval history in the database.
	 * 
	 * @param id
	 *            the record id to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean delete(String id) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).delete(id));
	}

	/**
	 * Set the status deleted for a record id in the maintenance plan interval history in the database.
	 * 
	 * @param id the record id to delete
	 * @param deleled 1 to delete otherwise to not delete
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateDeleted(String id, int deleled) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).updateDeleted(id, deleled));
	}

	/**
	 * Insert an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean createHistoryWarranty(MpHistoryWarrantyDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryWarrantyAccess(this.dbAccess).create(pDto));
	}

	/**
	 * Select an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to select
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public MpHistoryWarrantyDto readHistoryWarranty(MpHistoryWarrantyDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryWarrantyAccess().read(pDto));
	}

	/**
	 * Update an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateHistoryWarranty(MpHistoryWarrantyDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryWarrantyAccess(this.dbAccess).update(pDto));
	}

	/**
	 * Delete an interactive maintenance plan warranty date in the database.
	 * 
	 * @param pDto
	 *            the warranty date to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean deleteHistoryWarranty(MpHistoryWarrantyDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryWarrantyAccess(this.dbAccess).delete(pDto));
	}

	/**
	 * Select a list of interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to select
	 * @param pLanguageId the language identifier of request information
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryConfigDto> readListHistoryConfig(MpHistoryConfigDto pDto, String pLanguageId, List<String> lstPinVin) throws SystemException {
		return (getAccessFactory().getMpHistoryConfigAccess().readList(pDto, pLanguageId, lstPinVin));
	}

	/**
	 * Delete an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to delete
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean deleteHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryConfigAccess(this.dbAccess).delete(pDto));
	}

	/**
	 * Update an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to update
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryConfigAccess(this.dbAccess).update(pDto));
	}

	/**
	 * Insert an interactive maintenance plan history config in the database.
	 * 
	 * @param pDto
	 *            the history config to insert
	 * 
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean addHistoryConfig(MpHistoryConfigDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryConfigAccess(this.dbAccess).create(pDto));
	}

	/**
	 * Get value of coupon code for tolerance for a maintenance plan.
	 * 
	 * @param planId : maintenance plan identifier
	 * @return value of coupon code for tolerance
	 * @throws SystemException system exception
	 */
	public MpIntervalDto getCouponTolerance(String planId) throws SystemException {
		return (getAccessFactory().getMpIntervalAccess().getCouponTolerance(planId));
	}

	/**
	 * Select a list of interactive maintenance plan interval history in the database for a plan and an an origin SAP/eTIM.
	 * 
	 * @param vin
	 *            the vin
	 * @param filterOrigin
	 *            the filterOrigin
	 * @param dateFrom
	 *            the date of history beginning
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	//	public List<MpHistoryIntervalDto> readListFromDateByOrigin(String vin, Integer filterOrigin, long dateFrom) throws SystemException {
	//		return (getAccessFactory().getMpHistoryIntervalAccess().readListFromDateByOrigin(vin, filterOrigin, dateFrom));
	//	}

	/**
	 * Select the VIN without sap claim.
	 * 
	 * @return the request result
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public List<MpHistoryIntervalDto> getVinWithoutSapClaim() throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().getVinWithoutSapClaim());
	}

	/**
	 * udpate the hour for SAP history using eTim hour.
	 * 
	 * @param sapDto
	 *            the SAP interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateHourHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).updateHourHistoryInterval(sapDto, toleranceToMatch));
	}

	/**
	 * udpate the km for SAP history using eTim hour.
	 * 
	 * @param sapDto
	 *            the SAP interval history to insert
	 * @param toleranceToMatch : tolerance to match
	 * @return the request result
	 * 
	 * @throws SystemException
	 *             cannot execute query or access to database
	 */
	public boolean updateKmHistoryInterval(MpHistoryIntervalDto sapDto, long toleranceToMatch) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).updateKmHistoryInterval(sapDto, toleranceToMatch));
	}

	/**
	 * Return the complete list of history for a VIN and origin.
	 * 
	 * @param pinVin The PIN or VIN
	 * @param origin the origin of the history:
	 *            - 0 --> TIDB
	 *            - 1 --> SAP
	 *            - 2 --> UCR
	 * 
	 * @return the complete list of UCR history for a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpHistoryIntervalDto> getHistoryByVinAndOrigin(String pinVin, Integer origin) throws SystemException {
		return getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).getHistoryByVinAndOrigin(pinVin, origin);
	}

	/**
	 * Update the failure date of a claim.
	 * 
	 * @param idToUpdate claim id
	 * @param timestampFailure failure date in milliseconds
	 * @param vin VIN
	 */
	public void updateFailureDateForClaim(String idToUpdate, long timestampFailure, String vin) throws SystemException {
		getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).updateFailureDateForClaim(idToUpdate, timestampFailure, vin);
	}

	/**
	 * Get all the coupons with the description of the coupons by language.
	 * 
	 * @param lang the language
	 * @param famGroupIceCode family and group icecode concatenated.
	 * @return the list of coupons.
	 * @throws SystemException
	 */
	public List<MpIntervalDto> getAllCouponsByLang(String lang, String famGroupIceCode) throws SystemException {
		return getAccessFactory().getMpIntervalAccess().getAllCouponsByLang(lang, famGroupIceCode);
	}

	/**
	 * Get the maxEngineHour from a list of intervals for the last month of each interval
	 * 
	 * @param pDto
	 * @return
	 * @throws SystemException
	 */
	public MpHistoryIntervalDto getMaxEngineHour(MpHistoryIntervalDto pDto) throws SystemException {
		return (getAccessFactory().getMpHistoryIntervalAccess().getMaxEngineHour(pDto));
	}

	public boolean shouldUpdateHoursHistoryInterval(MpHistoryIntervalDto sapDto) throws SystemException {
		IMpHistoryIntervalAccess access = getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess);

		Optional<Long> hoursValue = access.fetchLatestHoursValue(sapDto);

		if (hoursValue.isPresent() && hoursValue.get() == 0)
		{
			Optional<Long> lastRecordHoursValue = access.fetchLastRecordHoursValue(sapDto);
			return lastRecordHoursValue.isPresent() && lastRecordHoursValue.get() != 0;
		}

		return false;
	}

	public boolean executeUpdateHoursHistoryInterval(MpHistoryIntervalDto sapDto, long secondToMatch) throws SystemException {
		return getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).executeUpdateHoursHistoryInterval(sapDto, secondToMatch);
	}

	/**
	 * Function which will retrieve the history intervals for the maintenance history export cron job of 22:00 P.M.
	 * 
	 * @param lastExportDate The last export date from which to retrieve the records.
	 * @return List of the retrieved history interval dtos.
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public List<MpHistoryIntervalDto> getCouponsForCsvExport(Date lastExportDate, Date firstExportDate) throws SystemException {
		return getAccessFactory().getMpHistoryIntervalAccess(this.dbAccess).getCouponsForCsvExport(lastExportDate, firstExportDate);
	}
}
