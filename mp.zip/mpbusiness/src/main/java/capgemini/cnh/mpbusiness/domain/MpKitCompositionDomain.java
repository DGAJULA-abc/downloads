package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpKitCompositionDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpKitCompositionDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpKitCompositionDomain() {
	}

	/**
	 * Get the composition of a kit.
	 * 
	 * @param selectedKitId for filter
	 * @return a list of intervals
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpKitCompositionDto> getPartsListByKit(String selectedKitId) throws SystemException, ApplicativeException {
		List<MpKitCompositionDto> myDto = getAccessFactory().getMpKitCompositionAccess().getPartsListByKit(selectedKitId);
		return myDto;
	}

}
