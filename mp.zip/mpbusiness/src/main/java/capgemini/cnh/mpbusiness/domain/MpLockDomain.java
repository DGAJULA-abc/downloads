package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpLockDto;

/**
 * 
 * @author cblois
 *
 */
public class MpLockDomain extends Domain {
	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpLockDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}


	/**
	 * Constructor.
	 * 
	 */
	public MpLockDomain() {
		super();
	}

	/**
	 * Add MP lock in database.
	 * 
	 * @param vin : a vin and a the current date to be inserted
	 * @return true if row inserted
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean addMpLock(String vin) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpLockAccess(this.dbAccess)).addMpLock(vin);
	}

	/**
	 * Remove MP lock in database.
	 * 
	 * @param vin : a vin
	 * @return true if row removed
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public boolean removeMpLock(String vin) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpLockAccess(this.dbAccess)).removeMpLock(vin);
	}

}
