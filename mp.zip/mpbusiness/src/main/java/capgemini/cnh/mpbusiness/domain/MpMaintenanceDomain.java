/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpMaintenanceDto;

/**
 *
 * @author lestrabo
 */
public class MpMaintenanceDomain extends Domain {

	/**
	 * 
	 */
	public MpMaintenanceDomain() {
		super();
	}

	public List<MpMaintenanceDto> getUrgentMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue, String connectedType)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getUrgentMaintenances(dealerCode, brandIceCode, date, customerCode, mpCallStatusValue, connectedType);

	}

	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomers(String dealerCode, String brandIceCode, String date) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getUrgentMaintenancesForAllCustomers(dealerCode, brandIceCode, date);

	}

	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCode(String dealerCode, String brandIceCode, String date, String customerCode) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getUrgentMaintenancesByCustomerCode(dealerCode, brandIceCode, date, customerCode);

	}

	public List<MpMaintenanceDto> getNextMaintenances(String dealerCode, String brandIceCode, String date, String customerCode, String connectedType) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getNextMaintenances(dealerCode, brandIceCode, date, customerCode, connectedType);

	}

	public List<MpMaintenanceDto> getUrgentMaintenancesByCustomerCodeAndCallStatus(String dealerCode, String brandIceCode, String date, String customerCode, String mpCallStatusValue)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getUrgentMaintenancesByCustomerCodeAndCallStatus(dealerCode, brandIceCode, date, customerCode, mpCallStatusValue);

	}

	public List<MpMaintenanceDto> getUrgentMaintenancesForAllCustomersAndCallStatus(String dealerCode, String brandIceCode, String date, String mpCallStatusValue)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().getUrgentMaintenancesForAllCustomersAndCallStatus(dealerCode, brandIceCode, date, mpCallStatusValue);

	}

	public boolean isExistingPlanId(Long planId)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpMaintenanceAccess().isExistingPlanId(planId);

	}

}
