package capgemini.cnh.mpbusiness.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpNextStopAlertDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopMinDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * @author bmilcend
 */
public class MpNextStopDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 *
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpNextStopDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 */
	public MpNextStopDomain() {
		super();
	}

	/**
	 * Get VIN list with updated plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPlan() throws SystemException {
		List<MpNextStopMinDto> myDto = getAccessFactory().getMpNextFlexStopMinAccess().getVinWithUpdatedPlan();
		return myDto;
	}

	/**
	 * Get VIN list with new plan.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithNewPlan() throws SystemException {
		List<MpNextStopMinDto> myDto = getAccessFactory().getMpNextFlexStopMinAccess().getVinWithNewPlan();
		return myDto;
	}

	/**
	 * Get VIN list with updated performance EDS.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithUpdatedPerformanceEDS() throws SystemException {
		List<MpNextStopMinDto> myDto = getAccessFactory().getMpNextFlexStopMinAccess().getVinWithUpdatedPerformanceEDS();
		return myDto;
	}

	/**
	 * Get VIN list with coupon in overdue.
	 *
	 * @return list of VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopMinDto> getVinWithCouponOverdue() throws SystemException {
		List<MpNextStopMinDto> myDto = getAccessFactory().getMpNextFlexStopMinAccess().getVinWithCouponOverdue();
		return myDto;
	}

	/**
	 * Update the proposal date into the table .
	 *
	 * @throws SystemException SystemException
	 */
	public void updateNextStopProposalDate() throws SystemException {
		getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).updateNextStopProposalDate();
	}

	/**
	 * add Mp next stop flexible in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStopFlex(MpNextStopDto nextStops) throws SystemException {
		Long result = getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).addNextStopFlex(nextStops);
		return result;
	}

	/**
	 * Get flexible next stop.
	 *
	 * @param vin       : vin to find
	 * @param coupon    : coupon code to find
	 * @param fromCroom : 1 external 0 internal
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public MpNextStopDto getNextStopFlexible(String vin, String coupon, Integer fromCroom) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().getNextStopFlexible(vin, coupon, fromCroom);
	}

	/**
	 * update Mp next stop flexible in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopFlex(MpNextStopDto nextStops) throws SystemException {
		Long result = null;
		getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).updateNextStopFlex(nextStops);
		return result;
	}

	/**
	 * update Mp next stop flexible in database for alert without mileage.
	 *
	 * @param vin       : vin
	 * @param currentKm : currentKm
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopFlexAlertNoValue(String vin, Long currentKm) throws SystemException {
		Long result = null;
		getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).updateNextStopFlexAlertNoValue(vin, currentKm);
		return result;
	}

	/**
	 * add Mp next stop in database.
	 *
	 * @param nextStops : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStop(MpNextStopDto nextStops) throws SystemException {
		Long result = null;
		getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).addNextStop(nextStops);
		return result;
	}

	/**
	 * Update Mp next stop min proposal date.
	 *
	 * @param minNextStop : to be updated
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long updateNextStopMinProposalDate(MpNextStopMinDto minNextStop) throws SystemException {
		Long result = null;
		getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).updateNextStopMinProposalDate(minNextStop);
		return result;
	}

	/**
	 * add Mp next stop min in database.
	 *
	 * @param nextStop : to be inserted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long addNextStopMin(MpNextStopMinDto nextStop) throws SystemException {
		Long result = null;
		getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).addMpNextStopMin(nextStop);
		return result;
	}

	/**
	 * delete Mp next stop min in database for one vin.
	 *
	 * @param vin : vin to delete
	 * @return a value different from 0 if row deleted
	 * @throws SystemException system exception
	 */
	public Long deleteNextStopMin(String vin) throws SystemException {
		Long result = null;
		result = getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).deleteMpNextStopMin(vin);
		return result;
	}

	/**
	 * delete Mp next stop flexible in database.
	 *
	 * @param vin : to be deleted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long deleteNextStopFlexible(String vin) throws SystemException {
		Long result = null;
		result = getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).deleteNextStopFlexible(vin);
		return result;
	}

	/**
	 * delete Mp next stop in database.
	 *
	 * @param vin : to be deleted
	 * @return a value different from 0 if row inserted
	 * @throws SystemException system exception
	 */
	public Long deleteNextStop(List<String> lstPinVin) throws SystemException {
		Long result = null;
		result = getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).deleteNextStop(lstPinVin);
		return result;
	}

	/**
	 * Get next flexible stop not done.
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextFlexibleStopNotDone(String vin) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().getNextFlexibleStopNotDone(vin);
	}

	/**
	 * Get next stop .
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getNextStops(List<String> lstPinVin) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().getNextStops(lstPinVin);
	}

	/**
	 * Get all next flexible stop .
	 *
	 * @param vin : vin to find
	 * @return list of next stop for flexible coupons fot a VIN
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopDto> getAllNextStopFlexibles(String vin) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().getAllNextStopFlexibles(vin);
	}

	/**
	 * Get min next stop.
	 *
	 * @param vin : vin to find
	 * @return min next stop
	 * @throws SystemException SystemException
	 */
	public MpNextStopMinDto getMpNextStopMin(List<String> lstPinVin) throws SystemException {
		return getAccessFactory().getMpNextFlexStopMinAccess().getMpNextStopMin(lstPinVin);
	}

	/**
	 * Check if plan changed .
	 *
	 * @param vin    : vin to find
	 * @param planId : planId to find
	 * @return true if plan change
	 * @throws SystemException SystemException
	 */
	public boolean checkPlanChange(List<String> lstPinVin, Long planId) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().checkPlanChange(lstPinVin, planId);
	}

	/**
	 * Set the flag to 1 for new alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewKmAlerts() throws SystemException {
		getAccessFactory().getMpNextFlexStopMinAccess().setFlagForNewKmAlerts();
	}

	/**
	 * Set the flag to 1 for new alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewHourAlerts() throws SystemException {
		getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).setFlagForNewHourAlerts();
	}

	/**
	 * Set the flag to 1 for new alerts.
	 *
	 * @throws SystemException SystemException
	 */
	public void setFlagForNewMonthAlerts() throws SystemException {
		getAccessFactory().getMpNextFlexStopMinAccess(this.dbAccess).setFlagForNewMonthAlerts();
	}

	/**
	 * Get the list of VIN-COUPON in alerts.
	 *
	 * @param alertType:         the alertType
	 * @param isFlexibleCoupons: true if we want to get flexible coupons (MP_NEXT_FLEX_STOP_WK table)
	 * @return the list of VIN-COUPON in alerts.
	 * @throws SystemException SystemException
	 */
	public List<MpNextStopAlertDto> getCouponInAlert(MpType alertType, boolean isFlexibleCoupons) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAlertAccess().getCouponInAlert(alertType, isFlexibleCoupons);
	}

	/**
	 * Get next stop .
	 *
	 * @param vin    : vin to find
	 * @param coupon : coupon code to find
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public MpNextStopDto getNextStop(String vin, String coupon) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().getNextStop(vin, coupon);
	}

	/**
	 * Get next stop wih last mileage.
	 *
	 * @param vin : vin to find
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public MpNextStopMinDto getMpNextStopMinWithLastMileage(String vin) throws SystemException {
		return getAccessFactory().getMpNextFlexStopMinAccess().getMpNextStopMinWithLastMileage(vin);
	}

	/**
	 * Update call state of MP Next Stop Min (0 not called 1 called 2 to recall).
	 *
	 * @param vin               : vin to find
	 * @param mpCallStatusValue : mpCallStatusValue
	 * @return the next stop for a flexible coupon and a VIN
	 * @throws SystemException SystemException
	 */
	public boolean updateCallStatusByVin(String vin, Integer mpCallStatusValue) throws SystemException {
		return getAccessFactory().getMpNextFlexStopMinAccess().updateCallStatus(vin, mpCallStatusValue);
	}

	/**
	 * Delete flex coupon in from external alert .
	 *
	 * @param dto : dto to delete
	 * @return value different from 0 if deleted
	 * @throws SystemException SystemException
	 */
	public Long deleteCouponExternalAlert(MpNextStopDto dto) throws SystemException {
		return getAccessFactory().getMpNextFlexStopAccess().deleteCouponExternalAlert(dto);
	}

	/**
	 * Get the min proposal date by vin.
	 *
	 * @param vins the vins
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<String, Date> getProposalDateByVin(Set<String> vins) throws SystemException {
		return getAccessFactory().getMpNextFlexStopMinAccess().getProposalDateByVin(vins);
	}

	/**
	 * Get the min proposal date by vin. (called by MpServices) Vins not identified for the recreation of alert but in alert.
	 *
	 * @param vins the vins already recreated
	 * @return the list of couples (vin, proposal date)
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public Map<String, Date> getProposalDateByVinInAlertNotInVins(Set<String> vins) throws SystemException {
		return getAccessFactory().getMpNextFlexStopMinAccess().getProposalDateByVinInAlertNotInVins(vins);
	}

	public void setNextStopComparison(String vin, Integer comparisonResult, String edsNextStopJson, String etimNextStopJson) throws SystemException {
		getAccessFactory().getMpNextFlexStopAccess(this.dbAccess).setNextStopComparison(vin, comparisonResult, edsNextStopJson, etimNextStopJson);
	}

}
