package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpOperationConsumableDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpOperationConsumableDomain() {
	}

	/**
	 * Get the List of consumables for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param language for translated texts
	 * @param defaultLanguage : default Language
	 * @param brandId : the brand id
	 * @param dtoIceContext context
	 * 
	 * @return the list of consumables
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpOperationConsumableDto> getListConsumablesByOp(Long idSeriesOperation, String language, String defaultLanguage, Long brandId, IceContextDto dtoIceContext)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpOperationConsumableAccess().getListConsumablesByOp(idSeriesOperation, language, defaultLanguage, brandId, dtoIceContext);

	}

	/**
	 * Get part number and occurrences name by consumable id and language.
	 * 
	 * @param consId consId
	 * @param language language
	 * @param isUsingDefaultLanguage defaultLanguage
	 * @param dtoIceContext dtoIceContext
	 * @return MpOperationConsumableDto dto
	 * @throws SystemException SystemException
	 */
	public MpOperationConsumableDto getConsumablesPnByConsIdAndCountryAndMarket(Long consId, Long consOccId, String country, String marketId)
			throws SystemException {

		return getAccessFactory().getMpOperationConsumableAccess().getConsumablesPnByConsIdAndCountryAndMarket(consId, consOccId, country, marketId);
	}

	/**
	 * Get part number and occurrences name by consumable id and language.
	 * 
	 * @param consId consId
	 * @param language language
	 * @param defaultLanguage defaultLanguage
	 * @param dtoIceContext dtoIceContext
	 * @return MpOperationConsumableDto dto
	 * @throws SystemException SystemException
	 */
	public MpOperationConsumableDto getConsumablesOccByConsId(Long consId, boolean defaultLanguage, IceContextDto dtoIceContext) throws SystemException {
		return getAccessFactory().getMpOperationConsumableAccess().getConsumablesOccByConsId(consId, defaultLanguage, dtoIceContext);

	}

}
