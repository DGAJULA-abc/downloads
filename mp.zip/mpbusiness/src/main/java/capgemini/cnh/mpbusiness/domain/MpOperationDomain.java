package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpIntervalOperationDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpOperationDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpOperationDomain() {
	}

	/**
	 * Get the List of operations by plan and intervals.
	 * 
	 * @param planId to filter
	 * @param intervalId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getListOperations(String intervalId, String language,
			String defaultLanguage) throws SystemException {
		List<MpIntervalOperationDto> myDto = getAccessFactory().getMpOperationAccess().getListOperations(intervalId, language, defaultLanguage);

		return myDto;
	}

	/**
	 * Get the operation by operation series id.
	 * 
	 * @param planId to filter
	 * @param language to filter
	 * @param defaultLanguage : default Language
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getOperation(Long opeSerId, String language, String defaultLanguage)
			throws SystemException {
		List<MpIntervalOperationDto> myDto = getAccessFactory().getMpOperationAccess().getOperation(opeSerId, language,
				defaultLanguage);

		return myDto;
	}

	/**
	 * Get the operation with the label of the series using its id.
	 * 
	 * @param operation to filter
	 * 
	 * @return the list of operations
	 * @throws SystemException system exception
	 */
	public List<MpIntervalOperationDto> getOperationWithSeriesLabel(MpIntervalOperationDto operation, String language,
			String defaultLanguage) throws SystemException {
		List<MpIntervalOperationDto> myDto = getAccessFactory().getMpOperationAccess()
				.getOperationWithSeriesLabel(operation, language, defaultLanguage);

		return myDto;
	}
}
