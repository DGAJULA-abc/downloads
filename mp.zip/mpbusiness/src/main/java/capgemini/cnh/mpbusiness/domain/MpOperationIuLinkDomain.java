package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpOperationIuLinkDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpOperationIuLinkDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpOperationIuLinkDomain() {
	}

	/**
	 * Get the List of Ius for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * 
	 * @return the list of IUs
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpOperationIuLinkDto> getListIusByOp(Long idSeriesOperation)
			throws SystemException, ApplicativeException {
		List<MpOperationIuLinkDto> myDto = getAccessFactory().getMpOperationIuLinkAccess().getListIusByOp(idSeriesOperation);
		return myDto;
	}

}
