package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpOperationPartDto;
import capgemini.cnh.mpbusiness.dto.MpPartDescriptionDto;

/**
 * 
 * @author mamestoy
 *
 */
public class MpOperationPartDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpOperationPartDomain() {
	}

	/**
	 * Get the List of parts for a given operation on a series.
	 * 
	 * @param idSeriesOperation to filter
	 * @param context context
	 * 
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpOperationPartDto> getListPartsByOp(String idSeriesOperation, IceContextDto context) throws SystemException, ApplicativeException {
		List<MpOperationPartDto> myDto = getAccessFactory().getMpOperationPartAccess().getListPartsByOp(idSeriesOperation, context);
		return myDto;
	}

	/**
	 * Get the List of parts for a given part for all the languages.
	 * 
	 * @param code the part code
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPartDescriptionDto> getPartsByCode(String code) throws SystemException {
		return getAccessFactory().getMpPartDescriptionAccess().getPartsByCode(code);
	}

	/**
	 * Get the part for a given part and specific language.
	 * 
	 * @param code the part code
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public MpPartDescriptionDto getPartsByCodeAndLanguage(String code, String language) throws SystemException {
		return getAccessFactory().getMpPartDescriptionAccess().getPartsByCodeAndLanguage(code, language);
	}

	/**
	 * Get the part for a given part list and specific language.
	 * 
	 * @param partList the part list
	 * @param language the part language
	 * @return the part
	 * @throws SystemException system exception
	 */
	public List<MpPartDescriptionDto> getPartsDescriptionByLanguage(List<String> partList, String language) throws SystemException {
		return getAccessFactory().getMpPartDescriptionAccess().getPartsDescriptionByLanguage(partList, language);
	}

	/**
	 * Get the List of parts for label for a list of parts.
	 * 
	 * @param partList the part list
	 * @return the list of parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpOperationPartDto> getParts(List<String> partList) throws SystemException {
		return getAccessFactory().getMpOperationPartAccess().getParts(partList);
	}

	/**
	 * Get the pars label .
	 * 
	 * @param part the part
	 * @return the parts
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpOperationPartDto getPart(String part) throws SystemException {
		return getAccessFactory().getMpOperationPartAccess().getPart(part);
	}

}
