package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPartDetailDto;

/**
 * 
 * @author cblois
 *
 */
public class MpPartDetailDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpPartDetailDomain() {
	}

	/**
	 * Get a part detail.
	 * 
	 * @param partNumber to find
	 * @return the part
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPartDetailDto getPartDetail(String partNumber) throws SystemException, ApplicativeException {
		return getAccessFactory().MpPartDetailAccess().getPartDetail(partNumber);
	}

}
