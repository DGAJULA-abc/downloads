package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPartSupersessionDto;

/**
 * 
 * @author cblois
 *
 */
public class MpPartSupersessionDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpPartSupersessionDomain() {
	}

	/**
	 * Get a list part supersession.
	 * 
	 * @param partNumber to find the supersession chain
	 * @return a list part supersession
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPartSupersessionDto> getSupersessionList(String partNumber) throws SystemException, ApplicativeException {
		List<MpPartSupersessionDto> myDto = getAccessFactory().MpPartSupersessionAccess().getSupersessionList(partNumber);
		return myDto;
	}
}
