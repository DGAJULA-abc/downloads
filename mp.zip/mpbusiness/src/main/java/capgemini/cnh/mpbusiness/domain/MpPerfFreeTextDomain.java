package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpPerfFreeTextDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpPerfFreeTextDomain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpPerfFreeTextDomain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpPerfFreeTextDomain() {
		super();
	}

	/**
	 * Get the free text performances for a series.
	 * 
	 * @param planId the plan id
	 * @return the list of all the free text performances for a series.
	 * @throws SystemException SystemException
	 */
	public List<MpPerfFreeTextDto> getPerformancesForSeries(String planId, String language) throws SystemException {
		return getAccessFactory().getMpPerfFreeTextAccess().getPerformancesForSeries(planId, language);
	}
}
