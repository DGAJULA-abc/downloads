package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.product.SeriesDto;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;

/**
 * 
 * @author cblois
 *
 */
public class MpPlanDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpPlanDomain() {
	}

	/**
	 * Get the plan list by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * 
	 * @return a list of applicable plan
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getListByProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException, ApplicativeException {
		List<MpPlanDto> myDto = getAccessFactory().getMpPlanAccess().getListByProjectList(projectIdList, context);
		return myDto;
	}

	/**
	 * Get the plan by id.
	 * 
	 * @param planId filter on plan id
	 * 
	 * @return the plan
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getPlan(Long planId) throws SystemException, ApplicativeException {

		MpPlanDto planDto = getAccessFactory().getMpPlanAccess().getPlan(planId);
		return planDto;
	}

	/**
	 * Get the performance list by plan list.
	 * 
	 * @param planList for filter
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getPerformanceListByPlanList(String planList) throws SystemException, ApplicativeException {
		List<MpPlanDto> myDto = getAccessFactory().getMpPlanAccess().getPerformanceListByPlanList(planList);
		return myDto;
	}

	public MpPlanDto getPerformanceForPlanId(String PlanExtId, String projectNumber, String version) throws SystemException {
		MpPlanDto myDto = getAccessFactory().getMpPlanAccess().getPerformanceForPlanId(PlanExtId, projectNumber, version);
		return myDto;
	}

	/**
	 * Get the number of plans with hour in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plan
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithHour(String planList) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpPlanAccess().getNbPlanWithHour(planList);
	}

	/**
	 * Get the number of plans with mileage in plan list.
	 * 
	 * @param planList for filter
	 * @return nb plan
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public Long getNbPlanWithMileage(String planList) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpPlanAccess().getNbPlanWithMileage(planList);
	}

	/**
	 * Get the plan applicable to the criteria.
	 * 
	 * @param planList list of plan
	 * @param usageId usage Id
	 * @param performance performance
	 * 
	 * @return list of plans
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpPlanDto> getPlanWithCriteria(List<Long> planList, int usageId, String performance) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpPlanAccess().getPlanWithCriteria(planList, usageId, performance);
	}

	/**
	 * <b>Publication Etim-Offline.</b>
	 * 
	 * @param serie serie
	 * @return list of plans
	 * @throws SystemException a system exception
	 */
	public List<MpPlanDto> getMaintenancePlanBySerie(SeriesDto serie) throws SystemException {
		return getAccessFactory().getMpPlanAccess().getMaintenancePlanBySerie(serie);
	}

	/**
	 * Get the external plan id.
	 * 
	 * @param planId for filter
	 * @return external plan id
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public MpPlanDto getExternalPlanId(Long planId) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpPlanAccess().getExternalPlanId(planId);
	}

	/**
	 * Get the publication date of the IU.
	 * 
	 * @param planId the id of the plan
	 * @param projectVersion the version of the project
	 * @return the IU information
	 * @throws SystemException a system exception
	 */
	public MpPlanDto getMpIuPublicationDate(Long planId, Integer projectVersion) throws SystemException {
		return getAccessFactory().getMpPlanAccess().getMpIuPublicationDate(planId, projectVersion);
	}

	/**
	 * Get the last version of the plan applicable.
	 * 
	 * @param planExtId the id of the plan
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto getMpCurrentPlanApplicable(Long planExtId) throws SystemException {
		return getAccessFactory().getMpPlanAccess().getMpCurrentPlanApplicable(planExtId);
	}

	/**
	 * Return plan if applicable to the context.
	 * 
	 * @param planId the id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkPlanApplicable(Long planId, IceContextDto context, List<Integer> projectList) throws SystemException {
		return getAccessFactory().getMpPlanAccess().checkPlanApplicable(planId, context, projectList);
	}

	/**
	 * Return plan id if applicable to the context.
	 * 
	 * @param planExtId the external id of the plan
	 * @param context the context
	 * @param projectList list of potential applicable project
	 * @return the plan applicable
	 * @throws SystemException a system exception
	 */
	public MpPlanDto checkLastVersionPlanApplicable(Long planExtId, IceContextDto context, List<Integer> projectList) throws SystemException {
		return getAccessFactory().getMpPlanAccess().checkLastVersionPlanApplicable(planExtId, context, projectList);
	}

	/**
	 * Get the plan by external plan id.
	 * 
	 * @param planExtId the external plan id
	 * @return the plan
	 * @throws SystemException SystemException
	 */
	public MpPlanDto getPlanByExtId(Long planExtId) throws SystemException {
		return getAccessFactory().getMpPlanAccess().getPlanByExtId(planExtId);
	}

	/**
	 * Get all the plans for a series.
	 * 
	 * @param brandIcecode
	 * @param typeIcecode
	 * @param productIcecode
	 * @param seriesIcecode
	 * @return
	 * @throws SystemException
	 */
	public List<MpPlanDto> getPlanAndApplicabilityBySeries(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException {
		return getAccessFactory().getMpPlanAccess().getPlanAndApplicabilityBySeries(brandIcecode, typeIcecode, productIcecode, seriesIcecode);
	}
}
