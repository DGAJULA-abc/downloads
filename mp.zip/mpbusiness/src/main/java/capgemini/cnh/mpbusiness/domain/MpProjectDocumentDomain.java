/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpProjectDocumentDto;

/**
 * @author sdomecq
 *
 */
public class MpProjectDocumentDomain extends Domain {

	/**
	 * Constructor.
	 */
	public MpProjectDocumentDomain() {
	}

	/**
	 * Get the List of project .
	 * 
	 * @param context for applicability
	 *
	 * @return the list of projects
	 * @throws SystemException Cannot execute query or access to database.
	 * @throws ApplicativeException application exception
	 */
	public List<MpProjectDocumentDto> getList(IceContextDto context) throws SystemException, ApplicativeException {
		return getAccessFactory().getProjectDocumentAccess().getList(context);
	}
}
