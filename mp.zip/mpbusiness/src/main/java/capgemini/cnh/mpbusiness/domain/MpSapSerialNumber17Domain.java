package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpSapSerialNumber17Dto;

/**
 * 
 * @author jdespeau
 *
 */
public class MpSapSerialNumber17Domain extends Domain {

	/** Transaction access. */
	private Access dbAccess;

	/**
	 * Constructor.
	 * 
	 * @param dbAccess : the connection information in case of transaction
	 */
	public MpSapSerialNumber17Domain(Access dbAccess) {
		super();
		this.dbAccess = dbAccess;
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpSapSerialNumber17Domain() {
		super();
	}

	/**
	 * Get Sap Vin 17 From Sap Vin.
	 * 
	 * @param sapVin
	 * @return MpSapSerialNumber17Dto
	 * @throws SystemException Cannot execute query or access to database.
	 */
	public MpSapSerialNumber17Dto getSapSerialNumber17FromSapVin(String sapVin) throws SystemException, ApplicativeException {
		return (getAccessFactory().getMpSapSerialNumber17Access().getSapSerialNumber17FromSapVin(sapVin));
	}

}
