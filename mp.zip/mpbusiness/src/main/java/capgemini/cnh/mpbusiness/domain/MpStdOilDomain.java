package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.dto.MpStdOilDto;

/**
 * 
 * @author cblois
 *
 */
public class MpStdOilDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpStdOilDomain() {
	}

	/**
	 * Get the list of standard oil by project list.
	 * 
	 * @param projectIdList filter on project id
	 * @param context filter on market, model & TT
	 * 
	 * @return a list of applicable plan
	 * 
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpStdOilDto> getStdOilsyProjectList(List<Integer> projectIdList, IceContextDto context) throws SystemException, ApplicativeException {
		List<MpStdOilDto> myDto = getAccessFactory().getMpStdOilAccess().getStdOilsyProjectList(projectIdList, context);
		return myDto;
	}
}
