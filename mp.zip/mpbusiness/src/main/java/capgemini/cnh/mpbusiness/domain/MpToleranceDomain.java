/**
 * 
 */
package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpToleranceDto;

/**
 *
 * @author jdespeau
 */
public class MpToleranceDomain extends Domain {

	/**
	 * 
	 */
	public MpToleranceDomain() {
		super();
	}

	public MpToleranceDto getToleranceByBrandAndMarket(String brandIceCode, Long marketId)
			throws SystemException, ApplicativeException {
		return getAccessFactory().getMpToleranceAccess().getToleranceByBrandAndMarket(brandIceCode, marketId);
	}

}
