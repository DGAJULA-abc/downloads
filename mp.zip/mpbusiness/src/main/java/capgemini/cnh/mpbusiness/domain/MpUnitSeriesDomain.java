package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpUnitSeriesDto;

/**
 * 
 * @author cblois
 *
 */
public class MpUnitSeriesDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpUnitSeriesDomain() {
	}

	/**
	 * Get unit by serie.
	 * 
	 * @param context
	 * @return the MpUnitSeriesDto
	 * @throws SystemException
	 * @throws ApplicativeException
	 */
	public MpUnitSeriesDto getUnitBySerie(String brandIcecode, String typeIcecode, String productIcecode, String seriesIcecode) throws SystemException, ApplicativeException {
		return getAccessFactory().getMpUnitSeriesAccess().getUnitBySerie(brandIcecode, typeIcecode, productIcecode, seriesIcecode);
	}

}
