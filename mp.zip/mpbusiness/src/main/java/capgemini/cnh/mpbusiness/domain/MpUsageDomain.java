package capgemini.cnh.mpbusiness.domain;

import java.util.List;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.cache.domain.CacheDomain;
import capgemini.cnh.mpbusiness.cache.domain.CacheMpUsageItemDomain;
import capgemini.cnh.mpbusiness.cache.domain.CacheMpUsageValueDomain;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * 
 * @author cblois
 *
 */
public class MpUsageDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpUsageDomain() {
	}

	/**
	 * Get the usage list by plan list.
	 * 
	 * @param planList for filter
	 * @param language for display
	 * @param defaultLanguage : default Language
	 * @return a list of oilType
	 * @throws SystemException system exception
	 * @throws ApplicativeException application exception
	 */
	public List<MpUsageDto> getListByPlanList(String planList, String language, String defaultLanguage) throws SystemException, ApplicativeException {
		List<MpUsageDto> myDto = getAccessFactory().getMpUsageAccess().getListByPlanList(planList, language, defaultLanguage);
		return myDto;
	}

	/**
	 * Get mp usage item translation for the given language.
	 * 
	 * @param itemId the mp usage item id
	 * @param language the language for translation
	 * @return the mp usage item translated
	 * @throws SystemException system exception
	 */
	public MpUsageDto getMpUsageItemTranslation(Long itemId, String language) throws SystemException {
		MpUsageDto myDto = null;

		if (CacheDomain.isCacheEnabled())
		{
			myDto = (new CacheMpUsageItemDomain()).getMpUsageItemTranslation(itemId, language);
		}
		else
		{
			myDto = getAccessFactory().getMpUsageAccess().getMpUsageItemTranslation(itemId, language);
		}

		return myDto;
	}

	/**
	 * Get mp usage value translation for the given language.
	 * 
	 * @param valueId the mp usage value id
	 * @param language the language for translation
	 * @return the mp usage value translated
	 * @throws SystemException system exception
	 */
	public MpUsageDto getMpUsageValueTranslation(int valueId, String language) throws SystemException {
		MpUsageDto myDto = null;

		if (CacheDomain.isCacheEnabled())
		{
			myDto = (new CacheMpUsageValueDomain()).getMpUsageValueTranslation(valueId, language);
		}
		else
		{
			myDto = getAccessFactory().getMpUsageAccess().getMpUsageValueTranslation(valueId, language);
		}

		return myDto;
	}

	/**
	 * Get all the avalable missions.
	 * 
	 * @return all the mission ids.
	 * @throws SystemException SystemException
	 */
	public List<MpUsageDto> getAllAvailableMissionsIds() throws SystemException {
		List<MpUsageDto> missionList = getAccessFactory().getMpUsageAccess().getAllAvailableMissionsIds();

		return missionList;
	}
}
