package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpVehicleAverageDto;

/**
 * Super class of Domain.
 * 
 */
public class MpVehicleAverageDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpVehicleAverageDomain() {
		super();
	}

	/**
	 * Get the vehicle values for a vin.
	 * 
	 * @param vin : vin
	 * @return a vehicleAverage dto
	 * @throws SystemException system exception
	 */
	public MpVehicleAverageDto getVehicleAverageForVin(String vin) throws SystemException {
		return getAccessFactory().getMpVehicleAverageAccess().getVehicleAverageForVin(vin);
	}

}
