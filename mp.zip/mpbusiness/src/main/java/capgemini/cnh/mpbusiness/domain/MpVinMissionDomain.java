package capgemini.cnh.mpbusiness.domain;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.dto.MpVinMissionDto;

/**
 * Super class of Domain.
 * 
 */
public class MpVinMissionDomain extends Domain {

	/**
	 * Constructor.
	 * 
	 */
	public MpVinMissionDomain() {
		super();
	}

	/**
	 * Get the mission for a vin.
	 * 
	 * @param vinCode : vin
	 * @return a mission dto
	 * @throws SystemException system exception
	 */

	public MpVinMissionDto getMpMissionForVin(String vinCode) throws SystemException {
		return getAccessFactory().getMpVinMissionAccess().getMpMissionForVin(vinCode);
	}

}
