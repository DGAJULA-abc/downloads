/**
 * 
 */
package capgemini.cnh.mpbusiness.domain.hsql;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMonMaintenancePlanAccess;
import capgemini.cnh.mpbusiness.access.IMpAlertToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpAppointmentAccess;
import capgemini.cnh.mpbusiness.access.IMpClaimAccess;
import capgemini.cnh.mpbusiness.access.IMpToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.access.IMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.access.IMpCustomerAccess;
import capgemini.cnh.mpbusiness.access.IMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexContractAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.access.IMpIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.access.IMpLockAccess;
import capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationPartAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDetailAccess;
import capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.access.IMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.access.IMpPlanAccess;
import capgemini.cnh.mpbusiness.access.IMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.access.IMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.access.IMpStdOilAccess;
import capgemini.cnh.mpbusiness.access.IMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.access.IMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.access.IMpVinMissionAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpAlertToleranceAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpAppointmentAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpClaimAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpToleranceAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpCustomerAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpFlexContractAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpIntervalAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpLockAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpNextStopAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpOperationAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpOperationPartAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpPartDetailAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpPlanAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpStdOilAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpUsageAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.access.hsql.HsqlMpVinMissionAccess;
import capgemini.cnh.mpbusiness.domain.ITableAccessFactory;

/**
 * 
 * Project WCM
 * 
 * @author JMORAS creation date : 28 mai 08 $Header: $
 *         Last Change by pospital on 11 February 2009
 */

/**
 * class HsqlTableAccessFactory.
 */
public class HsqlTableAccessFactory implements ITableAccessFactory {

	/**
	 * constructor.
	 */
	public HsqlTableAccessFactory() {
		super();
	}

	/**
	 * Gives access to MP usage.
	 * 
	 * @return IMpUsageAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpUsageAccess getMpUsageAccess() throws SystemException {
		return new HsqlMpUsageAccess();
	}

	/**
	 * Gives access to MP usage.
	 * 
	 * @return IMpPlanAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpPlanAccess getMpPlanAccess() throws SystemException {
		return new HsqlMpPlanAccess();
	}

	/**
	 * Gives access to MP operation.
	 * 
	 * @return IMpOperationAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationAccess getMpOperationAccess() throws SystemException {
		return new HsqlMpOperationAccess();
	}

	/**
	 * Gives access to MP operation consumable.
	 * 
	 * @return IMpOperationConsumableAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationConsumableAccess getMpOperationConsumableAccess() throws SystemException {
		return new HsqlMpOperationConsumableAccess();
	}

	/**
	 * Gives access to MP operation part.
	 * 
	 * @return IMpOperationPartAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationPartAccess getMpOperationPartAccess() throws SystemException {
		return new HsqlMpOperationPartAccess();
	}

	/**
	 * Gives access to MP interval.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpIntervalAccess getMpIntervalAccess() throws SystemException {
		return new HsqlMpIntervalAccess();
	}

	@Override
	public IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess() throws SystemException {
		return (new HsqlMpHistoryWarrantyAccess());
	}

	@Override
	public IMpHistoryIntervalAccess getMpHistoryIntervalAccess() throws SystemException {
		return (new HsqlMpHistoryIntervalAccess());
	}

	@Override
	public IMpHistoryConfigAccess getMpHistoryConfigAccess() throws SystemException {
		return (new HsqlMpHistoryConfigAccess());
	}

	@Override
	public IMpPartDescriptionAccess getMpPartDescriptionAccess() throws SystemException {
		return (new HsqlMpPartDescriptionAccess());
	}

	@Override
	public IMpContractVehicleAccess getMpContractVehicleAccess() throws SystemException {
		return (new HsqlMpContractVehicleAccess());
	}

	@Override
	public IMpContractConfigurationAccess getMpContractConfigurationAccess() throws SystemException {
		return (new HsqlMpContractConfigurationAccess());
	}

	@Override
	public IMpKitCompositionAccess getMpKitCompositionAccess() throws SystemException {
		return (new HsqlMpKitCompositionAccess());
	}

	@Override
	public IMpStdOilAccess getMpStdOilAccess() throws SystemException {
		return (new HsqlMpStdOilAccess());
	}

	@Override
	public IMpVinMissionAccess getMpVinMissionAccess() throws SystemException {
		return (new HsqlMpVinMissionAccess());

	}

	@Override
	public IMpDefaultMissionAccess getMpDefaultMissionAccess() throws SystemException {
		return (new HsqlMpDefaultMissionAccess());

	}

	@Override
	public IMpNextStopAccess getMpNextFlexStopAccess() throws SystemException {
		return (new HsqlMpNextStopAccess());
	}

	@Override
	public IMpFlexStopDoneAccess getMpFlexStopDoneAccess() throws SystemException {
		return (new HsqlMpFlexStopDoneAccess());
	}

	@Override
	public IMpFlexCouponAccess getMpFlexCouponAccess() throws SystemException {
		return (new HsqlMpFlexCouponAccess());
	}

	@Override
	public IMpNextStopMinAccess getMpNextFlexStopMinAccess() throws SystemException {
		return (new HsqlMpNextStopMinAccess());
	}

	@Override
	public IMpFlexContractAccess getMpFlexContractAccess() throws SystemException {
		return (new HsqlMpFlexContractAccess());
	}

	@Override
	public IMpNextStopAlertAccess getMpNextFlexStopAlertAccess() throws SystemException {
		return (new HsqlMpNextStopAlertAccess());
	}

	@Override
	public IMpMaintenanceAccess getMpMaintenanceAccess() throws SystemException {
		return (new HsqlMpMaintenanceAccess());
	}

	@Override
	public IMpVehicleAverageAccess getMpVehicleAverageAccess() throws SystemException {
		return (new HsqlMpVehicleAverageAccess());
	}

	@Override
	public IMpCustomerAccess getMpCustomerAccess() throws SystemException {
		return (new HsqlMpCustomerAccess());
	}

	@Override
	public IMpClaimAccess getMpClaimAccess() throws SystemException {
		return (new HsqlMpClaimAccess());

	}

	@Override
	public IMpSapSerialNumber17Access getMpSapSerialNumber17Access() throws SystemException {
		return (new HsqlMpSapSerialNumber17Access());

	}

	@Override
	public IMpNextStopAccess getMpNextFlexStopAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpNextStopAccess(dbAccess));
	}

	@Override
	public IMpNextStopMinAccess getMpNextFlexStopMinAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpNextStopMinAccess(dbAccess));
	}

	@Override
	public IMpClaimAccess getMpClaimAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpClaimAccess());
	}

	@Override
	public IMpSapSerialNumber17Access getMpSapSerialNumber17Access(Access dbAccess) throws SystemException {
		return (new HsqlMpSapSerialNumber17Access(dbAccess));
	}

	@Override
	public IMpHistoryIntervalAccess getMpHistoryIntervalAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpHistoryIntervalAccess());
	}

	@Override
	public IMpFlexStopDoneAccess getMpFlexStopDoneAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpFlexStopDoneAccess());
	}

	@Override
	public IMpHistoryConfigAccess getMpHistoryConfigAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpHistoryConfigAccess());
	}

	@Override
	public IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpHistoryWarrantyAccess());
	}

	@Override
	public IMpLockAccess getMpLockAccess(Access dbAccess) throws SystemException {
		return (new HsqlMpLockAccess());
	}

	@Override
	public IMpPerfFreeTextAccess getMpPerfFreeTextAccess() throws SystemException {
		return new HsqlMpPerfFreeTextAccess();
	}

	@Override
	public IMpAlertToleranceAcess getMpAlertToleranceAccess() throws SystemException {
		return new HsqlMpAlertToleranceAccess();
	}

	/* (non-Javadoc)
	 * @see capgemini.cnh.mp.domain.ITableAccessFactory#getMpFlexCustomerSapAccess()
	 */
	@Override
	public IMpFlexCustomerSapAccess getMpFlexCustomerSapAccess() throws SystemException {
		return new HsqlMpFlexCustomerSapAccess();
	}

	@Override
	public IMpProjectDocumentAccess getProjectDocumentAccess() throws SystemException, ApplicativeException {
		return new HsqlMpProjectDocumentAccess();
	}

	@Override
	public IMpOperationIuLinkAccess getMpOperationIuLinkAccess() throws SystemException {
		return new HsqlMpOperationIuLinkAccess();
	}

	@Override
	public IMpPartSupersessionAccess MpPartSupersessionAccess() throws SystemException {
		return new HsqlMpPartSupersessionAccess();
	}

	@Override
	public IMpPartDetailAccess MpPartDetailAccess() throws SystemException {
		return new HsqlMpPartDetailAccess();
	}

	@Override
	public IMpUnitSeriesAccess getMpUnitSeriesAccess() throws SystemException {
		return new HsqlMpUnitSeriesAccess();
	}

	@Override
	public IMpAppointmentAccess getMpAppointmentAccess() throws SystemException {
		return new HsqlMpAppointmentAccess();
	}


	@Override
	public IMpToleranceAcess getMpToleranceAccess() throws SystemException {
		return new HsqlMpToleranceAccess();
	}
	
	@Override
	public IMonMaintenancePlanAccess getMonMaintenancePlanAccess() throws SystemException {
		// TODO Auto-generated method stub
		return null;
	}
}
