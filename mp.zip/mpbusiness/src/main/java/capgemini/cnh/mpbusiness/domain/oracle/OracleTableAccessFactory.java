/**
 * 
 */
package capgemini.cnh.mpbusiness.domain.oracle;

import capgemini.cnh.framework.access.Access;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.access.IMonMaintenancePlanAccess;
import capgemini.cnh.mpbusiness.access.IMpAlertToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpAppointmentAccess;
import capgemini.cnh.mpbusiness.access.IMpClaimAccess;
import capgemini.cnh.mpbusiness.access.IMpToleranceAcess;
import capgemini.cnh.mpbusiness.access.IMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.access.IMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.access.IMpCustomerAccess;
import capgemini.cnh.mpbusiness.access.IMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexContractAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.access.IMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.access.IMpIntervalAccess;
import capgemini.cnh.mpbusiness.access.IMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.access.IMpLockAccess;
import capgemini.cnh.mpbusiness.access.IMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.access.IMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.access.IMpOperationPartAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.access.IMpPartDetailAccess;
import capgemini.cnh.mpbusiness.access.IMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.access.IMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.access.IMpPlanAccess;
import capgemini.cnh.mpbusiness.access.IMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.access.IMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.access.IMpStdOilAccess;
import capgemini.cnh.mpbusiness.access.IMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.access.IMpUsageAccess;
import capgemini.cnh.mpbusiness.access.IMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.access.IMpVinMissionAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMonMaintenancePlanAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpAlertToleranceAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpAppointmentAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpClaimAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpToleranceAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpContractConfigurationAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpContractVehicleAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpCustomerAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpDefaultMissionAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpFlexContractAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpFlexCouponAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpFlexCustomerSapAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpFlexStopDoneAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpHistoryConfigAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpHistoryIntervalAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpHistoryWarrantyAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpIntervalAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpKitCompositionAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpLockAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpMaintenanceAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpNextStopAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpNextStopAlertAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpNextStopMinAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpOperationAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpOperationConsumableAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpOperationIuLinkAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpOperationPartAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpPartDescriptionAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpPartDetailAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpPartSupersessionAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpPerfFreeTextAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpPlanAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpProjectDocumentAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpSapSerialNumber17Access;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpStdOilAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpUnitSeriesAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpUsageAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpVehicleAverageAccess;
import capgemini.cnh.mpbusiness.access.oracle.OracleMpVinMissionAccess;
import capgemini.cnh.mpbusiness.domain.ITableAccessFactory;

/**
 * Class to access to HSQLDB database or Oracle database . according the use of
 * the application
 * 
 */
public class OracleTableAccessFactory implements ITableAccessFactory {

	/**
	 * Constructor.
	 */
	public OracleTableAccessFactory() {
		super();
	}

	/**
	 * Gives access to MP usage.
	 * 
	 * @return IMpUsageAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpUsageAccess getMpUsageAccess() throws SystemException {
		return new OracleMpUsageAccess();
	}

	/**
	 * Gives access to MP operation.
	 * 
	 * @return IMpOperationAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationAccess getMpOperationAccess() throws SystemException {
		return new OracleMpOperationAccess();
	}

	/**
	 * Gives access to MP operation consumable.
	 * 
	 * @return IMpOperationConsumableAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationConsumableAccess getMpOperationConsumableAccess() throws SystemException {
		return new OracleMpOperationConsumableAccess();
	}

	/**
	 * Gives access to MP operation part.
	 * 
	 * @return IMpOperationPartAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpOperationPartAccess getMpOperationPartAccess() throws SystemException {
		return new OracleMpOperationPartAccess();
	}

	/**
	 * Gives access to MP interval.
	 * 
	 * @return IMpIntervalAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpIntervalAccess getMpIntervalAccess() throws SystemException {
		return new OracleMpIntervalAccess();
	}

	/**
	 * Gives access to MP plan.
	 * 
	 * @return IMpPlanAccess interface.
	 * @throws SystemException a system exception.
	 */
	public IMpPlanAccess getMpPlanAccess() throws SystemException {
		return new OracleMpPlanAccess();
	}

	@Override
	public IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess() throws SystemException {
		return (new OracleMpHistoryWarrantyAccess());
	}

	@Override
	public IMpHistoryIntervalAccess getMpHistoryIntervalAccess() throws SystemException {
		return (new OracleMpHistoryIntervalAccess());
	}

	@Override
	public IMpHistoryConfigAccess getMpHistoryConfigAccess() throws SystemException {
		return (new OracleMpHistoryConfigAccess());
	}

	@Override
	public IMpPartDescriptionAccess getMpPartDescriptionAccess() throws SystemException {
		return (new OracleMpPartDescriptionAccess());
	}

	@Override
	public IMpContractVehicleAccess getMpContractVehicleAccess() throws SystemException {
		return (new OracleMpContractVehicleAccess());
	}

	@Override
	public IMpContractConfigurationAccess getMpContractConfigurationAccess() throws SystemException {
		return (new OracleMpContractConfigurationAccess());
	}

	@Override
	public IMpKitCompositionAccess getMpKitCompositionAccess() throws SystemException {
		return (new OracleMpKitCompositionAccess());
	}

	@Override
	public IMpStdOilAccess getMpStdOilAccess() throws SystemException {
		return (new OracleMpStdOilAccess());
	}

	@Override
	public IMpVinMissionAccess getMpVinMissionAccess() throws SystemException {
		return (new OracleMpVinMissionAccess());
	}

	@Override
	public IMpDefaultMissionAccess getMpDefaultMissionAccess() throws SystemException {
		return (new OracleMpDefaultMissionAccess());
	}

	@Override
	public IMpNextStopAccess getMpNextFlexStopAccess() throws SystemException {
		return (new OracleMpNextStopAccess());
	}

	@Override
	public IMpFlexStopDoneAccess getMpFlexStopDoneAccess() throws SystemException {
		return (new OracleMpFlexStopDoneAccess());
	}

	@Override
	public IMpFlexCouponAccess getMpFlexCouponAccess() throws SystemException {
		return (new OracleMpFlexCouponAccess());
	}

	@Override
	public IMpNextStopMinAccess getMpNextFlexStopMinAccess() throws SystemException {
		return (new OracleMpNextStopMinAccess());
	}

	@Override
	public IMpFlexContractAccess getMpFlexContractAccess() throws SystemException {
		return (new OracleMpFlexContractAccess());
	}

	@Override
	public IMpNextStopAlertAccess getMpNextFlexStopAlertAccess() throws SystemException {
		return (new OracleMpNextStopAlertAccess());
	}

	@Override
	public IMpClaimAccess getMpClaimAccess() throws SystemException {
		return (new OracleMpClaimAccess());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see capgemini.cnh.mpbusiness.domain.ITableAccessFactory#getMpMaintenance()
	 */

	@Override
	public IMpMaintenanceAccess getMpMaintenanceAccess() throws SystemException {
		return (new OracleMpMaintenanceAccess());
	}

	@Override
	public IMpVehicleAverageAccess getMpVehicleAverageAccess() throws SystemException {
		return (new OracleMpVehicleAverageAccess());
	}

	@Override
	public IMpCustomerAccess getMpCustomerAccess() throws SystemException {
		return (new OracleMpCustomerAccess());
	}

	@Override
	public IMpNextStopAccess getMpNextFlexStopAccess(Access dbAccess) throws SystemException {
		return (new OracleMpNextStopAccess(dbAccess));
	}

	@Override
	public IMpNextStopMinAccess getMpNextFlexStopMinAccess(Access dbAccess) throws SystemException {
		return (new OracleMpNextStopMinAccess(dbAccess));
	}

	@Override
	public IMpClaimAccess getMpClaimAccess(Access dbAccess) throws SystemException {
		return (new OracleMpClaimAccess(dbAccess));
	}

	@Override
	public IMpHistoryIntervalAccess getMpHistoryIntervalAccess(Access dbAccess) throws SystemException {
		return (new OracleMpHistoryIntervalAccess(dbAccess));
	}

	@Override
	public IMpFlexStopDoneAccess getMpFlexStopDoneAccess(Access dbAccess) throws SystemException {
		return (new OracleMpFlexStopDoneAccess(dbAccess));
	}

	@Override
	public IMpHistoryConfigAccess getMpHistoryConfigAccess(Access dbAccess) throws SystemException {
		return (new OracleMpHistoryConfigAccess(dbAccess));
	}

	@Override
	public IMpHistoryWarrantyAccess getMpHistoryWarrantyAccess(Access dbAccess) throws SystemException {
		return (new OracleMpHistoryWarrantyAccess(dbAccess));
	}

	@Override
	public IMpLockAccess getMpLockAccess(Access dbAccess) throws SystemException {
		return (new OracleMpLockAccess(dbAccess));
	}

	@Override
	public IMpPerfFreeTextAccess getMpPerfFreeTextAccess() throws SystemException {
		return new OracleMpPerfFreeTextAccess();
	}

	@Override
	public IMpAlertToleranceAcess getMpAlertToleranceAccess() throws SystemException {
		return new OracleMpAlertToleranceAccess();
	}

	@Override
	public IMpFlexCustomerSapAccess getMpFlexCustomerSapAccess() throws SystemException {
		return new OracleMpFlexCustomerSapAccess();
	}

	@Override
	public IMpProjectDocumentAccess getProjectDocumentAccess() throws SystemException, ApplicativeException {
		return new OracleMpProjectDocumentAccess();
	}

	@Override
	public IMpOperationIuLinkAccess getMpOperationIuLinkAccess() throws SystemException {
		return new OracleMpOperationIuLinkAccess();
	}

	@Override
	public IMpPartSupersessionAccess MpPartSupersessionAccess() throws SystemException {
		return new OracleMpPartSupersessionAccess();
	}

	@Override
	public IMpPartDetailAccess MpPartDetailAccess() throws SystemException {
		return new OracleMpPartDetailAccess();
	}

	@Override
	public IMpUnitSeriesAccess getMpUnitSeriesAccess() throws SystemException {
		return new OracleMpUnitSeriesAccess();
	}

	@Override
	public IMpAppointmentAccess getMpAppointmentAccess() throws SystemException {
		return new OracleMpAppointmentAccess();
	}

	@Override
	public IMpToleranceAcess getMpToleranceAccess() throws SystemException {
		return new OracleMpToleranceAccess();
	}
	
	@Override
	public IMonMaintenancePlanAccess getMonMaintenancePlanAccess() throws SystemException {
		return new OracleMonMaintenancePlanAccess();
	}

	@Override
	public IMpSapSerialNumber17Access getMpSapSerialNumber17Access() throws SystemException {
		return new OracleMpSapSerialNumber17Access();
	}

	@Override
	public IMpSapSerialNumber17Access getMpSapSerialNumber17Access(Access dbAccess) throws SystemException {
		return (new OracleMpSapSerialNumber17Access(dbAccess));
	}
}
