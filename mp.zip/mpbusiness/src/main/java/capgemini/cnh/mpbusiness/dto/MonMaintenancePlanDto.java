package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

public class MonMaintenancePlanDto extends Dto {

	private static final long serialVersionUID = 1L;

	private Long monId;
	private String monVin;
	private Date monDate;
	private Long monUcrExtPlanId;
	private Long monUcrPlanId;
	private Long monEtimExtPlanId;
	private Long monEtimPlanId;

	public MonMaintenancePlanDto() {
		super();
	}

	public MonMaintenancePlanDto(Long monId, String monVin, Date monDate, Long monUcrExtPlanId, Long monUcrPlanId, Long monEtimExtPlanId, Long monEtimPlanId) {
		super();
		this.monId = monId;
		this.monVin = monVin;
		this.monDate = monDate;
		this.monUcrExtPlanId = monUcrExtPlanId;
		this.monUcrPlanId = monUcrPlanId;
		this.monEtimExtPlanId = monEtimExtPlanId;
		this.monEtimPlanId = monEtimPlanId;
	}

	public Long getMonId() {
		return monId;
	}

	public void setMonId(Long monId) {
		this.monId = monId;
	}

	public String getMonVin() {
		return monVin;
	}

	public void setMonVin(String monVin) {
		this.monVin = monVin;
	}

	public Date getMonDate() {
		return monDate;
	}

	public void setMonDate(Date monDate) {
		this.monDate = monDate;
	}

	public Long getMonUcrExtPlanId() {
		return monUcrExtPlanId;
	}

	public void setMonUcrExtPlanId(Long monUcrExtPlanId) {
		this.monUcrExtPlanId = monUcrExtPlanId;
	}

	public Long getMonUcrPlanId() {
		return monUcrPlanId;
	}

	public void setMonUcrPlanId(Long monUcrPlanId) {
		this.monUcrPlanId = monUcrPlanId;
	}

	public Long getMonEtimExtPlanId() {
		return monEtimExtPlanId;
	}

	public void setMonEtimExtPlanId(Long monEtimExtPlanId) {
		this.monEtimExtPlanId = monEtimExtPlanId;
	}

	public Long getMonEtimPlanId() {
		return monEtimPlanId;
	}

	public void setMonEtimPlanId(Long monEtimPlanId) {
		this.monEtimPlanId = monEtimPlanId;
	}

}
