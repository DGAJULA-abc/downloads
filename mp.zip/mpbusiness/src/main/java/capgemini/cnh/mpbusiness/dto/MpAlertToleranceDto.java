package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/* Maintenance Plan */

/**
 * Dto class for Maintenance Plan Flex Contract Info.
 */
public class MpAlertToleranceDto extends Dto {

	/**
	 * Constructor.
	 */
	public MpAlertToleranceDto() {
		super();
	}

	/**
	 * serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Plan Id.
	 */
	private Long planId = null;

	/**
	 * Plan Ext Id.
	 */
	private Long planExtId = null;

	/**
	 * Km tolerance.
	 */
	private Double kmTolerance = null;

	/** Hour Tolerance. **/
	private Double hourTolerance = null;

	/** Month Tolerance. **/
	private Double monthTolerance = null;

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planExtId
	 */
	public Long getPlanExtId() {
		return planExtId;
	}

	/**
	 * @param planExtId the planExtId to set
	 */
	public void setPlanExtId(Long planExtId) {
		this.planExtId = planExtId;
	}

	/**
	 * @return the kmTolerance
	 */
	public Double getKmTolerance() {
		return kmTolerance;
	}

	/**
	 * @param kmTolerance the kmTolerance to set
	 */
	public void setKmTolerance(Double kmTolerance) {
		this.kmTolerance = kmTolerance;
	}

	/**
	 * @return the hourTolerance
	 */
	public Double getHourTolerance() {
		return hourTolerance;
	}

	/**
	 * @param hourTolerance the hourTolerance to set
	 */
	public void setHourTolerance(Double hourTolerance) {
		this.hourTolerance = hourTolerance;
	}

	/**
	 * @return the monthTolerance
	 */
	public Double getMonthTolerance() {
		return monthTolerance;
	}

	/**
	 * @param monthTolerance the monthTolerance to set
	 */
	public void setMonthTolerance(Double monthTolerance) {
		this.monthTolerance = monthTolerance;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		toReturn += getPlanId();
		toReturn += " ";
		toReturn += getPlanExtId();
		toReturn += " ";
		toReturn += getKmTolerance();
		toReturn += " ";
		toReturn += getHourTolerance();
		toReturn += " ";
		toReturn += getMonthTolerance();
		return toReturn;
	}

}
