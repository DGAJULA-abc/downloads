/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

/**
 * @author bgadge
 *
 */
public enum MpAppointmentActionEnum {

	/**
	 * Enum CREATED.
	 */
	CREATED(Integer.valueOf(0), "CREATED"),
	/**
	 * Enum UPDATED.
	 */
	UPDATED(Integer.valueOf(1), "UPDATED"),
	/**
	 * Enum CANCELLED.
	 */
	CANCELLED(Integer.valueOf(2), "CANCELLED"),
	/**
	 * Enum CLOSED.
	 */
	CLOSED(Integer.valueOf(3), "CLOSED");

	/**
	 * value for an enum.
	 */
	private Integer value;
	/**
	 * label for an enum.
	 */
	private String label;

	/**
	 * Constructor.
	 * 
	 * @param num
	 *            value of status
	 * @param newLabel
	 *            label of status
	 */
	private MpAppointmentActionEnum(Integer num, String newLabel) {
		value = num;
		label = newLabel;
	}

	/**
	 * String to display.
	 * 
	 * @return string
	 */
	public String toString() {
		return label;
	}

	/**
	 * getter for value.
	 * 
	 * @return value
	 */
	public Integer getValue() {
		return value;
	}
}
