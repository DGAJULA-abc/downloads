package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author cblois
 * 
 *         Dto class for appointment.
 */
public class MpAppointmentDto extends Dto {

	/**
	 * Constructor.
	 */
	public MpAppointmentDto() {
		super();
	}

	/**
	 * Java internal serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/** APPOINTMENT_ID. **/
	private Long appointmentId = null;

	/** ALERT_GROUP_ID. **/
	private Long alertGroupId = null;

	/** DEALER_CODE. **/
	private String dealerCode = null;

	/** VIN. **/
	private String vin = null;

	/** FREE_NOTE. **/
	private String freeNote = null;

	/** OPEN_DATE. **/
	private Date openDate = null;

	/** OPEN_DATE. **/
	private String openDateString = null;

	/** UPDATE_DATE. **/
	private Date updateDate = null;

	/** UPDATE_DATE. **/
	private String updateDateString = null;

	/** CLOSE_DATE. **/
	private Date closeDate = null;

	/** SYNCHRO_DATE. **/
	private Date synchroDate = null;

	/** CANCEL_DATE. **/
	private Date cancelDate = null;

	/** CANCEL_DATE. **/
	private String cancelDateString = null;

	/** ACTION. **/
	private String action = null;

	/** STATUS. **/
	private String status = null;

	/** RECALL_DATE. **/
	private Date recallDate;

	/** CUSTOMER_NAME. **/
	private String customerName = null;

	/** MILEAGE. **/
	private Long mileage = null;

	/** ENGINE_HOURS. **/
	private Long engineHours = null;

	/** PLATE. **/
	private String plate = null;

	/**
	 * @return the appointmentId
	 */
	public Long getAppointmentId() {
		return appointmentId;
	}

	/**
	 * @param appointmentId the appointmentId to set
	 */
	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}

	/**
	 * @return the alertGroupId
	 */
	public Long getAlertGroupId() {
		return alertGroupId;
	}

	/**
	 * @param alertGroupId the alertGroupId to set
	 */
	public void setAlertGroupId(Long alertGroupId) {
		this.alertGroupId = alertGroupId;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the freeNote
	 */
	public String getFreeNote() {
		return freeNote;
	}

	/**
	 * @param freeNote the freeNote to set
	 */
	public void setFreeNote(String freeNote) {
		this.freeNote = freeNote;
	}

	/**
	 * @return the openDate
	 */
	public Date getOpenDate() {
		return openDate;
	}

	/**
	 * @param openDate the openDate to set
	 */
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	/**
	 * @return the updateDate
	 */
	public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the closeDate
	 */
	public Date getCloseDate() {
		return closeDate;
	}

	/**
	 * @param closeDate the closeDate to set
	 */
	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}

	/**
	 * @return the synchroDate
	 */
	public Date getSynchroDate() {
		return synchroDate;
	}

	/**
	 * @param synchroDate the synchroDate to set
	 */
	public void setSynchroDate(Date synchroDate) {
		this.synchroDate = synchroDate;
	}

	/**
	 * @return the cancelDate
	 */
	public Date getCancelDate() {
		return cancelDate;
	}

	/**
	 * @param cancelDate the cancelDate to set
	 */
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the recallDate
	 */
	public Date getRecallDate() {
		return recallDate;
	}

	/**
	 * @param recallDate the recallDate to set
	 */
	public void setRecallDate(Date recallDate) {
		this.recallDate = recallDate;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the mileage
	 */
	public Long getMileage() {
		return mileage;
	}

	/**
	 * @param mileage the mileage to set
	 */
	public void setMileage(Long mileage) {
		this.mileage = mileage;
	}

	/**
	 * @return the engineHours
	 */
	public Long getEngineHours() {
		return engineHours;
	}

	/**
	 * @param engineHours the engineHours to set
	 */
	public void setEngineHours(Long engineHours) {
		this.engineHours = engineHours;
	}

	/**
	 * @return the plate
	 */
	public String getPlate() {
		return plate;
	}

	/**
	 * @param plate the plate to set
	 */
	public void setPlate(String plate) {
		this.plate = plate;
	}

	/**
	 * @return the openDateString
	 */
	public String getOpenDateString() {
		return openDateString;
	}

	/**
	 * @param openDateString the openDateString to set
	 */
	public void setOpenDateString(String openDateString) {
		this.openDateString = openDateString;
	}

	/**
	 * @return the updateDateString
	 */
	public String getUpdateDateString() {
		return updateDateString;
	}

	/**
	 * @param updateDateString the updateDateString to set
	 */
	public void setUpdateDateString(String updateDateString) {
		this.updateDateString = updateDateString;
	}

	/**
	 * @return the cancelDateString
	 */
	public String getCancelDateString() {
		return cancelDateString;
	}

	/**
	 * @param cancelDateString the cancelDateString to set
	 */
	public void setCancelDateString(String cancelDateString) {
		this.cancelDateString = cancelDateString;
	}

}
