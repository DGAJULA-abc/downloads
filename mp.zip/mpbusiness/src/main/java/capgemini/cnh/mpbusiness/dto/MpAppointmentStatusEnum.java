/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

/**
 * @author bgadge
 *
 */
public enum MpAppointmentStatusEnum {

	/**
	 * Enum CALLED.
	 */
	CALLED(Integer.valueOf(0), "CALLED"),
	/**
	 * Enum NOTCALLED.
	 */
	NOTCALLED(Integer.valueOf(1), "NOTCALLED"),
	/**
	 * Enum RECALL.
	 */
	RECALL(Integer.valueOf(2), "RECALL");

	/**
	 * value for an enum.
	 */
	private Integer value;
	/**
	 * label for an enum.
	 */
	private String label;

	/**
	 * Constructor.
	 * 
	 * @param num
	 *            value of status
	 * @param newLabel
	 *            label of status
	 */
	private MpAppointmentStatusEnum(Integer num, String newLabel) {
		value = num;
		label = newLabel;
	}

	/**
	 * String to display.
	 * 
	 * @return string
	 */
	public String toString() {
		return label;
	}

	/**
	 * getter for value.
	 * 
	 * @return value
	 */
	public Integer getValue() {
		return value;
	}
}
