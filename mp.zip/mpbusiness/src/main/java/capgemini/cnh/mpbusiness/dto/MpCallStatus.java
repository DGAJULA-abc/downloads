package capgemini.cnh.mpbusiness.dto;

/**
 * Type of interval.
 * 
 * @author lestrabo
 *
 */
public enum MpCallStatus {

	/**
	 * Not called .
	 */
	NOT_CALLED(0),
	/**
	 * Called.
	 */
	CALLED(1),

	/**
	 * TO recall.
	 */
	TO_RECALL(2);

	/** Value for an Enum. */
	private Integer value;

	/**
	 * Type of interval.
	 */
	private String _type = null;

	/**
	 * Constructor.
	 * 
	 * @param num value of status
	 * @param newLabel label of status
	 */
	MpCallStatus(Integer num) {
		value = num;

	}

	/**
	 * Getter pour value.
	 *
	 * @return value
	 */
	public Integer getValue() {
		return value;
	}

	@Override
	public String toString() {
		switch (this)
		{
		case NOT_CALLED:
			return "NOT_CALLED";
		case CALLED:
			return "CALLED";
		case TO_RECALL:
			return "TO_RECALL";
		}
		return null;
	}

	public static Integer getValueFromStringIfExist(String mpCallStatus) {
		for (MpCallStatus mpCallstatus : values())
		{
			if (mpCallstatus.toString().equals(mpCallStatus))
			{
				return mpCallstatus.getValue();
			}
		}
		return null;
	}

	public static MpCallStatus getMpCallStatusFromValue(Integer mpCallStatusValue) {
		for (MpCallStatus mpCallstatus : values())
		{
			if (mpCallstatus.getValue().equals(mpCallStatusValue))
			{
				return mpCallstatus;
			}
		}
		return null;
	}

}