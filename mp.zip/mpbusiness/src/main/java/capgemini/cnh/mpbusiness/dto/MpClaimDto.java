package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 * 
 *         Dto class for claims.
 */
public class MpClaimDto extends Dto {

	/**
	 * Constructor.
	 */
	public MpClaimDto() {
		super();
	}

	/**
	 * Java internal serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Unique identifier for the filter. References the master sequence for the.
	 * database table primary keys.
	 */
	private String id = null;

	/**
	 * creation date in the database.
	 */
	private String creationDate = null;

	/**
	 * modification date in the database.
	 */
	private String modifDate = null;

	/**
	 * modification failure date in the database.
	 */
	private String failureDate = null;

	/**
	 * VIN Code.
	 */
	private java.lang.String vinCode = null;

	/**
	 * Raw XML of the filter (publication structure + include/exclude flag).
	 */
	private String filterXML = null;

	/**
	 * Raw SAPXML of the filter (publication structure + include/exclude flag).
	 */
	private String filterSAPXML = null;

	/**
	 * Raw original SAPXML of the filter (publication structure + include/exclude flag).
	 */
	private String filterOriginalSAPXML = null;

	/**
	 * Number of km.
	 */
	private Long km = null;

	/**
	 * Number of hours.
	 */
	private Long hour = null;

	/**
	 * PDF path on Azure.
	 */
	private String pdfPath = null;

	/**
	 * PDF path on Parts.
	 */
	private String pdfParts = null;

	/**
	 * PDF path on Service.
	 */
	private String pdfService = null;

	/**
	 * PDF path on Service.
	 */
	private Integer certifiedParts = null;

	/**
	 * Boolean the vin has an active contract
	 */
	private boolean hasContract = true;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the creationDate
	 */
	public String getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the modifDate
	 */
	public String getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(String modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the vinCode
	 */
	public java.lang.String getVinCode() {
		return vinCode;
	}

	/**
	 * @param vinCode the vinCode to set
	 */
	public void setVinCode(java.lang.String vinCode) {
		this.vinCode = vinCode;
	}

	/**
	 * @return the filterXML
	 */
	public String getFilterXML() {
		return filterXML;
	}

	/**
	 * @param filterXML the filterXML to set
	 */
	public void setFilterXML(String filterXML) {
		this.filterXML = filterXML;
	}

	/**
	 * @return the filterSAPXML
	 */
	public String getFilterSAPXML() {
		return filterSAPXML;
	}

	/**
	 * @param filterSAPXML the filterSAPXML to set
	 */
	public void setFilterSAPXML(String filterSAPXML) {
		this.filterSAPXML = filterSAPXML;
	}

	/**
	 * @return the filterOriginalSAPXML
	 */
	public String getFilterOriginalSAPXML() {
		return filterOriginalSAPXML;
	}

	/**
	 * @param filterOriginalSAPXML the filterOriginalSAPXML to set
	 */
	public void setFilterOriginalSAPXML(String filterOriginalSAPXML) {
		this.filterOriginalSAPXML = filterOriginalSAPXML;
	}

	/**
	 * @return the km
	 */
	public Long getKm() {
		return km;
	}

	/**
	 * @param km the km to set
	 */
	public void setKm(Long km) {
		this.km = km;
	}

	/**
	 * @return the hour
	 */
	public Long getHour() {
		return hour;
	}

	/**
	 * @param hour the hour to set
	 */
	public void setHour(Long hour) {
		this.hour = hour;
	}

	/**
	 * @return the hasContract
	 */
	public boolean hasContract() {
		return hasContract;
	}

	/**
	 * @param hasContract the vin has an active contract
	 */
	public void setHasContract(boolean hasContract) {
		this.hasContract = hasContract;
	}

	public String getPdfPath() {
		return pdfPath;
	}

	public void setPdfPath(String pdfPath) {
		this.pdfPath = pdfPath;
	}

	public String getPdfParts() {
		return pdfParts;
	}

	public void setPdfParts(String pdfParts) {
		this.pdfParts = pdfParts;
	}

	public String getPdfService() {
		return pdfService;
	}

	public void setPdfService(String pdfService) {
		this.pdfService = pdfService;
	}

	/**
	 * Getter pour failureDate.
	 *
	 * @return failureDate
	 */
	public String getFailureDate() {
		return failureDate;
	}

	/**
	 * Setter pour failureDate.
	 *
	 * @param failureDate failureDate à positionner.
	 */
	public void setFailureDate(String failureDate) {
		this.failureDate = failureDate;
	}

	public Integer getCertifiedParts() {
		return certifiedParts;
	}

	public void setCertifiedParts(Integer certifiedParts) {
		this.certifiedParts = certifiedParts;
	}

}
