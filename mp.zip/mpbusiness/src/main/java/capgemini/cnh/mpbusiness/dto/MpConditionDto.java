/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public class MpConditionDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** id. **/
	private Long idCondition = null;

	/** id. **/
	private Long idPlan = null;

	/** id. **/
	private Long idPerformance = null;

	/** oil type. **/
	private MpOilTypeDto oilType = null;

	/** usage. **/
	private MpUsageDto usage = null;

	/**
	 * Constructor.
	 */
	public MpConditionDto() {
		super();
	}

	/**
	 * @return the idCondition
	 */
	public Long getIdCondition() {
		return idCondition;
	}

	/**
	 * @param idCondition the idCondition to set
	 */
	public void setIdCondition(Long idCondition) {
		this.idCondition = idCondition;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the idPerformance
	 */
	public Long getIdPerformance() {
		return idPerformance;
	}

	/**
	 * @param idPerformance the idPerformance to set
	 */
	public void setIdPerformance(Long idPerformance) {
		this.idPerformance = idPerformance;
	}

	/**
	 * @return the oilType
	 */
	public MpOilTypeDto getOilType() {
		return oilType;
	}

	/**
	 * @param oilType the oilType to set
	 */
	public void setOilType(MpOilTypeDto oilType) {
		this.oilType = oilType;
	}

	/**
	 * @return the usage
	 */
	public MpUsageDto getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(MpUsageDto usage) {
		this.usage = usage;
	}

}
