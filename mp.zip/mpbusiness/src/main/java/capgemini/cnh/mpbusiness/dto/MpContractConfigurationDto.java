/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mmartel
 *
 */
public class MpContractConfigurationDto extends Dto {

	/**
	 * Constructor.
	 */
	public MpContractConfigurationDto() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param mpGroupConf : group conf
	 * @param itemId : item id
	 * @param valueId : value id
	 */
	public MpContractConfigurationDto(String mpGroupConf, Long itemId, Long valueId) {
		super();
		this.mpGroupConf = mpGroupConf;
		this.itemId = itemId;
		this.valueId = valueId;

	}

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** mp group configuration. **/
	private String mpGroupConf = null;

	/** item id. **/
	private Long itemId = null;

	/** value id. **/
	private Long valueId = null;

	/**
	 * @return the mpGroupConf
	 */
	public String getMpGroupConf() {
		return mpGroupConf;
	}

	/**
	 * @param mpGroupConf the mpGroupConf to set
	 */
	public void setMpGroupConf(String mpGroupConf) {
		this.mpGroupConf = mpGroupConf;
	}

	/**
	 * @return the itemId
	 */
	public Long getItemId() {
		return itemId;
	}

	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	/**
	 * @return the valueId
	 */
	public Long getValueId() {
		return valueId;
	}

	/**
	 * @param valueId the valueId to set
	 */
	public void setValueId(Long valueId) {
		this.valueId = valueId;
	}

	/**
	 * Return true if this and given object are equals. Equality between two
	 * ApplicabilityDto object means equality of attribute iceCode
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}

		// must return false if the explicit parameter is null
		if (obj == null)
		{
			return false;
		}

		// if the classes don't match, they can't be equal
		if (getClass() != obj.getClass())
		{
			return false;
		}

		// now we know otherObject is a non-null ApplicabilityDto 
		MpContractConfigurationDto other = (MpContractConfigurationDto) obj;

		return getValueId().equals(other.getValueId());
	}

}
