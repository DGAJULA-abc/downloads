package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.util.TIDBLogger;

/* Project CNH/WCM
 * $Header: $
 * Last Change by $Author: $ on $Date: $ */

/**
 * Dto class for Type.
 */
public class MpContractDto extends Dto implements Cloneable {

	/**
	 * Constructor.
	 */
	public MpContractDto() {
		super();
	}

	/**
	 * serial verison id.
	 */
	private static final long serialVersionUID = 1L;

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpContractDto.class);

	/**
	 * active Contract.
	 */
	private String warrantyStartDate = null;

	/**
	 * active Contract.
	 */
	private MpContractVehicleDto activeMpContract = null;

	/**
	 * previous contract.
	 */
	private MpContractVehicleDto previousMpContract = null;

	/**
	 * List of contract.
	 */
	private List<MpContractVehicleDto> contracts;

	/**
	 * List of all available contracts for this vin.
	 */
	private List<MpContractVehicleDto> allContracts;

	/**
	 * history is modified
	 * set to true if the history has been modified (sap claim received/ not received...).
	 */
	private boolean historyModified = false;

	/**
	 * @return the activeMpContract
	 */
	public MpContractVehicleDto getActiveMpContract() {
		return activeMpContract;
	}

	/**
	 * @param activeMpContract the activeMpContract to set
	 */
	public void setActiveMpContract(MpContractVehicleDto activeMpContract) {
		this.activeMpContract = activeMpContract;
	}

	/**
	 * @return the previousMpContract
	 */
	public MpContractVehicleDto getPreviousMpContract() {
		return previousMpContract;
	}

	/**
	 * @param previousMpContract the previousMpContract to set
	 */
	public void setPreviousMpContract(MpContractVehicleDto previousMpContract) {
		this.previousMpContract = previousMpContract;
	}

	/**
	 * @return the contracts
	 */
	public List<MpContractVehicleDto> getContracts() {
		return contracts;
	}

	/**
	 * @param contracts the contracts to set
	 */
	public void setContracts(List<MpContractVehicleDto> contracts) {
		this.contracts = contracts;
	}

	/**
	 * @return the warrantyStartDate
	 */
	public String getWarrantyStartDate() {
		return warrantyStartDate;
	}

	/**
	 * @param warrantyStartDate the warrantyStartDate to set
	 */
	public void setWarrantyStartDate(String warrantyStartDate) {
		this.warrantyStartDate = warrantyStartDate;
	}

	public boolean isHistoryModified() {
		return historyModified;
	}

	/**
	 * @param isHistoryModified the isHistoryModified to set
	 */
	public void setHistoryModified(boolean isHistoryModified) {
		this.historyModified = isHistoryModified;
	}

	/**
	 * Clone object.
	 * 
	 * @return clone
	 */
	@Override
	public Object clone() {
		MpContractDto o = null;
		try
		{
			o = (MpContractDto) super.clone();
			if (o.getActiveMpContract() != null)
			{
				o.setActiveMpContract((MpContractVehicleDto) o.getActiveMpContract().clone());
			}
			if (o.getPreviousMpContract() != null)
			{
				o.setPreviousMpContract((MpContractVehicleDto) o.getPreviousMpContract().clone());
			}
			if (o.getContracts() != null)
			{
				List<MpContractVehicleDto> contracts = new ArrayList<>();
				for (MpContractVehicleDto dto : (ArrayList<MpContractVehicleDto>) o.getContracts())
				{
					contracts.add((MpContractVehicleDto) dto.clone());
				}
				o.setContracts(contracts);
			}
		}
		catch (CloneNotSupportedException cnse)
		{
			//cnse.printStackTrace(System.err);
			logger.error("Clone Error");
		}

		return o;
	}

	public List<MpContractVehicleDto> getAllContracts() {
		return allContracts;
	}

	public void setAllContracts(List<MpContractVehicleDto> allContracts) {
		this.allContracts = allContracts;
	}

}
