/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * 
 * @author jdespeau
 *
 */
public class MpContractTypeMessageDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	private int contractTypeMessageKey;

	private String contractType = "";

	private String contractNumber = "";

	private String contractStartDate = "";

	private String contractEndDate = "";

	/**
	 * @return the contractTypeMessageKey
	 */
	public int getContractTypeMessageKey() {
		return contractTypeMessageKey;
	}

	/**
	 * @param contractTypeMessageKey the contractTypeMessageKey to set
	 */
	public void setContractTypeMessageKey(int contractTypeMessageKey) {
		this.contractTypeMessageKey = contractTypeMessageKey;
	}

	/**
	 * @return the contractNumber
	 */
	public String getContractNumber() {
		return contractNumber;
	}

	/**
	 * @param contractNumber the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	/**
	 * @return the contractStartDate
	 */
	public String getContractStartDate() {
		return contractStartDate;
	}

	/**
	 * @param contractStartDate the contractStartDate to set
	 */
	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	/**
	 * @return the contractEndDate
	 */
	public String getContractEndDate() {
		return contractEndDate;
	}

	/**
	 * @param contractEndDate the contractEndDate to set
	 */
	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	/**
	 * @return the contractType
	 */
	public String getContractType() {
		return contractType;
	}

	/**
	 * @param contractType the contractType to set
	 */
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

}
