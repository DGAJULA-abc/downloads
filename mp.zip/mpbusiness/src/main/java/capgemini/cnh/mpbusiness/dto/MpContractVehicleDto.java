/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.IceContextDto;

/**
 * @author mmartel
 *
 */
public class MpContractVehicleDto extends Dto implements Cloneable {

	/**
	 * Constructor.
	 */
	public MpContractVehicleDto() {
		super();
	}

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(IceContextDto.class);

	/**
	 * Constructor.
	 * 
	 * @param toCopy param to Copy
	 */
	public MpContractVehicleDto(MpContractVehicleDto toCopy) {
		this.setSapVin(toCopy.getSapVin());
		this.setPlanId(toCopy.getPlanId());
		this.setWarrantyStartDate(toCopy.getWarrantyStartDate());
		this.setPlanExtId(toCopy.getPlanExtId());
		this.setMpVersion(toCopy.getMpVersion());
		this.setContractStartDate(toCopy.getContractStartDate());
		this.setContractEndDate(toCopy.getContractEndDate());
		this.setMpGroupConf(toCopy.getMpGroupConf());
		this.setEngOilId(toCopy.getEngOilId());
		this.setGbOilId(toCopy.getGbOilId());
		this.setAxleOilId(toCopy.getAxleOilId());
		this.setContractNumber(toCopy.getContractNumber());
		this.setBrandIceCode(toCopy.getBrandIceCode());
		this.setTypeContract(toCopy.getTypeContract());
		this.setConnectedType(toCopy.getConnectedType());
		this.setCustomerData(toCopy.getCustomerData());
		this.setNumberOfStops(toCopy.getNumberOfStops());
		this.setTotalTravelAmount(toCopy.getTotalTravelAmount());
		this.setTotalTravelStopAmount(toCopy.getTotalTravelStopAmount());
	}

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** sap VIN. **/
	private String sapVin = null;

	/** plan Id. **/
	private Long planId = null;

	/** Warranty start date. **/
	private String warrantyStartDate = null;

	/** plan external id. **/
	private Long planExtId = null;

	/** version. **/
	private Integer mpVersion = null;

	/** contract start date. **/
	private Date contractStartDate = null;

	/** contract end date. **/
	private Date contractEndDate = null;

	/** mp group configuration. **/
	private String mpGroupConf = null;

	/** engine oil id. **/
	private Long engOilId = null;

	/** gear box oil id. **/
	private Long gbOilId = null;

	/** axle oil id. **/
	private Long axleOilId = null;

	/** typeContract : 01 classical, 03 heavy. **/
	private String typeContract;

	/** contractNumber. **/
	private String contractNumber;

	/** dealer code . */
	private String dealerCode = null;

	/** customer code . */
	private String customerCode = null;

	/** Brand ice code . */
	private String brandIceCode = null;

	/** The connected type, flexible or targa. */
	private String connectedType = null;

	/** The Mission Code . */
	private String missionCode = null;

	/** The Mission Description . */
	private String missionDescription = null;

	/** Is Construction . */
	private String isDeleted = null;

	/** The SAP System . */
	private String sapSystem = null;

	/** The Error type if the plan is not applicable. */
	private String errorType = null;

	private MpCustomerDto customerData = null;

	private Long amountOfUse = null;

	private Long duration = null;

	private Long numberOfStops = null;

	private Long numberOfConsumedStops = null;

	private Long numberOfTotalStops = null;

	private Double totalTravelAmount = null;

	private Double totalTravelStopAmount = null;

	/**
	 * @return the sapVin
	 */
	public String getSapVin() {
		return sapVin;
	}

	/**
	 * @param sapVin the sapVin to set
	 */
	public void setSapVin(String sapVin) {
		this.sapVin = sapVin;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the planExtId
	 */
	public Long getPlanExtId() {
		return planExtId;
	}

	/**
	 * @param planExtId the planExtId to set
	 */
	public void setPlanExtId(Long planExtId) {
		this.planExtId = planExtId;
	}

	/**
	 * @return the mpVersion
	 */
	public Integer getMpVersion() {
		return mpVersion;
	}

	/**
	 * @param mpVersion the mpVersion to set
	 */
	public void setMpVersion(Integer mpVersion) {
		this.mpVersion = mpVersion;
	}

	/**
	 * @return the contractStartDate
	 */
	public Date getContractStartDate() {
		return contractStartDate;
	}

	/**
	 * @param contractStartDate the contractStartDate to set
	 */
	public void setContractStartDate(Date contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	/**
	 * @return the contractEndtDate
	 */
	public Date getContractEndDate() {
		return contractEndDate;
	}

	/**
	 * @param contractEndtDate the contractEndtDate to set
	 */
	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	/**
	 * @return the mpGroupConf
	 */
	public String getMpGroupConf() {
		return mpGroupConf;
	}

	/**
	 * @param mpGroupConf the mpGroupConf to set
	 */
	public void setMpGroupConf(String mpGroupConf) {
		this.mpGroupConf = mpGroupConf;
	}

	/**
	 * @return the engOilId
	 */
	public Long getEngOilId() {
		return engOilId;
	}

	/**
	 * @param engOilId the engOilId to set
	 */
	public void setEngOilId(Long engOilId) {
		this.engOilId = engOilId;
	}

	/**
	 * @return the gbOilId
	 */
	public Long getGbOilId() {
		return gbOilId;
	}

	/**
	 * @param gbOilId the gbOilId to set
	 */
	public void setGbOilId(Long gbOilId) {
		this.gbOilId = gbOilId;
	}

	/**
	 * @return the axleOilId
	 */
	public Long getAxleOilId() {
		return axleOilId;
	}

	/**
	 * @param axleOilId the axleOilId to set
	 */
	public void setAxleOilId(Long axleOilId) {
		this.axleOilId = axleOilId;
	}

	/**
	 * @return the warrantyStartDate
	 */
	public String getWarrantyStartDate() {
		return warrantyStartDate;
	}

	/**
	 * @param warrantyStartDate the warrantyStartDate to set
	 */
	public void setWarrantyStartDate(String warrantyStartDate) {
		this.warrantyStartDate = warrantyStartDate;
	}

	/**
	 * @return the typeContract
	 */
	public String getTypeContract() {
		return typeContract;
	}

	/**
	 * @param typeContract the typeContract to set
	 */
	public void setTypeContract(String typeContract) {
		this.typeContract = typeContract;
	}

	/**
	 * @return the contractNumber
	 */
	public String getContractNumber() {
		return contractNumber;
	}

	/**
	 * @param contractNumber the contractNumber to set
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the brandIceCode
	 */
	public String getBrandIceCode() {
		return brandIceCode;
	}

	/**
	 * @param brandIceCode the brandIceCode to set
	 */
	public void setBrandIceCode(String brandIceCode) {
		this.brandIceCode = brandIceCode;
	}

	/**
	 * @return the connectedType
	 */
	public String getConnectedType() {
		return connectedType;
	}

	/**
	 * @param connectedType the connectedType to set
	 */
	public void setConnectedType(String connectedType) {
		this.connectedType = connectedType;
	}

	/**
	 * @return the missionCode
	 */
	public String getMissionCode() {
		return missionCode;
	}

	/**
	 * @param missionCode the missionCode to set
	 */
	public void setMissionCode(String missionCode) {
		this.missionCode = missionCode;
	}

	/**
	 * @return the missionDescription
	 */
	public String getMissionDescription() {
		return missionDescription;
	}

	/**
	 * @param missionDescription the missionDescription to set
	 */
	public void setMissionDescription(String missionDescription) {
		this.missionDescription = missionDescription;
	}

	/**
	 * @return the isDeleted
	 */
	public String getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the sapSystem
	 */
	public String getSapSystem() {
		return sapSystem;
	}

	/**
	 * @param sapSystem the sapSystem to set
	 */
	public void setSapSystem(String sapSystem) {
		this.sapSystem = sapSystem;
	}

	/**
	 * 
	 * @return errorType
	 */
	public String getErrorType() {
		return errorType;
	}

	/**
	 * 
	 * @param errorType errorType
	 */
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public MpCustomerDto getCustomerData() {
		return customerData;
	}

	public void setCustomerData(MpCustomerDto customerData) {
		this.customerData = customerData;
	}

	public Long getAmountOfUse() {
		return amountOfUse;
	}

	public void setAmountOfUse(Long amountOfUse) {
		this.amountOfUse = amountOfUse;
	}

	public Long getDuration() {
		return duration;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public Long getNumberOfStops() {
		return numberOfStops;
	}

	public void setNumberOfStops(Long numberOfStops) {
		this.numberOfStops = numberOfStops;
	}

	/**
	 * Clone object.
	 * 
	 * @return clone
	 */
	@Override
	public Object clone() {
		Object o = null;
		try
		{
			o = super.clone();
		}
		catch (CloneNotSupportedException cnse)
		{
			logger.error("Clone Error");
		}

		return o;
	}

	public Long getNumberOfConsumedStops() {
		return numberOfConsumedStops;
	}

	public void setNumberOfConsumedStops(Long numberOfConsumedStops) {
		this.numberOfConsumedStops = numberOfConsumedStops;
	}

	public Long getNumberOfTotalStops() {
		return numberOfTotalStops;
	}

	public void setNumberOfTotalStops(Long numberOfTotalStops) {
		this.numberOfTotalStops = numberOfTotalStops;
	}

	/**
	 * @return the totalTravelAmount
	 */
	public Double getTotalTravelAmount() {
		return totalTravelAmount;
	}

	/**
	 * @param totalTravelAmount the totalTravelAmount to set
	 */
	public void setTotalTravelAmount(Double totalTravelAmount) {
		this.totalTravelAmount = totalTravelAmount;
	}

	/**
	 * @return the totalTravelStopAmount
	 */
	public Double getTotalTravelStopAmount() {
		return totalTravelStopAmount;
	}

	/**
	 * @param totalTravelStopAmount the totalTravelStopAmount to set
	 */
	public void setTotalTravelStopAmount(Double totalTravelStopAmount) {
		this.totalTravelStopAmount = totalTravelStopAmount;
	}

}
