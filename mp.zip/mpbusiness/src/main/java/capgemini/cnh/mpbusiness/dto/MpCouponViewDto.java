/**
 *
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.Comparator;

import capgemini.cnh.mpbusiness.dto.MpNextStopDto.NextMaintenance;

/**
 *
 * @author thlarzab
 */
public class MpCouponViewDto {

	private String couponTitle;

	private NextMaintenance status;

	private Long value;

	private String couponDescription;

	private boolean isHidden = false;

	public MpCouponViewDto(String couponTitle, NextMaintenance status, Long value, String couponDescription, boolean isHidden) {
		this.couponTitle = couponTitle;
		this.status = status;
		this.value = value;
		this.couponDescription = couponDescription;
		this.isHidden = isHidden;
	}

	/**
	 * Getter pour couponTitle.
	 *
	 * @return couponTitle
	 */
	public String getCouponTitle() {
		return couponTitle;
	}

	/**
	 * Setter pour couponTitle.
	 *
	 * @param couponTitle
	 */
	public void setCouponTitle(String couponTitle) {
		this.couponTitle = couponTitle;
	}

	/**
	 * Getter pour status.
	 *
	 * @return status
	 */
	public NextMaintenance getStatus() {
		return status;
	}

	/**
	 * Setter pour status.
	 *
	 * @param status
	 */
	public void setStatus(NextMaintenance status) {
		this.status = status;
	}

	public Long getValue() {
		return value;
	}

	public void setValue(Long value) {
		this.value = value;
	}

	public String getCouponDescription() {
		return couponDescription;
	}

	public void setCouponDescription(String couponDescription) {
		this.couponDescription = couponDescription;
	}

	public boolean isHidden() {
		return isHidden;
	}

	public void setHidden(boolean hidden) {
		isHidden = hidden;
	}
}

class SortMpCouponViewDto implements Comparator<MpCouponViewDto> {

	// Used for sorting in ascending order of
	public int compare(MpCouponViewDto a, MpCouponViewDto b) {
		return a.getCouponTitle().compareTo(b.getCouponTitle());
	}
}