/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.framework.util.TIDBLogger;

/**
 *
 * @author lestrabo
 */
public class MpCustomerDto extends Dto {

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpCustomerDto.class);

	/**  */
	private static final long serialVersionUID = 1L;

	private String name1;
	private String name2;
	private String fullName;

	private String customerCode;

	private String customerPhone;
	private String customerMail;

	private String secondPhone;
	private String secondMail;

	private String street;
	private String city;
	private String country;
	private String zipCode;

	private String appSchedule;
	private String notes;

	private MpCallStatus mpCallStatus;

	public MpCustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param name1
	 * @param name2
	 * @param customerCode
	 */
	public MpCustomerDto(String name1, String name2, String customerCode) {
		super();
		this.name1 = name1;
		this.name2 = name2;
		this.customerCode = customerCode;
		this.fullName = buildFullName();
	}

	/**
	 * @param fullName
	 * @param customerCode
	 */
	public MpCustomerDto(String fullName, String customerCode) {
		super();
		this.fullName = fullName;
		this.customerCode = customerCode;
	}

	/**
	 * @param name1
	 * @param name2
	 * @param customerPhone
	 * @param customerMail
	 */
	public MpCustomerDto(String name1, String name2, String customerPhone, String customerMail) {
		super();
		this.name1 = name1;
		this.name2 = name2;
		this.customerPhone = customerPhone;
		this.customerMail = customerMail;
		this.fullName = buildFullName();
	}

	/**
	 * @param name1
	 * @param name2
	 * @param customerPhone
	 * @param customerMail
	 */

	public MpCustomerDto(String name1, String name2, String customerCode, String customerPhone, String customerMail,
			String secondPhone, String secondMail, String street, String city,
			String country, String zipCode, String appSchedule, String notes) {
		super();
		this.name1 = name1;
		this.name2 = name2;
		this.fullName = buildFullName();
		this.customerCode = customerCode;
		this.customerPhone = customerPhone;
		this.customerMail = customerMail;
		this.secondPhone = secondPhone;
		this.secondMail = secondMail;
		this.street = street;
		this.city = city;
		this.country = country;
		this.zipCode = zipCode;
		this.appSchedule = appSchedule;
		this.notes = notes;
	}

	/**
	 * 
	 */
	private String buildFullName() {
		String fullName = "";
		if (this.name1 != null && !this.name1.isEmpty())
		{
			fullName = this.name1;
		}

		if (this.name2 != null && !this.name2.isEmpty())
		{
			if (fullName.equals(""))
			{
				return this.name2;
			}
			fullName += " " + this.name2;
		}
		return fullName;
	}

	/**
	 * Getter pour name1.
	 *
	 * @return name1
	 */
	public String getName1() {
		return name1;
	}

	/**
	 * Setter pour name1.
	 *
	 * @param name1 name1 à positionner.
	 */
	public void setName1(String name1) {
		this.name1 = name1;
		this.fullName = buildFullName();
	}

	/**
	 * Getter pour name2.
	 *
	 * @return name2
	 */
	public String getName2() {
		return name2;
	}

	/**
	 * Setter pour name2.
	 *
	 * @param name2 name2 à positionner.
	 */
	public void setName2(String name2) {
		this.name2 = name2;
		this.fullName = buildFullName();
	}

	/**
	 * Getter pour customerCode.
	 *
	 * @return customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * Setter pour customerCode.
	 *
	 * @param customerCode customerCode à positionner.
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * Getter pour customerPhone.
	 *
	 * @return customerPhone
	 */
	public String getCustomerPhone() {
		return customerPhone;
	}

	/**
	 * Setter pour customerPhone.
	 *
	 * @param customerPhone customerPhone à positionner.
	 */
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	/**
	 * Getter pour customerMail.
	 *
	 * @return customerMail
	 */
	public String getCustomerMail() {
		return customerMail;
	}

	/**
	 * Setter pour customerMail.
	 *
	 * @param customerMail customerMail à positionner.
	 */
	public void setCustomerMail(String customerMail) {
		this.customerMail = customerMail;
	}

	/**
	 * Getter pour fullName.
	 *
	 * @return fullName
	 */
	public String getFullName() {
		return fullName;
	}

	@Override
	public String toString() {
		return "Customer [fullName=" + fullName + ", customerCode=" + customerCode + ", customerPhone=" + customerPhone
				+ ", customerMail=" + customerMail + "]";
	}

	/**
	 * Getter pour mpCallState.
	 *
	 * @return mpCallState
	 */
	public MpCallStatus getMpCallStatus() {
		return mpCallStatus;
	}

	/**
	 * Setter pour mpCallState.
	 *
	 * @param mpCallState mpCallState à positionner.
	 */
	public void setMpCallStatus(MpCallStatus mpCallStatus) {
		this.mpCallStatus = mpCallStatus;
	}

	public String getSecondPhone() {
		return secondPhone;
	}

	public void setSecondPhone(String secondPhone) {
		this.secondPhone = secondPhone;
	}

	public String getSecondMail() {
		return secondMail;
	}

	public void setSecondMail(String secondMail) {
		this.secondMail = secondMail;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getAppSchedule() {
		return appSchedule;
	}

	public void setAppSchedule(String appSchedule) {
		this.appSchedule = appSchedule;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 * Check if the object contains data
	 * 
	 * @return true if there no data, false either
	 */
	public boolean ifNullObject() {
		return (this.fullName == null || this.fullName.equals("")) &&
				this.customerCode == null &&
				this.customerPhone == null &&
				this.customerMail == null &&
				this.secondPhone == null &&
				this.secondMail == null &&
				this.street == null &&
				this.city == null &&
				this.country == null &&
				this.zipCode == null &&
				this.appSchedule == null &&
				this.notes == null;
	}

	/**
	 * Clone object.
	 * 
	 * @return clone
	 */
	@Override
	public Object clone() {
		Object o = null;
		try
		{
			o = super.clone();
		}
		catch (CloneNotSupportedException cnse)
		{
			//cnse.printStackTrace(System.err);
			logger.error("Clone Error");
		}

		return o;
	}

}
