/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public final class MpDefaultMissionDto extends Dto {

	/**
	 * Generated serial identifier.
	 */
	private static final long serialVersionUID = 6748698991908562431L;

	/** series Ice Code. **/
	private String seriesIceCode = null;
	/** model Ice Code. **/
	private String modelIceCode = null;
	/** tt Ice Code. **/
	private String ttIceCode = null;
	/** Mission Id. **/
	private Long valueMissionId = null;

	/**
	 * Locked Constructor.
	 */
	public MpDefaultMissionDto() {
		super();
	}

	/**
	 * @return the seriesIceCode
	 */

	public String getSeriesIceCode() {
		return seriesIceCode;
	}

	/**
	 * @param seriesIceCode : the series Ice Code to set
	 */
	public void setSeriesIceCode(String seriesIceCode) {
		this.seriesIceCode = seriesIceCode;
	}

	/**
	 * @return the modelIceCode
	 */

	public String getModelIceCode() {
		return modelIceCode;
	}

	/**
	 * @param modelIceCode : the model Ice Code to set
	 */
	public void setModelIceCode(String modelIceCode) {
		this.modelIceCode = modelIceCode;
	}

	/**
	 * @return the ttIceCode
	 */

	public String getTtIceCode() {
		return ttIceCode;
	}

	/**
	 * @param ttIceCode : the tt Ice Code to set
	 */
	public void setTtIceCode(String ttIceCode) {
		this.ttIceCode = ttIceCode;
	}

	/**
	 * @return the valueMissionId
	 */
	public Long getValueMissionId() {
		return valueMissionId;
	}

	/**
	 * @param valueMissionId : the mission Id to set
	 */
	public void setValueMissionId(Long valueMissionId) {
		this.valueMissionId = valueMissionId;
	}

	/**
	 * @return the descLanguage
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
