package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for: history of performed maintenances on a V.I.N.
 * 
 * @author mmartel
 */
public class MpFlexCouponDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Name of the maintenance plan interval (not saved in database).
	 */
	private String intervalCode;

	/**
	 * default constructor.
	 * 
	 * 
	 */
	public MpFlexCouponDto() {
		super();

	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Interval Code(" + (this.intervalCode == null ? "" : this.intervalCode) + ")");
		return builder.toString();
	}
}
