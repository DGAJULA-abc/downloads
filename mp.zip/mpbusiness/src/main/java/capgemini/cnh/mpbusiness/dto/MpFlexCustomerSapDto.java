/**
 * 1:20:12 PM
 * MpFlexCustomerSap.java
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mshaikh4
 *
 */
public class MpFlexCustomerSapDto extends Dto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 782626614313652432L;

	/**
	 * 
	 */
	private String customerCode;

	/**
	 * 
	 */
	private String customeName1;

	/**
	 * 
	 */
	private String customerName2;

	/**
	 * 
	 */
	private String eMail;

	/**
	 * 
	 */
	private String phoneNumber;

	/**
	 * 
	 */
	private String customerCountry;

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the customeName1
	 */
	public String getCustomeName1() {
		return customeName1;
	}

	/**
	 * @param customeName1 the customeName1 to set
	 */
	public void setCustomeName1(String customeName1) {
		this.customeName1 = customeName1;
	}

	/**
	 * @return the customerName2
	 */
	public String getCustomerName2() {
		return customerName2;
	}

	/**
	 * @param customerName2 the customerName2 to set
	 */
	public void setCustomerName2(String customerName2) {
		this.customerName2 = customerName2;
	}

	/**
	 * @return the eMail
	 */
	public String geteMail() {
		return eMail;
	}

	/**
	 * @param eMail the eMail to set
	 */
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the customerCountry
	 */
	public String getCustomerCountry() {
		return customerCountry;
	}

	/**
	 * @param customerCountry the customerCountry to set
	 */
	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

}
