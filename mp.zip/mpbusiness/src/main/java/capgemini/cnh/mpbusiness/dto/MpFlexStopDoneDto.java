package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for: history of performed maintenances on a V.I.N.
 * 
 * @author dbabillo
 */
public class MpFlexStopDoneDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * V.I.N. of the vehicle.
	 */
	private String vin;

	/**
	 * Name of the maintenance plan interval (not saved in database).
	 */
	private String intervalCode;

	/**
	 * date done.
	 */
	private Date dateDone;

	/**
	 * km done done.
	 */
	private Long kmDone;

	/**
	 * default constructor.
	 * 
	 * 
	 */
	public MpFlexStopDoneDto() {
		super();

	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the dateDone
	 */
	public Date getDateDone() {
		return dateDone;
	}

	/**
	 * @param dateDone the dateDone to set
	 */
	public void setDateDone(Date dateDone) {
		this.dateDone = dateDone;
	}

	/**
	 * @return the kmDone
	 */
	public Long getKmDone() {
		return kmDone;
	}

	/**
	 * @param kmDone the kmDone to set
	 */
	public void setKmDone(Long kmDone) {
		this.kmDone = kmDone;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Date done(" + (this.dateDone == null ? "" : this.dateDone) + ")");
		builder.append(" ");
		builder.append("V.I.N.(" + this.vin + ")");
		builder.append(" ");
		builder.append("Interval Code(" + (this.intervalCode == null ? "" : this.intervalCode) + ")");
		builder.append(" ");
		builder.append("Km done(" + (this.kmDone == null ? "" : this.kmDone) + ")");
		return builder.toString();
	}
}
