package capgemini.cnh.mpbusiness.dto;

import java.util.List;

import capgemini.cnh.ice.dto.ConfigurationDto;

/**
 * Dto class for config recorded when using interactive maintenance plan with a V.I.N.
 * 
 * @author dbabillo
 */
public class MpHistoryConfigDto extends ConfigurationDto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * V.I.N. of the vehicle.
	 */
	private String vin;

	/**
	 * lstPinVin of the vehicle.
	 */
	private List<String> lstPinVin;

	/**
	 * Config value (e.g. motor 1, cab 2) identifier.
	 */
	//private Long idValueConfig;

	/**
	 * Config item (group e.g. EN - Engine) identifier.
	 */
	//private Integer idItemConfig;

	/**
	 * Default constructor.
	 */

	public MpHistoryConfigDto() {
		super();
		this.vin = null;
	}

	/**
	 * Constructor from configuration DTO.
	 * 
	 * @param pVin the V.I.N.
	 * @param pConfigurationDto the config
	 */
	public MpHistoryConfigDto(String pVin, ConfigurationDto pConfigurationDto) {
		super(pConfigurationDto);
		this.vin = pVin;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	public List<String> getLstPinVin() {
		return lstPinVin;
	}

	public void setLstPinVin(List<String> lstPinVin) {
		this.lstPinVin = lstPinVin;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("vin(");
		builder.append(this.vin != null ? this.vin.toString() : "null");
		builder.append(") ");
		builder.append(super.toString());
		return builder.toString();
	}
}
