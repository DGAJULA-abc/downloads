package capgemini.cnh.mpbusiness.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.mpbusiness.util.MpIntervalHistoryEnum;

/**
 * Dto class for: history of performed maintenances on a V.I.N.
 * 
 * @author dbabillo
 */
public class MpHistoryIntervalDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Ref to the claim.
	 */
	private String idClaim = null;

	/**
	 * Id of the history.
	 */
	private String id;

	/**
	 * V.I.N. of the vehicle.
	 */
	private String vin;

	/**
	 * lstPinVin of the vehicle.
	 */
	private List<String> lstPinVin;

	/**
	 * Identifier of the maintenance plan interval.
	 */
	private Long intervalId;

	/**
	 * Name of the maintenance plan interval (not saved in database).
	 */
	private String intervalCode;

	/**
	 * Plan external id.
	 */
	private Long planExternalId;

	/**
	 * Date of the last UPDATE performed on the entry (automatically triggered).
	 */
	private String updateDate;

	/**
	 * Failure date.
	 */
	private Long failureDate;

	/**
	 * Value at which the maintenance was last performed.
	 */
	private Map<MpType, Long> exactValue;

	/**
	 * Interval value at which the maintenance was last performed.
	 * E.g. M1 every 100 000 KM exact value is 210 000, interval value is 200 000.
	 */
	private Map<MpType, Long> intervalValue;

	/**
	 * is sap origin.
	 */
	private Integer isSapOrigin;

	/**
	 * can be modified.
	 */
	private boolean canBeModified = true;

	/**
	 * can be saved.
	 */
	private boolean canBeSaved = true;

	/**
	 * can be saved.
	 */
	private Long idPlan;

	/**
	 * The question is checked or not. Checked: not send to UCR. Unchecked: sned to UCR.
	 */
	private boolean isChecked = false;

	/**
	 * Id of the history.
	 */
	private String strongId = null;

	/**
	 * Is deleted.
	 */
	private Integer isDeleted;

	/**
	 * The contract type. Used for exporting maintenance history.
	 */
	private String contractType = "";

	/**
	 * Operator Type CUSTOMER/DEALER.
	 */
	private int operatorType = MpIntervalHistoryEnum.DEALER.getValue();

	/**
	 * operationJsonUCR.
	 */
	private String operationJsonForUcr = "";

	/**
	 * operationJsonUCR.
	 */
	private String saveComments = "";

	/**
	 * Locked constructor.
	 */
	@SuppressWarnings("unused")
	private MpHistoryIntervalDto() {
		this.intervalId = null;
		this.id = null;
		this.intervalCode = null;
		this.strongId = UUID.randomUUID().toString();
	}

	/**
	 * Default constructor (with Strong ID set to null for SAP).
	 * TODO : When StrongId will be added in Claims, delete this constructor and insert StrongId return by SAP using following constructor
	 * public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, Long planId, Integer isSapOrigin, String strongId)
	 * 
	 * @param id history interval identifier in the database
	 * @param intervalId interval identifier
	 * @param vin the vin to set
	 * @param code the interval code to set
	 * @param planId the plan exact plan id
	 * @param planExtId the plan external id
	 * @param isSapOrigin is sap history
	 * 
	 */
	public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, Long planId, Integer isSapOrigin) {

		// TODO : When StrongId will be added in Claims, delete this constructor and insert StrongId return by SAP using following constructor
		// public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, Long planId, Integer isSapOrigin, String strongId)
		super();
		this.exactValue = new HashMap<MpType, Long>();
		this.intervalValue = new HashMap<MpType, Long>();

		if (id != null && id.equals(""))
		{
			this.id = null;
		}
		else
		{
			this.id = id;
		}
		this.intervalId = intervalId;
		this.vin = vin;
		this.intervalCode = code;
		this.planExternalId = planExtId;
		this.idPlan = planId;
		this.isSapOrigin = isSapOrigin;

	}

	/**
	 * Default constructor.
	 * 
	 * @param id history interval identifier in the database
	 * @param intervalId interval identifier
	 * @param vin the vin to set
	 * @param code the interval code to set
	 * @param planId the plan exact plan id
	 * @param planExtId the plan external id
	 * @param isSapOrigin is sap history
	 * 
	 */
	public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, Long planId, Integer isSapOrigin, String strongId) {
		super();
		this.exactValue = new HashMap<MpType, Long>();
		this.intervalValue = new HashMap<MpType, Long>();

		if (id != null && id.equals(""))
		{
			this.id = null;
		}
		else
		{
			this.id = id;
		}
		if (strongId != null)
		{
			this.strongId = strongId;
		}
		else
		{
			this.strongId = UUID.randomUUID().toString();

		}
		this.intervalId = intervalId;
		this.vin = vin;
		this.intervalCode = code;
		this.planExternalId = planExtId;
		this.idPlan = planId;
		this.isSapOrigin = isSapOrigin;

	}

	/**
	 * Default constructor.
	 * 
	 * @param id history interval identifier in the database
	 * @param intervalId interval identifier
	 * @param lstPinVin the vin 9 an 17
	 * @param code the interval code to set
	 * @param planExtId the plan external id
	 * 
	 */
	public MpHistoryIntervalDto(String id, Long intervalId, List<String> lstPinVin, String code, Long planExtId, String strongId) {
		super();
		this.exactValue = new HashMap<MpType, Long>();
		this.intervalValue = new HashMap<MpType, Long>();

		if (id != null && id.equals(""))
		{
			this.id = null;
		}
		else
		{
			this.id = id;
		}
		if (strongId != null)
		{
			this.strongId = strongId;
		}
		else
		{
			this.strongId = UUID.randomUUID().toString();

		}
		this.intervalId = intervalId;
		this.lstPinVin = lstPinVin;
		this.intervalCode = code;
		this.planExternalId = planExtId;
		this.isSapOrigin = MpHistoryOrigin.TIDB.getValue();
	}

	public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, String strongId) {
		super();
		this.exactValue = new HashMap<MpType, Long>();
		this.intervalValue = new HashMap<MpType, Long>();

		if (id != null && id.equals(""))
		{
			this.id = null;
		}
		else
		{
			this.id = id;
		}
		if (strongId != null)
		{
			this.strongId = strongId;
		}
		else
		{
			this.strongId = UUID.randomUUID().toString();

		}
		this.intervalId = intervalId;
		this.vin = vin;
		this.intervalCode = code;
		this.planExternalId = planExtId;
		this.isSapOrigin = MpHistoryOrigin.TIDB.getValue();
	}

	public MpHistoryIntervalDto(String id, Long intervalId, String vin, String code, Long planExtId, String strongId, boolean withoutInitilizeStrongId) {
		super();
		this.exactValue = new HashMap<MpType, Long>();
		this.intervalValue = new HashMap<MpType, Long>();

		if (id != null && id.equals(""))
		{
			this.id = null;
		}
		else
		{
			this.id = id;
		}

		this.strongId = strongId;
		this.intervalId = intervalId;
		this.vin = vin;
		this.intervalCode = code;
		this.planExternalId = planExtId;
		this.isSapOrigin = MpHistoryOrigin.TIDB.getValue();
	}

	/**
	 * @param type the type
	 * @return the intervalValue
	 */
	public Long getIntValue(MpType type) {
		Long value = null;
		try
		{
			value = this.intervalValue.get(type);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * @param type the type
	 * @param value the value
	 */
	public void setIntValue(MpType type, Long value) {
		try
		{
			this.intervalValue.put(type, value);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Long retreiveFromExactValueByMpType(MpType pType) {
		Long value = null;
		try
		{
			value = this.exactValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 * 
	 * @param pType the type
	 * @param pValue the value
	 */
	public void addToExactValue(MpType pType, Long pValue) {
		try
		{
			this.exactValue.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	public Map<MpType, Long> getExactValue() {
		return exactValue;
	}

	public void setExactValue(Map<MpType, Long> exactValue) {
		this.exactValue = exactValue;
	}

	/**
	 * @return the idClaim
	 */
	public String getIdClaim() {
		return idClaim;
	}

	/**
	 * @param idClaim the idClaim to set
	 */
	public void setIdClaim(String idClaim) {
		this.idClaim = idClaim;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	public List<String> getLstPinVin() {
		return lstPinVin;
	}

	public void setLstPinVin(List<String> lstPinVin) {
		this.lstPinVin = lstPinVin;
	}

	/**
	 * @return the intervalId
	 */
	public Long getIntervalId() {
		return intervalId;
	}

	/**
	 * @param intervalId the intervalId to set
	 */
	public void setIntervalId(Long intervalId) {
		this.intervalId = intervalId;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * 
	 * @return the failure date in Epoch
	 */
	public Long getFailureDate() {
		return failureDate;
	}

	/**
	 * 
	 * @param failureDate the failure date in Epoch
	 */
	public void setFailureDate(Long failureDate) {
		this.failureDate = failureDate;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the planExternalId
	 */
	public Long getPlanExternalId() {
		return planExternalId;
	}

	/**
	 * @param planExternalId the planExternalId to set
	 */
	public void setPlanExternalId(Long planExternalId) {
		this.planExternalId = planExternalId;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id set the id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the isSapOrigin
	 */
	public Integer getIsSapOrigin() {
		return isSapOrigin;
	}

	/**
	 * @param isSapOrigin the isSapOrigin to set
	 */
	public void setIsSapOrigin(Integer isSapOrigin) {
		this.isSapOrigin = isSapOrigin;
	}

	/**
	 * @return the canBeModified
	 */
	public boolean isCanBeModified() {
		return canBeModified;
	}

	/**
	 * @param canBeModified the canBeModified to set
	 */
	public void setCanBeModified(boolean canBeModified) {
		this.canBeModified = canBeModified;
	}

	/**
	 * @return the canBeSaved
	 */
	public boolean isCanBeSaved() {
		return canBeSaved;
	}

	/**
	 * @param canBeSaved the canBeSaved to set
	 */
	public void setCanBeSaved(boolean canBeSaved) {
		this.canBeSaved = canBeSaved;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * Get the checked parameter of the question.
	 * 
	 * @return true if the question is checked.
	 */
	public boolean isChecked() {
		return isChecked;
	}

	/**
	 * Set the checked parameter of the question.
	 * 
	 * @param isChecked true if the question is checked.
	 */
	public void setChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}

	/**
	 * @return the strongId
	 */
	public String getStrongId() {
		return strongId;
	}

	/**
	 * @param strongId the strongId to set
	 */
	public void setStrongId(String strongId) {
		this.strongId = strongId;
	}

	/**
	 * @return the operatorType
	 */
	public int getOperatorType() {
		return operatorType;
	}

	/**
	 * @param operatorType to set
	 */
	public void setOperatorType(int operatorType) {
		this.operatorType = operatorType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.id != null ? this.id : "null");
		builder.append(" ");
		builder.append("Strong Id(" + (this.strongId == null ? "" : this.strongId) + ")");
		builder.append(" ");
		builder.append("Update(" + (this.updateDate == null ? "" : this.updateDate) + ")");
		builder.append(" ");
		builder.append("Interval Id(" + this.intervalId + ")");
		builder.append(" ");
		builder.append("Plan external Id(" + this.planExternalId + ")");
		builder.append(" ");
		builder.append("V.I.N.(" + this.vin + ")");
		builder.append(" ");
		builder.append("Interval Code(" + (this.intervalCode == null ? "" : this.intervalCode) + ")");
		builder.append(" ");
		builder.append("[");
		for (MpType type : MpType.values())
		{
			if (this.exactValue != null && this.exactValue.get(type) != null)
			{
				builder.append(type.toString());
				builder.append("=");
				builder.append(this.exactValue.get(type));
				builder.append(" ");
			}
		}
		builder.append("]");
		builder.append("interval [");
		for (MpType type : MpType.values())
		{
			if (this.intervalValue != null && this.intervalValue.get(type) != null)
			{
				builder.append(type.toString());
				builder.append("=");
				builder.append(this.intervalValue.get(type));
				builder.append(" ");
			}
		}
		builder.append(" ");
		builder.append("sap origin(" + this.isSapOrigin + ")");
		builder.append(" ");
		builder.append("can be modified(" + this.canBeModified + ")");
		builder.append(" ");
		builder.append("can be saved(" + this.canBeSaved + ")");

		builder.append("]\n");
		return builder.toString();
	}

	public String getOperationJsonForUcr() {
		return operationJsonForUcr;
	}

	public void setOperationJsonForUcr(String operationJsonForUcr) {
		this.operationJsonForUcr = operationJsonForUcr;
	}

	public Map<MpType, Long> getIntervalValue() {
		return intervalValue;
	}

	public void setIntervalValue(Map<MpType, Long> intervalValue) {
		this.intervalValue = intervalValue;
	}

	/**
	 * @return the saveComments
	 */
	public String getSaveComments() {
		return saveComments;
	}

	/**
	 * @param saveComments the saveComments to set
	 */
	public void setSaveComments(String saveComments) {
		this.saveComments = saveComments;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
}
