package capgemini.cnh.mpbusiness.dto;

/**
 * Type of interval.
 * 
 * @author lestrabo
 *
 */
public enum MpHistoryOrigin {

	/**
	 * TIDB .
	 */
	TIDB(0),
	/**
	 * SAP.
	 */
	SAP(1),

	/**
	 * UCR.
	 */
	UCR(2);

	/** Value for an Enum. */
	private Integer value;

	/**
	 * Constructor.
	 * 
	 * @param num value of origin
	 * @param newLabel label of origin
	 */
	MpHistoryOrigin(Integer num) {
		value = num;

	}

	/**
	 * Getter pour value.
	 *
	 * @return value
	 */
	public Integer getValue() {
		return value;
	}

	@Override
	public String toString() {
		switch (this)
		{
		case TIDB:
			return "TIDB";
		case SAP:
			return "SAP";
		case UCR:
			return "UCR";
		}
		return null;
	}

	/**
	 * 
	 * @param mpHistoryOriginValue
	 * @return
	 */
	public static Integer getValueFromStringIfExist(String mpHistoryOriginValue) {
		for (MpHistoryOrigin mpHistoryOrigin : values())
		{
			if (mpHistoryOrigin.toString().equals(mpHistoryOriginValue))
			{
				return mpHistoryOrigin.getValue();
			}
		}
		return null;
	}

	/**
	 * 
	 * @param mpHistoryOriginValue
	 * @return
	 */
	public static MpHistoryOrigin getMpCallStatusFromValue(Integer mpHistoryOriginValue) {
		for (MpHistoryOrigin mpHistoryOrigin : values())
		{
			if (mpHistoryOrigin.getValue().equals(mpHistoryOriginValue))
			{
				return mpHistoryOrigin;
			}
		}
		return null;
	}

}