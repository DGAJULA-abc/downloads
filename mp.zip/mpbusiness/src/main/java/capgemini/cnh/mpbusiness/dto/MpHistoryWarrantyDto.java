package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for: data recorded when using interactive maintenance plan with a V.I.N.
 * 
 * @author dbabillo
 */
public final class MpHistoryWarrantyDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * V.I.N. of the vehicle.
	 */
	private String vin;

	/**
	 * Warranty start date.
	 */
	private String warrantyDate;

	/**
	 * Identifier of the element of the usage list to pre-select if any.
	 * Else 0.
	 */
	private int selectedUsage;

	/**
	 * Last registered mileage if any.
	 * Else value is 0.
	 */
	private int mileage;

	/**
	 * Last registered working hour if any.
	 * Else value is 0.
	 */
	private int hour;

	/**
	 * User search date (dd/MM/yyyy) in user local time.
	 */
	private String nowDate;

	/**
	 * Only for CNH: the WSD is modifiable only in some cases.
	 */
	private boolean isModifiable = true;

	/**
	 * Mininum range of selection of the WSD.
	 */
	private String minDate = null;

	/**
	 * Maximum range of selection of the WSD.
	 */
	private String maxDate = null;

	/**
	 * Default constructor.
	 */
	public MpHistoryWarrantyDto() {
		super();
		this.vin = null;
		this.warrantyDate = null;
		this.selectedUsage = 0;
		this.mileage = 0;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the warrantyDate
	 */
	public String getWarrantyDate() {
		return warrantyDate;
	}

	/**
	 * @param warrantyDate the warrantyDate to set
	 */
	public void setWarrantyDate(String warrantyDate) {
		this.warrantyDate = warrantyDate;
	}

	/**
	 * @return the selectedUsage
	 */
	public int getSelectedUsage() {
		return selectedUsage;
	}

	/**
	 * @param selectedUsage the selectedUsage to set
	 */
	public void setSelectedUsage(int selectedUsage) {
		this.selectedUsage = selectedUsage;
	}

	/**
	 * @return the mileage
	 */
	public int getMileage() {
		return mileage;
	}

	/**
	 * @param mileage the mileage to set
	 */
	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @param hour the hour to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * @return the nowDate
	 */
	public String getNowDate() {
		return nowDate;
	}

	/**
	 * @param nowDate the nowDate to set
	 */
	public void setNowDate(String nowDate) {
		this.nowDate = nowDate;
	}

	public boolean isModifiable() {
		return isModifiable;
	}

	public void setModifiable(boolean isModifiable) {
		this.isModifiable = isModifiable;
	}

	public String getMinDate() {
		return minDate;
	}

	public void setMinDate(String minDate) {
		this.minDate = minDate;
	}

	public String getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}

	@Override
	public String toString() {
		return "Warranty " + this.warrantyDate != null ? this.warrantyDate.toString() : "null" + " V.I.N. " + this.vin != null ? this.vin.toString() : "null";
	}
}
