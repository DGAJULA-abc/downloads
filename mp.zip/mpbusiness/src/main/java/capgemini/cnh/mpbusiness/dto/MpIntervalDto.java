/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.mpbusiness.util.MpIntervalStatusEnum;

/**
 * @author mamestoy
 *
 */
public class MpIntervalDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Maintenance Interval Id. **/
	private Long id = null;

	/** Plan Id. **/
	private Long idPlan = null;

	/** Type. **/
	private String typeLabel = null;

	/** Type. **/
	private String type = null;

	/** Code. **/
	private String code = null;

	/** Coupon. **/
	private String coupon = null;

	/** Frequency. **/
	private String frequency = null;

	/**
	 * Start value.
	 */
	private Map<MpType, Long> startValue;

	/**
	 * After value.
	 */
	private Map<MpType, Long> afterValue;

	/**
	 * After value.
	 */
	private String performanceLabel;

	/** Repair Time. **/
	private Long repairTime = null;

	/** operation by series. **/
	private Long operationBySeriesId = null;

	/** comment. **/
	//private String comment = null;
	/** comment Id. **/
	private Long commentId = null;
	/** comment Id. **/
	private String commentLabel = null;
	/** is selected . **/
	private boolean isSelected = false;
	/** type of selection R, B or A . **/
	private String selectionType = "";

	/** is modifiable . **/
	private boolean isModifiable = true;

	/** is savable . **/
	private boolean isSavable = true;
	/**
	 * Delta comment.
	 **/
	private String deltaComment = null;

	/**
	 * The status of the interval (High overdue, overdue, on time, coming soon, manually selected by dealer)
	 */
	private MpIntervalStatusEnum status = MpIntervalStatusEnum.NOT_RECOMMENDED;

	/**
	 * Maintenace Interval Group.
	 */
	private Long group = null;

	/** Is customer. **/
	private Boolean isCustomer = false;

	/** External : 1 from control room, 0 from EDS/eTIM. **/
	private Integer external = null;

	/**
	 * Delta value.
	 */
	private Map<MpType, Long> deltaValue;

	/** flag. **/
	private boolean flag = false;

	/** Failure Code. **/
	private String failureCode = null;

	/** Defect. **/
	private String defect = null;

	private String forecastDate = null;

	/** Coupon description. */
	private String description = null;
	
	/** hidden. */
	private boolean hidden = false;

	/**
	 * Constructor.
	 */
	public MpIntervalDto() {
		super();
		this.startValue = new HashMap<MpType, Long>();
		this.afterValue = new HashMap<MpType, Long>();
		this.deltaValue = new HashMap<MpType, Long>();
		for (MpType type : MpType.values())
		{
			this.setStartValue(type, null);
			this.setAfterValue(type, null);
		}
	}

	/**
	 * Constructor from value for debug purpose.
	 * 
	 * @param pSvKm
	 *            start value km
	 * @param pSvHour
	 *            start value hour
	 * @param pSvMonth
	 *            start value month
	 * @param pAvKm
	 *            after value km
	 * @param pAvHour
	 *            after value hour
	 * @param pAvMonth
	 *            after value month
	 */
	public MpIntervalDto(Long pSvKm, Long pSvHour, Long pSvMonth, Long pAvKm, Long pAvHour, Long pAvMonth) {
		super();
		this.startValue = new HashMap<MpType, Long>();
		this.afterValue = new HashMap<MpType, Long>();
		this.deltaValue = new HashMap<MpType, Long>();
		this.setStartValue(MpType.MP_KM, pSvKm);
		this.setStartValue(MpType.MP_HOUR, pSvHour);
		this.setStartValue(MpType.MP_MONTH, pSvMonth);
		this.setAfterValue(MpType.MP_KM, pAvKm);
		this.setAfterValue(MpType.MP_HOUR, pAvHour);
		this.setAfterValue(MpType.MP_MONTH, pAvMonth);
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan
	 *            the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the commentId
	 */
	public Long getCommentId() {
		return commentId;
	}

	/**
	 * @param commentId
	 *            the commentId to set
	 */
	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the startValueKm
	 */
	public Long getStartValueKm() {
		return this.getStartValue(MpType.MP_KM);
	}

	/**
	 * @param startValueKm
	 *            the startValueKm to set
	 */
	public void setStartValueKm(Long startValueKm) {
		this.setStartValue(MpType.MP_KM, startValueKm);
	}

	/**
	 * @return the startValueMonth
	 */
	public Long getStartValueMonth() {
		return this.getStartValue(MpType.MP_MONTH);
	}

	/**
	 * @param startValueMonth
	 *            the startValueMonth to set
	 */
	public void setStartValueMonth(Long startValueMonth) {
		this.setStartValue(MpType.MP_MONTH, startValueMonth);
	}

	/**
	 * @return the startValueHour
	 */
	public Long getStartValueHour() {
		return this.getStartValue(MpType.MP_HOUR);
	}

	/**
	 * @param startValueHour
	 *            the startValueHour to set
	 */
	public void setStartValueHour(Long startValueHour) {
		this.setStartValue(MpType.MP_HOUR, startValueHour);
	}

	/**
	 * Generic getter for start value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Long getStartValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.startValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic getter for start value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public long getStartMath(MpType pType) {
		long value = 0L;
		try
		{
			value = this.startValue.get(pType) != null ? this.startValue.get(pType).longValue() : 0L;
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for start value.
	 * 
	 * @param pType the type
	 * @param pStartValue the value
	 */
	public void setStartValue(MpType pType, Long pStartValue) {
		try
		{
			this.startValue.put(pType, pStartValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @return the afterValueKm
	 */
	public Long getAfterValueKm() {
		return this.getAfterValue(MpType.MP_KM);
	}

	/**
	 * @param afterValueKm
	 *            the afterValueKm to set
	 */
	public void setAfterValueKm(Long afterValueKm) {
		this.setAfterValue(MpType.MP_KM, afterValueKm);
	}

	/**
	 * @return the afterValueMonth
	 */
	public Long getAfterValueMonth() {
		return this.getAfterValue(MpType.MP_MONTH);
	}

	/**
	 * @param afterValueMonth
	 *            the afterValueMonth to set
	 */
	public void setAfterValueMonth(Long afterValueMonth) {
		this.setAfterValue(MpType.MP_MONTH, afterValueMonth);
	}

	/**
	 * @return the afterValueHour
	 */
	public Long getAfterValueHour() {
		return this.getAfterValue(MpType.MP_HOUR);
	}

	/**
	 * @param afterValueHour
	 *            the afterValueHour to set
	 */
	public void setAfterValueHour(Long afterValueHour) {
		this.setAfterValue(MpType.MP_HOUR, afterValueHour);
	}

	/**
	 * Generic getter for after value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Long getAfterValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.afterValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic getter for after value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public long getAfterMath(MpType pType) {
		long value = 0L;
		try
		{
			value = this.afterValue.get(pType) != null ? this.afterValue.get(pType).longValue() : 0L;
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for after value.
	 * 
	 * @param pType the type
	 * @param pAfterValue the value
	 */
	public void setAfterValue(MpType pType, Long pAfterValue) {
		try
		{
			this.afterValue.put(pType, pAfterValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @return the repairTime
	 */
	public Long getRepairTime() {
		return repairTime;
	}

	/**
	 * @param repairTime
	 *            the repairTime to set
	 */
	public void setRepairTime(Long repairTime) {
		this.repairTime = repairTime;
	}

	/**
	 * @return the typeLabel
	 */
	public String getTypeLabel() {
		return typeLabel;
	}

	/**
	 * @param typeLabel
	 *            the typeLabel to set
	 */
	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	/**
	 * @return the operationBySeriesId
	 */
	public Long getOperationBySeriesId() {
		return operationBySeriesId;
	}

	/**
	 * @param operationBySeriesId
	 *            the operationBySeriesId to set
	 */
	public void setOperationBySeriesId(Long operationBySeriesId) {
		this.operationBySeriesId = operationBySeriesId;
	}

	/**
	 * @return the isSelected
	 */
	public boolean isSelected() {
		return isSelected;
	}

	/**
	 * @param isSelected
	 *            the isSelected to set
	 */
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	/**
	 * @return the commentLabel
	 */
	public String getCommentLabel() {
		return commentLabel;
	}

	/**
	 * @param commentLabel
	 *            the commentLabel to set
	 */
	public void setCommentLabel(String commentLabel) {
		this.commentLabel = commentLabel;
	}

	/**
	 * @return the group
	 */
	public Long getGroup() {
		return group;
	}

	/**
	 * @return the group
	 */
	public long convertGroupForMath() {
		return group != null ? group.longValue() : 0L;
	}

	/**
	 * @param group
	 *            the group to set
	 */
	public void setGroup(Long group) {
		this.group = group;
	}

	/**
	 * @return the coupon
	 */
	public String getCoupon() {
		return coupon;
	}

	/**
	 * @param coupon the coupon to set
	 */
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	/**
	 * @return the isModifiable
	 */
	public boolean isModifiable() {
		return isModifiable;
	}

	/**
	 * @param isModifiable the isModifiable to set
	 */
	public void setModifiable(boolean isModifiable) {
		this.isModifiable = isModifiable;
	}

	/**
	 * @return the isSavable
	 */
	public boolean isSavable() {
		return isSavable;
	}

	/**
	 * @param isSavable the isSavable to set
	 */
	public void setSavable(boolean isSavable) {
		this.isSavable = isSavable;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("id(");
		builder.append(this.id != null ? this.id.toString() : "null");
		builder.append(") ");
		builder.append("idPlan(");
		builder.append(this.idPlan != null ? this.idPlan.toString() : "null");
		builder.append(") ");
		builder.append("code(");
		builder.append(this.code != null ? this.code.toString() : "null");
		builder.append(") ");
		builder.append("coupon(");
		builder.append(this.coupon != null ? this.coupon.toString() : "null");
		builder.append(") ");
		builder.append("group(");
		builder.append(this.group != null ? this.group.toString() : "null");
		builder.append(") ");
		builder.append("isModifiable(");
		builder.append(this.isModifiable);
		builder.append(") ");
		builder.append("isSavable(");
		builder.append(this.isSavable);
		builder.append(") ");
		for (MpType type : MpType.values())
		{
			builder.append(type.toString());
			builder.append("(");
			builder.append(this.getStartValue(type) != null ? this.getStartValue(type).toString() : "null");
			builder.append(", ");
			builder.append(this.getAfterValue(type) != null ? this.getAfterValue(type).toString() : "null");
			builder.append(") ");
		}
		builder.append("\n");
		return builder.toString();
	}

	/**
	 * @return the deltaComment
	 */
	public String getDeltaComment() {
		return deltaComment;
	}

	/**
	 * @param deltaComment the deltaComment to set
	 */
	public void setDeltaComment(String deltaComment) {
		this.deltaComment = deltaComment;
	}

	/**
	 * Return the divisor of 2 values.
	 * 
	 * @param m1 value 1
	 * @param m2 value 2
	 * @return -1 if value are not multiple, the divisor if values are multiple
	 */
	private static int ifMultipleType(long m1, long m2) {
		int v = -1;
		if (m1 <= 0L && m2 <= 0L)
		{ // -- both <= 0L (not set don't break multiple rule)
			v = 0;
		}
		else if (m2 > 0L && m1 > 0L)
		{ // -- both set
			if (m1 % m2 == 0)
			{ // -- multiple
				// -- get the divisor
				if (m1 < m2)
				{
					v = (int) (m2 / m1);
				}
				else
				{
					v = (int) (m1 / m2);
				}
			} // -- else not multiple
		} // -- else one interval is not set cannot be multiple
		return (v);
	}

	/**
	 * Check if two intervals are multiple of one another.
	 * 
	 * @param pInterval an interval
	 * @return true if interval are multiple, false otherwise
	 */
	public boolean ifMulitple(MpIntervalDto pInterval) {
		boolean is = true;
		int v_base = -1;
		int v = 0;
		for (MpType type : MpType.values())
		{
			// -- rule 1: no after value
			if (pInterval.getStartMath(type) > 0L || this.getStartMath(type) > 0L)
			{
				is = false;
				break;
			}
			// -- rule 2: no group
			if (this.convertGroupForMath() > 0L || pInterval.convertGroupForMath() > 0L)
			{
				is = false;
				break;
			}
			// -- rule 3: value are mulitple
			v = MpIntervalDto.ifMultipleType(this.getAfterMath(type), pInterval.getAfterMath(type));
			if (v < 0)
			{
				is = false;
				break;
			}
			else if (this.getAfterMath(type) > 0L && pInterval.getAfterMath(type) > 0L)
			{
				// -- to be multiple all interval type must share the same divisor
				if (v_base < 0)
				{ // -- initialize at first loop
					v_base = v;
				}
				else if (v != v_base)
				{ // -- not the same divisor
					is = false;
					break;
				}
			}
		}
		return (is);
	}

	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	/**
	 * 
	 * @return true if the interval is made of customer operations, false otherwise.
	 */
	public Boolean isCustomer() {
		return isCustomer;
	}

	/**
	 * 
	 * @param isCustomer true if the interval is made of customer operations, false otherwise.
	 */
	public void setCustomer(Boolean isCustomer) {
		this.isCustomer = isCustomer;
	}

	/**
	 * 
	 * @return The map of Delta values.
	 */
	public Map<MpType, Long> getDeltaValue() {
		return deltaValue;
	}

	/**
	 * @param deltaValue the deltaValue to set
	 */
	public void setDeltaValue(Map<MpType, Long> deltaValue) {
		this.deltaValue = deltaValue;
	}

	/**
	 * 
	 * @return true if the interval is recommended by eTIM, false otherwise.
	 */
	public String getSelectionType() {
		return selectionType;
	}

	/**
	 * 
	 * @param selectionType true if the interval is recommended by eTIM, false otherwise.
	 */
	public void setSelectionType(String selectionType) {
		this.selectionType = selectionType;
	}

	/**
	 * @return the external
	 */
	public Integer getExternal() {
		return external;
	}

	/**
	 * @param external the external to set
	 */
	public void setExternal(Integer external) {
		this.external = external;
	}

	/**
	 * @return the flag
	 */
	public boolean isFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getFailureCode() {
		return failureCode;
	}

	public void setFailureCode(String failureCode) {
		this.failureCode = failureCode;
	}

	public String getDefect() {
		return defect;
	}

	public void setDefect(String defect) {
		this.defect = defect;
	}

	/**
	 * Getter pour performanceLabel.
	 *
	 * @return performanceLabel
	 */
	public String getPerformanceLabel() {
		return performanceLabel;
	}

	/**
	 * Setter pour performanceLabel.
	 *
	 * @param performanceLabel performanceLabel à positionner.
	 */
	public void setPerformanceLabel(String performanceLabel) {
		this.performanceLabel = performanceLabel;
	}

	/**
	 * Get the status of the interval.
	 * 
	 * @return the status
	 */
	public MpIntervalStatusEnum getStatus() {

		return status;
	}

	/**
	 * Set the status of the interval.
	 * 
	 * @param status the status.
	 */
	public void setStatus(MpIntervalStatusEnum status) {
		this.status = status;
	}

	public String getForecastDate() {
		return forecastDate;
	}

	public void setForecastDate(String forecastDate) {
		this.forecastDate = forecastDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public boolean isHidden() {
		return hidden;
	}

	
	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

}
