/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mamestoy
 *
 */
public class MpIntervalOperationDto extends MpIntervalDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** interval Id. **/
	private Long intervalId = null;

	/** interval code. **/
	private String intervalCode = null;

	/** operation label. **/
	private String operationLabel = null;

	/** operation label id. **/
	private String operationLabelId = null;

	/** operation description. **/
	private String operationDescription = null;

	/** operation description id. **/
	private String operationDescriptionId = null;

	/** Operation Label for series. **/
	private String operationLabelForSeries = null;

	/** Operation Label for series id in MP_OPERATION_TITLE. **/
	private Long operationLabelForSeriesId = null;

	/** operation Id. **/
	private Long idOperation = null;

	/** operation micro. **/
	private String microOperation = null;

	/** operation srt. **/
	private String srtOperation = null;

	/** family ice code. **/
	private String locationFamilyIceCode = null;
	/** group ice code. **/
	private String locationGroupIceCode = null;
	/** subgroup ice code. **/
	private String locationSubGroupIceCode = null;

	/** topic ice code. **/
	private String infotypeTopicIceCode = null;
	/** subtopic ice code. **/
	private String infotypeSubTopicIceCode = null;
	/** category ice code. **/
	private String infotypeCategoryIceCode = null;
	/** infotype ice code. **/
	private String infotypeInfotypeIceCode = null;

	/** last maintenance date, engine hour **/
	private Long lastMaintenanceDate = null;
	private String lastMaintenanceEH = null;
	private String lastMaintenanceBales = null;

	/** operation location on the vehicle **/
	private String location = null;

	/**
	 * attached operations.
	 */
	private List<MpOperationDto> operations = null;

	/**
	 * Constructor.
	 */
	public MpIntervalOperationDto() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param intervalDto : intervalDto to copy
	 */
	public MpIntervalOperationDto(MpIntervalDto intervalDto) {
		super();
		this.setCode(intervalDto.getCode());
		this.setCoupon(intervalDto.getCoupon());
		this.setFrequency(intervalDto.getFrequency());
		this.setType(intervalDto.getType());
		this.setCommentId(intervalDto.getCommentId());
		this.setRepairTime(intervalDto.getRepairTime());
		for (MpType type : MpType.values())
		{
			this.setAfterValue(type, intervalDto.getAfterValue(type));
			this.setStartValue(type, intervalDto.getStartValue(type));
		}
		this.setId(intervalDto.getId());
		this.setCommentLabel(intervalDto.getCommentLabel());
		this.setOperations(new ArrayList<MpOperationDto>());
		this.setSelected(intervalDto.isSelected());
		this.setCustomer(intervalDto.isCustomer());
		this.setModifiable(intervalDto.isModifiable());
		this.setExternal(intervalDto.getExternal());
		this.setFailureCode(intervalDto.getFailureCode());
		this.setDefect(intervalDto.getDefect());
		this.setDeltaValue(intervalDto.getDeltaValue());
		this.setStatus(intervalDto.getStatus());
	}

	/**
	 * @return the idOperation
	 */
	public Long getIdOperation() {
		return idOperation;
	}

	/**
	 * @param idOperation the idOperation to set
	 */
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the intervalId
	 */
	public Long getIntervalId() {
		return intervalId;
	}

	/**
	 * @param intervalId the intervalId to set
	 */
	public void setIntervalId(Long intervalId) {
		this.intervalId = intervalId;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the operationLabel
	 */
	public String getOperationLabel() {
		return operationLabel;
	}

	/**
	 * @param operationLabel the operationLabel to set
	 */
	public void setOperationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
	}

	/**
	 * @return the operationDescription
	 */
	public String getOperationDescription() {
		return operationDescription;
	}

	/**
	 * @param operationDescription the operationDescription to set
	 */
	public void setOperationDescription(String operationDescription) {
		this.operationDescription = operationDescription;
	}

	/**
	 * @return the operationLabelForSeries
	 */
	public String getOperationLabelForSeries() {
		return operationLabelForSeries;
	}

	/**
	 * @param operationLabelForSeries the operationLabelForSeries to set
	 */
	public void setOperationLabelForSeries(String operationLabelForSeries) {
		this.operationLabelForSeries = operationLabelForSeries;
	}

	/**
	 * @return the operationLabelForSeriesId
	 */
	public Long getOperationLabelForSeriesId() {
		return operationLabelForSeriesId;
	}

	/**
	 * @param operationLabelForSeriesId the operationLabelForSeriesId to set
	 */
	public void setOperationLabelForSeriesId(Long operationLabelForSeriesId) {
		this.operationLabelForSeriesId = operationLabelForSeriesId;
	}

	/**
	 * @return the microOperation
	 */
	public String getMicroOperation() {
		return microOperation;
	}

	/**
	 * @param microOperation the microOperation to set
	 */
	public void setMicroOperation(String microOperation) {
		this.microOperation = microOperation;
	}

	/**
	 * @return the srtOperation
	 */
	public String getSrtOperation() {
		return srtOperation;
	}

	/**
	 * @param srtOperation the srtOperation to set
	 */
	public void setSrtOperation(String srtOperation) {
		this.srtOperation = srtOperation;
	}

	/**
	 * @return the operations
	 */
	public List<MpOperationDto> getOperations() {
		return operations;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<MpOperationDto> operations) {
		this.operations = operations;
	}

	/**
	 * @return the locationFamilyIceCode
	 */
	public String getLocationFamilyIceCode() {
		return locationFamilyIceCode;
	}

	/**
	 * @param locationFamilyIceCode the locationFamilyIceCode to set
	 */
	public void setLocationFamilyIceCode(String locationFamilyIceCode) {
		this.locationFamilyIceCode = locationFamilyIceCode;
	}

	/**
	 * @return the locationGroupIceCode
	 */
	public String getLocationGroupIceCode() {
		return locationGroupIceCode;
	}

	/**
	 * @param locationGroupIceCode the locationGroupIceCode to set
	 */
	public void setLocationGroupIceCode(String locationGroupIceCode) {
		this.locationGroupIceCode = locationGroupIceCode;
	}

	/**
	 * @return the locationSubGroupIceCode
	 */
	public String getLocationSubGroupIceCode() {
		return locationSubGroupIceCode;
	}

	/**
	 * @param locationSubGroupIceCode the locationSubGroupIceCode to set
	 */
	public void setLocationSubGroupIceCode(String locationSubGroupIceCode) {
		this.locationSubGroupIceCode = locationSubGroupIceCode;
	}

	/**
	 * @return the infotypeTopicIceCode
	 */
	public String getInfotypeTopicIceCode() {
		return infotypeTopicIceCode;
	}

	/**
	 * @param infotypeTopicIceCode the infotypeTopicIceCode to set
	 */
	public void setInfotypeTopicIceCode(String infotypeTopicIceCode) {
		this.infotypeTopicIceCode = infotypeTopicIceCode;
	}

	/**
	 * @return the infotypeSubTopicIceCode
	 */
	public String getInfotypeSubTopicIceCode() {
		return infotypeSubTopicIceCode;
	}

	/**
	 * @param infotypeSubTopicIceCode the infotypeSubTopicIceCode to set
	 */
	public void setInfotypeSubTopicIceCode(String infotypeSubTopicIceCode) {
		this.infotypeSubTopicIceCode = infotypeSubTopicIceCode;
	}

	/**
	 * @return the infotypeCategoryIceCode
	 */
	public String getInfotypeCategoryIceCode() {
		return infotypeCategoryIceCode;
	}

	/**
	 * @param infotypeCategoryIceCode the infotypeCategoryIceCode to set
	 */
	public void setInfotypeCategoryIceCode(String infotypeCategoryIceCode) {
		this.infotypeCategoryIceCode = infotypeCategoryIceCode;
	}

	/**
	 * @return the infotypeInfotypeIceCode
	 */
	public String getInfotypeInfotypeIceCode() {
		return infotypeInfotypeIceCode;
	}

	/**
	 * @param infotypeInfotypeIceCode the infotypeInfotypeIceCode to set
	 */
	public void setInfotypeInfotypeIceCode(String infotypeInfotypeIceCode) {
		this.infotypeInfotypeIceCode = infotypeInfotypeIceCode;
	}

	/**
	 * @return ice code format.
	 */
	public String getIceCode() {
		String toReturn = "";
		if (locationFamilyIceCode != null)
		{
			toReturn = locationFamilyIceCode;
			if (locationGroupIceCode != null)
			{
				toReturn += "." + locationGroupIceCode;
				if (locationSubGroupIceCode != null)
				{
					toReturn += "." + locationSubGroupIceCode;
				}
			}
		}
		toReturn += "-" + getInfotypeIceCode();
		return toReturn;
	}

	/**
	 * @return ice code format.
	 */
	public String getInfotypeIceCode() {
		String toReturn = "";
		toReturn = infotypeTopicIceCode + "." + infotypeSubTopicIceCode + "." + infotypeCategoryIceCode + "."
				+ infotypeInfotypeIceCode;

		return toReturn;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append("id ope Series ");
		builder.append(this.idOperationSeries != null ? this.idOperationSeries.toString() : "null");

		builder.append(" - interval Id ");
		builder.append(this.intervalId != null ? this.intervalId.toString() : "null");

		return builder.toString();
	}

	/**
	 * @return the operationDescriptionId
	 */
	public String getOperationDescriptionId() {
		return operationDescriptionId;
	}

	/**
	 * @param operationDescriptionId the operationDescriptionId to set
	 */
	public void setOperationDescriptionId(String operationDescriptionId) {
		this.operationDescriptionId = operationDescriptionId;
	}

	/**
	 * @return the operationLabelId
	 */
	public String getOperationLabelId() {
		return operationLabelId;
	}

	/**
	 * @param operationLabelId the operationLabelId to set
	 */
	public void setOperationLabelId(String operationLabelId) {
		this.operationLabelId = operationLabelId;
	}

	public Long getLastMaintenanceDate() {
		return lastMaintenanceDate;
	}

	public void setLastMaintenanceDate(Long lastMaintenanceDate) {
		this.lastMaintenanceDate = lastMaintenanceDate;
	}

	public String getLastMaintenanceEH() {
		return lastMaintenanceEH;
	}

	public void setLastMaintenanceEH(String lastMaintenanceEH) {
		this.lastMaintenanceEH = lastMaintenanceEH;
	}

	public String getLastMaintenanceBales() {
		return lastMaintenanceBales;
	}

	public void setLastMaintenanceBales(String lastMaintenanceBales) {
		this.lastMaintenanceBales = lastMaintenanceBales;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
