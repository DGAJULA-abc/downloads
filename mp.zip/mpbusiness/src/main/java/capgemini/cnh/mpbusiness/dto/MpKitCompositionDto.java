/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author MAY
 *
 */
public class MpKitCompositionDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public MpKitCompositionDto() {
		super();
	}

	/** COMP_KIT_CODE. **/
	private String compKitCode = null;

	/** COMP_PN_CODE. **/
	private String compPnCode = null;

	/** COMP_PN_LABEL. **/
	private String compPnLabel = null;

	/** COMP_PN_QTY. **/
	private Double compPnQty = null;

	/** COMP_DATE. **/
	private String compDate = null;

	/**
	 * @return the compKitCode
	 */
	public String getCompKitCode() {
		return compKitCode;
	}

	/**
	 * @param compKitCode the compKitCode to set
	 */
	public void setCompKitCode(String compKitCode) {
		this.compKitCode = compKitCode;
	}

	/**
	 * @return the compPnCode
	 */
	public String getCompPnCode() {
		return compPnCode;
	}

	/**
	 * @param compPnCode the compPnCode to set
	 */
	public void setCompPnCode(String compPnCode) {
		this.compPnCode = compPnCode;
	}

	/**
	 * @return the compPnLabel
	 */
	public String getCompPnLabel() {
		return compPnLabel;
	}

	/**
	 * @param compPnLabel the compPnLabel to set
	 */
	public void setCompPnLabel(String compPnLabel) {
		this.compPnLabel = compPnLabel;
	}

	/**
	 * @return the compPnQty
	 */
	public Double getCompPnQty() {
		return compPnQty;
	}

	/**
	 * @param compPnQty the compPnQty to set
	 */
	public void setCompPnQty(Double compPnQty) {
		this.compPnQty = compPnQty;
	}

	/**
	 * @return the compDate
	 */
	public String getCompDate() {
		return compDate;
	}

	/**
	 * @param compDate the compDate to set
	 */
	public void setCompDate(String compDate) {
		this.compDate = compDate;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";
		toReturn += getCompKitCode();
		toReturn += " ";
		toReturn += getCompPnCode();
		toReturn += " ";
		toReturn += getCompPnQty();
		toReturn += " ";
		toReturn += getCompDate();
		return toReturn;
	}

	/**
	 * Return true if this and given object are equals.
	 * 
	 * @param obj Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MpKitCompositionDto other = (MpKitCompositionDto) obj;

		if (this.compKitCode == null)
		{
			if (other.compKitCode != null)
			{
				return false;
			}
		}
		else if (!this.compKitCode.equals(other.compKitCode))
		{
			return false;
		}

		if (this.compPnCode == null)
		{
			if (other.compPnCode != null)
			{
				return false;
			}
		}
		else if (!this.compPnCode.equals(other.compPnCode))
		{
			return false;
		}

		if (this.compPnLabel == null)
		{
			if (other.compPnLabel != null)
			{
				return false;
			}
		}
		else if (!this.compPnLabel.equals(other.compPnLabel))
		{
			return false;
		}

		if (this.compPnQty == null)
		{
			if (other.compPnQty != null)
			{
				return false;
			}
		}
		else if (!this.compPnQty.equals(other.compPnQty))
		{
			return false;
		}

		return true;
	}

}
