/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author cblois
 *
 */
public final class MpLockDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;
	
	/** Code VIN. **/
	private String vin = null;
	
	/** Creation date. **/
	private Date creationDate = null;

	/**
	 * Locked Constructor.
	 */
	public MpLockDto() {
		super();
	}

	
	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	
	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	
	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	
	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}


}
