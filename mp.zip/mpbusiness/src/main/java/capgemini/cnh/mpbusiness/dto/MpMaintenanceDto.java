/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.Date;

import capgemini.cnh.framework.dto.Dto;

/**
 *
 * @author lestrabo
 */
public class MpMaintenanceDto extends Dto {

	/**  */
	private static final long serialVersionUID = 1L;

	/**
	 * Instance app (Vin)
	 */
	private String vin;

	private MpCustomerDto mpCustomerDto;

	private MpNextStopMinDto mpNextStopMinDto;

	/**
	 * Contract number
	 */
	private String contractNumber;

	/**
	 * Contract number
	 */
	private String planId;

	/**
	 * Next km date
	 */
	private Date dateProposalHour;

	/**
	 * Next date
	 */
	private Date dateProposalMonth;

	/**
	 * Next hour date
	 */
	private Date dateProposalKm;

	/**
	 * Is alert hour
	 */
	private boolean isAlertHour;

	/**
	 * Is alert km
	 */
	private boolean isAlertKm;

	/**
	 * Is alert month
	 */
	private boolean isAlertMonth;

	/**
	 * Appointment date
	 */
	private Date dateAppointment;

	/**
	 * Appointment id
	 */
	private Long idAppointment;

	/**
	 * CallStatus
	 */
	private String callStatus;

	/**
	 * 
	 */
	public MpMaintenanceDto() {
		super();
	}

	/**
	 * Getter pour vin.
	 *
	 * @return vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * Setter pour vin.
	 *
	 * @param vin vin à positionner.
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * Getter pour contractNumber.
	 *
	 * @return contractNumber
	 */
	public String getContractNumber() {
		return contractNumber;
	}

	/**
	 * Setter pour contractNumber.
	 *
	 * @param contractNumber contractNumber à positionner.
	 */
	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	/**
	 * Getter pour planId.
	 *
	 * @return planId
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * Setter pour planId.
	 *
	 * @param planId planId à positionner.
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * Getter pour dateProposalHour.
	 *
	 * @return dateProposalHour
	 */
	public Date getDateProposalHour() {
		return dateProposalHour;
	}

	/**
	 * Setter pour dateProposalHour.
	 *
	 * @param dateProposalHour dateProposalHour à positionner.
	 */
	public void setDateProposalHour(Date dateProposalHour) {
		this.dateProposalHour = dateProposalHour;
	}

	/**
	 * Getter pour dateProposalMonth.
	 *
	 * @return dateProposalMonth
	 */
	public Date getDateProposalMonth() {
		return dateProposalMonth;
	}

	/**
	 * Setter pour dateProposalMonth.
	 *
	 * @param dateProposalMonth dateProposalMonth à positionner.
	 */
	public void setDateProposalMonth(Date dateProposalMonth) {
		this.dateProposalMonth = dateProposalMonth;
	}

	/**
	 * Getter pour dateProposalKm.
	 *
	 * @return dateProposalKm
	 */
	public Date getDateProposalKm() {
		return dateProposalKm;
	}

	/**
	 * Setter pour dateProposalKm.
	 *
	 * @param dateProposalKm dateProposalKm à positionner.
	 */
	public void setDateProposalKm(Date dateProposalKm) {
		this.dateProposalKm = dateProposalKm;
	}

	/**
	 * Getter pour isAlertHour.
	 *
	 * @return isAlertHour
	 */
	public boolean isAlertHour() {
		return isAlertHour;
	}

	/**
	 * Setter pour isAlertHour.
	 *
	 * @param isAlertHour isAlertHour à positionner.
	 */
	public void setAlertHour(boolean isAlertHour) {
		this.isAlertHour = isAlertHour;
	}

	/**
	 * Getter pour isAlertKm.
	 *
	 * @return isAlertKm
	 */
	public boolean isAlertKm() {
		return isAlertKm;
	}

	/**
	 * Setter pour isAlertKm.
	 *
	 * @param isAlertKm isAlertKm à positionner.
	 */
	public void setAlertKm(boolean isAlertKm) {
		this.isAlertKm = isAlertKm;
	}

	/**
	 * Getter pour isAlertMonth.
	 *
	 * @return isAlertMonth
	 */
	public boolean isAlertMonth() {
		return isAlertMonth;
	}

	/**
	 * Setter pour isAlertMonth.
	 *
	 * @param isAlertMonth isAlertMonth à positionner.
	 */
	public void setAlertMonth(boolean isAlertMonth) {
		this.isAlertMonth = isAlertMonth;
	}

	/**
	 * Getter pour mpCustomerDto.
	 *
	 * @return mpCustomerDto
	 */
	public MpCustomerDto getMpCustomerDto() {
		return mpCustomerDto;
	}

	/**
	 * Setter pour mpCustomerDto.
	 *
	 * @param mpCustomerDto mpCustomerDto à positionner.
	 */
	public void setMpCustomerDto(MpCustomerDto mpCustomerDto) {
		this.mpCustomerDto = mpCustomerDto;
	}

	/**
	 * Getter pour mpNextStopMinDto.
	 *
	 * @return mpNextStopMinDto
	 */
	public MpNextStopMinDto getMpNextStopMinDto() {
		return mpNextStopMinDto;
	}

	/**
	 * Setter pour mpNextStopMinDto.
	 *
	 * @param mpNextStopMinDto mpNextStopMinDto à positionner.
	 */
	public void setMpNextStopMinDto(MpNextStopMinDto mpNextStopMinDto) {
		this.mpNextStopMinDto = mpNextStopMinDto;
	}

	/**
	 * @return the dateAppointment
	 */
	public Date getDateAppointment() {
		return dateAppointment;
	}

	/**
	 * @param dateAppointment the dateAppointment to set
	 */
	public void setDateAppointment(Date dateAppointment) {
		this.dateAppointment = dateAppointment;
	}

	/**
	 * @return the idAppointment
	 */
	public Long getIdAppointment() {
		return idAppointment;
	}

	/**
	 * @param idAppointment the idAppointment to set
	 */
	public void setIdAppointment(Long idAppointment) {
		this.idAppointment = idAppointment;
	}

	/**
	 * @return the callStatus
	 */
	public String getCallStatus() {
		return callStatus;
	}

	/**
	 * @param callStatus the callStatus to set
	 */
	public void setCallStatus(String callStatus) {
		this.callStatus = callStatus;
	}

}
