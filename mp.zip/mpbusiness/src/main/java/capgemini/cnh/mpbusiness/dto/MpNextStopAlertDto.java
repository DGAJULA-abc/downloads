package capgemini.cnh.mpbusiness.dto;

/**
 * Dto class for: coupon in alerts
 * 
 * @author bmilcend
 */
public class MpNextStopAlertDto extends MpNextStopDto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Dealer code
	 */
	public String dealerCode;

	/**
	 * Brand ice code.
	 */
	public String brandIceCode;

	/**
	 * default constructor.
	 * 
	 * 
	 */
	public MpNextStopAlertDto() {
		super();
	}

	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}

	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public void merge(MpNextStopAlertDto mpNextStopAlertDtoToMerge) {
		//Next Value
		if (mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_KM) != null)
		{
			this.setNextValue(MpType.MP_KM, mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_KM));
		}
		if (mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_HOUR) != null)
		{
			this.setNextValue(MpType.MP_HOUR, mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_HOUR));
		}
		if (mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_MONTH) != null)
		{
			this.setNextValue(MpType.MP_MONTH, mpNextStopAlertDtoToMerge.getNextValue(MpType.MP_MONTH));
		}

		//Proposal date
		if (mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_KM) != null)
		{
			this.setProposalDate(MpType.MP_KM, mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_KM));
		}
		if (mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_HOUR) != null)
		{
			this.setProposalDate(MpType.MP_HOUR, mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_HOUR));
		}
		if (mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_MONTH) != null)
		{
			this.setProposalDate(MpType.MP_MONTH, mpNextStopAlertDtoToMerge.getProposalDate(MpType.MP_MONTH));
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vin == null) ? 0 : vin.hashCode());
		return result;
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MpNextStopAlertDto other = (MpNextStopAlertDto) obj;
		if (vin == null)
		{
			if (other.vin != null)
			{
				return false;
			}
		}
		else if (!vin.equals(other.vin) || !intervalCode.equals(other.intervalCode))
		{
			return false;
		}
		return true;
	}

	/**
	 * @return the brandIceCode
	 */
	public String getBrandIceCode() {
		return brandIceCode;
	}

	/**
	 * @param brandIceCode the brandIceCode to set
	 */
	public void setBrandIceCode(String brandIceCode) {
		this.brandIceCode = brandIceCode;
	}

}
