package capgemini.cnh.mpbusiness.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MpNextStopByScoreDto extends MpScoreDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Interval next stop.
	 */
	private Map<MpType, Long> nextStop;
	/**
	 * Interval next stop recalculated for multiple interval.
	 */
	private Map<MpType, Long> nextStopRecalculated;

	/**
	 * coupon received from control room.
	 */
	private Integer external = 0;

	/**
	 * Default constructor.
	 * 
	 * @param interval
	 *            the interval of the score
	 */
	public MpNextStopByScoreDto(MpIntervalDto interval, String customer) {
		super(interval, customer);
		nextStop = new HashMap<>();
		nextStopRecalculated = new HashMap<>();
		for (MpType type : MpType.values())
		{
			this.nextStop.put(type, 0L);
			this.nextStopRecalculated.put(type, 0L);
		}
		external = 0;
	}

	/**
	 * Copy constructor.
	 * 
	 * @param score
	 *            the mp score to copy
	 */
	public MpNextStopByScoreDto(MpNextStopByScoreDto score) {
		super(score);
		this.nextStop = new HashMap<>();
		this.nextStopRecalculated = new HashMap<>();
		for (MpType type : MpType.values())
		{
			this.nextStop.put(type, score.getNextStopByType(type));
			this.nextStopRecalculated.put(type, score.getNextStopRecalculatedByType(type));
		}
		this.external = score.getExternal();
	}

	/**
	 * Test if this is multiple of pScore or pScore is multiple of this.
	 * 
	 * @param listScore the list containing the multiples values to compare
	 * @return true if this is a multiple for all the list
	 */
	public boolean isMultiple(List<MpNextStopByScoreDto> listScore) {
		boolean result = true;
		if (this.isCanBeMultiple())
		{
			for (MpScoreDto score : listScore)
			{
				if (!this.isMultiple(score))
				{
					result = false;
					break;
				}
			}
		}
		return result;
	}

	/**
	 * Test if this has at least one multiple in listScore.
	 * 
	 * @param listScore the list containing the multiples values to compare
	 * @return true if there is a multiple in the list
	 */
	public boolean hasMultipleInList(List<MpNextStopByScoreDto> listScore) {
		boolean result = false;
		if (this.isCanBeMultiple())
		{
			for (MpScoreDto score : listScore)
			{
				if (this.isMultiple(score))
				{
					result = true;
					break;
				}
			}
		}

		return result;
	}

	/**
	 * @return the nextStop
	 */
	public Map<MpType, Long> getNextStop() {
		return nextStop;
	}

	/**
	 * @return the nextStop by type
	 */
	public Long getNextStopByType(MpType type) {
		return nextStop.get(type);
	}

	/**
	 * Set the next stop for a given interval type.
	 * 
	 * @param stop
	 *            the stop
	 * @param type
	 *            type of interval
	 */
	public void setNextStopByType(Long stop, MpType type) {
		//		try
		//		{
		nextStop.put(type, stop);
		//		}
		//		catch (IllegalArgumentException | UnsupportedOperationException | ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
	}

	/**
	 * @return the nextStopRecalculated
	 */
	public Map<MpType, Long> getNextStopRecalculated() {
		return nextStopRecalculated;
	}

	/**
	 * @return the nextStopRecalculated
	 */
	public Long getNextStopRecalculatedByType(MpType type) {
		return nextStopRecalculated.get(type);
	}

	/**
	 * @param nextStopRecalculated the nextStopRecalculated to set
	 */
	public void setNextStopRecalculatedByType(Long stop, MpType type) {
		//		try
		//		{
		nextStopRecalculated.put(type, stop);
		//		}
		//		catch (IllegalArgumentException | UnsupportedOperationException | ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
	}

	/**
	 * Getter pour external.
	 *
	 * @return external
	 */
	public Integer getExternal() {
		return external;
	}

	/**
	 * Setter pour external.
	 *
	 * @param external external à positionner.
	 */
	public void setExternal(Integer external) {
		this.external = external;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getInterval().getCode() != null ? this.getInterval().getCode().toString() : "null");
		builder.append(": ");

		for (MpType type : MpType.values())
		{
			builder.append(type.toString());
			builder.append("(");
			builder.append(this.getScoreByType(type) != null ? this.getScoreByType(type).toString() : "null");
			builder.append(", ");
			builder.append(this.getSelectedByType(type));
			builder.append(", ");
			builder.append(this.getMultipleByType(type) != null ? this.getMultipleByType(type).toString() : "null");
			builder.append(", ");
			builder.append(this.getHistory(type) != null ? this.getHistory(type).toString() : "null");
			builder.append(") \n");
		}

		builder.append("Next Stop: 				");
		for (MpType type : MpType.values())
		{
			builder.append(this.getNextStopByType(type));
			builder.append(", ");
		}
		builder.append(" \n");

		builder.append("Next Stop Recalculated:	");
		for (MpType type : MpType.values())
		{
			builder.append(this.getNextStopRecalculatedByType(type));
			builder.append(", ");
		}
		builder.append(" \n");

		return builder.toString();
	}

}
