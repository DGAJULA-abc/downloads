package capgemini.cnh.mpbusiness.dto;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for: history of performed maintenances on a V.I.N.
 *
 * @author dbabillo
 */
public class MpNextStopDto extends Dto {

	public enum NextMaintenance {

		ANTICIPATED(0, "Anticipated"), SUGGESTED(2, "Suggested"), ON_TIME(3, "On Time"), OVERDUE(4, "Overdue"), HIGH_OVERDUE(5, "Heavy Overdue");

		private int value;
		private String desc;

		public int getValue() {
			return this.value;
		}

		public String getDesc() {
			return this.desc;
		}

		private NextMaintenance(int value, String desc) {
			this.value = value;
			this.desc = desc;
		}

		public static NextMaintenance valueOf(int val) {
			for (NextMaintenance maintenance : NextMaintenance.values())
			{
				if (maintenance.value == val)
				{
					return maintenance;
				}
			}
			return null;
		}
	}

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * V.I.N. of the vehicle.
	 */
	protected String vin;

	/**
	 * Name of the maintenance plan interval (not saved in database).
	 */
	protected String intervalCode;

	/**
	 * Date of the last UPDATE performed on the entry (automatically triggered).
	 */
	private String updateDate;

	/**
	 * Value at which the next maintenance needs to be done.
	 */
	private Map<MpType, Long> nextValue;

	/**
	 * Date at which the next maintenance needs to be done.
	 */
	private Map<MpType, Date> proposalDate;

	/**
	 * can be saved.
	 */
	private Long idPlan;

	/**
	 * is flexible.
	 */
	private boolean isFlexible = false;

	/**
	 * is flexible.
	 */
	private int toBeAddedUpdated = 0;

	/**
	 * coupon received from control room.
	 */
	private Integer external = 0;

	/**
	 * coupon received from ucr next_maintenance value
	 */
	private NextMaintenance ucrNextMaintenance = null;

	/**
	 * Value at which the maintenance is overdued.
	 */
	private Map<MpType, Long> overdueValue;

	/**
	 * Delta from the next stop up until the current value.
	 */
	private Map<MpType, Long> forecastValue;

	/**
	 * is high overdue.
	 */
	private boolean isHighOverdue = false;

	/**
	 * Description of the next Maintainance.
	 */
	protected String description;

	/**
	 * is high overdue days.
	 */
	private boolean isHighOverdueDays = false;

	/**
	 * is Coming soon hours.
	 */
	private boolean isComingSoonHours = false;

	/**
	 * is Coming soon days.
	 */
	private boolean isComingSoonDays = false;

	/**
	 * is Next stop.
	 */
	private boolean isNextStop = false;
	
	private boolean isHidden = false;

	/**
	 * default constructor.
	 *
	 *
	 */
	public MpNextStopDto() {
		super();
		this.nextValue = new HashMap<MpType, Long>();
		this.overdueValue = new HashMap<MpType, Long>();
		this.proposalDate = new HashMap<MpType, Date>();
		this.forecastValue = new HashMap<MpType, Long>();
	}

	/**
	 * Constructor.
	 * param toCopy : param to Copy
	 */
	public MpNextStopDto(MpNextStopDto toCopy) {
		super();
		this.nextValue = new HashMap<MpType, Long>();
		this.overdueValue = new HashMap<MpType, Long>();
		this.forecastValue = new HashMap<MpType, Long>();
		this.proposalDate = new HashMap<MpType, Date>();
		for (MpType type : MpType.values())
		{
			this.nextValue.put(type, toCopy.getNextValue(type));
			this.overdueValue.put(type, toCopy.getOverdueValue(type));
			this.proposalDate.put(type, toCopy.getProposalDate(type));
		}
		this.vin = toCopy.getVin();
		this.intervalCode = toCopy.getIntervalCode();
		this.idPlan = toCopy.getIdPlan();
		this.isFlexible = toCopy.isFlexible;
		this.toBeAddedUpdated = toCopy.toBeAddedUpdated;
		this.external = toCopy.external;
	}

	/**
	 * Second default constructor.
	 *
	 * @param vin the vin to set
	 * @param code the interval code to set
	 * @param planId the plan exact plan id
	 * @param external 1 if the alerts comes from EDS (case of FF if detected an anticipated stops)
	 *
	 */
	public MpNextStopDto(String vin, String code, Long planId, Integer external) {
		super();
		this.nextValue = new HashMap<MpType, Long>();
		this.overdueValue = new HashMap<MpType, Long>();
		this.forecastValue = new HashMap<MpType, Long>();
		this.proposalDate = new HashMap<MpType, Date>();
		this.vin = vin;
		this.intervalCode = code;
		this.idPlan = planId;
		this.isFlexible = false;
		this.external = external;

	}

	/**
	 * Generic getter for the value.
	 *
	 * @param pType the type
	 * @return the value
	 */
	public Date getProposalDate(MpType pType) {
		Date value = null;
		try
		{
			value = this.proposalDate.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 *
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setProposalDate(MpType pType, Date pValue) {
		try
		{
			this.proposalDate.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 *
	 * @param pType the type
	 * @return the value
	 */
	public Long getNextValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.nextValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 *
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setNextValue(MpType pType, Long pValue) {
		try
		{
			this.nextValue.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 *
	 * @param pType the type
	 * @return the value
	 */
	public Long getOverdueValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.overdueValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 *
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setOverdueValue(MpType pType, Long pValue) {
		try
		{
			this.overdueValue.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the isFlexible
	 */
	public boolean isFlexible() {
		return isFlexible;
	}

	/**
	 * @param isFlexible the isFlexible to set
	 */
	public void setFlexible(boolean isFlexible) {
		this.isFlexible = isFlexible;
	}

	/**
	 * @return the toBeAddedUpdated
	 */
	public int getToBeAddedUpdated() {
		return toBeAddedUpdated;
	}

	/**
	 * @param toBeAddedUpdated the toBeAddedUpdated to set
	 */
	public void setToBeAddedUpdated(int toBeAddedUpdated) {
		this.toBeAddedUpdated = toBeAddedUpdated;
	}

	/**
	 * @return the external
	 */
	public Integer getExternal() {
		return external;
	}

	/**
	 * @param external the external to set
	 */
	public void setExternal(Integer external) {
		this.external = external;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Update(" + (this.updateDate == null ? "" : this.updateDate) + ")");
		builder.append(" ");
		builder.append("V.I.N.(" + this.vin + ")");
		builder.append(" ");
		builder.append("Interval Code(" + (this.intervalCode == null ? "" : this.intervalCode) + ")");
		builder.append(" ");
		builder.append("[");
		for (MpType type : MpType.values())
		{
			if (this.nextValue.get(type) != null)
			{
				builder.append(type.toString());
				builder.append("=");
				builder.append(this.nextValue.get(type));
				builder.append(" ");
			}
		}
		builder.append("]\n");
		return builder.toString();
	}

	/**
	 * Getter pour nextValue.
	 *
	 * @return nextValue
	 */
	public Map<MpType, Long> getNextValueMap() {
		return nextValue;
	}

	/**
	 * Getter pour proposalDate.
	 *
	 * @return proposalDate
	 */
	public Map<MpType, Date> getProposalDateMap() {
		return proposalDate;
	}

	/**
	 * Getter pour ucrNextMaintenance.
	 *
	 * @return ucrNextMaintenance
	 */
	public NextMaintenance getUcrNextMaintenance() {
		return ucrNextMaintenance;
	}

	/**
	 * @param ucrNextMaintenance the ucrNextMaintenance to set
	 */
	public void setUcrNextMaintenance(NextMaintenance ucrNextMaintenance) {
		this.ucrNextMaintenance = ucrNextMaintenance;
	}

	/**
	 * @param dateList
	 * @return List<MpNextStopDto> sorted
	 */
	public List<MpNextStopDto> sortByCouponTitleValue(List<MpNextStopDto> mpNextStopDtoList) {
		if (!mpNextStopDtoList.isEmpty())
		{
			//TODO to create in the main class and to pass it
			Comparator<MpNextStopDto> NextValueHourComparatorMpNextStop = new Comparator<MpNextStopDto>() {

				@Override
				public int compare(MpNextStopDto mpNextStopDto1, MpNextStopDto mpNextStopDto2) {
					if (mpNextStopDto1.getIntervalCode() != null && mpNextStopDto2.getIntervalCode() != null)
					{
						return mpNextStopDto1.getIntervalCode().compareTo(mpNextStopDto2.getIntervalCode());
					}
					return 1;

				}
			};

			Collections.sort(mpNextStopDtoList, NextValueHourComparatorMpNextStop);
		}
		return mpNextStopDtoList;
	}

	/**
	 * True if it is high overdue for hours.
	 *
	 * @return True if it is high overdue for hours
	 */
	public boolean isHighOverdue() {
		return isHighOverdue;
	}

	/**
	 * Set True if it is high overdue for hours.
	 *
	 * @param isHighOverdue True if it is high overdue for hours.
	 */
	public void setHighOverdue(boolean isHighOverdue) {
		this.isHighOverdue = isHighOverdue;
	}

	/**
	 * True if it is high overdue for days.
	 *
	 * @return True if it is high overdue for days
	 */
	public boolean isHighOverdueDays() {
		return isHighOverdueDays;
	}

	/**
	 * Set True if it is high overdue for days.
	 *
	 * @param isHighOverdueDays True if it is high overdue for days
	 */
	public void setHighOverdueDays(boolean isHighOverdueDays) {
		this.isHighOverdueDays = isHighOverdueDays;
	}

	/**
	 * Generic getter for the forecast value.
	 *
	 * @param pType the type
	 * @return the value
	 */
	public Long getForecastValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.forecastValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the forecast value.
	 *
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setForecastValue(MpType pType, Long pValue) {
		try
		{
			this.forecastValue.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Get the forecast value.
	 *
	 * @return the forecast value
	 */
	public Map<MpType, Long> getForecastValue() {
		return forecastValue;
	}

	/**
	 * Set the forecast value.
	 *
	 * @param forecastValue the forecast value
	 */
	public void setForecastValue(Map<MpType, Long> forecastValue) {
		this.forecastValue = forecastValue;
	}

	/**
	 * True if the coupon is overdue in hours.
	 *
	 * @return True if the coupon is overdue in hours
	 */
	public boolean isComingSoonHours() {
		return isComingSoonHours;
	}

	/**
	 * Set True if the coupon is overdue in hours.
	 *
	 * @param isComingSoonHours True if the coupon is overdue in hours
	 */
	public void setComingSoonHours(boolean isComingSoonHours) {
		this.isComingSoonHours = isComingSoonHours;
	}

	/**
	 * True if the coupon is overdue in days.
	 *
	 * @return True if the coupon is overdue in days.
	 */
	public boolean isComingSoonDays() {
		return isComingSoonDays;
	}

	/**
	 * Set True if the coupon is overdue in days.
	 *
	 * @param isComingSoonDays True if the coupon is overdue in days.
	 */
	public void setComingSoonDays(boolean isComingSoonDays) {
		this.isComingSoonDays = isComingSoonDays;
	}

	public boolean isNextStop() {
		return isNextStop;
	}

	public void setNextStop(boolean isNextStop) {
		this.isNextStop = isNextStop;
	}
	
	public boolean isHidden() {
		return isHidden;
	}
	
	public void setHidden(boolean hidden) {
		isHidden = hidden;
	}
}

//class SortHourMpNextStopDto implements Comparator<MpNextStopDto> {
//
//	// Used for sorting in ascending order of values
//	public int compare(MpNextStopDto a, MpNextStopDto b) {
//		return a.getNextValue(MpType.MP_HOUR).compareTo(b.getNextValue(MpType.MP_HOUR));
//	}
//}