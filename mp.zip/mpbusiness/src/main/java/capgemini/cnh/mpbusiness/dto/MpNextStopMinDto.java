package capgemini.cnh.mpbusiness.dto;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.externals.eds.model.CurrentVehicleDataDto;
import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for: history of performed maintenances on a V.I.N.
 * 
 * @author dbabillo
 */
public class MpNextStopMinDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * V.I.N. of the vehicle.
	 */
	private String vin;

	/**
	 * contract of the vin when next stop is calculated.
	 */
	private String contractNb;

	/**
	 * Date of the last UPDATE performed on the entry (automatically triggered).
	 */
	private String updateDate;

	/**
	 * Value at which the next maintenance needs to be done.
	 */
	private Map<MpType, Long> nextValue = new HashMap<MpType, Long>();

	/**
	 * Date at which the next maintenance needs to be done.
	 */
	private Map<MpType, Date> minProposalDate = new HashMap<MpType, Date>();

	/**
	 * Flag alert = 1 if the stop is in alert.
	 */
	private Map<MpType, Integer> alert = new HashMap<MpType, Integer>();

	/**
	 * can be saved.
	 */
	private Long idPlan;

	/**
	 * curernt Mileage.
	 */
	private Long currentMileage;

	/**
	 * curernt hour.
	 */
	private Long currentHour;

	/**
	 * call status.
	 */
	private MpCallStatus mpCallStatus;

	/**
	 * The number of hours in Overdue.
	 */
	private Long hoursInOverdue = null;

	/**
	 * The number of days in Overdue.
	 */
	private Long daysInOverdue = null;

	/**
	 * Alert group id.
	 */
	private Long alertGroupId = null;

	/**
	 * Date proposal min.
	 */
	private Date dateProposalMin;

	/**
	 * Warranty Date.
	 */
	private String nextMaintenanceDate;

	/**
	 * default constructor.
	 * 
	 * 
	 */
	public MpNextStopMinDto() {
		super();
		this.nextValue = new HashMap<MpType, Long>();
		this.minProposalDate = new HashMap<MpType, Date>();
		this.alert = new HashMap<MpType, Integer>();
		for (MpType type : MpType.values())
		{
			this.setAlert(type, 0);
		}
	}

	/**
	 * Second default constructor.
	 * 
	 * @param vin the vin to set
	 * @param contractNb the contract Nb
	 * @param planId the plan exact plan id
	 * 
	 */
	public MpNextStopMinDto(String vin, Long planId, String contractNb) {
		super();
		this.nextValue = new HashMap<MpType, Long>();
		this.minProposalDate = new HashMap<MpType, Date>();
		this.alert = new HashMap<MpType, Integer>();
		for (MpType type : MpType.values())
		{
			this.setAlert(type, 0);
		}
		this.vin = vin;
		this.idPlan = planId;
		this.contractNb = contractNb;

	}

	/**
	 * Constructor.
	 * 
	 * @param toCopy : param to Copy
	 */
	public MpNextStopMinDto(MpNextStopMinDto toCopy) {
		super();
		this.vin = toCopy.getVin();
		this.idPlan = toCopy.getIdPlan();
		this.contractNb = toCopy.getContractNb();
		this.currentMileage = toCopy.getCurrentMileage();
		this.currentHour = toCopy.getCurrentHour();
		this.mpCallStatus = toCopy.getMpCallStatus();
		this.alertGroupId = toCopy.getAlertGroupId();

		for (MpType type : MpType.values())
		{
			this.nextValue.put(type, toCopy.getNextValue(type));
			this.minProposalDate.put(type, toCopy.getMinProposalDate(type));
			this.alert.put(type, toCopy.getAlert(type));
		}

	}

	/**
	 * Constructor.
	 * 
	 * @param toCopy : param to Copy
	 */
	public void copy(MpNextStopMinDto toCopy) {
		this.vin = toCopy.getVin();
		this.idPlan = toCopy.getIdPlan();
		this.contractNb = toCopy.getContractNb();
		this.currentMileage = toCopy.getCurrentMileage();
		this.currentHour = toCopy.getCurrentHour();

		for (MpType type : MpType.values())
		{
			this.nextValue.put(type, toCopy.getNextValue(type));
			this.minProposalDate.put(type, toCopy.getMinProposalDate(type));
			this.alert.put(type, toCopy.getAlert(type));
		}

	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Long getNextValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.nextValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic getter for map Next Value by type.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Map<MpType, Long> getNextValueMap() {
		return nextValue;
	}

	/**
	 * Generic setter for the value.
	 * 
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setNextValue(MpType pType, Long pValue) {
		try
		{
			this.nextValue.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Integer getAlert(MpType pType) {
		Integer value = null;
		try
		{
			value = this.alert.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 * 
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setAlert(MpType pType, Integer pValue) {
		try
		{
			this.alert.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Date getMinProposalDate(MpType pType) {
		Date value = null;
		try
		{
			value = this.minProposalDate.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Generic setter for the value.
	 * 
	 * @param pType the type
	 * @param pValue the value
	 */
	public void setMinProposalDate(MpType pType, Date pValue) {
		try
		{
			this.minProposalDate.put(pType, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the idPlan
	 */
	public Long getIdPlan() {
		return idPlan;
	}

	/**
	 * @param idPlan the idPlan to set
	 */
	public void setIdPlan(Long idPlan) {
		this.idPlan = idPlan;
	}

	/**
	 * @return the contractNb
	 */
	public String getContractNb() {
		return contractNb;
	}

	/**
	 * @param contractNb the contractNb to set
	 */
	public void setContractNb(String contractNb) {
		this.contractNb = contractNb;
	}

	/**
	 * @return the currentMileage
	 */
	public Long getCurrentMileage() {
		return currentMileage;
	}

	/**
	 * @param currentMileage the currentMileage to set
	 */
	public void setCurrentMileage(Long currentMileage) {
		this.currentMileage = currentMileage;
	}

	/**
	 * @return the currentHour
	 */
	public Long getCurrentHour() {
		return currentHour;
	}

	/**
	 * @param currentHour the currentHour to set
	 */
	public void setCurrentHour(Long currentHour) {
		this.currentHour = currentHour;
	}

	/**
	 * Update min next stop.
	 * 
	 * @param currentVehicleData current Vehicle Data
	 * @param contractNb the contract Nb
	 * @param planId the plan exact plan id
	 * 
	 */
	public void update(Long planId, String contractNb, CurrentVehicleDataDto currentVehicleData) {
		this.nextValue = new HashMap<MpType, Long>();
		this.minProposalDate = new HashMap<MpType, Date>();
		this.alert = new HashMap<MpType, Integer>();
		for (MpType type : MpType.values())
		{
			this.setAlert(type, 0);
		}
		this.idPlan = planId;
		this.contractNb = contractNb;
		if (currentVehicleData != null)
		{
			if (currentVehicleData.getCurrentMileage() != null)
			{
				this.currentMileage = currentVehicleData.getCurrentMileage();
			}
			if (currentVehicleData.getCurrentHours() != null)
			{
				this.currentHour = currentVehicleData.getCurrentHours();
			}
		}

	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Update(" + (this.updateDate == null ? "" : this.updateDate) + ")");
		builder.append(" ");
		builder.append("V.I.N.(" + this.vin + ")");
		builder.append(" ");
		builder.append("[");
		for (MpType type : MpType.values())
		{
			if (this.nextValue.get(type) != null)
			{
				builder.append(type.toString());
				builder.append("=");
				builder.append(this.nextValue.get(type));
				builder.append(" ");
			}
		}
		builder.append("]\n");
		return builder.toString();
	}

	/**
	 * Getter pour minProposalDate.
	 *
	 * @return minProposalDate
	 */
	public Map<MpType, Date> getMinProposalDate() {
		return minProposalDate;
	}

	/**
	 * Getter pour Alert.
	 *
	 * @return minProposalDate
	 */
	public Map<MpType, Integer> getAlertMap() {
		return alert;
	}

	/**
	 * Getter pour mpCallStatus.
	 *
	 * @return mpCallStatus
	 */
	public MpCallStatus getMpCallStatus() {
		return mpCallStatus;
	}

	/**
	 * Setter pour mpCallStatus.
	 *
	 * @param mpCallStatus mpCallStatus à positionner.
	 */
	public void setMpCallStatus(MpCallStatus mpCallStatus) {
		this.mpCallStatus = mpCallStatus;
	}

	/**
	 * Get the hours in overdue.
	 * 
	 * @return hoursInOverdue.
	 */
	public Long getHoursInOverdue() {
		return hoursInOverdue;
	}

	/**
	 * Set the hours in overdue.
	 * 
	 * @param hoursInOverdue the hours in overdue.
	 */
	public void setHoursInOverdue(Long hoursInOverdue) {
		this.hoursInOverdue = hoursInOverdue;
	}

	/**
	 * Get the days in overdue.
	 * 
	 * @return the days in overdue
	 */
	public Long getDaysInOverdue() {
		return daysInOverdue;
	}

	/**
	 * Set the days in overdue.
	 * 
	 * @param daysInOverdue the days in overdue
	 */
	public void setDaysInOverdue(Long daysInOverdue) {
		this.daysInOverdue = daysInOverdue;
	}

	/**
	 * Getter pour alertGroupId.
	 *
	 * @return alertGroupId
	 */
	public Long getAlertGroupId() {
		return alertGroupId;
	}

	/**
	 * Setter pour alertGroupId.
	 *
	 * @param alertGroupId alertGroupId à positionner.
	 */
	public void setAlertGroupId(Long alertGroupId) {
		this.alertGroupId = alertGroupId;
	}

	/**
	 * @return the dateProposalMin
	 */
	public Date getDateProposalMin() {
		return dateProposalMin;
	}

	/**
	 * @param dateProposalMin the dateProposalMin to set
	 */
	public void setDateProposalMin(Date dateProposalMin) {
		this.dateProposalMin = dateProposalMin;
	}

	/**
	 * Set nextMaintenanceDate
	 * 
	 * @param nextMaintenanceDate to set
	 */
	public void setNextDate(String nextMaintenanceDate) {
		this.nextMaintenanceDate = nextMaintenanceDate;
	}

	/**
	 * Get nextMaintenanceDate
	 */
	public String getNextDate() {
		return nextMaintenanceDate;
	}

}
