/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.List;

/**
 *
 * @author lestrabo
 *         Class is duplicated from etim because it need to be call from the smart view api
 *         Refacto has to be done to have one class used for both applications
 */
public class MpNextStopViewDto {

	private Long nextMaintenance;

	private String mpType;

	private Long overdueInHours;

	private List<MpCouponViewDto> comingSoon;

	private List<MpCouponViewDto> alert;

	private List<MpCouponViewDto> comingNext;

	private List<MpCouponViewDto> coupons;

	private List<MpCouponViewDto> nextStop;

	private String nextMaintenanceDate;

	/**
	 * Getter pour nextMaintenance.
	 *
	 * @return nextMaintenance
	 */
	public Long getNextMaintenance() {
		return nextMaintenance;
	}

	/**
	 * Setter pour nextMaintenance.
	 *
	 * @param nextMaintenance nextMaintenance à positionner.
	 */
	public void setNextMaintenance(Long nextMaintenance) {
		this.nextMaintenance = nextMaintenance;
	}

	/**
	 * Getter pour mpType.
	 *
	 * @return mpType
	 */
	public String getMpType() {
		return mpType;
	}

	/**
	 * Setter pour mpType.
	 *
	 * @param mpType mpType à positionner.
	 */
	public void setMpType(String mpType) {
		this.mpType = mpType;
	}

	/**
	 * Getter pour comingSoon.
	 *
	 * @return comingSoon
	 */
	public List<MpCouponViewDto> getComingSoon() {
		return comingSoon;
	}

	/**
	 * Setter pour comingSoon.
	 *
	 * @param comingSoon comingSoon à positionner.
	 */
	public void setComingSoon(List<MpCouponViewDto> comingSoon) {
		this.comingSoon = comingSoon;
	}

	/**
	 * Getter pour coupons.
	 *
	 * @return coupons
	 */
	public List<MpCouponViewDto> getCoupons() {
		return coupons;
	}

	/**
	 * Setter pour coupons.
	 *
	 * @param coupons coupons à positionner.
	 */
	public void setCoupons(List<MpCouponViewDto> coupons) {
		this.coupons = coupons;
	}

	public List<MpCouponViewDto> getAlert() {
		return alert;
	}

	public void setAlert(List<MpCouponViewDto> alert) {
		this.alert = alert;
	}

	public List<MpCouponViewDto> getComingNext() {
		return comingNext;
	}

	public void setComingNext(List<MpCouponViewDto> comingNext) {
		this.comingNext = comingNext;
	}

	public List<MpCouponViewDto> getNextStop() {
		return nextStop;
	}

	public void setNextStop(List<MpCouponViewDto> nextStop) {
		this.nextStop = nextStop;
	}

	public Long getOverdueInHours() {
		return overdueInHours;
	}

	public void setOverdueInHours(Long overdueInHours) {
		this.overdueInHours = overdueInHours;
	}

	/**
	 * Setter nextMaintenanceDate.
	 *
	 * @param nextMaintenanceDate
	 */
	public void setnextMaintenanceDate(String nextMaintenanceDate) {
		this.nextMaintenanceDate = nextMaintenanceDate;
	}

	/**
	 * Getter nextMaintenanceDate.
	 *
	 */
	public String getnextMaintenanceDate() {
		return nextMaintenanceDate;
	}
}
