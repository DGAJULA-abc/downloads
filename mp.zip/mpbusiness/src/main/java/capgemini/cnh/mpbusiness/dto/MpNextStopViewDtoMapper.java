/**
 *
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.DateUtil;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto.NextMaintenance;
import capgemini.cnh.mpbusiness.util.MpCouponViewComparator;

/**
 *
 * @author lestrabo
 *         Class is duplicated from etim because it need to be call from the smart view api
 *         Refacto has to be done to have one class used for both applications
 */
public class MpNextStopViewDtoMapper {

	/**
	 * map object dto to view.
	 *
	 * @param isDataFromUcr : mp data available from Ucr
	 * @param mpdtoList
	 * @param mpNextStopMin
	 * @return mpNextStopViewDtoList
	 **/
	public List<MpNextStopViewDto> mapDtoToListView(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, boolean isDataFromUcr, Map<String, MpFlexCouponDto> flexCoupons) {

		return mapDtoToListViewByMpType(mpdtoList, mpNextStopMin, Arrays.asList(MpType.values()), isDataFromUcr, flexCoupons);
	}

	/**
	 * MpNextStopViewDto will be created only for Type needed ,
	 * for example if month and hour are in alert there is no need to map km data in urgent maintenance.
	 *
	 * @param mpdtoList
	 * @param mpNextStopMin
	 * @param mpNextStopViewDto
	 * @param nextMaintenanceMap
	 * @param commingSoonMap
	 * @param mpType
	 * @return mpNextStopViewDtoList
	 */
	public List<MpNextStopViewDto> mapDtoToListViewByMpType(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, List<MpType> mpTypeList, boolean isDataFromUcr,
			Map<String, MpFlexCouponDto> flexCoupons) {
		List<MpNextStopViewDto> mpNextStopViewDtoList = new ArrayList<MpNextStopViewDto>();

		for (MpType mpType : mpTypeList)
		{
			MpNextStopViewDto mpNextStopViewDto = builMpNextStopViewDtoByMpType(mpdtoList, mpNextStopMin, mpType, isDataFromUcr, flexCoupons);
			if (mpNextStopViewDto != null)
			{
				mpNextStopViewDtoList.add(mpNextStopViewDto);
			}
		}

		return mpNextStopViewDtoList;
	}

	/**
	 * @param mpdtoList
	 * @param mpNextStopMin
	 * @param mpNextStopViewDto
	 * @param nextMaintenanceMap
	 * @param commingSoonMap
	 * @param mpType
	 */
	private MpNextStopViewDto builMpNextStopViewDtoByMpType(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, MpType mpType, boolean isDataFromUcr,
			Map<String, MpFlexCouponDto> flexCoupons) {

		MpNextStopViewDto mpNextStopViewDto = null;

		// Manage only hours for UCR
		if (isDataFromUcr && MpType.MP_HOUR == mpType)
		{
			// Min next stop is not recalculated for connected vehicles
			mpNextStopViewDto = builMpNextStopViewDtoByMpTypeUCR(mpdtoList, mpNextStopMin, mpType);
		}
		else
		{
			mpNextStopViewDto = builMpNextStopViewDtoByMpType(mpdtoList, mpNextStopMin, mpType, flexCoupons);
		}

		return mpNextStopViewDto;
	}

	/**
	 * @param mpdtoList
	 * @param mpNextStopMin
	 * @param mpType
	 */
	private MpNextStopViewDto builMpNextStopViewDtoByMpTypeUCR(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, MpType mpType) {

		// Initialise the View Dto for the SmartView
		MpNextStopViewDto mpNextStopViewDto = new MpNextStopViewDto();

		mpNextStopViewDto.setNextMaintenance(mpNextStopMin.getNextValue(mpType));
		mpNextStopViewDto.setMpType(mpType.toString());
		mpNextStopViewDto.setOverdueInHours(mpNextStopMin.getHoursInOverdue());

		//List Next stop by type
		Map<MpType, List<MpCouponViewDto>> nextStopMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List overdue by type
		Map<MpType, List<MpCouponViewDto>> overdueMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances coming soon by type
		Map<MpType, List<MpCouponViewDto>> comingSoonMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances alert by type
		Map<MpType, List<MpCouponViewDto>> alertMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances coming next by type
		Map<MpType, List<MpCouponViewDto>> comingNextMap = new HashMap<MpType, List<MpCouponViewDto>>();

		//Prepare all the coupons list
		nextStopMap.put(mpType, new ArrayList<>());
		overdueMap.put(mpType, new ArrayList<>());
		comingSoonMap.put(mpType, new ArrayList<>());
		alertMap.put(mpType, new ArrayList<>());
		comingNextMap.put(mpType, new ArrayList<>());

		for (MpNextStopDto mpdto : mpdtoList)
		{
			Long value = mpdto.getNextValue(mpType);

			// First row
			if (mpdto.isNextStop())
			{
				nextStopMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
			// First or second row with all the Heavy Overdue and Overdue (RED)
			else if (mpdto.getUcrNextMaintenance().equals(NextMaintenance.OVERDUE) || mpdto.getUcrNextMaintenance().equals(NextMaintenance.HIGH_OVERDUE))
			{
				overdueMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
			// Row below with On time (YELLOW)
			else if (mpdto.getUcrNextMaintenance().equals(NextMaintenance.ON_TIME))
			{
				alertMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
			// Row below with Suggested (GREY)
			else if (mpdto.getUcrNextMaintenance().equals(NextMaintenance.SUGGESTED))
			{
				comingNextMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
			//			else
			//			{
			//				comingSoonMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription()));
			//			}
		}

		//Sort coupons by coupon code
		Collections.sort(comingSoonMap.get(mpType), new MpCouponViewComparator());
		Collections.sort(alertMap.get(mpType), new MpCouponViewComparator());
		Collections.sort(comingNextMap.get(mpType), new MpCouponViewComparator());
		Collections.sort(nextStopMap.get(mpType), new MpCouponViewComparator());
		Collections.sort(overdueMap.get(mpType), new MpCouponViewComparator());

		mpNextStopViewDto.setComingSoon(comingSoonMap.get(mpType));
		mpNextStopViewDto.setAlert(alertMap.get(mpType));
		mpNextStopViewDto.setComingNext(comingNextMap.get(mpType));
		mpNextStopViewDto.setCoupons(nextStopMap.get(mpType));
		mpNextStopViewDto.setNextStop(overdueMap.get(mpType));

		return mpNextStopViewDto;
	}

	/**
	 * @param mpdtoList
	 * @param mpNextStopMin
	 * @param mpNextStopViewDto
	 * @param nextMaintenanceMap
	 * @param commingSoonMap
	 * @param mpType
	 * @throws SystemException
	 */
	private MpNextStopViewDto builMpNextStopViewDtoByMpType(List<MpNextStopDto> mpdtoList, MpNextStopMinDto mpNextStopMin, MpType mpType,
			Map<String, MpFlexCouponDto> flexCoupons) {

		//List nextMaintenance by type
		Map<MpType, List<MpCouponViewDto>> nextMaintenanceMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances coming soon by type
		Map<MpType, List<MpCouponViewDto>> comingSoonMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances alert by type
		Map<MpType, List<MpCouponViewDto>> alertMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances coming next by type
		Map<MpType, List<MpCouponViewDto>> comingNextMap = new HashMap<MpType, List<MpCouponViewDto>>();
		//List maintenances min Next Stop
		//Used for UCR in case we have not coupons in overdue or in alert, we display the min next stop
		Map<MpType, List<MpCouponViewDto>> nextStopMap = new HashMap<MpType, List<MpCouponViewDto>>();
		MpNextStopViewDto mpNextStopViewDto = null;

		//Init lists
		nextMaintenanceMap.put(mpType, new ArrayList<>());
		comingSoonMap.put(mpType, new ArrayList<>());
		alertMap.put(mpType, new ArrayList<>());
		comingNextMap.put(mpType, new ArrayList<>());
		nextStopMap.put(mpType, new ArrayList<>());

		//Init minValue and loop on the NextStops
		//to check each value and find the smallest
		Long minValue = null;
		String nextMaintenanceDate = null;
		for (MpNextStopDto mpdto : mpdtoList)
		{
			Long value = mpdto.getNextValue(mpType);
			//if the value is equals to the minValue the NextStop
			//is a next maintenance to do so added to nextMaintenanceMap
			if (value != null && !value.equals(new Long(0)) && minValue != null && value.equals(minValue))
			{
				mpNextStopMin.setNextValue(mpType, value);
				if (mpType == MpType.MP_MONTH && mpdto.getProposalDate(mpType) != null)
				{
					mpNextStopMin.setNextValue(mpType, mpdto.getProposalDate(mpType).getTime());
					nextMaintenanceDate = DateUtil.utilDateToString(mpdto.getProposalDate(mpType), DateUtil.DATE_ONLY_FORMAT);
					mpNextStopMin.setNextDate(nextMaintenanceDate);
				}
				//If the proposal date isn't defined we don't display the date row
				else if (mpType == MpType.MP_MONTH && mpdto.getProposalDate(mpType) == null)
				{
					mpNextStopMin.setNextValue(mpType, null);
				}

				nextMaintenanceMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
			//if the value is minus than the minValue the nextMaintenanceMap it is not anymore the minus value
			// so Added to the comingSoonMap and then add the new minus to nextMaintenanceMap
			else if (value != null && !value.equals(new Long(0)) && (minValue == null || value.compareTo(minValue) < 0))
			{
				comingSoonMap.get(mpType).addAll(nextMaintenanceMap.get(mpType));
				nextMaintenanceMap.get(mpType).clear();
				nextMaintenanceMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));

				mpNextStopMin.setNextValue(mpType, value);
				//If mpType is month the date value is already calculated in the proposalDate
				if (mpType == MpType.MP_MONTH && mpdto.getProposalDate(mpType) != null)
				{
					mpNextStopMin.setNextValue(mpType, mpdto.getProposalDate(mpType).getTime());
					nextMaintenanceDate = DateUtil.utilDateToString(mpdto.getProposalDate(mpType), DateUtil.DATE_ONLY_FORMAT);
					mpNextStopMin.setNextDate(nextMaintenanceDate);
				}
				//If the proposal date isn't defined we don't display the date row
				else if (mpType == MpType.MP_MONTH && mpdto.getProposalDate(mpType) == null)
				{
					mpNextStopMin.setNextValue(mpType, null);

				}
				minValue = value;
			}
			//if the value exist it is added to the comingSoonMap
			else if (value != null && value != 0)
			{
				comingSoonMap.get(mpType).add(new MpCouponViewDto(mpdto.getIntervalCode(), mpdto.getUcrNextMaintenance(), value, mpdto.getDescription(), mpdto.isHidden()));
			}
		}

		if (mpNextStopMin.getNextValue(mpType) != null)
		{
			mpNextStopViewDto = new MpNextStopViewDto();
			if (mpNextStopMin.getNextValue(mpType) != -1)
			{
				mpNextStopViewDto.setNextMaintenance(mpNextStopMin.getNextValue(mpType));
				mpNextStopViewDto.setMpType(mpType.toString());

				//Sort coupons by coupon code
				Collections.sort(comingSoonMap.get(mpType), new MpCouponViewComparator(flexCoupons));
				Collections.sort(alertMap.get(mpType), new MpCouponViewComparator(flexCoupons));
				Collections.sort(comingNextMap.get(mpType), new MpCouponViewComparator(flexCoupons));
				Collections.sort(nextStopMap.get(mpType), new MpCouponViewComparator(flexCoupons));

				mpNextStopViewDto.setComingSoon(comingSoonMap.get(mpType));
				mpNextStopViewDto.setAlert(alertMap.get(mpType));
				mpNextStopViewDto.setComingNext(comingNextMap.get(mpType));
				mpNextStopViewDto.setNextStop(nextStopMap.get(mpType));
				mpNextStopViewDto.setnextMaintenanceDate(mpNextStopMin.getNextDate());
			}

			if (flexCoupons != null && !flexCoupons.isEmpty())
			{
				Collections.sort(nextMaintenanceMap.get(mpType), new MpCouponViewComparator(flexCoupons));

			}

			mpNextStopViewDto.setCoupons(nextMaintenanceMap.get(mpType));

		}
		//add special case to fill coupons and comingSoon coupons when date_proposal of unit month is NULL
		else if (MpType.MP_MONTH.equals(mpType) && mpNextStopMin.getNextValue(mpType) == null)
		{
			mpNextStopViewDto = new MpNextStopViewDto();
			mpNextStopViewDto.setMpType(mpType.toString());

			//Sort coupons by coupon code
			Collections.sort(comingSoonMap.get(mpType), new MpCouponViewComparator(flexCoupons));
			Collections.sort(nextMaintenanceMap.get(mpType), new MpCouponViewComparator(flexCoupons));
			Collections.sort(alertMap.get(mpType), new MpCouponViewComparator(flexCoupons));
			Collections.sort(comingNextMap.get(mpType), new MpCouponViewComparator(flexCoupons));
			Collections.sort(nextStopMap.get(mpType), new MpCouponViewComparator(flexCoupons));

			mpNextStopViewDto.setAlert(alertMap.get(mpType));
			mpNextStopViewDto.setComingNext(comingNextMap.get(mpType));
			mpNextStopViewDto.setComingSoon(comingSoonMap.get(mpType));
			mpNextStopViewDto.setCoupons(nextMaintenanceMap.get(mpType));
			mpNextStopViewDto.setNextStop(nextMaintenanceMap.get(mpType));
			mpNextStopViewDto.setnextMaintenanceDate(mpNextStopMin.getNextDate());
		}

		return mpNextStopViewDto;

	}
}