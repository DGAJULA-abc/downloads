package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for oil performance when using interactive maintenance plan.
 * 
 * @author dbabillo
 */
public class MpOilPerformanceDto extends Dto {

	/**
	 * Default serial unique identifier.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Project identifier.
	 */
	private Long idProject;

	/**
	 * Config identifier.
	 */
	private Long idConfig;

	/**
	 * Config identifier of the standard performance oil.
	 */
	private Long standard;

	/**
	 * Config identifier of the low performance oil.
	 */
	private Long low;

	/**
	 * Default constructor.
	 */
	public MpOilPerformanceDto() {
		this.idProject = null;
		this.idConfig = null;
		this.standard = null;
		this.low = null;
	}

	/**
	 * @return the idProject
	 */
	public Long getIdProject() {
		return idProject;
	}

	/**
	 * @param idProject the idProject to set
	 */
	public void setIdProject(Long idProject) {
		this.idProject = idProject;
	}

	/**
	 * @return the idConfig
	 */
	public Long getIdConfig() {
		return idConfig;
	}

	/**
	 * @param idConfig the idConfig to set
	 */
	public void setIdConfig(Long idConfig) {
		this.idConfig = idConfig;
	}

	/**
	 * @return the standard
	 */
	public Long getStandard() {
		return standard;
	}

	/**
	 * @param standard the standard to set
	 */
	public void setStandard(Long standard) {
		this.standard = standard;
	}

	/**
	 * @return the low
	 */
	public Long getLow() {
		return low;
	}

	/**
	 * @param low the low to set
	 */
	public void setLow(Long low) {
		this.low = low;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("idConfig(");
		builder.append(this.idConfig != null ? this.idConfig.toString() : "null");
		builder.append(") ");
		builder.append("idProject(");
		builder.append(this.idProject != null ? this.idProject.toString() : "null");
		builder.append(") ");
		return builder.toString();
	}
}
