/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IConfiguration;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;

/**
 * @author mamestoy
 *
 */
public class MpOperationConsumableDto extends Dto implements IConfiguration, Comparable<MpOperationConsumableDto> {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** operation seies Id. **/
	private Long idOperationSeries = null;

	/** Id consumable. **/
	private Long idConsumable = null;
	/** Label consumable. **/
	private String consumable = null;

	/** description consumable. **/
	private String description = null;

	/** quanity. **/
	private String quantity = null;

	/** brandId. **/
	private Long brandId = null;

	/**
	 * Quantity in decimal format.
	 */
	private Float qty = Float.valueOf(0);

	/**
	 * Unit in which it is stored.
	 */
	private String unit = null;

	/**
	 * brand prefix.
	 */
	private String brandPrefix = null;

	/** with data. **/
	private String withAppli = null;

	/** part number. **/
	private String partnumber = null;

	/** is Selected. **/
	private boolean isSelected;

	/** is a part duplicated (to delete). */
	private boolean isDuplicated = false;

	/**
	 * Quantity in decimal format.
	 */
	private Float qtyLiter = 0f;

	/**
	 * Unit in which it is stored.
	 */
	private String unitLiter = null;

	/**
	 * Attached applicable configuration.
	 */
	private final IObjectConfiguration configuration;

	private Long occurrenceId = null;

	/**
	 * Locked Constructor.
	 */
	@SuppressWarnings("unused")
	private MpOperationConsumableDto() {
		super();
		this.configuration = ComplexConfigDto.valueOf(null);
	}

	/**
	 * Default Constructor.
	 * 
	 * @param configuration the attached configuration
	 */
	public MpOperationConsumableDto(IObjectConfiguration configuration) {
		super();
		if (configuration == null)
		{
			this.configuration = ComplexConfigDto.valueOf(null);
		}
		else
		{
			this.configuration = configuration;
		}
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the idConsumable
	 */
	public Long getIdConsumable() {
		return idConsumable;
	}

	/**
	 * @param idConsumable the idConsumable to set
	 */
	public void setIdConsumable(Long idConsumable) {
		this.idConsumable = idConsumable;
	}

	/**
	 * @return the consumable
	 */
	public String getConsumable() {
		return consumable;
	}

	/**
	 * @param consumable the consumable to set
	 */
	public void setConsumable(String consumable) {
		this.consumable = consumable;
	}

	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the brandId
	 */
	public Long getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the brandPrefix
	 */
	public String getBrandPrefix() {
		return brandPrefix;
	}

	/**
	 * @param brandPrefix the brandPrefix to set
	 */
	public void setBrandPrefix(String brandPrefix) {
		this.brandPrefix = brandPrefix;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	@Override
	public String toString() {
		String toReturn = "";

		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		if (idConsumable != null)
		{
			toReturn += "id consumable " + idConsumable.toString();
		}
		toReturn += " - ";
		toReturn += this.configuration.toString();
		toReturn += " - qty: " + this.quantity != null ? this.quantity : "null";

		return toReturn;
	}

	/**
	 * @return the part number
	 */
	public String getPartnumber() {
		return partnumber;
	}

	/**
	 * @param partnumber the part number
	 */
	public void setPartnumber(String partnumber) {
		this.partnumber = partnumber;
	}

	@Override
	public boolean isApplicable(ProductConfiguration productConfiguration) {
		return this.configuration.isApplicable(productConfiguration);
	}

	@Override
	public boolean hasConfiguration() {
		return this.configuration.hasConfiguration();
	}

	/**
	 * Getter pour isSelected.
	 *
	 * @return isSelected
	 */
	public boolean isSelected() {
		return isSelected;
	}

	/**
	 * Setter pour isSelected.
	 *
	 * @param isSelected isSelected à positionner.
	 */
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	/**
	 * @return the qty
	 */
	public Float getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(Float qty) {
		this.qty = qty;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * @return the isDuplicated
	 */
	public boolean isDuplicated() {
		return isDuplicated;
	}

	/**
	 * @param isDuplicated the isDuplicated to set
	 */
	public void setDuplicated(boolean isDuplicated) {
		this.isDuplicated = isDuplicated;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(MpOperationConsumableDto o) {
		return this.getId().compareTo(o.getId());
	}

	public Float getQtyLiter() {
		return qtyLiter;
	}

	public void setQtyLiter(Float qtyLiter) {
		this.qtyLiter = qtyLiter;
	}

	public String getUnitLiter() {
		return unitLiter;
	}

	public void setUnitLiter(String unitLiter) {
		this.unitLiter = unitLiter;
	}

	public Long getOccurrenceId() {
		return occurrenceId;
	}

	public void setOccurrenceId(Long occurrenceId) {
		this.occurrenceId = occurrenceId;
	}
}
