/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mamestoy
 *
 */
public class MpOperationDto extends MpIntervalDto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** interval Id. **/
	private Long intervalId = null;

	/** interval code. **/
	private String intervalCode = null;

	/** operation label. **/
	private String operationLabel = null;

	/** operation label id. **/
	private String operationLabelId = null;

	/** operation description. **/
	private String operationDescription = null;

	/** operation description. **/
	private String operationDescriptionId = null;

	/** Operation Label for series. **/
	private String operationLabelForSeries = null;

	/** Operation Label for series id in MP_OPERATION_TITLE. **/
	private Long operationLabelForSeriesId = null;

	/** operation Id. **/
	private Long idOperation = null;

	/** operation micro. **/
	private String microOperation = null;

	/** operation srt. **/
	private String srtOperation = null;

	/** operation ice code. **/
	private String iceCode = null;

	/** comment Label. **/
	private String commentLabel = null;

	/** location Label. **/
	private String location = null;

	/**
	 * attached operations.
	 */
	private List<MpOperationDto> operations = null;
	/**
	 * attached consumables.
	 */
	private List<MpOperationConsumableDto> consumables = null;

	/**
	 * attached parts.
	 */
	private List<MpOperationPartDto> parts = null;

	/**
	 * linked IU.
	 */
	//private List<MpOperationIuLinkDto> ius = null;

	private String iuLink = null;

	/**
	 * attached consumables.
	 */
	private List<MpOperationConsumableDto> mergedConsumables = new ArrayList<>();

	/**
	 * attached parts.
	 */
	private List<MpOperationPartDto> mergedParts = new ArrayList<>();

	/**
	 * Operation selected or not.
	 */
	private boolean selected = true;
	
	/**
	 * Check if has Iu link
	 */
	private boolean hasIuLink = true;

	/**
	 * Constructor.
	 */
	public MpOperationDto() {
		super();
	}

	/**
	 * @return the idOperation
	 */
	public Long getIdOperation() {
		return idOperation;
	}

	/**
	 * @param idOperation the idOperation to set
	 */
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the intervalId
	 */
	public Long getIntervalId() {
		return intervalId;
	}

	/**
	 * @param intervalId the intervalId to set
	 */
	public void setIntervalId(Long intervalId) {
		this.intervalId = intervalId;
	}

	/**
	 * @return the intervalCode
	 */
	public String getIntervalCode() {
		return intervalCode;
	}

	/**
	 * @param intervalCode the intervalCode to set
	 */
	public void setIntervalCode(String intervalCode) {
		this.intervalCode = intervalCode;
	}

	/**
	 * @return the operationLabel
	 */
	public String getOperationLabel() {
		return operationLabel;
	}

	/**
	 * @param operationLabel the operationLabel to set
	 */
	public void setOperationLabel(String operationLabel) {
		this.operationLabel = operationLabel;
	}

	/**
	 * @return the operationDescription
	 */
	public String getOperationDescription() {
		return operationDescription;
	}

	/**
	 * @param operationDescription the operationDescription to set
	 */
	public void setOperationDescription(String operationDescription) {
		this.operationDescription = operationDescription;
	}

	/**
	 * @return the microOperation
	 */
	public String getMicroOperation() {
		return microOperation;
	}

	/**
	 * @param microOperation the microOperation to set
	 */
	public void setMicroOperation(String microOperation) {
		this.microOperation = microOperation;
	}

	/**
	 * @return the srtOperation
	 */
	public String getSrtOperation() {
		return srtOperation;
	}

	/**
	 * @param srtOperation the srtOperation to set
	 */
	public void setSrtOperation(String srtOperation) {
		this.srtOperation = srtOperation;
	}

	/**
	 * @return the commentLabel
	 */
	public String getCommentLabel() {
		return commentLabel;
	}

	/**
	 * @param commentLabel the commentLabel to set
	 */
	public void setCommentLabel(String commentLabel) {
		this.commentLabel = commentLabel;
	}

	/**
	 * @return the consumables
	 */
	public List<MpOperationConsumableDto> getConsumables() {
		return consumables;
	}

	/**
	 * @param consumables the consumables to set
	 */
	public void setConsumables(List<MpOperationConsumableDto> consumables) {
		this.consumables = consumables;
	}

	/**
	 * @return the parts
	 */
	public List<MpOperationPartDto> getParts() {
		return parts;
	}

	/**
	 * @param parts the parts to set
	 */
	public void setParts(List<MpOperationPartDto> parts) {
		this.parts = parts;
	}

	/**
	 * @return the iuLink
	 */
	public String getIuLink() {
		return iuLink;
	}

	/**
	 * @param iuLink the iuLink to set
	 */
	public void setIuLink(String iuLink) {
		this.iuLink = iuLink;
	}

	/**
	 * @return the operations
	 */
	public List<MpOperationDto> getOperations() {
		return operations;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(List<MpOperationDto> operations) {
		this.operations = operations;
	}

	/**
	 * @return the iceCode
	 */
	public String getIceCode() {
		return iceCode;
	}

	/**
	 * @param iceCode the iceCode to set
	 */
	public void setIceCode(String iceCode) {
		this.iceCode = iceCode;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "interval Id " + intervalId;

		return toReturn;
	}

	/**
	 * @return the operationDescriptionId
	 */
	public String getOperationDescriptionId() {
		return operationDescriptionId;
	}

	/**
	 * @param operationDescriptionId the operationDescriptionId to set
	 */
	public void setOperationDescriptionId(String operationDescriptionId) {
		this.operationDescriptionId = operationDescriptionId;
	}

	/**
	 * @return the operationLabelId
	 */
	public String getOperationLabelId() {
		return operationLabelId;
	}

	/**
	 * @param operationLabelId the operationLabelId to set
	 */
	public void setOperationLabelId(String operationLabelId) {
		this.operationLabelId = operationLabelId;
	}

	/**
	 * @return the operationLabelForSeries
	 */
	public String getOperationLabelForSeries() {
		return operationLabelForSeries;
	}

	/**
	 * @param operationLabelForSeries the operationLabelForSeries to set
	 */
	public void setOperationLabelForSeries(String operationLabelForSeries) {
		this.operationLabelForSeries = operationLabelForSeries;
	}

	/**
	 * @return the operationLabelForSeriesId
	 */
	public Long getOperationLabelForSeriesId() {
		return operationLabelForSeriesId;
	}

	/**
	 * @param operationLabelForSeriesId the operationLabelForSeriesId to set
	 */
	public void setOperationLabelForSeriesId(Long operationLabelForSeriesId) {
		this.operationLabelForSeriesId = operationLabelForSeriesId;
	}

	/**
	 * Getter pour mergedConsumables.
	 *
	 * @return mergedConsumables
	 */
	public List<MpOperationConsumableDto> getMergedConsumables() {
		return mergedConsumables;
	}

	/**
	 * Setter pour mergedConsumables.
	 *
	 * @param mergedConsumables mergedConsumables à positionner.
	 */
	public void setMergedConsumables(List<MpOperationConsumableDto> mergedConsumables) {
		this.mergedConsumables = mergedConsumables;
	}

	/**
	 * Getter pour mergedParts.
	 *
	 * @return mergedParts
	 */
	public List<MpOperationPartDto> getMergedParts() {
		return mergedParts;
	}

	/**
	 * Setter pour mergedParts.
	 *
	 * @param mergedParts mergedParts à positionner.
	 */
	public void setMergedParts(List<MpOperationPartDto> mergedParts) {
		this.mergedParts = mergedParts;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	/**
	 * @return Has Iu link
	 */
	public boolean isHasIuLink() { return hasIuLink; }
	
	/**
	 * @param hasIuLink Has Iu link
	 */
	public void setHasIuLink(boolean hasIuLink) { this.hasIuLink = hasIuLink; }

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
