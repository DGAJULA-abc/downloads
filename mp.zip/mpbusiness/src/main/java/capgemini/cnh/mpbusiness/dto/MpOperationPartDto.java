/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IConfiguration;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;

/**
 * @author mamestoy
 *
 */
public class MpOperationPartDto extends Dto implements IConfiguration, Comparable<MpOperationPartDto> {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** Id. **/
	private Long id = null;

	/** father Id. **/
	private Long fatherId = null;

	/** operation series Id. **/
	private Long idOperationSeries = null;

	/** code part. **/
	private String codePart = null;
	/** Label part. **/
	private String partLabel = null;

	/** Note. **/
	private String note = null;

	/** quantity. **/
	private Double quantity = null;

	/** included in kit. */
	private boolean inKit = false;

	/** kit characterized as 'Preferred'. */
	private boolean kitPreferred = false;

	/** description (in translated language). */
	private String description = null;

	private List<MpOperationPartDto> replacedByList = new ArrayList<>();

	/** part replaced from which part. */
	private MpOperationPartDto replacedFrom = null;

	/** is a part that replaced (in substitution). */
	private boolean isAReplacement = false;

	/** part group. */
	private Integer partGroup = null;

	/** is a part duplicated (to delete). */
	private boolean isDuplicated = false;

	/** with data. **/
	//private List<ConfigurationDto> configs = new ArrayList<ConfigurationDto>();

	/**
	 * Part configuration applicability.
	 */
	private final IObjectConfiguration configuration;

	/** is Selected. */
	private boolean isSelected = false;

	/** Status part. **/
	private String status = "";

	/** is newPart. */
	private boolean newPart;

	private boolean original = true;

	/** part type S/M/C */
	private String type;

	/**
	 * Constructor.
	 */
	@SuppressWarnings("unused")
	private MpOperationPartDto() {
		super();
		this.configuration = ComplexConfigDto.valueOf(null);
	}

	/**
	 * Constructor.
	 * 
	 * @param configuration part configuration applicability
	 */
	public MpOperationPartDto(IObjectConfiguration configuration) {
		super();
		if (configuration == null)
		{
			this.configuration = ComplexConfigDto.valueOf(null);
		}
		else
		{
			this.configuration = configuration;
		}
	}

	/**
	 * @return the idOperationSeries
	 */
	public Long getIdOperationSeries() {
		return idOperationSeries;
	}

	/**
	 * @param idOperationSeries the idOperationSeries to set
	 */
	public void setIdOperationSeries(Long idOperationSeries) {
		this.idOperationSeries = idOperationSeries;
	}

	/**
	 * @return the codePart
	 */
	public String getCodePart() {
		return codePart;
	}

	/**
	 * @param codePart the codePart to set
	 */
	public void setCodePart(String codePart) {
		this.codePart = codePart;
	}

	/**
	 * @return the partLabel
	 */
	public String getPartLabel() {
		return partLabel;
	}

	/**
	 * @param partLabel the partLabel to set
	 */
	public void setPartLabel(String partLabel) {
		this.partLabel = partLabel;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the quantity
	 */
	public Double getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * convert to string.
	 * 
	 * @return converted dto.
	 */
	public String toString() {
		String toReturn = "";

		toReturn += " - ";
		if (idOperationSeries != null)
		{
			toReturn += "id ope Series " + idOperationSeries.toString();
		}
		toReturn += " - ";
		toReturn += "code part " + codePart;
		toReturn += " - ";
		toReturn += "part " + partLabel;
		toReturn += " - ";
		toReturn += "description " + description;
		toReturn += " - config " + this.configuration.toString();
		toReturn += " - qty:" + this.quantity != null ? this.quantity : "null";

		return toReturn;
	}

	/**
	 * @return the inKit
	 */
	public boolean isInKit() {
		return inKit;
	}

	/**
	 * @param inKit the inKit to set
	 */
	public void setInKit(boolean inKit) {
		this.inKit = inKit;
	}

	/**
	 * @return the kitPreferred
	 */
	public boolean isKitPreferred() {
		return kitPreferred;
	}

	/**
	 * @param kitPreferred the kitPreferred to set
	 */
	public void setKitPreferred(boolean kitPreferred) {
		this.kitPreferred = kitPreferred;
	}

	@Override
	public boolean isApplicable(ProductConfiguration productConfiguration) {
		return this.configuration.isApplicable(productConfiguration);
	}

	@Override
	public boolean hasConfiguration() {
		return this.configuration.hasConfiguration();
	}

	/**
	 * Getter pour isSelected.
	 *
	 * @return isSelected
	 */
	public boolean isSelected() {
		return isSelected;
	}

	/**
	 * Setter pour isSelected.
	 *
	 * @param isSelected isSelected à positionner.
	 */
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the newPart
	 */
	public boolean isNewPart() {
		return newPart;
	}

	/**
	 * @param newPart the newPart to set
	 */
	public void setNewPart(boolean newPart) {
		this.newPart = newPart;
	}

	/**
	 * Getter pour replacedByList.
	 *
	 * @return replacedByList
	 */
	public List<MpOperationPartDto> getReplacedByList() {
		return replacedByList;
	}

	/**
	 * Setter pour replacedByList.
	 *
	 * @param replacedByList replacedByList à positionner.
	 */
	public void setReplacedByList(List<MpOperationPartDto> replacedByList) {
		this.replacedByList = replacedByList;
	}

	/**
	 * Getter pour isAReplacement.
	 *
	 * @return isAReplacement
	 */
	public boolean isAReplacement() {
		return isAReplacement;
	}

	/**
	 * Setter pour isAReplacement.
	 *
	 * @param isAReplacement isAReplacement à positionner.
	 */
	public void setAReplacement(boolean isAReplacement) {
		this.isAReplacement = isAReplacement;
	}

	/**
	 * Getter pour group.
	 *
	 * @return group
	 */
	public Integer getPartGroup() {
		return partGroup;
	}

	/**
	 * Setter pour group.
	 *
	 * @param group group à positionner.
	 */
	public void setPartGroup(Integer partGroup) {
		this.partGroup = partGroup;
	}

	/**
	 * @return the isDuplicated
	 */
	public boolean isDuplicated() {
		return isDuplicated;
	}

	/**
	 * @param isDuplicated the isDuplicated to set
	 */
	public void setDuplicated(boolean isDuplicated) {
		this.isDuplicated = isDuplicated;
	}

	/**
	 * @return the replacedFrom
	 */
	public MpOperationPartDto getReplacedFrom() {
		return replacedFrom;
	}

	/**
	 * @param replacedFrom the replacedFrom to set
	 */
	public void setReplacedFrom(MpOperationPartDto replacedFrom) {
		this.replacedFrom = replacedFrom;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codePart == null) ? 0 : codePart.hashCode());
		return result;
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * MpOPerationPartDto object means equality of attribute PartCode
	 * 
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MpOperationPartDto other = (MpOperationPartDto) obj;
		if (!codePart.equals(other.codePart))
		{
			return false;
		}
		return true;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(MpOperationPartDto o) {
		return this.getId().compareTo(o.getId());
	}

	public boolean isOriginal() {
		return original;
	}

	public void setOriginal(boolean original) {
		this.original = original;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getFatherId() {
		return fatherId;
	}

	public void setFatherId(Long fatherId) {
		this.fatherId = fatherId;
	}

}
