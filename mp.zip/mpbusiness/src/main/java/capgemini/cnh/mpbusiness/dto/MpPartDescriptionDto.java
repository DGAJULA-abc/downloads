package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Part description DTO.
 * 
 * @author cblois
 */
public class MpPartDescriptionDto extends Dto {

	/**
	 * Unique serial identifier.
	 */
	private static final long serialVersionUID = -3662484241915877190L;

	/**
	 * Part number.
	 */
	String descPnCode;

	/**
	 * eTim database language identifier.
	 */
	String descLanguage;

	/**
	 * Part description.
	 */
	String description;

	/**
	 * Default constructor.
	 */
	public MpPartDescriptionDto() {
		this.descPnCode = null;
		this.descLanguage = null;
		this.description = null;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getSimpleName());
		builder.append(":");
		builder.append(" descPnCode ");
		if (this.descPnCode != null)
		{
			builder.append(this.descPnCode.toString());
		}
		else
		{
			builder.append("null");
		}
		builder.append(" descLanguage ");
		if (this.descLanguage != null)
		{
			builder.append(this.descLanguage.toString());
		}
		else
		{
			builder.append("null");
		}
		builder.append(" description ");
		if (this.description != null)
		{
			builder.append(this.description.toString());
		}
		else
		{
			builder.append("null");
		}
		return builder.toString();
	}

	/**
	 * @return the descPnCode
	 */
	public String getDescPnCode() {
		return descPnCode;
	}

	/**
	 * @param descPnCode the descPnCode to set
	 */
	public void setDescPnCode(String descPnCode) {
		this.descPnCode = descPnCode;
	}

	/**
	 * @return the descLanguage
	 */
	public String getDescLanguage() {
		return descLanguage;
	}

	/**
	 * @param descLanguage the descLanguage to set
	 */
	public void setDescLanguage(String descLanguage) {
		this.descLanguage = descLanguage;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
