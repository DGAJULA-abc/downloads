package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Part description DTO.
 * 
 * @author mmartel
 */
public class MpPartDetailDto extends Dto {

	/**
	 * Unique serial identifier.
	 */
	private static final long serialVersionUID = -3662484241915877190L;

	/**
	 * Part father.
	 */
	String pndPartNumber;

	/**
	 * Part status.
	 */
	String pndStatus;

	/**
	 * Part status.
	 */
	String pndLabelEn;

	/**
	 * Default constructor.
	 */
	public MpPartDetailDto() {
	}

	/**
	 * Getter pour pndPartNumber.
	 *
	 * @return pndPartNumber
	 */
	public String getPndPartNumber() {
		return pndPartNumber;
	}

	/**
	 * Setter pour pndPartNumber.
	 *
	 * @param pndPartNumber pndPartNumber à positionner.
	 */
	public void setPndPartNumber(String pndPartNumber) {
		this.pndPartNumber = pndPartNumber;
	}

	/**
	 * Getter pour pndStatus.
	 *
	 * @return pndStatus
	 */
	public String getPndStatus() {
		return pndStatus;
	}

	/**
	 * Setter pour pndStatus.
	 *
	 * @param pndStatus pndStatus à positionner.
	 */
	public void setPndStatus(String pndStatus) {
		this.pndStatus = pndStatus;
	}

	/**
	 * Getter pour pndLabelEn.
	 *
	 * @return pndLabelEn
	 */
	public String getPndLabelEn() {
		return pndLabelEn;
	}

	/**
	 * Setter pour pndLabelEn.
	 *
	 * @param pndLabelEn pndLabelEn à positionner.
	 */
	public void setPndLabelEn(String pndLabelEn) {
		this.pndLabelEn = pndLabelEn;
	}

	@Override
	public String toString() {
		return getPndPartNumber() + "-" + getPndStatus() + "-" + getPndLabelEn();
	}

}
