package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.List;

import capgemini.cnh.framework.dto.Dto;

/**
 * Part description DTO.
 * 
 * @author cblois
 */
public class MpPartNodeDto extends Dto {

	/**
	 * Unique serial identifier.
	 */
	private static final long serialVersionUID = -3662484241915877190L;

	/**
	 * Part father.
	 */
	String name;

	/**
	 * part child.
	 */
	int nodeId;

	/**
	 * part child.
	 */
	int fatherNodeId;

	/**
	 * Part quantity.
	 */
	Long quantity;

	/**
	 * Part type.
	 */
	String type;

	/**
	 * Part status.
	 */
	String status;

	/**
	 * Part label.
	 */
	String label;

	/**
	 * Part status.
	 */
	List<MpPartNodeDto> children = new ArrayList<>();

	/**
	 * Default constructor.
	 */
	public MpPartNodeDto() {
	}

	/**
	 * Default constructor.
	 */
	public MpPartNodeDto(String name, int nodeId, int fatherNodeId, Long quantity, String type, String status, String label) {
		this.name = name;
		this.nodeId = nodeId;
		this.fatherNodeId = fatherNodeId;
		this.quantity = quantity;
		this.type = type;
		this.status = status;
		this.label = label;
	}

	/**
	 * Getter pour name.
	 *
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Setter pour name.
	 *
	 * @param name name à positionner.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Getter pour nodeId.
	 *
	 * @return nodeId
	 */
	public int getNodeId() {
		return nodeId;
	}

	/**
	 * Setter pour nodeId.
	 *
	 * @param nodeId nodeId à positionner.
	 */
	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

	/**
	 * Getter pour fatherNodeId.
	 *
	 * @return fatherNodeId
	 */
	public int getFatherNodeId() {
		return fatherNodeId;
	}

	/**
	 * Setter pour fatherNodeId.
	 *
	 * @param fatherNodeId fatherNodeId à positionner.
	 */
	public void setFatherNodeId(int fatherNodeId) {
		this.fatherNodeId = fatherNodeId;
	}

	/**
	 * Getter pour quantity.
	 *
	 * @return quantity
	 */
	public Long getQuantity() {
		return quantity;
	}

	/**
	 * Setter pour quantity.
	 *
	 * @param quantity quantity à positionner.
	 */
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	/**
	 * Getter pour type.
	 *
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Setter pour type.
	 *
	 * @param type type à positionner.
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Getter pour status.
	 *
	 * @return status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Setter pour status.
	 *
	 * @param status status à positionner.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter pour child.
	 *
	 * @return child
	 */
	public List<MpPartNodeDto> getChildren() {
		return children;
	}

	/**
	 * Setter pour child.
	 *
	 * @param child child à positionner.
	 */
	public void setChildren(List<MpPartNodeDto> children) {
		this.children = children;
	}

	/**
	 * Getter pour label.
	 *
	 * @return label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * Setter pour label.
	 *
	 * @param label label à positionner.
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	@Override
	public String toString() {
		return getName() + " " + getNodeId() + " " + getFatherNodeId();
	}
}
