package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Part description DTO.
 * 
 * @author cblois
 */
public class MpPartSupersessionDto extends Dto {

	/**
	 * Unique serial identifier.
	 */
	private static final long serialVersionUID = -3662484241915877190L;

	/**
	 * Part father.
	 */
	String pnsFather;

	/**
	 * part child.
	 */
	String pnsChild;

	/**
	 * Part quantity.
	 */
	Long pnsQuantity;

	/**
	 * Part type.
	 */
	String pnsType;

	/**
	 * Part status.
	 */
	String pnsStatus;

	/**
	 * Part status.
	 */
	String pnsLabel;

	/**
	 * Default constructor.
	 */
	public MpPartSupersessionDto() {
	}

	/**
	 * Getter pour pnsFather.
	 *
	 * @return pnsFather
	 */
	public String getPnsFather() {
		return pnsFather;
	}

	/**
	 * Setter pour pnsFather.
	 *
	 * @param pnsFather pnsFather à positionner.
	 */
	public void setPnsFather(String pnsFather) {
		this.pnsFather = pnsFather;
	}

	/**
	 * Getter pour pnsChild.
	 *
	 * @return pnsChild
	 */
	public String getPnsChild() {
		return pnsChild;
	}

	/**
	 * Setter pour pnsChild.
	 *
	 * @param pnsChild pnsChild à positionner.
	 */
	public void setPnsChild(String pnsChild) {
		this.pnsChild = pnsChild;
	}

	/**
	 * Getter pour pnsQuantity.
	 *
	 * @return pnsQuantity
	 */
	public Long getPnsQuantity() {
		return pnsQuantity;
	}

	/**
	 * Setter pour pnsQuantity.
	 *
	 * @param pnsQuantity pnsQuantity à positionner.
	 */
	public void setPnsQuantity(Long pnsQuantity) {
		this.pnsQuantity = pnsQuantity;
	}

	/**
	 * Getter pour pnsType.
	 *
	 * @return pnsType
	 */
	public String getPnsType() {
		return pnsType;
	}

	/**
	 * Setter pour pnsType.
	 *
	 * @param pnsType pnsType à positionner.
	 */
	public void setPnsType(String pnsType) {
		this.pnsType = pnsType;
	}

	/**
	 * Getter pour pnsStatus.
	 *
	 * @return pnsStatus
	 */
	public String getPnsStatus() {
		return pnsStatus;
	}

	/**
	 * Setter pour pnsStatus.
	 *
	 * @param pnsStatus pnsStatus à positionner.
	 */
	public void setPnsStatus(String pnsStatus) {
		this.pnsStatus = pnsStatus;
	}

	/**
	 * Getter pour pnsLabel.
	 *
	 * @return pnsLabel
	 */
	public String getPnsLabel() {
		return pnsLabel;
	}

	/**
	 * Setter pour pnsLabel.
	 *
	 * @param pnsLabel pnsLabel à positionner.
	 */
	public void setPnsLabel(String pnsLabel) {
		this.pnsLabel = pnsLabel;
	}

	@Override
	public String toString() {
		return getPnsFather() + "-" + getPnsChild();
	}

}
