package capgemini.cnh.mpbusiness.dto;

import java.util.List;

import capgemini.cnh.framework.dto.Dto;

/**
 * 
 * @author iazkonob
 *
 */
public class MpPerfFreeTextDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The free text performance id in the DB.
	 */
	private Long freeTextPerfId = null;

	/**
	 * The free text performance name.
	 */
	private String freeTextPerfName = null;

	/**
	 * The operation series id linked to the Performance.
	 */
	private Long freeTextPerfOpeSerId = null;

	/**
	 * The free text performance label.
	 */
	private String freeTextPerfLabel = null;

	/**
	 * The free text performance label id in TABLE_TITLE.
	 */
	private Long freeTextPerfLabelId = null;

	/**
	 * attached operations.
	 */
	private List<MpOperationDto> operations = null;

	/**
	 * Get the freeText performance id.
	 * 
	 * @return The free text performance id
	 */
	public Long getFreeTextPerfId() {
		return freeTextPerfId;
	}

	/**
	 * Set The free text performance id.
	 * 
	 * @param freeTextPerfId The free text performance id
	 */
	public void setFreeTextPerfId(Long freeTextPerfId) {
		this.freeTextPerfId = freeTextPerfId;
	}

	/**
	 * Get The free text performance name.
	 * 
	 * @return The free text performance name
	 */
	public String getFreeTextPerfName() {
		return freeTextPerfName;
	}

	/**
	 * Set The free text performance name.
	 * 
	 * @param freeTextPerfName The free text performance name
	 */
	public void setFreeTextPerfName(String freeTextPerfName) {
		this.freeTextPerfName = freeTextPerfName;
	}

	/**
	 * Get The free text performance label.
	 * 
	 * @return The free text performance label
	 */
	public String getFreeTextPerfLabel() {
		return freeTextPerfLabel;
	}

	/**
	 * Set The free text performance label.
	 * 
	 * @param freeTextPerfLabel The free text performance label
	 */
	public void setFreeTextPerfLabel(String freeTextPerfLabel) {
		this.freeTextPerfLabel = freeTextPerfLabel;
	}

	/**
	 * Get The operation series id linked to the Performance.
	 * 
	 * @return The operation series id linked to the Performance
	 */
	public Long getFreeTextPerfOpeSerId() {
		return freeTextPerfOpeSerId;
	}

	/**
	 * Set The operation series id linked to the Performance.
	 * 
	 * @param freeTextPerfOpeSerId The operation series id linked to the Performance
	 */
	public void setFreeTextPerfOpeSerId(Long freeTextPerfOpeSerId) {
		this.freeTextPerfOpeSerId = freeTextPerfOpeSerId;
	}

	/**
	 * Get The free text performance label id in TABLE_TITLE.
	 * 
	 * @return The free text performance label id in TABLE_TITLE
	 */
	public Long getFreeTextPerfLabelId() {
		return freeTextPerfLabelId;
	}

	/**
	 * Set The free text performance label id in TABLE_TITLE.
	 * 
	 * @param freeTextPerfLabelId The free text performance label id in TABLE_TITLE
	 */
	public void setFreeTextPerfLabelId(Long freeTextPerfLabelId) {
		this.freeTextPerfLabelId = freeTextPerfLabelId;
	}

	/**
	 * Get the list of operations.
	 * 
	 * @return the operations
	 */
	public List<MpOperationDto> getOperations() {
		return operations;
	}

	/**
	 * Set the list of operations.
	 * 
	 * @param operations the operations to set
	 */
	public void setOperations(List<MpOperationDto> operations) {
		this.operations = operations;
	}
}
