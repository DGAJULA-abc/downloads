/**
 *
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.LanguageDto;
import capgemini.cnh.ice.dto.configuration.CCNode;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IConfiguration;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.configuration.IdNode;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;

/**
 * @author sdomecq
 *
 */
public class MpPlanDto extends Dto implements IConfiguration {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The plan applicable configuration.
	 */
	@JsonIgnore
	private IObjectConfiguration configuration;

	/** configuration as a string **/
	private String logic;

	/** Id. **/
	private Long id = null;

	/** id project. **/
	private Integer idProject = null;
	/** number project. **/
	private String projectNumber = null;
	/** id project. **/
	private Integer projectVersion = null;

	/** standard. **/
	private boolean standard = false;

	/** name. **/
	private String name = null;

	/** status. **/
	private Integer status = null;
	/** status. **/
	private String statusLabel = null;

	/** status change date. **/
	private Date modifDate = null;

	/** last modifier. **/
	private String lastModifier = null;

	/** condition. **/
	private MpConditionDto condition = null;

	/** performance. **/
	private String performance = null;

	/** performance. **/
	private String performanceId = "harm";

	/** Ext Id. **/
	private Long extId = null;

	/** with data. **/
	private String withAppli = null;

	/** with data. **/
	private String unitKey = null;

	/** Error management for Connected vehicles. */
	private String errorCase = "0";

	private boolean isOptimized = false;

	private MpUsageDto usageDtoList = null;

	/**
	 * Locked constructor.
	 */
	@SuppressWarnings("unused")
	public MpPlanDto() {
		super();
		this.configuration = null;
	}

	/**
	 * Default Constructor.
	 *
	 * @param configuration applicable configuration
	 */
	public MpPlanDto(IObjectConfiguration configuration) {
		super();
		this.configuration = configuration;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idProject
	 */
	public Integer getIdProject() {
		return idProject;
	}

	/**
	 * @param idProject the idProject to set
	 */
	public void setIdProject(Integer idProject) {
		this.idProject = idProject;
	}

	/**
	 * @return the standard
	 */
	public boolean getStandard() {
		return standard;
	}

	/**
	 * @param standard the standard to set
	 */
	public void setStandard(boolean standard) {
		this.standard = standard;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the statusLabel
	 */
	public String getStatusLabel() {
		return statusLabel;
	}

	/**
	 * @param statusLabel the statusLabel to set
	 */
	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	/**
	 * @return the modifDate
	 */
	public Date getModifDate() {
		return modifDate;
	}

	/**
	 * @param modifDate the modifDate to set
	 */
	public void setModifDate(Date modifDate) {
		this.modifDate = modifDate;
	}

	/**
	 * @return the lastModifier
	 */
	public String getLastModifier() {
		return lastModifier;
	}

	/**
	 * @param lastModifier the lastModifier to set
	 */
	public void setLastModifier(String lastModifier) {
		this.lastModifier = lastModifier;
	}

	/**
	 * @return the condition
	 */
	public MpConditionDto getCondition() {
		return condition;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(MpConditionDto condition) {
		this.condition = condition;
	}

	/**
	 * @return the performance
	 */
	public String getPerformance() {
		return performance;
	}

	/**
	 * @param performance the performance to set
	 */
	public void setPerformance(String performance) {
		this.performance = performance;
	}

	/**
	 * @return the performanceId
	 */
	public String getPerformanceId() {
		return performanceId;
	}

	/**
	 * @param performanceId the performanceId to set
	 */
	public void setPerformanceId(String performanceId) {
		this.performanceId = performanceId;
	}

	/**
	 * @return the withAppli
	 */
	public String getWithAppli() {
		return withAppli;
	}

	/**
	 * @param withAppli the withAppli to set
	 */
	public void setWithAppli(String withAppli) {
		this.withAppli = withAppli;
	}

	/**
	 * @return the projectNumber
	 */
	public String getProjectNumber() {
		return projectNumber;
	}

	/**
	 * @param projectNumber the projectNumber to set
	 */
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	/**
	 * @return the projectVersion
	 */
	public Integer getProjectVersion() {
		return projectVersion;
	}

	/**
	 * @param projectVersion the projectVersion to set
	 */
	public void setProjectVersion(Integer projectVersion) {
		this.projectVersion = projectVersion;
	}

	/**
	 * @return the extId
	 */
	public Long getExtId() {
		return extId;
	}

	/**
	 * @param extId the extId to set
	 */
	public void setExtId(Long extId) {
		this.extId = extId;
	}

	/**
	 * @param productConfiguration the product configuration
	 *
	 * @return a list of configurations attached to the plan
	 */
	public List<ConfigurationDto> getConfigs(ProductConfiguration productConfiguration) {
		List<ConfigurationDto> configList = new ArrayList<ConfigurationDto>();
		if (this.configuration == null)
		{
			//this.configuration = new ComplexConfigDto(this.logic);
		}
		for (Iterator<CCNode> it = this.configuration.getIterator(); it.hasNext();)
		{
			CCNode node = it.next();
			if (node instanceof IdNode)
			{
				configList.add(ComplexConfigDto.getConfiguration(productConfiguration, ((IdNode) node).getIdConfig(), null));
			}
		}
		return configList;
	}

	/**
	 * @param productConfiguration filter on the product configuration
	 * @param language output language
	 *
	 * @return a {@code String} representation of the attached configuration
	 */
	public String toConfigurationTitle(ProductConfiguration productConfiguration, LanguageDto language) {
		if (this.configuration == null)
		{
			//this.configuration = new ComplexConfigDto(this.logic);
		}
		return (this.configuration.toIuTitle(productConfiguration, language));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	/**
	 * Return true if this and given object are equals. Equality between two
	 * OperationSeriesDto object means equality of attribute aId
	 *
	 * @param obj
	 *            Object to test
	 * @return true or false.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MpPlanDto other = (MpPlanDto) obj;
		if (id == null)
		{
			if (other.id != null)
			{
				return false;
			}
		}
		else if (!name.equals(other.name) ||
				!status.equals(other.status) ||
				standard != other.standard ||
				(performance != null ? !performance.equals(other.performance) : other.performance != null))
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isApplicable(ProductConfiguration productConfiguration) {
		// -- safety rule not applicable if not initialized
		return (this.configuration != null && this.configuration.isApplicable(productConfiguration));
	}

	@Override
	public boolean hasConfiguration() {
		return (this.configuration != null && this.configuration.hasConfiguration());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append("id: ").append(this.id.toString());
		builder.append(",");
		builder.append("configuration: ").append(this.configuration.toString());
		builder.append("\n");
		return (builder.toString());
	}

	/**
	 * @return the unitKey
	 */
	public String getUnitKey() {
		return unitKey;
	}

	/**
	 * @param unitKey the unitKey to set
	 */
	public void setUnitKey(String unitKey) {
		this.unitKey = unitKey;
	}

	/**
	 *
	 * @return errorCase errorCase
	 */
	public String getErrorCase() {
		return errorCase;
	}

	/**
	 *
	 * @param errorCase errorCase
	 */
	public void setErrorCase(String errorCase) {
		this.errorCase = errorCase;
	}

	public String getLogic() {
		return logic;
	}

	public IObjectConfiguration getConfiguration() {
		return configuration;
	}

	public void setConfiguration() {
		if (this.configuration == null)
		{
			//this.configuration = new ComplexConfigDto(this.logic);
		}
	}

	public void setLogic(String logic) {
		this.logic = logic;
	}

	public boolean isOptimized() {
		return isOptimized;
	}

	public void setOptimized(boolean optimized) {
		isOptimized = optimized;
	}

	public MpUsageDto getUsageList() {
		return usageDtoList;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setUsageList(MpUsageDto usageDtoList) {
		this.usageDtoList = usageDtoList;
	}
}