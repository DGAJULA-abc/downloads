/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.configuration.ComplexConfigDto;
import capgemini.cnh.ice.dto.configuration.IConfiguration;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;

/**
 * @author mmartel
 *
 */
public class MpProjectDocumentDto extends Dto implements IConfiguration {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/** id document. **/
	private String mpDocumentId = null;

	/** id project. **/
	private Integer mpProjectId = null;

	/** project version. **/
	private Integer mpProjectVersion = null;

	/** project number. **/
	private String mpProjectNumber = null;

	/** iu id. **/
	private String mpIuId = null;

	/** iu version. **/
	private String mpIuVersion = null;

	/** doc type. **/
	private Integer docType = null;

	/** doc name. **/
	private String docName = null;

	/**
	 * The IU attached configuration.
	 */
	private final IObjectConfiguration configuration;

	/**
	 * Locked constructor.
	 */
	@SuppressWarnings("unused")
	private MpProjectDocumentDto() {
		super();
		this.configuration = ComplexConfigDto.valueOf(null);
	}

	/**
	 * Constructor.
	 * 
	 * @param configuration the IU attached configuration
	 */
	public MpProjectDocumentDto(IObjectConfiguration configuration) {
		super();
		if (configuration == null)
		{
			this.configuration = ComplexConfigDto.valueOf(null);
		}
		else
		{
			this.configuration = configuration;
		}
	}

	/**
	 * @return the mpDocumentId
	 */
	public String getMpDocumentId() {
		return mpDocumentId;
	}

	/**
	 * @param mpDocumentId the mpDocumentId to set
	 */
	public void setMpDocumentId(String mpDocumentId) {
		this.mpDocumentId = mpDocumentId;
	}

	/**
	 * @return the docType
	 */
	public Integer getDocType() {
		return docType;
	}

	/**
	 * @param docType the docType to set
	 */
	public void setDocType(Integer docType) {
		this.docType = docType;
	}

	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}

	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}

	/**
	 * @return the mpProjectId
	 */
	public Integer getMpProjectId() {
		return mpProjectId;
	}

	/**
	 * @param mpProjectId the mpProjectId to set
	 */
	public void setMpProjectId(Integer mpProjectId) {
		this.mpProjectId = mpProjectId;
	}

	/**
	 * @return the mpProjectVersion
	 */
	public Integer getMpProjectVersion() {
		return mpProjectVersion;
	}

	/**
	 * @param mpProjectVersion the mpProjectVersion to set
	 */
	public void setMpProjectVersion(Integer mpProjectVersion) {
		this.mpProjectVersion = mpProjectVersion;
	}

	/**
	 * @return the mpIu
	 */
	public String getMpIuId() {
		return mpIuId;
	}

	/**
	 * @param mpIuId the mpIuId to set
	 */
	public void setMpIuId(String mpIuId) {
		this.mpIuId = mpIuId;
	}

	/**
	 * @return the mpIuVersion
	 */
	public String getMpIuVersion() {
		return mpIuVersion;
	}

	/**
	 * @param mpIuVersion the mpIuVersion to set
	 */
	public void setMpIuVersion(String mpIuVersion) {
		this.mpIuVersion = mpIuVersion;
	}

	/**
	 * @return the mpProjectNumber
	 */
	public String getMpProjectNumber() {
		return mpProjectNumber;
	}

	/**
	 * @param mpProjectNumber the mpProjectNumber to set
	 */
	public void setMpProjectNumber(String mpProjectNumber) {
		this.mpProjectNumber = mpProjectNumber;
	}

	@Override
	public boolean isApplicable(ProductConfiguration productConfiguration) {
		return this.configuration.isApplicable(productConfiguration);
	}

	@Override
	public boolean hasConfiguration() {
		return this.configuration.hasConfiguration();
	}

}
