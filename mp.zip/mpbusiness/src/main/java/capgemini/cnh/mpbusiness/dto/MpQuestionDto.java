package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

public class MpQuestionDto extends Dto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9073328232225210867L;

	private String date;
	private String dateopened;
	private String externalPlanId;
	private String hasHour;
	private String hasKm;
	private String hasMonth;
	private String hour;
	private String hourInt;
	private String id;
	private String intervalcode;
	private String intervalcoupon;
	private String intervalid;
	private String intervalmodifiable;
	private String intervalorigin;
	private String intervalsavable;
	private String kmInt;
	private String month;
	private String monthInt;
	private String title;
	private String update;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDateopened() {
		return dateopened;
	}

	public void setDateopened(String dateopened) {
		this.dateopened = dateopened;
	}

	public String getExternalPlanId() {
		return externalPlanId;
	}

	public void setExternalPlanId(String externalPlanId) {
		this.externalPlanId = externalPlanId;
	}

	public String getHasHour() {
		return hasHour;
	}

	public void setHasHour(String hasHour) {
		this.hasHour = hasHour;
	}

	public String getHasKm() {
		return hasKm;
	}

	public void setHasKm(String hasKm) {
		this.hasKm = hasKm;
	}

	public String getHasMonth() {
		return hasMonth;
	}

	public void setHasMonth(String hasMonth) {
		this.hasMonth = hasMonth;
	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getHourInt() {
		return hourInt;
	}

	public void setHourInt(String hourInt) {
		this.hourInt = hourInt;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIntervalcode() {
		return intervalcode;
	}

	public void setIntervalcode(String intervalcode) {
		this.intervalcode = intervalcode;
	}

	public String getIntervalcoupon() {
		return intervalcoupon;
	}

	public void setIntervalcoupon(String intervalcoupon) {
		this.intervalcoupon = intervalcoupon;
	}

	public String getIntervalid() {
		return intervalid;
	}

	public void setIntervalid(String intervalid) {
		this.intervalid = intervalid;
	}

	public String getIntervalmodifiable() {
		return intervalmodifiable;
	}

	public void setIntervalmodifiable(String intervalmodifiable) {
		this.intervalmodifiable = intervalmodifiable;
	}

	public String getIntervalorigin() {
		return intervalorigin;
	}

	public void setIntervalorigin(String intervalorigin) {
		this.intervalorigin = intervalorigin;
	}

	public String getIntervalsavable() {
		return intervalsavable;
	}

	public void setIntervalsavable(String intervalsavable) {
		this.intervalsavable = intervalsavable;
	}

	public String getKmInt() {
		return kmInt;
	}

	public void setKmInt(String kmInt) {
		this.kmInt = kmInt;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getMonthInt() {
		return monthInt;
	}

	public void setMonthInt(String monthInt) {
		this.monthInt = monthInt;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUpdate() {
		return update;
	}

	public void setUpdate(String update) {
		this.update = update;
	}

}
