package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author jdespeau
 * 
 *         Dto class for MpSapSerialNumber17.
 */
public class MpSapSerialNumber17Dto extends Dto {

	/**
	 * Constructor.
	 */
	public MpSapSerialNumber17Dto() {
		super();
	}

	/**
	 * Java internal serial version id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * SAP vin
	 */
	private String sapVin = null;

	/**
	 * SAP vin 17
	 */
	private String sapVin17 = null;

	/**
	 * @return the sapVin
	 */
	public String getSapVin() {
		return sapVin;
	}

	/**
	 * @param sapVin the sapVin to set
	 */
	public void setSapVin(String sapVin) {
		this.sapVin = sapVin;
	}

	/**
	 * @return the sapVin17
	 */
	public String getSapVin17() {
		return sapVin17;
	}

	/**
	 * @param sapVin17 the sapVin17 to set
	 */
	public void setSapVin17(String sapVin17) {
		this.sapVin17 = sapVin17;
	}

}
