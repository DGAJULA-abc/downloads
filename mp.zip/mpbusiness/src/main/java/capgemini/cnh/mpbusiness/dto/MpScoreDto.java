package capgemini.cnh.mpbusiness.dto;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.util.Constants;

public class MpScoreDto extends Dto {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Delta form user value for the interval.
	 */
	private Map<MpType, Long> score;

	/**
	 * Multiple value of the interval.
	 */
	private Map<MpType, Long> multiple;

	/**
	 * Selected flag for each type of the interval.
	 */
	private Map<MpType, Boolean> selected;

	/**
	 * The interval.
	 */
	private MpIntervalDto interval;

	/**
	 * can Be Multiple.
	 */
	private boolean canBeMultiple;

	/**
	 * Interval last history.
	 */
	private Map<MpType, Long> history;

	/**
	 * Default constructor.
	 * 
	 * @param pInterval
	 *            the interval of the score
	 */
	public MpScoreDto(MpIntervalDto pInterval, String customer) {
		boolean multiple = true;
		this.selected = new HashMap<>();
		this.score = new HashMap<>();
		this.multiple = new HashMap<>();
		this.history = new HashMap<>();
		this.interval = pInterval;
		this.canBeMultiple = false;
		//this.multipleList = new ArrayList<MpScore>();
		for (MpType type : MpType.values())
		{
			this.selected.put(type, false);
			this.score.put(type, null);
			this.multiple.put(type, null);
			this.history.put(type, 0L);
			// Don't check multiples for AG&CE
			if (customer.equals(Constants.CUSTOMER_IVECO))
			{
				if (multiple == true
						&& (MaintenancePlanBusiness.getAt(this.interval, type) > 0L || (this.interval.getGroup() != null && this.interval.getGroup().compareTo(0L) > 0)))
				{
					multiple = false;
				}
			}
			else
			{
				multiple = false;
			}
		}
		if (multiple == true)
		{
			for (MpType type : MpType.values())
			{
				this.multiple.put(type, MaintenancePlanBusiness.getEvery(this.interval, type));
			}
			canBeMultiple = true;
		}

	}

	/**
	 * Copy constructor.
	 * 
	 * @param score
	 *            the mp score to copy
	 */
	public MpScoreDto(MpScoreDto score) {
		this.selected = new HashMap<>();
		this.score = new HashMap<>();
		this.multiple = new HashMap<>();
		this.history = new HashMap<>();
		this.interval = score.interval;
		this.canBeMultiple = score.canBeMultiple;
		//this.multipleList = new ArrayList<MpScore>();
		for (MpType type : MpType.values())
		{
			this.selected.put(type, score.getSelectedByType(type));
			this.score.put(type, score.getScoreByType(type));
			this.multiple.put(type, score.getMultipleByType(type));
			this.history.put(type, score.getHistory(type));

		}
	}

	public MpScoreDto() {
	}

	/**
	 * Set the score for a given interval type.
	 * 
	 * @param pScore
	 *            the score (near the user value)
	 * @param pSelected
	 *            the selected flag
	 * @param pType
	 *            type of interval
	 */
	public void setScoreByType(Long pScore, MpType pType, boolean pSelected) {
		//		try
		//		{
		selected.put(pType, pSelected);
		score.put(pType, pScore);
		//		}
		//		catch (IllegalArgumentException | UnsupportedOperationException | ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
	}

	/**
	 * Get the score for a given interval type.
	 * 
	 * @param pType
	 *            type of interval
	 * @return the score
	 */
	public Long getScoreByType(MpType pType) {
		Long s = 0L;
		//		try
		//		{
		s = this.score.get(pType);
		//		}
		//		catch (ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
		return s;
	}

	/**
	 * Get the selected flag for a given interval type.
	 * 
	 * @param pType
	 *            type of interval
	 * @return the selected flag
	 */
	public boolean getSelectedByType(MpType pType) {
		boolean s = false;
		//		try
		//		{
		s = this.selected.get(pType);
		//		}
		//		catch (ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
		return s;
	}

	/**
	 * Set the multiple value for a given interval type.
	 * 
	 * @param pMultiple
	 *            the _multiple (every value of the interval)
	 * @param pType
	 *            type of interval
	 */
	public void setMultipleByType(Long pMultiple, MpType pType) {
		//		try
		//		{
		this.multiple.put(pType, pMultiple);
		//		}
		//		catch (IllegalArgumentException | UnsupportedOperationException | ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
	}

	/**
	 * Get the multiple value for a given interval type.
	 * 
	 * @param pType type of interval
	 * @return the multiple value
	 */
	public Long getMultipleByType(MpType pType) {
		Long m = 0L;
		//		try
		//		{
		m = this.multiple.get(pType);
		if (m == null)
		{
			m = 0L;
		}
		//		}
		//		catch (ClassCastException | NullPointerException e)
		//		{
		//			logger.error(e.getMessage());
		//			e.printStackTrace();
		//		}
		return m;
	}

	/**
	 * @return the interval
	 */
	public MpIntervalDto getInterval() {
		return (this.interval);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.interval.getCode() != null ? this.interval.getCode().toString() : "null");
		builder.append(": ");

		for (MpType type : MpType.values())
		{
			builder.append(type.toString());
			builder.append("(");
			builder.append(this.score.get(type) != null ? this.score.get(type).toString() : "null");
			builder.append(", ");
			builder.append(this.selected.get(type) != null ? this.selected.get(type).toString() : "null");
			builder.append(", ");
			builder.append(this.multiple.get(type) != null ? this.multiple.get(type).toString() : "null");
			builder.append(", ");
			builder.append(this.history.get(type) != null ? this.history.get(type).toString() : "null");
			builder.append(") \n");
		}

		return builder.toString();
	}

	/**
	 * Test if this is multiple of pScore or pScore is multiple of this.
	 * 
	 * @param pScore the score containing the multiples values to compare
	 * @return true if intervals are multiples, false otherwise
	 */
	public boolean isMultiple(MpScoreDto pScore) {
		boolean multiple = true;
		boolean reversed = false;
		int v_base = -1;
		int v = 0;
		Long m1 = 0L;
		Long m2 = 0L;

		// -- one is not multiple of itself
		if (this.getInterval().getId().compareTo(pScore.getInterval().getId()) != 0)
		{
			for (MpType type : MpType.values())
			{
				m1 = this.getMultipleByType(type);
				m2 = pScore.getMultipleByType(type);
				if (m1 < m2 || reversed)
				{
					m1 = pScore.getMultipleByType(type);
					m2 = this.getMultipleByType(type);
					reversed = true;
				}
				if ((m1 <= 0L && m2 > 0L) || (m1 > 0L && m2 <= 0L))
				{ // -- one interval is not set cannot be multiple
					multiple = false;
					break;
				}
				else if (m2 > 0L && m1 > 0L)
				{ // -- both set
					if (m1 % m2 != 0)
					{ // -- not multiple
						multiple = false;
						break;
					}
					else
					{ // -- to be multiple all interval type must share the same divisor
						if (m1 < m2)
						{
							v = (int) (m2 / m1);
						}
						else
						{
							v = (int) (m1 / m2);
						}
						if (v_base < 0)
						{ // -- initialize at first loop
							v_base = v;
						}
						else if (v != v_base)
						{ // -- not the same divisor
							multiple = false;
							break;
						}
					}
				} // -- else both <= 0L (not set don't break multiple rule)
			}
		}
		else
		{
			multiple = false;
		}
		return (multiple);
		//return (this.interval.isMulitple(pScore.getInterval()));
	}

	/**
	 * @param pType type of interval
	 * @return true if interval type is valid, false otherwise
	 */
	public boolean isValid(MpType pType) {
		return validInterval(this.interval.getAfterValue(pType)) || validInterval(this.interval.getStartValue(pType));
	}

	/**
	 * Check if an interval value is valid for processing.
	 * 
	 * @param aInterval
	 *            an interval value
	 * 
	 * @return true if the interval value is valid, false otherwise
	 */
	private static boolean validInterval(Long aInterval) {
		boolean valid = false;
		if (aInterval != null && aInterval.compareTo(0L) > 0)
		{
			valid = true;
		}
		return valid;
	}

	/**
	 * @param pType the type
	 * @return the history
	 */
	public Long getHistory(MpType pType) {
		return this.history.get(pType);
	}

	/**
	 * @param pType the type
	 * @param pHistory the history
	 */
	public void setHistory(MpType pType, Long pHistory) {
		this.history.put(pType, pHistory);
	}

	/**
	 * @return the canBeMultiple
	 */
	public boolean isCanBeMultiple() {
		return canBeMultiple;
	}

	/**
	 * 
	 * @author cblois
	 *
	 */
	public class ScoreComparator implements Comparator<MpScoreDto> {

		/**
		 * Constructor.
		 */
		public ScoreComparator() {
		}

		/**
		 * used to compare to failure date.
		 * 
		 * @param repair1 a repair history 1
		 * @param repair2 a repair history 2
		 * @return the comparison result
		 */
		@Override
		public int compare(MpScoreDto score1, MpScoreDto score2) {
			// Date desc sort
			int resultat = 0;
			Long every1 = 0L;
			Long every2 = 0L;
			for (MpType type : MpType.values())
			{
				every1 = MaintenancePlanBusiness.getEvery(score1.getInterval(), type);
				every2 = MaintenancePlanBusiness.getEvery(score2.getInterval(), type);
				resultat = every1.compareTo(every2);
				if (every1 != 0 || every2 != 0)
				{
					break;
				}
			}
			return resultat;
		}
	}

	/**
	 * 
	 * @author cblois
	 *
	 */
	public class ScoreComparatorDesc implements Comparator<MpScoreDto> {

		/**
		 * Constructor.
		 */
		public ScoreComparatorDesc() {
		}

		/**
		 * used to compare to failure date.
		 * 
		 * @param repair1 a repair history 1
		 * @param repair2 a repair history 2
		 * @return the comparison result
		 */
		@Override
		public int compare(MpScoreDto score1, MpScoreDto score2) {
			// Date desc sort
			int resultat = 0;
			Long every1 = 0L;
			Long every2 = 0L;
			for (MpType type : MpType.values())
			{
				every1 = MaintenancePlanBusiness.getEvery(score1.getInterval(), type);
				every2 = MaintenancePlanBusiness.getEvery(score2.getInterval(), type);
				resultat = every2.compareTo(every1);
				if (every1 != 0 || every2 != 0)
				{
					break;
				}
			}
			return resultat;
		}
	}

}
