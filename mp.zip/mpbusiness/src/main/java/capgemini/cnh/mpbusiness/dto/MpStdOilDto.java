/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;
import capgemini.cnh.ice.dto.configuration.IConfiguration;
import capgemini.cnh.ice.dto.configuration.IObjectConfiguration;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;

/**
 * @author sdomecq
 *
 */
public class MpStdOilDto extends Dto implements IConfiguration {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The plan applicable configuration.
	 */
	private final IObjectConfiguration configuration;

	/**
	 * Standard Oil id.
	 */
	private Long oilStdId = null;

	/**
	 * Project id.
	 */
	private Integer projectId = null;

	/**
	 * Oil id.
	 */
	private Long oilId = null;

	/**
	 * Oil id.
	 */
	private Long oilItemId = null;

	/**
	 * Locked constructor.
	 */
	@SuppressWarnings("unused")
	private MpStdOilDto() {
		super();
		this.configuration = null;
	}

	/**
	 * Default Constructor.
	 * 
	 * @param configuration applicable configuration
	 */
	public MpStdOilDto(IObjectConfiguration configuration) {
		super();
		this.configuration = configuration;
	}

	/**
	 * @return the oilStdId
	 */
	public Long getOilStdId() {
		return oilStdId;
	}

	/**
	 * @param oilStdId the oilStdId to set
	 */
	public void setOilStdId(Long oilStdId) {
		this.oilStdId = oilStdId;
	}

	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the oilId
	 */
	public Long getOilId() {
		return oilId;
	}

	/**
	 * @param oilId the oilId to set
	 */
	public void setOilId(Long oilId) {
		this.oilId = oilId;
	}

	/**
	 * @return the oilItemId
	 */
	public Long getOilItemId() {
		return oilItemId;
	}

	/**
	 * @param oilItemId the oilItemId to set
	 */
	public void setOilItemId(Long oilItemId) {
		this.oilItemId = oilItemId;
	}

	@Override
	public boolean isApplicable(ProductConfiguration productConfiguration) {
		// -- safety rule not applicable if not initialized
		return (this.configuration != null && this.configuration.isApplicable(productConfiguration));
	}

	@Override
	public boolean hasConfiguration() {
		return (this.configuration != null && this.configuration.hasConfiguration());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("oil id: ").append(this.oilId.toString());
		builder.append(" project id: ").append(this.projectId.toString());
		builder.append(" configuration: ").append(this.configuration.toString());
		builder.append("\n");
		return (builder.toString());
	}
}
