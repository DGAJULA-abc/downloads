package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * Dto class for Commercial Tolerance.
 */
public class MpToleranceDto extends Dto {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * brand Ice Code
	 */
	private String brandIceCode;

	/**
	 * market Id
	 */
	private Long marketId;

	/**
	 * Scheduling type :
	 * - VARIABLE_SCHEDULING = 0
	 * - FIXED_SCHEDULING = 1
	 */
	private int schedulingType = 0;

	/**
	 * Tolerated delta for Km.
	 */
	private Long technicalKmMin = null;

	/**
	 * Tolerated delta for Km.
	 */
	private Long technicalKmMax = null;

	/**
	 * Tolerated delta for Hours.
	 */
	private Long technicalHourMin = null;

	/**
	 * Tolerated delta for Hours.
	 */
	private Long technicalHourMax = null;

	/**
	 * Tolerated delta for months.
	 */
	private Long technicalMonthMin = null;

	/**
	 * Tolerated delta for months.
	 */
	private Long technicalMonthMax = null;

	/**
	 * Tolerated far for Km.
	 */
	private Long commercialKmMin = null;

	/**
	 * Tolerated far for Km.
	 */
	private Long commercialKmMax = null;

	/**
	 * Tolerated far for Hours.
	 */
	private Long commercialHourMin = null;

	/**
	 * Tolerated far for Hours.
	 */
	private Long commercialHourMax = null;

	/**
	 * Tolerated far for months.
	 */
	private Long commercialMonthMin = null;

	/**
	 * Tolerated far for months.
	 */
	private Long commercialMonthMax = null;

	/**
	 * @return the schedulingType
	 */
	public int getSchedulingType() {
		return schedulingType;
	}

	/**
	 * @param schedulingType the schedulingType to set
	 */
	public void setSchedulingType(int schedulingType) {
		this.schedulingType = schedulingType;
	}

	/**
	 * @return the technicalKmMin
	 */
	public Long getTechnicalKmMin() {
		return technicalKmMin;
	}

	/**
	 * @param technicalKmMin the technicalKmMin to set
	 */
	public void setTechnicalKmMin(Long technicalKmMin) {
		this.technicalKmMin = technicalKmMin;
	}

	/**
	 * @return the technicalKmMax
	 */
	public Long getTechnicalKmMax() {
		return technicalKmMax;
	}

	/**
	 * @param technicalKmMax the technicalKmMax to set
	 */
	public void setTechnicalKmMax(Long technicalKmMax) {
		this.technicalKmMax = technicalKmMax;
	}

	/**
	 * @return the technicalHourMin
	 */
	public Long getTechnicalHourMin() {
		return technicalHourMin;
	}

	/**
	 * @param technicalHourMin the technicalHourMin to set
	 */
	public void setTechnicalHourMin(Long technicalHourMin) {
		this.technicalHourMin = technicalHourMin;
	}

	/**
	 * @return the technicalHourMax
	 */
	public Long getTechnicalHourMax() {
		return technicalHourMax;
	}

	/**
	 * @param technicalHourMax the technicalHourMax to set
	 */
	public void setTechnicalHourMax(Long technicalHourMax) {
		this.technicalHourMax = technicalHourMax;
	}

	/**
	 * @return the technicalMonthMin
	 */
	public Long getTechnicalMonthMin() {
		return technicalMonthMin;
	}

	/**
	 * @param technicalMonthMin the technicalMonthMin to set
	 */
	public void setTechnicalMonthMin(Long technicalMonthMin) {
		this.technicalMonthMin = technicalMonthMin;
	}

	/**
	 * @return the technicalMonthMax
	 */
	public Long getTechnicalMonthMax() {
		return technicalMonthMax;
	}

	/**
	 * @param technicalMonthMax the technicalMonthMax to set
	 */
	public void setTechnicalMonthMax(Long technicalMonthMax) {
		this.technicalMonthMax = technicalMonthMax;
	}

	/**
	 * @return the commercialKmMin
	 */
	public Long getCommercialKmMin() {
		return commercialKmMin;
	}

	/**
	 * @param commercialKmMin the commercialKmMin to set
	 */
	public void setCommercialKmMin(Long commercialKmMin) {
		this.commercialKmMin = commercialKmMin;
	}

	/**
	 * @return the commercialKmMax
	 */
	public Long getCommercialKmMax() {
		return commercialKmMax;
	}

	/**
	 * @param commercialKmMax the commercialKmMax to set
	 */
	public void setCommercialKmMax(Long commercialKmMax) {
		this.commercialKmMax = commercialKmMax;
	}

	/**
	 * @return the commercialHourMin
	 */
	public Long getCommercialHourMin() {
		return commercialHourMin;
	}

	/**
	 * @param commercialHourMin the commercialHourMin to set
	 */
	public void setCommercialHourMin(Long commercialHourMin) {
		this.commercialHourMin = commercialHourMin;
	}

	/**
	 * @return the commercialHourMax
	 */
	public Long getCommercialHourMax() {
		return commercialHourMax;
	}

	/**
	 * @param commercialHourMax the commercialHourMax to set
	 */
	public void setCommercialHourMax(Long commercialHourMax) {
		this.commercialHourMax = commercialHourMax;
	}

	/**
	 * @return the commercialMonthMin
	 */
	public Long getCommercialMonthMin() {
		return commercialMonthMin;
	}

	/**
	 * @param commercialMonthMin the commercialMonthMin to set
	 */
	public void setCommercialMonthMin(Long commercialMonthMin) {
		this.commercialMonthMin = commercialMonthMin;
	}

	/**
	 * @return the commercialMonthMax
	 */
	public Long getCommercialMonthMax() {
		return commercialMonthMax;
	}

	/**
	 * @param commercialMonthMax the commercialMonthMax to set
	 */
	public void setCommercialMonthMax(Long commercialMonthMax) {
		this.commercialMonthMax = commercialMonthMax;
	}

	/**
	 * @return the brandIceCode
	 */
	public String getBrandIceCode() {
		return brandIceCode;
	}

	/**
	 * @param brandIceCode the brandIceCode to set
	 */
	public void setBrandIceCode(String brandIceCode) {
		this.brandIceCode = brandIceCode;
	}

	/**
	 * @return the marketId
	 */
	public Long getMarketId() {
		return marketId;
	}

	/**
	 * @param marketId the marketId to set
	 */
	public void setMarketId(Long marketId) {
		this.marketId = marketId;
	}

}
