package capgemini.cnh.mpbusiness.dto;

/**
 * Type of interval.
 * 
 * @author dbabillo
 *
 */
public enum MpType {

	/**
	 * Mileage.
	 */
	MP_KM("km"),

	/**
	 * Working hours.
	 */
	MP_HOUR("hour"),

	/**
	 * Months since warranty start date.
	 */
	MP_MONTH("month");

	/**
	 * Type of interval.
	 */
	private String _type = null;

	/**
	 * Constructor by type.
	 * 
	 * @param aType
	 *            the type
	 */
	private MpType(String aType) {
		_type = aType;
	}

	@Override
	public String toString() {
		return _type;
	}

	/**
	 * Method used for change MpType order (used for AG display)
	 * 
	 * @return MpType tab
	 */
	public static MpType[] valuesForAG() {
		MpType[] values = new MpType[3];
		values[0] = MP_HOUR;
		values[1] = MP_MONTH;
		values[2] = MP_KM;
		return values;
	}
}