/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * 
 * @author jdespeau
 *
 */
public class MpUnitSeriesDto extends Dto {

	/**
	 * Serial version Id.
	 */
	private static final long serialVersionUID = 1L;

	private String appBra = null;

	private String appTyp = null;

	private String appPro = null;

	private String appSer = null;

	private String unitKey = null;

	private String unit = null;

	private Long toleranceDelta = null;

	private Long toleranceFar = null;

	/**
	 * @return the toleranceDelta
	 */
	public Long getToleranceDelta() {
		return toleranceDelta;
	}

	/**
	 * @param toleranceDelta the toleranceDelta to set
	 */
	public void setToleranceDelta(Long toleranceDelta) {
		this.toleranceDelta = toleranceDelta;
	}

	/**
	 * @return the toleranceFar
	 */
	public Long getToleranceFar() {
		return toleranceFar;
	}

	/**
	 * @param toleranceFar the toleranceFar to set
	 */
	public void setToleranceFar(Long toleranceFar) {
		this.toleranceFar = toleranceFar;
	}

	/**
	 * @return the appBra
	 */
	public String getAppBra() {
		return appBra;
	}

	/**
	 * @param appBra the appBra to set
	 */
	public void setAppBra(String appBra) {
		this.appBra = appBra;
	}

	/**
	 * @return the appTyp
	 */
	public String getAppTyp() {
		return appTyp;
	}

	/**
	 * @param appTyp the appTyp to set
	 */
	public void setAppTyp(String appTyp) {
		this.appTyp = appTyp;
	}

	/**
	 * @return the appPro
	 */
	public String getAppPro() {
		return appPro;
	}

	/**
	 * @param appPro the appPro to set
	 */
	public void setAppPro(String appPro) {
		this.appPro = appPro;
	}

	/**
	 * @return the appSer
	 */
	public String getAppSer() {
		return appSer;
	}

	/**
	 * @param appSer the appSer to set
	 */
	public void setAppSer(String appSer) {
		this.appSer = appSer;
	}

	/**
	 * @return the unitKey
	 */
	public String getUnitKey() {
		return unitKey;
	}

	/**
	 * @param unitKey the unitKey to set
	 */
	public void setUnitKey(String unitKey) {
		this.unitKey = unitKey;
	}

	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

}
