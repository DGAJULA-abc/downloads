/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author sdomecq
 *
 */
public final class MpUsageDto extends Dto implements Comparable<MpUsageDto> {

	/**
	 * Generated serial identifier.
	 */
	private static final long serialVersionUID = 6748698991908562431L;

	/**
	 * Default id value if no Usage has been defined for the plan.
	 */
	public static final int DEFAULT_VALUE_ID = -1;

	/** Id. **/
	private int valueId;
	/** title. **/
	private String valueTitle = null;
	/** title Id. **/
	private Long valueTitleId = null;

	/** Id. **/
	private Long itemId = null;
	/** title. **/
	private String itemTitle = null;
	/** title Id. **/
	private Long itemTitleId = null;

	/** Max Hour. **/
	private Long maxHour;
	/** Max KM. **/
	private Long maxKm;
	
	/** Plan Ext Id. **/
	private Long planExtId = null;

	/**
	 * Locked Constructor.
	 */
	public MpUsageDto() {
		super();
		this.valueId = 0;
		this.itemTitle = null;
	}

	/**
	 * Default constructor.
	 * 
	 * @param valueId Usage identifier
	 * @param itemTitle Usage title
	 */
	private MpUsageDto(int valueId, String itemTitle) {
		super();
		this.valueId = valueId;
		this.itemTitle = itemTitle;
	}

	/**
	 * 
	 * @param valueId
	 * @param valueTitle
	 * @param itemTitle
	 */
	public MpUsageDto(int valueId, String valueTitle, String itemTitle) {
		super();
		this.valueId = valueId;
		this.valueTitle = valueTitle;
		this.itemTitle = itemTitle;
	}
	
	/**
	 * Fill the MpUsageDto with the plan External id
	 * @param valueId
	 * @param valueTitle
	 * @param planExtId
	 */
	public MpUsageDto(int valueId, String valueTitle, long planExtId) {
		super();
		this.valueId = valueId;
		this.valueTitle = valueTitle;
		this.planExtId = planExtId;
	}

	/**
	 * Factory method for MpUsageDto.
	 * 
	 * @param valueId Usage identifier
	 * @param itemTitle Usage title
	 * 
	 * @return a MpUsageDto instance
	 */
	public static MpUsageDto valueOf(Integer valueId, String itemTitle) {
		int v = DEFAULT_VALUE_ID; // -- default value on null
		if (valueId != null)
		{
			v = valueId.intValue();
		}
		if (itemTitle == null)
		{
			itemTitle = ""; // -- default title on null
		}
		return (new MpUsageDto(v, itemTitle));
	}

	/**
	 * @return the valueId
	 */
	public int getValueId() {
		return valueId;
	}

	/**
	 * @param valueId the valueId to set
	 */
	public void setValueId(int valueId) {
		this.valueId = valueId;
	}

	/**
	 * @return the valueTitle
	 */
	public String getValueTitle() {
		return valueTitle;
	}

	/**
	 * @param valueTitle the valueTitle to set
	 */
	public void setValueTitle(String valueTitle) {
		this.valueTitle = valueTitle;
	}

	/**
	 * @return the valueTitleId
	 */
	public Long getValueTitleId() {
		return valueTitleId;
	}

	/**
	 * @param valueTitleId the valueTitleId to set
	 */
	public void setValueTitleId(Long valueTitleId) {
		this.valueTitleId = valueTitleId;
	}

	/**
	 * @return the itemId
	 */
	public Long getItemId() {
		return itemId;
	}

	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	/**
	 * @return the itemTitle
	 */
	public String getItemTitle() {
		return itemTitle;
	}

	/**
	 * @param itemTitle the itemTitle to set
	 */
	public void setItemTitle(String itemTitle) {
		this.itemTitle = itemTitle;
	}

	/**
	 * @return the itemTitleId
	 */
	public Long getItemTitleId() {
		return itemTitleId;
	}

	/**
	 * @param itemTitleId the itemTitleId to set
	 */
	public void setItemTitleId(Long itemTitleId) {
		this.itemTitleId = itemTitleId;
	}

	@Override
	public int compareTo(MpUsageDto o) {
		int comparedValue = -1;
		if (this.itemTitle != null)
		{
			comparedValue = this.itemTitle.compareTo(o.getItemTitle());
		}
		return comparedValue;
	}

	/**
	 * @param maxHour
	 */
	public void setMaxHour(Long maxHour) {
		this.maxHour = maxHour;
	}

	/**
	 * @param maxKm
	 */
	public void setMaxKm(Long maxKm) {
		this.maxKm = maxKm;
	}

	/**
	 * @return maxHour
	 */
	public Long getMaxHour() {
		return maxHour;
	}

	/**
	 * @return maxKm
	 */
	public Long getMaxKm() {
		return maxKm;
	}
	
	/**
	 * @return The plan Ext id
	 */
	public Long getPlanExtId() {
		return planExtId;
	}
	
	/**
	 * @param planExtId The plan Ext id
	 */
	public void setPlanExtId(Long planExtId) {
		this.planExtId = planExtId;
	}
}
