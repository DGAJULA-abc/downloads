/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author bmilcend
 *
 */
public final class MpVehicleAverageDto extends Dto {

	/**
	 * Generated serial identifier.
	 */
	private static final long serialVersionUID = 6748698991908562431L;

	/** vin. **/
	private String vin = null;
	/**
	 * Current vehicle values.
	 */
	private Map<MpType, Long> currentValue = new HashMap<MpType, Long>();
	/**
	 * Average vehicle values.
	 */
	private Map<MpType, Double> averageValue = new HashMap<MpType, Double>();

	/**
	 * export date.
	 */
	private Date exportDate;

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the currentValue
	 */
	public Map<MpType, Long> getCurrentValue() {
		return currentValue;
	}

	/**
	 * @param currentValue the currentValue to set
	 */
	public void setCurrentValue(Map<MpType, Long> currentValue) {
		this.currentValue = currentValue;
	}

	/**
	 * @return the averageValue
	 */
	public Map<MpType, Double> getAverageValue() {
		return averageValue;
	}

	/**
	 * @param averageValue the averageValue to set
	 */
	public void setAverageValue(Map<MpType, Double> averageValue) {
		this.averageValue = averageValue;
	}

	/**
	 * @return the exportDate
	 */
	public Date getExportDate() {
		return exportDate;
	}

	/**
	 * @param exportDate the exportDate to set
	 */
	public void setExportDate(Date exportDate) {
		this.exportDate = exportDate;
	}

	public void setCurrentValue(MpType mpKm, Long pValue) {
		try
		{
			this.currentValue.put(mpKm, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Long getCurrentValue(MpType pType) {
		Long value = null;
		try
		{
			value = this.currentValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

	public void setAverageValue(MpType mpKm, Double pValue) {
		try
		{
			this.averageValue.put(mpKm, pValue);
		}
		catch (ClassCastException | NullPointerException | UnsupportedOperationException | IllegalArgumentException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Generic getter for the value.
	 * 
	 * @param pType the type
	 * @return the value
	 */
	public Double getAverageValue(MpType pType) {
		Double value = null;
		try
		{
			value = this.averageValue.get(pType);
		}
		catch (ClassCastException | NullPointerException e)
		{
			e.printStackTrace();
		}
		return value;
	}

}
