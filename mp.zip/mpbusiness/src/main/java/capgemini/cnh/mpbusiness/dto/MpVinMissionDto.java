/**
 * 
 */
package capgemini.cnh.mpbusiness.dto;

import capgemini.cnh.framework.dto.Dto;

/**
 * @author mamestoy
 *
 */
public final class MpVinMissionDto extends Dto {

	/**
	 * Generated serial identifier.
	 */
	private static final long serialVersionUID = 6748698991908562431L;

	/** Code VIN. **/
	private String vinCode = null;
	/** Mission Id. **/
	private Long valueMissionId = null;

	/**
	 * Locked Constructor.
	 */
	public MpVinMissionDto() {
		super();
	}

	/**
	 * @return the vinCode
	 */
	public String getVinCode() {
		return vinCode;
	}

	/**
	 * @param vinCode : the vin code to set
	 */
	public void setVinCode(String vinCode) {
		this.vinCode = vinCode;
	}

	/**
	 * @return the valueMissionId
	 */
	public Long getValueMissionId() {
		return valueMissionId;
	}

	/**
	 * @param valueMissionId : the mission Id to set
	 */
	public void setValueMissionId(Long valueMissionId) {
		this.valueMissionId = valueMissionId;
	}

	/**
	 * @return the descLanguage
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
