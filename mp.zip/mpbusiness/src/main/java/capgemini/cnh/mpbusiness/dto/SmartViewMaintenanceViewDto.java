/**
 *
 */
package capgemini.cnh.mpbusiness.dto;

import java.util.List;

/**
 *
 * @author lestrabo
 *         Class is duplicated from etim because it need to be call from the smart view api
 *         Refacto has to be done to have one class used for both applications
 */
public class SmartViewMaintenanceViewDto {

	private Long currentMileage;

	private Long currentHour;

	private String proposalDate;

	private Long proposalDateMilliSec;

	private Long daysInOverdue;

	private List<MpNextStopViewDto> nextMaintenanceList;

	private Long planId;

	private String unitKey;

	private String ucrStatusMsg;

	private Long ucrStatus;

	private MpContractTypeMessageDto contractTypeMessage;
	
	private boolean isOptimized = false;

	/**
	 * attribute.
	 */
	private String lastCommunicationDate;

	private List<MpUsageDto> applicableMissionList;

	/**
	 * True if the vehicle need to be alerted, false if the alerts need to be swsitched off.
	 */
	private boolean mpAlertActive = false;

	/**
	 * Getter pour currentMileage.
	 *
	 * @return currentMileage
	 */
	public Long getCurrentMileage() {
		return currentMileage;
	}

	/**
	 * Setter pour currentMileage.
	 *
	 * @param currentMileage currentMileage à positionner.
	 */
	public void setCurrentMileage(Long currentMileage) {
		this.currentMileage = currentMileage;
	}

	/**
	 * Getter pour currentHour.
	 *
	 * @return currentHour
	 */
	public Long getCurrentHour() {
		return currentHour;
	}

	/**
	 * Setter pour currentHour.
	 *
	 * @param currentHour currentHour à positionner.
	 */
	public void setCurrentHour(Long currentHour) {
		this.currentHour = currentHour;
	}

	/**
	 * Getter pour proposalDate.
	 *
	 * @return proposalDate
	 */
	public String getProposalDate() {
		return proposalDate;
	}

	/**
	 * Setter pour proposalDate.
	 *
	 * @param proposalDate proposalDate à positionner.
	 */
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}

	/**
	 * Getter pour nextMaintenanceList.
	 *
	 * @return nextMaintenanceList
	 */
	public List<MpNextStopViewDto> getNextMaintenanceList() {
		return nextMaintenanceList;
	}

	/**
	 * Setter pour nextMaintenanceList.
	 *
	 * @param nextMaintenanceList nextMaintenanceList à positionner.
	 */
	public void setNextMaintenanceList(List<MpNextStopViewDto> nextMaintenanceList) {
		this.nextMaintenanceList = nextMaintenanceList;
	}

	/**
	 * Getter pour proposalDateMilliSec.
	 *
	 * @return proposalDateMilliSec
	 */
	public Long getProposalDateMilliSec() {
		return proposalDateMilliSec;
	}

	/**
	 * Setter pour proposalDateMilliSec.
	 *
	 * @param proposalDateMilliSec proposalDateMilliSec à positionner.
	 */
	public void setProposalDateMilliSec(Long proposalDateMilliSec) {
		this.proposalDateMilliSec = proposalDateMilliSec;
	}

	/**
	 * @return the planId
	 */
	public Long getPlanId() {
		return planId;
	}

	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	/**
	 * @return the unitKey
	 */
	public String getUnitKey() {
		return unitKey;
	}

	/**
	 * @param unitKey the unitKey to set
	 */
	public void setUnitKey(String unitKey) {
		this.unitKey = unitKey;
	}

	/**
	 * @return the ucrStatusMsg
	 */
	public String getUcrStatusMsg() {
		return ucrStatusMsg;
	}

	/**
	 * @param ucrStatusMsg the ucrStatusMsg to set
	 */
	public void setUcrStatusMsg(String ucrStatusMsg) {
		this.ucrStatusMsg = ucrStatusMsg;
	}

	/**
	 *
	 * @return
	 */
	public Long getDaysInOverdue() {
		return daysInOverdue;
	}

	/**
	 *
	 * @param daysInOverdue
	 */
	public void setDaysInOverdue(Long daysInOverdue) {
		this.daysInOverdue = daysInOverdue;
	}

	/**
	 * @return the contractTypeMessage
	 */
	public MpContractTypeMessageDto getContractTypeMessage() {
		return contractTypeMessage;
	}

	/**
	 * @param contractTypeMessage the contractTypeMessage to set
	 */
	public void setContractTypeMessage(MpContractTypeMessageDto contractTypeMessage) {
		this.contractTypeMessage = contractTypeMessage;
	}

	/**
	 * @return the ucrStatus
	 */
	public Long getUcrStatus() {
		return ucrStatus;
	}

	/**
	 * @param ucrStatus the ucrStatus to set
	 */
	public void setUcrStatus(Long ucrStatus) {
		this.ucrStatus = ucrStatus;
	}

	/**
	 * Get Last Communication Date.
	 *
	 * @return
	 */
	public String getLastCommunicationDate() {
		return lastCommunicationDate;
	}

	/**
	 * Put Last communication Date.
	 *
	 * @param lastCommunicationDate
	 */
	public void setLastCommunicationDate(String lastCommunicationDate) {
		this.lastCommunicationDate = lastCommunicationDate;
	}

	public boolean isMpAlertActive() {
		return mpAlertActive;
	}

	public void setMpAlertActive(boolean mpAlertActive) {
		this.mpAlertActive = mpAlertActive;
	}

	/**
	 * @return the applicableMissionList
	 */
	public List<MpUsageDto> getApplicableMissionList() {
		return applicableMissionList;
	}

	/**
	 * @param applicableMissionList the applicableMissionList to set
	 */
	public void setApplicableMissionList(List<MpUsageDto> applicableMissionList) {
		this.applicableMissionList = applicableMissionList;
	}
	
	public boolean isOptimized() {
		return isOptimized;
	}
	
	public void setOptimized(boolean optimized) {
		isOptimized = optimized;
	}
}