package capgemini.cnh.mpbusiness.util;

public enum ConnectedTypeEnum {

	/**
	 * Enum HEAVY_FLEX_CONTRACT.
	 */
	HEAVY_FLEX_CONTRACT("HEAVY_FLEX_CONTRACT", "03"),

	/**
	 * Enum LIGHT_TARGA_CONNECTED.
	 */
	LIGHT_TARGA_CONNECTED("LIGHT_TARGA_CONNECTED", "10");

	/** Key for an Enum. */
	private String key;

	/** Value for an Enum. */
	private String value;

	ConnectedTypeEnum(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public static String getEnumValueByKey(String key) {
		for (ConnectedTypeEnum e : ConnectedTypeEnum.values())
		{
			if (e.key.equals(key)) return e.value;
		}
		return "";
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

}
