package capgemini.cnh.mpbusiness.util;

public class Constants {

	/**
	 * Constructor.
	 */
	public Constants() {
	}

	/** customer AGCE. **/
	public static final String CUSTOMER_AGCE = "AGCE";
	/** customer CV. **/
	public static final String CUSTOMER_CV = "CV";
	/** customer CNH. **/
	public static final String CUSTOMER_CNH = "CNH";
	/** customer IVECO. **/
	public static final String CUSTOMER_IVECO = "IVECO";

	/** table title key : or. */
	public static final String MP_ID_OR = "MP_ID_OR";
	/** table title key : months. */
	public static final String MP_ID_MONTHS = "MP_ID_MONTHS";
	/** table title key : hours. */
	public static final String MP_ID_HOURS = "MP_ID_HOURS";
	/** table title key : at. */
	public static final String MP_ID_AT = "MP_ID_AT";
	/** table title key : and then. */
	public static final String MP_ID_AND_THEN = "MP_ID_AND_THEN";
	/** table title key : every. */
	public static final String MP_ID_EVERY = "MP_ID_EVERY";
	/** table title key : bales. */
	public static final String MP_ID_BALES = "MP_ID_BALES";

	/** International English language variable. */
	public static final String ENGLISH = "EN";

	/** INTERACTIVE_CONTRACT. */
	public static final String INTERACTIVE_CONTRACT = "01";

	/** PAY_PER_USE_CONTRACT. */
	public static final String PAY_PER_USE_CONTRACT = "02";

	/** STNADARD_CONTRACT. */
	public static final String STANDARD_CONTRACT = "M";

	/** Procare warranty type for CNH. */
	public static final String WARRANTY_TYPE_CNH_PROCARE = "M";

	/** Standard warranty type for CNH. */
	public static final String WARRANTY_TYPE_CNH_STANDARD = "0";

	/** List of warranty types for CNH. */
	public static final String[] WARRANTY_TYPES_CNH = new String[] { WARRANTY_TYPE_CNH_STANDARD, WARRANTY_TYPE_CNH_PROCARE };
	/** List of warranty types for IVECO. */
	public static final String[] WARRANTY_TYPES_IVECO = new String[] { STANDARD_CONTRACT };

	/** Type Of Contract Message KEY. */
	public static final int MESSAGE_KEY_INTERACTIVE = 1;
	public static final int MESSAGE_KEY_PAY_PER_USE = 2;
	public static final int MESSAGE_KEY_FLEXIBLE = 3;
	public static final int MESSAGE_KEY_STANDARD = 4;// M
	public static final int MESSAGE_KEY_WARRANTY_CNH_PROCARE = 400;// M or 0 ProCare
	public static final int MESSAGE_KEY_WARRANTY_CNH_STANDARD = 401;// M or 0 Standard
	public static final int MESSAGE_KEY_EXPIRED = 5;
	public static final int MESSAGE_KEY_NO_CONTRACT = 6;
	public static final int MESSAGE_KEY_CNH_PROCARE = 100;
	public static final int MESSAGE_KEY_CNH_STANDARD = 101;

	/** Coupon tolerance. */
	public static final String COUPON_TOL = "M1";
	/** Coupon tolerance. */
	public static final String COUPON_TOL_HARM = "N1";

	/** Coupon Fuel Filter. */
	public static final String COUPON_FF = "FF";

	/** Next stop value set if current value is missing. */
	public static final Long DEFAULT_VALUE_NEXT_STOP = -1L;

	/** LOG_TYPE weekly algorithm (calculate next stop). */
	public static final String LOG_TYPE_WEEKLY_ALGO = "WEEKLY_ALGO";
	/** LOG_TYPE WAR_DATE_MISSING (warranty date is missing, it is needed to recalculate next date for month). */
	public static final String LOG_TYPE_WAR_DATE_MISSING = "WAR_DATE_MISSING";
	/** LOG_TYPE NO_PLAN_APP (no more plan applicable for VIN without contract). */
	public static final String LOG_TYPE_NO_PLAN_APP = "NO_PLAN_APP";
	/** LOG_TYPE No dealer. */
	public static final String LOG_TYPE_NO_DEALER = "NO_DEALER";
	/** LOG_TYPE SYSTEM EROOR */
	public static final String LOG_TYPE_SYSTEM_ERROR = "SYSTEM_ERROR";

	/** MP PART STATUS UNDEFINED. */
	public static final String MP_PART_STATUS_UNDEFINED = "U";
	/** MP PART STATUS WARNING. */
	public static final String MP_PART_STATUS_WARNING = "W";
	/** MP PART STATUS ERROR. */
	public static final String MP_PART_STATUS_ERROR = "E";
	/** MP PART STATUS SUCCESS. */
	public static final String MP_PART_STATUS_SUCCESS = "S";

	/** MP UCR_GET_NEXT_COUPONS_ERROR */
	public static final String UCR_GET_NEXT_COUPONS_ERROR = "UCR_GET_NEXT_COUPONS_ERROR";

	/** MP JOBCARD_GET_WORKSHOP_ENABLED */
	public static final String JOBCARD_GET_WORKSHOP_ENABLED = "JOBCARD_GET_WORKSHOP_ENABLED";

	/** MP UCR_SENDING_HISTORY_RECORDS_ERROR */
	public static final String UCR_SENDING_HISTORY_RECORDS_ERROR = "UCR_SENDING_HISTORY_RECORDS_ERROR";

	/** MP AGCE FAILURE CODE SUFFIX. */
	public static final String MP_AGCE_FAILURE_CODE_SUFFIX = "001";

	/** MP AGCE FAILURE CODE PREFIX. */
	public static final String MP_IVECO_FAILURE_CODE_PREFIX = "000";

	/** MP AGCE FAILURE CODE SUFFIX. */
	public static final String MP_IVECO_FAILURE_CODE_SUFFIX = "0MM1";

	/** no child value in MP_PART_SUPERSESSION. */
	public static final String MP_PART_NO_CHILD = "NO_CHILD";

	/** X status : part not yet processed. */
	public static final String MP_PART_STATUS_X = "X";
	/** LOG_CSPS_CHECK csps check. */
	public static final String LOG_CSPS_CHECK = "CSPS_CHECK";

	/**
	 * Interval status NOT_RECOMMENDED.
	 */
	public static final String NOT_RECOMMENDED = "A";
	/**
	 * Interval status COMING_SOON.
	 */
	public static final String COMING_SOON = "S";
	/**
	 * Interval status ON_TIME.
	 */
	public static final String ON_TIME = "T";
	/**
	 * Interval status OVERDUE.
	 */
	public static final String OVERDUE = "O";
	/**
	 * Interval status HIGH_OVERDUE.
	 */
	public static final String HIGH_OVERDUE = "H";

	/**
	 * ACTUAL: Coupon selected but not recommended.
	 */
	public static final String A_ACTUAL = "A";
	/**
	 * RECOMMENDED: Coupon not selected but recommended.
	 */
	public static final String R_RECOMMENDED = "R";
	/**
	 * RECOMMENDED_SELECTED: Coupon selected and recommended.
	 */
	public static final String B_RECOMMENDED_SELECTED = "B";

	/** message High overdue of:. */
	public static final String MESSAGE_HIGH_OVERDUE_OF = "mp.label.high.overdue.of";
	/** message Overdue of:. */
	public static final String MESSAGE_OVERDUE_OF = "interactive.mp.interval.overdue";
	/** message Overdue. */
	public static final String MESSAGE_OVERDUE = "mp.label.overdue";
	/** message Overdue. */
	public static final String MESSAGE_HIGH_OVERDUE = "mp.label.high.overdue";
	/** message Next stop forecast. */
	public static final String MESSAGE_NEXT_STOP_FORECAST = "label.maintenance.next.stop.forecast";
	/** Error type for vehicles with contract but SAP Broker failed. */
	public static final String IMP_ERROR_TYPE_SAP_BROKER_KO = "1";
	/** Error type for vehicles with plan applicability/configurations issue. */
	public static final String IMP_ERROR_TYPE_CONFIG_KO = "2";
	/** Error type for vehicles with Plans applicable but not for specific mission/performance type. */
	public static final String IMP_ERROR_TYPE_CRITERIA_KO = "3";
	/** Error type for vehicles with contract Locked. */
	public static final String IMP_ERROR_TYPE_LOCKED = "6";
	/** Error type for vehicles that have a mission in the contract not applicable to them. */
	public static final String IMP_ERROR_TYPE_MISSION_KO = "7";
	/** Flag for variable scheduling (new algo for CE) **/
	public static final int VARIABLE_SCHEDULING = 0;
	/** Flag for fixed scheduling (new algo for CE) **/
	public static final int FIXED_SCHEDULING = 1;
}
