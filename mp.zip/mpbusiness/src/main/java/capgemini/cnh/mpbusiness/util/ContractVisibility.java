package capgemini.cnh.mpbusiness.util;

import capgemini.cnh.mpbusiness.dto.MpContractDto;

/**
 * Visibility classique (non flexible) : hasComponentFlexible=false, hasProposalDateAndAlert=false
 * Visibility flexible : hasComponentFlexible=true, hasProposalDateAndAlert=true
 * Visibility (targa) : hasComponentFlexible=false, hasProposalDateAndAlert=true
 * 
 * @author adm-fr-cnh
 *
 */
public class ContractVisibility {

	/**
	 * hasComponentFlexible : contract is flexible, heavyFlexContract=true
	 * 
	 */
	private boolean hasComponentFlexible = false;

	/**
	 * hasProposalDateAndAlert : for contract flexible and targa
	 */
	private boolean hasProposalDateAndAlert = false;

	/**
	 * Constructor
	 */
	public ContractVisibility() {
		super();
	}

	/**
	 * Constructor
	 */
	public ContractVisibility(MpContractDto contract) {

		if (contract != null && contract.getActiveMpContract() != null)
		{

			if (ConnectedTypeEnum.LIGHT_TARGA_CONNECTED.getValue().equals(contract.getActiveMpContract().getConnectedType()))
			{
				this.setHasComponentFlexible(false);
				this.setHasProposalDateAndAlert(true);
			}
			else if (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract()))
			{
				this.setHasComponentFlexible(true);
				this.setHasProposalDateAndAlert(true);
			}
		}

	}

	/**
	 * Constructor
	 */
	public ContractVisibility(MpContractDto contract, boolean ucrManageMp) {

		if (contract != null && contract.getActiveMpContract() != null)
		{

			if (ConnectedTypeEnum.LIGHT_TARGA_CONNECTED.getValue().equals(contract.getActiveMpContract().getConnectedType()))
			{
				this.setHasComponentFlexible(false);
				this.setHasProposalDateAndAlert(true);
			}
			else if (ConnectedTypeEnum.HEAVY_FLEX_CONTRACT.getValue().equals(contract.getActiveMpContract().getTypeContract()) && !ucrManageMp)
			{
				this.setHasComponentFlexible(true);
				this.setHasProposalDateAndAlert(true);
			}
		}

	}

	/**
	 * Constructor
	 * 
	 * @param hasComponentFlexible
	 * @param hasProposalDate
	 */
	public ContractVisibility(boolean hasComponentFlexible, boolean hasProposalDateAndAlert) {
		super();
		this.hasComponentFlexible = hasComponentFlexible;
		this.hasProposalDateAndAlert = hasProposalDateAndAlert;
	}

	/**
	 * @return the hasComponentFlexible
	 */
	public boolean hasComponentFlexible() {
		return hasComponentFlexible;
	}

	/**
	 * @param hasComponentFlexible the hasComponentFlexible to set
	 */
	public void setHasComponentFlexible(boolean hasComponentFlexible) {
		this.hasComponentFlexible = hasComponentFlexible;
	}

	/**
	 * @return the hasProposalDateAndAlert
	 */
	public boolean hasProposalDateAndAlert() {
		return hasProposalDateAndAlert;
	}

	/**
	 * @param hasProposalDateAndAlert the hasProposalDateAndAlert to set
	 */
	public void setHasProposalDateAndAlert(boolean hasProposalDateAndAlert) {
		this.hasProposalDateAndAlert = hasProposalDateAndAlert;
	}

}
