package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author mmartel
 *
 */
public class CouponOrder implements Comparator<String> {

	/** Flexible coupons. **/
	private Map<String, MpFlexCouponDto> flexibleCoupons;

	/**
	 * Constructor.
	 * 
	 * @param flexibleCoupons : map of flexible coupons
	 */
	public CouponOrder(Map<String, MpFlexCouponDto> flexibleCoupons) {
		if (flexibleCoupons != null)
		{
			this.flexibleCoupons = flexibleCoupons;
		}
		else
		{
			this.flexibleCoupons = new HashMap<>();
		}
	}

	/**
	 * Compare same code interval for CV.
	 * 
	 * @param code1 a code
	 * @param code2 a code
	 * @return the biggest interval
	 */
	private int compareSameCodeCv(String code1, String code2) {
		int result = 0;
		Integer i1;
		Integer i2;
		if (code2.charAt(0) == 'E')//Case of EP
		{
			i1 = new Integer(code1.substring(2, code1.length()));
			i2 = new Integer(code2.substring(2, code2.length()));
		}
		else
		{
			i1 = new Integer(code1.substring(1, code1.length()));
			i2 = new Integer(code2.substring(1, code2.length()));

		}
		result = i1.compareTo(i2);
		return (result);
	}

	/**
	 * Compare same code interval for AG&CE.
	 * 
	 * @param code1 a code
	 * @param code2 a code
	 * @return the biggest interval
	 */
	private int compareSameCodeAgCe(String code1, String code2) {
		int result = 0;
		// Split the interval code with / and use only the first part of the interval code (I50H, I100H, R100H, R200H, R1200H/1Y,...)
		String intCode1 = code1.split("/")[0];
		String intCode2 = code2.split("/")[0];

		Integer i1 = new Integer(intCode1.substring(1, intCode1.length() - 1));
		Integer i2 = new Integer(intCode2.substring(1, intCode2.length() - 1));

		if (i1.compareTo(i2) == 0)
		{
			if (code1.length() < code2.length())
			{
				result = -1;
			}
			else if (code1.length() > code2.length())
			{
				result = 1;
			}
			else
			{
				String intCodeBis1 = code1.split("/")[1];
				String intCodeBis2 = code2.split("/")[1];

				Integer ib1 = new Integer(intCodeBis1.substring(0, intCodeBis1.length() - 1));
				Integer ib2 = new Integer(intCodeBis2.substring(0, intCodeBis2.length() - 1));

				result = ib1.compareTo(ib2);
			}
		}
		else
		{
			result = i1.compareTo(i2);
		}

		return result;
	}

	/**
	 * used to sort by code.
	 * 
	 * @param code1 an interval code 1
	 * @param code2 an interval code 2
	 * @return the comparison result
	 */
	public int compare(String code1, String code2) {
		int result = 0;
		// CV
		if (isMCode(code1) && isMCode(code2)
				|| isEPCode(code1) && isEPCode(code2)
				|| isTCode(code1) && isTCode(code2)
				|| isNCode(code1) && isNCode(code2))
		{
			result = compareSameCodeCv(code1, code2);
		}
		// AG&CE
		else if ((isICode(code1) && isICode(code2)) || (isRCode(code1) && isRCode(code2)))
		{
			result = compareSameCodeAgCe(code1, code2);
		}
		// -- flexible coupons are the most important should come first (ordered in alphabetic order)
		else if (this.flexibleCoupons.containsKey(code1) && this.flexibleCoupons.containsKey(code2))
		{
			result = code1.compareTo(code2);
		}
		else if (this.flexibleCoupons.containsKey(code1))
		{
			result = -1;
		}
		else if (this.flexibleCoupons.containsKey(code2))
		{
			result = 1;
		}
		//keep temporary for 8.5 version the E0 (normally included in flex coupons)
		else if (code1.equals("EO"))
		{
			result = -1;
		}
		else if (code2.equals("EO"))
		{
			result = 1;
		}
		else if (isMCode(code1))
		{
			result = -1;
		}
		else if (isMCode(code2)) // -- Then is M
		{
			result = 1;
		}
		else if (isEPCode(code1)) // -- Then EP
		{
			result = -1;
		}
		else if (isEPCode(code2))
		{
			result = 1;
		}
		else if (isTCode(code1)) // -- Then T
		{
			result = -1;
		}
		else if (isTCode(code2))
		{
			result = 1;
		}
		else if (isNCode(code1)) // -- Then N
		{
			result = -1;
		}
		else if (isNCode(code2))
		{
			result = 1;
		}
		else if (isICode(code1)) // -- Then I
		{
			result = -1;
		}
		else if (isICode(code2))
		{
			result = 1;
		}
		else if (isRCode(code1)) // -- Then R
		{
			result = -1;
		}
		else if (isRCode(code2))
		{
			result = 1;
		}
		else
		{
			result = code1.compareTo(code2);
		}
		return result;
	}

	/**
	 * Return true if code is like M1, M2, .... M10,... .
	 * 
	 * @param code
	 *            to check
	 * @return if ok .
	 */
	// MML temporaire, il faudra l'enlever
	private boolean isMCode(String code) {
		boolean result = false;
		if (code.startsWith("M") && code.length() > 1)
		{
			String value = code.substring(1, code.length());
			if (Pattern.matches("^[0-9]*$", value))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * Return true if code is like EP1, EP2, .... EP10,... .
	 * 
	 * @param code
	 *            to check
	 * @return if ok .
	 */
	// MML temporaire, il faudra l'enlever
	private boolean isEPCode(String code) {
		boolean result = false;
		if (code.startsWith("EP") && code.length() > 2)
		{
			String value = code.substring(2, code.length());
			if (Pattern.matches("^[0-9]*$", value))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * Return true if code is like T1, T2, .... T10,... .
	 * 
	 * @param code
	 *            to check
	 * @return if ok .
	 */
	// MML temporaire, il faudra l'enlever
	private boolean isTCode(String code) {
		boolean result = false;
		if (code.startsWith("T") && code.length() > 1)
		{
			String value = code.substring(1, code.length());
			if (Pattern.matches("^[0-9]*$", value))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * Return true if code is like T1, T2, .... T10,... .
	 * 
	 * @param code
	 *            to check
	 * @return if ok .
	 */
	// MML temporaire, il faudra l'enlever
	private boolean isNCode(String code) {
		boolean result = false;
		if (code.startsWith("N") && code.length() > 1)
		{
			String value = code.substring(1, code.length());
			if (Pattern.matches("^[0-9]*$", value))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * Return true if code is like I50H, I100H
	 * 
	 * @param code to check
	 * @return if ok .
	 */
	private boolean isICode(String code) {
		boolean result = false;
		if (code.startsWith("I") && code.length() > 1)
		{
			String value = code.substring(1, code.length());
			if (Pattern.matches("^[0-9]+[A-Z]([/][0-9]+[A-Z])?$", value))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * Return true if code is like R100H, R200H, .... R1000H,... R1200H/1Y .
	 * 
	 * @param code to check
	 * @return if ok .
	 */
	private boolean isRCode(String code) {
		boolean result = false;
		if (code.startsWith("R") && code.length() > 1)
		{
			String value = code.substring(1, code.length());
			if (Pattern.matches("^[0-9]+[A-Z]([/][0-9]+[A-Z])?$", value))
			{
				result = true;
			}
		}
		return result;
	}

}
