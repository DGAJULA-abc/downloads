package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.mpbusiness.dto.MpCouponViewDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * 
 * @author bmilcend
 *
 */
public class MpCouponViewComparator implements Comparator<MpCouponViewDto> {

	/** Flexible coupons. **/
	private Map<String, MpFlexCouponDto> flexibleCoupons;

	/**
	 * Constructor.
	 * 
	 */
	public MpCouponViewComparator() {
	}

	/**
	 * Constructor.
	 * 
	 */
	public MpCouponViewComparator(Map<String, MpFlexCouponDto> flexibleCoupons) {
		if (flexibleCoupons != null)
		{
			this.flexibleCoupons = flexibleCoupons;
		}
		else
		{
			this.flexibleCoupons = new HashMap<>();
		}
	}

	/**
	 * used to sort by code.
	 * 
	 * @param mpCoupon1 a coupon
	 * @param mpCoupon2 a coupon
	 * @return the comparison result
	 */
	public int compare(MpCouponViewDto mpCoupon1, MpCouponViewDto mpCoupon2) {
		String code1 = mpCoupon1.getCouponTitle();
		String code2 = mpCoupon2.getCouponTitle();
		return new CouponOrder(flexibleCoupons).compare(code1, code2);
	}
}
