package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpIntervalByCodeComparator implements Comparator<MpIntervalDto> {

	/** Flexible coupons. **/
	private Map<String, MpFlexCouponDto> flexibleCoupons;

	/**
	 * Constructor.
	 * 
	 * @param flexibleCoupons : map of flexible coupons
	 */
	public MpIntervalByCodeComparator(Map<String, MpFlexCouponDto> flexibleCoupons) {
		if (flexibleCoupons != null)
		{
			this.flexibleCoupons = flexibleCoupons;
		}
		else
		{
			this.flexibleCoupons = new HashMap<>();
		}
	}

	/**
	 * used to sort by code.
	 * 
	 * @param interval1 an interval
	 * @param interval2 an interval
	 * @return the comparison result
	 */
	public int compare(MpIntervalDto interval1, MpIntervalDto interval2) {
		String code1 = interval1.getCode();
		String code2 = interval2.getCode();
		return new CouponOrder(flexibleCoupons).compare(code1, code2);
	}

}
