package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;

import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * 
 * @author cblois
 *
 */
public class MpIntervalComparator implements Comparator<MpHistoryIntervalDto> {

	/**
	 * Constructor.
	 */
	public MpIntervalComparator() {
	}

	/**
	 * used to sort by code.
	 * 
	 * @param histo1 a history
	 * @param histo2 a history
	 * @return the comparison result
	 */
	public int compare(MpHistoryIntervalDto histo1, MpHistoryIntervalDto histo2) {
		int result = 0;
		try
		{
			result = histo1.getIntervalCode().compareTo(histo2.getIntervalCode());
			if (result == 0)
			{
				result = -histo1.retreiveFromExactValueByMpType(MpType.MP_MONTH).compareTo(histo2.retreiveFromExactValueByMpType(MpType.MP_MONTH));
			}
		}
		catch (NullPointerException npe)
		{
			return 0;
		}
		return result;
	}

}
