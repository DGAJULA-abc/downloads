package capgemini.cnh.mpbusiness.util;

public enum MpIntervalHistoryEnum {

	DEALER(0), CUSTOMER(1);

	private final int operator;

	private MpIntervalHistoryEnum(int operator) {
		this.operator = operator;
	}

	public int getValue() {
		return operator;
	}

}