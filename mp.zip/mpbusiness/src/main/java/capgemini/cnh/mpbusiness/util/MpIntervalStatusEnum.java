package capgemini.cnh.mpbusiness.util;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * Project CNH - Ice administration.
 *
 * @author clonguei
 *
 *         Version history :
 *
 *         Date Name Change log
 *
 */

/**
 * Class defining enums for dto status.
 * 
 */
public enum MpIntervalStatusEnum {

	/**
	 * Enum NOT_RECOMMENDED.
	 */
	@JsonProperty(Constants.NOT_RECOMMENDED)
	NOT_RECOMMENDED(Constants.NOT_RECOMMENDED, "Not Recommended"),
	/**
	 * Enum COMING_SOON.
	 */
	@JsonProperty(Constants.COMING_SOON)
	COMING_SOON(Constants.COMING_SOON, "Coming soon"),
	/**
	 * Enum ON_TIME.
	 */
	@JsonProperty(Constants.ON_TIME)
	ON_TIME(Constants.ON_TIME, "On time"),
	/**
	 * Enum OVERDUE.
	 */
	@JsonProperty(Constants.OVERDUE)
	OVERDUE(Constants.OVERDUE, "Overdue"),
	/**
	 * Enum HIGH_OVERDUE.
	 */
	@JsonProperty(Constants.HIGH_OVERDUE)
	HIGH_OVERDUE(Constants.HIGH_OVERDUE, "High overdue");

	/** Value for an Enum. */
	private String value;

	/** Label for an Enum. */
	private String label;

	/**
	 * Constructor.
	 * 
	 * @param num value of status
	 * @param newLabel label of status
	 */
	MpIntervalStatusEnum(String abbreviation, String label) {
		this.value = abbreviation;
		this.label = label;

	}

	/**
	 * getters and setters.
	 * 
	 * @return value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * String to display.
	 * 
	 * @return the status label
	 */
	@Override
	public String toString() {
		return label;
	}
}
