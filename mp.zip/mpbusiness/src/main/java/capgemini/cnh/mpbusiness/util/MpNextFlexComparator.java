package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;

import capgemini.cnh.mpbusiness.dto.MpNextStopDto;
import capgemini.cnh.mpbusiness.dto.MpType;

/**
 * 
 * @author cblois
 *
 */
public class MpNextFlexComparator implements Comparator<MpNextStopDto> {

	/**
	 * Constructor.
	 */
	public MpNextFlexComparator() {
	}

	/**
	 * used to sort by code.
	 * 
	 * @param stop1 a next stop
	 * @param stop2 a next stop
	 * @return the comparison result
	 */
	public int compare(MpNextStopDto stop1, MpNextStopDto stop2) {
		int result = 0;
		try
		{
			result = stop1.getIntervalCode().compareTo(stop2.getIntervalCode());
			if (result == 0)
			{
				Long km1 = stop1.getNextValue(MpType.MP_KM);
				Long km2 = stop2.getNextValue(MpType.MP_KM);
				if (km1 == null)
				{
					result = 1;
				}
				else if (km2 == null)
				{
					result = -1;
				}
				else
				{
					result = km1.compareTo(km2);
				}
			}
		}
		catch (NullPointerException npe)
		{
			return 0;
		}
		return result;
	}

}
