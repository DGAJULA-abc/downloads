package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpNextStopByCodeComparator implements Comparator<MpNextStopDto> {

	/** Flexible coupons. **/
	private Map<String, MpFlexCouponDto> flexibleCoupons;

	/**
	 * Constructor.
	 * 
	 * @param flexibleCoupons : map of flexible coupons
	 */
	public MpNextStopByCodeComparator(Map<String, MpFlexCouponDto> flexibleCoupons) {
		if (flexibleCoupons != null)
		{
			this.flexibleCoupons = flexibleCoupons;
		}
		else
		{
			this.flexibleCoupons = new HashMap<>();
		}
	}

	/**
	 * used to sort by code.
	 * 
	 * @param nextStop1 an next stop
	 * @param nextStop2 an next stop
	 * @return the comparison result
	 */
	public int compare(MpNextStopDto nextStop1, MpNextStopDto nextStop2) {
		String code1 = nextStop1.getIntervalCode();
		String code2 = nextStop2.getIntervalCode();
		return new CouponOrder(flexibleCoupons).compare(code1, code2);
	}

}
