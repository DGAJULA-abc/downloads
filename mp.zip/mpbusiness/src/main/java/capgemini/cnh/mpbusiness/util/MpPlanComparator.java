package capgemini.cnh.mpbusiness.util;

import java.util.Comparator;

import capgemini.cnh.mpbusiness.dto.MpPlanDto;

/**
 * 
 * @author mmartel
 *
 */
public class MpPlanComparator implements Comparator<MpPlanDto> {

	/**
	 * Constructor.
	 */
	public MpPlanComparator() {
	}

	/**
	 * used to sort by standard plan and then by plan id.
	 * 
	 * @param plan1 a plan
	 * @param plan2 a plan
	 * @return the comparison result
	 */
	public int compare(MpPlanDto plan1, MpPlanDto plan2) {
		int result = 0;
		try
		{
			if (plan1.getStandard() == plan2.getStandard())
			{
				result = 0;
			}
			else if (plan1.getStandard())
			{
				result = -1;
			}
			else
			{
				result = 1;
			}
			if (result == 0)
			{
				Long planId1 = plan1.getId();
				Long planId2 = plan2.getId();
				if (planId1 == null)
				{
					result = 1;
				}
				else if (planId2 == null)
				{
					result = -1;
				}
				else
				{
					result = planId1.compareTo(planId2);
				}
			}
		}
		catch (NullPointerException npe)
		{
			return 0;
		}
		return result;
	}

}
