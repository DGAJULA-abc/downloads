package capgemini.cnh.mpbusiness.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import capgemini.cnh.externals.sap.SAPBroker;
import capgemini.cnh.externals.sap.model.ResponseData;
import capgemini.cnh.externals.sap.model.ResponseData.RepairHistoryDto;
import capgemini.cnh.externals.sap.model.SAPParameters;
import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.business.DMCBusiness;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.mpbusiness.business.MPSapHistoryService;
import capgemini.cnh.mpbusiness.business.MpNextStopBusiness;
import capgemini.cnh.mpbusiness.business.MpPlanBusiness;
import capgemini.cnh.mpbusiness.dto.MpContractDto;
import capgemini.cnh.mpbusiness.dto.MpFlexCouponDto;

/**
 * SOLR index process thread.
 */
public class MpUpdateHistoryCouponThread implements Runnable {

	/** Logger for the application. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpUpdateHistoryCouponThread.class);

	/** Vin. **/
	private String vin = null;
	/** isIveco. **/
	private boolean isIveco = false;
	/** List of vin to update the proposal date. **/
	private Set<String> mpNextFlexStopSet = Collections.synchronizedSet(new HashSet<String>());

	private IceContextDto context;

	private List<String> vinList = new ArrayList<>();

	/**
	 * Constructor.
	 * 
	 * @param vin the vin.
	 * @param mpNextFlexStopSet : mpNextFlexStopSet
	 * @param isIveco : isIveco customer
	 */
	public MpUpdateHistoryCouponThread(String vin, List<String> vinList, Set<String> mpNextFlexStopSet, boolean isIveco, IceContextDto context) {
		this.vin = vin;
		this.vinList = vinList;
		this.isIveco = isIveco;
		this.mpNextFlexStopSet = mpNextFlexStopSet;
		this.context = context;
	}

	@Override
	public void run() {
		logger.info("Update coupon history for VIN " + vin);
		DMCBusiness dmcBusiness = new DMCBusiness();
		try
		{
			String customer;
			String subflowName = null;
			if (isIveco)
			{
				subflowName = Context.getStringProperty("cms.subflow.name.iveco");
				customer = Constants.CUSTOMER_IVECO;
			}
			else
			{
				subflowName = Context.getStringProperty("cms.subflow.name.na");
				customer = Constants.CUSTOMER_CNH;
			}

			//Call SAP BROKER
			SAPParameters sapParameters = new SAPParameters(vin, "EN", subflowName);
			sapParameters.setRepHistory(2);
			sapParameters.setVehicle(1);
			sapParameters.setSubflowName(subflowName);
			ResponseData response = SAPBroker.call(sapParameters);
			List<RepairHistoryDto> repairHistoryDtoList = null;
			if (response != null)
			{
				repairHistoryDtoList = response.getRepairHistory();
			}

			if (!isIveco && repairHistoryDtoList.size() == 0)
			{
				subflowName = Context.getStringProperty("cms.subflow.name.eu");
				sapParameters = new SAPParameters(vin, "EN", subflowName);
				sapParameters.setRepHistory(2);
				sapParameters.setVehicle(1);
				response = SAPBroker.call(sapParameters);
			}

			MpPlanBusiness mpBusiness = new MpPlanBusiness();
			MpContractDto contract = mpBusiness.getAllMpContracts(Arrays.asList(vin), true, isIveco);

			//Call function update history
			int toleranceToMatch = new Integer(Context.getStringProperty("mp.tolerance.tomatch"));
			int toleranceToWait = new Integer(Context.getStringProperty("mp.tolerance.towait"));

			MPSapHistoryService service = new MPSapHistoryService(vin, vinList, Constants.ENGLISH, response,
					contract, toleranceToMatch, toleranceToWait, context);

			List<MpFlexCouponDto> list = (new MpNextStopBusiness()).getFlexibleCoupons();
			Map<String, MpFlexCouponDto> flexibleCouponsMap = new HashMap<>();
			if (list != null)
			{
				for (MpFlexCouponDto couponDto : list)
				{
					flexibleCouponsMap.put(couponDto.getIntervalCode(), couponDto);
				}
			}

			service.setCouponFlexibles(flexibleCouponsMap);
			service.setCustomer(customer);

			boolean historyUpdated = service.updateMpHistoryWithSapData();
			if (historyUpdated)
			{
				//Add the vin into the list to update the proposal date
				mpNextFlexStopSet.add(vin);
			}
		}
		catch (SystemException e)
		{
			try
			{
				dmcBusiness.logFailureMP("TIDB_APPLI", Constants.LOG_TYPE_WEEKLY_ALGO, "MpUpdateHistoryCouponThread - SystemException. VIN: " + vin + " " + e,
						Context.getSoftwareVersion(), "localhost");
			}
			catch (SystemException | ApplicativeException e1)
			{
				logger.error("MpServices logFailureMP Exception = " + e);
			}
			logger.error("MpServices SystemException = " + e);
		}
		catch (ApplicativeException e)
		{
			try
			{
				dmcBusiness.logFailureMP("TIDB_APPLI", Constants.LOG_TYPE_WEEKLY_ALGO, "MpUpdateHistoryCouponThread - getAllMpContracts ApplicativeException. VIN: " + vin + " " + e,
						Context.getSoftwareVersion(), "localhost");
			}
			catch (SystemException | ApplicativeException e1)
			{
				logger.error("MpServices logFailureMP Exception = " + e);
			}
			logger.error("MpServices ApplicativeException = " + e);
		}
		catch (RuntimeException e)
		{
			try
			{
				dmcBusiness.logFailureMP("TIDB_APPLI", Constants.LOG_TYPE_WEEKLY_ALGO, "MpUpdateHistoryCouponThread - RuntimeException. VIN: " + vin + " " + e,
						Context.getSoftwareVersion(), "localhost");
			}
			catch (SystemException | ApplicativeException e1)
			{
				logger.error("MpServices logFailureMP Exception = " + e);
			}
			logger.error("MpServices RuntimeException = " + e);
		}

	}

}
