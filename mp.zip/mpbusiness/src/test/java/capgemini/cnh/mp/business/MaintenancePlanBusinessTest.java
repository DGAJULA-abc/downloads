package capgemini.cnh.mp.business;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.LanguageDto;
import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.business.MaintenancePlanVariableSchedulingBusiness;
import capgemini.cnh.mpbusiness.business.MpIntervalBusiness;
import capgemini.cnh.mpbusiness.dto.MpHistoryIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.Constants;

/**
 * Test for the class MaintenancePlanBusiness.
 * 
 * @author dbabillo
 */
public class MaintenancePlanBusinessTest {

	/**
	 * Actual value.
	 */
	private static final String actualMileage = "210000";
	/**
	 * Actual value.
	 */
	private static final String actualHour = "0";
	/**
	 * Actual value.
	 */
	private static final String warrantyDate = "1396483200000"; // -- 03/04/2014
	/**
	 * Today.
	 */
	private static final String nowDate = "1396483200000"; // -- 24/04/2017
	/**
	 * Questions.
	 */
	private static final String questionJsonArray = "D:\\Projet\\TIDB\\2017_MPi\\questions.json";
	/**
	 * Intervals.
	 */
	private static final String intervalJsonArray = "D:\\Projet\\TIDB\\2017_MPi\\intervals.json";

	/**
	 * 
	 */
	private static final String customer = Constants.CUSTOMER_IVECO;

	/**
	 * Class tested.
	 */
	private MaintenancePlanBusiness mpBusiness = null;

	/**
	 * Default constructor.
	 */
	public MaintenancePlanBusinessTest() {

	}

	/**
	 * Initialization.
	 */
	@Before
	public void setUp() {
		Locale locale = new Locale(LanguageDto.valueOfDefault().getIdlanguage());
		this.mpBusiness = new MaintenancePlanVariableSchedulingBusiness(actualMileage, actualHour, warrantyDate, nowDate, locale, customer, null);

		Context.setTestMode(Context.TestMode.ORACLE_TIDB);
	}

	/**
	 * Current VIN.
	 */
	private String vin;
	/**
	 * Current interval id.
	 */
	private Long intervalId;
	private Long externalPlanId;

	private String vehicleMileage;
	private String vehicleHour;
	private String vehicleWSD;
	private String todayDate;

	/**
	 * @param intervalList interval list
	 * @param questionList question list
	 * @param saveList save list
	 * @throws SystemException cannot execute query
	 */
	private void runCycle(List<MpIntervalDto> intervalList, List<MpHistoryIntervalDto> questionList, List<MpHistoryIntervalDto> saveList) throws SystemException {
		Locale locale = new Locale("EN");
		// -- 00 init business
		MaintenancePlanBusiness business = new MaintenancePlanVariableSchedulingBusiness(this.vehicleMileage, this.vehicleHour, this.vehicleWSD, this.todayDate, locale, customer, null);

		MpIntervalBusiness mpIntervalBusiness = new MpIntervalBusiness();

		questionList.clear(); // -- empty question list
		saveList.clear(); // -- empty save list

		List<String> vinList = new ArrayList<String>();
		vinList.add(this.vin);
		// -- 01 read history from base
		List<MpHistoryIntervalDto> historyList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, null);

		// -- 02 read question
		questionList.addAll(business.getHistoryQuestionList(historyList, intervalList));

		// -- 03 run interval selection algorithm
		business.selectRecommandedIntervals(intervalList, questionList, null, null, true, "");

		// -- 04 save interval in db
		String nowEpoch = Long.valueOf(System.currentTimeMillis()).toString();
		saveList.addAll(business.getIntervalHistory(this.vin, intervalList, nowEpoch, questionList, this.externalPlanId, false));
		for (MpHistoryIntervalDto save : saveList)
		{
			mpIntervalBusiness.createHistoryInterval(save);
		}
	}

	/**
	 * Take basic interval M1 every 100 000 KM (id 666L) and run maintenance multiple times to simulate the life cycle of the vehicle.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testMileageLongLifeCycleBigJump() {
		this.vin = "VinDiesel";
		this.intervalId = 666L;
		this.vehicleMileage = null;
		this.vehicleHour = null;
		this.vehicleWSD = null;
		this.todayDate = null;

		// -- init M1 every 100 000 KM
		List<MpIntervalDto> intervalList = new ArrayList<MpIntervalDto>();
		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setId(this.intervalId);
		m1.setCode("M1");
		intervalList.add(m1);

		try
		{
			List<String> vinList = new ArrayList<String>();
			vinList.add(this.vin);
			// -- clear all history related to vin and interval
			List<MpHistoryIntervalDto> questionList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, null);
			for (MpHistoryIntervalDto question : questionList)
			{
				MpIntervalBusiness.deleteHistoryInterval(question);
			}
			questionList.clear();
			List<MpHistoryIntervalDto> saveList = new ArrayList<MpHistoryIntervalDto>();

			this.vehicleMileage = "95000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			this.vehicleMileage = "190000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "285000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "380000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "475000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "710000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("700000")));

			vehicleMileage = "810000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("800000")));

			vehicleMileage = "900000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

		}
		catch (SystemException e) // -- catch db read/write errors
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Take basic interval M1 every 100 000 KM (id 666L) and run maintenance multiple times to simulate the life cycle of the vehicle.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testMileageLongLifeCycleBigJumpExact() {
		this.vin = "VinDiesel";
		this.intervalId = 666L;
		this.vehicleMileage = null;
		this.vehicleHour = null;
		this.vehicleWSD = null;
		this.todayDate = null;
		Long externalId = null;

		// -- init M1 every 100 000 KM
		List<MpIntervalDto> intervalList = new ArrayList<MpIntervalDto>();
		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setId(this.intervalId);
		m1.setCode("M1");
		intervalList.add(m1);

		try
		{
			List<String> vinList = new ArrayList<String>();
			vinList.add(this.vin);

			// -- clear all history related to vin and interval
			List<MpHistoryIntervalDto> questionList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, externalId);
			for (MpHistoryIntervalDto question : questionList)
			{
				MpIntervalBusiness.deleteHistoryInterval(question);
			}
			questionList.clear();
			List<MpHistoryIntervalDto> saveList = new ArrayList<MpHistoryIntervalDto>();

			vehicleMileage = "110000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("100000")));

			vehicleMileage = "210000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("200000")));

			vehicleMileage = "410000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("400000")));
		}
		catch (SystemException e) // -- catch db read/write errors
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Take basic interval M1 every 100 000 KM (id 666L) and run maintenance multiple times to simulate the life cycle of the vehicle.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testMileageLongLifeCycle02() {
		this.vin = "VinDiesel";
		this.intervalId = 666L;
		this.vehicleMileage = null;
		this.vehicleHour = null;
		this.vehicleWSD = null;
		this.todayDate = null;

		// -- init M1 every 100 000 KM
		List<MpIntervalDto> intervalList = new ArrayList<MpIntervalDto>();
		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setId(this.intervalId);
		m1.setCode("M1");
		intervalList.add(m1);

		try
		{
			List<String> vinList = new ArrayList<String>();
			vinList.add(this.vin);

			// -- clear all history related to vin and interval
			List<MpHistoryIntervalDto> questionList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, null);
			for (MpHistoryIntervalDto question : questionList)
			{
				MpIntervalBusiness.deleteHistoryInterval(question);
			}
			questionList.clear();
			List<MpHistoryIntervalDto> saveList = new ArrayList<MpHistoryIntervalDto>();

			vehicleMileage = "95000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "190000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "285000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "395000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "500000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "600000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "680000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == false);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 0);

			vehicleMileage = "692000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == false);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == true);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 0);

			vehicleMileage = "695000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "815000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("800000")));

		}
		catch (SystemException e) // -- catch db read/write errors
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Take basic interval M1 every 1 000 Hours (id 666L) and run maintenance multiple times to simulate the life cycle of the vehicle.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testHourLongLifeCycle() {
		this.vin = "VinDiesel";
		this.intervalId = 666L;
		this.vehicleMileage = null;
		this.vehicleHour = null;
		this.vehicleWSD = null;
		this.todayDate = null;

		// -- init M1 every 100 000 KM
		List<MpIntervalDto> intervalList = new ArrayList<MpIntervalDto>();
		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 0L, 1000L, 0L);
		m1.setId(this.intervalId);
		m1.setCode("M1");
		intervalList.add(m1);

		try
		{
			List<String> vinList = new ArrayList<String>();
			vinList.add(this.vin);

			// -- clear all history related to vin and interval
			List<MpHistoryIntervalDto> questionList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, null);
			for (MpHistoryIntervalDto question : questionList)
			{
				MpIntervalBusiness.deleteHistoryInterval(question);
			}
			questionList.clear();
			List<MpHistoryIntervalDto> saveList = new ArrayList<MpHistoryIntervalDto>();

			vehicleHour = "920";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleHour + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleHour + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleHour + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleHour + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleHour + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleHour + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
			assertTrue(vehicleHour + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));

			vehicleHour = "1840";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleHour + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleHour + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleHour + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleHour + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleHour + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleHour + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
			assertTrue(vehicleHour + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));

			vehicleHour = "2760";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleHour + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleHour + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleHour + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleHour + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleHour + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleHour + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
			assertTrue(vehicleHour + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));

			vehicleHour = "3680";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleHour + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleHour + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleHour + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleHour + ": bad coming soon flag" m1.isSoon() == false);
			assertTrue(vehicleHour + ": bad size for save list,", saveList.size() == 1);
			assertTrue(vehicleHour + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
			assertTrue(vehicleHour + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));

			vehicleHour = "4600";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleHour + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleHour + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleHour + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleHour + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleHour + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleHour + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
			assertTrue(vehicleHour + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_HOUR).equals(Long.valueOf(vehicleHour)));
		}
		catch (SystemException e) // -- catch db read/write errors
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValue() {
		this.vin = "VinDiesel";
		this.intervalId = 666L;
		this.vehicleMileage = null;
		this.vehicleHour = null;
		this.vehicleWSD = null;
		this.todayDate = null;

		// -- init M1 every 100 000 KM
		List<MpIntervalDto> intervalList = new ArrayList<MpIntervalDto>();
		MpIntervalDto m1 = new MpIntervalDto(100000L, 0L, 0L, 200000L, 0L, 0L);
		m1.setId(this.intervalId);
		m1.setCode("M1");
		intervalList.add(m1);

		try
		{
			List<String> vinList = new ArrayList<String>();
			vinList.add(this.vin);

			// -- clear all history related to vin and interval
			List<MpHistoryIntervalDto> questionList = MpIntervalBusiness.readListHistoryInterval(vinList, this.intervalId, null);
			for (MpHistoryIntervalDto question : questionList)
			{
				MpIntervalBusiness.deleteHistoryInterval(question);
			}
			questionList.clear();
			List<MpHistoryIntervalDto> saveList = new ArrayList<MpHistoryIntervalDto>();

			vehicleMileage = "80000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == false);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == true); // -- 10% de M1 -> 20 000 KM
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 0);

			vehicleMileage = "95000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 0);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));

			vehicleMileage = "105000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == false);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 0);

			vehicleMileage = "210000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == false);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == false);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 0);

			vehicleMileage = "310000";
			runCycle(intervalList, questionList, saveList);
			assertTrue(vehicleMileage + ": bad size for question list", questionList.size() == 1);
			assertTrue(vehicleMileage + ": bad selection flag", m1.isSelected() == true);
			//			assertTrue(vehicleMileage + ": bad overdue flag", m1.isOver() == true);
			//			assertTrue(vehicleMileage + ": bad coming soon flag", m1.isSoon() == false);
			assertTrue(vehicleMileage + ": bad size for save list", saveList.size() == 1);
			assertTrue(vehicleMileage + ": bad size for save value", saveList.get(0).retreiveFromExactValueByMpType(MpType.MP_KM).equals(Long.valueOf(vehicleMileage)));
			assertTrue(vehicleMileage + ": bad size for save int value", saveList.get(0).getIntValue(MpType.MP_KM).equals(Long.valueOf("300000")));
		}
		catch (SystemException e) // -- catch db read/write errors
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * test the getInterval function.
	 */
	/*	@Test
	public void testGetInterval() {
		MaintenancePlanBusiness bus = new MaintenancePlanBusiness("0", "0", "0", "0", new Locale("EN"), customer);
		long intValue = bus.getInterval(80000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 50000L);
		intValue = bus.getInterval(102000L, 100000L, 0L); // -- every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 100000L);
		intValue = bus.getInterval(50000L, 100000L, 0L); // -- every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 50000L);
		intValue = bus.getInterval(198000L, 100000L, 0L); // -- every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 198000L);
		intValue = bus.getInterval(625000L, 100000L, 0L); // -- every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 600000L);
		intValue = bus.getInterval(570000L, 100000L, 0L); // -- every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 500000L);
		intValue = bus.getInterval(50000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 50000L);
		intValue = bus.getInterval(48000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 48000L);
		intValue = bus.getInterval(10000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(65000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 50000L);
		intValue = bus.getInterval(95000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 95000L);
		intValue = bus.getInterval(98000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 98000L);
		intValue = bus.getInterval(94000L, 50000L, 0L); // -- every 50 000 KM
		assertTrue("intValue=" + intValue, intValue == 50000L);
		// -- add at value
	
		intValue = bus.getInterval(1000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 1000L);
		intValue = bus.getInterval(10000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(99000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(100000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 100000L);
		intValue = bus.getInterval(102000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 102000L);
		intValue = bus.getInterval(110000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 110000L);
		intValue = bus.getInterval(120000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 110000L);
		intValue = bus.getInterval(650000L, 100000L, 10000L); // -- at 10 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 610000L);
	
		intValue = bus.getInterval(1000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 1000L);
		intValue = bus.getInterval(10000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(99000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(100000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(102000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(110000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(120000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 10000L);
		intValue = bus.getInterval(210000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 210000L);
		intValue = bus.getInterval(205000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 205000L);
		intValue = bus.getInterval(215000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 210000L);
		intValue = bus.getInterval(650000L, 200000L, 10000L); // -- at 10 000 KM every 200 000 KM
		assertTrue("intValue=" + intValue, intValue == 610000L);
	
		intValue = bus.getInterval(100000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 0L);
		intValue = bus.getInterval(340000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 340000L);
		intValue = bus.getInterval(350000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 350000L);
		intValue = bus.getInterval(360000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 350000L);
		intValue = bus.getInterval(440000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 440000L);
		intValue = bus.getInterval(455000L, 100000L, 350000L); // -- at 350 000 KM every 100 000 KM
		assertTrue("intValue=" + intValue, intValue == 450000L);
	
		intValue = bus.getInterval(300000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 0L);
		intValue = bus.getInterval(359000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 0L);
		intValue = bus.getInterval(360000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 360000L);
		intValue = bus.getInterval(400000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 400000L);
		intValue = bus.getInterval(440000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 400000L);
		intValue = bus.getInterval(888000L, 0L, 400000L); // -- at 400 000 KM
		assertTrue("intValue=" + intValue, intValue == 400000L);
	}*/
}
