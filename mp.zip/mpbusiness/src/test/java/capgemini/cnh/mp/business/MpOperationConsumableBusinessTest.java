/**
 * 
 */
package capgemini.cnh.mp.business;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.LanguageDto;
import capgemini.cnh.ice.dto.MarketDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.business.MpOperationConsumableBusiness;
import capgemini.cnh.mpbusiness.dto.MpOperationConsumableDto;

/**
 * @author dbabillo
 */
public class MpOperationConsumableBusinessTest {

	/**
	 * Default constructor.
	 */
	public MpOperationConsumableBusinessTest() {
		super();
	}

	/**
	 * @return a product configuration
	 */
	private ProductConfiguration getProductConfig() {
		ProductConfiguration configuration = new ProductConfiguration();
		try
		{
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(125L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(131L));
			configuration.putConfiguration(ConfigurationDto.valueOf(138L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(141L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(47L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(262L));
		}
		catch (ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
		return (configuration);
	}

	/**
	 * Before.
	 */
	@Before
	public void setUp() {
		Context.setTestMode(Context.TestMode.ORACLE_TIDB);
	}

	/**
	 * Test method for
	 * {@link capgemini.cnh.ticd.component.business.MpOperationConsumableBusiness#getListConsumablesByOp(java.lang.String, capgemini.cnh.ice.dto.IceContextDto, capgemini.cnh.ice.dto.configuration.ProductConfiguration)}.
	 */
	@Test
	public void testGetListConsumablesByOp() {
		IceContextDto context = new IceContextDto();
		context.setMarket(MarketDto.EUROPE);
		context.setLanguage(LanguageDto.valueOf("IT"));
		context.setDefaultLanguage("EN");
		context.setFullICE("2.1.40.186.IT.001");
		context.getBrand().setId(2L);

		List<MpOperationConsumableDto> result;
		try
		{
			result = MpOperationConsumableBusiness.getListConsumablesByOp(677L, context, getProductConfig());
			assertTrue("no result", result.size() > 0);
		}
		catch (SystemException | ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

}
