/**
 * 
 */
package capgemini.cnh.mp.business;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.business.MpSupersessionBusiness;
import capgemini.cnh.mpbusiness.dto.MpPartNodeDto;

/**
 * @author dbabillo
 *
 */
public class MpPartSupersessionTest {

	/**
	 * Default constructor.
	 */
	public MpPartSupersessionTest() {
		super();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() {
		Context.setTestMode(Context.TestMode.ORACLE_TIDB);
	}

	/**
	 * @return a product configuration
	 */
	@Test
	public void testSupersession() {
		try
		{
			try
			{
				MpPartNodeDto result = new MpSupersessionBusiness().getSupersessions("pn1", "rootLabel", "AR", null);
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
				objectMapper.setSerializationInclusion(Include.NON_NULL);
				String jsonAlert = objectMapper.writeValueAsString(result);
				System.out.println(jsonAlert);
				//assertTrue("result:", result.getName().equals("1"));
			}
			catch (JsonProcessingException | SystemException e)
			{
				fail(e.getMessage());
				e.printStackTrace();

			}
		}
		catch (ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}
}
