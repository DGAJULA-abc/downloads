/**
 * 
 */
package capgemini.cnh.mp.business;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.IceContextDto;
import capgemini.cnh.ice.dto.MarketDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.business.MpPlanBusiness;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.dto.MpUsageDto;

/**
 * @author dbabillo
 *
 */
public class MpPlanBusinessTest {

	/**
	 * Default constructor.
	 */
	public MpPlanBusinessTest() {
	}

	/**
	 * Initialize tests.
	 */
	@Before
	public void setUp() {
		Context.setTestMode(Context.TestMode.ORACLE_TIDB);
	}

	/**
	 * @return a product configuration
	 */
	private ProductConfiguration getProductConfig() {
		ProductConfiguration configuration = new ProductConfiguration();
		try
		{
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(261L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(262L));
			configuration.putConfiguration(ConfigurationDto.valueOf(1722L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(1726L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(1729L));
			//configuration.putSelectConfiguration(ConfigurationDto.valueOf(42L));
		}
		catch (ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
		return (configuration);
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#getListByProjectList(java.lang.String, capgemini.cnh.ice.dto.IceContextDto, java.util.List)}.
	 */
	@Test
	public void testGetListByProjectList() {
		try
		{
			MpPlanBusiness business = new MpPlanBusiness();

			List<Integer> projectIdList = new ArrayList<Integer>();
			projectIdList.add(Integer.valueOf(145));
			projectIdList.add(Integer.valueOf(146));

			IceContextDto context = new IceContextDto();
			context.setMarket(MarketDto.EUROPE); // -- filter on market
			context.setModel(null);
			context.setTechnicalType(null);
			//context.setLanguage(LanguageDto.valueOf("IT"));

			List<MpPlanDto> plan = business.getListByProjectList(projectIdList, context, getProductConfig());
			assertTrue("no result", plan.size() > 0);

		}
		catch (SystemException | ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#getPerformanceListByPlanList(java.lang.String)}.
	 */
	@Test
	public void testGetPerformanceListByPlanList() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#getNbPlanWithHour(java.lang.String)}.
	 */
	@Test
	public void testGetNbPlanWithHour() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#getPlanWithCriteria(java.util.List, int, java.lang.Long, java.lang.String)}.
	 */
	@Test
	public void testGetPlanWithCriteria() {
		try
		{
			MpPlanBusiness business = new MpPlanBusiness();

			List<Long> planIdList = new ArrayList<Long>();
			planIdList.add(Long.valueOf(581));
			planIdList.add(Long.valueOf(696));
			planIdList.add(Long.valueOf(583));
			planIdList.add(Long.valueOf(578));
			planIdList.add(Long.valueOf(579));
			planIdList.add(Long.valueOf(580));

			int usageId = MpUsageDto.DEFAULT_VALUE_ID;

			String performanceId = "max";

			List<MpPlanDto> plan = business.getPlanWithCriteria(planIdList, usageId, performanceId, getProductConfig());
			assertTrue("no result", plan.size() > 0);
		}
		catch (SystemException | ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#getMaintenancePlanBySerie(capgemini.cnh.ice.dto.product.SeriesDto)}.
	 */
	@Test
	public void testGetMaintenancePlanBySerie() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link capgemini.cnh.ticd.component.business.MpPlanBusiness#generateMaintenancePlanTablePef(capgemini.cnh.ice.dto.product.SeriesDto, java.io.Writer, boolean)}.
	 */
	@Test
	public void testGenerateMaintenancePlanTablePef() {
		fail("Not yet implemented");
	}

}
