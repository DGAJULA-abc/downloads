/**
 * 
 */
package capgemini.cnh.mp.business;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import capgemini.cnh.framework.exception.ApplicativeException;
import capgemini.cnh.framework.util.TIDBLogger;
import capgemini.cnh.ice.dto.ConfigurationDto;
import capgemini.cnh.ice.dto.configuration.ProductConfiguration;
import capgemini.cnh.mpbusiness.dto.MpPlanDto;
import capgemini.cnh.mpbusiness.util.MpPlanComparator;

/**
 * @author dbabillo
 *
 */
public class MpPlanComparatorTest {

	/** Logger for the class. */
	private static TIDBLogger logger = TIDBLogger.getLogger(MpPlanComparatorTest.class);

	/**
	 * Default constructor.
	 */
	public MpPlanComparatorTest() {
	}

	/**
	 * Initialize tests.
	 */
	@Before
	public void setUp() {
		//Context.setTestMode(Context.TestMode.ORACLE_TIDB);
	}

	/**
	 * @return a product configuration
	 */
	private ProductConfiguration getProductConfig() {
		ProductConfiguration configuration = new ProductConfiguration();
		try
		{
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(261L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(262L));
			configuration.putConfiguration(ConfigurationDto.valueOf(1722L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(1726L));
			configuration.putSelectConfiguration(ConfigurationDto.valueOf(1729L));
			//configuration.putSelectConfiguration(ConfigurationDto.valueOf(42L));
		}
		catch (ApplicativeException e)
		{
			fail(e.getMessage());
			e.printStackTrace();
		}
		return (configuration);
	}

	/**
	 * Test method for {testPlanComparator}.
	 */
	@Test
	public void testPlanComparator() {

		List<MpPlanDto> planIdList = new ArrayList<MpPlanDto>();

		MpPlanDto plan4 = new MpPlanDto(null);
		plan4.setId(104L);
		plan4.setStandard(true);
		planIdList.add(plan4);

		MpPlanDto plan3 = new MpPlanDto(null);
		plan3.setStandard(true);
		plan3.setId(103L);
		planIdList.add(plan3);

		MpPlanDto plan5 = new MpPlanDto(null);
		plan5.setId(105L);
		plan5.setStandard(true);
		planIdList.add(plan5);

		MpPlanDto plan1 = new MpPlanDto(null);
		plan1.setId(101L);
		plan1.setStandard(true);
		planIdList.add(plan1);
		MpPlanDto plan2 = new MpPlanDto(null);
		plan2.setId(102L);
		plan2.setStandard(true);
		planIdList.add(plan2);

		Collections.sort(planIdList, new MpPlanComparator());

		for (MpPlanDto planDto : planIdList)
		{
			//logger.info("plan: " + planDto.getId());
			System.out.println("plan: " + planDto.getId());
		}
		assertTrue("no result", planIdList.size() > 0);

		/*	catch (SystemException )
			{
				fail(e.getMessage());
				e.printStackTrace();
			}*/
	}

}
