package capgemini.cnh.mp.business;

import org.junit.Test;

import capgemini.cnh.framework.common.Context;
import capgemini.cnh.framework.exception.SystemException;
import capgemini.cnh.mpbusiness.business.MpAppointmentBusiness;
import capgemini.cnh.mpbusiness.util.Constants;

public class mpappbusinessTest {

	private static final String customer = Constants.CUSTOMER_IVECO;

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 * 
	 * @throws SystemException
	 */
	@Test
	public void testAppointment() throws SystemException {
		Context.setTestMode(Context.TestMode.ORACLE_TIDB);

		MpAppointmentBusiness bus = new MpAppointmentBusiness();

		bus.closeAppointment(new Long(2));
	}

}
