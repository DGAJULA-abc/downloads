package capgemini.cnh.mp.business;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.junit.Test;

import capgemini.cnh.mpbusiness.business.MaintenancePlanBusiness;
import capgemini.cnh.mpbusiness.business.MaintenancePlanVariableSchedulingBusiness;
import capgemini.cnh.mpbusiness.dto.MpIntervalDto;
import capgemini.cnh.mpbusiness.dto.MpNextStopByScoreDto;
import capgemini.cnh.mpbusiness.dto.MpScoreDto;
import capgemini.cnh.mpbusiness.dto.MpType;
import capgemini.cnh.mpbusiness.util.Constants;

public class mpbusinessTest {

	private static final String customer = Constants.CUSTOMER_IVECO;

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValue() {

		MaintenancePlanBusiness bus = new MaintenancePlanVariableSchedulingBusiness("0", "0", "0", "0", new Locale("EN"), customer, null);
		// -- init M1 every 100 000 KM /  M2 every 200 000 KM /  M4 every 400 000 KM

		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setCode("M1");
		m1.setId(1L);

		MpIntervalDto m125 = new MpIntervalDto(0L, 0L, 0L, 125000L, 0L, 0L);
		m125.setCode("M125");
		m125.setId(125L);

		MpIntervalDto m150 = new MpIntervalDto(0L, 0L, 0L, 150000L, 0L, 0L);
		m150.setCode("M150");
		m150.setId(150L);

		MpIntervalDto m175 = new MpIntervalDto(0L, 0L, 0L, 175000L, 0L, 0L);
		m175.setCode("M175");
		m175.setId(175L);

		MpIntervalDto m2 = new MpIntervalDto(0L, 0L, 0L, 200000L, 0L, 0L);
		m2.setCode("M2");
		m2.setId(2L);

		MpIntervalDto m250 = new MpIntervalDto(0L, 0L, 0L, 250000L, 0L, 0L);
		m250.setCode("M250");
		m250.setId(250L);

		MpIntervalDto m3 = new MpIntervalDto(0L, 0L, 0L, 300000L, 0L, 0L);
		m3.setCode("M3");
		m3.setId(3L);

		MpIntervalDto m4 = new MpIntervalDto(0L, 0L, 0L, 400000L, 0L, 0L);
		m4.setCode("M4");
		m4.setId(4L);

		MpIntervalDto m5 = new MpIntervalDto(0L, 0L, 0L, 500000L, 0L, 0L);
		m5.setCode("M5");
		m5.setId(5L);

		MpIntervalDto m6 = new MpIntervalDto(0L, 0L, 0L, 600000L, 0L, 0L);
		m6.setCode("M6");
		m6.setId(6L);

		MpIntervalDto m7 = new MpIntervalDto(0L, 0L, 0L, 700000L, 0L, 0L);
		m7.setCode("M7");
		m7.setId(7L);

		MpIntervalDto m8 = new MpIntervalDto(0L, 0L, 0L, 800000L, 0L, 0L);
		m8.setCode("M8");
		m8.setId(8L);

		MpIntervalDto m9 = new MpIntervalDto(0L, 0L, 0L, 900000L, 0L, 0L);
		m9.setCode("M9");
		m9.setId(9L);

		MpIntervalDto m10 = new MpIntervalDto(0L, 0L, 0L, 1000000L, 0L, 0L);
		m10.setCode("M10");
		m10.setId(10L);

		MpIntervalDto m11 = new MpIntervalDto(0L, 0L, 0L, 1100000L, 0L, 0L);
		m11.setCode("M11");
		m11.setId(11L);

		MpIntervalDto m12 = new MpIntervalDto(0L, 0L, 0L, 1200000L, 0L, 0L);
		m12.setCode("M12");
		m12.setId(12L);

		// set the score
		MpNextStopByScoreDto nextStopM1 = new MpNextStopByScoreDto(m1, customer);
		MpNextStopByScoreDto nextStopM125 = new MpNextStopByScoreDto(m125, customer);
		MpNextStopByScoreDto nextStopM150 = new MpNextStopByScoreDto(m150, customer);
		MpNextStopByScoreDto nextStopM175 = new MpNextStopByScoreDto(m175, customer);
		MpNextStopByScoreDto nextStopM2 = new MpNextStopByScoreDto(m2, customer);
		MpNextStopByScoreDto nextStopM250 = new MpNextStopByScoreDto(m250, customer);
		MpNextStopByScoreDto nextStopM3 = new MpNextStopByScoreDto(m3, customer);
		MpNextStopByScoreDto nextStopM4 = new MpNextStopByScoreDto(m4, customer);
		MpNextStopByScoreDto nextStopM5 = new MpNextStopByScoreDto(m5, customer);
		MpNextStopByScoreDto nextStopM6 = new MpNextStopByScoreDto(m6, customer);
		MpNextStopByScoreDto nextStopM7 = new MpNextStopByScoreDto(m7, customer);
		MpNextStopByScoreDto nextStopM8 = new MpNextStopByScoreDto(m8, customer);
		MpNextStopByScoreDto nextStopM9 = new MpNextStopByScoreDto(m9, customer);
		MpNextStopByScoreDto nextStopM10 = new MpNextStopByScoreDto(m10, customer);
		MpNextStopByScoreDto nextStopM11 = new MpNextStopByScoreDto(m11, customer);
		MpNextStopByScoreDto nextStopM12 = new MpNextStopByScoreDto(m12, customer);

		List<MpNextStopByScoreDto> listNextStop = new ArrayList<>();
		listNextStop.add(nextStopM1);
		listNextStop.add(nextStopM125);
		listNextStop.add(nextStopM150);
		listNextStop.add(nextStopM175);
		listNextStop.add(nextStopM2);
		listNextStop.add(nextStopM250);
		listNextStop.add(nextStopM3);
		listNextStop.add(nextStopM4);
		listNextStop.add(nextStopM5);
		listNextStop.add(nextStopM6);
		listNextStop.add(nextStopM7);
		listNextStop.add(nextStopM8);
		listNextStop.add(nextStopM9);
		listNextStop.add(nextStopM10);
		listNextStop.add(nextStopM11);
		listNextStop.add(nextStopM12);

		//case 1 M1 - M2 - M4 :M1 selected
		nextStopM1.setNextStopByType(800000L, MpType.MP_KM);
		nextStopM125.setNextStopByType(850000L, MpType.MP_KM);
		nextStopM150.setNextStopByType(875000L, MpType.MP_KM);
		nextStopM175.setNextStopByType(870000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(850000L, MpType.MP_KM);
		nextStopM250.setNextStopByType(950000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(860000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(840000L, MpType.MP_KM);
		nextStopM5.setNextStopByType(1000000L, MpType.MP_KM);
		nextStopM6.setNextStopByType(1200000L, MpType.MP_KM);
		nextStopM7.setNextStopByType(1400000L, MpType.MP_KM);
		nextStopM8.setNextStopByType(860000L, MpType.MP_KM);
		nextStopM9.setNextStopByType(900000L, MpType.MP_KM);
		nextStopM10.setNextStopByType(1000000L, MpType.MP_KM);
		nextStopM11.setNextStopByType(1100000L, MpType.MP_KM);
		nextStopM12.setNextStopByType(1200000L, MpType.MP_KM);

		nextStopM1.setNextStopRecalculatedByType(800000L, MpType.MP_KM);
		nextStopM125.setNextStopRecalculatedByType(850000L, MpType.MP_KM);
		nextStopM150.setNextStopRecalculatedByType(875000L, MpType.MP_KM);
		nextStopM175.setNextStopRecalculatedByType(870000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(850000L, MpType.MP_KM);
		nextStopM250.setNextStopRecalculatedByType(950000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(860000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(840000L, MpType.MP_KM);
		nextStopM5.setNextStopRecalculatedByType(1000000L, MpType.MP_KM);
		nextStopM6.setNextStopRecalculatedByType(1200000L, MpType.MP_KM);
		nextStopM7.setNextStopRecalculatedByType(1400000L, MpType.MP_KM);
		nextStopM8.setNextStopRecalculatedByType(860000L, MpType.MP_KM);
		nextStopM9.setNextStopRecalculatedByType(900000L, MpType.MP_KM);
		nextStopM10.setNextStopRecalculatedByType(1000000L, MpType.MP_KM);
		nextStopM11.setNextStopRecalculatedByType(1100000L, MpType.MP_KM);
		nextStopM12.setNextStopRecalculatedByType(1200000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 790000L);
		result(listNextStop, 0L, 0L, 800000L);

		//case 2 M1 - M2 - M4 : M2 selected
		nextStopM1.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(210000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(210000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 195000L);
		result(listNextStop, 0L, 200000L, 0L);

		//case 3 M1 - M2 - M4 :M4 selected
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(420000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(420000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(430000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(430000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 390000L);
		result(listNextStop, 0L, 0L, 400000L);

		//case 2-1 M1 - M4 - M2 : M4 selected
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(410000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(410000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 390000L);
		result(listNextStop, 0L, 0L, 400000L);

		//case 2-2 M1 - M4 - M2 : M4 selected
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(430000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(430000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(420000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(420000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 395000L);
		result(listNextStop, 0L, 0L, 400000L);

		////////////////CASE M2

		//case M2-1 -  M2 - M1 - M4 :M2 selected
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(800000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(800000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 190000L);
		result(listNextStop, 0L, 200000L, 0L);

		//case M2-2 -  M2 - M1 - M4 :M2 selected (M4 in M1 tol)
		nextStopM1.setNextStopByType(430000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(430000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(460000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(460000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 390000L);
		result(listNextStop, 0L, 400000L, 0L);

		//case M2-1 -  M2 - M4 - M1 :M2 selected (M4 not in M2 tol)
		nextStopM1.setNextStopByType(800000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(800000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 190000L);
		result(listNextStop, 0L, 200000L, 0L);

		//case M2-1 -  M2 - M4 - M1 :M4 selected (M4 in M2 tol)
		nextStopM1.setNextStopByType(460000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(460000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(430000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(430000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 380000L);
		result(listNextStop, 0L, 400000L, 0L);

		//CASE M4
		//case M4-1 -  M4 - M1 - M2 :M4 selected (M2 in M1 tol)
		nextStopM1.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(610000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(610000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 385000L);
		result(listNextStop, 0L, 0L, 400000L);

		//case M4-1 -  M4 - M1 - M2 :M4 selected (M2 not in M1 tol)
		nextStopM1.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(700000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(700000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 400000L);
		result(listNextStop, 0L, 0L, 400000L);

		//case M4-1 -  M4 - M2 - M1 :M4 selected 
		nextStopM1.setNextStopByType(800000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(800000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 400000L);
		result(listNextStop, 0L, 0L, 400000L);

	}

	public void result(List<MpNextStopByScoreDto> listNextStop, Long valM1, Long valM2, Long valM4) {
		for (MpNextStopByScoreDto nextStop : listNextStop)
		{
			if ("M1".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM1));
			}
			else if ("M2".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM2));
			}
			else if ("M4".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM4));
			}
		}
	}

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValueWithNotMul() {

		MaintenancePlanBusiness bus = new MaintenancePlanVariableSchedulingBusiness("0", "0", "0", "0", new Locale("EN"), customer, null);
		// -- init M1 every 100 000 KM /  M2 every 200 000 KM /  M4 every 400 000 KM

		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setCode("M1");
		m1.setId(1L);

		MpIntervalDto m2 = new MpIntervalDto(0L, 0L, 0L, 200000L, 0L, 0L);
		m2.setCode("M2");
		m2.setId(2L);

		MpIntervalDto m4 = new MpIntervalDto(0L, 0L, 0L, 400000L, 0L, 0L);
		m4.setCode("M4");
		m4.setId(4L);

		MpIntervalDto ep1 = new MpIntervalDto(0L, 0L, 0L, 150000L, 0L, 0L);
		ep1.setCode("EP1");
		ep1.setId(5L);

		MpIntervalDto ep2 = new MpIntervalDto(0L, 0L, 0L, 250000L, 0L, 0L);
		ep2.setCode("EP2");
		ep2.setId(6L);

		// set the score
		MpNextStopByScoreDto nextStopM1 = new MpNextStopByScoreDto(m1, customer);
		MpNextStopByScoreDto nextStopM2 = new MpNextStopByScoreDto(m2, customer);
		MpNextStopByScoreDto nextStopM4 = new MpNextStopByScoreDto(m4, customer);
		MpNextStopByScoreDto nextStopEP1 = new MpNextStopByScoreDto(ep1, customer);
		MpNextStopByScoreDto nextStopEP2 = new MpNextStopByScoreDto(ep2, customer);

		List<MpNextStopByScoreDto> listNextStop = new ArrayList<>();
		listNextStop.add(nextStopM1);
		listNextStop.add(nextStopM2);
		listNextStop.add(nextStopM4);
		listNextStop.add(nextStopEP1);
		listNextStop.add(nextStopEP2);
		Collections.sort(listNextStop, new MpScoreDto().new ScoreComparator());

		//CASE M4
		//case M4-1 -  M4 - M1 - M2 :M4 selected (M2 in M1 tol)
		nextStopM1.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(610000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(610000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopEP1.setNextStopByType(410000L, MpType.MP_KM);
		nextStopEP1.setNextStopRecalculatedByType(410000L, MpType.MP_KM);
		nextStopEP2.setNextStopByType(420000L, MpType.MP_KM);
		nextStopEP2.setNextStopRecalculatedByType(420000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result2(listNextStop, 0L, 0L, 400000L, 410000L, 420000L);
	}

	public void result2(List<MpNextStopByScoreDto> listNextStop, Long valM1, Long valM2, Long valM4, Long valEP1, Long valEP2) {
		for (MpNextStopByScoreDto nextStop : listNextStop)
		{
			if ("M1".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM1));
			}
			else if ("M2".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM2));
			}
			else if ("M4".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM4));
			}
			else if ("EP1".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valEP1));
			}
			else if ("EP2".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valEP2));
			}
		}
	}

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValueWithDifferentMultipleIndependant() {
		MaintenancePlanBusiness bus = new MaintenancePlanVariableSchedulingBusiness("0", "0", "0", "0", new Locale("EN"), customer, null);
		// -- init M1 every 100 000 KM /  M2 every 200 000 KM /  M4 every 400 000 KM

		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setCode("M1");
		m1.setId(1L);

		MpIntervalDto m2 = new MpIntervalDto(0L, 0L, 0L, 200000L, 0L, 0L);
		m2.setCode("M2");
		m2.setId(2L);

		MpIntervalDto m4 = new MpIntervalDto(0L, 0L, 0L, 400000L, 0L, 0L);
		m4.setCode("M4");
		m4.setId(4L);

		MpIntervalDto ep1 = new MpIntervalDto(0L, 0L, 0L, 125000L, 0L, 0L);
		ep1.setCode("EP1");
		ep1.setId(5L);

		MpIntervalDto ep2 = new MpIntervalDto(0L, 0L, 0L, 250000L, 0L, 0L);
		ep2.setCode("EP2");
		ep2.setId(6L);

		// set the score
		MpNextStopByScoreDto nextStopM1 = new MpNextStopByScoreDto(m1, customer);
		MpNextStopByScoreDto nextStopM2 = new MpNextStopByScoreDto(m2, customer);
		MpNextStopByScoreDto nextStopM4 = new MpNextStopByScoreDto(m4, customer);
		MpNextStopByScoreDto nextStopEP1 = new MpNextStopByScoreDto(ep1, customer);
		MpNextStopByScoreDto nextStopEP2 = new MpNextStopByScoreDto(ep2, customer);

		List<MpNextStopByScoreDto> listNextStop = new ArrayList<>();
		listNextStop.add(nextStopM1);
		listNextStop.add(nextStopM2);
		listNextStop.add(nextStopM4);
		listNextStop.add(nextStopEP1);
		listNextStop.add(nextStopEP2);
		Collections.sort(listNextStop, new MpScoreDto().new ScoreComparator());

		//CASE M4
		//case M4-1 -  M4 - M1 - M2 :M4 selected (M2 in M1 tol)
		nextStopM1.setNextStopByType(600000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(600000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(610000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(610000L, MpType.MP_KM);
		nextStopM4.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM4.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopEP1.setNextStopByType(410000L, MpType.MP_KM);
		nextStopEP1.setNextStopRecalculatedByType(410000L, MpType.MP_KM);
		nextStopEP2.setNextStopByType(420000L, MpType.MP_KM);
		nextStopEP2.setNextStopRecalculatedByType(420000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result2(listNextStop, 0L, 0L, 400000L, 0L, 410000L);
	}

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValueWithtDifferentMultipleDependant() {
		MaintenancePlanBusiness bus = new MaintenancePlanVariableSchedulingBusiness("0", "0", "0", "0", new Locale("EN"), customer, null);
		// -- init M1 every 100 000 KM /  M2 every 200 000 KM /  M4 every 400 000 KM

		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setCode("M1");
		m1.setId(1L);

		MpIntervalDto m2 = new MpIntervalDto(0L, 0L, 0L, 200000L, 0L, 0L);
		m2.setCode("M2");
		m2.setId(2L);

		MpIntervalDto m3 = new MpIntervalDto(0L, 0L, 0L, 300000L, 0L, 0L);
		m3.setCode("M3");
		m3.setId(3L);

		// set the score
		MpNextStopByScoreDto nextStopM1 = new MpNextStopByScoreDto(m1, customer);
		MpNextStopByScoreDto nextStopM2 = new MpNextStopByScoreDto(m2, customer);
		MpNextStopByScoreDto nextStopM3 = new MpNextStopByScoreDto(m3, customer);

		List<MpNextStopByScoreDto> listNextStop = new ArrayList<>();
		listNextStop.add(nextStopM1);
		listNextStop.add(nextStopM2);
		listNextStop.add(nextStopM3);

		Collections.sort(listNextStop, new MpScoreDto().new ScoreComparator());

		//case 1 M1 - M2 - M3 :M1 selected
		nextStopM1.setNextStopByType(100000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(100000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 100000L, 0L, 0L);

		//case 2 M1 - M2 - M3 : M2 selected
		nextStopM1.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(210000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(210000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 0L);

		//case 3 M1 - M3 - M2 :M3 selected
		nextStopM1.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(300000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(420000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(420000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(320000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(320000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 0L, 300000L);

		//case 3 M1 - M2 - M3 :M2/M3 selected
		nextStopM1.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(300000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(310000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(310000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(320000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(320000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 300000L, 300000L);

		////////////////CASE M2

		//case M2-1 -  M2 - M1 - M3 :M2/M3 selected the algo alway select M2 and M3 if (M3 in tol of M1)
		nextStopM1.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(300000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(310000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(310000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 0L);

		//case M2-1 -  M2 - M1 - M3 :M2/M3 selected the algo alway select M2 and M3 if (M3 in tol of M1)
		nextStopM1.setNextStopByType(210000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(210000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(215000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(215000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 210000L);

		//case M2-2 -  M2 - M1 - M3 :M2 selected (M3 in not M1 tol)
		nextStopM1.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(300000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(350000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(350000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 0L);

		//case M2-1 -  M2 - M3 - M1 :M2/M3 selected 
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(350000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(350000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 0L);

		//case M2-1 -  M2 - M3 - M1 :M2/M3 selected 
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(200000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(200000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(210000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(210000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 200000L, 210000L);

		//CASE M3
		//case M2-1 -  M3 - M1 - M2 :M2/M3 selected the algo alway select M2 and M3 if (M2 in tol of M1)
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(410000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(410000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 0L, 300000L);

		//CASE M3
		//case M2-1 -  M3 - M1 - M2 :M2/M3 selected the algo alway select M2 and M3 if (M2 in tol of M1)
		nextStopM1.setNextStopByType(310000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(310000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(320000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(320000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 310000L, 300000L);

		//case M2-2 -  M3 - M1 - M2 :M2 selected (M2  not in M1 tol)
		nextStopM1.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(450000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(450000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 0L, 300000L);

		//case M2-1 -  M3 - M2 - M1 :M2/M3 selected 
		nextStopM1.setNextStopByType(500000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(500000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(400000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(400000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 0L, 300000L);

		//case M2-1 -  M3 - M2 - M1 :M2/M3 selected 
		nextStopM1.setNextStopByType(500000L, MpType.MP_KM);
		nextStopM1.setNextStopRecalculatedByType(500000L, MpType.MP_KM);
		nextStopM2.setNextStopByType(310000L, MpType.MP_KM);
		nextStopM2.setNextStopRecalculatedByType(310000L, MpType.MP_KM);
		nextStopM3.setNextStopByType(300000L, MpType.MP_KM);
		nextStopM3.setNextStopRecalculatedByType(300000L, MpType.MP_KM);

		bus.applyNextStopMultiples(listNextStop, MpType.MP_KM, 100000L);
		result3(listNextStop, 0L, 310000L, 300000L);

	}

	public void result3(List<MpNextStopByScoreDto> listNextStop, Long valM1, Long valM2, Long valM3) {
		for (MpNextStopByScoreDto nextStop : listNextStop)
		{
			if ("M1".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM1));
			}
			else if ("M2".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM2));
			}
			else if ("M3".equals(nextStop.getInterval().getCode()))
			{
				assertTrue(nextStop.getInterval().getCode() + " next stop:", nextStop.getNextStopRecalculatedByType(MpType.MP_KM).equals(valM3));
			}
		}
	}

	/**
	 * Take basic intervals with At value.
	 * History is saved under VIN VinDiesel.
	 * We never edit manually the history.
	 */
	@Test
	public void testAtValueComplex() {
		MaintenancePlanBusiness bus = new MaintenancePlanVariableSchedulingBusiness("0", "0", "0", "0", new Locale("EN"), customer, null);
		// -- init M1 every 100 000 KM /  M2 every 200 000 KM /  M4 every 400 000 KM

		MpIntervalDto m1 = new MpIntervalDto(0L, 0L, 0L, 100000L, 0L, 0L);
		m1.setCode("M1");
		m1.setId(1L);

		MpIntervalDto m2 = new MpIntervalDto(0L, 0L, 0L, 200000L, 0L, 0L);
		m2.setCode("M2");
		m2.setId(2L);

		MpIntervalDto m3 = new MpIntervalDto(0L, 0L, 0L, 300000L, 0L, 0L);
		m3.setCode("M3");
		m3.setId(3L);

		// set the score
		MpNextStopByScoreDto nextStopM1 = new MpNextStopByScoreDto(m1, customer);
		MpNextStopByScoreDto nextStopM2 = new MpNextStopByScoreDto(m2, customer);
		MpNextStopByScoreDto nextStopM3 = new MpNextStopByScoreDto(m3, customer);

		List<MpNextStopByScoreDto> listNextStop = new ArrayList<>();
		listNextStop.add(nextStopM1);
		listNextStop.add(nextStopM2);
		listNextStop.add(nextStopM3);

		Collections.sort(listNextStop, new MpScoreDto().new ScoreComparator());

	}

}
