import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegistersComponent } from './registers/registers.component';
@NgModule({
  declarations: [],
  imports: [CommonModule],
})
export class PlanModule {
  
}
