import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-registers',
  templateUrl: './registers.component.html',
  styleUrls: ['./registers.component.css']
})
export class RegistersComponent {
  showContent:boolean = false;

  toggleContent() {
    this.showContent = !this.showContent;
  }
}
