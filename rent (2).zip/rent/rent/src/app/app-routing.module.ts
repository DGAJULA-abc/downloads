import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddPropertyComponent } from './add-property/add-property.component';
import { PropertyDetailsComponent } from './property-details/property-details.component';
import { PropertyListComponent } from './property-list/property-list.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserRegisterComponent } from './user-register/user-register.component';

const routes: Routes = [
  {path:'' , component: PropertyListComponent},
  {path:'rent-property' , component: PropertyListComponent},
  {path:'property-datails/:id', component: PropertyDetailsComponent},
  {path:'user/login' , component: UserLoginComponent},
  {path:'user/register' , component: UserRegisterComponent},
  {path:'add-property' , component: AddPropertyComponent},
  {path:'**' , component: PropertyListComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
