import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { housing } from './housing';
import { map } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class HousingService {

  constructor(private http:HttpClient) { }

  getAllProperties(SellRent: number): Observable<housing[]> {
    return this.http.get<housing[]>(
      `http://localhost:3000/property`
    ).pipe(
      map(data=>{
        const propertiesArray: Array<housing> = [];

        for(const id in data){
          if(data.hasOwnProperty(id) && data[id].SellRent === SellRent){
          propertiesArray.push(data[id]);
        }
       }
        return propertiesArray;
      })
    );
}
}
