export interface housing {
  Id?: number;
  SellRent:number;
  Name: string;
  Type: string;
  price: string;
  Image?: string;
}
