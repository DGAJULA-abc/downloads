import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { housing } from '../housing';
import { HousingService } from '../housing.service';

@Component({
  selector: 'app-property-list',
  templateUrl: './property-list.component.html',
  styleUrls: ['./property-list.component.css']
})
export class PropertyListComponent implements OnInit {
  properties!: Array<housing>;
  SellRent=1;
  constructor(private http:HttpClient, private housingService:HousingService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    if(this.route.snapshot.url.toString()){
        this.SellRent=2;
    }
    this.housingService.getAllProperties(this.SellRent).subscribe(
     data=>{
     this.properties=data;
     console.log(data);
     }, error =>{
       console.log(error);
     }
    );
  }

}
