export interface User{
userName: string;
email: string;
password: string;
mobile: string;
 }
