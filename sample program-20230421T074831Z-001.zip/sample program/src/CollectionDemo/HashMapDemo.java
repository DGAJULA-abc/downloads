package CollectionDemo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap has = new HashMap();
		has.put("name", "dinesh");
		has.put("dob", "10thjuly1999");
		has.put("place", "Ananthapur");
		has.put("nickname", "dinesh");
		
		Set s = has.keySet();   //pre define method
		Iterator it = s.iterator();
		while (it.hasNext()) { //check entrys
			Object obj = it.next();
			String str = (String) obj;//type coasting
			System.out.println(str + " " + has.get(str));
		}
	}
}
