package CollectionDemo;

import java.util.*;

public class HashTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Hashtable D1=new Hashtable();
      D1.put("a", "Dinesh");
      D1.put("c","Dileep");
      D1.put("b", "yoga");
      D1.put("e", "keeru");
      D1.put("d", "pandu");
      
    Set s1= D1.keySet() ;
    Iterator d= s1.iterator();
    while(d.hasNext()) {
    	Object obj=d.next();
    	String str=(String) obj;
    	System.out.println(str+" "+D1.get(str));
    }
    
	}

}
