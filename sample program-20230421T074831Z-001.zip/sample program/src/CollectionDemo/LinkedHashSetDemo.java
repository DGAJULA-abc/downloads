package CollectionDemo;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   LinkedHashSet<Integer> a1=new LinkedHashSet<>();
     a1.add(6);
     a1.add(8);
     a1.add(9);
     a1.add(1);
     a1.add(12);
     a1.add(1);
    // System.out.println(a1);
	for(Integer k:a1) {
		System.out.println(k);
	}
	}

}
