package CollectionDemo;

import java.util.*;

public class Linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> zz = new LinkedList<>();
          zz.add("rtugf");
          zz.add("rhjjg");
          zz.add("satyhjk");
          zz.add("rhjjg");
       //  for(String s:zz) {
        	// System.out.println(s);
        // }
          //for(int i=0;i<zz.size();i++) {
        	//  System.out.println(zz.get(i));
          //}
          Iterator<String> it = zz.iterator();
          while(it.hasNext()) {
        	  System.out.println(it.next());
          }
          
	}

}
