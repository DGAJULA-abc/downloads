package CollectionDemo;
import java.util.*;
public class List1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> a=new ArrayList<>();
a.add("Dinesh");
a.add("Dileep");
a.add("yoga");
a.add("keeru");
a.add(0, "pandu");
System.out.println(a.lastIndexOf("pandu"));

List<String> b=new ArrayList<>();
b.add("Dinesh");
b.add("Dileep");
b.add("yoga");
b.add("keeru");
b.add(0, "pandu");
//b.addAll(a);
//b.clear();


//------------itorator---------------
Iterator d= a.iterator();
while(d.hasNext()) {
System.out.println(d.next());
}


System.out.println();

//---------------------Forloop-----------
for(int i=0;i<b.size();i++) {
	System.out.println(b.get(i));
}
//-------------forEach-----------
	//for(String d:a) {
		//System.out.println(d);
	//}


//---------------ForEach-------------
//a.forEach(a1->{
	//System.out.println(a1);
//});
	}

}
