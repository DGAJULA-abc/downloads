package CollectionDemo;
import java.util.*;
class Student{
	int id;
	String name,addres;
	public Student(int id, String name, String addres) {
		this.id = id;
		this.name = name;
		this.addres = addres;
	}
	
}
public class List2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  List<Student> list= new ArrayList<>();
  Student s1= new Student(1,"dinesh", "narpala");
  Student s2= new Student(2,"dileep", "narpala");
  Student s3= new Student(3,"yoga", "narpala");
  Student s4= new Student(4,"keeru", "narpala");
  list.add(s1);
  list.add(s2);
  list.add(s3);
  list.add(s4);
  for(Student s:list) {
	  System.out.println(s.id+" "+s.name+" "+s.addres);
  }
	}

}
