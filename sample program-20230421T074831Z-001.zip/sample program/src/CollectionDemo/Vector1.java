package CollectionDemo;

import java.util.Vector;

public class Vector1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Vector v= new Vector(4,8);
      v.add(4);
      v.add(7);
      v.add(3);
      v.add(1);
      v.add(1);
      v.add(1);
      v.add(1);
      v.add(1);
      v.add(1); 
      v.add(1);
      v.add(1);
      System.out.println(v.capacity());
      System.out.println(v.size());
	}

}
