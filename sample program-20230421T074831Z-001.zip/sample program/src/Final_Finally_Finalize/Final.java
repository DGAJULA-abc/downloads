package Final_Finally_Finalize;

//------------------------------------
class sub {
//declaring final variable
	final int age = 18;

	void display() {
//Here it will show Compilation error.
//age = 55;
		System.out.println(age);
	}
}

//-------------------------------------
public class Final {
	public static void main(String[] args) {
		sub obj = new sub();
		obj.display();
	}
}