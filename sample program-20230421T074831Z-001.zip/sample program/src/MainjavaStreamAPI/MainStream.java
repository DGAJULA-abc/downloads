package MainjavaStreamAPI;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainStream {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
     Employee1 e1=new Employee1(1,"dinesh",Gender.MALE,22);
     Employee1 e2=new Employee1(2,"dileep",Gender.MALE,21);
     Employee1 e3=new Employee1(3,"yoga",Gender.FEMALE,21);
     Employee1 e4=new Employee1(4,"keeru",Gender.FEMALE,14);
     Employee1 e5=new Employee1(5,"pandu",Gender.FEMALE,10);
     Employee1 e6=new Employee1(6,"Chintu",Gender.MALE,14);
     
     Salary1 s1=new Salary1(1,25000,"Software Engineer");
     Salary1 s2=new Salary1(2,35000,"Software Engineer");
     Salary1 s3=new Salary1(3,25000,"Software Engineer");
     Salary1 s4=new Salary1(4,20000,"Software Engineer");
     Salary1 s5=new Salary1(5,15000,"Software Engineer");
     Salary1 s6=new Salary1(6,20000,"Software Engineer");
     
     List<Employee1> employeeList = new ArrayList<>();
     List<Salary1> sal= new ArrayList<>();
     
     employeeList.add(e1);
     employeeList.add(e2);
     employeeList.add(e3);
     employeeList.add(e4);
     employeeList.add(e5);
     employeeList.add(e6);
     
     sal.add(s1);
     sal.add(s2);
     sal.add(s3);
     sal.add(s4);
     sal.add(s5);
     sal.add(s6);
     
     
     //employeeList.stream().filter(emp->emp.getAge()==21).forEach(emp->System.out.println(emp.getAge()+" "+emp.getId()+" "+emp.getName()));
       
   //  sal.stream().filter(emp->emp.getSalary()==20000).forEach(emp->System.out.println(emp.getId()+" "+emp.getSalary()));
   
     for(int i=0;i<employeeList.size();i++) {
    	 if(employeeList.get(i).getId()==sal.get(i).getId()) {
    	 System.out.println(employeeList.get(i).getId()+"  "+sal.get(i).getSalary()+" "+employeeList.get(i).getName());
     }
     }
	}

}
