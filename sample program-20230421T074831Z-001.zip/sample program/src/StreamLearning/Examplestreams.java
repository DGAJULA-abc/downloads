package StreamLearning;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Examplestreams {

	public static void main(String[] args) {
		List<Integer> list= Arrays.asList(1,2,3,4,5,6,7);
		
		Stream<Integer> nstrem = list.stream();
		Stream<Integer> fresult = nstrem.filter(x -> x%2==0);
		fresult.forEach( x->{
			System.out.println(x);
		});
		
		// TODO Auto-generated method stub

	}

}
