package StreamLearning;

import java.util.Optional;

public class Optionalclass {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		
		//System.out.println(user.getUserName());
	
    User user = new User();
    Optional<String> obj = user.getUserName();
    if(obj.isPresent() && obj.get().equalsIgnoreCase("dinesh")) {
    	System.out.println("equal");
    }
    else {
    	System.out.println("not equal");
    }
    //if(user.getUserName().equalsIgnoreCase("dinesh")) {
    	//System.out.println("equal");
    //}
    //else {
    //	System.out.println("not equal");
   // }
    
	}
	

}
