package StreamLearning;

import java.util.*;

public class SteamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  List<Integer> v= Arrays.asList(12,20,35,46,55,68,75);
  System.out.println(v.stream()
		  .filter(i->i%5==0)
		  .map(i->i*2)
		  .findFirst()
		  .orElse(0)
		  );
	}

}
