package StringProgram;
class Add{
	
  public int hello() {
	  int a=10;
		int b=20;
		return a+b;
	}
}
public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Add a= new Add();

    System.out.println(a.hello());
	}

}
