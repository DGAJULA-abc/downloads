package StringProgram;

import java.util.Scanner;

public class Prime1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
	
    System.out.println("Enter number");
    int s=sc.nextInt();
    int c=0;
    for(int i=1;i<=s;i++) {
    	if(s%i==0) {
    		c++;
    	}
    }
    	if(c==2) {
    		System.out.println("prime");
    	}else {
    		System.out.println("not prime");
    	}
    }
	}


