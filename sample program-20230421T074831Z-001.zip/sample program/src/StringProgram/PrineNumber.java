package StringProgram;

import java.util.Scanner;

public class PrineNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc=new Scanner(System.in);
       System.out.println("enter the number");
       int n=sc.nextInt();
       int c=0;
       int i=1;
       while(i<=n) {
    	 if(n%i==0) {
    		 c++;
    		
    	 }
    	 i++;
       if(c==2) {
    	   System.out.println("prime");
    	 
            }
            else {
    	   System.out.println("not prime");
    	   break;
       }

	}
	}
}
