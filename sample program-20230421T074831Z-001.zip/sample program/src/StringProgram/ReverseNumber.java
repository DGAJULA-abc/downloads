package StringProgram;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           long a,b;
           long r=0;
           Scanner sc=new Scanner(System.in);
           System.out.println("enter the No");
           a=sc.nextInt();
          // while(a>0) {
        	  // b=a%10;
        	  // a=a/10;
        	//   r=(r*10)+b;
           //}
           for(int i=1;i<=a;i++) {
        	   b=a%10;
        	   a=a/10;
        	   r=r*10+b;
           }
           //System.out.println(a);
           System.out.println(r);
	}

}
