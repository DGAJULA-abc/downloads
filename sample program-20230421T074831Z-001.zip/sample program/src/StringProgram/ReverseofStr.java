package StringProgram;

public class ReverseofStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String srt="Dinesh Royal";
String r="";
int len=srt.length();
for(int i=len-1;i>=0;i--) {
	r=r+srt.charAt(i);
}
System.out.println(r);
}
}