package StringProgram;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//int a[]= {1,4,2,7,8,8,3,9,4,0,2,5};
//System.out.println(a.length);
//for(int i=0;i<a.length;i++) {
	//for(int j=i+1;j<a.length;j++) {
		//if(a[i]==a[j]) {
			//System.out.println(a[j]);
	
		//}
	//}
	//}
		String s="dinesh";
		StringBuilder ogg =new StringBuilder(s);
		ogg.reverse();
		System.out.println(ogg);
		
}
}