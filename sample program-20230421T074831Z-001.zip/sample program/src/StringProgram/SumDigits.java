package StringProgram;

import java.util.Scanner;

public class SumDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int n,x;
        int sum=0;
        Scanner sc= new Scanner(System.in);
        System.out.println("enter value");
        n=sc.nextInt();
        while(n>0) {
        	x=n%10;
        	sum=sum+x;
        	n=n/10;
        }
        System.out.println(sum);
	}

}
