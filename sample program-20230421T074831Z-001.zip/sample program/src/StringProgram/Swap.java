package StringProgram;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int a=18;
 int b=19;
// b=a+b; 
// a=b-a;
// b=b-a;
 int temp=a;
 a=b;
 b=temp;
 System.out.println(a);
 System.out.println(b);
	}

}
