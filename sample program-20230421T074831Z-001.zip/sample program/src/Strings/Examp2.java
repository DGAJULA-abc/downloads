package Strings;

public class Examp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String s=new String("welcom");
      s.concat("Good morning");
      System.out.println(s);
      
      String a=new String("welcom");
     a= a.concat("Good morning");
      System.out.println(a); 
      
      
      
	}

}
