package Strings;

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Dinesh";  
		  s= s.concat(" Royal ");
		   System.out.println(s);
	}

}
