package Strings;
class Stu{
	String s1="good";
	String s2="good";
	public void hi() {
		System.out.println(s1);
	}
	//literal method
}
public class StringImutable {
public static void main(String args[]) {
	Stu s=new Stu();
	s.hi();
}
}
