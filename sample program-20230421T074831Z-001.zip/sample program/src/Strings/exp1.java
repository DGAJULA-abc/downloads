package Strings;

import java.util.Scanner;

public class exp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int i=sc.nextInt();
		double d= sc.nextDouble();
		sc.nextLine();
		String s=sc.nextLine();
		
		System.out.println(s);
		System.out.println(d);
		System.out.println(i);
		
	}

}
