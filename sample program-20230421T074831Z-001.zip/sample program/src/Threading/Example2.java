package Threading;
class MyThreadDemo implements Runnable{
	int b[]= {1,6,5,9,2,4};
	public void run() {
		for(int i=0;i<b.length;i++) {
			b[i]=b[i]*2;
			System.out.println(b[i]);
		}
	}
}
public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThreadDemo h1= new MyThreadDemo();
		//Thread t1 = new Thread(h1);
		h1.run();
	}

}
