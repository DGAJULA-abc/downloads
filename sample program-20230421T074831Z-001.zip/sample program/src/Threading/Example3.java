package Threading;

public class Example3 {

	public static void main(String[] args) throws Exception 
	{
		// TODO Auto-generated method stub
    
      
      Thread t1=new Thread(() ->
      {
			for(int i=1;i<=5;i++) {
			System.out.println(" Hello ");
			try {Thread.sleep(1000);}catch(Exception e) {}
		}
	});
      Thread t11=new Thread(()-> {
  		
			for(int i=1;i<=5;i++) {
			System.out.println(" Hi");
			try {Thread.sleep(1000);}catch(Exception e) {}
		}
		});
      
      t1.start();
		try {Thread.sleep(10);}catch(Exception e) {}
      t11.start();
      
      
      
      t1.join();
      t11.join();
      System.out.println(t1.isAlive());
      
      System.out.println(" Bye");
	}

}
	
