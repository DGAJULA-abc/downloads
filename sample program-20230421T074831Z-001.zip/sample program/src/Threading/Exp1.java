package Threading;
class Super{
	public void run() {
		System.out.println("Thread class");
	}
}
class Myclass extends Super implements Runnable{
	int values[]= {6,5,7,8,4,9};
	
	public void run() {
	for(int i=0;i<=5;i++) {
		values[i]=values[i]*2;
		System.out.println(values[i]);
	}
		
	}
	
}
public class Exp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Super n=new Myclass();
       n.run();

	}

}
