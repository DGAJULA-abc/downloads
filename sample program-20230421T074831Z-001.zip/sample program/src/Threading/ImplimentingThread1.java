package Threading;
class A implements Runnable{
	public void run() {
		System.out.println("this is runnable");
	}
}
public class ImplimentingThread1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        A a1= new A();
        // Thread t1=new Thread(a1);
  
       a1.run();
	}

}
