package Threading;
		class SleepMethod1 extends Thread{  
			 public void run(){  
			  for(int i=1;i<=5;i++){  
				    System.out.println("hello"); 
			  try{Thread.sleep(1000);}catch(InterruptedException e){System.out.println(e);}  
	 
			  }  
			  
			  for(int j=1;j<=5;j++){  
				    System.out.println("hi");
				  try{Thread.sleep(1000);}catch(InterruptedException e){System.out.println(e);}  
				  
				  } 
			 }  
			 
			 public static void main(String args[]){  
				 SleepMethod1 t1=new SleepMethod1();  
				 SleepMethod1 t2=new SleepMethod1();  
			   
			  t1.start();  
			  t2.start();  
			 }  	
	}


