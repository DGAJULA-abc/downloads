package basic;

public class NumberWordsString {
String s="Dinesh dileep yoga keeru pandu kavya sunitha";
String w[]=s.split(" ");
System.out.println(w.length);
  
   //String s = "Sharma is a good player and he is so punctual";  
  // String words[] = s.split(" ");  
 // System.out.println("The Number of words present in the string are : "+words.length);  

}
