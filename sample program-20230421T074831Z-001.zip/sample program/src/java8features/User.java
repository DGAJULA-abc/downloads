package java8features;

public interface User {
public String run(String id, String name);
}
