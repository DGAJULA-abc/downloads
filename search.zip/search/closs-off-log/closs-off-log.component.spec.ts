import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClossOffLogComponent } from './closs-off-log.component';

describe('ClossOffLogComponent', () => {
  let component: ClossOffLogComponent;
  let fixture: ComponentFixture<ClossOffLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClossOffLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClossOffLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
