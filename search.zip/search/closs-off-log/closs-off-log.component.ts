import { Component } from '@angular/core';

@Component({
  selector: 'app-closs-off-log',
  templateUrl: './closs-off-log.component.html',
  styleUrls: ['./closs-off-log.component.css']
})
export class ClossOffLogComponent {
  Data = [
    {site:'site 1' ,WeekEnding:'', user:'',status: 'status 1',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 2' ,WeekEnding:'', user:'',status: 'status 2',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 3' ,WeekEnding:'', user:'',status: 'status 3',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 4 ' ,WeekEnding:'', user:'',status:'status 4',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 5' ,WeekEnding:'', user:'',status: 'status 5',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 6' ,WeekEnding:'', user:'',status: 'status 6',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 7' ,WeekEnding:'', user:'',status: 'status 7',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 8' ,WeekEnding:'', user:'',status: 'status 8',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 9' ,WeekEnding:'', user:'',status: 'status 9',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'site 10' ,WeekEnding:'', user:'',status: 'status 10',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'status 1',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'status 1',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'status 1',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'Submitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'Submitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: 'NotSubmitted',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
    {site:'status' ,WeekEnding:'', user:'',status: '',submitted:'',Started:'',Exported:'', Reconclied:'', Reported:'', Cancelled:''},
  ];
  displayedColumns: string[] = ['Site..', 'Week Ending..', 'user..','Status..','Submitted..' , 'Started..','Exported..','Reconclied..','Reported..','Cancelled..' ];
}
