import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  
  showservices:boolean=false;
  showtrips:boolean=false;

  constructor(private router: Router
  ) {}

  showsServices(){
    this.showservices=!this.showservices;
    // this.router.navigate(['home/search/services']);
    this.showtrips=false;
  }

  showTrips(){
    this.showservices=false;
    this.showtrips=!this.showtrips;
  }
}
