import { Component } from '@angular/core';
import { MatCalendarCellCssClasses } from '@angular/material/datepicker';
import { addevents } from './interface/addevents';
import { AddeventsServices } from './services/addevents.services';
// import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Calendar';
  selectedDate: any;
  courses : any = ' ';
  courseList: Array<addevents>;
  todayEvents: Array<addevents>;
  mandatory: any = [];
  nonMandatory: any = [];
  overlappingDates: any = [];
flag= false;

  // private router:Router

  constructor(private addeventsService: AddeventsServices) {
    this.courseList = new Array<addevents>();
  }

  ngOnInit() {
    this.addeventsService.getAllCourses('ajay').subscribe(data => {
      this.courseList = data;
      this.getCourseDates(this.courseList);
      this.todayEvents = this.todaysEvents(this.courseList);
    });

  }
  DateRange(startDate: any, endDate: any) {
    let courseDates = [];
    const dateMove = new Date(startDate);
    let strDate = startDate;
    while (strDate < endDate) {
      strDate = dateMove.toISOString().slice(0, 10);
      courseDates.push(strDate);
      dateMove.setDate(dateMove.getDate() + 1);
    };
    if(strDate == endDate) {
      courseDates.push(strDate);
    }
    return courseDates;
  }
  getCourseDates(courseList: addevents[]) {
    courseList.map(course=>{if(course.courseAssignment.category == 'non-mandatory') {
      let dates = this.DateRange(course.courseAssignment.startDate,course.courseAssignment.endDate);
      this.nonMandatory = this.nonMandatory.concat(dates);
    }
  });
    courseList.map(course=>{if(course.courseAssignment.category == 'mandatory') {
      let date = this.DateRange(course.courseAssignment.startDate,course.courseAssignment.endDate);
      this.mandatory = this.mandatory.concat(date);
    }
    });
   const allDates = this.mandatory.concat(this.nonMandatory);
    const unique = [...new Set(allDates.map((propYoureChecking: { mandatory: any; }) => propYoureChecking.mandatory))];
    this.overlappingDates =this.mandatory.filter((element: any) => this.nonMandatory.includes(element));
    this.flag = true;
  }
  onSelect(event: any) {
    this.selectedDate = event;
    // this.router.navigateByUrl('/addEvent');
  }

  dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      const highlightDate = this.mandatory
        .map((startDate: any) => new Date(startDate))
        .some(
          (d : any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
        const nonMandHighlight = this.nonMandatory.map((startDate: any) => new Date(startDate))
        .some(
          (d : any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
        const overLap = this.overlappingDates.map((startDate: any) => new Date(startDate))
        .some(
          (d : any) =>
            d.getDate() === date.getDate() &&
            d.getMonth() === date.getMonth() &&
            d.getFullYear() === date.getFullYear()
        );
      return overLap ? 'overlapDates' : ( highlightDate? 'mandatory': ( nonMandHighlight? 'non-mandatory':'')) ;
    };
  }
  dateCheck(from: any,to: any): boolean {
    let today = new Date().toISOString().slice(0, 10);
    let fDate,lDate,cDate;
    fDate = Date.parse(from);
    lDate = Date.parse(to);
    cDate = Date.parse(today);
    if((cDate <= lDate && cDate >= fDate)) {
        return true;
    }
    return false;
}
todaysEvents(courseList: addevents[]): addevents[] {
  
  let courses = courseList.filter((course: addevents)=>
    this.dateCheck(course.courseAssignment.startDate,course.courseAssignment.endDate)
  );
  console.log(courses);
return courses;

}
filters(event : Event){
  //this.courseList.filter((course: addevents)=>course.courseAssignment.category == event)
}
}
