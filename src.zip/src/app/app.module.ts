
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatDatepickerModule
} from '@angular/material/datepicker';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { MaterialCalendarModule } from 'material-calendar';
import {AppComponent} from './app.component';
import {MatCardModule} from '@angular/material/card';
import { NgModule } from '@angular/core';
import { MatNativeDateModule } from '@angular/material/core';
import { CalendarEventsComponent } from './calendar-events/calendar-events.component';
@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    MatDatepickerModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialCalendarModule,
    MatCardModule,
    MatNativeDateModule,
    HttpClientModule
  ],
  declarations: [AppComponent, CalendarEventsComponent],
  bootstrap: [AppComponent],
  providers: []
})
export class AppModule {}


