export interface addevents {
    courseId: number,
    trainingPlatform: string;
    courseName: string;
    platformName: string;
    courseUrl: string;
    learningHours: number;
    courseAssignment: {
      assignmentId: number,
      userId: string,
      startDate: Date,
      endDate: Date,
      category: string,
      trainingType: string,
      courseId: number;
      courseStatus: string;
      completedDateTime: Date;
    };
}