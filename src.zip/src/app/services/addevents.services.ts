import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { addevents } from '../interface/addevents';
@Injectable({
    providedIn: 'root',
  })
  export class AddeventsServices{
    constructor(private httpClient: HttpClient) {}
    getAllCourses(userId: any): Observable<addevents[]> {
        return this.httpClient.get<addevents[]>(
          `http://localhost:3000/events`
        );
      }
  }