package com.capgemini.dto;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ViewStatusDto {
	private int id;
	private String userId;
    private List<Course> course;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<Course> getCourse() {
		return course;
	}
	public void setCourse(List<Course> course) {
		this.course = course;
	}
	
    
}
