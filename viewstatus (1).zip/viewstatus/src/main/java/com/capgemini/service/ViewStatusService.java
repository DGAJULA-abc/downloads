package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dto.Course;
import com.capgemini.dto.ViewStatusDto;
import com.capgemini.entity.ViewStatus;
import com.capgemini.repository.ViewStatusRepository;

@Service
public class ViewStatusService {

	@Autowired
	private ViewStatusRepository viewStatusRepository;

	public ViewStatus saveStatus(ViewStatus viewStatus) {
		return viewStatusRepository.save(viewStatus);
	}

	public List<ViewStatus> getViewStatus() {
		return null;
	}

	public List<ViewStatus> getAllViewStatus() {
		return viewStatusRepository.findAll();

	}

	public ViewStatusDto getByUserId(String userId) {
		List<ViewStatus> totalCourses = viewStatusRepository.findByUserId(userId);
		ViewStatusDto dto = new ViewStatusDto();
		List<Course> listCourse = new ArrayList<>();
		totalCourses.stream().forEach(course -> {

			Course courseObj = new Course();
			courseObj.setCourseId(course.getCourseId());
			courseObj.setCourseName(course.getCourseName());
			courseObj.setCourseStatus(course.getCourseStatus());
			courseObj.setStartDate(course.getStartDate());
			courseObj.setEndDate(course.getEndDate());
			listCourse.add(courseObj);
			dto.setId(course.getId());
			dto.setUserId(course.getUserId());
			dto.setCourse(listCourse);

		});
		System.err.println("totalCourses " + totalCourses.size());
		return dto;

	}

}
