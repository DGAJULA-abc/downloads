package com.capgemini;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capgemini.dto.ViewStatusDto;
import com.capgemini.entity.ViewStatus;
import com.capgemini.repository.ViewStatusRepository;
import com.capgemini.service.ViewStatusService;

@SpringBootTest
public class ViewstatusApplicationTests {
	
	@Autowired
	private ViewStatusService service;
	
	@MockBean
    private ViewStatusRepository repository;
	
	@Test
	public void getAllViewStatusTest() {
		when(repository.findAll()). thenReturn(Stream 
				.of(new ViewStatus(1, "DGAJULA", 202, "Cyber Security", "completed", "20/11/2021", "9/12/2021")).collect(Collectors.toList()));
	assertEquals(1, service.getAllViewStatus().size());
	}
	
	@Test
	public void getByUserIdTest() {
	 String viewStatus="DGAJULA";
	 when(repository.findByUserId(viewStatus)).thenReturn(Stream 
				.of(new ViewStatus(1, "DGAJULA", 202, "Cyber Security", "completed", "20/11/2021", "9/12/2021")).collect(Collectors.toList()));
	 ViewStatusDto dto = new ViewStatusDto();
	 dto = service.getByUserId(viewStatus);
	 assertEquals(dto, dto);
	}
	
	@Test
	public void saveStatusTest(){
		ViewStatus viewStatus = new ViewStatus(2,"DRAVI", 202, "C-Language","incomplete","23/11/2021", "20/12/2021");
		when(repository.save(viewStatus)).thenReturn(viewStatus);
		assertEquals(viewStatus, service.saveStatus(viewStatus));
	}
	
	@Test
	void contextLoads() {
	}

}
